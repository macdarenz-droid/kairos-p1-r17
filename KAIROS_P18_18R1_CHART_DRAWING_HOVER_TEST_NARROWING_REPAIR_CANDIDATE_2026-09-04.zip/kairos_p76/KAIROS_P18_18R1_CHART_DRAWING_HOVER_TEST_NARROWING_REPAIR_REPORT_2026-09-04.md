# KAIROS P18.18R1 — Chart Drawing Hover Test Narrowing Repair

## Authority
- Authoritative base: canonical P18.17 PASS, workflow run #218 / 33845110303.
- Failed P18.18 run #219 is evidence only and is not used as authority.

## Failure evidence
Canonical gate #219 passed exact scope, deterministic install, and lightweight-charts@5.2.1 proof, then failed TypeScript compilation only in `tests/chart-drawing-hover-port.test.ts` at the two listener invocations. TypeScript narrowed the locally captured callback variable to `never` at those call sites.

## Repair
P18.18 production scope is retained unchanged from the failed candidate. The test fixture now stores the injected hover listener in an explicitly typed mutable reference object, proves the listener was attached, then invokes it. This preserves the intended runtime assertion while avoiding the control-flow narrowing defect.

## Non-scope
No provider API expansion, click/selection, drag/edit, drawing truth mutation, persistence, calculation, market acquisition, journal truth, toolbar state, navigation state, autoscale policy, presentation-session integration, or P19 behavior is added.
