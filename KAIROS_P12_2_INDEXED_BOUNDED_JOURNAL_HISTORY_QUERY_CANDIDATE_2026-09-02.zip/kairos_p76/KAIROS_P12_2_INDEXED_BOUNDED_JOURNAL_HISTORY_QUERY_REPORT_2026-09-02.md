# KAIROS P12.2 Indexed Bounded Journal History Query

## Status
HOLD pending canonical GitHub gate.

## Authoritative base
KAIROS_P12_1R1_JOURNAL_HISTORY_QUERY_SCOPE_REPAIR_CANDIDATE_2026-09-02.zip — canonical PASS run #53.

## Objective
Remove the unbounded all-trades read from the P12 journal-history hot path before history UI is introduced.

## Research
Current official Dexie documentation was rechecked on 2026-09-02. `Table.orderBy(index)` requires an indexed property, and `reverse()` plus `limit()` bound an ordered collection. Kairos V2 already indexes `trades.updatedAt`, so this patch reuses that index without a schema migration. The locked P0 performance contract requires DB-index querying rather than always loading all trades and filtering/sorting in application or React memory.

## Owner trace
Journal consumer -> P12 application history query -> existing TradeRepository -> Dexie `updatedAt` index -> selected trades -> existing child repositories -> P11 Calculation Engine.

## Pre-change flow
P12.1R1 loaded every trade with `listAll()`, reconstructed child evidence for every trade, and sorted the complete result in application memory.

## Change
- Add `TradeRepository.listRecentByUpdatedAt(limit)` using the existing `updatedAt` index.
- Bound journal history to 100 trades by default and 500 maximum.
- Reject invalid/unbounded limits.
- Select the bounded trade set before loading child evidence.
- Update the prior P12.1R1 static verifier only to recognize the stronger indexed newest-first ordering path; all ownership/error checks remain unchanged.

## Non-scope
No UI, filters, search, cursor pagination, schema migration, writes, backup/restore, activation, theme, network, FX, chart, P13 visual P&L, or financial formula change.

## Data/state flow
Journal query -> bounded limit -> TradeRepository `updatedAt` descending index -> child evidence for selected trade IDs -> existing `calculateTradeMetrics()` -> immutable entries.

## Persistence
Read-only. Schema remains V2.

## Security
No new security surface.

## Theme
No theme impact.

## Offline
Fully local/offline.

## Tests
Existing history reconstruction/error tests retained. New tests prove indexed updated chronology with a limit of two and reject zero, >500, and fractional limits. Static verification forbids `trades.listAll()` and application full-set sorting in this query.

## Performance
The trade-selection stage is now index-backed and bounded before per-trade child reconstruction, removing direct dependence on total journal size from the first history query selection path.

## Known limitations
This establishes bounded recent history, not cursor pagination or user-facing filtering. `updatedAt` is the ordering key because it is already authoritative and indexed; a different persisted chronology key would require its own controlled schema/data migration.

## Real-device status
Not required for this backend/query-only slice.

## Result
HOLD until canonical GitHub Actions passes deterministic install, build, full unit regression, full P1-P12.2 regression, and P12.2 verification.

## Next
Only after PASS: continue P12 from exact P12.2 artifact and assess the smallest history presentation/filtering dependency without entering P13.
