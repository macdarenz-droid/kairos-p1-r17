import { existsSync, readFileSync } from 'node:fs';

const files = [
  'src/app/analysisSavedTradeRiskRewardRendererProjection.ts',
  'tests/analysis-saved-trade-risk-reward-renderer-projection.test.ts',
  'docs/KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RENDERER_PROJECTION.md',
];
for (const file of files) if (!existsSync(file)) throw new Error(`missing-saved-trade-risk-reward-renderer:${file}`);

const source = readFileSync(files[0], 'utf8');
const tests = readFileSync(files[1], 'utf8');
const report = readFileSync(files[2], 'utf8');

for (const expected of [
  'AnalysisSavedTradeRiskRewardReferenceProjection',
  'RiskRewardChartObjectProjection',
  'projectChartTimestamp',
  'projectChartDecimal',
  'hasExactReleasedEvidence',
  "kind: 'renderer-ready'",
  "reason: 'renderer-evidence-invalid'",
  'logicalObject: chartObject',
]) if (!source.includes(expected)) throw new Error(`saved-trade-risk-reward-renderer-drift:${expected}`);

for (const forbidden of [
  'JournalHistoryEntry', 'parseFloat(', 'new Decimal', 'decimal.js', 'calculate', 'grossPnl', 'netPnl',
  'executionVenue:', 'fetch(', 'WebSocket', 'indexedDB', 'localStorage', 'createChart(',
  'attachPrimitive(', 'createSeriesMarkers(', 'ISeriesApi',
]) if (source.includes(forbidden)) throw new Error(`saved-trade-risk-reward-renderer-owner-violation:${forbidden}`);

for (const expected of [
  'delegates exact timestamps and Decimal strings through released P17 renderer conversions',
  'preserves exact logical evidence and semantic token references separately from renderer numbers',
  'preserves short-side source ordering without normalizing renderer prices',
  'propagates exact Gate448 unavailable evidence without manufacturing renderer values',
  'fails closed for inconsistent released %s evidence',
  'fails closed for invalid renderer conversion evidence',
  'deeply freezes renderer output without mutating Gate448 evidence',
]) if (!tests.includes(expected)) throw new Error(`missing-saved-trade-risk-reward-renderer-regression:${expected}`);

for (const expected of [
  'UI visible: no', 'Gate448', 'P14', 'P17', 'P19', 'P18', 'P20',
  'renderer-evidence-invalid', 'no Lightweight Charts primitive',
  'execution, venue, FX or P&L inference',
]) if (!report.includes(expected)) throw new Error(`saved-trade-risk-reward-renderer-report-drift:${expected}`);

console.log('Analysis saved-trade Risk/Reward renderer projection verifier PASS');
