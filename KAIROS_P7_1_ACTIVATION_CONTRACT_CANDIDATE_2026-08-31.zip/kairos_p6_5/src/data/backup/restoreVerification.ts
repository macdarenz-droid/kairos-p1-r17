import { closeKairosDatabase, openKairosDatabase } from '../database/databaseLifecycle';
import type { KairosDatabase } from '../database/KairosDatabase';
import { assertKairosDatabaseIntegrity, type DatabaseIntegrityReport } from '../database/integrity';
import { createKairosRepositories } from '../repositories';
import type { DatabaseMetadataRecord } from '../database/schema';
import type { KairosPreparedRestoreV1, KairosRecoverySnapshotV1 } from './restorePreflight';
import { replaceKairosDatabaseFromPreparedRestore } from './restoreReplacement';

export type KairosRestoreVerificationCode =
  | 'REOPEN_FAILED'
  | 'REQUERY_MISMATCH';

export class KairosRestoreVerificationError extends Error {
  constructor(
    public readonly code: KairosRestoreVerificationCode,
    message: string,
    public readonly recovery: KairosRecoverySnapshotV1,
  ) {
    super(message);
    this.name = 'KairosRestoreVerificationError';
  }
}

export interface KairosVerifiedRestoreResultV1 {
  readonly restoredMetadataRecords: number;
  readonly reloadedMetadataRecords: number;
  readonly verifiedAfterReload: true;
  readonly integrity: DatabaseIntegrityReport;
  readonly recovery: KairosRecoverySnapshotV1;
}

function sortMetadata(records: readonly DatabaseMetadataRecord[]): DatabaseMetadataRecord[] {
  return records.map((record) => ({ ...record })).sort((left, right) => left.key.localeCompare(right.key));
}

function metadataMatches(
  actual: readonly DatabaseMetadataRecord[],
  expected: readonly DatabaseMetadataRecord[],
): boolean {
  if (actual.length !== expected.length) return false;
  return actual.every((record, index) => {
    const target = expected[index];
    return target !== undefined
      && record.key === target.key
      && record.value === target.value
      && record.updatedAt === target.updatedAt;
  });
}

/**
 * Completes a prepared replacement and then verifies the committed state through
 * a fresh database connection and authoritative repository re-query.
 */
export async function restoreAndVerifyKairosDatabase(
  db: KairosDatabase,
  prepared: KairosPreparedRestoreV1,
): Promise<KairosVerifiedRestoreResultV1> {
  const replacement = await replaceKairosDatabaseFromPreparedRestore(db, prepared);

  closeKairosDatabase(db);
  const reopenStatus = await openKairosDatabase(db);
  if (reopenStatus.state !== 'ready') {
    throw new KairosRestoreVerificationError(
      'REOPEN_FAILED',
      'Restored data committed, but Kairos could not reopen the database for verification.',
      prepared.recovery,
    );
  }

  const integrity = await assertKairosDatabaseIntegrity(db);
  const repositories = createKairosRepositories(db);
  const reloaded = await db.transaction('r', db.metadata, () => repositories.metadata.listAll());

  const actual = sortMetadata(reloaded);
  const expected = sortMetadata(prepared.incoming.payload.metadata);
  if (!metadataMatches(actual, expected)) {
    throw new KairosRestoreVerificationError(
      'REQUERY_MISMATCH',
      'Restored data did not match the prepared backup after reopening and re-querying.',
      prepared.recovery,
    );
  }

  return Object.freeze({
    restoredMetadataRecords: replacement.restoredMetadataRecords,
    reloadedMetadataRecords: actual.length,
    verifiedAfterReload: true as const,
    integrity,
    recovery: prepared.recovery,
  });
}
