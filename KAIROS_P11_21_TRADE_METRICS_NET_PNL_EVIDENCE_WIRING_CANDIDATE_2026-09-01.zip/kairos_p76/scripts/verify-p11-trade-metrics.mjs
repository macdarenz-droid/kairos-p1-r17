import fs from 'node:fs';

const files = [
  'src/domain/calculations/tradeMetrics.ts',
  'tests/trade-metrics.test.ts',
];
for (const file of files) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const source = fs.readFileSync('src/domain/calculations/tradeMetrics.ts', 'utf8');

for (const token of [
  'calculateTradeMetrics',
  'assessExecutionBalance',
  'calculateFlatTradeGrossRealizedPnl',
  'averageEntryPrice',
  'averageExitPrice',
  'totalEnteredQuantity',
  'totalExitedQuantity',
  'remainingQuantity',
  "'unrealized'",
  "'partially-realized'",
  "'realized'",
  'completeness',
  'pnlPercent: null',
]) {
  if (!source.includes(token)) throw new Error(`Missing P11.5 TradeMetrics contract: ${token}`);
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error('P11.5 TradeMetrics must not introduce native numeric arithmetic/coercion.');
}

for (const forbidden of [
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
  'FX',
  'exchangeRate',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.5 out-of-scope owner detected: ${forbidden}`);
  }
}

console.log('P11.5 TradeMetrics foundation verification PASS');
