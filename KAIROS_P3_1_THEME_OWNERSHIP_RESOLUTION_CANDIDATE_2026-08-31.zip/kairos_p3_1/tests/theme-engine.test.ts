import { describe, expect, it } from 'vitest';
import { applyTheme, resolveTheme, themeRegistry } from '../src/design-system/themes';

describe('P3.1 theme engine', () => {
  it('resolves explicit and system preferences deterministically', () => {
    expect(resolveTheme('light', true)).toBe('light');
    expect(resolveTheme('dark', false)).toBe('dark');
    expect(resolveTheme('system', false)).toBe('light');
    expect(resolveTheme('system', true)).toBe('dark');
  });

  it('keeps geometry out of theme definitions', () => {
    for (const theme of Object.values(themeRegistry)) {
      expect(Object.keys(theme.tokens).some((key) => /spacing|radius|control|page-padding|card-gap|chart-min|navigation|motion/.test(key))).toBe(false);
    }
  });

  it('keeps light and dark token contracts structurally identical', () => {
    expect(Object.keys(themeRegistry.light.tokens).sort()).toEqual(Object.keys(themeRegistry.dark.tokens).sort());
  });

  it('applies only presentation state to the document root', () => {
    const root = document.createElement('html');
    applyTheme(root, 'dark');
    expect(root.dataset.kairosTheme).toBe('dark');
    expect(root.style.colorScheme).toBe('dark');
    expect(root.style.getPropertyValue('--kairos-background-base')).toBe(themeRegistry.dark.tokens['--kairos-background-base']);
  });
});
