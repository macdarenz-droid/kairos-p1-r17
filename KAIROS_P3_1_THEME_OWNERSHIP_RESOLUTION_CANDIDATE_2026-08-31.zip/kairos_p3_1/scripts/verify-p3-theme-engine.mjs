import fs from 'node:fs';
const engine = fs.readFileSync(new URL('../src/design-system/themes/themeEngine.ts', import.meta.url), 'utf8');
const forbidden = ['--kairos-spacing-', '--kairos-radius-', '--kairos-control-', '--kairos-page-padding', '--kairos-card-gap', '--kairos-chart-min-height', '--kairos-navigation-height', '--kairos-motion-'];
if (!engine.includes("export type ThemePreference = ThemeId | 'system'")) throw new Error('Theme preference contract missing.');
if (!engine.includes('resolveTheme') || !engine.includes('applyTheme')) throw new Error('Theme resolution/application owner missing.');
if (!engine.includes('themeRegistry')) throw new Error('Theme registry missing.');
for (const token of forbidden) if (engine.includes(token)) throw new Error(`Geometry token leaked into theme engine: ${token}`);
console.log('P3.1 theme engine contract: PASS');
