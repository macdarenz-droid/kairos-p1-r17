export const themeIds = ['light', 'dark'] as const;
export type ThemeId = (typeof themeIds)[number];
export type ThemePreference = ThemeId | 'system';

export type ThemeDefinition = Readonly<{
  id: ThemeId;
  colorScheme: ThemeId;
  tokens: Readonly<Record<string, string>>;
}>;

type ThemeTokenMap = Readonly<Record<string, string>>;

const lightTokens: ThemeTokenMap = {
  '--kairos-background-base': '#f7f8fa', '--kairos-background-depth': '#eef1f5', '--kairos-background-overlay': 'rgba(15,23,42,.52)',
  '--kairos-surface-card': '#ffffff', '--kairos-surface-raised': '#ffffff', '--kairos-surface-input': '#ffffff', '--kairos-surface-modal': '#ffffff',
  '--kairos-border-default': '#cbd2dc', '--kairos-border-subtle': '#e3e7ed', '--kairos-border-active': '#5667ff',
  '--kairos-text-primary': '#151923', '--kairos-text-secondary': '#4f5968', '--kairos-text-muted': '#6f7886', '--kairos-text-disabled': '#9aa2ad',
  '--kairos-accent-primary': '#4d5cff', '--kairos-accent-secondary': '#7b61ff', '--kairos-accent-soft': '#e9ebff', '--kairos-accent-glow': 'rgba(77,92,255,.28)',
  '--kairos-trade-profit': '#087a55', '--kairos-trade-loss': '#b4233b', '--kairos-trade-flat': '#687181', '--kairos-trade-long': '#087a55', '--kairos-trade-short': '#b4233b', '--kairos-trade-entry': '#2d5bd1', '--kairos-trade-stop': '#b4233b', '--kairos-trade-target': '#087a55', '--kairos-trade-risk-zone': 'rgba(180,35,59,.16)', '--kairos-trade-reward-zone': 'rgba(8,122,85,.16)',
  '--kairos-chart-background': '#ffffff', '--kairos-chart-grid': '#e8ebf0', '--kairos-chart-axis': '#667080', '--kairos-chart-crosshair': '#596273', '--kairos-chart-candle-up': '#087a55', '--kairos-chart-candle-down': '#b4233b', '--kairos-chart-wick-up': '#087a55', '--kairos-chart-wick-down': '#b4233b', '--kairos-chart-volume-up': 'rgba(8,122,85,.38)', '--kairos-chart-volume-down': 'rgba(180,35,59,.38)', '--kairos-chart-drawing-primary': '#4d5cff', '--kairos-chart-drawing-secondary': '#7b61ff', '--kairos-chart-support': '#087a55', '--kairos-chart-resistance': '#b4233b',
  '--kairos-state-success': '#087a55', '--kairos-state-warning': '#9a6700', '--kairos-state-error': '#b4233b', '--kairos-state-info': '#2d5bd1', '--kairos-state-focus': '#3347ff', '--kairos-state-hover': 'rgba(21,25,35,.06)', '--kairos-state-pressed': 'rgba(21,25,35,.11)', '--kairos-state-disabled': '#a7aeb8',
  '--kairos-glow-none': 'none', '--kairos-glow-subtle': '0 0 12px rgba(77,92,255,.12)', '--kairos-glow-active': '0 0 18px rgba(77,92,255,.22)', '--kairos-glow-emphasis': '0 0 28px rgba(77,92,255,.32)',
};

const darkTokens: ThemeTokenMap = {
  '--kairos-background-base': '#0d1016', '--kairos-background-depth': '#080a0f', '--kairos-background-overlay': 'rgba(0,0,0,.68)',
  '--kairos-surface-card': '#151922', '--kairos-surface-raised': '#1b202b', '--kairos-surface-input': '#11151d', '--kairos-surface-modal': '#191e28',
  '--kairos-border-default': '#343b49', '--kairos-border-subtle': '#252b36', '--kairos-border-active': '#8d97ff',
  '--kairos-text-primary': '#f3f5f8', '--kairos-text-secondary': '#bdc4cf', '--kairos-text-muted': '#8f98a7', '--kairos-text-disabled': '#626b78',
  '--kairos-accent-primary': '#8d97ff', '--kairos-accent-secondary': '#ae8cff', '--kairos-accent-soft': '#25294a', '--kairos-accent-glow': 'rgba(141,151,255,.34)',
  '--kairos-trade-profit': '#42d3a0', '--kairos-trade-loss': '#ff6b83', '--kairos-trade-flat': '#a5adba', '--kairos-trade-long': '#42d3a0', '--kairos-trade-short': '#ff6b83', '--kairos-trade-entry': '#78a6ff', '--kairos-trade-stop': '#ff6b83', '--kairos-trade-target': '#42d3a0', '--kairos-trade-risk-zone': 'rgba(255,107,131,.18)', '--kairos-trade-reward-zone': 'rgba(66,211,160,.18)',
  '--kairos-chart-background': '#0f131a', '--kairos-chart-grid': '#242a35', '--kairos-chart-axis': '#929baa', '--kairos-chart-crosshair': '#a8b0bd', '--kairos-chart-candle-up': '#42d3a0', '--kairos-chart-candle-down': '#ff6b83', '--kairos-chart-wick-up': '#42d3a0', '--kairos-chart-wick-down': '#ff6b83', '--kairos-chart-volume-up': 'rgba(66,211,160,.42)', '--kairos-chart-volume-down': 'rgba(255,107,131,.42)', '--kairos-chart-drawing-primary': '#8d97ff', '--kairos-chart-drawing-secondary': '#ae8cff', '--kairos-chart-support': '#42d3a0', '--kairos-chart-resistance': '#ff6b83',
  '--kairos-state-success': '#42d3a0', '--kairos-state-warning': '#f5bf55', '--kairos-state-error': '#ff6b83', '--kairos-state-info': '#78a6ff', '--kairos-state-focus': '#a8afff', '--kairos-state-hover': 'rgba(255,255,255,.07)', '--kairos-state-pressed': 'rgba(255,255,255,.12)', '--kairos-state-disabled': '#5e6673',
  '--kairos-glow-none': 'none', '--kairos-glow-subtle': '0 0 12px rgba(141,151,255,.15)', '--kairos-glow-active': '0 0 18px rgba(141,151,255,.28)', '--kairos-glow-emphasis': '0 0 28px rgba(141,151,255,.38)',
};

export const themeRegistry: Readonly<Record<ThemeId, ThemeDefinition>> = Object.freeze({
  light: Object.freeze({ id: 'light', colorScheme: 'light', tokens: Object.freeze(lightTokens) }),
  dark: Object.freeze({ id: 'dark', colorScheme: 'dark', tokens: Object.freeze(darkTokens) }),
});

export function resolveTheme(preference: ThemePreference, systemDark: boolean): ThemeId {
  return preference === 'system' ? (systemDark ? 'dark' : 'light') : preference;
}

export function applyTheme(root: HTMLElement, themeId: ThemeId): void {
  const theme = themeRegistry[themeId];
  root.dataset.kairosTheme = theme.id;
  root.style.colorScheme = theme.colorScheme;
  for (const [property, value] of Object.entries(theme.tokens)) root.style.setProperty(property, value);
}
