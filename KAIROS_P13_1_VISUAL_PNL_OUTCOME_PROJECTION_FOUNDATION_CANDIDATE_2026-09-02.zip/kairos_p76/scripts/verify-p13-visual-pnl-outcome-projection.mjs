import { readFileSync } from 'node:fs';

function read(path) { return readFileSync(new URL(`../${path}`, import.meta.url), 'utf8'); }
function requireText(text, needle, label) {
  if (!text.includes(needle)) throw new Error(`Missing ${label}: ${needle}`);
}
function rejectText(text, needle, label) {
  if (text.includes(needle)) throw new Error(`Forbidden ${label}: ${needle}`);
}

const source = read('src/application/visual-pnl/outcomeProjection.ts');
const barrel = read('src/application/visual-pnl/index.ts');
const test = read('tests/visual-pnl-outcome-projection.test.ts');
const pkg = JSON.parse(read('package.json'));

requireText(source, "export type VisualPnlOutcome = 'profit' | 'loss' | 'breakeven' | 'unavailable'", 'explicit semantic outcome contract');
requireText(source, "label: 'Profit' | 'Loss' | 'Break-even' | 'Not available'", 'non-color text semantics');
requireText(source, "if (metrics.netPnl !== null)", 'net P&L preference');
requireText(source, "metrics.grossPnl !== null && metrics.totalFees === '0'", 'gross fallback gated by authoritative zero fees');
requireText(source, "return unavailable();", 'explicit unavailable fallback');
requireText(source, "parseDecimalString", 'canonical decimal validation');
rejectText(source, "Number(", 'binary floating-point conversion');
rejectText(source, "parseFloat(", 'binary floating-point conversion');
rejectText(source, "parseInt(", 'numeric coercion');
rejectText(source, "decimalAdd(", 'new financial aggregation ownership');
rejectText(source, "decimalSubtract(", 'new financial arithmetic ownership');
rejectText(source, "decimalMultiply(", 'new financial arithmetic ownership');
rejectText(source, "decimalDivide(", 'new financial arithmetic ownership');
requireText(barrel, "export * from './outcomeProjection'", 'stable application boundary export');

requireText(test, "source: 'net-pnl'", 'comparable net P&L test');
requireText(test, "source: 'gross-pnl-zero-fees'", 'zero-fee gross fallback test');
requireText(test, "outcome: 'loss'", 'loss semantic test');
requireText(test, "outcome: 'breakeven'", 'break-even semantic test');
requireText(test, "outcome: 'unavailable'", 'unavailable semantic test');
requireText(test, "[fee('20', 'USD')]", 'non-zero fee no-comparability safety test');

if (pkg.scripts?.['verify:p13:visual-pnl-outcome-projection'] !== 'node scripts/verify-p13-visual-pnl-outcome-projection.mjs') {
  throw new Error('P13.1 verifier package registration missing or changed.');
}

console.log('P13.1 Visual P&L outcome projection verification PASS');
