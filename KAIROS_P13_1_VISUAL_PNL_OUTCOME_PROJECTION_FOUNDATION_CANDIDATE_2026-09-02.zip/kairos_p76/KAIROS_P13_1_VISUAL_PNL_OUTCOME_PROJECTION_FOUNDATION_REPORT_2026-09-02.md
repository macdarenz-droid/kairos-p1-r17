# KAIROS PATCH REPORT

Patch: P13.1 Visual P&L Outcome Projection Foundation
Base: P12.7R2 Journal History Closure / Async Wait Repair canonical PASS, GitHub Actions Run #69 / 33589532147
App version: 0.1.0
Build ID: P13.1-candidate-2026-09-02

## OBJECTIVE
Create the first Visual P&L application primitive without introducing P14 Trade Visualizer/chart scope. Convert already-authoritative P11 TradeMetrics into a small visual semantic contract: Profit, Loss, Break-even, or Not available.

## RESEARCH
- Controlling handoff rechecked: P13 is Visual P&L System; P14 is Trade Visualizer and must remain separate.
- Product experience rule rechecked: visual-first, semantic green/red only for trading outcomes, plain text remains available.
- W3C WCAG 1.4.1 / G14 rechecked: color cannot be the sole carrier of meaning; the projection therefore carries explicit text labels in addition to future visual styling.
- Existing P11 calculation ownership rechecked: decimal financial truth and currency comparability stay in Calculation Engine.

## OWNER TRACE
- Financial truth: P11 Calculation Engine / TradeMetrics.
- P13.1 ownership: application-level visual projection only.
- Trade persistence/query ownership remains P5/P9/P12.
- Theme presentation remains P2/P3.

## PRE-CHANGE FLOW
Journal History receives TradeMetrics and prints Gross P&L / Net P&L values as text. No reusable Visual P&L semantic contract existed.

## CHANGE
Added `src/application/visual-pnl/outcomeProjection.ts` and application barrel export.
The projection:
- prefers authoritative comparable `netPnl` when available;
- permits `grossPnl` only when authoritative fee evidence is explicitly zero, because then fees cannot change the outcome sign;
- returns Not available when fee evidence is unknown or non-zero and comparable net P&L is unavailable;
- exposes text label plus semantic outcome, amount, optional currency, and evidence source;
- performs no financial arithmetic and uses no JavaScript Number conversion.

Added focused tests and a static verifier/package registration.

## NON-SCOPE
No calendar/heatmap UI, day aggregation, equity curve, streak calculation, performance dashboard, Trade Visualizer, candles, chart engine, market data, FX conversion, new financial formulas, persistence/schema changes, or deployment changes.

## DATA/STATE FLOW
Trade evidence -> P11 `calculateTradeMetrics` -> P12 Journal History consumers / future P13 consumers -> P13.1 `projectVisualPnlOutcome` -> semantic visual state.

## PERSISTENCE
None. No schema or backup-format change.

## SECURITY
No network, secret, activation, or external-content surface change.

## THEME
No theme tokens changed. The semantic contract is presentation-neutral; later UI styling must use shared semantic tokens and must keep the text label visible/available so color is never the only signal.

## OFFLINE
Fully local; no new online dependency.

## TESTS
Focused P13.1 tests cover:
- comparable net profit;
- loss;
- break-even;
- zero-fee gross fallback;
- non-zero fee with missing currency comparability -> unavailable;
- missing metrics -> unavailable.

## REGRESSION
Static P13.1 verifier plus existing P12 closure/heavy/status verifiers passed before packaging. A local deterministic dependency install exceeded the available execution window and left an incomplete node_modules tree, so no local build/unit PASS is claimed. Full canonical build/unit/roadmap regression remains GitHub gate authority.

## PERFORMANCE
O(1) projection per metrics object; no DB queries, list scans, aggregation, or repeated journal parsing.

## KNOWN LIMITATIONS
P13.1 is intentionally a per-trade outcome projection. Day-level green/red classification is not yet safe across mixed/incomparable currencies and is deferred to later P13 controlled slices. Currency conversion remains P33 scope.

## REAL-DEVICE STATUS
Not required for this non-rendering foundation slice. Future visible P13 UI will require mobile/theme/accessibility smoke.

## RESULT
HOLD pending canonical GitHub gate.

## NEXT
Only after PASS: next dependency-ordered P13 slice may wire this semantic into a minimal visual logbook surface without crossing into P14/charting.
