import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { JournalTradeMap } from '../src/app/JournalTradeMap';
import type { JournalHistoryEntry } from '../src/application/journal-history';
import { createTradeDomainId } from '../src/domain/trades';

const entry: JournalHistoryEntry = {
  trade: {
    id: createTradeDomainId<'TradeId'>('trade-marker-semantics'),
    symbol: 'SOLUSDT',
    side: 'long',
    status: 'closed',
    openedAt: '2026-09-03T00:00:00.000Z',
    closedAt: '2026-09-03T01:00:00.000Z',
    createdAt: '2026-09-03T00:00:00.000Z',
    updatedAt: '2026-09-03T01:00:00.000Z',
  },
  plans: [{
    tradeId: createTradeDomainId<'TradeId'>('trade-marker-semantics'),
    plannedEntryPrice: '140.25',
    plannedStopPrice: '135.00',
    plannedTargetPrice: '150.50',
    plannedQuantity: '2',
    createdAt: '2026-09-03T00:00:00.000Z',
    updatedAt: '2026-09-03T00:00:00.000Z',
  }],
  executions: [{
    id: createTradeDomainId<'TradeExecutionId'>('exit-marker-semantics'),
    tradeId: createTradeDomainId<'TradeId'>('trade-marker-semantics'),
    kind: 'exit',
    price: '149.75',
    quantity: '2',
    feeAmount: '0',
    feeCurrency: null,
    executedAt: '2026-09-03T01:00:00.000Z',
    createdAt: '2026-09-03T01:00:00.000Z',
  }],
};

describe('P14.6 Journal Trade Map marker semantics', () => {
  it('uses distinct non-color marker shapes while preserving exact authoritative HTML facts', () => {
    const { container } = render(<JournalTradeMap entry={entry} />);

    expect(screen.getByRole('img', { name: 'SOLUSDT trade map visual' })).toBeInTheDocument();
    expect(container.querySelector('[data-level-kind="planned-entry"] [data-marker-shape="circle"]')).not.toBeNull();
    expect(container.querySelector('[data-level-kind="planned-stop"] [data-marker-shape="square"]')).not.toBeNull();
    expect(container.querySelector('[data-level-kind="planned-target"] [data-marker-shape="triangle"]')).not.toBeNull();
    expect(container.querySelector('[data-level-kind="executed-exit"] [data-marker-shape="diamond"]')).not.toBeNull();

    expect(screen.getByText('140.25')).toBeInTheDocument();
    expect(screen.getByText('135.00')).toBeInTheDocument();
    expect(screen.getByText('150.50')).toBeInTheDocument();
    expect(screen.getByText('149.75')).toBeInTheDocument();
    expect(screen.getByText('Visual guide · Not to scale')).toBeInTheDocument();
  });
});
