# KAIROS P14.6 — Journal Trade Map Categorical Marker Semantics

## Patch / Base / Identity
- Patch: P14.6
- Base: canonical P14.5R2 (Run #111, gate SHA c55269542c49848f99e445cfcc1f016eaa30cdaf)
- Candidate: KAIROS_P14_6_JOURNAL_TRADE_MAP_CATEGORICAL_MARKER_SEMANTICS_CANDIDATE_2026-09-03.zip

## OBJECTIVE
Make the supplementary Journal Trade Map visually distinguish planned entry, planned stop, planned target, and authoritative actual exit levels without relying on color alone and without introducing quantitative price geometry.

## RESEARCH / BOUNDARY
The existing P14.5 accessible SVG boundary is retained: semantic labels and exact values remain in the display model/native HTML facts; the SVG remains supplementary and explicitly not to scale.

## OWNER TRACE
JournalHistoryEntry -> P14.1 facts -> P14.2 display semantics -> P14.3 Journal projection -> P14.4 exact HTML facts -> P14.5/P14.6 supplementary SVG.
No new truth owner is introduced.

## CHANGE
- Planned entry: circle marker.
- Planned stop: square marker + dashed lane.
- Planned target: triangle marker + dotted lane.
- Actual exit: diamond marker + heavier lane.
- Accessible SVG description now states that distinct marker shapes are used.
- Added focused runtime test and static verifier.

## NON-SCOPE
No price scaling, numeric price geometry, candles, inferred path, current/live price, market data, P&L, FX, persistence, network access, animation, canvas, or P15+ work.

## DATA / STATE FLOW
Read-only projection only. Marker kind derives directly from existing TradeVisualizerLevel.kind.

## PERSISTENCE / SECURITY / OFFLINE
No writes, no persistence, no secrets, no network. Fully local/offline.

## THEME / ACCESSIBILITY
Uses existing semantic theme tokens. Shape, line pattern, and text labels prevent color-only communication.

## PERFORMANCE
O(level count) SVG nodes. No observers, timers, parsing loops, DB queries, or network work.

## TESTS
- Dedicated P14.6 static verifier.
- Dedicated runtime marker-semantics test.
- Historical P14.5/P14.4/P14.3/P14.2/P14.1 and earlier regressions required by canonical gate.

## KNOWN LIMITATIONS
Still intentionally categorical and not price-scaled.

## REAL-DEVICE STATUS
Not proven in this environment.

## RESULT
HOLD pending canonical GitHub gate.
