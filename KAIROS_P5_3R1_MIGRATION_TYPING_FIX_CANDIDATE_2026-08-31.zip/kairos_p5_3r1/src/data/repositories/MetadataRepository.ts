import type { KairosDatabase } from '../database/KairosDatabase';
import type { DatabaseMetadataRecord } from '../database/schema';

export class MetadataRepository {
  constructor(private readonly db: KairosDatabase) {}

  async get(key: string): Promise<DatabaseMetadataRecord | undefined> {
    return this.db.metadata.get(key);
  }

  async put(record: DatabaseMetadataRecord): Promise<void> {
    await this.db.metadata.put(record);
  }

  async delete(key: string): Promise<void> {
    await this.db.metadata.delete(key);
  }
}
