import { kairosDatabase, type KairosDatabase } from '../database';
import { MetadataRepository } from './MetadataRepository';

export interface KairosRepositories {
  readonly metadata: MetadataRepository;
}

export function createKairosRepositories(db: KairosDatabase): KairosRepositories {
  return Object.freeze({
    metadata: new MetadataRepository(db),
  });
}

export const kairosRepositories = createKairosRepositories(kairosDatabase);

export { MetadataRepository } from './MetadataRepository';
