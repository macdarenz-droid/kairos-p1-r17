# Kairos P9.2 Trade Persistence Foundation — Candidate Report

Status before independent gate: HOLD
Authoritative base: P9.1 PASS artifact from GitHub run 33462444715 / artifact 9783658625.

## Scope
- Append database schema V2 while retaining immutable V1 metadata schema history.
- Add authoritative stores for trades, tradePlans, tradeExecutions, tradeFees.
- Stable `id` primary keys; only query/integrity indexes required by current access paths.
- Add repository owners for all four stores.
- Expand short atomic transaction scope owner to current V2 stores.
- Expand read-only database integrity to record shape and cross-store reference checks.
- Add V1 -> V2 upgrade/reopen, atomic commit/rollback, and orphan-reference regressions.
- Adapt historical P5/P6/P7 static verifiers to assert their immutable historical contracts rather than incorrectly requiring the current database to remain V1 forever. These checks are preserved/strengthened, not removed.

## Explicit non-scope
No UI, Journal implementation, P&L/R-multiple/position-size calculations, broker/network work, payment work, or P10/P11 feature work. Backup payload remains V1 metadata-only in this patch; no user-facing trade-write path exists yet. Backup coverage for authoritative trade records must be completed before P9 closes or any user-facing trade write is enabled.

## Local verification
PASS: P9.2 static verifier.
PASS: updated historical P5.1-P5.5 static contracts.
PASS: P6.1 backup-envelope static contract.
PASS: P7.2 activation-persistence static contract.
PASS: P9.1 domain static contract.
Executable npm install/build/unit verification is not promotion evidence locally because the local deterministic install was interrupted by the execution environment and left an incomplete node_modules tree. GitHub `npm ci` is therefore required.

## Promotion rule
PASS only if the independent GitHub gate completes deterministic npm ci, build, full unit regression, P1-P9.2 static/regression chain, controlled patch-scope verification, and evidence upload. Otherwise previous P9.1 PASS remains authoritative.
