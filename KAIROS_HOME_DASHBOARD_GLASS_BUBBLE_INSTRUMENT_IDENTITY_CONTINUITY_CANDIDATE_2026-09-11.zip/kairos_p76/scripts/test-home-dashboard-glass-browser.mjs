import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { spawn } from 'node:child_process';
const require = createRequire(resolve(process.env.KAIROS_BROWSER_PACKAGE_DIR ?? '.', 'package.json'));
const { chromium } = require('playwright');
const evidence = resolve(process.env.KAIROS_GLASS_EVIDENCE_DIR ?? '.glass-evidence');
mkdirSync(evidence, { recursive: true });
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js','--host','127.0.0.1','--port','4173','--strictPort'], { stdio: 'pipe' });
let log='';server.stdout.on('data',x=>log+=x);server.stderr.on('data',x=>log+=x);
let browser;
try {
  let available=false;
  for(let i=0;i<100;i++){try { if((await fetch('http://127.0.0.1:4173/')).ok){available=true;break;} } catch {} await new Promise(r=>setTimeout(r,200));}
  assert(available,'Vite test server unavailable');
  browser=await chromium.launch({headless:true,...(process.env.KAIROS_CHROMIUM_EXECUTABLE ? {executablePath:process.env.KAIROS_CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage','--no-zygote','--single-process']} : {})});
  const page=await browser.newPage({viewport:{width:390,height:844},deviceScaleFactor:1});
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.route('http://127.0.0.1:4173/',route=>route.fulfill({contentType:'text/html',body:`<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;padding:20px;background:var(--kairos-background-base);font-family:system-ui}#glass-test-root{max-width:900px;margin:auto}</style><div id="glass-test-root"></div><script type="module">import RefreshRuntime from '/@react-refresh';RefreshRuntime.injectIntoGlobalHook(window);window.$RefreshReg$=()=>{};window.$RefreshSig$=()=>type=>type;window.__vite_plugin_react_preamble_installed__=true;const f=await import('/tests/fixtures/homeDashboardGlassBrowser.tsx');f.theme('kairos-depth');f.mount(8);</script>`}));
  await page.goto('http://127.0.0.1:4173/');
  await page.waitForFunction(()=>document.querySelectorAll('[data-glass-ready="true"]').length===8);
  assert.equal(await page.locator('.kairos-glass-bubble').count(),8);
  const transform=()=>page.locator('.kairos-glass-bubble').first().evaluate(e=>getComputedStyle(e).transform);
  const before=await transform();await page.waitForTimeout(500);assert.notEqual(await transform(),before,'Hover must move');
  // A rank update must preserve the real DOM canvas and active CSS animation.
  const retained = await page.evaluateHandle(() => { const e = [...document.querySelectorAll('.kairos-glass-bubble')].find(n => n.querySelector('strong')?.textContent === 'BTC'); return {bubble:e,canvas:e.querySelector('canvas'),animation:e.getAnimations()[0]}; });
  await page.evaluate(async() => (await import('/tests/fixtures/homeDashboardGlassBrowser.tsx')).refreshRanking());
  await page.waitForFunction(() => [...document.querySelectorAll('.kairos-glass-bubble')].some(e => e.querySelector('strong')?.textContent === 'BTC' && e.textContent.includes('4.25%')));
  const retainedAfter = await retained.evaluate(({bubble,canvas,animation}) => ({connected:bubble.isConnected,sameCanvas:bubble.querySelector('canvas')===canvas,sameAnimation:bubble.getAnimations()[0]===animation,value:bubble.textContent.includes('4.25%')}));
  assert.deepEqual(retainedAfter,{connected:true,sameCanvas:true,sameAnimation:true,value:true},'Ranking refresh must retain the actual bubble, canvas and animation while applying new facts');
  await retained.dispose();
  await page.getByRole('button',{name:'Pause motion'}).click();
  const frozen=await transform();await page.waitForTimeout(250);assert.equal(await transform(),frozen,'Paused hover must stop');
  const positions=()=>page.locator('.kairos-glass-bubble').evaluateAll(nodes=>nodes.map(n=>[n.style.left,n.style.top,n.style.width,n.style.height]));
  const first=await positions();
  const checks=await page.locator('canvas').first().evaluate(canvas=>{const ctx=canvas.getContext('2d');return {corner:ctx.getImageData(0,0,1,1).data[3],centre:ctx.getImageData(256,256,1,1).data[3]}});
  assert(checks.corner<=3&&checks.centre<=3,'Matte must actually be transparent');
  assert.equal(await page.locator('.kairos-glass-label').first().evaluate(e=>getComputedStyle(e).filter),'none','Labels must not blur');
  for(const id of ['kairos-depth','cosmic','ocean','light-proof']) {
    await page.evaluate(async id=>(await import('/tests/fixtures/homeDashboardGlassBrowser.tsx')).theme(id),id);
    assert.deepEqual(await positions(),first,'Theme must preserve layout');
    await page.screenshot({path:resolve(evidence,`mobile-${id}.png`),fullPage:true});
  }
  await page.emulateMedia({reducedMotion:'reduce'});
  assert.equal(await page.locator('.kairos-glass-bubble').first().evaluate(e=>getComputedStyle(e).animationName),'none');
  await page.setViewportSize({width:900,height:900});
  await page.evaluate(async()=>(await import('/tests/fixtures/homeDashboardGlassBrowser.tsx')).mount(30));
  await page.waitForFunction(()=>document.querySelectorAll('[data-glass-ready="true"]').length===30);
  await page.waitForTimeout(100);
  const circles=await page.locator('.kairos-glass-bubble').evaluateAll(nodes=>nodes.map(n=>{const r=n.getBoundingClientRect();return{x:r.x+r.width/2,y:r.y+r.height/2,r:r.width/2}}));
  for(let i=0;i<circles.length;i++) for(let j=i+1;j<circles.length;j++) assert(Math.hypot(circles[i].x-circles[j].x,circles[i].y-circles[j].y)>=circles[i].r+circles[j].r+23.9,'Bubbles must not overlap');
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,'No horizontal overflow');
  await page.screenshot({path:resolve(evidence,'desktop-30-light.png'),fullPage:true});
  assert.deepEqual(errors,[]);
  writeFileSync(resolve(evidence,'browser-results.json'),JSON.stringify({passed:true,checks,views:['three existing themes','light stress case'],counts:[8,30],rankRefreshIdentity:true,rankRefreshAnimation:true,immediateFacts:true,hover:true,pause:true,reducedMotion:true,noOverlap:true,errors},null,2));
  console.log('PASS: real Chromium glass rendering, RGBA transparency, theme stability, motion, reduced motion, 30 circles, no page errors.');
} finally {
  writeFileSync(resolve(evidence,'vite.log'),log);await browser?.close();server.kill();
}
