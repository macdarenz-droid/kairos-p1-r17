# KAIROS P16.3 — Binance Spot Public Stream Endpoint Semantics

## BASE
P16.2R1 Binance Spot Trade Observation Test Contract Repair — canonical PASS, Run #147.

## OBJECTIVE
Introduce the smallest provider-specific production endpoint composition owner required before a later concrete Binance Spot public market-data transport adapter.

## RESEARCH
Current official Binance Spot API documentation states that production market streams use either `wss://stream.binance.com:9443` or `wss://stream.binance.com:443`. A single raw stream is addressed at `/ws/<streamName>`, while combined streams use `/stream?streams=...`. Symbols in stream names are lowercase. The same documentation states that a connection is valid for 24 hours and documents heartbeat and rate-limit behavior; those lifecycle concerns remain deliberately outside this patch.

P16.3 selects raw single-stream composition only because P16.1 currently proves one provider stream descriptor at a time. Combined multiplexing is deferred to a later controlled slice rather than being introduced speculatively.

## OWNER TRACE
P16.1R1:
`MarketDataInstrument -> Binance Spot trade stream descriptor`

P16.2R1:
`raw Binance trade payload + caller-owned observedAt -> P15 MarketPriceObservation`

P16.3:
`valid Binance Spot trade stream descriptor -> production raw-stream endpoint descriptor`

New owner:
`src/services/market-data/providers/binance/binanceSpotPublicStreamEndpoint.ts`

## CHANGE
- pins the documented production host `stream.binance.com`;
- pins only documented public-stream ports `9443` and `443`;
- composes a raw stream URL at `/ws/<streamName>`;
- defaults to port `9443` while allowing documented port `443`;
- consumes the already-valid P16.1 stream descriptor so stream naming is not duplicated.

## NON-SCOPE
- no connection creation;
- no heartbeat implementation;
- no 24-hour reconnect execution;
- no rate-limit scheduler;
- no combined-stream multiplexing;
- no symbol catalogue discovery;
- no credentials;
- no account/user streams;
- no order execution;
- no persistence;
- no chart rendering;
- no journal/P&L mutation.

## DATA/STATE FLOW
P16.1 valid stream descriptor
-> P16.3 public raw endpoint descriptor
-> future concrete provider transport
-> P16.2 raw trade mapper
-> P15 observation/lifecycle boundary

## SECURITY
Public market-data endpoint only. No credentials or authenticated account surfaces.

## OFFLINE
No networking is created by this patch. Existing local/offline journal behavior is unchanged.

## TESTS
- BTCUSDT descriptor -> `wss://stream.binance.com:9443/ws/btcusdt@trade`;
- ETHUSDT descriptor -> documented port 443 equivalent;
- host and supported port set are pinned.

## RESULT
HOLD pending canonical GitHub gate.
