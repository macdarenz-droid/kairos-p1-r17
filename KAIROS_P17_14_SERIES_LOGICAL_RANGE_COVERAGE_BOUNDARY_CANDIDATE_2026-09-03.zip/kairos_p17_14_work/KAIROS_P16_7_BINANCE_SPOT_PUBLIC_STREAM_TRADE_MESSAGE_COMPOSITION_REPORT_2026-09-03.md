# KAIROS P16.7 — Binance Spot Public Stream Trade Message Composition

## BASE
P16.6 — canonical PASS, Run #151.

## OBJECTIVE
Compose the already-separated P16.5 JSON decoder, P16.6 provider-event classifier, and P16.2 trade observation mapper for one received raw Binance Spot public-stream text message, while keeping receipt time caller-owned.

## RESEARCH
Current official Binance Spot WebSocket Streams documentation continues to define raw streams at `/ws/<streamName>`, JSON trade events, a 24-hour connection lifetime, protocol ping/pong requirements, and a `serverShutdown` event before shutdown. P16.7 does not duplicate any of those transport/lifecycle policies; it composes existing message semantic owners only.

## OWNER TRACE
P16.1 stream naming.
P16.3 endpoint.
P16.4 injected connection seam.
P16.5 JSON decode.
P16.6 event classification.
P16.2 trade payload -> P15 observation.
P16.7 composition of those existing semantic owners for one message.
P15 lifecycle/reconnect remains authoritative.

## CHANGE
Added `mapBinanceSpotPublicStreamTradeMessage(data, observedAt)`.
Trade text flows decode -> classify -> existing P16.2 mapper.
Non-trade events are ignored by this trade-specific composition owner.
Malformed transport JSON and invalid trade semantics remain explicit failures.
Receipt time is supplied by the caller.

## NON-SCOPE
No concrete network constructor.
No clock acquisition.
No reconnect action.
No timers or 24-hour rotation.
No ping/pong ownership.
No persistence.
No charts.
No journal/P&L mutation.
No credentials/account streams/orders.
No binary/SBE.

## DATA FLOW
message data -> P16.5 -> P16.6 -> if trade, P16.2 -> P15 observation.
`serverShutdown` remains available to lifecycle composition outside this trade-specific owner and is not converted into a trade observation.

## TESTS
Valid BTCUSDT JSON trade composes into a P15 observation with lexical decimal preservation and caller-owned observedAt.
serverShutdown is ignored by trade composition.
Malformed JSON is explicit.
Semantically invalid trade is explicit.

## REGRESSION
P1 static and P16.1-P16.7 verifiers run locally. Canonical build/unit/full historical regression remains required.

## RESULT
HOLD pending upload and canonical GitHub gate.
