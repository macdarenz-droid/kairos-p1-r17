import { createChartEnginePortFromDriver } from './chartEngineDriver';
import { createLightweightChartsV5Driver } from './lightweightChartsV5ModuleAdapter';
import { lightweightChartsV5Package } from './lightweightChartsV5Package';
import { createProjectedChartRendererFactory } from './projectedChartRenderer';

/**
 * Production composition root for the P17 chart renderer.
 *
 * It binds the verified Lightweight Charts v5 package through the existing
 * Kairos driver and engine boundaries. It owns no feed, journal, persistence,
 * calculation, drawing, or navigation state.
 */
export function createLightweightChartsV5ProductionRendererFactory() {
  return createProjectedChartRendererFactory(
    createChartEnginePortFromDriver(
      createLightweightChartsV5Driver({
        ...lightweightChartsV5Package,
        createChart(container) {
          return lightweightChartsV5Package.createChart(container, { autoSize: true });
        },
      }),
    ),
  );
}
