import type { ChartRenderModel } from './chartRenderContract';
import type {
  ChartRendererFactory,
  ChartRendererLifecycle,
} from './chartRendererLifecycle';
import { projectChartSeries } from './chartSeriesProjection';
import type { ChartEnginePort } from './chartEnginePort';

export function createProjectedChartRendererFactory(
  engine: ChartEnginePort,
): ChartRendererFactory {
  return {
    create(container: HTMLElement): ChartRendererLifecycle {
      const session = engine.create(container);
      let destroyed = false;

      return {
        render(model: ChartRenderModel): void {
          if (destroyed) {
            throw new Error('chart-renderer-destroyed');
          }
          session.replaceSeries(projectChartSeries(model));
        },
        destroy(): void {
          if (destroyed) return;
          destroyed = true;
          session.destroy();
        },
      };
    },
  };
}
