# KAIROS P17.1R2 — Chart Render Contract DecimalString Fixture Repair

## OBJECTIVE
Repair the remaining P17.1 canonical build failure without weakening the DecimalString domain contract.

## FAILURE
Run #171 reached TypeScript compilation and failed because the P17.1 test fixture supplied ordinary strings where branded DecimalString values are required.

## ROOT CAUSE
The production import owner was corrected in R1. The remaining defect was test-only fixture construction.

## CHANGE
The P17.1 test now creates DecimalString fixtures through the existing authoritative `parseDecimalString` validator exported by `src/domain/trades`.
Production chart semantics are unchanged.

## NON-SCOPE
No chart library integration, renderer, calculations, reconciliation, persistence, market subscriptions, reconnect behavior, timers, credentials, order execution, or later roadmap phases.

## RESULT
Local verifier/static checks are performed below. Canonical CI remains authoritative for build/unit/runtime PASS.
