# KAIROS P16.5 — Binance Spot Public Stream Message Decode

## BASE
P16.4 — canonical PASS, Run #149.

## OBJECTIVE
Add the smallest deterministic transport-framing step needed between the injected P16.4 connection seam and the existing P16.2 Binance Spot trade observation mapper: JSON text decoding only.

## RESEARCH
Current official Binance Spot WebSocket stream documentation describes raw stream events as JSON payloads and documents raw stream access at `/ws/<streamName>`. The current WebSocket Standard exposes received text messages to script as string data through the `message` event. Ping and Pong protocol frames are not exposed by the browser WebSocket API. P16.5 therefore decodes only text-message JSON and does not attempt to own protocol heartbeat behavior.

## OWNER TRACE
P16.1 owns Binance Spot stream naming.
P16.3 owns public raw-stream endpoint composition.
P16.4 owns only the injected connection seam.
P16.5 owns JSON text decoding only.
P16.2 owns provider trade-payload semantic mapping to a P15 observation.
P15 owns provider-neutral lifecycle/reconnect semantics.

## PRE-CHANGE FLOW
P16.1 stream -> P16.3 endpoint -> P16.4 injected connector -> message data.
There was no controlled JSON text decoding owner before P16.2 semantic mapping.

## CHANGE
Added `decodeBinanceSpotPublicStreamMessage(data)`.

It:
- accepts unknown message data;
- accepts strings only;
- parses JSON text deterministically;
- returns the parsed value as `unknown`;
- distinguishes malformed JSON from unsupported non-text data.

## NON-SCOPE
No concrete browser/network constructor.
No protocol ping/pong implementation.
No connection-lifetime timer.
No retry/reconnect execution.
No clock acquisition.
No trade semantic validation.
No observation construction.
No serverShutdown policy.
No binary/SBE decoding.
No credentials.
No account/user streams.
No orders.
No persistence.
No chart rendering.
No journal/P&L mutation.

## DATA/STATE FLOW
P16.1 stream -> P16.3 endpoint -> P16.4 injected connector -> P16.5 JSON decode -> later semantic owner.
Trade objects may then be supplied to P16.2 together with caller-owned `observedAt`.

## PERSISTENCE
None.

## SECURITY
Public market-data serialization only. No secrets or authenticated endpoints.

## THEME
No UI.

## OFFLINE
Offline journal behavior is unchanged.

## TESTS
- raw BTCUSDT trade JSON decodes without changing the lexical decimal string;
- `serverShutdown` JSON remains generic transport data rather than being interpreted here;
- malformed JSON is rejected;
- non-text data is rejected rather than inventing binary decoding.

## REGRESSION
P1 static, P16.1, P16.2, P16.3, P16.4 and dedicated P16.5 static verifiers run locally. Canonical gate remains required for build, unit runtime, and full historical regression.

## PERFORMANCE
One `JSON.parse` per supplied message. No polling, observers, timers, persistence, or repeated journal parsing.

## KNOWN LIMITATIONS
No concrete browser transport is created. Binary/SBE frames are intentionally unsupported. Browser WebSocket protocol Ping/Pong frames are not exposed to script by the standard API.

## REAL-DEVICE STATUS
Not applicable yet; no concrete transport is created.

## RESULT
HOLD pending upload and canonical GitHub gate.
