# KAIROS P14.5R1 — Journal Trade Map Accessibility ID Ownership Repair

## Patch/Base/app/build identity
- Authoritative base: `KAIROS_P14_4R1_JOURNAL_TRADE_MAP_FIXTURE_CONTRACT_REPAIR_CANDIDATE_2026-09-02.zip`
- Failed input candidate: `KAIROS_P14_5_JOURNAL_TRADE_MAP_ACCESSIBLE_SVG_SHELL_CANDIDATE_2026-09-02.zip`
- Repair candidate: `KAIROS_P14_5R1_JOURNAL_TRADE_MAP_ACCESSIBILITY_ID_OWNERSHIP_REPAIR_CANDIDATE_2026-09-02.zip`
- App: Kairos Trading Journal
- Phase: P14 Trade Visualizer

## OBJECTIVE
Repair the canonical P14.5 TypeScript build failure without changing production truth ownership or broadening P14.5 scope.

## RESEARCH
The failure is local to React/SVG presentation identity. React `useId()` is the correct local mechanism for generating identifiers used by accessibility attributes; no domain identifier is required.

## OWNER TRACE
- Trade facts remain owned by P14.1.
- Display semantics remain owned by P14.2.
- Journal projection remains owned by P14.3.
- Exact textual presentation remains owned by P14.4R1.
- P14.5 remains supplementary SVG presentation only.
- SVG accessibility linkage IDs are local presentation state and must not be sourced from a nonexistent domain field on `TradeVisualizerDisplayModel`.

## PRE-CHANGE FLOW
`JournalHistoryEntry` → `projectJournalTradeVisualizer(entry)` → `TradeVisualizerDisplayModel` → `JournalTradeMapGraphic`.

The failed P14.5 graphic incorrectly attempted `model.tradeId`, but `TradeVisualizerDisplayModel` intentionally exposes only `symbol`, `side`, `status`, and `levels`.

## CHANGE
- Import React `useId` in `JournalTradeMapGraphic.tsx`.
- Generate one local accessibility ID seed.
- Derive SVG `<title>` and `<desc>` IDs from that local seed.
- Keep `aria-labelledby` linkage unchanged semantically.
- No display-model/domain contract expansion.

## NON-SCOPE
No DB changes, no repository changes, no market data, no current/live price, no candles, no synthetic path, no price scaling, no financial calculations, no FX, no P15+, no animation, no domain ID additions.

## DATA/STATE FLOW
No change. `TradeVisualizerDisplayModel` remains authoritative input; `useId` only creates DOM linkage identifiers and does not represent trade data.

## PERSISTENCE
None.

## SECURITY
No network or executable-content changes.

## THEME
No theme behavior changes.

## OFFLINE
Fully local; unchanged.

## TESTS
Canonical failure being repaired:
`src/app/JournalTradeMapGraphic.tsx(16,44): TS2339 Property 'tradeId' does not exist on type 'TradeVisualizerDisplayModel'.`

Static P14.5 verifier and historical regressions were rerun locally and passed. A local `npm ci`/build attempt exceeded the execution window before install completion, so no local build/runtime PASS is claimed. Canonical GitHub build/unit/full regression is still required for promotion.

## REGRESSION
P14.4R1 exact HTML facts remain intact. P14.3/P14.2/P14.1R1 ownership boundaries remain intact. P13 closure and earlier roadmap ownership remain protected by canonical gate.

## PERFORMANCE
`useId()` is constant-cost component-local presentation identity and adds no observer, polling, persistence, parsing, or journal traversal.

## KNOWN LIMITATIONS
The SVG remains deliberately categorical and not price-scaled. Exact prices remain in native HTML text.

## REAL-DEVICE STATUS
Not claimed. Canonical gate required before promotion.

## RESULT
HOLD pending canonical P14.5R1 gate.
