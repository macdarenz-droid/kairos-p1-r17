import { useId } from 'react';
import type { TradeVisualizerDisplayModel } from '../application/trade-visualizer';

interface JournalTradeMapGraphicProps {
  readonly model: TradeVisualizerDisplayModel;
}

/**
 * P14.5 supplementary visual shell.
 *
 * This SVG is intentionally categorical and NOT price-scaled. Each authoritative
 * level is placed on an equal-spaced lane in display-model order, so the visual
 * cannot imply market distance, chronology, or price path. Exact values remain
 * owned by the adjacent native HTML definition list.
 */
export function JournalTradeMapGraphic({ model }: JournalTradeMapGraphicProps) {
  const accessibilityId = useId();
  const titleId = `trade-map-title-${accessibilityId}`;
  const descId = `trade-map-desc-${accessibilityId}`;
  const laneCount = Math.max(model.levels.length, 1);
  const laneHeight = 24;
  const height = laneCount * laneHeight + 24;

  return (
    <svg
      className="kairos-trade-map__graphic"
      viewBox={`0 0 320 ${height}`}
      role="img"
      aria-labelledby={`${titleId} ${descId}`}
      preserveAspectRatio="xMidYMid meet"
    >
      <title id={titleId}>{model.symbol} trade map visual</title>
      <desc id={descId}>Categorical trade levels shown at equal spacing. Not to scale. Exact prices are listed below.</desc>
      {model.levels.map((level, index) => {
        const y = 20 + index * laneHeight;
        return (
          <g key={`${level.kind}-${index}`} data-level-kind={level.kind}>
            <line className="kairos-trade-map__lane" x1="12" x2="308" y1={y} y2={y} />
            <circle className="kairos-trade-map__marker" cx="20" cy={y} r="4" />
            <text className="kairos-trade-map__graphic-label" x="32" y={y + 4}>{level.label}</text>
          </g>
        );
      })}
    </svg>
  );
}
