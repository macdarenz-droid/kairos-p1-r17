import { readFile } from 'node:fs/promises';

const packageJson = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));
if (packageJson.dependencies?.dexie !== '4.4.5') {
  throw new Error('P5.1 requires exactly pinned dexie@4.4.5.');
}
if (packageJson.devDependencies?.['fake-indexeddb'] !== '6.2.5') {
  throw new Error('P5.1 database tests require exactly pinned fake-indexeddb@6.2.5.');
}
if (packageJson.scripts?.['verify:p5:database-kernel'] !== 'node scripts/verify-p5-database-kernel.mjs') {
  throw new Error('P5.1 database-kernel verifier must have one package-script owner.');
}

const schema = await readFile(new URL('../src/data/database/schema.ts', import.meta.url), 'utf8');
if (!/KAIROS_DB_SCHEMA_VERSION\s*=\s*1\s+as const/.test(schema)) {
  throw new Error('P5.1 must establish immutable database schema version 1.');
}
if (!/metadata:\s*'&key'/.test(schema)) {
  throw new Error('P5.1 v1 must contain the metadata store keyed by stable metadata key.');
}
if (/trades|tradePlans|tradeExecutions|tradeFees|chartAnalyses|chartDrawings|strategies|strategyRules|goals|attachments/i.test(schema)) {
  throw new Error('P5.1 must not pre-create future domain tables before their roadmap owners exist.');
}

const database = await readFile(new URL('../src/data/database/KairosDatabase.ts', import.meta.url), 'utf8');
if (!/extends Dexie/.test(database) || !/this\.version\(KAIROS_DB_SCHEMA_VERSION\)\.stores\(KAIROS_V1_STORES\)/.test(database)) {
  throw new Error('P5.1 database owner must use Dexie and the authoritative schema registry.');
}

const lifecycle = await readFile(new URL('../src/data/database/databaseLifecycle.ts', import.meta.url), 'utf8');
if (!/db\.on\('versionchange'/.test(lifecycle) || !/await db\.open\(\)/.test(lifecycle)) {
  throw new Error('P5.1 must own database open and version-change lifecycle explicitly.');
}
if (!/state:\s*'error'/.test(lifecycle)) {
  throw new Error('P5.1 must expose fatal database-open failure rather than masquerading as empty data.');
}
if (/fetch\(|WebSocket|navigator\.|localStorage|sessionStorage/.test(lifecycle + database)) {
  throw new Error('P5.1 database kernel must not perform network, UI, or unrelated browser-storage work.');
}

console.log('P5.1 Dexie database kernel / V1 metadata schema contract: PASS');
