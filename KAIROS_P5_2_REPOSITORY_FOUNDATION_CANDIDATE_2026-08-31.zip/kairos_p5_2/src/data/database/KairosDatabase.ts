import Dexie, { type EntityTable } from 'dexie';
import {
  KAIROS_DATABASE_NAME,
  KAIROS_DB_SCHEMA_VERSION,
  KAIROS_V1_STORES,
  type DatabaseMetadataRecord,
} from './schema';

export class KairosDatabase extends Dexie {
  readonly metadata!: EntityTable<DatabaseMetadataRecord, 'key'>;

  constructor(name = KAIROS_DATABASE_NAME) {
    super(name);
    this.version(KAIROS_DB_SCHEMA_VERSION).stores(KAIROS_V1_STORES);
  }
}
