import { createRoot } from 'react-dom/client';
import { HomeDashboardGlassBubbleMap } from '../../src/app/HomeDashboardGlassBubbleMap';
import { applyTheme, type ThemeId } from '../../src/design-system/themes/themeEngine';
import '../../src/design-system/tokens.css';
import { glassTestModel } from './homeDashboardGlassModel';

const root = createRoot(document.getElementById('glass-test-root')!);
export function mount(count: number) {
  root.render(<HomeDashboardGlassBubbleMap model={glassTestModel(count)} />);
}
export function theme(id: ThemeId | 'light-proof') {
  applyTheme(document.documentElement, id === 'light-proof' ? 'kairos-depth' : id);
  if (id === 'light-proof') {
    // Test-only light surface stress case; does not add a product theme.
    const tokens = { '--kairos-background-base': '#eef2f7', '--kairos-surface-card': '#e1e7f1', '--kairos-surface-raised': '#ffffff', '--kairos-text-primary': '#18243a', '--kairos-text-secondary': '#4a5970', '--kairos-trade-profit': '#06775a', '--kairos-trade-loss': '#b52950' };
    for (const [k,v] of Object.entries(tokens)) document.documentElement.style.setProperty(k,v);
  }
}

export function refreshRanking() {
  const model = glassTestModel(8);
  if (!model.radiusScaleProjection?.ok) throw Error('fixture');
  const entries = model.radiusScaleProjection.entries;
  Object.assign(entries[0].areaWeightEntry.presentationEntry.metricInput, { movementPercent24h: '4.25' });
  Object.assign(model.radiusScaleProjection, { entries: [...entries].reverse() });
  root.render(<HomeDashboardGlassBubbleMap model={model} />);
}

import { MemoryRouter, Route, Routes } from 'react-router';
import { AppShell } from '../../src/app/AppShell';
import '../../src/design-system/shell/navigationShell.css';
export function mountCompact() {
  const model=glassTestModel(30);
  if(!model.radiusScaleProjection?.ok) throw Error('fixture');
  const symbols=['BTC','ETH','SOL','BNB','XRP','ADA','LINK','SUI','DOGE','AVAX','DOT','NEAR','LTC','UNI','ATOM','AAVE','TRX','FIL','SHIB','PEPE','ARB','OP','TON','JUP','WIF','ENA','INJ','SEI','APT','TAO'];
  model.radiusScaleProjection.entries.forEach((e,i)=>{
    const p=e.areaWeightEntry.presentationEntry;
    const value=i===0?10.5:((i%11)+1)*.22*(i%2?-1:1);
    Object.assign(p.metricInput,{movementPercent24h:String(value),instrument:{venue:'binance-spot',symbol:symbols[i]+'USDT'}});
    Object.assign(p,{movementSemantic:value<0?'negative':'positive'});
  });
  root.render(<MemoryRouter><Routes><Route element={<AppShell/>}><Route path="/" element={<section className="kairos-route" data-kairos-home-dashboard="live-crypto-text-runtime"><header><h1>Home</h1><p>Your Kairos dashboard lives here.</p></header><section><h2>Live Crypto Bubble</h2><HomeDashboardGlassBubbleMap model={model}/></section></section>}/></Route></Routes></MemoryRouter>);
}
