import fs from 'node:fs';

const sourceFile = 'src/domain/calculations/tradeMetrics.ts';
const legacyVerifierFile = 'scripts/verify-p11-trade-metrics.mjs';
const testFile = 'tests/trade-metrics-risk-evidence.test.ts';

for (const file of [sourceFile, legacyVerifierFile, testFile]) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const source = fs.readFileSync(sourceFile, 'utf8');

for (const token of [
  'TradeMetricsRiskPerformanceInput',
  'riskPerformanceInput?',
  'calculateRiskPerformance',
  'resultAmount',
  'riskPerUnit',
  'quantity',
  'initialRisk',
  'realizedR',
  'hasInitialRisk',
  'hasRealizedR',
  "'invalid-risk-performance-decimal'",
  "'zero-initial-risk'",
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P11.14 TradeMetrics risk-evidence contract: ${token}`);
  }
}

for (const token of [
  'totalFees: null',
  'netPnl: null',
  'pnlPercent: null',
]) {
  if (!source.includes(token)) {
    throw new Error(`P11.14 must preserve unresolved metric as unavailable: ${token}`);
  }
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error(
    'P11.14 TradeMetrics wiring must compose existing decimal owners, not native numeric arithmetic.',
  );
}

for (const forbidden of [
  'TradeFeeRecord',
  'exchangeRate',
  'currencyConversion',
  'marketType',
  'plannedEntryPrice',
  'plannedStopPrice',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.14 out-of-scope owner detected: ${forbidden}`);
  }
}

console.log('P11.14 TradeMetrics risk evidence wiring verification PASS');
