import { readFileSync } from 'node:fs';
const route=readFileSync('src/app/JournalRoute.tsx','utf8');
const list=readFileSync('src/app/JournalHistoryList.tsx','utf8');
const css=readFileSync('src/app/journalRoute.css','utf8');
const tests=readFileSync('tests/journal-history-route.test.tsx','utf8');
const checks=[
 [route.includes('listJournalHistory(db)'), 'route must consume P12 query owner'],
 [route.includes('await refreshHistory()'), 'successful save must refresh history'],
 [route.includes('<JournalHistoryList'), 'journal route must render history component'],
 [!list.toLowerCase().includes('indexeddb') && !list.includes('createKairosRepositories'), 'history renderer must not own storage/repositories'],
 [list.includes("entry.metrics?.netPnl ?? 'Not available'"), 'missing net P&L must render as unavailable, never zero'],
 [list.includes('entry.metricsError'), 'calculation evidence errors must remain visible'],
 [list.includes('aria-busy') && list.includes('role="alert"'), 'loading/error accessibility states required'],
 [css.includes('@media (max-width: 420px)'), 'mobile history layout required'],
 [tests.includes('refreshes history after a successful manual save'), 'post-save refresh regression required'],
];
for(const [ok,msg] of checks){if(!ok){console.error(`P12.3 verification FAIL: ${msg}`);process.exit(1)}}
console.log('P12.3 journal history route verification PASS');
