# KAIROS P12.3 Journal History Route Presentation

## Status
HOLD pending canonical GitHub gate and real-device visual verification.

## Base
P12.2R1 canonical PASS, run #55.

## Objective
Expose the existing P12 journal-history read model on the real Journal route without creating a second data/calculation owner or entering P13 visual P&L.

## Research
The controlling handoff requires explicit route boundaries, local temporary UI state, semantic design tokens, responsive shared data ownership, non-color-only important information, and DB-index-backed journal queries. Current React guidance for effects/external synchronization and current accessibility guidance were rechecked before implementation. P12.2R1 already owns bounded indexed retrieval.

## Owner trace
JournalRoute temporary loading state -> P12 listJournalHistory() -> repositories -> IndexedDB -> P11 calculation engine -> JournalHistoryList presentation.

## Pre-change flow
The Journal route only rendered the P10 manual-trade form. P12 history existed as an application query but had no real route consumer.

## Change
- Add a presentational JournalHistoryList component.
- JournalRoute loads P12 history on mount and refreshes it only after a successful P10 save commit.
- Render symbol, direction, status, timestamp, execution/fee counts, and existing P11-derived gross/net P&L evidence.
- Missing financial evidence is displayed as “Not available”; it is never coerced to zero.
- Calculation evidence errors remain visible in plain language.
- Add loading, empty, error, and populated states plus mobile-responsive semantic-token styling.

## Non-scope
No edit/delete history actions, filters/search, pagination UI, charts/sparklines, P13 visual P&L, schema migration, financial formula, FX, activation, backup/restore, or network changes.

## Data/state flow
Mount or successful save -> refreshHistory -> listJournalHistory -> repository/indexed bounded read -> P11 metrics -> immutable entries -> presentational list.

## Persistence
Read-only history path. Existing P10 save path remains the sole write owner. No schema change.

## Security
No new external input/network surface.

## Theme
Uses existing semantic tokens only. No new theme owner.

## Offline
Fully local-first/offline.

## Tests
New route tests cover persisted-history rendering, empty state, and post-save refresh. Static verification guards query ownership, missing-value semantics, accessibility states, and mobile CSS.

## Performance
History continues to use P12.2R1's bounded indexed selection. No observers, intervals, animation loops, or high-frequency subscriptions added.

## Known limitations
The first UI slice shows the bounded recent set only. Filtering/search, progressive paging, trade-detail navigation, and history mutation are intentionally deferred to controlled P12 sub-patches.

## Real-device status
Required because this patch changes the visible Journal route. Pending after canonical gate PASS.

## Result
HOLD pending canonical gate.

## Next
Only after PASS and visual verification: assess the next smallest P12 history interaction dependency without entering P13.
