import type { JournalHistoryEntry } from '../application/journal';

interface JournalHistoryListProps {
  readonly entries: readonly JournalHistoryEntry[];
  readonly isLoading: boolean;
  readonly errorMessage: string | null;
}

function statusLabel(status: JournalHistoryEntry['trade']['status']): string {
  if (status === 'draft') return 'Draft';
  if (status === 'open') return 'Open';
  if (status === 'closed') return 'Closed';
  return 'Cancelled';
}

function sideLabel(side: JournalHistoryEntry['trade']['side']): string {
  return side === 'long' ? 'Long' : 'Short';
}

function formatTimestamp(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(date);
}

export function JournalHistoryList({ entries, isLoading, errorMessage }: JournalHistoryListProps) {
  return (
    <section className="kairos-history" aria-labelledby="kairos-history-title" aria-busy={isLoading || undefined}>
      <div className="kairos-history__heading">
        <div>
          <p className="kairos-journal__eyebrow">Saved locally</p>
          <h2 id="kairos-history-title">Trade history</h2>
        </div>
        <span className="kairos-history__count">{entries.length} shown</span>
      </div>

      {errorMessage ? <p className="kairos-history__state kairos-history__state--error" role="alert">{errorMessage}</p> : null}
      {isLoading ? <p className="kairos-history__state" role="status">Loading trade history…</p> : null}
      {!isLoading && !errorMessage && entries.length === 0 ? (
        <p className="kairos-history__state">No saved trades yet. Your first saved trade will appear here.</p>
      ) : null}

      {!isLoading && !errorMessage && entries.length > 0 ? (
        <ol className="kairos-history__list">
          {entries.map((entry) => {
            const timestamp = entry.trade.closedAt ?? entry.trade.openedAt ?? entry.trade.updatedAt;
            return (
              <li className="kairos-history-card" key={entry.trade.id}>
                <div className="kairos-history-card__topline">
                  <strong>{entry.trade.symbol}</strong>
                  <span>{sideLabel(entry.trade.side)}</span>
                  <span>{statusLabel(entry.trade.status)}</span>
                </div>
                <time dateTime={timestamp}>{formatTimestamp(timestamp)}</time>
                <dl className="kairos-history-card__facts">
                  <div><dt>Executions</dt><dd>{entry.executions.length}</dd></div>
                  <div><dt>Fees</dt><dd>{entry.fees.length}</dd></div>
                  <div><dt>Gross P&amp;L</dt><dd>{entry.metrics?.grossPnl ?? 'Not available'}</dd></div>
                  <div><dt>Net P&amp;L</dt><dd>{entry.metrics?.netPnl ?? 'Not available'}</dd></div>
                </dl>
                {entry.metricsError ? <p className="kairos-history-card__notice">Some performance values are unavailable for this trade.</p> : null}
              </li>
            );
          })}
        </ol>
      ) : null}
    </section>
  );
}
