import type { KairosDatabase } from '../../data/database';
import { createKairosRepositories } from '../../data/repositories';
import { calculateTradeMetrics, type TradeMetricsResult } from '../../domain/calculations';
import type { TradeExecutionRecord, TradeFeeRecord, TradePlanRecord, TradeRecord } from '../../domain/trades';

export interface JournalHistoryEntry {
  readonly trade: TradeRecord;
  readonly plans: readonly TradePlanRecord[];
  readonly executions: readonly TradeExecutionRecord[];
  readonly fees: readonly TradeFeeRecord[];
  readonly metrics: Extract<TradeMetricsResult, { readonly ok: true }>['value'] | null;
  readonly metricsError: Extract<TradeMetricsResult, { readonly ok: false }>['reason'] | null;
}

export const DEFAULT_JOURNAL_HISTORY_LIMIT = 100 as const;
export const MAX_JOURNAL_HISTORY_LIMIT = 500 as const;

export interface JournalHistoryQueryOptions { readonly limit?: number; }

function normalizeHistoryLimit(limit: number | undefined): number {
  if (limit === undefined) return DEFAULT_JOURNAL_HISTORY_LIMIT;
  if (!Number.isInteger(limit) || limit < 1 || limit > MAX_JOURNAL_HISTORY_LIMIT) {
    throw new RangeError(`Journal history limit must be an integer from 1 to ${MAX_JOURNAL_HISTORY_LIMIT}.`);
  }
  return limit;
}

export async function listJournalHistory(
  db: KairosDatabase,
  options: JournalHistoryQueryOptions = {},
): Promise<readonly JournalHistoryEntry[]> {
  const repositories = createKairosRepositories(db);
  const trades = await repositories.trades.listRecentByUpdatedAt(normalizeHistoryLimit(options.limit));

  const entries = await Promise.all(trades.map(async (trade): Promise<JournalHistoryEntry> => {
    const [plans, executions, fees] = await Promise.all([
      repositories.tradePlans.listByTradeId(trade.id),
      repositories.tradeExecutions.listByTradeId(trade.id),
      repositories.tradeFees.listByTradeId(trade.id),
    ]);
    const metricsResult = calculateTradeMetrics(trade.side, executions, undefined, fees);
    return Object.freeze({
      trade,
      plans: Object.freeze(plans),
      executions: Object.freeze(executions),
      fees: Object.freeze(fees),
      metrics: metricsResult.ok ? metricsResult.value : null,
      metricsError: metricsResult.ok ? null : metricsResult.reason,
    });
  }));

  return Object.freeze(entries);
}
