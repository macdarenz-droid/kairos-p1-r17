import 'fake-indexeddb/auto';
import '@testing-library/jest-dom/vitest';
import { afterEach, describe, expect, it } from 'vitest';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { JournalRoute } from '../src/app/JournalRoute';
import { createKairosDatabase, openKairosDatabase } from '../src/data/database';
import { createKairosRepositories } from '../src/data/repositories';
import { createTradeDomainId, type TradeId } from '../src/domain/trades';

const names = new Set<string>();
const dbName = () => { const value = `kairos-p123-${crypto.randomUUID()}`; names.add(value); return value; };
afterEach(async () => { for (const name of names) await new Promise<void>((resolve, reject) => { const request=indexedDB.deleteDatabase(name); request.onsuccess=()=>resolve(); request.onerror=()=>reject(request.error); request.onblocked=()=>reject(new Error('blocked')); }); names.clear(); });

describe('P12.3 journal history route presentation', () => {
  it('renders persisted history through the P12 query without direct storage access in the component', async () => {
    const db=createKairosDatabase(dbName()); await openKairosDatabase(db); const repos=createKairosRepositories(db);
    await repos.trades.put({ id:createTradeDomainId<TradeId>(), symbol:'BTCUSD', marketType:'crypto', side:'long', status:'draft', source:'manual', openedAt:null, closedAt:null, createdAt:'2026-09-02T01:00:00.000Z', updatedAt:'2026-09-02T01:00:00.000Z' });
    render(<JournalRoute db={db} />);
    expect(await screen.findByRole('heading',{name:'Trade history'})).toBeInTheDocument();
    expect(await screen.findByText('BTCUSD')).toBeInTheDocument();
    expect(screen.getByText('1 shown')).toBeInTheDocument();
    db.close();
  });

  it('shows an empty state and refreshes history after a successful manual save', async () => {
    const db=createKairosDatabase(dbName()); await openKairosDatabase(db);
    render(<JournalRoute db={db} />);
    expect(await screen.findByText('No saved trades yet. Your first saved trade will appear here.')).toBeInTheDocument();
    fireEvent.change(screen.getByLabelText(/Symbol/),{target:{value:'AAPL'}});
    fireEvent.change(screen.getByLabelText(/Market/),{target:{value:'stock'}});
    fireEvent.change(screen.getByLabelText(/Direction/),{target:{value:'long'}});
    fireEvent.change(screen.getByLabelText(/Status/),{target:{value:'cancelled'}});
    fireEvent.click(screen.getByRole('button',{name:'Save trade'}));
    expect(await screen.findByText('Trade saved to your journal.')).toBeInTheDocument();
    await waitFor(()=>expect(screen.getByText('1 shown')).toBeInTheDocument());
    expect(screen.getByText('AAPL')).toBeInTheDocument();
    db.close();
  });
});
