import { readFileSync } from 'node:fs';

const production = readFileSync('src/features/chart/chartTrendLineEditPresentationCoordination.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const tests = readFileSync('tests/chart-trend-line-edit-presentation-coordination.test.ts', 'utf8');
const presentationPort = readFileSync('src/features/chart/chartDrawingPresentationPort.ts', 'utf8');

function fail(message) {
  console.error(`P18.51R1 verification failed: ${message}`);
  process.exit(1);
}

for (const token of [
  'executeChartTrendLineEditAndRefreshPresentation(',
  'executeChartTrendLineEdit(interaction, collection, anchor)',
  'if (edited === null) return null;',
  'refreshChartDrawingPresentationFromCollection(presentation, collection)',
  'return edited;',
]) {
  if (!production.includes(token)) fail(`production coordination missing token: ${token}`);
}

for (const forbidden of [
  'collection.replaceDrawing(',
  'collection.removeDrawing(',
  'interaction.dispatch(',
  "type: 'start-editing'",
  'projectChartDrawings(',
  'presentation.replaceDrawings(',
  'lightweight-charts',
  'subscribeClick(',
  'subscribeCrosshairMove(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'riskReward',
]) {
  if (production.includes(forbidden)) fail(`production coordination leaked protected ownership: ${forbidden}`);
}

if (!index.includes("export { executeChartTrendLineEditAndRefreshPresentation } from './chartTrendLineEditPresentationCoordination';")) {
  fail('chart index production export missing');
}

if (!presentationPort.includes('export interface ChartDrawingPresentationDrawingRefreshSession')) {
  fail('P18.46 drawing-refresh session owner missing');
}

if (!tests.includes("from '../src/features/chart/chartDrawingPresentationPort';")) {
  fail('focused test must import drawing-refresh session type directly from its owner module');
}

if (index.includes('ChartDrawingPresentationDrawingRefreshSession')) {
  fail('repair must not expand public chart barrel solely for a test-only type import');
}

for (const token of [
  'refreshes current committed drawing presentation exactly once after a successful edit',
  'does not refresh presentation when authoritative interaction state does not execute an edit',
  'does not refresh presentation for a stale authoritative edit target',
  'never rolls back committed edit truth when presentation refresh fails',
]) {
  if (!tests.includes(token)) fail(`focused runtime test missing case: ${token}`);
}

console.log('P18.51R1 chart trend-line edit presentation coordination typecheck import repair verification passed.');
