import type { MarketDataReconnectPolicy } from '../services/market-data/marketDataReconnectPolicy';

/** Shared authoritative page size for the historical-to-live Analysis handoff. */
export const ANALYSIS_LIVE_CANDLE_HISTORY_LIMIT = 500;

/**
 * Route-owned reconnect policy for the eventual Analysis live-candle mount.
 *
 * P15 remains the decision and jitter owner. This product policy limits one
 * disconnected session to four retries with capped exponential backoff.
 */
export const ANALYSIS_LIVE_CANDLE_RECONNECT_POLICY: Readonly<MarketDataReconnectPolicy> = Object.freeze({
  initialDelayMs: 1_000,
  maxDelayMs: 8_000,
  maxAttempts: 4,
});
