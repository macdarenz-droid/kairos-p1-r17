import { useCallback, useMemo, useState, type ComponentType } from 'react';
import type { JournalHistoryEntry } from '../application/journal';
import { getChartTheme, useTheme } from '../design-system/themes';
import type { MarketCandleHistorySnapshot } from '../services/market-data/MarketCandleHistoryPort';
import type { MarketDataInstrument } from '../services/market-data/marketDataTypes';
import {
  AnalysisLiveCandleCanvas,
  type AnalysisLiveCandleCanvasProps,
} from './AnalysisLiveCandleCanvas';
import { AnalysisSavedTradeMarkerEvidencePresentation } from './AnalysisSavedTradeMarkerEvidencePresentation';
import {
  createAnalysisCandleRendererSession,
  type AnalysisCandleRendererSessionInput,
} from './analysisCandleRendererSession';
import { createAnalysisLiveCandleRouteSession } from './analysisLiveCandleRouteSession';
import { projectAnalysisSavedTradeRiskRewardSnapshotExtent } from './analysisSavedTradeRiskRewardSnapshotExtentProjection';
import { createAnalysisSavedTradeRiskRewardThemeStyleSource } from './analysisSavedTradeRiskRewardThemeStyleSource';
import {
  useAnalysisSavedTradeOverlayPresentationSession,
  type AnalysisSavedTradeOverlayReactBindingOptions,
  type AnalysisSavedTradeOverlayReactBindingResult,
} from './useAnalysisSavedTradeOverlayPresentationSession';

export interface AnalysisSavedTradeOverlayLiveCandleCanvasProps {
  readonly entry: JournalHistoryEntry;
  readonly instrument: MarketDataInstrument;
  readonly interval: string;
  readonly quoteAsset: string;
  readonly revision?: number;
  readonly LiveCanvas?: ComponentType<AnalysisLiveCandleCanvasProps>;
  readonly useOverlayBinding?: (
    options: AnalysisSavedTradeOverlayReactBindingOptions,
  ) => AnalysisSavedTradeOverlayReactBindingResult;
  readonly createLiveSession?: typeof createAnalysisLiveCandleRouteSession;
  readonly createRendererSession?: typeof createAnalysisCandleRendererSession;
}

interface ScopedSnapshot {
  readonly key: string;
  readonly snapshot: MarketCandleHistorySnapshot | null;
}

const selectionKey = (
  instrument: MarketDataInstrument,
  interval: string,
  revision: number,
): string => [instrument.venue, instrument.symbol, interval, revision].join('\u0000');

/**
 * Unmounted composition boundary between Gate460's shared saved-trade overlay
 * lifecycle and the released live-candle canvas. The overlay supplies only its
 * exact renderer factory; the live owner supplies the authoritative history
 * snapshot. Risk/Reward presentation is deferred until Gate463 accepts that
 * exact snapshot extent, while Gate462 resolves style from the active theme.
 */
export function AnalysisSavedTradeOverlayLiveCandleCanvas({
  entry,
  instrument,
  interval,
  quoteAsset,
  revision = 0,
  LiveCanvas = AnalysisLiveCandleCanvas,
  useOverlayBinding = useAnalysisSavedTradeOverlayPresentationSession,
  createLiveSession = createAnalysisLiveCandleRouteSession,
  createRendererSession = createAnalysisCandleRendererSession,
}: AnalysisSavedTradeOverlayLiveCandleCanvasProps) {
  const { themeId } = useTheme();
  const key = selectionKey(instrument, interval, revision);
  const [scopedSnapshot, setScopedSnapshot] = useState<ScopedSnapshot>({ key, snapshot: null });
  const snapshot = scopedSnapshot.key === key ? scopedSnapshot.snapshot : null;
  const scope = useMemo(() => ({ instrument, quoteAsset }), [instrument.venue, instrument.symbol, quoteAsset]);
  const theme = useMemo(() => getChartTheme(themeId), [themeId]);
  const styleSource = useMemo(
    () => createAnalysisSavedTradeRiskRewardThemeStyleSource(themeId),
    [themeId],
  );
  const extentProjection = useMemo(
    () => snapshot === null
      ? null
      : projectAnalysisSavedTradeRiskRewardSnapshotExtent(snapshot, { instrument, interval }),
    [instrument.symbol, instrument.venue, interval, snapshot],
  );
  const extent = extentProjection?.kind === 'extent-ready' ? extentProjection.extent : null;
  const overlay = useOverlayBinding({
    entry,
    scope,
    snapshot,
    theme,
    extent,
    styleSource,
    revision,
  });

  const publishSnapshot = useCallback((next: MarketCandleHistorySnapshot | null) => {
    setScopedSnapshot({ key, snapshot: next });
  }, [key]);

  const createSession = useMemo(() => {
    const rendererFactory = overlay.rendererFactory;
    if (rendererFactory === null) return null;
    return () => createLiveSession({
      createRendererSession(input: AnalysisCandleRendererSessionInput) {
        return createRendererSession({ ...input, factory: rendererFactory });
      },
    });
  }, [createLiveSession, createRendererSession, overlay.rendererFactory]);

  const evidence = <AnalysisSavedTradeMarkerEvidencePresentation
    presentation={overlay.presentation?.markers ?? null}
    lastError={overlay.markerError}
    quoteAsset={quoteAsset}
  />;

  if (createSession === null) return evidence;
  return <>
    <LiveCanvas
      instrument={instrument}
      interval={interval}
      quoteAsset={quoteAsset}
      revision={revision}
      createSession={createSession}
      onAuthoritativeSnapshot={publishSnapshot}
    />
    {evidence}
  </>;
}
