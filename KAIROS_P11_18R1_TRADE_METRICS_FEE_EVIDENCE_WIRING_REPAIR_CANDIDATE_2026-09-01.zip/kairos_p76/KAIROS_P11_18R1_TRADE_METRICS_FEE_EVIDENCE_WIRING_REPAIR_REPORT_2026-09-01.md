# KAIROS P11.18R1 TradeMetrics Fee Evidence Wiring Repair Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Authoritative base
P11.17R1 PASS, gate run #39, artifact 9798935833.

## Repair reason
P11.18 gate run #40 failed only because the gate declared two unchanged legacy test files as required changed files. No build or unit regression executed. P11.18 was discarded under A35.

## Objective
Rebuild the fee-evidence wiring fresh from P11.17R1 and use an exact seven-file controlled scope.

## Contract
- Omitted fee evidence -> `totalFees: null`, `totalFeesCurrency: null`, `hasTotalFees: false`.
- Explicit empty fee evidence -> `totalFees: "0"`, `totalFeesCurrency: null`, `hasTotalFees: true`.
- Same-currency fees -> exact decimal total plus authoritative currency.
- Mixed currencies -> explicit `mixed-fee-currency` failure.
- Malformed fee decimals -> explicit `invalid-fee-decimal` failure.
- `netPnl` remains null and incomplete.

## Scope
Exactly seven files differ from P11.17R1:
1. this report
2. package.json
3. scripts/verify-p11-trade-metrics.mjs
4. scripts/verify-p11-trade-metrics-risk-evidence.mjs
5. scripts/verify-p11-trade-metrics-fee-evidence.mjs
6. src/domain/calculations/tradeMetrics.ts
7. tests/trade-metrics-fee-evidence.test.ts

No FX conversion, net-P&L composition, percentage wiring, persistence, UI, schema, network, or deployment changes.
