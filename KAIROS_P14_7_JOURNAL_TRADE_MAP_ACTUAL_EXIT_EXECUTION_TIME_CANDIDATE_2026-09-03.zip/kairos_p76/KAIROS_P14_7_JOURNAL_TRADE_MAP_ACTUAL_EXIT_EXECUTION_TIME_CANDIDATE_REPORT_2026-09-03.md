# KAIROS P14.7 — Journal Trade Map Actual Exit Execution Time

## Patch/Base/app/build identity
- Patch: P14.7
- Base: P14.6R2 canonical PASS candidate
- Area: Trade Visualizer / Journal Trade Map

## OBJECTIVE
Expose each authoritative actual-exit execution timestamp beside its exact actual-exit price in the native HTML Trade Map facts. Planned levels remain timeless planned facts. No new truth owner is introduced.

## RESEARCH
Current HTML guidance confirms `<time datetime="…">` is the semantic element for a specific machine-readable date/time. P14.7 therefore renders the already-authoritative `executedAt` string directly in both visible content and `dateTime`, without local parsing or timezone formatting.

## OWNER TRACE
Journal History hydrates persisted trade/plan/execution evidence → P14.1 fact projection → P14.2 display model → P14.3 Journal projection → JournalTradeMap presentation. `executedAt` already belongs to the existing display level; P14.7 only exposes it.

## PRE-CHANGE FLOW
Actual exits were distinguishable by label/shape and exact price, while their existing display-model `executedAt` field was not visible in the native HTML facts.

## CHANGE
- Actual-exit rows render `Executed <time dateTime={executedAt}>{executedAt}</time>` beneath the exact price.
- Planned rows do not render execution time.
- Styling uses semantic theme tokens.
- Added dedicated verifier and runtime test covering two partial exits.

## NON-SCOPE
No date parsing, locale conversion, timezone conversion, price geometry, candles, path inference, current price, market data, P&L, FX, persistence, network, animation, or P15+ work.

## DATA/STATE FLOW
Read-only rendering from `TradeVisualizerDisplayModel.levels[].executedAt`. No state mutation.

## PERSISTENCE
None.

## SECURITY
No new input, network, storage, or executable content surface.

## THEME
Execution-time metadata uses `var(--color-text-secondary)`.

## OFFLINE
Fully offline; consumes already hydrated local facts.

## TESTS
Dedicated runtime coverage asserts two actual exits retain exact prices and exact `datetime` values, and planned rows contain no `<time>` element.

## REGRESSION
Existing P14.6 marker semantics, P14.5 SVG shell, P14.4 presentation, P14.3 projection, P14.2 semantics, P14.1 facts, and closed P13/P12/P11 ownership remain protected by the canonical gate.

## PERFORMANCE
Presentation-only O(level-count) markup; no queries, parsing, observers, or timers.

## KNOWN LIMITATIONS
Timestamp is intentionally shown in authoritative stored ISO form. Friendly/local formatting remains out of scope until timezone presentation ownership is explicitly designed.

## REAL-DEVICE STATUS
Not independently real-device tested in this environment.

## RESULT
HOLD until canonical GitHub gate PASS.

## NEXT
Only after PASS: continue to the next dependency-safe P14 Trade Visualizer slice.
