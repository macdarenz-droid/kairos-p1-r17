import { readFileSync } from 'node:fs';

const read = path => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const workspace = read('src/app/AnalysisHistoryWorkspace.tsx');
const canvas = read('src/app/AnalysisLiveCandleCanvas.tsx');
const route = read('src/app/AnalysisRoute.tsx');
const bootstrap = read('src/app/binanceAnalysisHistoryLiveCandleBootstrapCoordination.ts');
const browser = read('scripts/test-analysis-history-browser.mjs');
const tests = read('tests/analysis-history-workspace.test.tsx');
const report = read('docs/KAIROS_ANALYSIS_LIVE_CANDLE_WORKSPACE_MOUNT.md');

for (const expected of [
  'AnalysisLiveCandleCanvas',
  'LiveCanvas = AnalysisLiveCandleCanvas',
  'instrument={fact.instrument}',
  'interval={interval}',
  'quoteAsset={fact.quoteAsset}',
  'revision={revision}',
  'Historical + live',
  'Connection and recovery status are shown above the chart.',
]) {
  if (!workspace.includes(expected)) throw new Error(`missing workspace live-candle mount evidence: ${expected}`);
}

for (const forbidden of [
  'MarketCandleHistoryPort',
  'MarketCandleHistoryResult',
  'AnalysisCandleCanvas',
  'acquireHistory(',
  'setHistory(',
  'historyFailure(',
  'scope-mismatch',
  'WebSocket',
  'indexedDB',
  'localStorage',
  'calculateTradeMetrics',
]) {
  if (workspace.includes(forbidden)) throw new Error(`duplicate or forbidden workspace owner: ${forbidden}`);
}

if (!(route.indexOf('<AnalysisHistoryWorkspace />') < route.indexOf('<TradeReviewDetails entry='))) {
  throw new Error('chart-first Analysis route ordering changed');
}
for (const expected of [
  'presentAnalysisLiveCandleStatus',
  'data-live-candle-status',
  'binding.activation?.ok',
  'Candle values',
  'Times in UTC',
]) {
  if (!canvas.includes(expected)) throw new Error(`released canvas evidence missing: ${expected}`);
}
for (const expected of [
  'history.acquireHistory(request',
  "reason: 'history-scope-mismatch'",
  'received.limit !== request.limit',
  "reason: 'history-empty'",
]) {
  if (!bootstrap.includes(expected)) throw new Error(`released authoritative-history evidence missing: ${expected}`);
}
for (const expected of [
  'never asks history directly',
  'uses only the explicit refresh button as the live-session revision key',
  'aborts metadata on timeout and unmount',
]) {
  if (!tests.includes(expected)) throw new Error(`workspace regression missing: ${expected}`);
}
for (const expected of [
  'routeWebSocket',
  'Live candles connected',
  'liveWorkspaceMounted: true',
  'exactProviderConnectedStatus: true',
  'oneHistoryOwner: true',
  'noJournalMutation: true',
]) {
  if (!browser.includes(expected)) throw new Error(`browser mount evidence missing: ${expected}`);
}
for (const forbidden of ['provider expansion', 'journal mutation', 'saved-analysis write', 'phase closure']) {
  if (!report.includes(forbidden)) throw new Error(`report boundary missing: ${forbidden}`);
}

console.log('PASS: Analysis mounts one exact-scope released live-candle canvas, delegates authoritative history/transport/renderer ownership, preserves truthful status and does not mutate journal facts.');
