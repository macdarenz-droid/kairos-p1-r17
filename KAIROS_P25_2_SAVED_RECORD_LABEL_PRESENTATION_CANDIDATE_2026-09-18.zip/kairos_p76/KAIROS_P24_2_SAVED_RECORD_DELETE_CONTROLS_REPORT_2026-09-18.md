# KAIROS P24.2 — Saved Record Delete Controls

**Patch label:** P24.2 · P24 saved record lifecycle · owner phase P24 (active from the Gate491 canonical PASS) · definition: the visible delete of the selected Saved Analysis and the selected saved time-assisted snapshot on the Analysis page, through the released P24.1 commands, with real browser evidence.

## Authority
Base: canonical Gate492 (P24.1 delete commands). Autonomous continuation under the user's "continue" of 18 September 2026 after the P23 closure report, recorded as proceeding with P24 under the same gate discipline.

## Result
Both saved-record groups on the Analysis page gain a delete: **Delete analysis** in the Saved analysis group and **Delete snapshot** in the Saved snapshot group, each enabled only with a selection and each removing exactly the selected record through a new `remove` port that calls the P24.1 command. The list refreshes and the selection moves to a remaining record; the chart, the shown estimate, the other store and the journal are never touched. Outcomes are plain words: deleted, "no longer exists" (list refreshed), or "could not be deleted. It is still saved." No undo and no confirmation dialog: the record stays in any earlier backup and the released restore brings it back. The released save/list/load ports, their pinned import lines and the workspace mounts are unchanged.

Unit evidence covers both controls with fake IndexedDB and the failure outcomes; real-browser evidence seeds records through the released save commands on the production database, deletes exactly the selected records per market, proves an untouched journal and other market, survives a reload and empties both groups at 390/320px in Ink and Paper. Details: `docs/KAIROS_ANALYSIS_SAVED_RECORD_DELETE.md`.

## Ownership
P24.2 owns only the delete controls and ports. P24.1 keeps the commands; P20/P23 keep persistence, save and load; P21.27/P23.5 keep the round trips; the journal owners keep trade truth.

## Non-scope
No undo, no confirmation dialog, no bulk delete, no rename or update, no backup change. Nothing else in the workspace changes.

## Next dependency boundary
P24.3 closes the phase: ledger closure, roadmap update and the whole-phase verifier.

## Canonical requirement
These controls become authoritative only after the exact P24.2 candidate receives a full `Kairos Controlled Roadmap Gate` PASS with both canonical artifacts and main carries the same commit with its own canonical PASS. P24.3 may not begin before that PASS.
