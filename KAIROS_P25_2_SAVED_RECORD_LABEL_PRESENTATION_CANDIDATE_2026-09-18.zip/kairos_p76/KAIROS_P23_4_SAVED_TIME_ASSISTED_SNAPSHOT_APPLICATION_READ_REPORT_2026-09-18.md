# KAIROS P23.4 — Saved Time-Assisted Snapshot Application Read Orchestration

**Patch label:** P23.4 · P23 durable time-assisted snapshot provenance · owner phase P23 (active from the Gate485 canonical PASS) · definition: the application read boundary that loads one saved time-assisted snapshot by its canonical stable id and lists the saved snapshots newest first.

## Authority
Base: canonical Gate488 (P23.3 application save orchestration). Autonomous continuation under the user's 18 September 2026 decision to proceed with P23 under the same gate discipline ("1").

## Result
`src/application/saved-time-assisted-snapshot/loadSavedTimeAssistedSnapshot.ts` owns two reads and nothing else:

- `loadSavedTimeAssistedSnapshot(db, id)` reads through `SavedTimeAssistedSnapshotRepository.get` and returns the structured-cloned record, an explicit `not-found` result (`saved-time-assisted-snapshot-not-found`) or an explicit `storage-error` result (`saved-time-assisted-snapshot-load-failed`).
- `listSavedTimeAssistedSnapshots(db)` reads through `SavedTimeAssistedSnapshotRepository.listAll`, clones every record, orders them newest save first with ties broken by id, freezes the list, and returns `saved-time-assisted-snapshot-list-failed` on storage failure. The ordering is a deterministic application projection over the stable-id store; no secondary index is introduced.

`tests/saved-time-assisted-snapshot-load-query.test.ts` proves the clone-safe load, the not-found result, the ordered and frozen list (including the empty store) and both storage-error results on a closed database.

## Ownership
P23.4 owns only these reads. P23.3 keeps the save command; P23.2 keeps raw persistence, integrity and backup/restore; P23.1 keeps the logical contract; P22 keeps estimate semantics; the journal owners keep trade truth.

## Non-scope
No UI. No update/delete orchestration. No estimate acquisition, provider, chart or pixel work. No query index. Nothing in the workspace changes.

## Next dependency boundary
P23.5 must mount save, list and load in the Analysis time-assisted preview on top of P23.3/P23.4 (save the shown estimate, list saved snapshots for the selected market, load one back into the preview and its markers/window), with browser evidence; P23.6 closes the phase.

## Canonical requirement
These reads become authoritative only after the exact P23.4 candidate receives a full `Kairos Controlled Roadmap Gate` PASS with both canonical artifacts and main carries the same commit with its own canonical PASS. P23.5 may not begin before that PASS.
