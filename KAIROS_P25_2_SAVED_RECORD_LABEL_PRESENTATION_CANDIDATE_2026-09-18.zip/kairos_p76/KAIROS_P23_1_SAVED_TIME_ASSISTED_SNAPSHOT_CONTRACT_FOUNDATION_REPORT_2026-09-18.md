# KAIROS P23.1 — Saved Time-Assisted Snapshot Contract Foundation

**Patch label:** P23.1 · P23 durable time-assisted snapshot provenance · owner phase P23 (active from the Gate485 canonical PASS) · definition: the provider-neutral saved time-assisted snapshot logical contract and its independent stable identity allocator.

## Authority
Base: canonical Gate485 (P22.6 closure), which defined P23 from ownership. The user chose on 18 September 2026 to proceed with P23 under the same gate discipline ("1").

## Result
P23.1 establishes only the saved time-assisted snapshot aggregate contract (`src/app/savedTimeAssistedSnapshotContract.ts`) and its identity allocator (`src/app/savedTimeAssistedSnapshotIdentity.ts`). The contract composes existing owners instead of copying them: the P17 `ChartMarketReference`, the P22.2 side and instants, and the P22.1 `EstimatedMarketReference` values, which already carry their provenance (method, resolution, exact candle, gap from the candle open, acquisition time). It adds the entered instants exactly as typed with their UTC normalisation, the device time zone in effect, the duration and the save moment. An unavailable estimate remains representable so a saved record states exactly what could and could not be estimated.

The aggregate is contract-only. It carries no price, P&L, hypothetical result, execution identity or trade relation, and it is never journal truth.

## Ownership
P23 owns only the saved time-assisted snapshot aggregate identity/composition boundary introduced here. P22.1/P22.2 retain estimate semantics; P17 retains market-reference truth; P20 retains Saved Analyses; P10/P11/P13/P14 retain journal and result truth.

## Non-scope
No database schema, migration, repository, transaction, backup/restore, UI, provider or pixel work. No display name, trade relation, persistence index or renderer state is introduced.

## Next dependency boundary
P23.2 must consume this contract and evolve the established persistence plus full backup/restore system coherently (schema version, migration, repository, backup format, restore preflight/replacement/verification, integrity). This patch does not preselect that storage shape.

## Canonical requirement
This contract becomes authoritative only after the exact P23.1 candidate receives a full `Kairos Controlled Roadmap Gate` PASS with both canonical artifacts and main carries the same commit with its own canonical PASS. P23.2 may not begin before that PASS.
