# KAIROS P22.2 — Time-Assisted Trade Snapshot Composition

**Patch label:** P22.2 · P22 time-assisted trade snapshot · owner phase P22 (active) · definition: the readonly application composition that turns instrument, side and opening/closing instants into the two P22.1 estimates plus the exact duration, with no price, result or journal identity.

## Authority
Base: canonical Gate480 (P22.1 estimated market-reference foundation) under the user's autonomous-continuation instruction of 17 September 2026 and the P22 definition recorded at P21 closure.

## Boundary added
`src/application/market-reference/timeAssistedTradeSnapshot.ts`, exported through the market-reference index:

- `TimeAssistedTradeSnapshotRequest`: exact instrument, `side` (`long` | `short`), ISO-8601 `openedAt` (any offset) and `closedAt` or `null` for a trade still open.
- `composeTimeAssistedTradeSnapshot(port, request, options)`: validates the request shape first and rejects `side-invalid`, `opened-at-invalid`, `closed-at-invalid` and `closed-before-opened` without any port call; then resolves the opening and (when given) closing estimates through the released P22.1 boundary over the released P15/P16 history port, each reporting its own availability so one unavailable instant never hides the other. A future instant is a P22.1 `unavailable` estimate, not a request rejection.
- `TimeAssistedTradeSnapshot`: `kind 'snapshot'`, `isEstimate true`, `source 'market-reference'`, instrument, side, `opening`, `closing` (or null) and `durationMs` (or null). It carries **no price, no P&L, no hypothetical result and no execution identity**; the feasibility policy allows a hypothetical result only with separately supplied assumptions, which this slice does not add.

## Retained ownership and non-scope
P22.1 remains the only estimation owner; P15/P16 remain acquisition owners; P10/P11/P13/P14 journal and result truth are untouched. No UI, route, chart marker, interval/window policy, persistence or Saved Analysis extension is added. The visible preview (inputs, disclosed estimated markers on the released chart) follows in later P22 slices.

## Evidence
`tests/time-assisted-trade-snapshot.test.ts` proves the two P22.1 lookups with offset instants and exact duration, the frozen snapshot without price/result/execution fields, the open-trade case, per-instant availability, and every request rejection before any port call. `scripts/verify-p22-2-time-assisted-trade-snapshot-composition.mjs` pins the boundary, its exports, forbidden dependencies and this report.

## Canonical requirement
This composition is authoritative only after the exact candidate receives full PASS from `Kairos Controlled Roadmap Gate` with both artifacts and main carries the same commit with its own canonical PASS. P22.3 may not begin before that PASS.
