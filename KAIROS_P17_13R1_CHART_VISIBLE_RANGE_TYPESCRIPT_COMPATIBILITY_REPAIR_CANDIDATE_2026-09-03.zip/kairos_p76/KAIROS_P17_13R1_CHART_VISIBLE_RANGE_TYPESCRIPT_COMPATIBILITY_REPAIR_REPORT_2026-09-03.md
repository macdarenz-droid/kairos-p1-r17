# KAIROS P17.13R1 — Chart Visible Range TypeScript Compatibility Repair

## AUTHORITATIVE BASE
P17.12 Incremental Chart Engine Driver Composition — canonical PASS, Run #184.

## FAILED CANDIDATE
P17.13 initial candidate failed canonical Run #186 during Production TypeScript compilation.

## PROVEN DEFECTS
1. Existing Lightweight Charts v5 module-adapter test double did not implement the newly required `timeScale()` member.
2. Responsive-sizing test double likewise did not implement `timeScale()`.
3. The new visible-range test used a nullable captured handler pattern that TypeScript narrowed incorrectly at the call site.

## REPAIR
- Added narrow `timeScale()` stubs to affected typed test doubles only.
- Reworked the visible-range test to use an explicit mutable handler box and guarded invocation.
- Production P17.13 viewport contract and adapter behavior remain unchanged.

## NON-SCOPE
No provider acquisition, Binance logic, persistence, journal truth, calculations, drawings, markers, navigation, styling, or P18 work.

## RESULT
This is a controlled repair candidate from authoritative P17.12. Canonical GitHub CI is required before promotion.
