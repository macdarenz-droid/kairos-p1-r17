# KAIROS P14.4 — Journal Trade Map Accessible Facts Presentation

## OBJECTIVE
Expose the P14.3 Journal Trade Visualizer projection in Journal History as an accessible, exact-text Trade Map before introducing visual geometry.

## RESEARCH
Current MDN/W3C guidance confirms contentful graphics require a text alternative/accessibility name. P14.4 deliberately stops before SVG; the first presentation is native HTML with an explicitly named region and exact text facts, preserving a complete accessible equivalent for later visual layers.

## OWNER TRACE / PRE-CHANGE FLOW
JournalHistoryEntry → P14.1 facts → P14.2 display semantics → P14.3 journal projection. P14.4 consumes only projectJournalTradeVisualizer(entry); no new query, storage, calculation, or market-data owner is introduced.

## CHANGE
Adds JournalTradeMap and wires it into each rendered Journal History card. It renders symbol context, side/status, planned entry/stop/target when present, and authoritative actual exits when present. Exact DecimalString values are rendered as text without numeric conversion.

## NON-SCOPE
No SVG/canvas, coordinate scaling, candles, synthetic path, current/live price, market data, FX, P&L calculation, animation, DB access, repository creation, or P15+ work.

## ACCESSIBILITY / THEME / OFFLINE
Uses native section/dl semantics and an explicit accessible region name. Presentation uses existing semantic tokens. No network dependency is introduced.

## TESTS
Dedicated runtime tests cover open-trade planned facts with no invented exit and closed-trade authoritative actual exit. Static verifier enforces P14.3 projection reuse and rejects DB/network/geometry/numeric-conversion ownership in the new component.

## LOCAL VERIFICATION
Static source inspection completed. Dependency installation/build/runtime execution could not be completed in the current container because npm installation exceeded the available tool execution window. Canonical GitHub gate is therefore required before promotion.

## RESULT
HOLD — candidate prepared; P14.3 is canonical PASS, but P14.4 requires upload and canonical GitHub gate before becoming authoritative.
