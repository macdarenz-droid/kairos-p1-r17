import 'fake-indexeddb/auto';
import '@testing-library/jest-dom/vitest';
import { afterEach, describe, expect, it } from 'vitest';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { SettingsRoute } from '../src/app/SettingsRoute';
import { createKairosDatabase, openKairosDatabase } from '../src/data/database';
import { createKairosRepositories } from '../src/data/repositories';
import { readVisualPnlTimeZonePreference } from '../src/application/visual-pnl';

const names = new Set<string>();
async function fixture(label: string) {
  const name=`kairos-p1312-${label}-${crypto.randomUUID()}`; names.add(name);
  const db=createKairosDatabase(name); await openKairosDatabase(db);
  return { db, repositories:createKairosRepositories(db) };
}
afterEach(async()=>{ for(const name of names){ await new Promise<void>((resolve,reject)=>{ const r=indexedDB.deleteDatabase(name); r.onsuccess=()=>resolve(); r.onerror=()=>reject(r.error); r.onblocked=()=>reject(new Error('blocked')); }); } names.clear(); });

describe('P13.12 explicit Visual P&L timezone settings',()=>{
  it('starts unconfigured and never inserts a device timezone', async()=>{
    const {db}=await fixture('empty');
    render(<SettingsRoute db={db}/>);
    expect(await screen.findByText('Not configured')).toBeInTheDocument();
    expect(screen.getByLabelText('Time zone')).toHaveValue('');
    db.close();
  });

  it('persists an explicitly entered valid timezone through P13.10R1', async()=>{
    const {db,repositories}=await fixture('save');
    render(<SettingsRoute db={db}/>);
    const input=await screen.findByLabelText('Time zone');
    fireEvent.change(input,{target:{value:'Australia/Sydney'}});
    fireEvent.click(screen.getByRole('button',{name:'Save time zone'}));
    expect(await screen.findByText('Daily-results time zone saved.')).toBeInTheDocument();
    await waitFor(async()=>expect(await readVisualPnlTimeZonePreference(repositories.metadata)).toBe('Australia/Sydney'));
    db.close();
  });

  it('rejects invalid evidence without replacing the stored preference', async()=>{
    const {db,repositories}=await fixture('invalid');
    await repositories.metadata.put({key:'preferences.visual-pnl.time-zone.v1',value:'UTC',updatedAt:'2026-09-02T00:00:00.000Z'});
    render(<SettingsRoute db={db}/>);
    const input=await screen.findByDisplayValue('UTC');
    fireEvent.change(input,{target:{value:'Not/A_Time_Zone'}});
    fireEvent.click(screen.getByRole('button',{name:'Save time zone'}));
    expect(await screen.findByRole('alert')).toHaveTextContent('Enter a valid time zone');
    expect(await readVisualPnlTimeZonePreference(repositories.metadata)).toBe('UTC');
    db.close();
  });
});
