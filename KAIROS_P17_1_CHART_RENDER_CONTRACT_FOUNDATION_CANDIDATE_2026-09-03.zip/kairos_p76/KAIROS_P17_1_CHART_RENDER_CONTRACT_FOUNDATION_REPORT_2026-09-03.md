# KAIROS P17.1 — Chart Render Contract Foundation

## OBJECTIVE
Establish the P17 Chart Engine boundary as render-only before integrating a concrete chart library.

## RESEARCH
TradingView Lightweight Charts 5.2.1 is the current public release. Its v5 API is client-side, targets ES2020, includes TypeScript declarations, and uses createChart plus series APIs. P17.1 does not install or instantiate the library yet; the ownership contract is locked first.

## OWNER TRACE
P11 remains calculation owner.
P14 remains trade-visual semantics owner.
P15 remains provider-neutral market-data lifecycle/reconnect owner.
P16 remains Binance Spot live-feed owner.
P17 receives authoritative presentation inputs and renders them.

## CHANGE
Adds a provider-neutral chart render contract with:
- market-reference identity
- price-line presentation points
- candle presentation data
- journal execution references kept semantically distinct
- DecimalString values
- no-op identity constructor with no calculation/mutation

## INVARIANTS
Chart rendering never mutates journal truth or market-data truth.
Candle close is never treated as expected execution price.
Missing data is never invented.
No persistence, WebSocket, reconnect, scheduler, timer, random, credentials, order execution, or calculation ownership.

## NON-SCOPE
No Lightweight Charts dependency yet, no DOM/canvas renderer, no candle acquisition, no live wiring, no drawing tools, no risk/reward tool, no persistence, no route changes.

## TESTS
P17.1 verifier: PASS locally.
P1 static contract: PASS locally.
Dedicated Vitest was attempted locally but timed out at the execution limit; runtime PASS is not claimed locally and must be decided by canonical CI.

## RESULT
HOLD pending canonical gate.
