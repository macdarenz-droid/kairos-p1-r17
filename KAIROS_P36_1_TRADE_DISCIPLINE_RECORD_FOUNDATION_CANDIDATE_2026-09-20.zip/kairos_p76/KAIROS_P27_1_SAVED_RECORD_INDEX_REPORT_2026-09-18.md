# KAIROS P27.1 — Saved Record Index

**Patch label:** P27.1 · P27 Library foundation · owner phase P27 (active from the Gate501 canonical PASS) · definition: the read-only cross-market index over the released Saved Analysis and saved snapshot listings, with ordering, distinct markets and a kind/market filter.

## Authority
Base: canonical Gate501 (P26.4 closure), which defined P27 from research: Library is a primary tab still rendering the placeholder while the app's saved records are reachable only inside Analysis per market. Autonomous continuation under the user's 18 September 2026 rule.

## Research settled before implementation
- Both saved-record repositories already expose `listAll`; the index reads those two listings and nothing else, so no new store, index or field is needed.
- The P23.1 contract carries a save moment; the P20.1 contract carries no save moment, so the index orders snapshots newest first and Saved Analyses after them by label then id, and states `savedAt: null` for an analysis rather than inventing one.
- Labels (P25) and markets (P17) are carried as stored; nothing is normalised or re-estimated.

## Result
`src/application/library/savedRecordIndex.ts` owns `buildSavedRecordIndex` (entries, distinct markets ordered by venue then instrument, counts), `orderSavedRecordIndexEntries`, `filterSavedRecordIndex` (kind and exact market, order preserved) and `listSavedRecordIndex(db)` over the released repositories. The Library route stays a placeholder in this patch.

`tests/saved-record-index.test.ts` proves the ordering and entry shapes, markets and counts, the filters, and the database read with nothing written.

## Ownership
P27 owns only the index. P20/P23 keep their records, P25 the labels, P24 deletion, P21.27/P23.5 loading into Analysis.

## Non-scope
No UI. No write. No new store, index or field. No save moment for Saved Analyses.

## Next dependency boundary
P27.2 replaces the Library placeholder with the route: the list over this index, the kind/market filter, and an "Open in Analysis" handoff to the released load paths, with unit and real-browser evidence; P27.3 closes the phase.

## Canonical requirement
This index becomes authoritative only after the exact P27.1 candidate receives a full `Kairos Controlled Roadmap Gate` PASS with both canonical artifacts and main carries the same commit with its own canonical PASS. P27.2 may not begin before that PASS.
