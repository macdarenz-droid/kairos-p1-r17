# KAIROS P28.2 — Backup Restore Command

**Patch label:** P28.2 · P28 Profile foundation: your data · owner phase P28 (active from the Gate504 canonical PASS) · definition: the two-step application command that restores a backup file over the released P6 preflight → preview → confirm → verified replacement path with explicit outcomes and the pre-restore copy on every failure.

## Authority
Base: canonical Gate505 (P28.1 backup export command). Autonomous continuation under the user's 18 September 2026 rule.

## Research settled before implementation
- `prepareKairosRestore` (P6.3) already parses, migrates and validates the incoming file, refuses incompatible or inconsistent payloads with a typed code, and takes the recovery snapshot; `restoreAndVerifyKairosDatabase` (P6.4/P6.5) already replaces every store in one atomic write, reopens the database and re-queries it against the prepared payload. Neither is called by any route. P28.2 composes them into two explicit steps and adds no restore logic.
- The recovery snapshot is exposed as a P28.1 file (named from its own export moment, so the command owns no clock) before anything is written and again on every post-commit failure, so the previous data is always downloadable.
- `MetadataRepository.replaceAll` retains device-scoped metadata by P6 design, so the activation receipt survives a restore; the tests prove it.
- A backup is read as text by the caller; the command guards the text at 64 MiB before parsing so an accidental file cannot be parsed into memory.

## Result
`src/application/backup/restoreBackup.ts` exports `prepareBackupRestore(db, serializedBackup)` → `{ ok: true, restore: { preview, recoveryFile, prepared } }` or `invalid-input` (`backup-file-too-large`), `invalid-backup` (`backup-unreadable` with the validation code), `incompatible-backup` (`restore-preflight-refused` with the preflight code), `integrity-error` (failed check ids) or `storage-error` (`restore-prepare-failed`), and `commitBackupRestore(db, restore)` → `{ ok: true, restored }` (restored counts, reloaded total, `verifiedAfterReload: true`) or `verification-error` (P6.5 code), `integrity-error` or `storage-error` (`restore-replacement-failed`), each carrying `recoveryFile`. Unit tests prove the preview and recovery file with nothing written, the verified replacement, the size guard before any database access, each refusal with its code, and the recovery file on verification and storage failures. UI VISIBLE:NO.

## Ownership
P28.2 owns only the two-step composition, the size guard and the outcome contract. P6 keeps preflight, replacement and verification; P28.1 keeps the file shape; P5 keeps the database.

## Non-scope
No route, file picker or confirmation UI (P28.3). No partial or merge restore. No schema, backup format or metadata change.

## Next dependency boundary
P28.3 mounts export and restore on the Profile route with the read-only activation state.

## Canonical requirement
This command becomes authoritative only after the exact P28.2 candidate receives a full `Kairos Controlled Roadmap Gate` PASS with both canonical artifacts and main carries the same commit with its own canonical PASS. P28.3 may not begin before that PASS.
