# KAIROS P31.1 — Draft Trade Activation Command

**Patch label:** P31.1 · P31 Trade record lifecycle: draft activation · owner phase P31 (active from the Gate515 canonical PASS) · definition: the application command that moves one saved manual draft to open with its opened moment and optional first fills, fees and price currency in one atomic write, keeping its id and plan.

## Authority
Base: canonical Gate515 (P30.3 trade record lifecycle closure). Autonomous continuation under the user's 18 September 2026 rule. P31 was defined from research at the P30 closure.

## Research settled before implementation
- `prepareManualTrade` (P10.1) already validates an open trade (opened moment required, positive prices and quantities, valid fill times, currency code), so the activation re-prepares the draft's own facts with status open and the new inputs and adds no validation of its own.
- `updateOpenManualTrade` (P10.4) already fixed the guarded-write pattern: re-read inside the transaction, compare a revision of header and children so a stale form is never applied, reject an id collision before any write, append only. P31.1 uses the same revision and guards for drafts and the transition draft → open.
- Practice drafts stay recorded only (P29 non-scope): the command refuses any trade that is not a manual draft.

## Result
`src/application/trades/openDraftTrade.ts` exports `openDraftTrade(db, { expected, openedAt, grossPnlCurrency?, executions, fees }, dependencies)` → the P10 save result (`{ ok: true, tradeId, persisted }` with the plan count 0 because the plan is kept, not written), the P10 `validation-error`, `storage-error`, or `update-conflict` (`trade-not-draft-manual`, `trade-changed`, `identity-conflict`). Unit tests prove the transition with the first fill, fee and currency and the plan and id kept, the refusals for an open trade, a practice draft, a missing opened moment, an invalid fill and a stale snapshot with nothing written, and the explicit storage failure. The Gate515 (P30.3) verifier pin that asserted no activation command existed advanced to the command literal. UI VISIBLE:NO.

## Ownership
P31.1 owns only the draft → open composition. P10 keeps the preparation, the manual write and the open-trade update; P9 the atomic write; P12 the history.

## Non-scope
No control (P31.2). No draft edit of symbol, market or side. No draft → closed in one step. No practice activation.

## Next dependency boundary
P31.2 mounts the control on the draft history card with the released execution, fee and currency fields.

## Canonical requirement
This command becomes authoritative only after the exact P31.1 candidate receives a full `Kairos Controlled Roadmap Gate` PASS with both canonical artifacts and main carries the same commit with its own canonical PASS. P31.2 may not begin before that PASS.
