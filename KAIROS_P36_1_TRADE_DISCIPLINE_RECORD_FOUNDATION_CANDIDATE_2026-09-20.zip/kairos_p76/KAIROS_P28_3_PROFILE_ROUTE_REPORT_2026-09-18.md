# KAIROS P28.3 — Profile Route

**Patch label:** P28.3 · P28 Profile foundation: your data · owner phase P28 (active from the Gate504 canonical PASS) · definition: the Profile page replacing the More-tab placeholder, mounting the P28.1 backup export, the P28.2 restore flow and the read-only device activation state, proven in unit tests and a real browser.

## Authority
Base: canonical Gate506 (P28.2 backup restore command). Autonomous continuation under the user's 18 September 2026 rule.

## Research settled before implementation
- The activation receipt is stored by `ActivationReceiptRepository` under one device-scoped metadata key; its `load()` already distinguishes missing, corrupt and stored, so the route reads through it and shows only the activation id and moments, never the payload or signature, and never verifies (the verifier needs the deployment public key that belongs to the activation gate).
- A browser download and a file read are the only two facts a unit test cannot supply, so both are props with browser defaults (`createBrowserBackupDownloadPorts(window)` and `File.text()`); Playwright proves the real ones.
- Restore is destructive, so the route never writes on file choice: the P28.2 prepare step yields the preview and the recovery file, the picker is locked while a preview is open, and only the explicit "Replace my data" reaches the commit step.

## Result
`/profile` renders `ProfileRoute` instead of `PlaceholderRoute`: the device card (activation state, version, build), the export card (Download backup → named V4 file, status with record count and size) and the restore card (Backup file picker → refusal or preview → Download current data first / Replace my data / Cancel → verified outcome or failure with the pre-restore copy). The Gate500/Gate503/Gate504/Gate505/Gate506 pins on the Profile placeholder advanced to the route line. Practice stays a placeholder.

Unit and real-browser evidence cover the activation states, the real download of the current journal, the unchanged store after export and preview, the refusal of a non-backup, the verified replacement and its visibility on the Goals page, the retained device receipt, the failure paths with the recovery file, and both viewports in both themes. Details: `docs/KAIROS_PROFILE_ROUTE.md`.

## Ownership
P28.3 owns only the Profile route and its presentation of the P28.1/P28.2 outcomes. P28.1 keeps the export, P28.2 the restore, P6 the backup lifecycle, the activation service its receipt, the shell navigation.

## Non-scope
No activation write, clearing or verification. No partial restore. No journal edit. Practice stays a placeholder.

## Next dependency boundary
P28.4 closes the phase: ledger closure, roadmap update and the whole-phase verifier.

## Canonical requirement
This route becomes authoritative only after the exact P28.3 candidate receives a full `Kairos Controlled Roadmap Gate` PASS with both canonical artifacts and main carries the same commit with its own canonical PASS. P28.4 may not begin before that PASS.
