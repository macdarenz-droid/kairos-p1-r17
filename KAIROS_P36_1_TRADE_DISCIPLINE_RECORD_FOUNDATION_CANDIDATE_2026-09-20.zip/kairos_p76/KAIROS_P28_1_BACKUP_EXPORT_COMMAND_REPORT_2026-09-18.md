# KAIROS P28.1 — Backup Export Command

**Patch label:** P28.1 · P28 Profile foundation: your data · owner phase P28 (active from the Gate504 canonical PASS) · definition: the application command that turns the released P6 snapshot into one named `.json` backup file and the seam that hands that file to the browser as a download, nothing written.

## Authority
Base: canonical Gate504 (P27.3 Library foundation closure). Autonomous continuation under the user's 18 September 2026 rule. P28 was defined from research at the P27 closure.

## Research settled before implementation
- `createKairosDatabaseSnapshot` (P6.2) already produces the integrity-checked, device-metadata-free V4 envelope inside one read transaction, and `serializeKairosBackup` already validates and serialises it; no route calls either. P28.1 therefore adds no snapshot logic: it composes the two released functions and names the result.
- The export moment is the caller's explicit `Date` (the Profile route will pass its wall clock), so the command owns no clock and the file name is reproducible in tests: `kairos-backup-2026-09-18T15-51-00Z.json` (UTC to the second, colons replaced, sortable, filesystem-safe).
- A browser download needs three facts a unit test cannot supply (object URL creation, an anchor click, URL release), so they are a port interface with one browser implementation; the object URL is released in `finally` whatever the click does.

## Result
`src/application/backup/exportBackup.ts` exports `exportKairosBackup(db, exportedAt)` → `{ ok: true, file }` with `fileName`, `mediaType` (`application/json`), `contents`, `byteLength`, `exportedAt` and the envelope's `recordCounts`, or an explicit `invalid-input` (`export-moment-invalid`, refused before any database access), `integrity-error` (`database-integrity-failed` with the failed check ids) or `storage-error` (`backup-export-failed`). `handBackupFileToBrowser(file, ports)` and `createBrowserBackupDownloadPorts(window)` own the download hand-off. Unit tests prove the file name, the parseable V4 contents with device metadata excluded, the unchanged record counts after export, each failure outcome and the port call order including release after a failed click. UI VISIBLE:NO.

## Ownership
P28.1 owns only the export composition, the file name policy and the download seam. P6 keeps the envelope, validation, serialisation and integrity; P5 keeps the database.

## Non-scope
No restore (P28.2). No route or button (P28.3). No schema, backup format or metadata change. No write of any kind.

## Next dependency boundary
P28.2 adds the restore command over the released P6 preflight → preview → verified replacement path.

## Canonical requirement
This command becomes authoritative only after the exact P28.1 candidate receives a full `Kairos Controlled Roadmap Gate` PASS with both canonical artifacts and main carries the same commit with its own canonical PASS. P28.2 may not begin before that PASS.
