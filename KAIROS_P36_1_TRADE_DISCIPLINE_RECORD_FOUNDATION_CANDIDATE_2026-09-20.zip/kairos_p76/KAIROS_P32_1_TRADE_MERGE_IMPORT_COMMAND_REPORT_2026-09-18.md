# KAIROS P32.1 — Trade Merge-Import Command

**Patch label:** P32.1 · P32 Journal import: merge trades from a backup · owner phase P32 (active from the Gate518 canonical PASS) · definition: the two-step application command that adds the trades a Kairos backup holds and this device lacks, with their own plans, executions and fees, in one atomic write, never touching an existing record.

## Authority
Base: canonical Gate518 (P31.3 draft activation closure). Autonomous continuation under the user's 18 September 2026 rule. P32 was defined from research at the P31 closure.

## Research settled before implementation
- `preflightKairosRestore` (P6.3) already parses, migrates and validates a backup and refuses duplicate ids and broken references without touching the database, so the import reads through it and takes no recovery snapshot (nothing is replaced).
- Trade ids are the merge key: the backup format carries every trade with its stable id and its children by `tradeId`; a trade already on the device is left byte-identical and its children are never touched.
- Provenance: a trade whose source describes real executions elsewhere (`manual`, `import`, `broker-import`) arrives as `import`, so the journal shows where it came from and the P29.2 real scope still lists it; a practice trade keeps its source and stays in the practice scope.
- A child id already on the device can only mean two different histories share an id; the import refuses rather than guess, both at preview and again inside the confirmed write.

## Result
`src/application/backup/importTrades.ts` exports `prepareTradeImport(db, serializedBackup)` → `{ ok: true, import: { preview, trades, plans, executions, fees } }` or `invalid-input` (size), `invalid-backup` (validation code), `incompatible-backup` (preflight code), `identity-conflict` (`child-id-present`) or `storage-error`, and `commitTradeImport(db, import)` → `{ ok: true, added, skipped }` or `identity-conflict` / `storage-error`. Unit tests prove the preview and the merge with re-stamped sources against a backup from a second device, the untouched existing trade and the skip of a trade that appeared between preview and confirmation, every refusal with nothing written, and the explicit storage failures. The Gate518 (P31.3) verifier pin that asserted no import command existed advanced to the command literal. UI VISIBLE:NO.

## Ownership
P32.1 owns only the selection, re-stamping and merge write. P6 keeps parsing, validation and the format; P5 the stores; P9 the atomic write; P28 the Profile page.

## Non-scope
No control or file picker (P32.2). No import of saved analyses, snapshots or preferences. No replacement of existing records (P28 restore owns that).

## Next dependency boundary
P32.2 mounts the Profile "Import trades" control with a preview and confirmation.

## Canonical requirement
This command becomes authoritative only after the exact P32.1 candidate receives a full `Kairos Controlled Roadmap Gate` PASS with both canonical artifacts and main carries the same commit with its own canonical PASS. P32.2 may not begin before that PASS.
