# KAIROS P18.15 — Lightweight Charts v5 Drawing Hover Subscription Lifecycle

## Authority
Built from canonical P18.14 after GitHub Actions run #213 passed from P18.13R1.

## Controlled scope
P18.15 adds one provider-specific crosshair-move subscription lifecycle boundary for drawing hover presentation.

Ownership remains split deliberately:
- P18.13R1: provider primitive hit-test binding and externalId source.
- P18.14: provider hoveredObjectId -> Kairos drawing-hover projection.
- P18.15: subscribeCrosshairMove/unsubscribeCrosshairMove lifecycle only.

The subscription captures one immutable renderer-drawing snapshot, delegates every provider event to P18.14, emits either a drawing-hover projection or null, and unsubscribes the exact registered handler once on idempotent destroy.

## Explicit non-scope
No click subscription, selection state, drag/edit behavior, drawing-truth mutation, persistence, calculations, market acquisition, journal truth, toolbar state, navigation state, autoscale ownership, or P19 risk/reward behavior.

## Research basis
Lightweight Charts v5.2 IChartApi documents subscribeCrosshairMove(handler) and matching unsubscribeCrosshairMove(handler), both using MouseEventHandler. Mouse-event parameters expose hoveredObjectId for hovered provider/plugin objects.

## Evidence
- Dedicated P18.15 static verifier: PASS locally.
- Dedicated P18.15 Vitest and broader regression remain for canonical GitHub gating.
