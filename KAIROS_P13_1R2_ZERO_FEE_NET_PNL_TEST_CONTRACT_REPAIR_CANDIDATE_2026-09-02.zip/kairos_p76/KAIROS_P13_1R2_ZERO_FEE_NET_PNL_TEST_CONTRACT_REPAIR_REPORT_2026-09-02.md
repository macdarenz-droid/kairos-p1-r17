# KAIROS P13.1R2 — Zero-Fee Net P&L Test Contract Repair

- Patch: P13.1R2
- Base: canonical P12.7R2 PASS artifact (Run #69)
- Objective: repair the sole P13.1R1 failing test so it respects established P11 zero-fee net-P&L composition while preserving the Visual P&L compatibility fallback.
- Canonical failure evidence: P13.1R1 Run #71 built successfully and passed 323 tests; one new P13 test incorrectly expected `metrics.netPnl` to be null for zero fees, while authoritative P11 returned `"10"`.
- Owner trace: P11 `calculateTradeMetrics` remains financial truth owner. P13 is a read-only semantic projection consumer.
- Pre-change: P13 test contradicted P11 by asserting zero-fee `netPnl === null`.
- Change: test now asserts P11 zero-fee `netPnl === "10"` and `source: "net-pnl"`; a cloned explicit `netPnl: null` + `totalFees: "0"` compatibility fixture separately exercises the guarded gross fallback. Verifier requires both contracts.
- Production code: unchanged from P13.1/P13.1R1.
- Non-scope: no P11 arithmetic change; no database/schema/persistence change; no Journal route/UI change; no FX inference; no P14 Trade Visualizer/chart/candle work; no deployment change.
- Data flow: P11 TradeMetrics -> P13 `projectVisualPnlOutcome` -> semantic result only.
- Persistence: none.
- Security: none.
- Theme/accessibility: semantic text labels remain Profit/Loss/Break-even/Not available; no color-only contract.
- Offline: unchanged.
- Regression target: exact six-file delta from P12.7R2; full build/unit/verifier chain; P12 closure and USER_HEAVY canary.
- Known limitation: P13.1 is a projection foundation only; no Journal UI rendering yet.
- Real-device status: not applicable to this non-UI slice.
- Result: HOLD until canonical GitHub gate PASS.
