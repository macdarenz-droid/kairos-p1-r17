import { readFileSync } from 'node:fs';
const source=readFileSync('src/application/visual-pnl/progressSeries.ts','utf8');
const index=readFileSync('src/application/visual-pnl/index.ts','utf8');
const tests=readFileSync('tests/visual-pnl-progress-series.test.ts','utf8');
for(const required of ['projectVisualPnlProgressSeries','no-result-days','unavailable-result-day','mixed-currencies','day.summary.total','day.summary.currency']) if(!source.includes(required)) throw new Error(`P13.17 contract missing: ${required}`);
if(!index.includes("export * from './progressSeries'")) throw new Error('P13.17 export missing');
for(const required of ['without accumulation','daily result is unavailable','mixed currencies']) if(!tests.includes(required)) throw new Error(`P13.17 test evidence missing: ${required}`);
for(const forbidden of ['Number(','parseFloat(','parseInt(','new Decimal','Intl.','new Date(','indexedDB','Dexie','localStorage','sessionStorage','exchangeRate','Math.','+=','-=']) if(source.includes(forbidden)) throw new Error(`P13.17 arithmetic/ownership violation: ${forbidden}`);
console.log('PASS P13.17 Visual P&L progress-series semantics verifier');
