import type {
  DecimalString,
  TradeExecutionRecord,
  TradeFeeRecord,
  TradeSide,
} from '../trades';
import { assessExecutionBalance } from './executionBalance';
import { calculateFlatTradeGrossRealizedPnl } from './grossRealizedPnl';
import { calculateRiskPerformance } from './riskPerformanceCalculator';
import { calculateTotalFees } from './feeCalculator';

export type TradeMetricsState =
  | 'unrealized'
  | 'partially-realized'
  | 'realized';

export interface TradeMetricsCompleteness {
  readonly hasEntryExecutions: boolean;
  readonly hasExitExecutions: boolean;
  readonly hasAverageEntryPrice: boolean;
  readonly hasAverageExitPrice: boolean;
  readonly hasGrossPnl: boolean;
  readonly hasTotalFees: boolean;
  readonly hasNetPnl: false;
  readonly hasPnlPercent: false;
  readonly hasInitialRisk: boolean;
  readonly hasRealizedR: boolean;
}

export interface TradeMetricsRiskPerformanceInput {
  readonly resultAmount: DecimalString;
  readonly riskPerUnit: DecimalString;
  readonly quantity: DecimalString;
}

export interface TradeMetrics {
  readonly grossPnl: DecimalString | null;
  readonly totalFees: DecimalString | null;
  readonly totalFeesCurrency: string | null;
  readonly netPnl: null;
  readonly pnlPercent: null;
  readonly initialRisk: DecimalString | null;
  readonly realizedR: DecimalString | null;
  readonly averageEntryPrice: DecimalString | null;
  readonly averageExitPrice: DecimalString | null;
  readonly totalEnteredQuantity: DecimalString;
  readonly totalExitedQuantity: DecimalString;
  readonly remainingQuantity: DecimalString;
  readonly state: TradeMetricsState | null;
  readonly completeness: TradeMetricsCompleteness;
}

export type TradeMetricsResult =
  | { readonly ok: true; readonly value: TradeMetrics }
  | {
      readonly ok: false;
      readonly reason:
        | 'invalid-execution-decimal'
        | 'exit-without-entry'
        | 'over-exited'
        | 'invalid-risk-performance-decimal'
        | 'zero-initial-risk'
        | 'invalid-fee-decimal'
        | 'mixed-fee-currency';
    };

function toMetricsState(
  balanceState: 'empty' | 'open' | 'partially-exited' | 'flat',
): TradeMetricsState | null {
  if (balanceState === 'empty') return null;
  if (balanceState === 'open') return 'unrealized';
  if (balanceState === 'partially-exited') return 'partially-realized';
  return 'realized';
}

export function calculateTradeMetrics(
  side: TradeSide,
  executions: readonly TradeExecutionRecord[],
  riskPerformanceInput?: TradeMetricsRiskPerformanceInput,
  fees?: readonly TradeFeeRecord[],
): TradeMetricsResult {
  const balance = assessExecutionBalance(executions);
  if (!balance.ok) {
    return { ok: false, reason: balance.reason };
  }

  const grossPnlResult = calculateFlatTradeGrossRealizedPnl(side, executions);
  if (!grossPnlResult.ok) {
    return { ok: false, reason: grossPnlResult.reason };
  }

  const { entry, exit, netQuantity } = balance.aggregate;
  const grossPnl = grossPnlResult.available
    ? grossPnlResult.grossRealizedPnl
    : null;

  const riskPerformance = riskPerformanceInput
    ? calculateRiskPerformance(
        riskPerformanceInput.resultAmount,
        riskPerformanceInput.riskPerUnit,
        riskPerformanceInput.quantity,
      )
    : null;

  if (riskPerformance && !riskPerformance.ok) {
    return {
      ok: false,
      reason: riskPerformance.reason === 'zero-initial-risk'
        ? 'zero-initial-risk'
        : 'invalid-risk-performance-decimal',
    };
  }

  const initialRisk = riskPerformance?.initialRisk ?? null;
  const realizedR = riskPerformance?.realizedR ?? null;

  const feeResult = fees === undefined
    ? null
    : calculateTotalFees(fees);

  if (feeResult && !feeResult.ok) {
    return {
      ok: false,
      reason: feeResult.reason === 'mixed-currency'
        ? 'mixed-fee-currency'
        : 'invalid-fee-decimal',
    };
  }

  const totalFees = feeResult?.totalFees ?? null;
  const totalFeesCurrency = feeResult?.currency ?? null;

  return {
    ok: true,
    value: Object.freeze({
      grossPnl,
      totalFees,
      totalFeesCurrency,
      netPnl: null,
      pnlPercent: null,
      initialRisk,
      realizedR,
      averageEntryPrice: entry.weightedAveragePrice,
      averageExitPrice: exit.weightedAveragePrice,
      totalEnteredQuantity: entry.quantity,
      totalExitedQuantity: exit.quantity,
      remainingQuantity: netQuantity,
      state: toMetricsState(balance.state),
      completeness: Object.freeze({
        hasEntryExecutions: entry.quantity !== '0',
        hasExitExecutions: exit.quantity !== '0',
        hasAverageEntryPrice: entry.weightedAveragePrice !== null,
        hasAverageExitPrice: exit.weightedAveragePrice !== null,
        hasGrossPnl: grossPnl !== null,
        hasTotalFees: totalFees !== null,
        hasNetPnl: false,
        hasPnlPercent: false,
        hasInitialRisk: initialRisk !== null,
        hasRealizedR: realizedR !== null,
      }),
    }),
  };
}
