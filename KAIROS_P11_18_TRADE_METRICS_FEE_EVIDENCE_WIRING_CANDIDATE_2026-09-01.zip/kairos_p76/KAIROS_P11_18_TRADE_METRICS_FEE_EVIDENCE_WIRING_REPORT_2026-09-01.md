# KAIROS P11.18 TradeMetrics Fee Evidence Wiring Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Authoritative base
P11.17R1 PASS, gate run #39, artifact 9798935833.

## Objective
Wire authoritative fee evidence into TradeMetrics without crossing the unresolved gross-P&L currency boundary.

## Contract
- Omitted fee evidence -> `totalFees: null`, `totalFeesCurrency: null`, `hasTotalFees: false`.
- Explicit empty fee evidence -> `totalFees: "0"`, `totalFeesCurrency: null`, `hasTotalFees: true`.
- Same-currency fees -> exact decimal total plus authoritative currency.
- Mixed currencies -> explicit `mixed-fee-currency` failure.
- Malformed fee decimals -> explicit `invalid-fee-decimal` failure.
- `netPnl` remains null and incomplete.

## Why net P&L remains unwired
Gross realized P&L evidence still has no authoritative currency dimension. P11.16 requires gross P&L and fees to be proven comparable before subtraction. This patch does not invent that proof and performs no FX conversion.

## Non-scope
No net-P&L composition, no FX conversion, no percentage wiring, no realized-R semantic change, no persistence/schema/UI/network work.
