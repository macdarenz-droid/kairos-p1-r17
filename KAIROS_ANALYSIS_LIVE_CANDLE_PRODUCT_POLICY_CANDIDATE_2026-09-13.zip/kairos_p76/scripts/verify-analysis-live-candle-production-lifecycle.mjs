import { existsSync, readFileSync } from 'node:fs';

const sourcePath = 'src/app/binanceAnalysisLiveCandleProductionLifecycle.ts';
const testPath = 'tests/binance-analysis-live-candle-production-lifecycle.test.ts';
for (const file of [sourcePath, testPath]) if (!existsSync(file)) throw new Error(`missing-production-lifecycle:${file}`);
const source = readFileSync(sourcePath, 'utf8');
const test = readFileSync(testPath, 'utf8');

for (const token of [
  'createBinanceAnalysisLiveCandleProductionLifecycle',
  'dependencies.history ?? analysisHistoryPorts.history',
  'createBinanceAnalysisSelectedLiveCandleSessionController(',
  'createBinanceAnalysisHistoryLiveCandleBootstrapCoordinator(',
  'createBinanceAnalysisLiveCandleGapBackfillRecoveryCoordinator(bootstrap)',
  'createBinanceAnalysisLiveCandleBrowserAvailabilityLifecycle(',
]) if (!source.includes(token)) throw new Error(`missing-production-lifecycle-token:${token}`);

for (const token of [
  'uses authoritative history then starts the released live session from its final candle',
  'forwards caller-owned policy, renderer and state callbacks without inventing defaults',
  'stops live ownership while hidden and reacquires authoritative history before resume',
  'routes a candle gap through authoritative history recovery and coalesces duplicates',
  'closes the assembled lifecycle and removes browser listeners idempotently',
]) if (!test.includes(token)) throw new Error(`missing-production-lifecycle-evidence:${token}`);

for (const forbidden of [
  'new WebSocket', 'fetch(', 'indexedDB', 'localStorage', 'Dexie', 'setTimeout(',
  'setInterval(', 'Math.random(', 'Date.now(', 'initialDelayMs:', 'maxDelayMs:',
  'maxAttempts:', 'createTrade', 'updateTrade', 'calculateTrade', 'createSeriesMarkers',
  'AnalysisRoute', 'AnalysisHistoryWorkspace', 'useEffect', 'useState',
]) if (source.includes(forbidden)) throw new Error(`production-lifecycle-ownership-violation:${forbidden}`);

console.log('Analysis live candle production lifecycle verifier PASS');
