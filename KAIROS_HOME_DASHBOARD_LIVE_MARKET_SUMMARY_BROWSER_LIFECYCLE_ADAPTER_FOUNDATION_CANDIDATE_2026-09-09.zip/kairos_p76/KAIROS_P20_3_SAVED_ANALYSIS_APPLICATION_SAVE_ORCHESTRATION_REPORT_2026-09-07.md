# KAIROS P20.3 — Saved Analysis Application Save Orchestration

## Authority
Base: canonical P20.2 — Saved Analysis Persistence Foundation, canonical gate #282 / run `34040888312`.

## Responsibility
P20.3 adds exactly one application-layer save use case above the P20.1 logical contract and P20.2 raw repository boundary.

The application command:
- accepts the existing provider-neutral Saved Analysis logical fields without an id;
- allocates the fresh id only through `createSavedAnalysisId`;
- persists through the existing `SavedAnalysisRepository` inside the current atomic database transaction boundary;
- returns explicit success with the authoritative Saved Analysis id;
- converts storage failure into the explicit `saved-analysis-save-failed` result.

## Preserved ownership
P20.1 remains owner of Saved Analysis logical truth and Saved Analysis identity.
P20.2 remains owner of DB V4, SavedAnalysisRepository, backup/restore, migrations, current-store authority and raw persistence.

## Explicit non-scope
No UI, route or dashboard work.
No list/load/delete orchestration.
No DB/schema/migration/backup changes.
No provider or Lightweight Charts state.
No pixel geometry.
No invented name, timeframe, timestamps or optional metadata.
No secondary indexes/query APIs.
No changes to P17/P18/P19 semantics.

## Verification intent
Focused application-save tests cover success, explicit storage failure, authoritative id propagation and clone-safe preservation of caller-owned logical input. The dedicated P20.3 verifier enforces the owner/non-scope boundary. Full canonical authority still requires the normal Kairos Controlled Roadmap Gate.
