# Binance Spot Exchange Info Public REST Request Descriptor Foundation

## Authority
Base: canonical Live Market Universe Instrument Metadata Fact Contract Foundation, `Kairos Controlled Roadmap Gate` #313 / run `34192273207`.

## Responsibility
The canonical universe-metadata fact now defines provider-neutral `baseAsset`, `quoteAsset`, and current `tradingEnabled` truth, but deliberately owns no Binance HTTP. Existing Kairos Binance REST architecture starts provider acquisition with a pure request-description seam before execution, decode, mapping and concrete browser transport. Current official Binance Spot documentation identifies `GET /api/v3/exchangeInfo` as a public exchange-information endpoint and permits `https://data-api.binance.vision` for public market-data endpoints.

This slice therefore describes only one public Binance Spot request: `GET https://data-api.binance.vision/api/v3/exchangeInfo`. It intentionally supplies no symbol filter so provider metadata discovery does not become Live Crypto universe policy.

## Explicit non-scope
- No fetch/XHR/WebSocket/browser transport or request execution.
- No JSON parsing, exchangeInfo response decoding, or metadata mapping.
- No mapping to `LiveMarketUniverseInstrumentMetadataFact`.
- No caching, refresh cadence, polling, retry, backoff, request-weight or rate-limit policy.
- No USDT eligibility filtering, stablecoin exclusion, ranking, sorting, tie-break or Top-N policy.
- No freshness changes, Home React wiring, stale presentation or Bubble rendering.
- No Your Trades/journal, persistence/IndexedDB, Saved Analysis, chart/navigation or transition ownership.
