# Binance Spot Exchange Information Instrument Metadata Fact Collection Mapping Foundation

## Authority
Base: canonical Binance Spot Exchange Information Instrument Metadata Fact Mapping Foundation, `Kairos Controlled Roadmap Gate` #317 / run `34226750711`.

Canonical #317 owns semantic mapping for exactly one already-decoded exchangeInfo symbol object into one validated provider-neutral `LiveMarketUniverseInstrumentMetadataFact`. Its released follow-on boundary explicitly leaves mapping of an explicitly supplied decoded exchangeInfo symbol collection to a later provider composition.

## Responsibility
This slice introduces exactly one Binance-provider collection composition. It accepts only one explicitly supplied decoded symbol collection, requires that value to be an array, maps each entry only through the released `mapBinanceSpotExchangeInfoInstrumentMetadataFact(...)` owner, preserves the exact caller-supplied collection sequence, and returns the resulting provider-neutral facts.

The composition accepts an explicitly supplied empty array and returns an empty fact list rather than inventing exchange completeness or universe policy. If an entry is invalid, it stops deterministically at the first invalid entry and returns that exact zero-based index plus the released one-entry mapper reason. It does not skip invalid entries or reinterpret provider semantics.

This composition does not own the outer exchangeInfo response object or its `symbols` property. Extraction of a collection from a whole decoded response remains a separate responsibility.

## Explicit non-scope
- No HTTP request descriptor/execution, fetch/XHR/WebSocket/browser transport, `Response`, status/header/body acquisition, or JSON parsing.
- No whole exchangeInfo response-object interpretation and no `.symbols` extraction.
- No new one-entry symbol/status/baseAsset/quoteAsset semantic validation; all entry semantics delegate to the released #317 mapper.
- No USDT eligibility filtering or symbol-suffix inference.
- No stablecoin exclusion.
- No 24h quote-volume lookup, ranking/sorting, symbol tie-break, Top-N/Top-30, popularity, or market-cap logic.
- No deduplication, grouping, default scope, exchange completeness, or missing-symbol policy.
- No metadata cache, polling, refresh, retry, backoff, rate-limit or request-weight policy.
- No freshness-age/classification changes, evaluation-time ownership, stale/expired eviction, or visible-dashboard cadence.
- No Home React wiring, Bubble Map geometry/size/color/grouping/interactions/animation, or presentation state.
- No Your Trades/journal ownership, persistence/IndexedDB, Saved Analysis, chart, navigation, or transition ownership.

## Follow-on boundary
A later separate provider composition may validate/extract the `symbols` collection from one whole already-decoded exchangeInfo response object and delegate that collection unchanged to this released collection mapper. Only after authoritative metadata facts exist should a separate deterministic universe-policy owner combine metadata with released 24h summary facts to implement the user-approved active-USDT/stablecoin-exclusion/quote-volume-ranking/Top-30 policy.
