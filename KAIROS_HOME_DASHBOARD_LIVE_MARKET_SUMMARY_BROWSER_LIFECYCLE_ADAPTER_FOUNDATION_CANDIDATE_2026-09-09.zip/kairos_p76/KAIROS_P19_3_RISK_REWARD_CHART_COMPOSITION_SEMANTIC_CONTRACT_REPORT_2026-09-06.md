# KAIROS P19.3 — Risk/Reward Chart Composition Semantic Contract

## Authority
Base: canonical P19.2 Risk/Reward Zone Semantics Projection, `Kairos Controlled Roadmap Gate` run #275 / `34012163133`.

## Scope
Adds one provider-neutral P19-owned chart-composition semantic projection. It preserves the Risk/Reward analysis identity and side, exposes three semantic price levels (`entry`, `stop`, `target`), and composes the already-authoritative P19.2 semantic zones (`risk`, `reward`) into one immutable RR-specific chart semantic model.

Semantic roles only are owned here. P2/P3 remain styling/token/color owners.

## Non-scope
No ratio/R math, price-order or side validation, price normalization, chart timestamp/span/screen geometry, provider or Lightweight Charts APIs, P18 `ChartDrawing` widening, DOM/UI/tool controls, edit/drag/delete lifecycle, P20 persistence, P14 journal/execution writes, hard-coded visual colors, or P11 calculation duplication.
