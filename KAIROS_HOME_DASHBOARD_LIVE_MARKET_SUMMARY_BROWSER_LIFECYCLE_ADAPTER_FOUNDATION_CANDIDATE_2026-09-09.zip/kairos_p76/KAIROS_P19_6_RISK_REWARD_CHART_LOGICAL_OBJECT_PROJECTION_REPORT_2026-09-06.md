# KAIROS P19.6 — Risk/Reward Chart Logical Object Projection

## Authority
Base: canonical P19.5 Risk/Reward Chart Logical Placement Projection, `Kairos Controlled Roadmap Gate` run #278 / `34016854057`.

## Scope
Adds one P19-owned app-boundary provider-neutral logical chart-object projection. Entry/stop/target become horizontal logical spans using canonical P19 semantic prices, P19.4 semantic style references, and P19.5 logical start/end. Risk/reward become logical rectangles using the same logical extent and canonical semantic zone bounds.

## Ownership
P19 owns Risk/Reward meaning and logical composition. P18 remains generic chart drawing/provider infrastructure. P11 retains calculation ownership, P14 retains journal/execution truth, P20 retains later Saved Analysis persistence, and P2/P3 retain semantic token values.

## Non-scope
No provider/Lightweight Charts production APIs, renderer-number conversion, pixels/screen geometry, P18 contract widening, DOM/UI/CSS, interaction/editing, P20 persistence, P14 mutation, P11 math duplication, timestamp/price normalization or order validation, hard-coded colors, or duplicate semantic/style/placement ownership.
