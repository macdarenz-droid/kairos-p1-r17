# KAIROS P21.9 — Binance Spot 24h Public REST Baseline Response Decode Foundation

## Authority
Base: canonical P21.8 Binance Spot 24h Public REST Baseline Request Execution Boundary Foundation, `Kairos Controlled Roadmap Gate` #293 / run `34087112414`.

## Source-proven responsibility
P21.8 owns only an injected generic execution seam and deliberately leaves response representation outside its ownership. P21.6 already owns semantic composition from an already-decoded one-or-many Binance Spot 24h ticker payload. Released P16.4→P16.5 architecture establishes the corresponding smallest framing seam between an injected provider execution boundary and later provider semantic mapping: JSON text decoding only.

Current official Binance Spot REST documentation identifies the `/api/v3/ticker/24hr` response examples as JSON / `application/json`. P21.9 therefore owns only deterministic JSON-text decoding into `unknown`; it does not validate ticker semantics or decide single-vs-multiple scope completeness.

## Explicit non-scope
- No fetch/XHR/WebSocket/browser transport and no concrete `Response`/HTTP status/body acquisition semantics.
- No provider ticker-field validation, P21.5 fact mapping, or P21.6 complete-for-scope delivery composition.
- No scope/universe selection, descriptor construction/mutation, batching/chunking, request-weight accounting, throttling, rate-limit/backoff/retry, credentials, polling or reconnect policy.
- No concrete P21.4 acquisition-port adapter orchestration.
- No accumulator/state/order/freshness/reset ownership; decoded array order is not ranking/universe truth.
- No Bubble Map sizing/color/grouping/filtering/geometry/interactions or Home wiring.
- No persistence, journal/Your-Trades semantics, direct IndexedDB UI access, or dashboard transitions.
