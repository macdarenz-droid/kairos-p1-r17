# KAIROS — Live Market Universe Instrument Eligibility Policy Foundation

## Authority
Base: exact canonical Gate #325 Binance Spot exchangeInfo Browser Instrument Metadata Acquisition Binding Foundation, run `34289145300`.

## Source-proven responsibility
Released `LiveMarketUniverseInstrumentMetadataFact` carries authoritative `instrument`, `baseAsset`, `quoteAsset`, and `tradingEnabled` truth specifically for later caller-owned universe policy. Canonical exchangeInfo acquisition layers deliberately exclude USDT eligibility and stablecoin exclusion. The user-approved Live Crypto V1 contract requires actively tradable Binance Spot instruments quoted in USDT with an explicit configurable stablecoin-exclusion set.

## Contract
- Consume only a released `LiveMarketUniverseInstrumentMetadataFact` plus caller-owned policy options.
- Eligible requires `tradingEnabled === true`.
- Eligible requires exact authoritative `quoteAsset === 'USDT'`.
- Eligible requires the authoritative `baseAsset` not be present in the explicit caller-configured `excludedStablecoinBaseAssets` set.
- Return a deterministic boolean only; do not mutate facts or configuration.

## Explicit non-scope
- No 24h quote-volume ranking or sorting.
- No equal-volume symbol tie-break.
- No Top-N or Top-30 selection/limiting.
- No market-summary joins, provider requests, transport, decode or mapping.
- No observedAt/freshness thresholds, cadence, polling, visibility/resume/session lifecycle or state.
- No persistence, Home/Live Crypto Bubble Map UI, Your Trades/journal, chart, navigation or transitions.
