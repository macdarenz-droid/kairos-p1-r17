# KAIROS P21.15 — Binance Spot 24h Browser Public REST Baseline Acquisition Binding Foundation

## Authority
Base: canonical P21.14 browser public REST baseline connector, canonical gate #299 / run `34118010684`.

## Source-proven responsibility
Canonical P21.13 implements the provider-neutral P21.4 baseline acquisition port but deliberately receives its P21.8 connector from the caller. Canonical P21.14 supplies the missing concrete browser P21.8 connector but deliberately does not compose or own acquisition. Existing P16.16 demonstrates the released project pattern for a narrow browser-ready provider entry point that composes an already-released concrete browser connector with an already-released provider application seam while keeping clocks and lifecycle policy injected. Therefore the smallest dependency-safe next responsibility is one browser-ready P21.13/P21.14 binding, with observation time still caller-owned.

## Contract
- Export one factory returning the existing `LiveMarketSummaryBaselineAcquisitionPort`.
- Compose only released `createBinanceSpot24hPublicRestBaselineAcquisitionPort` with released `connectBinanceSpot24hBrowserPublicRestBaselineRequest`.
- Keep `readObservedAt` mandatory and externally supplied; this binding reads no clock itself.
- Preserve P21.4 caller cancellation and all P21.13/P21.14 result/rejection behavior unchanged.
- Add no second request, transport, decode, validation, completeness, state, or UI owner.

## Explicit non-scope
- No endpoint/path/query/symbol-selection policy and no additional fetch/XHR/WebSocket transport.
- No HTTP status/header interpretation, response taxonomy, retry/backoff/throttle/rate-limit/request-weight, credentials/auth, timeout or AbortController policy.
- No `Date.now`, `new Date`, observation-time acquisition, freshness TTL, polling, reconnect, scheduling or randomness.
- No JSON/provider payload decode, ticker validation, completeness or acquisition validation changes.
- No universe/ranking/batching/chunking, market state accumulator, persistence or direct IndexedDB access.
- No Live Crypto Bubble Map sizing/color/grouping/filtering/geometry/Home wiring.
- No Your Trades Bubble Map, journal reads, Saved Analysis or dashboard transitions.
