# KAIROS — Binance Spot exchangeInfo Browser Instrument Metadata Acquisition Binding Foundation

## Authority
Base: canonical Gate #324 Binance Spot exchangeInfo Browser Public REST Connector Foundation, run `34279358453`.

## Source-proven responsibility
Gate #323 owns the Binance Spot implementation of the provider-neutral instrument metadata acquisition port but deliberately receives its exchangeInfo request connector from the caller. Gate #324 owns the concrete browser connector but deliberately does not compose acquisition. The released P21.15 24h browser acquisition binding establishes the dependency direction for one narrow browser-ready provider entry point. Therefore the smallest dependency-safe next responsibility is composition only: bind the released Gate #323 acquisition adapter to the released Gate #324 browser connector.

## Contract
- Export one factory returning the existing `LiveMarketUniverseInstrumentMetadataAcquisitionPort`.
- Compose only `createBinanceSpotExchangeInfoInstrumentMetadataAcquisitionPort` with `connectBinanceSpotExchangeInfoBrowserPublicRestRequest`.
- Preserve optional caller-owned `AbortSignal` forwarding through the existing port/adapter/connector chain.
- Preserve successful authoritative metadata facts and the existing single `acquisition-failed` result unchanged.
- Add no new network, provider decode/mapping, universe, freshness, state, persistence, or UI owner.

## Explicit non-scope
- No endpoint/path/query ownership, additional fetch/XHR/WebSocket transport, HTTP status/header/error taxonomy, credentials, timeout, retry/backoff/rate/request-weight policy.
- No JSON decode, exchangeInfo response mapping, symbol fact mapping, or provider validation changes.
- No USDT eligibility, stablecoin exclusion, 24h quote-volume ranking, symbol tie-break, Top 30, batching, or universe policy.
- No observedAt/freshness thresholds, 5-second cadence, visibility/resume/session lifecycle, cache, accumulator, state, or persistence.
- No Home/Live Crypto Bubble Map UI and no Your Trades/journal/Saved Analysis/chart/navigation/transitions.
