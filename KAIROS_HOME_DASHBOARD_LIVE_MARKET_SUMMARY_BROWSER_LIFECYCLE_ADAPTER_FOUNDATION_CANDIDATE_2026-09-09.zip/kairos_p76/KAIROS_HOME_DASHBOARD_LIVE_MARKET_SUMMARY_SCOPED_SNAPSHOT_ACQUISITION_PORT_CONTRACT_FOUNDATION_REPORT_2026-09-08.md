# Home Dashboard Live Market Summary Scoped Snapshot Acquisition Port Contract Foundation

## Authority
Base: exact canonical P21.23 candidate promoted by `Kairos Controlled Roadmap Gate` #308 / run `34166273061`.

## Source-proven responsibility
Released P21.23 is provider-specific under the Binance market-data owner. Released Home remains presentation-only and has no dashboard insights connected. No application-facing Home/dashboard market-data acquisition seam exists. The smallest dependency-safe next responsibility is therefore a provider-neutral port contract outside React presentation.

## Contract
- Accept explicit caller-owned `readonly MarketDataInstrument[]` scope.
- Accept optional caller-owned cancellation compatible with released `signal?: AbortSignal` semantics.
- Return a Promise of only released provider-neutral `LiveMarketSummaryBaselineStateOrchestrationResult` plus released `readonly LiveMarketSummaryScopedStateSnapshotEntry[]` truth.
- Choose no provider, session, transport, universe, default scope, clock, ranking, freshness, retry, persistence, subscription, Bubble presentation, UI state, or transition behavior.

## Explicit non-scope
No Binance/provider adapter; no Home React wiring/hooks/effects/UI state; no default universe/scope; no ranking/filtering/grouping/sorting/top-N/popularity/market-cap; no Bubble sizing/color/geometry/interactions/animation; no Your Trades/journal ownership; no caller clock/readObservedAt construction; no freshness/TTL/polling/reconnect/scheduling/background work; no provider transport/error/retry/rate-limit/timeout policy; no new cancellation/concurrency/coalescing/subscription framework; no persistence/IndexedDB/Saved Analysis/chart/navigation/transition ownership; no reinterpretation of released P21 semantics.
