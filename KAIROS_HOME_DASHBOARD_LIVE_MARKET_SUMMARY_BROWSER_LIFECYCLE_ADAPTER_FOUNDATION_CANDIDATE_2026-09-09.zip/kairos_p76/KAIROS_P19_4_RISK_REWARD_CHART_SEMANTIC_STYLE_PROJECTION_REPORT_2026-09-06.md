# KAIROS P19.4 — Risk/Reward Chart Semantic Style Projection

## Authority
Base: canonical P19.3 Risk/Reward Chart Composition Semantic Contract, `Kairos Controlled Roadmap Gate` run #276 / `34013463627`.

## Scope
Adds one presentation-boundary projection in `src/app` that maps the five P19.3 Risk/Reward semantic roles (`entry`, `stop`, `target`, `risk`, `reward`) to the existing P2/P3 semantic trade-token CSS-variable references. It does not own token values and does not change Risk/Reward business semantics.

## Ownership
P19 application semantics remain presentation-agnostic. P2/P3 remain semantic token/theme value owners. P17/P18 remain generic provider/drawing infrastructure. The app layer composes P19 semantics with existing design-system token references without reversing dependencies.

## Non-scope
No ratio/R or price math, price normalization, chart timestamp/span/screen geometry, provider or Lightweight Charts production APIs, P18 `ChartDrawing` widening, DOM/UI component/CSS work, edit/drag/delete lifecycle, P20 persistence, P14 journal/execution mutation, P11 calculation duplication, or hard-coded visual colors.
