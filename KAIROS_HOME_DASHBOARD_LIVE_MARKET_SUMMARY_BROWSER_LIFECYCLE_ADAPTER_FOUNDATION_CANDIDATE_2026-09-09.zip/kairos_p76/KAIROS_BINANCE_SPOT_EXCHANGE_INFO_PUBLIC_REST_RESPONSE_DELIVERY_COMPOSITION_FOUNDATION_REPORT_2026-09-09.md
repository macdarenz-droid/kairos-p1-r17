# Binance Spot exchangeInfo Public REST Response Delivery Composition Foundation

## Canonical base
Exact latest GOLDEN: Binance Spot Exchange Information Instrument Metadata Fact Response Mapping Foundation via `Kairos Controlled Roadmap Gate` #319 / run `34234539616` / job `102088750010` / head `fde4243efc2a00cac82c300e1a9311259cb8927a`.

## Source-proven responsibility
This slice composes exactly two already-released owners for one already-received response-data value: `decodeBinanceSpotExchangeInfoPublicRestResponse(data)` followed, only on decode success, by `mapBinanceSpotExchangeInfoInstrumentMetadataFactResponse(decoded.payload)`. Decode failures are returned unchanged. The decoded payload is forwarded unchanged to the released whole-response mapper.

## Explicit non-scope
- No request descriptor or request execution ownership.
- No connector, fetch/XHR/WebSocket/browser transport, HTTP status/header/body acquisition, or `Response` ownership.
- No full REST round-trip orchestration.
- No new exchangeInfo symbol-field interpretation or metadata-fact mapping algorithm.
- No USDT filtering, stablecoin exclusion, universe selection, quote-volume ranking, symbol tie-break, or Top-N policy.
- No cache, polling, retry/backoff, request-weight, rate-limit, freshness or cadence policy.
- No Home/Bubble UI, Your Trades, journal, persistence, chart, navigation, or transitions.
