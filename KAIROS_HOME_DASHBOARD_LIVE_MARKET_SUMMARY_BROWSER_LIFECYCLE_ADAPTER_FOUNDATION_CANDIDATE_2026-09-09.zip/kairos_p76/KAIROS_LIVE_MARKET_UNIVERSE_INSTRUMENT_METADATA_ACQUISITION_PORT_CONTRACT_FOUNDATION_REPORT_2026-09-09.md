# KAIROS — Live Market Universe Instrument Metadata Acquisition Port Contract Foundation

## Authority
Base: canonical Gate #321 Binance Spot Exchange Information Public REST Round Trip Composition Foundation.

## Responsibility
Introduce only the missing provider-neutral application-facing acquisition port for authoritative `LiveMarketUniverseInstrumentMetadataFact` values, following the released P21.4 acquisition-port convention: async port, explicit `acquisition-failed`, and optional caller-owned cancellation.

## Contract
- `acquireInstrumentMetadata(options)` acquires authoritative metadata facts without choosing a product universe.
- Success carries only released `LiveMarketUniverseInstrumentMetadataFact` values.
- Failure is explicit as `acquisition-failed`.
- Optional `AbortSignal` is caller-owned cancellation only.

## Explicit non-scope
- No Binance adapter, exchangeInfo call, concrete transport, HTTP semantics, retry/backoff/rate policy.
- No cache, polling, resume, visibility, cadence, or freshness policy.
- No USDT eligibility, stablecoin exclusion, quote-volume ranking, symbol tie-break, or Top-N policy.
- No Home/Bubble UI, Your Trades, journal, persistence, chart, navigation, or transitions.
