# KAIROS P21.14 — Binance Spot 24h Browser Public REST Baseline Connector Foundation

## Authority
Base: canonical P21.13 acquisition adapter, canonical gate #298 / run `34114301112`.

## Source-proven responsibility
Canonical P21.8 deliberately leaves network execution behind an injected connector. Canonical P21.13 now composes the P21.4 acquisition port onto the released Binance round-trip but still requires that connector from its caller. Existing P16.12 establishes the project pattern that concrete browser transport is a narrow provider adapter separate from provider semantics and lifecycle policy. Official Binance Spot REST documentation states that public market-data APIs may use `https://data-api.binance.vision`, while released P21.7 already owns the exact public GET URL/query descriptor. Therefore the smallest missing runtime seam is one concrete browser connector that executes exactly one already-described P21.7 request and returns response body text to the released P21.9 decoder.

## Contract
- Accept the released P21.7 request descriptor through the existing P21.8 connector type.
- Perform exactly one `globalThis.fetch(request.url, { method: request.method, signal: options?.signal })` call.
- Forward the exact caller-owned P21.12 `AbortSignal` without creating, combining, timing, or interpreting cancellation.
- Read `Response.text()` exactly once and return that string unchanged for released P21.9 JSON-text decoding.
- Native fetch/text rejection propagates unchanged so released P21.13 alone maps connector rejection to existing P21.4 `acquisition-failed`.
- Do not inspect HTTP status/headers or create response/error taxonomy in this slice.

## Explicit non-scope
- No endpoint/path/query/symbol-selection policy beyond the released P21.7 descriptor.
- No HTTP status/header interpretation, retry-after handling, response error taxonomy, credentials, authentication, custom headers, cache policy, redirect policy, timeout, AbortController, signal combination, retry/backoff/throttle/rate-limit/request-weight/polling/reconnect.
- No JSON/provider payload decode, ticker validation, completeness, acquisition validation, observation-time, clock/freshness, universe/ranking/batching/state/persistence.
- No Live Crypto Bubble Map sizing/color/grouping/filtering/geometry/Home wiring.
- No Your Trades Bubble Map, journal reads, Saved Analysis, direct IndexedDB UI access or dashboard transitions.
