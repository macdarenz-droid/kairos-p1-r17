# KAIROS P19.2 — Risk/Reward Zone Semantics Projection

## Authority
Base: canonical P19.1 Risk/Reward Analysis Semantic Contract Foundation, `Kairos Controlled Roadmap Gate` run #274 / `34010682979`.

## Scope
Adds one provider-neutral P19-owned semantic projection from a Risk/Reward analysis into exactly two immutable price-bound zones:
- `risk`: entry to stop
- `reward`: entry to target

Zone roles are semantic only. P2/P3 remain styling/color owners.

## Non-scope
No ratio/R math, price-order or side validation, price normalization, chart-time/span geometry, rendering/provider API, P18 `ChartDrawing` expansion, editing lifecycle, P20 persistence, P14 journal/execution writes, or hard-coded visual colors.
