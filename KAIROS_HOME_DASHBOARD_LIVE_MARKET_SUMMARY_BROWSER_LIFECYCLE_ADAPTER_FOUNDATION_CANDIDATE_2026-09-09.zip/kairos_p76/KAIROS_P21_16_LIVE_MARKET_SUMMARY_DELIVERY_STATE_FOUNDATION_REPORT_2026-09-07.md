# KAIROS P21.16 — Live Market Summary Delivery State Foundation

## Authority
Base: canonical P21.15 browser public REST baseline acquisition binding, canonical gate #300 / run `34123121667`.

## Source-proven responsibility
Canonical P21.3 defines explicit provider-neutral live-market summary delivery completeness (`incremental` versus `complete-for-scope`) but explicitly owns no accumulator/state store. Canonical P21.4-P21.15 progressively establish baseline acquisition and the browser-ready Binance binding while repeatedly preserving state, freshness, universe, ranking, and UI as non-scope. Exact canonical P21.15 package inspection shows no production `LiveMarketSummary` state/accumulator owner or consumer. The smallest dependency-safe next responsibility is therefore one provider-neutral state reducer for already-received P21.3 deliveries, without selecting scope or acquiring data.

## Contract
- Define one provider-neutral current-summary state keyed solely by normalized instrument identity.
- Validate every incoming delivery through released `validateLiveMarketSummaryDelivery` before state mutation.
- `incremental` delivery: upsert only delivered instrument facts; preserve all unrelated state.
- `complete-for-scope` delivery: replace only facts for that delivery's explicit scope; preserve all facts outside that scope.
- Invalid delivery: return explicit `delivery-invalid` and the exact prior state unchanged.
- Apply deliveries synchronously in caller delivery order. Do not compare timestamps or infer freshness.
- Map iteration/insertion order is storage detail only and is never ranking, grouping, or presentation truth.

## Explicit non-scope
- No market-universe/scope selection, ranking, filtering, grouping, sorting, bubble metric, color, geometry, interaction, or Home wiring.
- No baseline acquisition call, Binance/provider mapping, fetch/XHR/WebSocket/Response ownership, endpoint/query/status/header/error/retry/rate-limit/credentials/timeout policy.
- No clock/`Date`, timestamp arbitration, freshness TTL, stale eviction, polling, reconnect, scheduling, or event-order policy beyond applying the delivery the caller supplies now.
- No persistence, schema, repository, backup, direct IndexedDB, journal, Your Trades Bubble Map, Saved Analysis, chart, or transition ownership.
