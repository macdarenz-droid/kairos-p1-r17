# Binance Spot Exchange Information Instrument Metadata Fact Mapping Foundation

## Authority
Base: canonical Binance Spot Exchange Information Public REST Response Decode Foundation, `Kairos Controlled Roadmap Gate` #316 / run `34221724357`.

The released provider-neutral `LiveMarketUniverseInstrumentMetadataFact` already owns instrument identity, base asset, quote asset, and current trading-enabled truth. Canonical #316 owns JSON-text response decoding only and explicitly leaves exchangeInfo semantic interpretation and metadata-fact mapping to a later provider responsibility.

## Responsibility
This slice introduces exactly one Binance-provider semantic mapper for one already-decoded exchangeInfo symbol object. It validates provider `symbol`, `status`, `baseAsset`, and `quoteAsset` representation, maps the released Binance Spot venue plus those asset identities into one `LiveMarketUniverseInstrumentMetadataFact`, maps exact Binance `TRADING` status to `tradingEnabled: true`, maps any other non-empty provider status to `tradingEnabled: false`, and delegates final provider-neutral validation to the released metadata-fact validator.

The mapper does not own the outer exchangeInfo `symbols[]` collection. It therefore cannot select a market universe, infer default scope, or rank/filter instruments.

## Explicit non-scope
- No HTTP request descriptor/execution, fetch/XHR/WebSocket/browser transport, `Response`, status/header/body acquisition, or JSON parsing.
- No whole-response or `symbols[]` traversal/composition; one decoded symbol object only.
- No USDT eligibility filtering or symbol-suffix inference.
- No stablecoin exclusion.
- No 24h quote-volume lookup, ranking/sorting, symbol tie-break, Top-N/Top-30, popularity, or market-cap logic.
- No metadata cache, polling, refresh, retry, backoff, rate-limit or request-weight policy.
- No freshness-age/classification changes, evaluation-time ownership, stale/expired eviction, or visible-dashboard cadence.
- No Home React wiring, Bubble Map geometry/size/color/grouping/interactions/animation, or presentation state.
- No Your Trades/journal ownership, persistence/IndexedDB, Saved Analysis, chart, navigation, or transition ownership.

## Follow-on boundary
A later separate provider composition may map an explicitly supplied decoded exchangeInfo symbol collection into metadata facts. Only after authoritative metadata facts exist should a separate deterministic universe-policy owner combine metadata with released 24h summary facts to implement the user-approved active-USDT/stablecoin-exclusion/quote-volume-ranking/Top-30 policy.
