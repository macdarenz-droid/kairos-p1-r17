# KAIROS P21.2 — Live Market Summary Fact Contract Foundation

## Authority
Base: canonical P21.1 Home Dashboard Route Ownership Foundation, `Kairos Controlled Roadmap Gate` #286 / run `34061840453`.

## Source-backed responsibility
P21 product authority defines two separate Bubble Maps. The Live Crypto Bubble Map must consume authoritative market/provider truth only. Canonical P15/P16 currently expose single-instrument live trade-price observations, not a market-wide summary fact contract.

Current official Binance Spot mini-ticker semantics provide raw per-symbol current/close price, rolling-24h open/high/low, base volume, quote volume, and provider event time. P21.2 therefore adds only a provider-neutral `LiveMarketSummaryFact` contract and validation boundary for those raw facts plus application receipt time.

## Ownership
This contract belongs to the existing market-data service boundary. It does not move provider mapping or acquisition into Home/P21 presentation. Existing P15/P16 owners remain authoritative for market acquisition/provider integration.

## Explicit non-scope
- No Bubble Map renderer, geometry, size metric, color semantics, ranking, grouping, filtering, interaction, or dashboard wiring.
- No market-universe selection, REST polling, WebSocket subscription, transport choice, state accumulation, complete-snapshot policy, or freshness policy.
- No persistence/schema/index work and no direct IndexedDB access.
- No journal/trade-history reads, P11/P12/P14 calculation duplication, or Your Trades Bubble Map semantics.
- No navigation, transition/motion, chart, Saved Analysis, goal, or discipline ownership.

A later controlled slice must separately source-contract acquisition, universe, accumulation/snapshot, and freshness semantics before any live-market Bubble Map can claim a complete current market view.
