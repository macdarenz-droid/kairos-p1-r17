# Kairos Home Dashboard Live Market Summary Acquisition Cadence Policy Foundation

Base authority: Gate328 Top-N canonical GOLDEN.

Responsibility: provider-neutral deterministic Home Dashboard live-market acquisition cadence policy only.

Released product semantics proposed by this candidate:
- visible entry => acquire immediately;
- visible resume => acquire immediately;
- visible periodic cadence => acquire and schedule next visible acquisition after exactly 5000 ms;
- hidden => suspend acquisition and schedule no periodic acquisition.

The policy is intentionally pure. It does not own browser timers, DOM/page visibility listeners, provider transport, session state, observedAt generation, freshness classification, eligibility, stablecoin exclusion, ordering, Top-N selection, persistence, React/Home presentation, Bubble rendering, journal truth, chart/navigation, or transitions.

A later lifecycle/scheduler adapter may consume this deterministic policy together with the already-released one-shot Home acquisition port; this candidate does not preempt that ownership.
