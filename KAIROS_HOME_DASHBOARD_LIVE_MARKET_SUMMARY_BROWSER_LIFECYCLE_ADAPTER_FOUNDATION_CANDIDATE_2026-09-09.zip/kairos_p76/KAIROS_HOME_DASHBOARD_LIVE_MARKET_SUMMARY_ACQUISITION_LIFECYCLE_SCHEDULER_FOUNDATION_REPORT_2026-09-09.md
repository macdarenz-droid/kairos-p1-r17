# Kairos Home Dashboard Live Market Summary Acquisition Lifecycle Scheduler Foundation

Base authority: Gate330 acquisition-cadence canonical GOLDEN.

Responsibility: provider-neutral application-layer acquisition lifecycle scheduling above the released pure cadence policy and one-shot Home acquisition port.

Semantics:
- visible entry acquires immediately and arms one 5000ms next-visible tick;
- each visible periodic tick starts at the approved fixed cadence, aborting any still-in-flight prior caller-owned request before starting the new one so non-serialized state transitions cannot race;
- hidden cancels the pending tick and aborts in-flight acquisition;
- hidden -> visible resumes with immediate acquisition and one new 5000ms tick;
- close is idempotent and prevents future scheduled work;
- lifecycle-driven abort settlement is suppressed, while current non-aborted result/error may be forwarded through caller-owned observers.

Non-scope: no browser timer implementation, DOM/Page Visibility listener, provider transport/selection, session construction, observedAt/freshness policy, universe eligibility/stablecoin/order/Top-N, persistence, React/Home/Bubble presentation, journal/Your Trades truth, chart/navigation, or transitions.
