# Binance Spot exchangeInfo Browser Public REST Connector Foundation

Base: canonical Gate #323 Binance Spot exchangeInfo instrument-metadata acquisition adapter foundation.

Responsibility: implement only the existing exchangeInfo request connector with exactly one native browser `globalThis.fetch` of the already-described request, exact optional caller-owned `AbortSignal` forwarding, exactly one `Response.text()` read, unchanged string return, and unchanged native fetch/text rejection.

Non-scope: no endpoint/path/query ownership beyond the released descriptor; no HTTP status/header/error taxonomy; no credentials/custom headers/cache/redirect/timeout; no retry/backoff/rate/request-weight policy; no JSON decode/mapping; no acquisition polling/visibility/resume/session lifecycle; no USDT/stablecoin/ranking/tie-break/Top-N universe policy; no freshness/cadence; no Home/Bubble/Your-Trades/journal/persistence/chart/navigation/transitions.
