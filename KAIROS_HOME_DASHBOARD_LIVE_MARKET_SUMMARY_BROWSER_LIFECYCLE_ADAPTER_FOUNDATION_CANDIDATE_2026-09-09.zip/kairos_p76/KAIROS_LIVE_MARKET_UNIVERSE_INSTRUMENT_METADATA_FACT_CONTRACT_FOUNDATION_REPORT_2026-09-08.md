# Live Market Universe Instrument Metadata Fact Contract Foundation

## Authority
Base: exact canonical Live Market Summary Freshness Classification Policy Foundation promoted by `Kairos Controlled Roadmap Gate` #312 / run `34188023039`.

Current user-approved P21 Live Crypto Bubble Map V1 authority defines the eligible default universe as actively tradable Binance Spot instruments quoted in USDT, with later deterministic universe policy responsible for configurable stablecoin exclusion, descending 24h quote-volume ranking, deterministic symbol tie-break, and configurable Top-30 limiting.

## Source proof
Released `LiveMarketSummaryFact` already owns `quoteVolume24h`, so the ranking fact exists. Released instrument identity is only `{ venue, symbol }`; it does not expose base asset, quote asset, or current tradability, and no released Spot exchange-information/instrument-directory owner exists.

Official Binance Spot documentation identifies `/api/v3/exchangeInfo` as exchange information and defines `quoteAsset` plus `TRADING` status semantics. Therefore current tradability and quote-asset identity belong to provider market metadata, not symbol-suffix inference in the application policy.

## Responsibility
This slice introduces only a provider-neutral market-data metadata fact contract with instrument identity, base asset, quote asset, and current trading-enabled truth, plus deterministic validation. It sits beside released market facts and is designed for a later Binance Spot metadata mapper and a later separate universe policy owner.

## Explicit non-scope
No Binance HTTP request, decoder, exchangeInfo adapter, transport, polling or cache; no USDT eligibility decision; no stablecoin exclusion; no quote-volume ranking/sorting/tie-break/top-N; no freshness policy or observation-age work; no Home React wiring; no Bubble renderer/geometry/size/color/interactions; no Your Trades/journal ownership; no persistence/IndexedDB/Saved Analysis/chart/navigation/transition ownership.

## Follow-on boundary
A later separately controlled Binance Spot adapter may map official exchange-information metadata into this fact. Only after that provider fact source is canonical should a separate deterministic universe-policy owner combine metadata facts with released 24h summary facts.
