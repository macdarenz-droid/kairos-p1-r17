# KAIROS P20.1 — Saved Analysis Contract Foundation

## Authority
Base: canonical P19.7 Risk/Reward Tool System Closure, `Kairos Controlled Roadmap Gate` run #280 / `34021672747`.

## Result
P20.1 establishes only the provider-neutral Saved Analysis aggregate contract and its independent stable identity allocator. The contract composes existing owners instead of copying them: P17 `ChartMarketReference`, P18 committed `ChartDrawing` snapshots, P19 `RiskRewardAnalysis`, and the P19.5 logical `RiskRewardChartTimeExtent`.

The aggregate is contract-only. Its readonly drawing and Risk/Reward arrays intentionally preserve the existing ability for either collection to be empty; empty drawing and Risk/Reward collections remain representable without inventing additional business rules.

## Ownership
P20 owns only the Saved Analysis aggregate identity/composition boundary introduced here. P17 retains market-reference truth. P18 retains drawing identities, logical anchors, committed drawing behavior, provider machinery, interaction, and presentation. P19 retains Risk/Reward semantics and logical placement. Derived P19 style/object projections remain derived and are not duplicated as Saved Analysis truth.

## Non-scope
No database schema, migration, repository, transaction, backup/restore, UI, provider, or pixel work. No timeframe, display-name, trade relation, creation/update timestamp, persistence index, renderer state, semantic-token output, or provider resource is introduced.

## Next dependency boundary
Later P20 persistence work must consume this contract and evolve the established persistence + full backup/restore system coherently. This patch does not preselect that storage shape.

## Canonical requirement
This contract becomes authoritative only after the exact P20.1 candidate receives a full `Kairos Controlled Roadmap Gate` PASS with canonical artifacts.
