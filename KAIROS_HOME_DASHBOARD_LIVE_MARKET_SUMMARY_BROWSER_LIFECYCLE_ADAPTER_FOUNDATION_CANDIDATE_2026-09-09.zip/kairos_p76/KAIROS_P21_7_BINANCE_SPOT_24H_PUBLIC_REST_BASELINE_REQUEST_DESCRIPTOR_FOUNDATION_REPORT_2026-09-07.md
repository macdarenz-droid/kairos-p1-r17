# KAIROS P21.7 — Binance Spot 24h Public REST Baseline Request Descriptor Foundation

## Authority
Base: canonical P21.6 Binance Spot 24h Baseline Delivery Mapping Foundation, `Kairos Controlled Roadmap Gate` #291 / run `34078317199`.

## Responsibility
P21.4 owns the provider-neutral baseline acquisition port, P21.5 maps one decoded Binance Spot 24h ticker entry, and P21.6 maps a decoded one-or-many ticker payload into validated complete-for-scope delivery. P21.7 adds only the missing pure provider request-description seam for an explicit caller-provided Binance Spot scope.

The descriptor validates non-empty unique Binance Spot instruments, describes public `GET /api/v3/ticker/24hr` against `https://data-api.binance.vision`, uses `symbol` for one requested instrument or `symbols` for multiple requested instruments, and fixes `type=FULL` because the released P21.5 mapper consumes FULL 24h ticker fields. Caller sequence is preserved only for deterministic request construction, never as ranking or universe truth.

## Explicit non-scope
- No fetch/XHR/WebSocket/browser transport, request execution, or JSON decoding.
- No multi-request batching/chunking or request-weight/rate-limit/backoff/retry policy.
- No credentials, AbortSignal, or concrete P21.4 acquisition-port orchestration.
- No market-universe selection/ranking or accumulator/state/order/freshness/reset/reconnect ownership.
- No Bubble Map sizing/color/grouping/filtering/geometry/interactions or Home wiring.
- No persistence, journal/Your-Trades semantics, direct IndexedDB UI access, or dashboard transitions.
