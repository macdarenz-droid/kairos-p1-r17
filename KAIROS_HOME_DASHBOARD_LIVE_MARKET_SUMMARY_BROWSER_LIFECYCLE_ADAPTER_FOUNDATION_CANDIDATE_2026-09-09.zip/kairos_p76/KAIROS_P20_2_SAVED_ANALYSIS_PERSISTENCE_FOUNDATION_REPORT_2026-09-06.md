# KAIROS P20.2 — Saved Analysis Persistence Foundation

Base: canonical P20.1 Saved Analysis Contract Foundation.

This slice adds the first persistence/restore ownership for the existing provider-neutral Saved Analysis contract: DB V4 `savedAnalyses` with stable `&id`, repository ownership, merged current-store authority, backup format V3, snapshot/restore/preflight/re-query coverage, and compatibility-aware historical verifiers. Released V1/V2/V3 database declarations and backup V1/V2 compatibility remain preserved.

Non-scope: no UI, provider state, pixels, optional metadata, secondary indexes, query APIs, drawing/Risk-Reward semantic duplication, or journal/calculation ownership.
