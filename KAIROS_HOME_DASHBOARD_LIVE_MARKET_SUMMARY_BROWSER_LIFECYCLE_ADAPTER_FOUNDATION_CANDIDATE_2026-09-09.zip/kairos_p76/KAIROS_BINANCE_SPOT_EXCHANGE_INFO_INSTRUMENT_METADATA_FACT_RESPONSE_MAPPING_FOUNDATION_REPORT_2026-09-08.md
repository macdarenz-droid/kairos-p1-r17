# Binance Spot Exchange Information Instrument Metadata Fact Response Mapping Foundation

## Authority
Base: canonical Binance Spot Exchange Information Instrument Metadata Fact Collection Mapping Foundation, `Kairos Controlled Roadmap Gate` #318 / run `34230096640`.

Canonical #318 owns mapping of exactly one explicitly supplied already-decoded exchangeInfo symbol collection into provider-neutral metadata facts, preserving collection sequence and delegating every entry to the released one-entry mapper. Its released follow-on boundary explicitly leaves validation/extraction of the `symbols` collection from one whole already-decoded exchangeInfo response object to a later provider composition.

## Responsibility
This slice introduces exactly one Binance-provider whole-response semantic composition. It accepts one whole already-decoded exchangeInfo value, requires that outer value to be a non-array object, reads only its `symbols` property, and delegates that exact property value unchanged to the released `mapBinanceSpotExchangeInfoInstrumentMetadataFactCollection(...)` owner.

A non-object or array outer value returns `response-invalid`. Missing or non-array `symbols` is not reinterpreted here: it surfaces the released collection mapper's exact `collection-invalid` result. Invalid symbol entries surface the released exact first-invalid-entry index and entry reason unchanged. Successful facts and provider collection order are returned unchanged from the released collection mapper.

This composition does not parse JSON, own transport, inspect unrelated exchangeInfo properties, or infer universe eligibility from symbol text.

## Explicit non-scope
- No HTTP request descriptor/execution, fetch/XHR/WebSocket/browser transport, `Response`, status/header/body acquisition, or JSON parsing.
- No new symbol/status/baseAsset/quoteAsset validation; all symbol-entry semantics remain owned by the released one-entry mapper.
- No new collection iteration, ordering, skipping, deduplication, or collection validation algorithm; all collection semantics remain owned by the released #318 collection mapper.
- No interpretation of `timezone`, `serverTime`, `rateLimits`, `exchangeFilters`, permissions, filters, order types, precision, or any other exchangeInfo property beyond reading `symbols`.
- No USDT eligibility filtering or symbol-suffix inference.
- No stablecoin exclusion.
- No 24h quote-volume lookup, ranking/sorting, symbol tie-break, Top-N/Top-30, popularity, or market-cap logic.
- No metadata cache, polling, refresh, retry, backoff, rate-limit or request-weight policy.
- No freshness-age/classification changes, evaluation-time ownership, stale/expired eviction, or visible-dashboard cadence.
- No Home React wiring, Bubble Map geometry/size/color/grouping/interactions/animation, or presentation state.
- No Your Trades/journal ownership, persistence/IndexedDB, Saved Analysis, chart, navigation, or transition ownership.

## Follow-on boundary
With one whole decoded exchangeInfo response now deterministically projected into authoritative provider-neutral metadata facts, a later separate deterministic universe-policy owner may combine those metadata facts with released 24h summary facts to implement the user-approved active-USDT eligibility, configurable stablecoin exclusion, descending 24h quote-volume ranking, deterministic symbol tie-break, and config-owned Top-30 selection. That policy must remain outside this Binance response composition.
