# Binance Spot Exchange Info Public REST Request Execution Boundary Foundation

## Authority
Base: canonical Binance Spot Exchange Information Public REST Request Descriptor Foundation, `Kairos Controlled Roadmap Gate` #314 / run `34195620691`.

## Responsibility
Canonical #314 describes the public Binance Spot `GET /api/v3/exchangeInfo` request but deliberately owns no execution. Existing released Binance REST architecture already separates request description from an injected execution boundary. This slice applies that same proven ownership pattern to exchangeInfo: accept one already-described request plus an externally supplied connector, invoke the connector exactly once, return its Promise/result unchanged, and forward optional caller-owned `signal?: AbortSignal` options unchanged without creating or interpreting cancellation policy.

## Explicit non-scope
- No concrete fetch/XHR/WebSocket/browser transport or Response acquisition.
- No HTTP status/header/body interpretation.
- No JSON parsing or exchangeInfo response decode.
- No mapping to `LiveMarketUniverseInstrumentMetadataFact`.
- No cache/polling/refresh/retry/backoff/request-weight/rate-limit policy.
- No USDT eligibility filtering, stablecoin exclusion, ranking, sorting, symbol tie-break or Top-N policy.
- No freshness changes, Home React wiring, stale presentation or Bubble rendering.
- No Your Trades/journal, persistence/IndexedDB, Saved Analysis, chart/navigation or transition ownership.
