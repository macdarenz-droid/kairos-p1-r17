import { readFileSync } from 'node:fs';
const s=readFileSync(new URL('../src/services/market-data/liveMarketUniverseQuoteVolumeOrderingPolicy.ts',import.meta.url),'utf8'); const i=readFileSync(new URL('../src/services/market-data/index.ts',import.meta.url),'utf8');
for(const t of ['decimalSubtract','LiveMarketSummaryFact','orderLiveMarketUniverseByQuoteVolume(','[...facts].sort(','difference.value === \'0\'','compareInstrumentSymbols(left.instrument.symbol, right.instrument.symbol)']) if(!s.includes(t)) throw new Error('missing '+t);
if(!i.includes("export * from './liveMarketUniverseQuoteVolumeOrderingPolicy';")) throw new Error('missing export');
for(const t of ['slice(0','Top 30','excludedStablecoinBaseAssets','fetch(','setInterval(','Date.now(','indexedDB','createChart(','React']) if(s.includes(t)) throw new Error('broadened '+t);
console.log('Live Market Universe quote-volume ordering policy verification passed.');
