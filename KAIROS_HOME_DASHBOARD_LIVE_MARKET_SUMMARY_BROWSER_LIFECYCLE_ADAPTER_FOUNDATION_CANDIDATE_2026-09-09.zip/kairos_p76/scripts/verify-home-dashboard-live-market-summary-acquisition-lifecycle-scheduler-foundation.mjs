import { readFileSync } from 'node:fs';

const source = readFileSync('src/application/dashboard/homeDashboardLiveMarketSummaryAcquisitionLifecycleScheduler.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-market-summary-acquisition-lifecycle-scheduler-foundation.test.ts', 'utf8');

for (const token of [
  'decideHomeDashboardLiveMarketSummaryAcquisitionCadence',
  'HomeDashboardLiveMarketSummaryScopedSnapshotAcquisitionPort',
  'AbortController',
  'scheduler.schedule',
  'scheduler.cancel',
  "runVisibleTrigger('periodic')",
  "runVisibleTrigger('resume')",
  "visibility === 'hidden'",
  'abortActiveAcquisition();',
  'observer.onResult?.(result)',
  'observer.onError?.(error)',
]) {
  if (!source.includes(token)) throw new Error(`missing lifecycle-scheduler evidence: ${token}`);
}

for (const forbidden of [
  'setInterval(', 'setTimeout(', 'document.', 'visibilityState', 'visibilitychange',
  'addEventListener(', 'fetch(', 'WebSocket', 'Binance', 'quoteVolume24h', 'stablecoin',
  'TopN', 'FRESH', 'STALE', 'EXPIRED', 'React', 'useEffect(', 'useState(', 'IndexedDB',
]) {
  if (source.includes(forbidden)) throw new Error(`lifecycle scheduler leaked forbidden ownership: ${forbidden}`);
}

for (const token of [
  "toBe(5000)",
  "setVisibility('hidden')",
  "setVisibility('visible')",
  'firstSignal.aborted',
  'onResult',
  'onError',
]) {
  if (!test.includes(token)) throw new Error(`missing focused lifecycle test evidence: ${token}`);
}

console.log('Home Dashboard live-market acquisition lifecycle scheduler foundation verifier PASS');
