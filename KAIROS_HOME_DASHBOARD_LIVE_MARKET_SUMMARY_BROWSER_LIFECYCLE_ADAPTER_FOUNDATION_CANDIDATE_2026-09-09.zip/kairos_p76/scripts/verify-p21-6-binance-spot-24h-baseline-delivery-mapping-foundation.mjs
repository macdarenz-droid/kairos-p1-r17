import { readFileSync } from 'node:fs';
const mapper = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hBaselineDelivery.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_6_BINANCE_SPOT_24H_BASELINE_DELIVERY_MAPPING_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');
for (const token of [
  'export type BinanceSpot24hBaselineDeliveryResult =',
  'export function mapBinanceSpot24hBaselineDelivery(',
  'mapBinanceSpot24hSummaryFact(entry, observedAt)',
  "completeness: 'complete-for-scope'",
  'validateLiveMarketSummaryBaselineSuccess(scope, delivery)',
]) if (!mapper.includes(token)) throw new Error(`P21.6 mapping evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpot24hBaselineDelivery';")) throw new Error('P21.6 mapper barrel export missing');
for (const forbidden of ['fetch(', 'WebSocket', 'EventSource', 'indexedDB', '/api/v3/', 'acquireBaseline(', 'createChart(', 'bubbleSize', 'marketCap', 'URLSearchParams']) {
  if (mapper.includes(forbidden)) throw new Error(`P21.6 broadened into forbidden implementation scope: ${forbidden}`);
}
for (const token of ['# KAIROS P21.6 — Binance Spot 24h Baseline Delivery Mapping Foundation', 'No HTTP/fetch/browser transport', 'No symbol batching', 'No concrete P21.4 acquisition-port adapter', 'No Bubble Map sizing', 'No persistence']) {
  if (!report.includes(token)) throw new Error(`P21.6 report evidence missing: ${token}`);
}
console.log('P21.6 Binance Spot 24h baseline delivery mapping verification passed.');
