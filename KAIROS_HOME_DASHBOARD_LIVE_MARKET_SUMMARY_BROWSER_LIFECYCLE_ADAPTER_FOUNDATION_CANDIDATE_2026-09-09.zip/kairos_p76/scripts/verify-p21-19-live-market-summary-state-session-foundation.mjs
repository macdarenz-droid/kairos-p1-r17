import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/liveMarketSummaryStateSession.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_19_LIVE_MARKET_SUMMARY_STATE_SESSION_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');
for (const token of [
  'createLiveMarketSummaryDeliveryState',
  'LiveMarketSummaryDeliveryState',
  'LiveMarketSummaryStateTransition',
  'createLiveMarketSummaryStateSession(',
  'getState(): LiveMarketSummaryDeliveryState',
  'const nextState = await transitionState(currentState)',
  'currentState = nextState',
]) if (!source.includes(token)) throw new Error(`P21.19 state-session evidence missing: ${token}`);
if (!index.includes("export * from './liveMarketSummaryStateSession';")) throw new Error('P21.19 state-session export missing');
for (const forbidden of [
  'binance', 'globalThis.fetch(', 'fetch(', 'Response(', 'XMLHttpRequest', 'WebSocket(',
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'AbortController', 'indexedDB',
  '.sort(', 'createChart(', 'applyLiveMarketSummaryDeliveryState(',
]) if (source.toLowerCase().includes(forbidden.toLowerCase())) throw new Error(`P21.19 broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'no long-lived current-state owner',
  'provider-neutral in-memory state-session owner only',
  'Commit only the state returned by that transition',
  'preserve exact prior-state identity/content unchanged',
  'No universe/default symbols/scope selection',
  'No persistence/IndexedDB/repository/schema/backup',
  'no UI reactivity/subscription framework choice',
]) if (!report.includes(token)) throw new Error(`P21.19 report evidence missing: ${token}`);
console.log('P21.19 Live Market Summary State Session verification passed.');
