import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/liveMarketSummaryScopedStateSnapshot.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_21_LIVE_MARKET_SUMMARY_SCOPED_STATE_SNAPSHOT_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');
for (const token of [
  'LiveMarketSummaryScopedStateSnapshotEntry',
  'readLiveMarketSummaryScopedStateSnapshot(',
  'scope.map((instrument) => ({',
  'getLiveMarketSummaryDeliveryStateFact(state, instrument)',
  'LiveMarketSummaryFact | null',
]) if (!source.includes(token)) throw new Error(`P21.21 snapshot evidence missing: ${token}`);
if (!index.includes("export * from './liveMarketSummaryScopedStateSnapshot';")) throw new Error('P21.21 snapshot export missing');
for (const forbidden of [
  '.sort(', '.filter(', '.reduce(', 'new Map(', 'new Set(', 'Date.now(', 'new Date(',
  'setTimeout(', 'setInterval(', 'fetch(', 'XMLHttpRequest', 'WebSocket(', 'indexedDB',
  'transition(', 'applyLiveMarketSummaryDeliveryState(', 'createChart(',
]) if (source.includes(forbidden)) throw new Error(`P21.21 broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'backing Map iteration order is storage detail rather than ranking or presentation truth',
  'no production owner for an explicit caller-scoped multi-fact read projection',
  'Resolve facts only through released `getLiveMarketSummaryDeliveryStateFact(...)`',
  'never ranking or presentation truth',
  'No universe/default-symbol/scope discovery',
  'No persistence/IndexedDB/journal/Your Trades/Saved Analysis/chart/transitions',
]) if (!report.includes(token)) throw new Error(`P21.21 report evidence missing: ${token}`);
console.log('P21.21 Live Market Summary Scoped State Snapshot verification passed.');
