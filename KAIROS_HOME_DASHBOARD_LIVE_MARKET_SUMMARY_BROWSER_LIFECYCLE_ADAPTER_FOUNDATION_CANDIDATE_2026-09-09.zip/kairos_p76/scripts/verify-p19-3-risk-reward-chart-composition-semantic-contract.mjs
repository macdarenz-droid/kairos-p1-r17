import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/application/risk-reward/riskRewardChartSemantics.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/application/risk-reward/index.ts', import.meta.url), 'utf8');
const test = readFileSync(new URL('../tests/risk-reward-chart-semantics.test.ts', import.meta.url), 'utf8');

for (const token of [
  "export type RiskRewardChartLevelRole = 'entry' | 'stop' | 'target'",
  'export interface RiskRewardChartSemanticPriceLevel',
  'readonly price: DecimalString',
  'export interface RiskRewardChartSemanticLevels',
  'readonly entry: RiskRewardChartSemanticPriceLevel',
  'readonly stop: RiskRewardChartSemanticPriceLevel',
  'readonly target: RiskRewardChartSemanticPriceLevel',
  'export interface RiskRewardChartSemantics',
  'readonly id: RiskRewardAnalysisId',
  'readonly side: TradeSide',
  'readonly zones: RiskRewardZoneSemantics',
  'export function projectRiskRewardChartSemantics',
  'id: analysis.id',
  'side: analysis.side',
  "entry: { role: 'entry', price: analysis.levels.entry }",
  "stop: { role: 'stop', price: analysis.levels.stop }",
  "target: { role: 'target', price: analysis.levels.target }",
  'zones: projectRiskRewardZoneSemantics(analysis)',
]) {
  if (!source.includes(token)) throw new Error(`P19.3 chart semantics missing: ${token}`);
}
for (const forbidden of [
  'lightweight-charts', 'ChartDrawing', 'IndexedDB', 'Dexie', 'localStorage',
  'fetch(', 'WebSocket', 'calculateTradeMetrics', 'calculateRisk', 'calculateRMultiple',
  'Decimal(', 'Math.min', 'Math.max', 'TradeExecutionRecord', 'TradePlanRecord',
  'TradeRecord', 'timestamp', 'time:', 'color:', 'fill:', 'style:', 'document.', 'window.',
]) {
  if (source.includes(forbidden)) throw new Error(`P19.3 chart semantics owns forbidden concern: ${forbidden}`);
}
if (!index.includes("from './riskRewardChartSemantics'")) throw new Error('P19.3 risk-reward barrel does not export chart semantics');
for (const token of [
  "analysis('long', '100', '90', '120')",
  "entry: { role: 'entry'",
  "stop: { role: 'stop'",
  "target: { role: 'target'",
  "risk: { role: 'risk'",
  "reward: { role: 'reward'",
  "analysis('short', '100', '110', '80')",
  'without normalization',
]) {
  if (!test.includes(token)) throw new Error(`P19.3 focused test missing: ${token}`);
}
console.log('P19.3 Risk/Reward chart composition semantic contract verification passed.');
