import fs from 'node:fs';
const read=(p)=>fs.readFileSync(new URL(`../${p}`, import.meta.url),'utf8');
const src=read('src/services/market-data/providers/binance/binanceSpotExchangeInfoPublicRestRoundTrip.ts');
const idx=read('src/services/market-data/index.ts');
if(!src.includes('const request = describeBinanceSpotExchangeInfoPublicRestRequest();')) throw new Error('unconditional descriptor composition missing');
if(src.includes('described.ok') || src.includes('described.request')) throw new Error('round trip incorrectly treats unconditional exchangeInfo descriptor as a fallible request result');
if(!src.includes('executeBinanceSpotExchangeInfoPublicRestRequest(request, connect)')) throw new Error('execution composition missing');
if(!src.includes('executeBinanceSpotExchangeInfoPublicRestRequest(request, connect, options)')) throw new Error('execution options forwarding missing');
if(!src.includes('mapBinanceSpotExchangeInfoPublicRestResponseDelivery(data)')) throw new Error('response delivery composition missing');
if(!idx.includes("export * from './providers/binance/binanceSpotExchangeInfoPublicRestRoundTrip';")) throw new Error('index export missing');
for (const forbidden of ['fetch(', 'XMLHttpRequest', 'WebSocket(', 'setTimeout(', 'setInterval(', 'indexedDB']) {
  if (src.includes(forbidden)) throw new Error(`round trip broadened into forbidden scope: ${forbidden}`);
}
console.log('exchangeInfo public REST round-trip verifier PASS');
