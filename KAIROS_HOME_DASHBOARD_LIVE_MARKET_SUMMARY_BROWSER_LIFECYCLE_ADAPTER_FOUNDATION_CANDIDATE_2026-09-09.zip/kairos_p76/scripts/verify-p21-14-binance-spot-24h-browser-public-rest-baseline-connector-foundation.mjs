import { readFileSync } from 'node:fs';
const connector = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hBrowserPublicRestBaselineConnector.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_14_BINANCE_SPOT_24H_BROWSER_PUBLIC_REST_BASELINE_CONNECTOR_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');
for (const token of [
  'connectBinanceSpot24hBrowserPublicRestBaselineRequest',
  'BinanceSpot24hPublicRestBaselineRequestConnector<string>',
  'globalThis.fetch(request.url,',
  'method: request.method',
  'signal: options?.signal',
  'return response.text()',
]) if (!connector.includes(token)) throw new Error(`P21.14 connector evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpot24hBrowserPublicRestBaselineConnector';")) throw new Error('P21.14 connector export missing');
for (const forbidden of [
  'response.ok', 'response.status', 'response.headers', 'new AbortController(', 'AbortSignal.any(', 'AbortSignal.timeout(',
  'setTimeout(', 'setInterval(', 'JSON.parse(', 'indexedDB', 'createChart(', 'WebSocket(', 'XMLHttpRequest',
  'credentials:', 'headers:', 'cache:', 'redirect:',
]) if (connector.includes(forbidden)) throw new Error(`P21.14 broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'Canonical P21.8 deliberately leaves network execution behind an injected connector.',
  'Existing P16.12 establishes the project pattern that concrete browser transport is a narrow provider adapter',
  'public market-data APIs may use `https://data-api.binance.vision`',
  'Read `Response.text()` exactly once',
  'Do not inspect HTTP status/headers',
  'No HTTP status/header interpretation',
  'No JSON/provider payload decode',
  'No Live Crypto Bubble Map sizing',
  'No Your Trades Bubble Map',
]) if (!report.includes(token)) throw new Error(`P21.14 report evidence missing: ${token}`);
console.log('P21.14 Binance Spot browser public REST baseline connector verification passed.');
