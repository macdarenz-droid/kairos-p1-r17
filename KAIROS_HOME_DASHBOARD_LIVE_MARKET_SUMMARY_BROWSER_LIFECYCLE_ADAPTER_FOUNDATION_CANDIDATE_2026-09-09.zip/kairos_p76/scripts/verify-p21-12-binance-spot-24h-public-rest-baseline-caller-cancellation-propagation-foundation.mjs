import { readFileSync } from 'node:fs';
const exec = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hPublicRestBaselineRequestExecution.ts', import.meta.url), 'utf8');
const round = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hPublicRestBaselineRoundTrip.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_12_BINANCE_SPOT_24H_PUBLIC_REST_BASELINE_CALLER_CANCELLATION_PROPAGATION_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');
for (const token of [
  'BinanceSpot24hPublicRestBaselineExecutionOptions',
  'readonly signal?: AbortSignal',
  'if (options === undefined) return connect(request);',
  'return connect(request, options);',
]) if (!exec.includes(token)) throw new Error(`P21.12 execution propagation evidence missing: ${token}`);
for (const token of [
  'options?: BinanceSpot24hPublicRestBaselineExecutionOptions',
  'executeBinanceSpot24hPublicRestBaselineRequest(described.request, connect)',
  'executeBinanceSpot24hPublicRestBaselineRequest(described.request, connect, options)',
]) if (!round.includes(token)) throw new Error(`P21.12 round-trip propagation evidence missing: ${token}`);
for (const source of [exec, round]) for (const forbidden of [
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'new Response(', 'new AbortController(',
  'AbortSignal.any(', 'AbortSignal.timeout(', 'setTimeout(', 'acquireBaseline(', 'indexedDB',
]) if (source.includes(forbidden)) throw new Error(`P21.12 broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'No concrete fetch/XHR/WebSocket/browser transport',
  'No `AbortController` creation',
  'No concrete P21.4 acquisition-port implementation yet',
  'No retry/backoff/throttle/rate-limit',
  'No new request/decode/ticker/completeness algorithm',
]) if (!report.includes(token)) throw new Error(`P21.12 report evidence missing: ${token}`);
console.log('P21.12 caller cancellation propagation verification passed.');
