import { readFileSync } from 'node:fs';
const binding = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpotExchangeInfoBrowserInstrumentMetadataAcquisitionBinding.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_BINANCE_SPOT_EXCHANGE_INFO_BROWSER_INSTRUMENT_METADATA_ACQUISITION_BINDING_FOUNDATION_REPORT_2026-09-09.md', import.meta.url), 'utf8');
for (const token of [
  'createBinanceSpotExchangeInfoBrowserInstrumentMetadataAcquisitionPort()',
  'LiveMarketUniverseInstrumentMetadataAcquisitionPort',
  'createBinanceSpotExchangeInfoInstrumentMetadataAcquisitionPort(',
  'connectBinanceSpotExchangeInfoBrowserPublicRestRequest,',
]) if (!binding.includes(token)) throw new Error(`binding evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpotExchangeInfoBrowserInstrumentMetadataAcquisitionBinding';")) throw new Error('binding export missing');
for (const forbidden of [
  'globalThis.fetch(', 'fetch(', 'XMLHttpRequest', 'WebSocket(', 'Response(', 'JSON.parse(',
  'Date.now(', 'new Date(', 'new AbortController(', 'AbortSignal.any(', 'AbortSignal.timeout(',
  'setTimeout(', 'setInterval(', 'indexedDB', 'createChart(', 'USDT', 'quoteVolume', 'Top 30',
]) if (binding.includes(forbidden)) throw new Error(`binding broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'Gate #323 owns the Binance Spot implementation of the provider-neutral instrument metadata acquisition port',
  'Gate #324 owns the concrete browser connector',
  'released P21.15 24h browser acquisition binding establishes the dependency direction',
  'No USDT eligibility, stablecoin exclusion, 24h quote-volume ranking',
  'No observedAt/freshness thresholds, 5-second cadence',
  'No Home/Live Crypto Bubble Map UI',
]) if (!report.includes(token)) throw new Error(`report evidence missing: ${token}`);
console.log('Binance Spot exchangeInfo browser instrument metadata acquisition binding verification passed.');
