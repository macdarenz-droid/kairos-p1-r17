import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceHomeDashboardLiveMarketSummaryScopedSnapshotAcquisitionPortAdapter.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_BINANCE_HOME_DASHBOARD_LIVE_MARKET_SUMMARY_SCOPED_SNAPSHOT_ACQUISITION_PORT_ADAPTER_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');
for (const token of [
  'createBinanceHomeDashboardLiveMarketSummaryScopedSnapshotAcquisitionPort',
  'session: LiveMarketSummaryStateSession',
  'readObservedAt: BinanceSpot24hPublicRestBaselineObservedAtSource',
  'HomeDashboardLiveMarketSummaryScopedSnapshotAcquisitionPort',
  'return acquireBinanceSpot24hBrowserPublicRestBaselineIntoSessionAndReadScopedSnapshot(',
]) if (!source.includes(token)) throw new Error(`adapter contract evidence missing: ${token}`);
if (!/session,\s*readObservedAt,\s*scope,\s*options,/.test(source)) throw new Error('adapter must forward same session/readObservedAt/scope/options in order');
const calls=(source.match(/acquireBinanceSpot24hBrowserPublicRestBaselineIntoSessionAndReadScopedSnapshot\(/g)||[]).length;
if (calls !== 1) throw new Error(`adapter must delegate to released P21.23 exactly once, found ${calls}`);
if (!index.includes("export * from './providers/binance/binanceHomeDashboardLiveMarketSummaryScopedSnapshotAcquisitionPortAdapter';")) throw new Error('adapter public export missing');
for (const forbidden of [
  'createLiveMarketSummaryStateSession(', 'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'indexedDB', 'new AbortController(', '.sort(', '.filter(', '.reduce(',
  'React', 'useEffect', 'useState', 'createChart(',
]) if (source.includes(forbidden)) throw new Error(`adapter broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'provider-owned adapter',
  'delegates exactly once to released P21.23',
  'Return the released P21.23 Promise/result unchanged',
  'no Home React wiring/hooks/effects/UI state',
  'no Your Trades/journal ownership',
]) if (!report.includes(token)) throw new Error(`adapter report evidence missing: ${token}`);
console.log('Binance Home Dashboard live-market acquisition-port adapter verification passed.');
