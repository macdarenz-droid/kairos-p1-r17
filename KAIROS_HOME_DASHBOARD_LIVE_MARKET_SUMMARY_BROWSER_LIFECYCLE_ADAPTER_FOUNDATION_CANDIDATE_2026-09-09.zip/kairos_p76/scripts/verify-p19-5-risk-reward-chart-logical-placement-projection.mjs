import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/app/riskRewardChartPlacementProjection.ts', import.meta.url), 'utf8');
const test = readFileSync(new URL('../tests/risk-reward-chart-placement-projection.test.ts', import.meta.url), 'utf8');
const chartContract = readFileSync(new URL('../src/features/chart/chartRenderContract.ts', import.meta.url), 'utf8');
const chartIndex = readFileSync(new URL('../src/features/chart/index.ts', import.meta.url), 'utf8');

for (const token of [
  "import type { RiskRewardChartSemantics } from '../application/risk-reward'",
  "import type { ChartTimestamp } from '../features/chart'",
  'export interface RiskRewardChartTimeExtent',
  'readonly start: ChartTimestamp',
  'readonly end: ChartTimestamp',
  'export interface RiskRewardChartPlacementProjection',
  "readonly id: RiskRewardChartSemantics['id']",
  'export function projectRiskRewardChartPlacement',
  'id: semantics.id',
  'start: extent.start',
  'end: extent.end',
]) {
  if (!source.includes(token)) throw new Error(`P19.5 placement projection missing: ${token}`);
}

if (!chartContract.includes('export type ChartTimestamp = string')) {
  throw new Error('P19.5 requires the established generic ChartTimestamp owner');
}
if (!chartIndex.includes('ChartTimestamp')) {
  throw new Error('P19.5 requires ChartTimestamp to remain exported by the generic chart feature boundary');
}

for (const forbidden of [
  'lightweight-charts', 'ChartDrawing', 'IndexedDB', 'Dexie', 'localStorage',
  'fetch(', 'WebSocket', 'calculateTradeMetrics', 'calculateRisk', 'calculateRMultiple',
  'Math.min', 'Math.max', 'new Date(', 'Date.parse', '.sort(', 'localeCompare(',
  'parseInt(', 'parseFloat(', 'Number(', 'document.', 'window.', '.applyOptions(',
  'addSeries(', 'createChart(', 'setData(', 'update(', 'priceToCoordinate(',
]) {
  if (source.includes(forbidden)) throw new Error(`P19.5 placement projection owns forbidden concern: ${forbidden}`);
}
if (/(#[0-9a-fA-F]{3,8}\b|rgba?\(|hsla?\()/.test(source)) {
  throw new Error('P19.5 placement projection hard-codes a visual color value');
}

for (const token of [
  'preserves analysis identity and caller-supplied logical start/end timestamps',
  'does not validate, reorder, or normalize the caller-owned logical extent',
  'start: extent.start',
  'end: extent.end',
]) {
  if (!test.includes(token)) throw new Error(`P19.5 focused test missing: ${token}`);
}

console.log('P19.5 Risk/Reward chart logical placement projection verification passed.');
