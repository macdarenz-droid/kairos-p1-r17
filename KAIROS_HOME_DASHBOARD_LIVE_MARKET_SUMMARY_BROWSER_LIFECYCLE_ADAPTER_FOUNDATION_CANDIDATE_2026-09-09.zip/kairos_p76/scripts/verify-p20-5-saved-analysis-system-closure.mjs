import { readFileSync } from 'node:fs';

const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const architecture = readFileSync(new URL('../docs/KAIROS_ARCHITECTURE_MAP.md', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P20_5_SAVED_ANALYSIS_SYSTEM_CLOSURE_REPORT_2026-09-07.md', import.meta.url), 'utf8');

const requiredScripts = [
  'verify:p20:1-saved-analysis-contract-foundation',
  'verify:p20:2-saved-analysis-persistence-foundation',
  'verify:p20:3-saved-analysis-application-save',
  'verify:p20:4-saved-analysis-application-load',
];
for (const name of requiredScripts) {
  if (typeof pkg.scripts?.[name] !== 'string') throw new Error(`P20 closure missing retained verifier registration: ${name}`);
}

for (const token of [
  '## P20 canonical ownership ledger — SYSTEM CLOSED through P20.5',
  'P20.4 | Saved Analysis application load-one-by-id orchestration',
  'P20.5 | Saved Analysis system closure',
  'P20.5 adds **no production runtime behavior and no new production owner**',
  'does not invent generic CRUD',
  'P21 may not begin before that PASS',
  'P19 (SYSTEM CLOSED through P19.7)',
]) {
  if (!architecture.includes(token)) throw new Error(`P20 closure architecture evidence missing: ${token}`);
}

for (const token of [
  '# KAIROS P20.5 — Saved Analysis System Closure',
  'No production runtime source changes',
  'P20.1 through P20.4',
  'does not create application list/update/delete orchestration',
  'P21 remains out of scope until canonical closure PASS',
]) {
  if (!report.includes(token)) throw new Error(`P20 closure report evidence missing: ${token}`);
}

console.log('P20 Saved Analysis system closure verification passed.');
