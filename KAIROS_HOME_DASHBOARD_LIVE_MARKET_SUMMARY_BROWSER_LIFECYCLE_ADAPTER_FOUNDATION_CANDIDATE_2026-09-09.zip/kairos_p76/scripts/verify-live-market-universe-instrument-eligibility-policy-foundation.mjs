import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/liveMarketUniverseInstrumentEligibilityPolicy.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_LIVE_MARKET_UNIVERSE_INSTRUMENT_ELIGIBILITY_POLICY_FOUNDATION_REPORT_2026-09-09.md', import.meta.url), 'utf8');

for (const token of [
  'LiveMarketUniverseInstrumentMetadataFact',
  'excludedStablecoinBaseAssets: ReadonlySet<string>',
  'isLiveMarketUniverseInstrumentEligible(',
  'fact.tradingEnabled',
  "fact.quoteAsset === 'USDT'",
  '!options.excludedStablecoinBaseAssets.has(fact.baseAsset)',
]) if (!source.includes(token)) throw new Error(`eligibility policy evidence missing: ${token}`);

if (!index.includes("export * from './liveMarketUniverseInstrumentEligibilityPolicy';")) throw new Error('eligibility policy public export missing');

for (const forbidden of [
  '.sort(', 'quoteVolume24h', 'Top 30', 'slice(', 'Date.now(', 'new Date(',
  'setInterval(', 'setTimeout(', 'fetch(', 'XMLHttpRequest', 'WebSocket(',
  'JSON.parse(', 'indexedDB', 'createChart(', 'React', 'useEffect',
]) if (source.includes(forbidden)) throw new Error(`eligibility policy broadened into forbidden scope: ${forbidden}`);

for (const token of [
  'Gate #325',
  'actively tradable Binance Spot instruments quoted in USDT',
  'explicit configurable stablecoin-exclusion set',
  'No 24h quote-volume ranking or sorting',
  'No Top-N or Top-30 selection/limiting',
  'No observedAt/freshness thresholds',
]) if (!report.includes(token)) throw new Error(`eligibility report evidence missing: ${token}`);

console.log('Live Market Universe instrument eligibility policy verification passed.');
