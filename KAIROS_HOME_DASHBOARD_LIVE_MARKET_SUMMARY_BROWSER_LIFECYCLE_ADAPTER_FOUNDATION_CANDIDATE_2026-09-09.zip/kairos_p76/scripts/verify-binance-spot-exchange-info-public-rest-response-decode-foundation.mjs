import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpotExchangeInfoPublicRestResponseDecode.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_BINANCE_SPOT_EXCHANGE_INFO_PUBLIC_REST_RESPONSE_DECODE_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');

for (const token of [
  'BinanceSpotExchangeInfoPublicRestResponseDecodeResult',
  'decodeBinanceSpotExchangeInfoPublicRestResponse',
  "typeof data !== 'string'",
  'JSON.parse(data)',
  "'unsupported-response-data'",
  "'invalid-json'",
]) if (!source.includes(token)) throw new Error(`exchangeInfo response-decode evidence missing: ${token}`);

if (!index.includes("export * from './providers/binance/binanceSpotExchangeInfoPublicRestResponseDecode';")) {
  throw new Error('exchangeInfo response-decode barrel export missing');
}

for (const forbidden of [
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'new Response(', '.json(', 'executeBinanceSpotExchangeInfoPublicRestRequest(',
  'LiveMarketUniverseInstrumentMetadataFact', 'tradingEnabled:', 'quoteVolume24h', '.sort(', 'Top 30', 'topN',
  'setTimeout(', 'setInterval(', 'indexedDB',
]) if (source.includes(forbidden)) throw new Error(`response decode broadened into forbidden scope: ${forbidden}`);

for (const token of [
  'No fetch/XHR/WebSocket/browser transport',
  'No HTTP status/header/body acquisition or interpretation',
  'No exchangeInfo semantic validation',
  'No mapping to `LiveMarketUniverseInstrumentMetadataFact`',
  'No cache/polling/refresh/retry',
  'No USDT eligibility filtering',
  'No freshness changes',
  'No Your Trades/journal',
]) if (!report.includes(token)) throw new Error(`response-decode report evidence missing: ${token}`);

console.log('Binance Spot exchangeInfo public REST response decode verification passed.');
