import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/application/risk-reward/riskRewardZoneSemantics.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/application/risk-reward/index.ts', import.meta.url), 'utf8');
const test = readFileSync(new URL('../tests/risk-reward-zone-semantics.test.ts', import.meta.url), 'utf8');

for (const token of [
  "export type RiskRewardZoneRole = 'risk' | 'reward'",
  'export interface RiskRewardSemanticPriceZone',
  'readonly from: DecimalString',
  'readonly to: DecimalString',
  'export interface RiskRewardZoneSemantics',
  'readonly risk: RiskRewardSemanticPriceZone',
  'readonly reward: RiskRewardSemanticPriceZone',
  'export function projectRiskRewardZoneSemantics',
  "role: 'risk'",
  'from: analysis.levels.entry',
  'to: analysis.levels.stop',
  "role: 'reward'",
  'to: analysis.levels.target',
]) {
  if (!source.includes(token)) throw new Error(`P19.2 zone semantics missing: ${token}`);
}
for (const forbidden of [
  'lightweight-charts', 'ChartDrawing', 'IndexedDB', 'Dexie', 'fetch(', 'WebSocket',
  'calculateTradeMetrics', 'calculateRisk', 'calculateRMultiple', 'Decimal(',
  'Math.min', 'Math.max', 'riskZone:', 'rewardZone:', 'color:', 'fill:',
  'TradeExecutionRecord', 'TradePlanRecord', 'TradeRecord', 'timestamp', 'time:',
]) {
  if (source.includes(forbidden)) throw new Error(`P19.2 zone semantics owns forbidden concern: ${forbidden}`);
}
if (!index.includes("from './riskRewardZoneSemantics'")) throw new Error('P19.2 risk-reward barrel does not export zone semantics');
for (const token of [
  "analysis('long', '100', '90', '120')",
  "risk: { role: 'risk'",
  "reward: { role: 'reward'",
  "analysis('short', '100', '110', '80')",
  'preserves short-side price ordering rather than normalizing or validating it',
]) {
  if (!test.includes(token)) throw new Error(`P19.2 focused test missing: ${token}`);
}
console.log('P19.2 Risk/Reward zone semantics projection verification passed.');
