import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpotExchangeInfoPublicRestResponseDelivery.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_BINANCE_SPOT_EXCHANGE_INFO_PUBLIC_REST_RESPONSE_DELIVERY_COMPOSITION_FOUNDATION_REPORT_2026-09-09.md', import.meta.url), 'utf8');
for (const token of [
  'mapBinanceSpotExchangeInfoPublicRestResponseDelivery',
  'decodeBinanceSpotExchangeInfoPublicRestResponse(data)',
  'if (!decoded.ok) return decoded',
  'mapBinanceSpotExchangeInfoInstrumentMetadataFactResponse(decoded.payload)',
]) if (!source.includes(token)) throw new Error(`response-delivery evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpotExchangeInfoPublicRestResponseDelivery';")) throw new Error('response-delivery barrel export missing');
for (const forbidden of [
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'new Response(', 'AbortSignal',
  'setTimeout(', 'setInterval(', 'indexedDB', 'quoteVolume', 'Top 30',
]) if (source.includes(forbidden)) throw new Error(`response-delivery broadened scope: ${forbidden}`);
for (const token of [
  'No request descriptor or request execution ownership',
  'No full REST round-trip orchestration',
  'No USDT filtering',
  'No cache, polling',
  'No Home/Bubble UI',
]) if (!report.includes(token)) throw new Error(`response-delivery report evidence missing: ${token}`);
console.log('Binance Spot exchangeInfo public REST response delivery composition verification passed.');
