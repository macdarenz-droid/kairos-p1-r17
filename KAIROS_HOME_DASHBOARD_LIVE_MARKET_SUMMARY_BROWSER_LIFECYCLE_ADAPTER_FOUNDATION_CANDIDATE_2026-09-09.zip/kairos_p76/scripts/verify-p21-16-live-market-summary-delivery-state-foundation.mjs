import { readFileSync } from 'node:fs';
const state = readFileSync(new URL('../src/services/market-data/liveMarketSummaryDeliveryState.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_16_LIVE_MARKET_SUMMARY_DELIVERY_STATE_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');
for (const token of [
  'LiveMarketSummaryDeliveryState',
  'validateLiveMarketSummaryDelivery(delivery)',
  "delivery.completeness === 'complete-for-scope'",
  'next.delete(instrumentKey(instrument))',
  'next.set(instrumentKey(fact.instrument), fact)',
  "reason: 'delivery-invalid'",
]) if (!state.includes(token)) throw new Error(`P21.16 state evidence missing: ${token}`);
if (!index.includes("export * from './liveMarketSummaryDeliveryState';")) throw new Error('P21.16 state export missing');
for (const forbidden of [
  'globalThis.fetch(', 'fetch(', 'XMLHttpRequest', 'WebSocket(', 'Response(', 'JSON.parse(',
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'indexedDB', '.sort(', 'createChart(',
  'createBinanceSpot24hBrowserPublicRestBaselineAcquisitionPort(',
]) if (state.includes(forbidden)) throw new Error(`P21.16 broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'Canonical P21.3 defines explicit provider-neutral live-market summary delivery completeness',
  'no production `LiveMarketSummary` state/accumulator owner or consumer',
  '`incremental` delivery: upsert only delivered instrument facts',
  '`complete-for-scope` delivery: replace only facts for that delivery\'s explicit scope',
  'Do not compare timestamps or infer freshness',
  'No market-universe/scope selection, ranking, filtering, grouping, sorting',
  'No persistence, schema, repository, backup, direct IndexedDB',
]) if (!report.includes(token)) throw new Error(`P21.16 report evidence missing: ${token}`);
console.log('P21.16 live market summary delivery state verification passed.');
