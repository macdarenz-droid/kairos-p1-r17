# KAIROS Live Market Universe Top-N Selection Policy Foundation
Base: Gate #327 canonical GOLDEN, Live Market Universe quote-volume ordering policy.

Owns one provider-neutral deterministic selection/config responsibility above released ordering: default count 30 inside policy, strict positive-integer explicit count validation, exact prefix selection preserving already-ordered sequence, non-mutating result, and count-above-availability returning all available facts.

Non-scope: no quote-volume ordering/tie-break, eligibility/USDT/stablecoin policy, provider transport/decode/mapping, freshness/cadence, state/persistence, Home/Bubble/Your Trades UI, chart, navigation, or transitions.
