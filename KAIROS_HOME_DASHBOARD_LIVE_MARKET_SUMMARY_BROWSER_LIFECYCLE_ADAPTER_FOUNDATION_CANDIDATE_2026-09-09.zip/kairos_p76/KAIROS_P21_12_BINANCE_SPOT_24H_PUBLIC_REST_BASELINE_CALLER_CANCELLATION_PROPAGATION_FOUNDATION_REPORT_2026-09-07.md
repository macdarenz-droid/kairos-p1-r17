# KAIROS P21.12 — Binance Spot 24h Public REST Baseline Caller Cancellation Propagation Foundation

## Authority
Base: canonical P21.11 round-trip composition, canonical gate #296 / run `34100573164`.

## Source-proven responsibility
P21.4 already exposes optional caller cancellation through `AbortSignal`, but canonical P21.8/P21.11 cannot carry that signal to an injected connector. The smallest dependency-safe prerequisite before a concrete P21.4 adapter is propagation only: accept optional caller-owned execution options and forward the exact signal unchanged across P21.8 and P21.11.

Current Fetch API behavior supports request cancellation by passing an `AbortSignal` as the request `signal`; concrete fetch remains outside this slice.

## Contract
- Existing calls without options preserve their exact one-argument connector invocation, including the P21.11-to-P21.8 delegation path.
- Supplied P21.8 execution options are forwarded unchanged to the injected connector exactly once.
- P21.11 forwards the same options into P21.8 only when options are supplied.
- Connector result/rejection behavior remains unchanged.

## Explicit non-scope
- No concrete fetch/XHR/WebSocket/browser transport and no `Response`/status/header/body acquisition.
- No `AbortController` creation, signal combination, timeout, abort interpretation, or error translation.
- No concrete P21.4 acquisition-port implementation yet.
- No retry/backoff/throttle/rate-limit/request-weight/credentials/polling/reconnect.
- No new request/decode/ticker/completeness algorithm, scope selection/ranking, state, Bubble/Your-Trades/Home/persistence/transitions.
