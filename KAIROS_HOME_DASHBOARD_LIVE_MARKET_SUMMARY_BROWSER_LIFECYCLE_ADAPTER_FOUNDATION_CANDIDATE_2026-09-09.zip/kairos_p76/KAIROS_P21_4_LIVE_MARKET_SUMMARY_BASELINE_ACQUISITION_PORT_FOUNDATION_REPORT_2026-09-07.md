# KAIROS P21.4 — Live Market Summary Baseline Acquisition Port Foundation

## Authority
Base: canonical P21.3 Live Market Summary Delivery Completeness Contract Foundation, `Kairos Controlled Roadmap Gate` #288 / run `34069156361`.

## Source-backed responsibility
P21.3 can state that a delivery is `complete-for-scope`, but canonical source has no provider-neutral producer for that baseline. Current all-market mini-ticker delivery is incremental changed-symbol evidence, so downstream state must not infer initialization from one incremental event. P21.4 introduces only the missing acquisition port.

## Contract
- The caller supplies the explicit instrument scope.
- `LiveMarketSummaryBaselineAcquisitionPort.acquireBaseline(scope, options)` returns an async result.
- Failure is explicit as `acquisition-failed`.
- A success carries only a P21.3 `complete-for-scope` delivery.
- `validateLiveMarketSummaryBaselineSuccess` reuses P21.3 delivery validation and rejects a delivery whose declared scope does not exactly match the caller request.
- Scope order is not authoritative; scope membership is.

## Ownership
The port stays in the existing market-data acquisition/service boundary. It does not alter the existing P15 single-instrument subscription contract, choose a product universe, or move acquisition into Home/Bubble UI.

## Explicit non-scope
- No Binance implementation, endpoint mapping, REST-vs-WebSocket decision, polling, subscription, or reconnect behavior.
- No market-universe selection/ranking policy.
- No accumulator/state store, event ordering, freshness TTL, reset/reconnect state machine, or persistence.
- No Bubble Map sizing, color, grouping, filtering, geometry, interaction, or Home wiring.
- No journal reads, Your Trades Bubble Map semantics, P11/P12/P14/P16 duplication, or direct IndexedDB UI access.
- No dashboard transition/motion implementation.
