# KAIROS P21.5 — Binance Spot 24h Summary Fact Mapping Foundation

## Authority
Base: canonical P21.4 Live Market Summary Baseline Acquisition Port Foundation, `Kairos Controlled Roadmap Gate` #289 / run `34072260372`.

## Responsibility
P16 already separates provider payload mapping from endpoint and browser transport. P21.5 adds only the missing pure Binance Spot 24h ticker-entry mapper into canonical P21.2 `LiveMarketSummaryFact` truth. Caller-owned `observedAt` remains outside provider mapping clock ownership.

## Mapping
`symbol` -> instrument symbol at existing `BINANCE_SPOT_VENUE`; `lastPrice` -> `lastPrice`; `openPrice` -> `open24h`; `highPrice` -> `high24h`; `lowPrice` -> `low24h`; `volume` -> `baseVolume24h`; `quoteVolume` -> `quoteVolume24h`; valid `closeTime` -> ISO `sourceTimestamp`. Canonical P21.2 fact validation is reused before success.

## Explicit non-scope
- No HTTP/fetch, REST URL/query construction, endpoint selection, symbol batching, or request-weight policy.
- No P21.4 acquisition-port implementation, polling, subscription, retry, reconnect, credentials, or rate-limit policy.
- No market-universe selection/ranking or accumulator/state/freshness/reset ownership.
- No Bubble Map metric/color/grouping/filtering/geometry/interactions or Home wiring.
- No persistence, journal/Your-Trades semantics, direct IndexedDB UI access, or dashboard transition motion.
