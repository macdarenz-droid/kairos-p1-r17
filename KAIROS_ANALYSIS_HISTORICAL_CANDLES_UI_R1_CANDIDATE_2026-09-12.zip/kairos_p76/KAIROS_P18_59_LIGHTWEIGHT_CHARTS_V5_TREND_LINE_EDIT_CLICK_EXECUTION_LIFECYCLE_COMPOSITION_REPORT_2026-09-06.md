# KAIROS P18.59 — Lightweight Charts v5 Trend-Line Edit Click Execution Lifecycle Composition

Date: 2026-09-06  
Authoritative base: **P18.58 — Lightweight Charts v5 Trend-Line Edit Endpoint-Click Lifecycle Composition**  
Canonical base evidence: **Kairos Controlled Roadmap Gate #269 / run 33977995596 / head a26c9c718da88c39b4d633c060004a8dbe3dab76 — SUCCESS**  
Canonical base artifacts: **KAIROS_CURRENT_CANDIDATE 9973007019 / KAIROS_GATE_EVIDENCE 9973007322**

## Source-derived missing seam

Canonical P18.58 closes edit **initiation** inside the existing single provider click lifecycle: an endpoint click on the already-selected trend line may enter authoritative `editing` state through P18.57/P18.56/P18.54. Canonical source also already contains the downstream committed edit path:

- P18.50 executes an edit only from authoritative `editing` state plus one provider-neutral replacement anchor;
- P18.51R3 composes successful P18.50 execution into the existing P18.47 drawing-only presentation refresh;
- P18.25R1/P18.26/P18.27 already project each provider click into one provider-neutral market anchor after the raw P18.40 click observer runs.

Fresh canonical P18.58 source search found no production lifecycle composition that routes a later projected click anchor through P18.51R3 when editing is already authoritative. Without that seam, endpoint initiation can enter `editing`, but the existing provider click lifecycle never reaches the already-built edit execution/presentation owner.

The source also proves an ordering hazard: P18.40 deliberately invokes the raw click observer **before** projecting/delivering the anchor for the same click. If edit execution were keyed only off post-observer state, the endpoint-initiation click would enter `editing` and immediately execute a zero-movement edit from its own anchor. P18.59 therefore must preserve **pre-click editing-state evidence** for exactly one projected-anchor delivery.

No new Lightweight Charts API behavior is introduced or assumed. This slice uses only canonical P18.40 click ordering, P18.25R1 anchor projection, and P18.51R3 execution/presentation APIs, so external provider research is not required.

## P18.59 responsibility

P18.59 extends the existing `createLightweightChartsV5TrendLineDraftInteractionFromBinding(...)` lifecycle with one optional execution configuration:

`LightweightChartsV5TrendLineEditClickExecutionLifecycleOptions`

- `collection`: the existing P18.33/P18.44 committed drawing collection session;
- `presentation`: the existing P18.46/P18.47 drawing-refresh presentation session.

For each raw provider click, the composition snapshots whether the authoritative interaction session was already `editing` **before** P18.58 endpoint initiation and P18.42 selection coordination run.

Then, when P18.25R1 delivers that same click's projected anchor:

1. if pre-click state was already `editing` and execution configuration exists:
   - null anchor fails closed and leaves editing state authoritative;
   - valid anchor delegates exactly once to P18.51R3 `executeChartTrendLineEditAndRefreshPresentation(...)`;
2. otherwise, the anchor continues through the unchanged P18.29 draft-interaction path.

The one-event routing flag is cleared before edit execution so a thrown presentation error cannot leave stale same-event routing evidence behind.

## Same-click safety invariant

P18.59 never lets the endpoint-initiation click execute its own edit.

- pre-click `selected` + endpoint hit -> P18.58 may enter `editing`, but the same click's anchor remains non-executing;
- a later provider click observed while already `editing` -> its projected anchor may execute P18.51R3;
- a null replacement anchor -> no mutation, no refresh, editing state remains available for a later valid retry click.

This keeps P18.23/P18.24 authoritative transition/state ownership intact and avoids inventing a second gesture state machine.

## Ownership preservation

- P18.26 remains sole `subscribeClick` / `unsubscribeClick` owner.
- P18.27/P18.40 remain provider binding and raw-click-before-anchor fan-out owners.
- P18.25R1 remains provider click -> market anchor projection owner.
- P18.58 remains selected endpoint edit-initiation lifecycle composition.
- P18.50 remains committed edit-execution coordinator.
- P18.51R3 remains successful edit -> drawing-only presentation refresh coordinator.
- P18.33/P18.44 remain committed drawing collection/mutation owners.
- P18.46/P18.47 remain drawing-only presentation refresh owners.
- P18.23/P18.24 remain transition/current interaction-state owners.
- P18.59 owns only pre-click `editing` evidence -> same lifecycle projected anchor -> existing P18.51R3 delegation.

## Historical P18.58 verifier compatibility amendment

P18.58's dedicated historical verifier previously treated the literal absence of `executeChartTrendLineEditAndRefreshPresentation(...)` from the lifecycle composition module as part of P18.58 non-scope. P18.59 intentionally extends that same lifecycle owner with downstream edit execution composition, so retaining the literal absence check would make the historical verifier reject the legitimate later owner extension.

The P18.58 verifier is minimally amended to preserve its actual historical ownership guarantees while allowing later P18.59 composition **only when it delegates to the canonical P18.51R3 owner**. It still rejects direct edit execution, direct collection mutation, direct projection, duplicate subscription, direct start-editing dispatch, persistence, and P19 leakage.

This is verifier compatibility maintenance inside the P18.59 candidate, not evidence that canonical P18.58 was defective.

## Explicit non-scope

No second click subscription; no new pointer/drag lifecycle; no new interaction state/event/reducer; no direct drawing-ID or endpoint input at execution time; no direct collection mutation implementation; no direct drawing projection implementation; no direct presentation-refresh implementation; no persistence/restore/P20; no undo/redo; no toolbar/handle styling; no new drawing kind; no Risk/Reward/P19 semantics; no journal/calculation/navigation truth; no toolchain/dependency migration.

## Focused runtime evidence

The P18.59 focused test proves:

- endpoint-initiation click enters authoritative `editing` but does not mutate or refresh on that same click;
- a later provider click while editing projects one replacement anchor, delegates through P18.51R3, commits the edited endpoint, refreshes drawing presentation exactly once, and resets interaction to idle;
- a null replacement anchor fails closed, preserves committed truth and editing state, and allows a later valid retry click;
- the composition still owns no second provider subscription and destroy remains one exact unsubscribe lifecycle.

## Canonical promotion requirement

Promotion requires exact P18.58 -> P18.59 controlled scope, deterministic npm install, Node 22.16.0, npm 10.9.2, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.59 verifier/runtime, historical P18.58/P18.57/P18.51R3/P18.50/P18.42/P18.40/P18.26 compatibility, focused P18.59 tests, full unit regression, full controlled roadmap regression through P18.59, P18.59 -> P17 chart regressions, historical closures, candidate artifact, and gate evidence.

## Local/static evidence actually completed before packaging

PASS:
- dedicated P18.59 verifier;
- historical P18.58 verifier after the controlled compatibility amendment;
- historical P18.57, P18.51R3, P18.50, P18.42, P18.40, and P18.26 verifier contracts;
- all P18 verifier contracts through P18.59: **59/59**;
- P1 toolchain contract: **Node 22.16.0 / npm 10.9.2**;
- P1 static contract: **216 source files / 17 pinned package versions**;
- P1 gate-result classifier.

A broader local P2-P18 verifier sweep was attempted after the above passes but exceeded the local command transport window before a complete aggregate result was returned. No complete broad-sweep PASS is claimed from that timed-out attempt. No `node_modules` or `dist` residue exists in the candidate worktree. Canonical GitHub Actions remains the promotion authority for deterministic install, TypeScript, production build, focused Vitest, full units, full roadmap regression, P18->P17 regressions, historical closures, and artifacts.
