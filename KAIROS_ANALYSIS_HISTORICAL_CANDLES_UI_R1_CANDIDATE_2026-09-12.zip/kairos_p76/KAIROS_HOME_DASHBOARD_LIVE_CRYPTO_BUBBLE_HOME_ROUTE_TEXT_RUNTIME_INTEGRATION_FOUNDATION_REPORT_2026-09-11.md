# Kairos Home Dashboard Live Crypto Bubble Home Route Text Runtime Integration Foundation Report — 2026-09-11

## Authority

This candidate starts only from the exact Gate362 canonical GOLDEN candidate `KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_RUNTIME_PRODUCT_POLICY_FOUNDATION_CANDIDATE_2026-09-11.zip`, size `1,681,458` bytes, SHA-256 `ed812610da32a163627e77f539f749a54f0a09f316010208e3d290e113a1475b`, root exactly `kairos_p76/`.

Gate362 canonically releases the user-approved default runtime product policy. Gate361 already canonically releases the configured browser textual-evidence runtime immediately below eventual Home route integration. This slice connects those two released owners at `HomeRoute` without introducing another product, provider, data, persistence or renderer owner.

## Released responsibility

`src/app/HomeRoute.tsx` performs only the route-level composition required to make the already-released truthful Live Crypto textual evidence observable from the existing `/` Home route:

1. request the exact released Gate362 default product configuration through `createHomeDashboardLiveCryptoBubbleDefaultRuntimeProductConfiguration()` exactly once per HomeRoute render;
2. pass that exact configuration reference into Gate361 `HomeDashboardLiveCryptoBubbleConfiguredTextEvidenceRuntime` exactly once; and
3. replace the stale disconnected-dashboard placeholder with the released Live Crypto textual-runtime consumer.

The route does not copy or reinterpret the stablecoin exclusions or neutral threshold. The exact released Gate362 default product configuration remains the sole owner of those values.

## Preserved ownership and regressions

The P21.1 Home-route ownership verifier is minimally evolved so it continues proving the `/` route belongs to `HomeRoute`, preserves the route shell/accessibility boundary, and now recognises the canonically released textual-runtime integration rather than requiring the obsolete disconnected placeholder.

The generic router-shell test mocks only the configured Live Crypto runtime boundary so route navigation remains a deterministic unit test and never performs real market-network acquisition as a side effect of testing route headings. A dedicated regression independently proves that HomeRoute invokes the Gate362 factory once and forwards the exact returned configuration reference into Gate361 once.

## Explicit non-scope

- No Bubble geometry, palette, radius, collision, layout or motion.
- No square-root radius conversion or viewport-specific min/max radius selection.
- No provider/request/response/acquisition/retry changes.
- No ranking, Top-N, stablecoin, movement or freshness recalculation.
- No timers, clocks, lifecycle or cadence ownership.
- No IndexedDB, persistence or Saved Analysis changes.
- No Your Trades, journal, chart, Risk/Reward or Calculation Brain changes.
- No navigation ownership change beyond the already-released `/` → `HomeRoute` route.

Live Crypto Bubble and Your Trades remain separate truth domains. The approved later renderer policy remains outside this textual route integration.
