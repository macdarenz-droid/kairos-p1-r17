# Binance Home Dashboard Live Market Summary Scoped Snapshot Acquisition Port Adapter Foundation

## Authority
Base: exact canonical patch-numberless Home Dashboard Live Market Summary Scoped Snapshot Acquisition Port Contract Foundation promoted by gate #309 / run `34170279174`.

## Source-proven responsibility
The canonical Home port explicitly leaves provider binding to a later adapter. Released P21.23 already owns Binance browser acquisition into an existing released state session followed by the exact caller-scoped snapshot read. The smallest dependency-safe responsibility is a provider-owned adapter that binds those two already-released seams without moving provider semantics into Home presentation.

## Contract
- Accept an existing released `LiveMarketSummaryStateSession` and caller-owned released Binance `readObservedAt` at adapter binding time.
- Return the canonical `HomeDashboardLiveMarketSummaryScopedSnapshotAcquisitionPort`.
- Each `acquire(scope, options?)` delegates exactly once to released P21.23 using the same session, `readObservedAt`, exact scope and options.
- Return the released P21.23 Promise/result unchanged; add no semantic translation.

## Explicit non-scope
No new session creation/reset/lifecycle ownership; no clock/readObservedAt creation; no Home React wiring/hooks/effects/UI state; no default universe/scope; no ranking/filtering/grouping/sorting/top-N/popularity/market-cap; no Bubble presentation; no Your Trades/journal ownership; no freshness/TTL/polling/reconnect/scheduling/background work; no new transport/endpoint/status/header/error/retry/rate-limit/timeout/credentials policy; no new AbortController/signal-combination/concurrency/coalescing/subscription framework; no persistence/IndexedDB/Saved Analysis/chart/navigation/transition ownership; no duplication or reinterpretation of released P21.23 semantics.
