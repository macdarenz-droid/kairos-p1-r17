# Kairos Home Dashboard Live Crypto Bubble Configured Browser Pixel-Radius Hook Composition Foundation

## Authority

Base: canonical Gate379 browser pixel-radius hook composition foundation.

## Responsibility

This slice owns exactly one thin configured browser React pixel-radius hook composition edge between released runtime-options composition and released Gate379 browser pixel-radius hook composition.

`useHomeDashboardLiveCryptoBubbleConfiguredBrowserPixelRadiusViewModel(...)`:
- accepts one exact caller-owned product configuration through `HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration`;
- accepts one exact caller-owned `HomeDashboardLiveCryptoBubblePixelRadiusPolicy` reference;
- delegates that exact product configuration once to `composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions(...)`;
- passes the exact returned runtime-options object and exact caller pixel-radius policy once to `useHomeDashboardLiveCryptoBubbleBrowserPixelRadiusViewModel(...)`; and
- returns the exact released Gate379 pixel-radius view-model result unchanged.

Runtime-options composition remains the only owner that translates product configuration into runtime binding options. Gate379 remains the browser pixel-radius hook-composition owner. This boundary does not inspect, clone, validate, default, or reinterpret the stablecoin exclusion set, neutral-movement threshold, or pixel-radius policy.

## Explicit non-scope

No concrete stablecoin exclusion, neutral-movement value, minimum/maximum pixel radius, responsive breakpoint or viewport value is selected here. No Top-N default. No browser lifecycle override. No state/effects/memo/callback/ref owner. No clocks, timers, page visibility, provider request/acquisition/retry/cadence, or freshness ownership. No radius arithmetic or policy validation. No viewport/DOM read, collision/packing/layout, labels, interactions, SVG/canvas, CSS/theme/palette/dimming, or animation. No `HomeRoute` mutation. No persistence/Saved Analysis. No Your Trades Bubble Map, journal/trade truth, chart, Risk/Reward, Calculation Brain, navigation, or transitions.

## Dependency ownership preserved

Runtime-options composition owns pure translation of the exact caller-owned product configuration into released runtime-binding options. Gate379 owns browser-clock injection into the released React pixel-radius path while accepting the exact caller-supplied pixel-radius policy. Gate375 remains pixel-radius projection arithmetic owner and Gate374 remains pixel-radius policy validation owner.

This slice closes only the unowned technical dependency edge from caller-owned runtime product configuration plus caller-owned pixel-radius policy to the released browser pixel-radius hook. Concrete responsive sizing defaults, viewport observation, collision/packing/layout and visible Bubble rendering remain later controlled presentation responsibilities.

Live Crypto Bubble Map and Your Trades Bubble Map remain separate authoritative truth domains.
