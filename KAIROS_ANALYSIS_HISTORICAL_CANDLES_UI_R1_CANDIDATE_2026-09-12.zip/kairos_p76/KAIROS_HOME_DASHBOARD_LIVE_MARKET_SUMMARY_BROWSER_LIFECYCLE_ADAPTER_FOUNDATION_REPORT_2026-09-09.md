# KAIROS Home Dashboard Live Market Summary Browser Lifecycle Adapter Foundation

## Authority
Base: canonical Gate331 Home Dashboard live-market acquisition lifecycle/scheduler orchestration GOLDEN.

## Source-proven responsibility
Gate331 deliberately owns provider-neutral lifecycle/scheduler orchestration but forbids concrete DOM/Page Visibility listeners and concrete timer APIs. Fresh repository search found no production Home/live-market Page Visibility owner. Existing browser/provider acquisition composition owns transport composition only. Current Kairos application bootstrap composes browser-facing infrastructure while browser APIs remain environment-edge concerns.

## Contract
This slice owns only the browser environment adaptation required to drive released Gate331:
- map current browser `document.visibilityState` to released visible/hidden lifecycle input;
- subscribe to `visibilitychange` and forward only visibility changes to Gate331;
- implement Gate331's injected one-shot scheduler through browser timeout APIs;
- enter the released lifecycle exactly once when the adapter is created;
- remove the exact listener and close released lifecycle work idempotently.

The adapter does not own the 5000ms product cadence, lifecycle race/cancellation policy, provider selection/transport, state-session construction, observedAt/freshness, universe filtering/order/Top-N, persistence, React/Home rendering, bubble geometry/color, navigation, or transitions.
