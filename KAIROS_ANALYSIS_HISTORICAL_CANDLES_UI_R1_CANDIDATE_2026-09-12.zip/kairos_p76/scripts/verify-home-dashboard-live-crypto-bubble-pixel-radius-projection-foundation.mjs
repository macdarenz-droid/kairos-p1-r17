import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const source = readFileSync('src/application/dashboard/homeDashboardLiveCryptoBubblePixelRadiusProjection.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-pixel-radius-projection-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_PIXEL_RADIUS_PROJECTION_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-pixel-radius-projection-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-pixel-radius-projection-foundation.mjs',
);

for (const required of [
  'HomeDashboardLiveCryptoBubblePixelRadiusProjectionEntry',
  'radiusScaleEntry: HomeDashboardLiveCryptoBubbleRadiusScaleProjectionEntry',
  'radiusCssPixels: number | null',
  'HomeDashboardLiveCryptoBubblePixelRadiusProjectionResult',
  'projectHomeDashboardLiveCryptoBubblePixelRadii',
  "reason: 'radius-scale-projection-invalid'",
  "reason: 'pixel-radius-policy-invalid'",
  "reason: 'pixel-radius-entry-invalid'",
  'validateHomeDashboardLiveCryptoBubblePixelRadiusPolicy(policy)',
  'entries.push({ radiusScaleEntry, radiusCssPixels: null })',
  'Number.isFinite(radiusScale)',
  'radiusScale < 0',
  'radiusScale > 1',
  'minimumRadiusCssPixels + radiusScale * radiusRangeCssPixels',
  'entries.push({ radiusScaleEntry, radiusCssPixels })',
  'radiusScaleProjection,',
  'policy,',
]) {
  assert.ok(source.includes(required), `pixel-radius projection missing exact evidence: ${required}`);
}

assert.equal(
  (source.match(/validateHomeDashboardLiveCryptoBubblePixelRadiusPolicy\(policy\)/g) ?? []).length,
  1,
  'pixel-radius projection must delegate policy validation exactly once',
);

for (const forbidden of [
  '.sort(', '.filter(', '.reverse(', 'Math.min(', 'Math.max(', 'clamp(',
  'DEFAULT_', 'defaultRadius', 'breakpoint', 'window.innerWidth', 'window.innerHeight',
  'ResizeObserver', 'getBoundingClientRect', 'matchMedia(',
  "from 'react'", 'useState', 'useEffect', 'useMemo', 'useRef',
  '<svg', '<circle', '<canvas', 'className=', 'style=', 'HomeRoute',
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'requestAnimationFrame(',
  'fetch(', 'WebSocket(', 'indexedDB', 'localStorage',
  'quoteVolume24h', 'movementPercent24h', 'Top 30', 'stablecoin',
  'freshMaxAgeMs', 'staleMaxAgeMs',
]) {
  assert.ok(!source.includes(forbidden), `pixel-radius projection broadened ownership: ${forbidden}`);
}

for (const evidence of [
  'interpolates normalized radius evidence only inside exact caller-supplied bounds while preserving references and order',
  'preserves caller choice of equal bounds without inventing visible size variation',
  'preserves an upstream radius-scale projection failure by exact reference before policy interpretation',
  'delegates invalid caller bounds to the released Gate374 policy validator without fallback values',
  'fails closed for %s radius-scale evidence instead of clamping it',
  'toEqual([10, 20, 30, 50, null])',
  'expect(entry.radiusScaleEntry).toBe(entries[index])',
]) {
  assert.ok(test.includes(evidence), `pixel-radius projection regression evidence missing: ${evidence}`);
}

for (const phrase of [
  'Gate374 canonical GOLDEN candidate',
  'pure provider-neutral pixel-radius projection boundary',
  'delegates the caller policy exactly once to released Gate374',
  'minimumRadiusCssPixels + radiusScale * (maximumRadiusCssPixels - minimumRadiusCssPixels)',
  'no default minimum or maximum Bubble radius values',
  'Live Crypto Bubble and Your Trades Bubble remain separate truth domains',
  'must not be guessed',
]) {
  assert.ok(report.includes(phrase), `pixel-radius projection report missing ownership evidence: ${phrase}`);
}

console.log('PASS: Home Live Crypto Bubble pixel-radius projection maps released normalized radius evidence only within caller-supplied Gate374-validated bounds, with no defaults, viewport/layout, renderer, route, market, persistence or Your Trades ownership.');
