import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const source = readFileSync('src/application/dashboard/homeDashboardLiveCryptoBubbleLayoutBoundsPolicy.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-layout-bounds-policy-contract-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_LAYOUT_BOUNDS_POLICY_CONTRACT_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-layout-bounds-policy-contract-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-layout-bounds-policy-contract-foundation.mjs',
);

for (const required of [
  'HomeDashboardLiveCryptoBubbleLayoutBoundsPolicy',
  'widthCssPixels: number',
  'heightCssPixels: number',
  'HomeDashboardLiveCryptoBubbleLayoutBoundsPolicyValidationResult',
  'validateHomeDashboardLiveCryptoBubbleLayoutBoundsPolicy',
  "reason: 'width-invalid'",
  "reason: 'height-invalid'",
  'Number.isFinite(policy.widthCssPixels)',
  'Number.isFinite(policy.heightCssPixels)',
  'return { ok: true, policy }',
]) {
  assert.ok(source.includes(required), `layout-bounds policy contract missing exact evidence: ${required}`);
}

for (const forbidden of [
  'DEFAULT_', 'defaultWidth', 'defaultHeight', 'breakpoint', 'window.', 'document.',
  'ResizeObserver', 'MutationObserver', 'getBoundingClientRect', 'matchMedia(',
  'requestAnimationFrame', 'setTimeout', 'setInterval', 'Math.', 'clamp',
  "from 'react'", 'useState', 'useEffect', 'useMemo', '<svg', '<circle', '<canvas',
  'className=', 'style=', 'HomeRoute', 'fetch(', 'WebSocket(', 'indexedDB', 'localStorage',
  'minimumRadiusCssPixels', 'maximumRadiusCssPixels', 'radiusScale', 'quoteVolume24h',
  'movementPercent24h', 'collision', 'packing', 'padding', 'gapCssPixels',
]) {
  assert.ok(!source.includes(forbidden), `layout-bounds policy contract broadened ownership: ${forbidden}`);
}

for (const evidence of [
  'accepts finite non-negative caller-owned bounds and preserves the exact policy reference',
  'accepts zero bounds without inventing minimum viewport or visibility semantics',
  'rejects %s without substituting fallback values',
  'expect(result.policy).toBe(policy)',
]) {
  assert.ok(test.includes(evidence), `layout-bounds policy regression evidence missing: ${evidence}`);
}

for (const phrase of [
  'Gate383 canonical GOLDEN candidate',
  'caller-owned layout-bounds policy contract and validator',
  'No default width or height values',
  'No viewport or element measurement',
  'No collision, packing, placement or renderer behavior',
  'Live Crypto Bubble and Your Trades Bubble remain separate truth domains',
]) {
  assert.ok(report.includes(phrase), `layout-bounds policy report missing ownership evidence: ${phrase}`);
}

console.log('PASS: Home Live Crypto Bubble layout-bounds policy foundation adds only caller-owned finite non-negative CSS-pixel bounds with no defaults, measurement, packing, renderer, route, market, persistence or Your Trades ownership.');
