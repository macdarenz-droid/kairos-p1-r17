import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/application/dashboard/homeDashboardLiveMarketSummaryScopedSnapshotAcquisitionPort.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_HOME_DASHBOARD_LIVE_MARKET_SUMMARY_SCOPED_SNAPSHOT_ACQUISITION_PORT_CONTRACT_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');
for (const token of [
  'readonly MarketDataInstrument[]',
  'readonly signal?: AbortSignal',
  'LiveMarketSummaryBaselineStateOrchestrationResult',
  'readonly LiveMarketSummaryScopedStateSnapshotEntry[]',
  'interface HomeDashboardLiveMarketSummaryScopedSnapshotAcquisitionPort',
  'Promise<HomeDashboardLiveMarketSummaryScopedSnapshotAcquisitionResult>',
]) if (!source.includes(token)) throw new Error(`port contract evidence missing: ${token}`);
for (const forbidden of [
  'binance', 'fetch(', 'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(',
  'WebSocket(', 'indexedDB', 'new AbortController(', '.sort(', '.filter(', '.reduce(',
  'React', 'useEffect', 'useState', 'createChart(',
]) if (source.includes(forbidden)) throw new Error(`port broadened into forbidden scope: ${forbidden}`);
if (/\b(class|function|const)\s+HomeDashboardLiveMarketSummaryScopedSnapshotAcquisitionPort\b/.test(source)) throw new Error('port contract must not implement an adapter');
for (const token of [
  'provider-neutral port contract outside React presentation',
  'Choose no provider, session, transport, universe, default scope, clock, ranking, freshness, retry, persistence, subscription, Bubble presentation, UI state, or transition behavior',
  'No Binance/provider adapter',
  'no Your Trades/journal ownership',
]) if (!report.includes(token)) throw new Error(`report evidence missing: ${token}`);
console.log('Home Dashboard Live Market Summary Scoped Snapshot Acquisition Port Contract verification passed.');
