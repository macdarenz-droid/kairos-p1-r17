import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const source = readFileSync('src/app/homeDashboardLiveCryptoBubbleRuntimeProductPolicy.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-runtime-product-policy-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_RUNTIME_PRODUCT_POLICY_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-runtime-product-policy-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-runtime-product-policy-foundation.mjs',
);

for (const required of [
  'HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_DEFAULT_EXCLUDED_STABLECOIN_BASE_ASSETS',
  'HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_DEFAULT_NEUTRAL_MAX_ABSOLUTE_MOVEMENT_PERCENT',
  'createHomeDashboardLiveCryptoBubbleDefaultRuntimeProductConfiguration',
  'HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration',
  "'USDC'", "'FDUSD'", "'XUSD'", "'USDS'", "'U'", "'TUSD'", "'USDP'", "'DAI'", "'EURI'", "'AEUR'",
  "'0.25' as DecimalString",
  'excludedStablecoinBaseAssets: new Set(',
]) {
  assert.ok(source.includes(required), `runtime product policy missing approved ownership evidence: ${required}`);
}

for (const forbidden of [
  "'USDT'", "'PAXG'", 'topNCount', 'lifecycle:',
  'Date.now(', 'new Date(', 'setInterval(', 'setTimeout(', 'requestAnimationFrame(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'indexedDB', 'localStorage',
  'HomeRoute', '<svg', '<circle', '<canvas', 'style=',
  'useState(', 'useEffect(', 'useMemo(', 'useCallback(',
]) {
  assert.ok(!source.includes(forbidden), `runtime product policy must not own forbidden behavior: ${forbidden}`);
}

for (const evidence of [
  "has('USDT')).toBe(false)",
  "has('PAXG')).toBe(false)",
  "toBe('0.25')",
  "expect('topNCount' in configuration).toBe(false)",
  "expect('lifecycle' in configuration).toBe(false)",
  'not.toBe(second.excludedStablecoinBaseAssets)',
]) {
  assert.ok(test.includes(evidence), `runtime product policy test missing regression evidence: ${evidence}`);
}

for (const phrase of [
  'exact approved default stablecoin base-asset exclusion set',
  'neutral threshold is exactly `0.25` percent absolute 24h movement',
  '`USDT` remains the required quote asset and is not excluded',
  '`PAXG` is not treated as a stablecoin',
  'Top-30 selection remains owned by the released universe policy',
  'No `HomeRoute` or visible Bubble renderer wiring',
]) {
  assert.ok(report.includes(phrase), `foundation report missing approved product-policy evidence: ${phrase}`);
}

console.log('PASS: Home Live Crypto Bubble runtime product policy owns only the approved default stablecoin exclusion set and 0.25% neutral threshold while preserving all released universe, lifecycle, provider, route, renderer, persistence, and Your Trades ownership boundaries.');
