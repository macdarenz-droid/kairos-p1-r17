import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { spawn } from 'node:child_process';
const require = createRequire(resolve(process.env.KAIROS_BROWSER_PACKAGE_DIR ?? '.', 'package.json'));
const { chromium } = require('playwright');
const evidence = resolve('.currency-guidance-evidence'); mkdirSync(evidence, { recursive: true });

const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', '--host', '127.0.0.1', '--port', '4178', '--strictPort'], { stdio: 'pipe' });
let log = ''; server.stdout.on('data', x => log += x); server.stderr.on('data', x => log += x);
let browser, page;
try {
  let ready = false;
  for (let i = 0; i < 100; i++) { try { if ((await fetch('http://127.0.0.1:4178/')).ok) { ready = true; break; } } catch {} await new Promise(r => setTimeout(r, 200)); }
  assert(ready, log);
  browser = await chromium.launch({ headless: true, ...(process.env.KAIROS_CHROMIUM_EXECUTABLE ? { executablePath: process.env.KAIROS_CHROMIUM_EXECUTABLE, args: ['--no-sandbox', '--disable-dev-shm-usage', '--no-zygote', '--single-process'] } : {}) });
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, timezoneId: 'Australia/Melbourne', reducedMotion: 'reduce' });
  page = await context.newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
  await page.route('https://**/*', route => route.abort());
  // Full production route tree, with test-only mounting; direct URLs and reloads
  // use BrowserRouter and the actual persisted browser database.
  await page.route('http://127.0.0.1:4178/**', route => route.request().resourceType() === 'document' ? route.fulfill({ contentType: 'text/html', body: '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0}</style><div id="execution-test-root"></div><script type="module">import RefreshRuntime from "/@react-refresh";RefreshRuntime.injectIntoGlobalHook(window);window.$RefreshReg$=()=>{};window.$RefreshSig$=()=>type=>type;window.__vite_plugin_react_preamble_installed__=true;const f=await import("/tests/fixtures/tradeReviewBrowser.tsx");await f.mount();</script>' }) : route.continue());
  const savedFacts = () => page.evaluate(async () => (await import('/tests/fixtures/tradeReviewBrowser.tsx')).readSavedFacts());
  const setup = async (symbol, status) => {
    await page.getByLabel(/^Symbol/).fill(symbol);
    for (const [name, value] of [['Market', 'crypto'], ['Direction', 'long'], ['Status', status]]) await page.getByLabel(new RegExp('^' + name)).selectOption(value);
    await page.getByLabel(/^Opened/).fill('2026-09-12T17:32');
    if (status === 'closed') await page.getByLabel(/^Closed/).fill('2026-09-12T18:32');
  };
  await page.goto('http://127.0.0.1:4178/journal');
  await setup('XRPUSD', 'closed');
  const field = () => page.getByRole('textbox', { name: 'Currency code', exact: true });
  const note = () => page.getByRole('note', { name: 'P&L guidance', exact: true });
  assert((await note().innerText()).includes('P&L will stay unavailable'));
  const empty = await savedFacts();
  for (const invalid of ['50 USD', '50', '$50']) {
    await field().fill(invalid); await page.getByRole('button', { name: 'Save trade', exact: true }).click();
    await page.getByRole('alert').waitFor();
    assert((await page.getByRole('alert').innerText()).includes('without an amount'));
    assert.equal(await field().inputValue(), invalid); assert.equal(await field().getAttribute('aria-invalid'), 'true');
    assert.deepEqual(await savedFacts(), empty);
  }
  const measurements = [];
  for (const width of [320, 390]) {
    await page.setViewportSize({ width, height: 844 }); let previous;
    for (const theme of ['kairos-depth', 'cosmic', 'ocean']) {
      await page.evaluate(async theme => (await import('/tests/fixtures/tradeReviewBrowser.tsx')).theme(theme), theme);
      await field().scrollIntoViewIfNeeded();
      const measured = await page.evaluate(() => {
        const note = document.querySelector('[aria-label="P&L guidance"]');
        const field = document.querySelector('input[aria-invalid="true"]');
        return { overflow: document.documentElement.scrollWidth > innerWidth, inputHeight: field.getBoundingClientRect().height, noteColor: getComputedStyle(note).color, noteHeight: note.getBoundingClientRect().height };
      });
      assert(!measured.overflow); assert(measured.inputHeight >= 44); assert(measured.noteHeight > 0);
      if (previous) assert.equal(measured.noteHeight, previous.noteHeight); previous = measured;
      measurements.push({ width, theme, ...measured });
      await page.screenshot({ path: resolve(evidence, `currency-${width}-${theme}.png`), fullPage: true });
    }
  }
  await page.setViewportSize({ width: 390, height: 844 });
  await field().fill('USD'); assert.equal(await field().getAttribute('aria-invalid'), null);
  await page.getByRole('button', { name: 'Save trade', exact: true }).click();
  await page.getByText('Trade saved to your journal.', { exact: true }).waitFor();
  const first = (await savedFacts()).trades[0]; assert.equal(first.grossPnlCurrency, 'USD');
  assert.equal((await savedFacts()).executions.length, 0);
  await page.getByRole('link', { name: 'View trade', exact: true }).click();
  await page.locator('[data-review-trade-id]').waitFor();
  assert.equal(await page.locator('[data-review-trade-id]').getAttribute('data-review-trade-id'), first.id);
  await page.getByText('No executions recorded.', { exact: true }).waitFor();
  await page.getByRole('link', { name: 'Back to Journal', exact: true }).click();
  await setup('BTCUSDT', 'open');
  await page.getByRole('button', { name: 'Add entry', exact: true }).click();
  for (const [label, value] of [['Entry 1 price', '100'], ['Entry 1 quantity', '2'], ['Entry 1 date and time', '2026-09-12T17:32']]) await page.getByLabel(label, { exact: true }).fill(value);
  await page.getByRole('button', { name: 'Save trade', exact: true }).click();
  await page.getByRole('button', { name: 'Update trade', exact: true }).click();
  const editor = page.getByRole('region', { name: 'Update BTCUSDT', exact: true });
  await editor.getByRole('combobox', { name: 'Trade status', exact: true }).selectOption('closed');
  await editor.getByLabel('Closed date & time', { exact: true }).fill('2026-09-12T18:32');
  assert((await editor.getByRole('note').innerText()).includes('No actual exit'));
  const updateField = editor.getByRole('textbox', { name: 'Currency code', exact: true });
  await updateField.fill('50 USD'); const before = await savedFacts();
  await editor.getByRole('button', { name: 'Save update', exact: true }).click();
  await editor.getByRole('alert').waitFor(); assert.deepEqual(await savedFacts(), before);
  assert.equal(await updateField.inputValue(), '50 USD'); assert.equal(await updateField.getAttribute('aria-invalid'), 'true');
  await updateField.fill('USDT');
  await editor.getByRole('button', { name: 'Add exit', exact: true }).click();
  assert.equal(await editor.getByRole('note').count(), 0);
  for (const [label, value] of [['Exit 1 price', '120'], ['Exit 1 quantity', '2'], ['Exit 1 date and time', '2026-09-12T18:32']]) await editor.getByLabel(label, { exact: true }).fill(value);
  await editor.getByRole('button', { name: 'Save update', exact: true }).click();
  await page.getByText('Trade updated. Your saved details are below.', { exact: true }).waitFor();
  await page.locator('.kairos-history-card').filter({ hasText: 'BTCUSDT' }).getByText('40 USDT', { exact: true }).first().waitFor();
  await page.reload();
  const after = await savedFacts(); assert.deepEqual(after.trades.find(t => t.id === first.id), first);
  assert.equal(after.trades.length, 2); assert.equal(after.executions.length, 2); assert.deepEqual(errors, []);
  writeFileSync(resolve(evidence, 'currency-guidance-browser-report.json'), JSON.stringify({ passed: true, source: 'actual save/update UI and production route tree', invalidInputsBlocked: ['50 USD', '50', '$50'], invalidWrites: 0, correctedCurrency: 'USD', noFillResultRemainsUnavailable: true, openUpdateGuarded: true, completeResult: '40 USDT', firstTradePreservedAfterReload: true, measurements, errors }, null, 2));
  console.log('PASS: amount-like currency blocked in save/update without writes; clear missing-fill guidance; corrected save/review/reload and real complete result; 320/390px across three themes.');
} catch (error) {
  if (page) { writeFileSync(resolve(evidence, 'failure.html'), await page.content()); await page.screenshot({ path: resolve(evidence, 'failure.png'), fullPage: true }); }
  throw error;
} finally { await browser?.close(); server.kill('SIGTERM'); }
