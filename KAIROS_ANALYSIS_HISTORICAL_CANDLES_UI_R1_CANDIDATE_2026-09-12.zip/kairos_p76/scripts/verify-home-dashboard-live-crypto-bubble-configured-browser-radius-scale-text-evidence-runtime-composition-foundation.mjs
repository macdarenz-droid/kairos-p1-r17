import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const component = readFileSync('src/app/HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime.tsx', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-configured-browser-radius-scale-text-evidence-runtime-composition-foundation.test.tsx', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_CONFIGURED_BROWSER_RADIUS_SCALE_TEXT_EVIDENCE_RUNTIME_COMPOSITION_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-configured-browser-radius-scale-text-evidence-runtime-composition-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-configured-browser-radius-scale-text-evidence-runtime-composition-foundation.mjs',
);

for (const required of [
  "import { HomeDashboardLiveCryptoBubbleRadiusScaleTextEvidence }",
  'readonly configuration: HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration',
  'useHomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleViewModel(configuration)',
  '<HomeDashboardLiveCryptoBubbleRadiusScaleTextEvidence model={model} />',
]) {
  assert.ok(component.includes(required), `configured radius text runtime missing exact released delegation: ${required}`);
}

assert.equal((component.match(/useHomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleViewModel\(configuration\)/g) ?? []).length, 1);
assert.equal((component.match(/<HomeDashboardLiveCryptoBubbleRadiusScaleTextEvidence/g) ?? []).length, 1);

for (const forbidden of [
  'composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions(',
  'new Set(', 'neutralMaxAbsoluteMovementPercent:', 'excludedStablecoinBaseAssets:', 'topNCount:', 'lifecycle:',
  'useState(', 'useEffect(', 'useMemo(', 'useCallback(',
  'Date.now(', 'new Date(', 'setInterval(', 'setTimeout(', 'requestAnimationFrame(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'indexedDB', 'localStorage',
  'Math.sqrt(', 'decimalDivide(', 'decimalMultiply(', 'parseDecimalString(',
  '<svg', '<circle', '<canvas', 'style=', "import './", 'HomeRoute',
]) {
  assert.ok(!component.includes(forbidden), `configured radius text runtime must not own forbidden behavior: ${forbidden}`);
}

assert.ok(test.includes('expect(configuredRadiusHookMock).toHaveBeenCalledTimes(1)'));
assert.ok(test.includes('expect(configuredRadiusHookMock).toHaveBeenCalledWith(configuration)'));
assert.ok(test.includes('expect(radiusTextEvidenceMock).toHaveBeenCalledTimes(1)'));
assert.ok(test.includes('expect(props.model).toBe(radiusScaleModel)'));

for (const phrase of [
  'exact caller-owned product configuration',
  'Gate369 remains configured browser radius-scale hook owner',
  'Gate371 remains normalized radius textual-evidence presenter owner',
  'No concrete pixel radius, breakpoint, collision, packing, or label-fit value',
  'No `HomeRoute` mutation',
]) {
  assert.ok(report.includes(phrase), `foundation report missing ownership evidence: ${phrase}`);
}

console.log('PASS: Home Live Crypto Bubble configured browser radius-scale textual runtime composes the exact caller configuration through released Gate369 hook truth into the released Gate371 presenter once while leaving product values, pixel geometry, layout, route, provider, state, and persistence ownership outside this boundary.');
