import { readFileSync } from 'node:fs';

const source = readFileSync('src/application/dashboard/homeDashboardLiveCryptoBubbleMetricObservationBridge.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-metric-observation-bridge-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_METRIC_OBSERVATION_BRIDGE_FOUNDATION_REPORT_2026-09-10.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'createHomeDashboardLiveCryptoBubbleMetricObservationSink',
  'HomeDashboardLiveMarketSummaryFreshnessObservationSink',
  'readonly freshnessObservation: HomeDashboardLiveMarketSummaryFreshnessObservation',
  'readonly bubbleMetricProjection: LiveCryptoBubbleMetricInputProjectionResult',
  'projectLiveCryptoBubbleMetricInputs(',
  'freshnessObservation.freshnessEvaluation',
  'freshnessObservation,',
  'bubbleMetricProjection,',
  'sink.onError?.(error)',
]) {
  if (!source.includes(token)) throw new Error(`Bubble metric observation bridge evidence missing: ${token}`);
}

for (const forbidden of [
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'fetch(', 'XMLHttpRequest', 'WebSocket(',
  'React', 'useEffect', 'useState', 'indexedDB', 'AbortController', '.sort(', '.filter(', '.reduce(',
  '15_000', '60_000', 'freshMaxAgeMs', 'staleMaxAgeMs', 'priceChangePercent', 'radius', 'palette', 'color:',
]) {
  if (source.includes(forbidden)) throw new Error(`Bubble metric observation bridge broadened ownership: ${forbidden}`);
}

for (const token of [
  'preserves the exact freshness observation and projects its exact freshness evaluation once',
  'keeps deterministic Bubble metric projection failure as observation data',
  'forwards the upstream error channel unchanged',
  'does not swallow downstream observation sink failures',
]) {
  if (!test.includes(token)) throw new Error(`Missing Bubble metric observation bridge regression: ${token}`);
}

for (const token of [
  'provider-neutral Home Dashboard Live Crypto Bubble metric-observation bridge',
  'exact original freshness-observation object',
  'Deterministic Gate343 projection failures remain observation data',
  'No React/Home/Bubble rendering',
]) {
  if (!report.includes(token)) throw new Error(`Bubble metric observation bridge report evidence missing: ${token}`);
}

const verifyName = 'verify:home-dashboard-live-crypto-bubble-metric-observation-bridge-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-home-dashboard-live-crypto-bubble-metric-observation-bridge-foundation.mjs') {
  throw new Error('Bubble metric observation bridge verifier registration mismatch');
}

console.log('PASS: Home Dashboard Live Crypto Bubble metric-observation bridge remains provider-neutral, observation-preserving, fail-closed, and presentation-free.');
