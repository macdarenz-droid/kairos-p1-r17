import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read=p=>readFileSync(p,'utf8');
const sizing=read('src/app/homeDashboardYourTradesSizing.ts'),view=read('src/app/HomeDashboardYourTrades.tsx');
for(const token of ['parseDecimalString','decimalSubtract(amount, maximum)','trade.currency','decimalDivide(amount, maximum)','Number(normalized.value)','currency-missing',"basis: 'unavailable'", "radius: .3, basis: 'loss'"]) assert(sizing.includes(token),token);
for(const token of ['decimal.js', 'fetch(', 'WebSocket', 'indexedDB', 'createKairosRepositories', 'calculateTradeMetrics', 'parseFloat(', 'Number(trade.amount)', 'Math.abs(']) assert(!sizing.includes(token),'Sizing must not own '+token);
for(const token of ['projectYourTradeBubbleSizes(trades)','sizes.slice(page*12,(page+1)*12)','layoutGlassViewportCircles','useHomeDashboardGlassMotion','same recorded currency']) assert(view.includes(token),token);
assert(!view.includes('Equal sizes'));
console.log('PASS: Your Trades uses currency-scoped relative profit weights, small losses, explicit missing evidence and existing layout/motion owners.');
