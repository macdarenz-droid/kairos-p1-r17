import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const source = readFileSync('src/application/dashboard/homeDashboardLiveCryptoBubblePixelRadiusPolicy.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-pixel-radius-policy-contract-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_PIXEL_RADIUS_POLICY_CONTRACT_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-pixel-radius-policy-contract-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-pixel-radius-policy-contract-foundation.mjs',
);

for (const required of [
  'HomeDashboardLiveCryptoBubblePixelRadiusPolicy',
  'minimumRadiusCssPixels: number',
  'maximumRadiusCssPixels: number',
  'HomeDashboardLiveCryptoBubblePixelRadiusPolicyValidationResult',
  'validateHomeDashboardLiveCryptoBubblePixelRadiusPolicy',
  "reason: 'minimum-radius-invalid'",
  "reason: 'maximum-radius-invalid'",
  "reason: 'radius-range-invalid'",
  'Number.isFinite(policy.minimumRadiusCssPixels)',
  'Number.isFinite(policy.maximumRadiusCssPixels)',
  'policy.maximumRadiusCssPixels < policy.minimumRadiusCssPixels',
  'return { ok: true, policy }',
]) {
  assert.ok(source.includes(required), `pixel-radius policy contract missing exact evidence: ${required}`);
}

for (const forbidden of [
  'radiusScale', 'Math.sqrt', 'Math.min', 'Math.max', 'clamp',
  'DEFAULT_', 'defaultRadius', 'breakpoint', 'window.innerWidth', 'window.innerHeight', 'ResizeObserver', 'getBoundingClientRect', 'matchMedia(',
  "from 'react'", 'useState', 'useEffect', 'useMemo', '<svg', '<circle', '<canvas',
  'className=', 'style=', 'HomeRoute', 'fetch(', 'WebSocket(', 'indexedDB', 'localStorage',
  'quoteVolume24h', 'movementPercent24h', 'Top 30', 'stablecoin', 'freshMaxAgeMs',
]) {
  assert.ok(!source.includes(forbidden), `pixel-radius policy contract broadened ownership: ${forbidden}`);
}

for (const evidence of [
  'accepts finite non-negative caller-owned bounds and preserves the exact policy reference',
  'accepts equal bounds without inventing a requirement that bubble size must vary',
  'rejects %s without substituting fallback values',
  'rejects a maximum below the minimum without reordering caller-owned values',
  'expect(result.policy).toBe(policy)',
]) {
  assert.ok(test.includes(evidence), `pixel-radius policy regression evidence missing: ${evidence}`);
}

for (const phrase of [
  'Gate373 canonical GOLDEN candidate',
  'policy contract and validator',
  'No default minimum or maximum Bubble radius values',
  'No interpolation from released `radiusScale`',
  'no concrete default values may be introduced until authoritative product/design policy supplies them',
  'Live Crypto Bubble and Your Trades Bubble remain separate truth domains',
]) {
  assert.ok(report.includes(phrase), `pixel-radius policy report missing ownership evidence: ${phrase}`);
}

console.log('PASS: Home Live Crypto Bubble pixel-radius policy foundation adds only a caller-owned finite non-negative bound contract with no defaults, radius arithmetic, layout, renderer, route, market, persistence or Your Trades ownership.');
