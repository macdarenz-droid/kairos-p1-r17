import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync('src/app/homeDashboardLiveCryptoBubbleBrowserWallClock.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-browser-wall-clock-sources-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_BROWSER_WALL_CLOCK_SOURCES_FOUNDATION_REPORT_2026-09-10.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const required of [
  'BinanceSpot24hPublicRestBaselineObservedAtSource',
  'HomeDashboardLiveMarketSummaryFreshnessEvaluationTimeSource',
  'readHomeDashboardLiveCryptoBubbleBrowserObservedAt',
  'readHomeDashboardLiveCryptoBubbleBrowserEvaluationTimeMs',
  'new Date(Date.now()).toISOString()',
  'Date.now()',
]) {
  assert.ok(source.includes(required), `browser wall-clock source missing required evidence: ${required}`);
}

for (const forbidden of [
  '15_000',
  '60_000',
  'freshMaxAgeMs',
  'staleMaxAgeMs',
  'excludedStablecoinBaseAssets',
  'topNCount',
  'neutralMaxAbsoluteMovementPercent',
  'setInterval(',
  'setTimeout(',
  'requestAnimationFrame(',
  'fetch(',
  'XMLHttpRequest',
  'WebSocket(',
  'useState(',
  'useEffect(',
  'indexedDB',
  'HomeRoute',
  'Math.sqrt(',
  '<svg',
  '<circle',
]) {
  assert.ok(!source.includes(forbidden), `browser wall-clock source must not own forbidden behavior: ${forbidden}`);
}

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-browser-wall-clock-sources-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-browser-wall-clock-sources-foundation.mjs',
);
assert.ok(test.includes('reads acquisition observation time and freshness evaluation time independently'));
assert.ok(test.includes('expect(observedAt).toBe(new Date(1_789_056_000_000).toISOString())'));
assert.ok(test.includes('expect(evaluationTimeMs).toBe(1_789_056_005_000)'));
assert.ok(report.includes('do not collapse acquisition observation time into later freshness-evaluation time'));
assert.ok(report.includes('owns only browser wall-clock source adaptation'));

console.log('PASS: Home Live Crypto Bubble browser wall-clock sources provide separate current-time adapters without absorbing freshness policy, market configuration, lifecycle, geometry, route, or persistence ownership.');
