import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const source = readFileSync('src/app/useHomeDashboardLiveCryptoBubblePresentationObservedRuntime.ts', 'utf8');
const dependencies = source.slice(source.lastIndexOf('  }, ['));
for (const input of [
  'readObservedAt,', 'readEvaluationTimeMs,',
  'options.universe.excludedStablecoinBaseAssets,',
  'options.universe.topNCount,', 'options.universe.signal,',
  'options.lifecycle?.document,', 'options.lifecycle?.timer,',
  'options.presentationPolicy.neutralMaxAbsoluteMovementPercent,',
]) assert.ok(dependencies.includes(input), `Missing lifecycle dependency: ${input}`);
for (const wrapper of ['options.universe,', 'options.lifecycle,', 'options.presentationPolicy,']) {
  assert.ok(!dependencies.includes(wrapper), `Unstable wrapper dependency: ${wrapper}`);
}
assert.equal((source.match(/useEffect\(/g) ?? []).length, 1);
assert.equal((source.match(/useState</g) ?? []).length, 1);
assert.ok(source.includes('if (!active) return;'));
assert.ok(source.includes('if (result.ok) result.runtime.close();'));
assert.ok(source.includes('closeRuntime?.();'));
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));
assert.equal(pkg.scripts['verify:home-dashboard-live-crypto-bubble-configured-runtime-lifecycle-stability-repair'], 'node scripts/verify-home-dashboard-live-crypto-bubble-configured-runtime-lifecycle-stability-repair.mjs');
console.log('PASS: one runtime effect follows caller inputs, preserves cleanup and ignores recreated configuration wrappers. Behavioral regression separately exercises both real configured hook paths and every mutable input.');
