import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { spawn } from 'node:child_process';
const require=createRequire(resolve(process.env.KAIROS_BROWSER_PACKAGE_DIR??'.','package.json'));
const {chromium}=require('playwright');
const evidence=resolve('.your-trades-sizing-evidence');mkdirSync(evidence,{recursive:true});
const server=spawn(process.execPath,['node_modules/vite/bin/vite.js','--host','127.0.0.1','--port','4181','--strictPort'],{stdio:'pipe'});
let log='',browser;server.stdout.on('data',b=>log+=b);server.stderr.on('data',b=>log+=b);
try {
  let ready=false;for(let i=0;i<100;i++){try{if((await fetch('http://127.0.0.1:4181/')).ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,100));}assert(ready,log);
  browser=await chromium.launch({headless:true,...(process.env.KAIROS_CHROMIUM_EXECUTABLE?{executablePath:process.env.KAIROS_CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage','--no-zygote','--single-process']}:{})});
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,deviceScaleFactor:1,reducedMotion:'reduce'});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.route('https://**/*',r=>r.abort());
  await page.route('http://127.0.0.1:4181/',r=>r.fulfill({contentType:'text/html',body:'<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0}</style><div id="sizing-root"></div><script type="module">import RefreshRuntime from "/@react-refresh";RefreshRuntime.injectIntoGlobalHook(window);window.$RefreshReg$=()=>{};window.$RefreshSig$=()=>type=>type;window.__vite_plugin_react_preamble_installed__=true;const f=await import("/tests/fixtures/yourTradesSizingBrowser.tsx");f.theme("kairos-depth");await f.seed();f.mount();</script>'}));
  await page.goto('http://127.0.0.1:4181/');await page.waitForFunction(()=>document.querySelectorAll('[data-glass-ready="true"]').length===6);
  const fixture=action=>page.evaluate(async action=>{const f=await import('/tests/fixtures/yourTradesSizingBrowser.tsx');return f[action]();},action);
  const saved=await fixture('snapshot');
  const geometry=()=>page.locator('.kairos-your-trades__bubble').evaluateAll(nodes=>nodes.map(n=>{const r=n.getBoundingClientRect();return {key:n.dataset.glassKey,label:n.getAttribute('aria-label'),x:r.x,y:r.y,width:r.width,height:r.height};}));
  const checkBounds=async()=>{const field=await page.locator('.kairos-glass-field').boundingBox();assert(field);const circles=await geometry();
    for(const c of circles){assert(c.width>=55.9,'Readable touch target');assert(c.x>=field.x-.6&&c.x+c.width<=field.x+field.width+.6,'Horizontal bounds');assert(c.y>=field.y-.6&&c.y+c.height<=field.y+field.height+.6,'Vertical bounds');}
    assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'No horizontal overflow');return circles;
  };
  const checkOrder=circles=>{const size=s=>circles.find(c=>c.label.startsWith(s+',')).width;assert(size('SOLUSDT')>size('ETHUSDT'));assert(size('ETHUSDT')>size('BTCUSDT'));assert(size('XRPUSDT')<size('BTCUSDT'));assert(size('BNBUSDT')===size('ADAUSDT'));};
  const measures=[];
  for(const width of [320,390,768]) {
    await page.setViewportSize({width,height:844});await page.waitForTimeout(180);
    for(const theme of ['kairos-depth','cosmic','ocean']) {
      await page.evaluate(async theme=>(await import('/tests/fixtures/yourTradesSizingBrowser.tsx')).theme(theme),theme);
      const circles=await checkBounds();checkOrder(circles);measures.push({width,theme,circles});
      await page.screenshot({path:resolve(evidence,`${width}-${theme}.png`),fullPage:true});
    }
  }
  await page.setViewportSize({width:390,height:844});await page.waitForTimeout(150);
  const loss=page.getByRole('button',{name:/XRPUSDT, long, Loss/});await loss.click();
  assert((await page.getByLabel('Selected trade',{exact:true}).innerText()).includes('-50 USDT'));
  await page.getByRole('button',{name:'Close details',exact:true}).click();
  await page.emulateMedia({reducedMotion:'no-preference'});await page.waitForTimeout(100);
  const cdp=await context.newCDPSession(page),big=page.getByRole('button',{name:/SOLUSDT, long, Profit/});
  const r=await big.boundingBox();assert(r);const start={x:r.x+r.width/2,y:r.y+r.height/2};
  const touch=(type,points=[])=>cdp.send('Input.dispatchTouchEvent',{type,touchPoints:points.map(p=>({...p,id:1,radiusX:3,radiusY:3,force:1}))});
  await touch('touchStart',[start]);await page.locator('[data-glass-dragging="true"]').waitFor();
  for(let i=1;i<=8;i++){await touch('touchMove',[{x:Math.max(40,start.x-i*8),y:start.y+i*6}]);await page.waitForTimeout(16);}
  await touch('touchEnd');await page.waitForTimeout(400);assert.equal(await page.locator('[data-glass-dragging="true"]').count(),0);
  assert.equal(await page.getByLabel('Selected trade',{exact:true}).count(),0);await checkBounds();
  assert.deepEqual(await fixture('snapshot'),saved,'Display/drag/theme must not mutate saved trades, executions or fees');
  await page.emulateMedia({reducedMotion:'reduce'});
  await fixture('increaseFirstProfit');await page.getByRole('button',{name:'Refresh',exact:true}).click();
  await page.waitForFunction(()=>{const nodes=[...document.querySelectorAll('.kairos-your-trades__bubble')];const size=s=>parseFloat(nodes.find(n=>n.getAttribute('aria-label').startsWith(s+',')).style.width);return nodes.length===6&&size('BTCUSDT')>size('SOLUSDT');});
  await page.getByRole('button',{name:/BTCUSDT, long, Profit/}).click();assert((await page.getByLabel('Selected trade',{exact:true}).innerText()).includes('20000 USDT'));
  await page.getByRole('button',{name:'Close details',exact:true}).click();
  await page.evaluate(async()=>{const f=await import('/tests/fixtures/yourTradesSizingBrowser.tsx');await f.seed(14);});
  await page.getByRole('button',{name:'Refresh',exact:true}).click();await page.waitForFunction(()=>document.querySelectorAll('.kairos-your-trades__bubble').length===12);
  await page.waitForTimeout(150);await checkBounds();await page.screenshot({path:resolve(evidence,'390-twelve-trades.png'),fullPage:true});
  const firstKeys=(await geometry()).map(x=>x.key);await page.getByRole('button',{name:'Next',exact:true}).click();await page.waitForFunction(()=>document.querySelectorAll('.kairos-your-trades__bubble').length===2);
  assert((await geometry()).every(x=>!firstKeys.includes(x.key)));await checkBounds();
  assert.deepEqual(errors,[]);
  writeFileSync(resolve(evidence,'report.json'),JSON.stringify({passed:true,source:'Production Your Trades with actual IndexedDB records and released P11/P13 results; Chromium touch emulation',relativeProfitOrder:true,smallLosses:true,unknownDistinct:true,savedFactsUnchanged:true,drag:true,refresh:true,pagination:true,measures,errors},null,2));
  console.log('PASS: real-browser profit sizes, currency-backed saved results, phone themes, drag, refresh, pagination and unchanged saved facts.');
}finally{await browser?.close();server.kill('SIGTERM');}
