import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpotExchangeInfoInstrumentMetadataFact.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_BINANCE_SPOT_EXCHANGE_INFO_INSTRUMENT_METADATA_FACT_MAPPING_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');

for (const token of [
  'BinanceSpotExchangeInfoInstrumentMetadataFactResult',
  'mapBinanceSpotExchangeInfoInstrumentMetadataFact',
  'validateLiveMarketUniverseInstrumentMetadataFact(fact)',
  'BINANCE_SPOT_VENUE',
  'payload.symbol',
  'payload.status',
  'payload.baseAsset',
  'payload.quoteAsset',
  "payload.status === 'TRADING'",
  "'payload-invalid'",
  "'symbol-invalid'",
  "'status-invalid'",
  "'base-asset-invalid'",
  "'quote-asset-invalid'",
]) if (!source.includes(token)) throw new Error(`exchangeInfo metadata mapper evidence missing: ${token}`);

if (!index.includes("export * from './providers/binance/binanceSpotExchangeInfoInstrumentMetadataFact';")) {
  throw new Error('exchangeInfo instrument metadata mapper barrel export missing');
}

for (const forbidden of [
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'JSON.parse(', 'decodeBinanceSpotExchangeInfoPublicRestResponse(',
  '.symbols', "quoteAsset === 'USDT'", "quoteAsset !== 'USDT'", '.filter(', '.sort(', 'quoteVolume24h',
  'Top 30', 'topN', 'stablecoin', 'setTimeout(', 'setInterval(', 'Date.now(', 'new Date(', 'indexedDB',
  'React', 'useEffect',
]) if (source.includes(forbidden)) throw new Error(`metadata mapper broadened into forbidden scope: ${forbidden}`);

for (const token of [
  'one already-decoded exchangeInfo symbol object',
  'maps exact Binance `TRADING` status to `tradingEnabled: true`',
  'maps any other non-empty provider status to `tradingEnabled: false`',
  'No whole-response or `symbols[]` traversal/composition',
  'No USDT eligibility filtering or symbol-suffix inference',
  'No stablecoin exclusion',
  'No 24h quote-volume lookup, ranking/sorting, symbol tie-break, Top-N/Top-30',
  'No freshness-age/classification changes',
  'No Home React wiring',
  'No Your Trades/journal ownership',
]) if (!report.includes(token)) throw new Error(`exchangeInfo metadata mapper report evidence missing: ${token}`);

console.log('Binance Spot exchangeInfo instrument metadata fact mapping verification passed.');
