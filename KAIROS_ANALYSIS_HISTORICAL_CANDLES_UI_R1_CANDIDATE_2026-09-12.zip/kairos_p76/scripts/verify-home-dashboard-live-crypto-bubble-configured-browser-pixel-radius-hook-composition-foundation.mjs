import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const source = readFileSync('src/app/useHomeDashboardLiveCryptoBubbleConfiguredBrowserPixelRadiusViewModel.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-configured-browser-pixel-radius-hook-composition-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_CONFIGURED_BROWSER_PIXEL_RADIUS_HOOK_COMPOSITION_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

const verifyName = 'verify:home-dashboard-live-crypto-bubble-configured-browser-pixel-radius-hook-composition-foundation';
assert.equal(
  pkg.scripts?.[verifyName],
  'node scripts/verify-home-dashboard-live-crypto-bubble-configured-browser-pixel-radius-hook-composition-foundation.mjs',
);

for (const required of [
  'useHomeDashboardLiveCryptoBubbleConfiguredBrowserPixelRadiusViewModel',
  'configuration: HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration',
  'policy: HomeDashboardLiveCryptoBubblePixelRadiusPolicy',
  'composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions(configuration)',
  'useHomeDashboardLiveCryptoBubbleBrowserPixelRadiusViewModel(options, policy)',
]) {
  assert.ok(source.includes(required), `Configured browser pixel-radius hook evidence missing: ${required}`);
}

assert.equal((source.match(/composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions\(configuration\)/g) ?? []).length, 1);
assert.equal((source.match(/useHomeDashboardLiveCryptoBubbleBrowserPixelRadiusViewModel\(options, policy\)/g) ?? []).length, 1);

for (const forbidden of [
  'new Set(', 'neutralMaxAbsoluteMovementPercent:', 'excludedStablecoinBaseAssets:', 'topNCount:', 'lifecycle:',
  'minimumRadiusCssPixels:', 'maximumRadiusCssPixels:',
  'useState(', 'useEffect(', 'useMemo(', 'useCallback(', 'useRef(',
  'Date.now(', 'new Date(', 'setInterval(', 'setTimeout(', 'requestAnimationFrame(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'indexedDB', 'localStorage',
  'Math.sqrt(', 'Math.pow(', 'radiusScale =', 'innerWidth', 'clientWidth', 'getBoundingClientRect(',
  '<svg', '<circle', '<canvas', 'className=', 'style=', 'HomeRoute', 'YourTrades',
]) {
  assert.ok(!source.includes(forbidden), `Configured browser pixel-radius hook must not own forbidden behavior: ${forbidden}`);
}

for (const phrase of [
  'delegates the exact caller configuration and pixel-radius policy into Gate379 exactly once',
  'returns the exact released Gate379 result unchanged',
  'does not retain a second configured pixel-radius result owner across rerenders',
]) {
  assert.ok(test.includes(phrase), `Missing configured browser pixel-radius regression: ${phrase}`);
}

for (const phrase of [
  'exact caller-owned product configuration',
  'exact caller-owned `HomeDashboardLiveCryptoBubblePixelRadiusPolicy` reference',
  'Gate379 remains the browser pixel-radius hook-composition owner',
  'No concrete stablecoin exclusion, neutral-movement value, minimum/maximum pixel radius',
  'Live Crypto Bubble Map and Your Trades Bubble Map remain separate authoritative truth domains',
]) {
  assert.ok(report.includes(phrase), `Foundation report missing ownership evidence: ${phrase}`);
}

console.log('PASS: configured browser pixel-radius hook delegates exact caller configuration and exact caller pixel-radius policy into Gate379 once without adding product values, pixel defaults, clocks, state, geometry, route, persistence, or Your Trades truth.');
