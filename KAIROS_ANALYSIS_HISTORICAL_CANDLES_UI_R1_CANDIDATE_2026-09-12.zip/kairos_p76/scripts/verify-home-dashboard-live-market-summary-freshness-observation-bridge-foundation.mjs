import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/application/dashboard/homeDashboardLiveMarketSummaryFreshnessObservationBridge.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_HOME_DASHBOARD_LIVE_MARKET_SUMMARY_FRESHNESS_OBSERVATION_BRIDGE_FOUNDATION_REPORT_2026-09-09.md', import.meta.url), 'utf8');

for (const token of [
  'createHomeDashboardLiveMarketSummaryFreshnessObservationObserver',
  'HomeDashboardLiveMarketSummaryFreshnessEvaluationTimeSource = () => number',
  'readonly acquisitionResult: HomeDashboardLiveMarketSummaryScopedSnapshotAcquisitionResult',
  'readonly freshnessEvaluation: LiveMarketSummaryFreshnessEvaluationProjectionResult',
  'evaluationTimeMs = readEvaluationTimeMs()',
  'evaluateLiveMarketSummaryScopedSnapshotFreshness(',
  'result.scopedSnapshot,',
  'acquisitionResult: result,',
  'freshnessEvaluation,',
  'sink.onError?.(error)',
]) if (!source.includes(token)) throw new Error(`freshness observation bridge evidence missing: ${token}`);

for (const forbidden of [
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'fetch(', 'XMLHttpRequest', 'WebSocket(',
  'document.', 'visibilityState', 'React', 'useEffect', 'useState', 'indexedDB', 'AbortController',
  '.sort(', '.filter(', '.reduce(', '15_000', '60_000', 'freshMaxAgeMs', 'staleMaxAgeMs',
]) if (source.includes(forbidden)) throw new Error(`freshness observation bridge broadened ownership: ${forbidden}`);

for (const token of [
  'provider-neutral non-presentation observation bridge',
  'original acquisition result and Gate338 freshness evaluation as separate fields',
  'Acquisition/session failure is never reinterpreted as stale/expired',
  'evaluation-time source itself throws',
  'No provider/Binance transport',
]) if (!report.includes(token)) throw new Error(`freshness observation bridge report evidence missing: ${token}`);

console.log('Home Dashboard Live Market Summary Freshness Observation Bridge Foundation verification passed.');
