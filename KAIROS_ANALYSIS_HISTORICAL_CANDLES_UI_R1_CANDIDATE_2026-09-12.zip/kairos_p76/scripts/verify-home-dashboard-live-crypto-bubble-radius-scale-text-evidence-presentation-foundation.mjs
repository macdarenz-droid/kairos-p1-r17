import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const component = readFileSync('src/app/HomeDashboardLiveCryptoBubbleRadiusScaleTextEvidence.tsx', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-radius-scale-text-evidence-presentation-foundation.test.tsx', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-radius-scale-text-evidence-presentation-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-radius-scale-text-evidence-presentation-foundation.mjs',
);

for (const required of [
  "import type { HomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel }",
  'readonly model: HomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel',
  'data-runtime-status={runtimeState.status}',
  'data-radius-projection-status="none"',
  'data-radius-projection-status="failed"',
  'data-radius-projection-status="available"',
  'entry.areaWeightEntry.presentationEntry.metricInput.instrument',
  'entry.radiusScale',
]) {
  assert.ok(component.includes(required), `component missing required released radius evidence use: ${required}`);
}

for (const forbidden of [
  'useHomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleViewModel',
  'useHomeDashboardLiveCryptoBubbleBrowserRadiusScaleViewModel',
  'useHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel',
  'useState(',
  'useEffect(',
  'useMemo(',
  'Date.now(',
  'new Date(',
  'setInterval(',
  'setTimeout(',
  'requestAnimationFrame(',
  'Math.sqrt(',
  'decimalDivide(',
  'decimalMultiply(',
  'parseDecimalString(',
  '<svg',
  '<circle',
  '<canvas',
  'style=',
  "import './",
  'HomeRoute',
  'indexedDB',
]) {
  assert.ok(!component.includes(forbidden), `component must not own forbidden behavior: ${forbidden}`);
}

assert.ok(test.includes('renderToStaticMarkup'));
assert.ok(test.includes("runtimeState('acquisition-failed'"));
assert.ok(test.includes("reason: 'radius-scale-entry-invalid'"));
assert.ok(test.includes("html.indexOf('BTCUSDT')"));
assert.ok(test.includes('radiusScale: null'));

console.log('PASS: Home Live Crypto Bubble radius-scale textual evidence presenter consumes released normalized radius truth without owning runtime, arithmetic, pixel geometry, layout, styling, route wiring, or persistence.');
