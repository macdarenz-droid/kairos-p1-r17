import { readFileSync } from 'node:fs';

const source = readFileSync('src/app/binanceHomeDashboardLiveCryptoBubblePresentationObservedRuntimeComposition.ts', 'utf8');
const test = readFileSync('tests/binance-home-dashboard-live-crypto-bubble-presentation-observed-runtime-composition-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_BINANCE_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_PRESENTATION_OBSERVED_RUNTIME_COMPOSITION_FOUNDATION_REPORT_2026-09-10.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'startBinanceHomeDashboardLiveCryptoBubblePresentationObservedRuntime',
  "extends Omit<BinanceHomeDashboardLiveCryptoBubbleObservedRuntimeCompositionOptions, 'observationSink'>",
  'readonly presentationPolicy: HomeDashboardLiveCryptoBubblePresentationPolicy;',
  'readonly observationSink?: HomeDashboardLiveCryptoBubblePresentationStateObservationSink;',
  'createHomeDashboardLiveCryptoBubblePresentationStateObservationSink(',
  'options.presentationPolicy,',
  'options.observationSink,',
  'startBinanceHomeDashboardLiveCryptoBubbleObservedRuntime(',
  'readObservedAt,',
  'readEvaluationTimeMs,',
  'universe: options.universe,',
  'lifecycle: options.lifecycle,',
  'observationSink,',
]) {
  if (!source.includes(token)) throw new Error(`Presentation-observed runtime composition evidence missing: ${token}`);
}

for (const forbidden of [
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'fetch(', 'XMLHttpRequest', 'WebSocket(',
  'React', 'useEffect', 'useState', 'indexedDB', 'AbortController', '.sort(', '.filter(', '.reduce(',
  '15_000', '60_000', 'freshMaxAgeMs', 'staleMaxAgeMs', 'priceChangePercent', 'radius', 'palette', 'color:',
  'projectHomeDashboardLiveCryptoBubblePresentationState(', 'createHomeDashboardLiveCryptoBubbleMetricObservationSink(',
]) {
  if (source.includes(forbidden)) throw new Error(`Presentation-observed runtime composition broadened ownership: ${forbidden}`);
}

for (const token of [
  'creates exactly one Gate349 semantic observation adapter and delegates once to Gate345 while preserving caller dependencies by reference',
  'preserves a failed Gate345 runtime result unchanged while owning the semantic adaptation slot without a downstream sink',
]) {
  if (!test.includes(token)) throw new Error(`Missing presentation-observed runtime regression: ${token}`);
}

for (const token of [
  'app-level Binance Home Live Crypto Bubble presentation-observed runtime composition',
  'constructs exactly one Gate349 semantic observation adapter',
  "returns Gate345's runtime bootstrap result unchanged",
  'No React/Home/Bubble rendering',
]) {
  if (!report.includes(token)) throw new Error(`Presentation-observed runtime report evidence missing: ${token}`);
}

const verifyName = 'verify:binance-home-dashboard-live-crypto-bubble-presentation-observed-runtime-composition-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-binance-home-dashboard-live-crypto-bubble-presentation-observed-runtime-composition-foundation.mjs') {
  throw new Error('Presentation-observed runtime composition verifier registration mismatch');
}

console.log('PASS: Binance Home Live Crypto Bubble presentation-observed runtime composes Gate349 into Gate345 without owning runtime or React presentation truth.');
