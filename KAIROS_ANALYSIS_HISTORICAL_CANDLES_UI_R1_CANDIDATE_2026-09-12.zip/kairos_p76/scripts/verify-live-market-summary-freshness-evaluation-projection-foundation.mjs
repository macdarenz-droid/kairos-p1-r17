import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/liveMarketSummaryFreshnessEvaluationProjection.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_LIVE_MARKET_SUMMARY_FRESHNESS_EVALUATION_PROJECTION_FOUNDATION_REPORT_2026-09-09.md', import.meta.url), 'utf8');

for (const token of [
  'evaluateLiveMarketSummaryScopedSnapshotFreshness',
  'readonly fact: LiveMarketSummaryFact | null',
  'readonly ageMs: number | null',
  'readonly freshness: LiveMarketSummaryFreshnessClassification | null',
  "'evaluation-time-invalid'",
  "'fact-invalid'",
  "'observation-after-evaluation'",
  'validateLiveMarketSummaryFact(entry.fact)',
  'Date.parse(entry.fact.observedAt)',
  'const ageMs = evaluationTimeMs - observedAtMs',
  'classifyLiveMarketSummaryObservationAge(ageMs, policy)',
]) if (!source.includes(token)) throw new Error(`freshness evaluation evidence missing: ${token}`);

if (!index.includes("export * from './liveMarketSummaryFreshnessEvaluationProjection';")) throw new Error('freshness evaluation public export missing');
for (const forbidden of [
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'fetch(', 'XMLHttpRequest', 'WebSocket(',
  'document.', 'visibilityState', 'React', 'useEffect', 'useState', 'indexedDB', 'AbortController',
  '.sort(', '.filter(', '.reduce(', '15_000', '60_000',
]) if (source.includes(forbidden)) throw new Error(`freshness evaluation broadened or duplicated policy: ${forbidden}`);
for (const token of [
  'provider-neutral deterministic freshness-evaluation projection below presentation',
  'Missing `fact: null` stays missing',
  'observation-after-evaluation',
  'Thresholds are not duplicated here',
  'No acquisition, provider/Binance transport',
]) if (!report.includes(token)) throw new Error(`freshness evaluation report evidence missing: ${token}`);
console.log('Live Market Summary freshness evaluation projection verification passed.');
