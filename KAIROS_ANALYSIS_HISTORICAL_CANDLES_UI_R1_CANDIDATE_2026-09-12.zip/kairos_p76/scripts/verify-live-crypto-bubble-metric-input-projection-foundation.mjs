import { readFileSync } from 'node:fs';

const source = readFileSync('src/services/market-data/liveCryptoBubbleMetricInputProjection.ts', 'utf8');
const barrel = readFileSync('src/services/market-data/index.ts', 'utf8');
const test = readFileSync('tests/live-crypto-bubble-metric-input-projection-foundation.test.ts', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

const requiredSource = [
  'projectLiveCryptoBubbleMetricInputs',
  'LiveMarketSummaryFreshnessEvaluationProjectionResult',
  'deriveLiveMarketSummary24hPercentageMovement',
  'quoteVolume24h: entry.fact.quoteVolume24h',
  'movementPercent24h: movement.movement.movementPercent24h',
  "reason: 'freshness-evaluation-invalid'",
  "reason: 'movement-derivation-invalid'",
  'entryIndex',
];
for (const token of requiredSource) {
  if (!source.includes(token)) throw new Error(`Missing metric-input projection contract token: ${token}`);
}
for (const forbidden of [
  'Date.now(',
  'setInterval(',
  'setTimeout(',
  'parseFloat(',
  'Number(entry.fact.quoteVolume24h)',
  'priceChangePercent',
  'stablecoin',
  'topN',
  'Top 30',
  'radius',
  'palette',
  'color:',
]) {
  if (source.includes(forbidden)) throw new Error(`Forbidden ownership widened into metric-input projection: ${forbidden}`);
}
if (!barrel.includes("export * from './liveCryptoBubbleMetricInputProjection';")) {
  throw new Error('Metric-input projection is not exported through market-data barrel');
}
for (const token of [
  'keeps a missing fact explicit with null metrics instead of inventing zero',
  'preserves request/association order without introducing ranking truth',
  'fails closed on upstream freshness-evaluation failure',
  'fails closed with the exact entry index',
  'preserves stale and expired classifications as data without applying visual policy',
]) {
  if (!test.includes(token)) throw new Error(`Missing required focused regression: ${token}`);
}
const verifyName = 'verify:live-crypto-bubble-metric-input-projection-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-live-crypto-bubble-metric-input-projection-foundation.mjs') {
  throw new Error('Metric-input projection verifier registration mismatch');
}
console.log('PASS: Live Crypto Bubble metric-input projection contract remains provider-neutral, fail-closed, ordered, missing-aware, and presentation-free.');
