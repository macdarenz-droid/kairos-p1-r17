import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { spawn } from 'node:child_process';
const require = createRequire(resolve(process.env.KAIROS_BROWSER_PACKAGE_DIR ?? '.', 'package.json'));
const { chromium } = require('playwright');
const evidence = resolve('.open-trade-evidence'); mkdirSync(evidence, { recursive: true });
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', '--host', '127.0.0.1', '--port', '4175', '--strictPort'], { stdio: 'pipe' });
let log = ''; server.stdout.on('data', x => log += x); server.stderr.on('data', x => log += x);
let browser, page;
try {
  let ready = false;
  for (let i = 0; i < 100; i++) { try { if ((await fetch('http://127.0.0.1:4175/')).ok) { ready = true; break; } } catch {} await new Promise(r => setTimeout(r, 200)); }
  assert(ready, log);
  browser = await chromium.launch({ headless: true, ...(process.env.KAIROS_CHROMIUM_EXECUTABLE ? { executablePath: process.env.KAIROS_CHROMIUM_EXECUTABLE, args: ['--no-sandbox', '--disable-dev-shm-usage', '--no-zygote', '--single-process'] } : {}) });
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, timezoneId: 'Australia/Melbourne', reducedMotion: 'reduce' });
  page = await context.newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
  await page.route('https://**/*', route => route.abort());
  await page.route('http://127.0.0.1:4175/', route => route.fulfill({ contentType: 'text/html', body: '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0}</style><div id="execution-test-root"></div><script type="module">import RefreshRuntime from "/@react-refresh";RefreshRuntime.injectIntoGlobalHook(window);window.$RefreshReg$=()=>{};window.$RefreshSig$=()=>type=>type;window.__vite_plugin_react_preamble_installed__=true;const f=await import("/tests/fixtures/journalExecutionBrowser.tsx");await f.mount();</script>' }));
  const savedFacts = () => page.evaluate(async () => (await import('/tests/fixtures/journalExecutionBrowser.tsx')).readSavedFacts());
  await page.goto('http://127.0.0.1:4175/');
  for (const [label, value] of [['Market','crypto'], ['Direction','long'], ['Status','open']]) await page.getByLabel(new RegExp('^' + label)).selectOption(value);
  await page.getByLabel(/^Symbol/).fill('BTCUSDT'); await page.getByLabel(/^Opened/).fill('2026-09-12T14:00');
  await page.getByRole('button', { name: 'Add entry', exact: true }).click();
  await page.getByLabel('Entry 1 price').fill('100'); await page.getByLabel('Entry 1 quantity').fill('2'); await page.getByLabel('Entry 1 date and time').fill('2026-09-12T14:00');
  await page.getByRole('button', { name: 'Save trade', exact: true }).click();
  await page.getByText('Trade saved to your journal.', { exact: true }).waitFor();
  const original = await savedFacts(); assert.equal(original.trades.length, 1); assert.equal(original.executions.length, 1);
  await page.reload(); await page.getByRole('button', { name: 'Update trade', exact: true }).click();
  let editor = page.getByRole('region', { name: 'Update BTCUSDT', exact: true });
  await editor.getByRole('button', { name: 'Add exit', exact: true }).click();
  await editor.getByLabel('Exit 1 price').fill('110'); await editor.getByLabel('Exit 1 quantity').fill('0.5'); await editor.getByLabel('Exit 1 date and time').fill('2026-09-12T14:30');
  await editor.getByRole('button', { name: 'Save update' }).click();
  await page.getByText('Trade updated. Your saved details are below.', { exact: true }).waitFor();
  let saved = await savedFacts(); assert.equal(saved.trades[0].status, 'open'); assert.equal(saved.executions.length, 2);
  assert.deepEqual(saved.executions.find(e => e.type === 'entry'), original.executions[0]);
  await page.reload(); await page.getByRole('button', { name: 'Update trade', exact: true }).click();
  editor = page.getByRole('region', { name: 'Update BTCUSDT', exact: true });
  await editor.getByRole('button', { name: 'Add exit', exact: true }).click();
  await editor.getByLabel('Exit 1 price').fill('120'); await editor.getByLabel('Exit 1 quantity').fill('1.5'); await editor.getByLabel('Exit 1 date and time').fill('2026-09-12T15:00');
  await editor.getByRole('combobox', { name: 'Trade status', exact: true }).selectOption('closed');
  await editor.getByLabel('Closed date & time', { exact: true }).fill('2026-09-12T15:00');
  const geometry = () => editor.locator('input,select,button').evaluateAll(nodes => nodes.filter(n => n.getClientRects().length).map(n => ({ width: n.getBoundingClientRect().width, height: n.getBoundingClientRect().height })));
  const initial = await geometry();
  for (const theme of ['kairos-depth', 'cosmic', 'ocean']) {
    await page.evaluate(async theme => (await import('/tests/fixtures/journalExecutionBrowser.tsx')).theme(theme), theme);
    assert.deepEqual(await geometry(), initial, 'Theme preserves geometry');
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'No horizontal overflow');
    await editor.evaluate(e => window.scrollTo(0, e.getBoundingClientRect().top + window.scrollY - 70));
    await page.screenshot({ path: resolve(evidence, `open-update-${theme}.png`), fullPage: false });
  }
  await page.setViewportSize({ width: 320, height: 740 });
  assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), '320px viewport contained');
  assert((await geometry()).every(g => g.width >= 80 && g.height >= 44), 'Readable mobile controls');
  await page.screenshot({ path: resolve(evidence, 'open-update-320.png'), fullPage: false });
  await page.setViewportSize({ width: 390, height: 844 });
  await editor.getByLabel('Exit 1 quantity').fill('0'); await editor.getByRole('button', { name: 'Save update' }).click();
  await editor.getByRole('alert').waitFor(); assert(await editor.getByRole('alert').evaluate(e => document.activeElement === e));
  assert.equal((await savedFacts()).executions.length, 2);
  await editor.getByLabel('Exit 1 quantity').fill('1.5'); await editor.getByRole('button', { name: 'Save update' }).click();
  await page.getByText('Trade updated. Your saved details are below.', { exact: true }).waitFor();
  saved = await savedFacts(); assert.equal(saved.trades.length, 1); assert.equal(saved.trades[0].id, original.trades[0].id);
  assert.equal(saved.trades[0].closedAt, '2026-09-12T05:00:00.000Z'); assert.equal(saved.executions.length, 3);
  assert.deepEqual(saved.executions.find(e => e.type === 'entry'), original.executions[0]);
  await page.reload(); await page.locator('.kairos-history-card').waitFor();
  assert.equal(await page.getByRole('button', { name: 'Update trade', exact: true }).count(), 0);
  await page.getByRole('link', { name: 'Home', exact: true }).click(); await page.getByRole('button', { name: 'Your Trades', exact: true }).click();
  await page.locator('.kairos-your-trades__bubble').click(); await page.getByText('35', { exact: true }).waitFor();
  await page.getByText('Currency not recorded', { exact: true }).waitFor();
  await page.screenshot({ path: resolve(evidence, 'updated-trade-result.png'), fullPage: true });
  assert.deepEqual(errors, []);
  writeFileSync(resolve(evidence, 'open-trade-browser-report.json'), JSON.stringify({ passed: true, source: 'real create-open/reload/append-partial-exit/reload/close UI; no seeded trades', originalTradeIdPreserved: true, originalEntryUnchanged: true, executions: 3, result: '35', currency: null, widths: [320,390], themes: 3, errors }, null, 2));
  console.log('PASS: existing open trade partial/final exits, validation, stable identity, reload, mobile themes and Your Trades result.');
} catch (error) {
  if (page) { writeFileSync(resolve(evidence, 'failure.html'), await page.content()); await page.screenshot({ path: resolve(evidence, 'failure.png'), fullPage: true }); }
  throw error;
} finally { await browser?.close(); server.kill('SIGTERM'); }
