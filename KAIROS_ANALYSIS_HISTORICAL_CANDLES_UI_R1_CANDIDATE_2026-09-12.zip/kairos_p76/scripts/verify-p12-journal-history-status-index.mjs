import { readFileSync } from 'node:fs';
const schema=readFileSync('src/data/database/schema.ts','utf8');
const migrations=readFileSync('src/data/database/migrations.ts','utf8');
const repo=readFileSync('src/data/repositories/TradeRepositories.ts','utf8');
const query=readFileSync('src/application/journal/historyQuery.ts','utf8');
const tests=readFileSync('tests/journal-history-query.test.ts','utf8');
const migrationTests=readFileSync('tests/database-migrations.test.ts','utf8');
const checks=[
 [schema.includes('KAIROS_DB_SCHEMA_VERSION = 4') && schema.includes('KAIROS_V3_STORES') && schema.includes("'&id,status,symbol,updatedAt,[status+updatedAt]'"), 'v3 compound index must be declared'],
 [migrations.includes('KAIROS_V3_MIGRATION') && migrations.includes('KAIROS_V3_STORES'), 'v3 migration must be append-only registered'],
 [repo.includes("where('[status+updatedAt]')") && repo.includes('.reverse()') && repo.includes('.limit(limit)'), 'repository must use compound indexed newest-first bounded path'],
 [query.includes('readonly status?: TradeStatus') && query.includes('listRecentByStatusAndUpdatedAt(options.status, normalizeHistoryLimit(options.limit))'), 'application query must delegate status filtering to repository'],
 [!query.includes('.filter('), 'application journal query must not filter trades in memory'],
 [tests.includes("status: 'draft', limit: 1") && tests.includes("DRAFT-NEW"), 'status bounded query regression fixture required'],
 [migrationTests.includes("toContain('[status+updatedAt]')"), 'live schema migration must prove index exists'],
];
for (const [ok,msg] of checks) { if(!ok){ console.error(`P12.4 verification FAIL: ${msg}`); process.exit(1); } }
console.log('P12.4 indexed journal status filter verification PASS');
