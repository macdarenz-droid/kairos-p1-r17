import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { spawn } from 'node:child_process';
const require = createRequire(resolve(process.env.KAIROS_BROWSER_PACKAGE_DIR ?? '.', 'package.json'));
const { chromium } = require('playwright');
const evidence = resolve('.execution-evidence'); mkdirSync(evidence, { recursive: true });
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', '--host', '127.0.0.1', '--port', '4174', '--strictPort'], { stdio: 'pipe' });
let log = ''; server.stdout.on('data', x => log += x); server.stderr.on('data', x => log += x);
let browser;
try {
  let ready = false;
  for (let i = 0; i < 100; i++) { try { if ((await fetch('http://127.0.0.1:4174/')).ok) { ready = true; break; } } catch {} await new Promise(r => setTimeout(r, 200)); }
  assert(ready, log);
  browser = await chromium.launch({ headless: true, ...(process.env.KAIROS_CHROMIUM_EXECUTABLE ? { executablePath: process.env.KAIROS_CHROMIUM_EXECUTABLE, args: ['--no-sandbox', '--disable-dev-shm-usage', '--no-zygote', '--single-process'] } : {}) });
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, timezoneId: 'Australia/Melbourne', reducedMotion: 'reduce' });
  const page = await context.newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
  await page.route('https://**/*', route => route.abort());
  await page.route('http://127.0.0.1:4174/', route => route.fulfill({ contentType: 'text/html', body: '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0}</style><div id="execution-test-root"></div><script type="module">import RefreshRuntime from "/@react-refresh";RefreshRuntime.injectIntoGlobalHook(window);window.$RefreshReg$=()=>{};window.$RefreshSig$=()=>type=>type;window.__vite_plugin_react_preamble_installed__=true;const f=await import("/tests/fixtures/journalExecutionBrowser.tsx");await f.mount();</script>' }));
  await page.goto('http://127.0.0.1:4174/'); await page.getByRole('button', { name: 'Save trade' }).waitFor();
  assert(await page.getByRole('button', { name: 'Add entry', exact: true }).isDisabled());
  await page.getByLabel('Symbol', { exact: false }).fill('BTCUSDT');
  await page.getByLabel('Market', { exact: false }).selectOption('crypto');
  await page.getByLabel('Direction', { exact: false }).selectOption('long');
  await page.getByLabel('Status', { exact: false }).selectOption('closed');
  await page.getByLabel(/^Opened/).fill('2026-09-12T14:00');
  await page.getByLabel(/^Closed/).fill('2026-09-12T15:00');
  for (const [type, index, price, time] of [['entry', 1, '100', '14:00'], ['exit', 2, '120', '15:00']]) {
    await page.getByRole('button', { name: `Add ${type}`, exact: true }).click();
    const title = `${type === 'entry' ? 'Entry' : 'Exit'} ${index}`;
    await page.getByLabel(`${title} price`, { exact: true }).fill(price);
    await page.getByLabel(`${title} quantity`, { exact: true }).fill('2');
    await page.getByLabel(`${title} date and time`, { exact: true }).fill(`2026-09-12T${time}`);
  }
  const geometry = () => page.locator('.kairos-executions input').evaluateAll(nodes => nodes.map(n => ({ width: n.getBoundingClientRect().width, height: n.getBoundingClientRect().height })));
  const initial = await geometry();
  for (const theme of ['kairos-depth', 'cosmic', 'ocean']) {
    await page.evaluate(async theme => (await import('/tests/fixtures/journalExecutionBrowser.tsx')).theme(theme), theme);
    assert.deepEqual(await geometry(), initial, 'Theme changes preserve field geometry');
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'No phone horizontal overflow');
    await page.locator('.kairos-executions').evaluate(e => window.scrollTo(0, e.getBoundingClientRect().top + window.scrollY - 70));
    await page.screenshot({ path: resolve(evidence, `execution-form-${theme}.png`), fullPage: false });
  }
  await page.setViewportSize({ width: 320, height: 740 });
  assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), '320px form stays within viewport');
  const controls = await geometry(); assert(controls.every(r => r.height >= 44 && r.width > 80), 'Readable fields and touch targets');
  await page.setViewportSize({ width: 390, height: 844 });
  // A save validation error must preserve all entered facts and focus its message.
  await page.getByLabel('Exit 2 quantity').fill('0'); await page.getByRole('button', { name: 'Save trade' }).click();
  await page.getByRole('alert').waitFor(); assert.equal(await page.getByLabel('Entry 1 price').inputValue(), '100');
  assert(await page.getByRole('alert').evaluate(e => e === document.activeElement));
  await page.getByLabel('Exit 2 quantity').fill('2'); await page.getByRole('button', { name: 'Save trade' }).click();
  await page.getByText('Trade saved to your journal.', { exact: true }).waitFor();
  const saved = await page.evaluate(async () => (await import('/tests/fixtures/journalExecutionBrowser.tsx')).readSavedFacts());
  assert.equal(saved.trades.length, 1); assert.equal(saved.executions.length, 2);
  assert.equal(saved.trades[0].openedAt, '2026-09-12T04:00:00.000Z');
  assert(saved.executions.some(e => e.type === 'exit' && e.executedAt === '2026-09-12T05:00:00.000Z'));
  await page.reload(); await page.locator('.kairos-history-card').waitFor();
  assert.equal(await page.locator('.kairos-history-card').count(), 1, 'Trade survives reload');
  await page.getByRole('link', { name: 'Home', exact: true }).click();
  await page.getByRole('button', { name: 'Your Trades', exact: true }).click();
  await page.locator('.kairos-your-trades__bubble').waitFor();
  await page.locator('.kairos-your-trades__bubble').click();
  await page.getByText('40', { exact: true }).waitFor(); await page.getByText('Currency not recorded', { exact: true }).waitFor();
  await page.screenshot({ path: resolve(evidence, 'saved-execution-your-trades.png'), fullPage: true });
  assert.deepEqual(errors, []);
  writeFileSync(resolve(evidence, 'execution-browser-report.json'), JSON.stringify({ passed: true, source: 'actual Journal UI saves; no seeded trades', savedExecutions: 2, result: '40', currency: null, reload: true, timezone: 'Australia/Melbourne', themes: 3, widths: [320, 390], errors }, null, 2));
  console.log('PASS: actual execution-entry UI, validation, atomic save, reload, local timezone, mobile themes and Your Trades result.');
} finally { await browser?.close(); server.kill('SIGTERM'); }
