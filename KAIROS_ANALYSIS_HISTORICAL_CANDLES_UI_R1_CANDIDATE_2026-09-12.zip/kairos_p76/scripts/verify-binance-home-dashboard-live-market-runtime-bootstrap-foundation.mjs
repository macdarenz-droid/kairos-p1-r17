import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/app/binanceHomeDashboardLiveMarketRuntimeBootstrap.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_BINANCE_HOME_DASHBOARD_LIVE_MARKET_RUNTIME_BOOTSTRAP_FOUNDATION_REPORT_2026-09-09.md', import.meta.url), 'utf8');
const packageJson = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

for (const token of [
  'acquireBinanceSpotBrowserLiveMarketUniverseOnce',
  'createLiveMarketSummaryStateSession',
  'createBinanceHomeDashboardLiveMarketSummaryScopedSnapshotAcquisitionPort',
  'createHomeDashboardLiveMarketSummaryBrowserLifecycleAdapter',
  'BinanceSpot24hPublicRestBaselineObservedAtSource',
  'LiveMarketUniverseAcquisitionOptions',
  'HomeDashboardLiveMarketSummaryBrowserLifecycleAdapterOptions',
  'options.universe',
  'options.lifecycle',
  'if (!universeResult.ok) return universeResult;',
  'if (instruments.length === 0)',
  'close: lifecycle.close',
]) if (!source.includes(token)) throw new Error(`Home live-market runtime bootstrap evidence missing: ${token}`);

for (const forbidden of [
  "quoteAsset === 'USDT'", 'tradingEnabled', 'quoteVolume24h', '.sort(', '.slice(',
  'DEFAULT_LIVE_MARKET_UNIVERSE_TOP_N_COUNT', '= 30', 'setInterval(', '5000',
  'Date.now(', 'new Date(', 'indexedDB', 'createChart(', 'React', 'useEffect',
  'bubbleSize', 'marketCap', 'retry', 'WebSocket(', 'FRESH', 'STALE', 'EXPIRED',
]) if (source.includes(forbidden)) throw new Error(`Home live-market runtime bootstrap duplicated/broadened ownership: ${forbidden}`);

const verifyKey = 'verify:binance-home-dashboard-live-market-runtime-bootstrap-foundation';
if (packageJson.scripts?.[verifyKey] !== 'node scripts/verify-binance-home-dashboard-live-market-runtime-bootstrap-foundation.mjs') {
  throw new Error('Home live-market runtime bootstrap verifier registration missing');
}

for (const token of [
  'non-presentation Home live-market runtime bootstrap',
  'Gate336 one-shot selected scope',
  'same caller-owned readObservedAt source',
  'released state session',
  'released Binance Home scoped-snapshot port',
  'released browser lifecycle adapter',
  'authoritative empty selected scope',
  'initial acquisition failure',
  'No universe refresh cadence',
  'No freshness policy ownership',
  'No React/Home/Bubble presentation ownership',
]) if (!report.includes(token)) throw new Error(`Home live-market runtime bootstrap report evidence missing: ${token}`);

console.log('Binance Home Dashboard live-market runtime bootstrap verification passed.');
