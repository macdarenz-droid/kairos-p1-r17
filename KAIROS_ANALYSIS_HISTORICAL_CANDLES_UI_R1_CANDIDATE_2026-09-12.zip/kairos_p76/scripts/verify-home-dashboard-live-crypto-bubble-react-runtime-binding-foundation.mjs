import { readFileSync } from 'node:fs';

const source = readFileSync('src/app/useHomeDashboardLiveCryptoBubblePresentationObservedRuntime.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-react-runtime-binding-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_REACT_RUNTIME_BINDING_FOUNDATION_REPORT_2026-09-10.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  "import { useEffect, useState } from 'react';",
  'useHomeDashboardLiveCryptoBubblePresentationObservedRuntime',
  "extends Omit<",
  "'observationSink'",
  "status: 'starting'",
  'latestObservation: null',
  'lastError: null',
  'startBinanceHomeDashboardLiveCryptoBubblePresentationObservedRuntime(',
  'readObservedAt,',
  'readEvaluationTimeMs,',
  'universe: options.universe,',
  'lifecycle: options.lifecycle,',
  'presentationPolicy: options.presentationPolicy,',
  'onObservation(observation)',
  'latestObservation: observation',
  'onError(error)',
  'lastError: error',
  "status: 'acquisition-failed'",
  "status: 'running'",
  "status: 'bootstrap-error'",
  'if (result.ok) result.runtime.close();',
  'closeRuntime = result.runtime.close;',
  'closeRuntime?.();',
  'async function bootstrap(): Promise<void>',
  'const result = await startBinanceHomeDashboardLiveCryptoBubblePresentationObservedRuntime(',
  '} catch (error: unknown) {',
  'void bootstrap();',
]) {
  if (!source.includes(token)) throw new Error(`React Bubble runtime binding evidence missing: ${token}`);
}

for (const forbidden of [
  'Date.now(', 'new Date(', 'fetch(', 'XMLHttpRequest', 'WebSocket(', 'indexedDB', 'localStorage',
  'excludedStablecoinBaseAssets: new Set', 'topNCount:', 'neutralMaxAbsoluteMovementPercent:',
  '15_000', '60_000', 'freshMaxAgeMs', 'staleMaxAgeMs', 'priceChangePercent',
  'radius', 'collision', 'palette', 'background:', 'color:', 'className=', '<section', '<svg', '<canvas',
  'createHomeDashboardLiveCryptoBubblePresentationStateObservationSink(',
]) {
  if (source.includes(forbidden)) throw new Error(`React Bubble runtime binding broadened ownership: ${forbidden}`);
}

for (const token of [
  'starts exactly one Gate350 runtime per effect and preserves exact semantic observation plus error evidence without erasing the observation',
  'closes a successfully resolved runtime exactly once when bootstrap finishes after unmount',
  'keeps Gate350 acquisition failure explicit instead of inventing usable Bubble state',
  'preserves an unexpected bootstrap exception as explicit error evidence',
]) {
  if (!test.includes(token)) throw new Error(`Missing React Bubble runtime binding regression: ${token}`);
}

for (const token of [
  'React lifecycle/state binding',
  'preserves the latest exact Gate349 semantic observation by reference',
  'without erasing the latest semantic observation',
  'No concrete stablecoin exclusion set or neutral-movement threshold is selected or hard-coded',
  'No provider transport/request/decode/mapping',
  'visible Bubble circles',
]) {
  if (!report.includes(token)) throw new Error(`React Bubble runtime binding report evidence missing: ${token}`);
}

const verifyName = 'verify:home-dashboard-live-crypto-bubble-react-runtime-binding-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-home-dashboard-live-crypto-bubble-react-runtime-binding-foundation.mjs') {
  throw new Error('React Bubble runtime binding verifier registration mismatch');
}

console.log('PASS: Home Live Crypto Bubble React lifecycle/state binding consumes Gate350 without absorbing provider, policy, geometry, persistence or visible rendering truth.');
