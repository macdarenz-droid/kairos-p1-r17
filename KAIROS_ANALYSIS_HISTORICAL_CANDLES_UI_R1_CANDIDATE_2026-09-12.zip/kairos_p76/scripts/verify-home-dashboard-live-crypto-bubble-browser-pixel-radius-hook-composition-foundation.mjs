import { readFileSync } from 'node:fs';

const source = readFileSync('src/app/useHomeDashboardLiveCryptoBubbleBrowserPixelRadiusViewModel.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-browser-pixel-radius-hook-composition-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_BROWSER_PIXEL_RADIUS_HOOK_COMPOSITION_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'useHomeDashboardLiveCryptoBubbleBrowserPixelRadiusViewModel',
  'readHomeDashboardLiveCryptoBubbleBrowserObservedAt',
  'readHomeDashboardLiveCryptoBubbleBrowserEvaluationTimeMs',
  'useHomeDashboardLiveCryptoBubbleReactPixelRadiusViewModel(',
  'options: HomeDashboardLiveCryptoBubbleReactRuntimeBindingOptions',
  'policy: HomeDashboardLiveCryptoBubblePixelRadiusPolicy',
]) {
  if (!source.includes(token)) throw new Error(`Browser pixel-radius hook evidence missing: ${token}`);
}

if ((source.match(/useHomeDashboardLiveCryptoBubbleReactPixelRadiusViewModel\(/g) ?? []).length !== 1) {
  throw new Error('Browser pixel-radius hook must delegate to Gate378 exactly once');
}
if (!source.includes(`readHomeDashboardLiveCryptoBubbleBrowserObservedAt,
    readHomeDashboardLiveCryptoBubbleBrowserEvaluationTimeMs,
    options,
    policy,`)) {
  throw new Error('Browser pixel-radius hook must forward exact Gate358 sources, options and policy in order');
}

for (const forbidden of [
  'useEffect', 'useState', 'useMemo', 'useRef', 'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'startBinanceHomeDashboard', '.sort(', '.filter(', '.reverse(',
  'validateHomeDashboardLiveCryptoBubblePixelRadiusPolicy(', 'projectHomeDashboardLiveCryptoBubblePixelRadii(',
  'minimumRadiusCssPixels +', 'maximumRadiusCssPixels -', 'Math.sqrt(', 'Math.pow(', 'window.', 'document.',
  'ResizeObserver', 'getBoundingClientRect(', 'borderRadius', 'className=', '<div', '<svg', 'HomeRoute',
  'indexedDB', 'YourTrades',
]) {
  if (source.includes(forbidden)) throw new Error(`Browser pixel-radius hook broadened ownership: ${forbidden}`);
}

for (const token of [
  'injects exact released Gate358 browser clock sources plus caller options and policy into Gate378 once',
  'returns the exact released Gate378 result unchanged',
  'does not retain a second browser pixel-radius result owner across rerenders',
]) {
  if (!test.includes(token)) throw new Error(`Missing browser pixel-radius hook regression: ${token}`);
}

for (const token of [
  'thin browser-specific React composition seam immediately above Gate378',
  'Gate358 remains the concrete browser wall-clock owner',
  'exact caller-owned runtime-options and pixel-radius policy references are forwarded unchanged',
  'Live Crypto Bubble Map and Your Trades Bubble Map remain separate authoritative truth domains',
]) {
  if (!report.includes(token)) throw new Error(`Browser pixel-radius hook report evidence missing: ${token}`);
}

const verifyName = 'verify:home-dashboard-live-crypto-bubble-browser-pixel-radius-hook-composition-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-home-dashboard-live-crypto-bubble-browser-pixel-radius-hook-composition-foundation.mjs') {
  throw new Error('Browser pixel-radius hook verifier registration mismatch');
}

console.log('PASS: browser pixel-radius hook injects released Gate358 clocks into Gate378 with exact caller options/policy and no second state, viewport, sizing-default, layout, renderer, route, or market-truth ownership.');
