import { readFileSync } from 'node:fs';

const source = readFileSync('src/app/useHomeDashboardLiveCryptoBubbleReactPixelRadiusViewModel.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-react-pixel-radius-hook-composition-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_REACT_PIXEL_RADIUS_HOOK_COMPOSITION_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'useHomeDashboardLiveCryptoBubbleReactPixelRadiusViewModel',
  'useHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel(',
  'projectHomeDashboardLiveCryptoBubbleReactPixelRadiusViewModel(',
  'readObservedAt',
  'readEvaluationTimeMs',
  'options: HomeDashboardLiveCryptoBubbleReactRuntimeBindingOptions',
  'policy: HomeDashboardLiveCryptoBubblePixelRadiusPolicy',
  'radiusScaleViewModel,',
  'policy,',
]) {
  if (!source.includes(token)) throw new Error(`React pixel-radius hook composition evidence missing: ${token}`);
}

if ((source.match(/useHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel\(/g) ?? []).length !== 1) {
  throw new Error('React pixel-radius hook must delegate to the released radius-scale hook exactly once');
}
if ((source.match(/projectHomeDashboardLiveCryptoBubbleReactPixelRadiusViewModel\(/g) ?? []).length !== 1) {
  throw new Error('React pixel-radius hook must delegate the exact radius-scale view model and policy to Gate377 exactly once');
}

for (const forbidden of [
  'useEffect', 'useState', 'useMemo', 'useRef', 'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'startBinanceHomeDashboard', 'createHomeDashboard',
  '.sort(', '.filter(', '.reverse(', 'validateHomeDashboardLiveCryptoBubblePixelRadiusPolicy(',
  'projectHomeDashboardLiveCryptoBubblePixelRadii(', 'minimumRadiusCssPixels +', 'maximumRadiusCssPixels -',
  'Math.sqrt(', 'Math.pow(', 'window.', 'document.', 'ResizeObserver', 'getBoundingClientRect(',
  'borderRadius', 'className=', '<div', '<svg', 'HomeRoute', 'indexedDB',
]) {
  if (source.includes(forbidden)) throw new Error(`React pixel-radius hook composition broadened ownership: ${forbidden}`);
}

for (const token of [
  'delegates exact caller runtime inputs and exact pixel-radius policy once through the released owners',
  'does not retain a second app-level pixel-radius state owner across rerenders',
  'returns the exact released Gate377 pixel-radius view-model result unchanged',
]) {
  if (!test.includes(token)) throw new Error(`Missing React pixel-radius hook regression: ${token}`);
}

for (const token of [
  'one thin React composition seam',
  'calls `useHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel(...)` exactly once',
  'passes the exact returned radius-scale view-model reference plus exact caller policy exactly once',
  'adds no second retained state/effect owner, cache, timer, observer, viewport source, policy validation, arithmetic or error taxonomy',
  'Live Crypto Bubble Map and Your Trades Bubble Map remain separate truth domains',
]) {
  if (!report.includes(token)) throw new Error(`React pixel-radius hook report evidence missing: ${token}`);
}

const verifyName = 'verify:home-dashboard-live-crypto-bubble-react-pixel-radius-hook-composition-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-home-dashboard-live-crypto-bubble-react-pixel-radius-hook-composition-foundation.mjs') {
  throw new Error('React pixel-radius hook verifier registration mismatch');
}

console.log('PASS: Home Live Crypto Bubble React pixel-radius hook composes released runtime/radius-scale evidence with exact caller-supplied Gate374 bounds through Gate377 without owning defaults, second state, viewport, layout, renderer, or market truth.');
