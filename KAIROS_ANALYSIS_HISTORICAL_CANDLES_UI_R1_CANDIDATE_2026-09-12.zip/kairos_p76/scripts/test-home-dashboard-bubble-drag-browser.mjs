import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { spawn } from 'node:child_process';
const require = createRequire(resolve(process.env.KAIROS_BROWSER_PACKAGE_DIR ?? '.', 'package.json'));
const { chromium } = require('playwright');
const evidence = resolve('.bubble-drag-evidence'); mkdirSync(evidence, { recursive: true });
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', '--host', '127.0.0.1', '--port', '4179', '--strictPort'], { stdio: 'pipe' });
let log = '', browser, page;
server.stdout.on('data', b => log += b); server.stderr.on('data', b => log += b);
try {
  let ready = false;
  for (let i = 0; i < 100; i++) { try { if ((await fetch('http://127.0.0.1:4179/')).ok) { ready = true; break; } } catch {} await new Promise(r => setTimeout(r, 200)); }
  assert(ready, log);
  browser = await chromium.launch({ headless: true, ...(process.env.KAIROS_CHROMIUM_EXECUTABLE ? { executablePath: process.env.KAIROS_CHROMIUM_EXECUTABLE, args: ['--no-sandbox', '--disable-dev-shm-usage', '--no-zygote', '--single-process'] } : {}) });
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 1 });
  page = await context.newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
  await page.route('https://**/*', route => route.abort());
  await page.route('http://127.0.0.1:4179/', route => route.fulfill({ contentType: 'text/html', body: '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0}</style><div id="glass-test-root"></div><script type="module">import RefreshRuntime from "/@react-refresh";RefreshRuntime.injectIntoGlobalHook(window);window.$RefreshReg$=()=>{};window.$RefreshSig$=()=>type=>type;window.__vite_plugin_react_preamble_installed__=true;const f=await import("/tests/fixtures/homeDashboardGlassBrowser.tsx");f.theme("kairos-depth");f.mountCompact();</script>' }));
  await page.goto('http://127.0.0.1:4179/');
  await page.waitForFunction(() => document.querySelectorAll('[data-glass-ready="true"]').length === 30);
  await page.waitForTimeout(900);
  const cdp = await context.newCDPSession(page);
  const send = (type, points = []) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: points.map((p, i) => ({ x: p.x, y: p.y, id: i + 1, radiusX: 3, radiusY: 3, force: 1 })) });
  const start = p => send('touchStart', [p]);
  const move = p => send('touchMove', [p]);
  const end = () => send('touchEnd');
  const geometry = () => page.locator('.kairos-glass-bubble').evaluateAll(nodes => nodes.map(n => { const r = n.getBoundingClientRect(); return { key: n.dataset.glassKey, x: r.x + r.width / 2, y: r.y + r.height / 2, r: r.width / 2, text: n.innerText, movement: n.dataset.movement, width: n.style.width, left: n.style.left, top: n.style.top }; }));
  const centre = async selector => { const r = await page.locator(selector).first().boundingBox(); assert(r); return { x: r.x + r.width / 2, y: r.y + r.height / 2 }; };
  const held = () => page.locator('[data-glass-dragging="true"]');
  const hold = async selector => { const p = await centre(selector); await start(p); await held().waitFor(); return p; };
  const path = async (from, to, steps = 12) => { for (let i = 1; i <= steps; i++) { await move({ x: from.x + (to.x - from.x) * i / steps, y: from.y + (to.y - from.y) * i / steps }); await page.waitForTimeout(16); } };
  const bounded = async () => {
    const field = await page.locator('.kairos-glass-field').boundingBox(); assert(field);
    for (const c of await geometry()) {
      assert(c.x - c.r >= field.x - .5 && c.x + c.r <= field.x + field.width + .5, 'Bubble horizontal bounds');
      assert(c.y - c.r >= field.y - .5 && c.y + c.r <= field.y + field.height + .5, 'Bubble vertical bounds');
    }
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'No horizontal overflow');
  };
  const measures = [];

  // Real touchscreen input, production 30-bubble renderer, real collision and frame loop.
  const origin = await hold('[data-identity="BTC"]');
  const before = await geometry(), heldKey = await held().getAttribute('data-glass-key'), own = before.find(c => c.key === heldKey);
  assert(own);
  const neighbour = before.filter(c => c.key !== own.key).sort((a, b) => Math.hypot(a.x - own.x, a.y - own.y) - Math.hypot(b.x - own.x, b.y - own.y))[0];
  const scrollBefore = await page.evaluate(() => scrollY);
  await path(origin, neighbour);
  const during = await geometry(), movedNeighbours = during.filter(c => c.key !== own.key && Math.hypot(c.x - before.find(b => b.key === c.key).x, c.y - before.find(b => b.key === c.key).y) > 12).length;
  assert(movedNeighbours >= 1, 'Held bubble must push neighbours aside');
  assert.equal(await held().count(), 1); assert.equal(await page.evaluate(() => scrollY), scrollBefore, 'Active drag must not scroll');
  assert.equal(await held().evaluate(n => getComputedStyle(n).cursor), 'grabbing');
  await page.screenshot({ path: resolve(evidence, 'phone-390-drag-collision.png'), fullPage: true });
  await end(); assert.equal(await held().count(), 0);
  await page.waitForTimeout(700); await bounded();
  const fact = c => [c.key, c.text, c.movement, c.width];
  assert.deepEqual((await geometry()).map(fact), before.map(fact), 'Dragging must not change identities, displayed facts or sizes');

  // Theme switching and mobile sizes retain geometry and readable grabbed feedback.
  await page.emulateMedia({ reducedMotion: 'reduce' });
  for (const width of [320, 390]) {
    await page.setViewportSize({ width, height: 844 });
    await page.evaluate(async () => (await import('/tests/fixtures/homeDashboardGlassBrowser.tsx')).mountCompact());
    await page.waitForTimeout(150);
    const initial = (await geometry()).map(c => [c.key, c.left, c.top, c.width]);
    for (const theme of ['kairos-depth', 'cosmic', 'ocean']) {
      await page.evaluate(async theme => (await import('/tests/fixtures/homeDashboardGlassBrowser.tsx')).theme(theme), theme);
      assert.deepEqual((await geometry()).map(c => [c.key, c.left, c.top, c.width]), initial);
      const p = await hold('[data-identity="BTC"]');
      await path(p, { x: Math.min(width - 25, p.x + 45), y: p.y + 50 }, 5);
      await page.screenshot({ path: resolve(evidence, `phone-${width}-${theme}-held.png`), fullPage: true });
      const feedback = await held().evaluate(n => ({ outline: getComputedStyle(n).outlineColor, cursor: getComputedStyle(n).cursor, touchAction: getComputedStyle(n).touchAction }));
      assert.equal(feedback.cursor, 'grabbing'); assert.equal(feedback.touchAction, 'manipulation');
      measures.push({ width, theme, ...feedback });
      await end(); const frozen = await page.locator('.kairos-glass-bubble').evaluateAll(nodes => nodes.map(n => n.style.translate));
      await page.waitForTimeout(200);
      assert.deepEqual(await page.locator('.kairos-glass-bubble').evaluateAll(nodes => nodes.map(n => n.style.translate)), frozen, 'Reduced motion has no release inertia');
      await bounded();
    }
  }

  // A browser scroll harness adds overflow around the real renderer; an immediate swipe stays native.
  await page.evaluate(() => { document.body.style.minHeight = '1800px'; window.scrollTo(0, 0); });
  const scrollTarget = (await geometry()).find(c => c.y > 260 && c.y < 620); assert(scrollTarget);
  await start(scrollTarget);
  for (let i = 1; i <= 5; i++) { await move({ x: scrollTarget.x, y: scrollTarget.y - i * 22 }); await page.waitForTimeout(12); }
  await end(); await page.waitForTimeout(350);
  assert(await page.evaluate(() => scrollY > 30), 'Quick swipe over a bubble must scroll the page');
  assert.equal(await held().count(), 0);
  await page.evaluate(() => { document.body.style.minHeight = ''; window.scrollTo(0, 0); });
  await page.waitForTimeout(200);
  // A second finger yields to the browser instead of keeping a stuck grab.
  const multi = await hold('[data-identity="BTC"]');
  await send('touchStart', [multi, { x: multi.x + 20, y: multi.y + 20 }]);
  assert.equal(await held().count(), 0); await end();

  // User trade identity and persisted facts are separate from decorative positions.
  await page.evaluate(async () => { const f = await import('/tests/fixtures/homeDashboardGlassBrowser.tsx'); await f.seedYourTrades(); f.mountHome(); });
  await page.getByRole('button', { name: 'Your Trades', exact: true }).click();
  await page.waitForFunction(() => document.querySelectorAll('.kairos-your-trades__bubble').length === 12);
  const saved = () => page.evaluate(async () => (await import('/tests/fixtures/journalExecutionBrowser.tsx')).readSavedFacts());
  const persisted = await saved();
  let p = await centre('.kairos-your-trades__bubble'); await page.touchscreen.tap(p.x, p.y);
  await page.getByRole('complementary', { name: 'Selected trade' }).waitFor();
  await page.getByRole('button', { name: 'Close details' }).click();
  p = await hold('.kairos-your-trades__bubble'); await path(p, { x: Math.min(350, p.x + 65), y: p.y + 45 }, 6); await end();
  assert.equal(await page.getByRole('complementary', { name: 'Selected trade' }).count(), 0, 'Drag release must not open trade details');
  p = await centre('.kairos-your-trades__bubble'); await page.touchscreen.tap(p.x, p.y);
  await page.getByRole('complementary', { name: 'Selected trade' }).waitFor();
  await page.getByRole('button', { name: 'Close details' }).click();
  await page.locator('.kairos-your-trades__bubble').first().focus(); await page.keyboard.press('Enter');
  await page.getByRole('complementary', { name: 'Selected trade' }).waitFor();
  await page.getByRole('button', { name: 'Close details' }).click();
  await page.screenshot({ path: resolve(evidence, 'your-trades-after-drag.png'), fullPage: true });
  assert.deepEqual(await saved(), persisted, 'Movement must not write trade, execution or fee records');
  await hold('.kairos-your-trades__bubble');
  await page.getByRole('button', { name: 'Live Market', exact: true }).click(); await end();
  assert.equal(await held().count(), 0); assert.equal(await page.locator('.kairos-your-trades__bubble').count(), 0);
  assert.deepEqual(await saved(), persisted);

  // Sparse layout makes release inertia measurable separately from ambient drift and dense contacts.
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await page.evaluate(async () => (await import('/tests/fixtures/homeDashboardGlassBrowser.tsx')).mount(8));
  await page.waitForFunction(() => document.querySelectorAll('.kairos-glass-bubble').length === 8);
  await page.waitForTimeout(900);
  p = await hold('[data-identity="BTC"]');
  const field = await page.locator('.kairos-glass-field').boundingBox(); assert(field);
  const destination = { x: p.x < 195 ? 310 : 80, y: Math.min(field.y + field.height - 100, p.y + 70) };
  await path(p, destination, 7); await end();
  let previous = await centre('[data-identity="BTC"]'), travelled = 0;
  for (let i = 0; i < 6; i++) { await page.waitForTimeout(60); const next = await centre('[data-identity="BTC"]'); travelled += Math.hypot(next.x - previous.x, next.y - previous.y); previous = next; }
  assert(travelled > 15, 'A quick release must have visible inertia beyond ambient drift');
  await bounded();
  // Mouse pointer path and a real market rerender use the same retained gesture owner.
  p = await centre('[data-identity="ETH"]'); await page.mouse.move(p.x, p.y); await page.mouse.down(); await held().waitFor();
  const heldIdentity = await held().getAttribute('data-glass-key');
  const retainedCanvas = await held().locator('canvas').elementHandle();
  await page.evaluate(async () => (await import('/tests/fixtures/homeDashboardGlassBrowser.tsx')).refreshRanking());
  await page.getByText('+4.25%', { exact: true }).waitFor();
  assert.equal(await held().getAttribute('data-glass-key'), heldIdentity, 'Live refresh must retain held identity');
  assert(await retainedCanvas.evaluate(n => n.isConnected && n === n.closest('[data-glass-dragging="true"]').querySelector('canvas')), 'Live refresh retains held canvas');
  await page.mouse.move(Math.min(340, p.x + 55), p.y + 40, { steps: 6 });
  assert.equal(await held().count(), 1); await page.mouse.up(); assert.equal(await held().count(), 0);
  assert.deepEqual(errors, []);
  writeFileSync(resolve(evidence, 'bubble-drag-browser-report.json'), JSON.stringify({ passed: true, source: 'production renderers and Home composition; real Chromium touchscreen CDP and mouse input', bubbleCount: 30, movedNeighbours, releaseTravelCssPixels: travelled, nativeScrollPreserved: true, reducedMotionDirectOnly: true, multitouchCancellation: true, realTradeTapAndKeyboard: true, dragDoesNotSelect: true, persistedFactsUnchanged: true, switchCancelsHold: true, mouseHold: true, liveRefreshDuringHold: true, measures, errors }, null, 2));
  console.log('PASS: real touch hold/drag/collisions/fling, native swipe, reduced motion, mobile themes, selection, exact saved facts and cancellation.');
} catch (error) {
  if (page) { writeFileSync(resolve(evidence, 'failure.html'), await page.content()); await page.screenshot({ path: resolve(evidence, 'failure.png'), fullPage: true }); }
  throw error;
} finally { await browser?.close(); server.kill('SIGTERM'); writeFileSync(resolve(evidence, 'vite.log'), log); }
