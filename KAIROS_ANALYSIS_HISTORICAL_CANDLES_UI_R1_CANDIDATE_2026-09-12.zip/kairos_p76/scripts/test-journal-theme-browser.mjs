import assert from 'node:assert/strict';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { spawn } from 'node:child_process';
const require = createRequire(resolve(process.env.KAIROS_BROWSER_PACKAGE_DIR ?? '.', 'package.json'));
const { chromium } = require('playwright');
const evidence = resolve('.journal-theme-evidence'); mkdirSync(evidence, { recursive: true });
const variables = [...new Set([...readFileSync('src/app/journalRoute.css', 'utf8').matchAll(/var\(\s*(--[\w-]+)/g)].map(match => match[1]))];
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', '--host', '127.0.0.1', '--port', '4177', '--strictPort'], { stdio: 'pipe' });
let log = ''; server.stdout.on('data', x => log += x); server.stderr.on('data', x => log += x);
let browser, page;
function luminance(color) {
  const channels = color.match(/[\d.]+/g).slice(0, 3).map(Number).map(v => v / 255).map(v => v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4);
  return channels[0] * .2126 + channels[1] * .7152 + channels[2] * .0722;
}
function contrast(a, b) { const values = [luminance(a), luminance(b)].sort((x, y) => y - x); return (values[0] + .05) / (values[1] + .05); }
try {
  let ready = false;
  for (let i = 0; i < 100; i++) { try { if ((await fetch('http://127.0.0.1:4177/')).ok) { ready = true; break; } } catch {} await new Promise(r => setTimeout(r, 200)); }
  assert(ready, log);
  browser = await chromium.launch({ headless: true, ...(process.env.KAIROS_CHROMIUM_EXECUTABLE ? { executablePath: process.env.KAIROS_CHROMIUM_EXECUTABLE, args: ['--no-sandbox', '--disable-dev-shm-usage', '--no-zygote', '--single-process'] } : {}) });
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, timezoneId: 'Australia/Melbourne', reducedMotion: 'reduce' });
  page = await context.newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
  await page.route('https://**/*', route => route.abort());
  await page.route('http://127.0.0.1:4177/', route => route.fulfill({ contentType: 'text/html', body: '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0}</style><div id="execution-test-root"></div><script type="module">import RefreshRuntime from "/@react-refresh";RefreshRuntime.injectIntoGlobalHook(window);window.$RefreshReg$=()=>{};window.$RefreshSig$=()=>type=>type;window.__vite_plugin_react_preamble_installed__=true;const f=await import("/tests/fixtures/journalExecutionBrowser.tsx");await f.mount();</script>' }));
  const savedFacts = () => page.evaluate(async () => (await import('/tests/fixtures/journalExecutionBrowser.tsx')).readSavedFacts());
  await page.goto('http://127.0.0.1:4177/');
  // Configure only the test browser's explicit calendar preference through its
  // released application owner. All trade facts still come from the real UI.
  await page.evaluate(async () => {
    const { kairosDatabase, openKairosDatabase } = await import('/src/data/database');
    const { createKairosRepositories } = await import('/src/data/repositories');
    const { writeVisualPnlTimeZonePreference } = await import('/src/application/visual-pnl');
    await openKairosDatabase(kairosDatabase);
    await writeVisualPnlTimeZonePreference(createKairosRepositories(kairosDatabase).metadata, 'Australia/Melbourne', '2026-09-12T00:00:00.000Z');
  });
  // Reproduce the recording through the actual save UI: two Closed trades,
  // one with a plan, neither with actual executions. No fixture-injected trades.
  for (const symbol of ['BTCUSDT', 'ETHUSDT']) {
    for (const [label, value] of [['Market', 'crypto'], ['Direction', 'long'], ['Status', 'closed']]) await page.getByLabel(new RegExp('^' + label)).selectOption(value);
    await page.getByLabel(/^Symbol/).fill(symbol);
    await page.getByLabel(/^Opened/).fill('2026-09-12T14:00');
    await page.getByLabel(/^Closed/).fill('2026-09-12T15:00');
    if (symbol === 'BTCUSDT') {
      await page.locator('summary').filter({ hasText: 'Trade plan' }).click();
      for (const [label, value] of [['Planned entry', '12'], ['Planned stop', '10'], ['Planned target', '15']]) await page.getByLabel(label, { exact: true }).fill(value);
    }
    await page.getByRole('button', { name: 'Save trade', exact: true }).click();
    await page.waitForFunction(count => document.querySelectorAll('.kairos-history-card').length === count, symbol === 'BTCUSDT' ? 1 : 2);
  }
  const original = await savedFacts(); assert.equal(original.trades.length, 2); assert.equal(original.executions.length, 0); assert.equal(original.fees.length, 0);
  await page.reload(); await page.locator('.kairos-history-card').first().waitFor();
  await page.locator('.kairos-pnl-streak').waitFor();
  assert.equal(await page.locator('.kairos-history-card__outcome--unavailable').count(), 2, 'Planned values do not fabricate a result');
  await page.locator('summary').filter({ hasText: 'Fees' }).click();
  await page.getByRole('button', { name: 'Add fee', exact: true }).waitFor({ state: 'visible' });
  await page.locator('summary').filter({ hasText: 'Fees' }).click();
  const checks = [];
  for (const width of [320, 390]) {
    await page.setViewportSize({ width, height: 844 }); let geometry;
    for (const theme of ['kairos-depth', 'cosmic', 'ocean']) {
      await page.evaluate(async theme => (await import('/tests/fixtures/journalExecutionBrowser.tsx')).theme(theme), theme);
      const actual = await page.evaluate(variables => {
        const root = getComputedStyle(document.documentElement);
        const style = selector => getComputedStyle(document.querySelector(selector));
        const card = style('.kairos-history-card'), label = style('.kairos-trade-map__graphic-label');
        const spans = [...document.querySelector('.kairos-history-card__topline').querySelectorAll('span')].map(e => e.getBoundingClientRect());
        return {
          missingVariables: variables.filter(v => !root.getPropertyValue(v).trim()),
          cardPadding: parseFloat(card.paddingLeft), cardRadius: parseFloat(card.borderRadius), cardBorder: parseFloat(card.borderTopWidth), cardBackground: card.backgroundColor,
          listGap: parseFloat(style('.kairos-history__list').rowGap), labelGap: spans[1].left - spans[0].right,
          labelFill: label.fill, markerFill: style('.kairos-trade-map__marker--entry').fill,
          laneStroke: style('.kairos-trade-map__lane').stroke,
          summaries: ['.kairos-pnl-streak', '.kairos-pnl-performance-summary', '.kairos-pnl-progress'].filter(selector => document.querySelector(selector)).map(selector => ({ selector, padding: parseFloat(style(selector).paddingLeft), gap: parseFloat(style(selector).rowGap), border: parseFloat(style(selector).borderTopWidth) })),
          overflow: document.documentElement.scrollWidth > innerWidth,
          geometry: [...document.querySelectorAll('.kairos-history-card, .kairos-trade-map, .kairos-trade-map__graphic')].map(e => { const r = e.getBoundingClientRect(); return { width: r.width, height: r.height }; })
        };
      }, variables);
      actual.labelContrast = contrast(actual.labelFill, actual.cardBackground);
      checks.push({ width, theme, ...actual });
      await page.locator('.kairos-pnl-streak').evaluate(e => window.scrollTo(0, e.getBoundingClientRect().top + scrollY - 72));
      await page.screenshot({ path: resolve(evidence, `summaries-${width}-${theme}.png`), fullPage: false });
      const card = page.locator('.kairos-history-card').filter({ hasText: 'BTCUSDT' });
      await card.evaluate(e => window.scrollTo(0, e.getBoundingClientRect().top + scrollY - 72));
      await page.screenshot({ path: resolve(evidence, `history-${width}-${theme}.png`), fullPage: false });
      writeFileSync(resolve(evidence, 'journal-theme-measurements.json'), JSON.stringify(checks, null, 2));
      assert.deepEqual(actual.missingVariables, [], 'Every Journal CSS token resolves in the active theme');
      assert(actual.cardPadding >= 12 && actual.cardRadius >= 8 && actual.cardBorder >= 1, 'History cards retain visible framing');
      assert(actual.listGap >= 8 && actual.labelGap >= 4, 'History cards and side/status labels stay separated');
      assert(actual.labelContrast >= 4.5, 'Small SVG labels have readable contrast against the card');
      assert.equal(actual.markerFill, actual.labelFill, 'Entry marker retains the readable theme foreground');
      assert.notEqual(actual.laneStroke, 'none', 'Trade map lanes remain visible');
      assert(actual.summaries.length === 3 && actual.summaries.every(s => s.padding >= 12 && s.gap >= 4 && s.border >= 1), 'All summary cards retain spacing and borders');
      assert(!actual.overflow, 'Journal fits the mobile viewport');
      if (geometry) assert.deepEqual(actual.geometry, geometry, 'Theme switches preserve Journal geometry'); else geometry = actual.geometry;
    }
  }
  assert.deepEqual(await savedFacts(), original, 'Reloads and theme changes preserve all saved facts');
  assert.deepEqual(errors, []);
  writeFileSync(resolve(evidence, 'journal-theme-browser-report.json'), JSON.stringify({ passed: true, source: 'real save UI, no seeded trades', unavailableResultsPreserved: 2, feesToggleWorks: true, savedFactsUnchanged: true, checks, errors }, null, 2));
  console.log('PASS: Journal spacing, borders, readable SVG labels, all CSS variables, 320/390px × three themes, and saved facts.');
} catch (error) {
  if (page) { writeFileSync(resolve(evidence, 'failure.html'), await page.content()); await page.screenshot({ path: resolve(evidence, 'failure.png'), fullPage: true }); }
  throw error;
} finally { await browser?.close(); server.kill('SIGTERM'); }
