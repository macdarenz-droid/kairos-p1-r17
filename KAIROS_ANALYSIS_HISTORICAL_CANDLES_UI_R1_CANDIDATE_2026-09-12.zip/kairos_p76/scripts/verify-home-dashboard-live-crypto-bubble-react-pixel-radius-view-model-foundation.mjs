import { readFileSync } from 'node:fs';

const source = readFileSync('src/app/homeDashboardLiveCryptoBubbleReactPixelRadiusViewModel.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-react-pixel-radius-view-model-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_REACT_PIXEL_RADIUS_VIEW_MODEL_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'HomeDashboardLiveCryptoBubbleReactPixelRadiusViewModel',
  'radiusScaleViewModel: HomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel',
  "runtimeState: HomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel['runtimeState']",
  'pixelRadiusProjection: HomeDashboardLiveCryptoBubblePixelRadiusProjectionResult | null',
  'projectHomeDashboardLiveCryptoBubbleReactPixelRadiusViewModel',
  'const runtimeState = radiusScaleViewModel.runtimeState',
  'const radiusScaleProjection = radiusScaleViewModel.radiusScaleProjection',
  'if (radiusScaleProjection === null)',
  'pixelRadiusProjection: null',
  'projectHomeDashboardLiveCryptoBubblePixelRadii(',
  'radiusScaleProjection,',
  'policy,',
]) {
  if (!source.includes(token)) throw new Error(`React pixel-radius view-model evidence missing: ${token}`);
}

if ((source.match(/projectHomeDashboardLiveCryptoBubblePixelRadii\(/g) ?? []).length !== 1) {
  throw new Error('React pixel-radius view model must delegate to Gate375 exactly once');
}

for (const forbidden of [
  "from 'react'", 'useEffect', 'useState', 'useMemo', 'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'startBinanceHomeDashboard', '.sort(', '.filter(', '.reverse(',
  'validateHomeDashboardLiveCryptoBubblePixelRadiusPolicy(', 'minimumRadiusCssPixels +', 'maximumRadiusCssPixels -',
  'Math.sqrt(', 'Math.pow(', 'window.', 'document.', 'ResizeObserver', 'getBoundingClientRect(',
  'borderRadius', 'radius:', 'width:', 'height:', 'left:', 'top:', 'className=', '<div', '<svg',
  'neutralMaxAbsoluteMovementPercent', 'stablecoin', 'topN', 'Top 30', 'freshMaxAgeMs', 'staleMaxAgeMs', 'indexedDB',
]) {
  if (source.includes(forbidden)) throw new Error(`React pixel-radius view model broadened ownership: ${forbidden}`);
}

for (const token of [
  'preserves exact radius-scale view-model and runtime-state references before normalized radius evidence exists',
  'delegates exact released normalized radius evidence and exact caller bounds once into Gate375 pixel-radius projection',
  'preserves released radius-scale failure evidence by exact reference through Gate375 projection',
  'delegates invalid caller bounds to Gate374 through Gate375 without inventing fallback values',
  'keeps last authoritative pixel-radius evidence composable when runtime status reports a later acquisition failure',
]) {
  if (!test.includes(token)) throw new Error(`Missing React pixel-radius view-model regression: ${token}`);
}

for (const token of [
  'one pure app-level composition seam',
  'preserves that exact radius-scale view-model object and its exact `runtimeState` reference',
  'passes only the exact `radiusScaleProjection` reference and exact caller policy into `projectHomeDashboardLiveCryptoBubblePixelRadii(...)` once',
  'no React hook/state/effect or wall clock',
  'Live Crypto Bubble Map and Your Trades Bubble Map remain separate truth domains',
]) {
  if (!report.includes(token)) throw new Error(`React pixel-radius view-model report evidence missing: ${token}`);
}

const verifyName = 'verify:home-dashboard-live-crypto-bubble-react-pixel-radius-view-model-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-home-dashboard-live-crypto-bubble-react-pixel-radius-view-model-foundation.mjs') {
  throw new Error('React pixel-radius view-model verifier registration mismatch');
}

console.log('PASS: Home Live Crypto Bubble React pixel-radius view model composes released normalized radius evidence with caller-supplied Gate374 policy through Gate375 without owning defaults, React state, layout, renderer, or market truth.');
