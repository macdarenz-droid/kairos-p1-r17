import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const home = readFileSync('src/app/HomeRoute.tsx', 'utf8');
const preservedRouteVerifier = readFileSync('scripts/verify-p21-1-home-dashboard-route-ownership-foundation.mjs', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-home-route-text-runtime-integration-foundation.test.tsx', 'utf8');
const routerTest = readFileSync('tests/router.test.tsx', 'utf8');
const foundationReport = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_HOME_ROUTE_TEXT_RUNTIME_INTEGRATION_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const amendmentReport = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_HOME_ROUTE_RADIUS_SCALE_TEXT_RUNTIME_INTEGRATION_AMENDMENT_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-home-route-text-runtime-integration-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-home-route-text-runtime-integration-foundation.mjs',
);

for (const required of [
  "import { HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime }",
  "import { createHomeDashboardLiveCryptoBubbleDefaultRuntimeProductConfiguration }",
  'const configuration = createHomeDashboardLiveCryptoBubbleDefaultRuntimeProductConfiguration();',
  'data-kairos-home-dashboard="live-crypto-text-runtime"',
  'id="kairos-home-dashboard-heading">Live Crypto Bubble</h2>',
  '<HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime',
  'configuration={configuration}',
]) {
  assert.ok(home.includes(required), `HomeRoute runtime integration missing exact released delegation: ${required}`);
}

assert.equal(
  (home.match(/createHomeDashboardLiveCryptoBubbleDefaultRuntimeProductConfiguration\(\)/g) ?? []).length,
  1,
);
assert.equal(
  (home.match(/<HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime/g) ?? []).length,
  1,
);
assert.ok(
  !home.includes('HomeDashboardLiveCryptoBubbleConfiguredTextEvidenceRuntime'),
  'HomeRoute must replace rather than duplicate the superseded configured area-weight textual runtime consumer',
);

for (const forbidden of [
  "'USDC'", "'FDUSD'", "'XUSD'", "'USDS'", "'TUSD'", "'USDP'", "'DAI'", "'EURI'", "'AEUR'",
  "'0.25'", 'new Set(', 'topNCount', 'neutralMaxAbsoluteMovementPercent:', 'excludedStablecoinBaseAssets:',
  'Date.now(', 'new Date(', 'setInterval(', 'setTimeout(', 'requestAnimationFrame(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'indexedDB', 'localStorage',
  '<svg', '<circle', '<canvas', 'style=', 'Math.sqrt(', 'minRadius', 'maxRadius', 'radiusPx',
  'collision', 'viewport', 'areaWeight',
]) {
  assert.ok(!home.includes(forbidden), `HomeRoute must not become a hidden policy/data/renderer owner: ${forbidden}`);
}

for (const preserved of [
  'data-kairos-home-dashboard="live-crypto-text-runtime"',
  'HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime',
  'createHomeDashboardLiveCryptoBubbleDefaultRuntimeProductConfiguration',
]) {
  assert.ok(
    preservedRouteVerifier.includes(preserved),
    `P21.1 route-ownership regression must evolve without losing current route evidence: ${preserved}`,
  );
}
assert.ok(!preservedRouteVerifier.includes('No dashboard insights are connected yet.'));
assert.ok(!preservedRouteVerifier.includes("'HomeDashboardLiveCryptoBubbleConfiguredTextEvidenceRuntime',"));

for (const evidence of [
  'expect(defaultConfigurationFactoryMock).toHaveBeenCalledTimes(1)',
  'expect(configuredRadiusRuntimeMock).toHaveBeenCalledTimes(1)',
  'expect(props.configuration).toBe(defaultConfiguration)',
]) {
  assert.ok(test.includes(evidence), `route integration test missing exact-reference evidence: ${evidence}`);
}

for (const isolation of [
  "vi.mock('../src/app/HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime'",
  'HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime: () => null',
]) {
  assert.ok(routerTest.includes(isolation), `router shell test must isolate live runtime side effects: ${isolation}`);
}
assert.ok(!routerTest.includes("vi.mock('../src/app/HomeDashboardLiveCryptoBubbleConfiguredTextEvidenceRuntime'"));

for (const phrase of [
  'Gate362 canonical GOLDEN',
  'exact released Gate362 default product configuration',
  'No Bubble geometry, palette, radius, collision, layout or motion',
  'Live Crypto Bubble and Your Trades remain separate truth domains',
]) {
  assert.ok(foundationReport.includes(phrase), `foundation report missing preserved route-integration evidence: ${phrase}`);
}

for (const phrase of [
  'Gate372 canonical GOLDEN',
  'replace the superseded configured area-weight textual runtime consumer',
  'exact released default product configuration reference',
  'No pixel radius values, min/max radii, breakpoints, collision packing, viewport layout or label-fit policy',
  'Live Crypto Bubble and Your Trades remain separate truth domains',
]) {
  assert.ok(amendmentReport.includes(phrase), `route amendment report missing ownership evidence: ${phrase}`);
}

console.log('PASS: HomeRoute now delegates the exact released default product configuration once to the Gate372 configured browser normalized-radius textual runtime, replacing the superseded area-weight route consumer while preserving route, provider, product, persistence, Your Trades, and pixel-renderer boundaries.');
