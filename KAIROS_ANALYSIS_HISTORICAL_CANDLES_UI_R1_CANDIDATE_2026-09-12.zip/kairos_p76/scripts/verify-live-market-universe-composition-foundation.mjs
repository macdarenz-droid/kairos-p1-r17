import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/liveMarketUniverseComposition.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_LIVE_MARKET_UNIVERSE_COMPOSITION_FOUNDATION_REPORT_2026-09-09.md', import.meta.url), 'utf8');

for (const token of [
  'LiveMarketUniverseInstrumentMetadataFact',
  'LiveMarketSummaryFact',
  'MarketDataInstrument',
  'extends LiveMarketUniverseInstrumentEligibilityPolicyOptions',
  'isLiveMarketUniverseInstrumentEligible(fact, options)',
  '`${instrument.venue.trim()}::${instrument.symbol.trim()}`',
  'orderLiveMarketUniverseByQuoteVolume(joinedSummaryFacts)',
  'selectLiveMarketUniverseTopN(orderedFacts, options.topNCount)',
  'return selectedFacts.map((fact) => fact.instrument)',
]) if (!source.includes(token)) throw new Error(`universe composition evidence missing: ${token}`);

if (!index.includes("export * from './liveMarketUniverseComposition';")) throw new Error('universe composition public export missing');

for (const forbidden of [
  "quoteAsset === 'USDT'", 'tradingEnabled', 'quoteVolume24h', '.sort(', '.slice(',
  'DEFAULT_LIVE_MARKET_UNIVERSE_TOP_N_COUNT', '= 30', 'fetch(', 'XMLHttpRequest',
  'WebSocket(', 'JSON.parse(', 'setInterval(', 'setTimeout(', 'Date.now(', 'new Date(',
  'indexedDB', 'createChart(', 'React', 'useEffect', 'bubbleSize', 'marketCap',
]) if (source.includes(forbidden)) throw new Error(`universe composition duplicated/broadened policy: ${forbidden}`);

for (const token of [
  'provider-neutral Live Market Universe composition',
  'exact instrument-identity join',
  'released eligibility',
  'released quote-volume ordering',
  'released Top-N selection',
  'No provider transport',
  'No freshness/cadence/lifecycle',
  'No React/Home/Bubble presentation',
]) if (!report.includes(token)) throw new Error(`universe composition report evidence missing: ${token}`);

console.log('Live Market Universe composition verification passed.');
