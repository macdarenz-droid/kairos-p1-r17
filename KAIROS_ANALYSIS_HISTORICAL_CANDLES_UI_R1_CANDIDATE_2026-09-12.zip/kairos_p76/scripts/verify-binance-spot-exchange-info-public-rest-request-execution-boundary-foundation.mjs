import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpotExchangeInfoPublicRestRequestExecution.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_BINANCE_SPOT_EXCHANGE_INFO_PUBLIC_REST_REQUEST_EXECUTION_BOUNDARY_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');

for (const token of [
  'BinanceSpotExchangeInfoPublicRestRequestDescriptor',
  'BinanceSpotExchangeInfoPublicRestExecutionOptions',
  'signal?: AbortSignal',
  'BinanceSpotExchangeInfoPublicRestRequestConnector',
  'executeBinanceSpotExchangeInfoPublicRestRequest',
  'return connect(request)',
  'return connect(request, options)',
]) if (!source.includes(token)) throw new Error(`exchangeInfo execution evidence missing: ${token}`);

if (!index.includes("export * from './providers/binance/binanceSpotExchangeInfoPublicRestRequestExecution';")) {
  throw new Error('exchangeInfo execution barrel export missing');
}

for (const forbidden of [
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'Response', 'JSON.parse(', 'baseAsset:', 'quoteAsset:', 'tradingEnabled:',
  'USDT', 'stablecoin', '.sort(', 'Top 30', 'topN', 'setTimeout(', 'setInterval(', 'indexedDB', 'new AbortController',
]) if (source.includes(forbidden)) throw new Error(`execution boundary broadened into forbidden scope: ${forbidden}`);

for (const token of [
  'No concrete fetch/XHR/WebSocket/browser transport',
  'No HTTP status/header/body interpretation',
  'No JSON parsing',
  'No mapping to `LiveMarketUniverseInstrumentMetadataFact`',
  'No cache/polling/refresh/retry',
  'No USDT eligibility filtering',
  'No freshness changes',
  'No Your Trades/journal',
]) if (!report.includes(token)) throw new Error(`execution report evidence missing: ${token}`);

console.log('Binance Spot exchangeInfo public REST request execution boundary verification passed.');
