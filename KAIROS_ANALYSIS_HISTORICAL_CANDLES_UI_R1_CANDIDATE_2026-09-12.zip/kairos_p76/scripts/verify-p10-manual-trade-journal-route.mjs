import fs from 'node:fs';
import process from 'node:process';

const route = fs.readFileSync('src/app/JournalRoute.tsx', 'utf8');
const routes = fs.readFileSync('src/app/routes.tsx', 'utf8');
const css = fs.readFileSync('src/app/journalRoute.css', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));

// P10's currency validation error uses this exact field address. It is saved
// input metadata, not P11 arithmetic. Keep the original forbidden vocabulary
// everywhere else and explicitly reject calculator imports/calls/conversion.
const routeWithoutCurrencyFieldAddress = route.replaceAll("'grossPnlCurrency'", "''");

const checks = [
  ['Journal route replaces placeholder', routes.includes("{ path: 'journal', element: <JournalRoute /> }")],
  ['Uses P10.2 draft adapter', route.includes('prepareManualTradeSubmission(draft)')],
  ['Uses P10.1 save command', route.includes('saveManualTrade(db, prepared.input)')],
  ['Uses authoritative database by default', route.includes('db = kairosDatabase')],
  ['No direct IndexedDB API', !route.includes('indexedDB.') && !route.includes('.transaction(')],
  ['No P11 calculation logic', !routeWithoutCurrencyFieldAddress.match(/profit|loss|riskReward|leverage|pnl/i) && !route.match(/domain\/calculations|decimal\.js|calculateTradeMetrics|parseFloat\s*\(|Number\s*\(/)],
  ['Explicit labels are present', route.includes('htmlFor="kairos-trade-symbol"') && route.includes('id="kairos-trade-symbol"')],
  ['Required selections start empty', route.includes('<option value="">Choose market</option>') && route.includes('<option value="">Choose direction</option>') && route.includes('<option value="">Choose status</option>')],
  ['Open/closed timestamp controls exist', route.includes('type="datetime-local"') && route.includes('showClosedAt')],
  ['Form is preserved on failure', route.includes('Your form has been kept so you can try again.')],
  ['Form clears only in success branch', route.indexOf('setDraft(createEmptyManualTradeDraft())') > route.indexOf("if (!result.ok)")],
  ['Mobile layout contract exists', css.includes('@media (max-width: 34rem)')],
  ['Semantic tokens own presentation', css.includes('var(--kairos-surface-card)') && css.includes('var(--kairos-accent-primary)')],
  ['Verifier script is registered', pkg.scripts?.['verify:p10:manual-trade-journal-route'] === 'node scripts/verify-p10-manual-trade-journal-route.mjs'],
];

let failed = false;
for (const [name, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`);
  if (!ok) failed = true;
}
if (failed) process.exit(1);
