import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const component = readFileSync('src/app/HomeDashboardLiveCryptoBubbleTextEvidence.tsx', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-text-evidence-presentation-foundation.test.tsx', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-text-evidence-presentation-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-text-evidence-presentation-foundation.mjs',
);

for (const required of [
  "import type { HomeDashboardLiveCryptoBubbleReactAreaWeightViewModel }",
  'readonly model: HomeDashboardLiveCryptoBubbleReactAreaWeightViewModel',
  'data-runtime-status={runtimeState.status}',
  "data-projection-status=\"none\"",
  "data-projection-status=\"failed\"",
  "data-projection-status=\"available\"",
  'metricInput.instrument.symbol',
  'presentationEntry.availability',
  'presentationEntry.freshnessState',
  'presentationEntry.movementSemantic',
  'metricInput.quoteVolume24h',
  'metricInput.movementPercent24h',
  'entry.areaWeight',
]) {
  assert.ok(component.includes(required), `component missing required released evidence use: ${required}`);
}

for (const forbidden of [
  'useHomeDashboardLiveCryptoBubbleReactAreaWeightViewModel',
  'useHomeDashboardLiveCryptoBubblePresentationObservedRuntime',
  'useState(',
  'useEffect(',
  'useMemo(',
  'setInterval(',
  'setTimeout(',
  'requestAnimationFrame(',
  'decimalDivide(',
  'decimalMultiply(',
  'decimalSubtract(',
  'parseDecimalString(',
  'Math.sqrt(',
  '<svg',
  '<circle',
  '<canvas',
  'style=',
  "import './",
  'HomeRoute',
  'indexedDB',
]) {
  assert.ok(!component.includes(forbidden), `component must not own forbidden behavior: ${forbidden}`);
}

assert.ok(test.includes('renderToStaticMarkup'));
assert.ok(test.includes("runtimeState('acquisition-failed'"));
assert.ok(test.includes("reason: 'area-weight-entry-inconsistent'"));
assert.ok(test.includes("html.indexOf('BTCUSDT')"));

console.log('PASS: Home Live Crypto Bubble textual evidence presentation consumes released view-model truth without owning runtime, arithmetic, geometry, styling, route wiring, or persistence.');
