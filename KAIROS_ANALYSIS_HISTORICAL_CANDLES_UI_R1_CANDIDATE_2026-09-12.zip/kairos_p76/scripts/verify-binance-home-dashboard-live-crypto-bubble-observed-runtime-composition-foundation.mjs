import { readFileSync } from 'node:fs';

const source = readFileSync('src/app/binanceHomeDashboardLiveCryptoBubbleObservedRuntimeComposition.ts', 'utf8');
const test = readFileSync('tests/binance-home-dashboard-live-crypto-bubble-observed-runtime-composition-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_BINANCE_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_OBSERVED_RUNTIME_COMPOSITION_FOUNDATION_REPORT_2026-09-10.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'startBinanceHomeDashboardLiveCryptoBubbleObservedRuntime',
  "extends Omit<BinanceHomeDashboardLiveMarketObservedRuntimeCompositionOptions, 'observationSink'>",
  'createHomeDashboardLiveCryptoBubbleMetricObservationSink(',
  'options.observationSink,',
  'startBinanceHomeDashboardLiveMarketObservedRuntime(',
  'readObservedAt,',
  'readEvaluationTimeMs,',
  'universe: options.universe,',
  'lifecycle: options.lifecycle,',
  'observationSink,',
]) {
  if (!source.includes(token)) throw new Error(`Bubble observed-runtime composition evidence missing: ${token}`);
}

for (const forbidden of [
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'fetch(', 'XMLHttpRequest', 'WebSocket(',
  'React', 'useEffect', 'useState', 'indexedDB', 'AbortController', '.sort(', '.filter(', '.reduce(',
  '15_000', '60_000', 'freshMaxAgeMs', 'staleMaxAgeMs', 'priceChangePercent', 'radius', 'palette', 'color:',
  'projectLiveCryptoBubbleMetricInputs(', 'createHomeDashboardLiveMarketSummaryFreshnessObservationObserver(',
]) {
  if (source.includes(forbidden)) throw new Error(`Bubble observed-runtime composition broadened ownership: ${forbidden}`);
}

for (const token of [
  'creates exactly one Gate344 Bubble observation adapter and delegates once to Gate341 while preserving caller dependencies by reference',
  'preserves a failed Gate341 runtime result unchanged and owns the adaptation slot when no downstream sink is supplied',
]) {
  if (!test.includes(token)) throw new Error(`Missing Bubble observed-runtime composition regression: ${token}`);
}

for (const token of [
  'app-level Binance Home Live Crypto Bubble observed-runtime composition',
  'constructs exactly one Gate344 adapter',
  "returns Gate341's runtime bootstrap result unchanged",
  'No React/Home/Bubble rendering',
]) {
  if (!report.includes(token)) throw new Error(`Bubble observed-runtime composition report evidence missing: ${token}`);
}

const verifyName = 'verify:binance-home-dashboard-live-crypto-bubble-observed-runtime-composition-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-binance-home-dashboard-live-crypto-bubble-observed-runtime-composition-foundation.mjs') {
  throw new Error('Bubble observed-runtime composition verifier registration mismatch');
}

console.log('PASS: Binance Home Live Crypto Bubble observed-runtime composition owns only Gate344-to-Gate341 adaptation and remains presentation-free.');
