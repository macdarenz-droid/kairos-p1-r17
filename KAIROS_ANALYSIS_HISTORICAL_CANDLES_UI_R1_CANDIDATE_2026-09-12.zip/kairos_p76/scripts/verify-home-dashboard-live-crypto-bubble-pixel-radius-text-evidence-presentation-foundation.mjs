import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const component = readFileSync('src/app/HomeDashboardLiveCryptoBubblePixelRadiusTextEvidence.tsx', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-pixel-radius-text-evidence-presentation-foundation.test.tsx', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-pixel-radius-text-evidence-presentation-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-pixel-radius-text-evidence-presentation-foundation.mjs',
);

for (const required of [
  "import type { HomeDashboardLiveCryptoBubblePixelRadiusProjectionResult }",
  'readonly projection: HomeDashboardLiveCryptoBubblePixelRadiusProjectionResult',
  "data-pixel-radius-projection-status={projection.ok ? 'available' : 'failed'}",
  'Pixel radius projection status: {projection.reason}',
  'entry.radiusScaleEntry.areaWeightEntry.presentationEntry.metricInput.instrument',
  'entry.radiusCssPixels',
  "entry.radiusCssPixels ?? 'missing'",
]) {
  assert.ok(component.includes(required), `component missing required released pixel-radius evidence use: ${required}`);
}

for (const forbidden of [
  'projectHomeDashboardLiveCryptoBubblePixelRadii',
  'validateHomeDashboardLiveCryptoBubblePixelRadiusPolicy',
  'minimumRadiusCssPixels +',
  'maximumRadiusCssPixels -',
  'useHomeDashboardLiveCryptoBubble',
  'useState(',
  'useEffect(',
  'useMemo(',
  'Date.now(',
  'new Date(',
  'setInterval(',
  'setTimeout(',
  'requestAnimationFrame(',
  'window.',
  'document.',
  'matchMedia(',
  'ResizeObserver',
  '<svg',
  '<circle',
  '<canvas',
  'style=',
  "import './",
  'HomeRoute',
  'indexedDB',
]) {
  assert.ok(!component.includes(forbidden), `component must not own forbidden behavior: ${forbidden}`);
}

assert.ok(test.includes('renderToStaticMarkup'));
assert.ok(test.includes("reason: 'radius-scale-projection-invalid'"));
assert.ok(test.includes("reason: 'pixel-radius-policy-invalid'"));
assert.ok(test.includes("reason: 'pixel-radius-entry-invalid'"));
assert.ok(test.includes("html.indexOf('BTCUSDT')"));
assert.ok(test.includes('radiusCssPixels: null'));

console.log('PASS: Home Live Crypto Bubble pixel-radius textual evidence presenter consumes released Gate375 CSS-pixel radius truth without owning bounds, arithmetic, viewport/layout, renderer, styling, route wiring, runtime, or persistence.');
