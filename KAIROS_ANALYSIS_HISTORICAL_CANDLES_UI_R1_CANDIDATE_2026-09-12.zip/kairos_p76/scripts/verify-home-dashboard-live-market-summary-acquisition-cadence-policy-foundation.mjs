import { readFileSync } from 'node:fs';

const sourcePath = 'src/application/dashboard/homeDashboardLiveMarketSummaryAcquisitionCadencePolicy.ts';
const source = readFileSync(sourcePath, 'utf8');
const test = readFileSync('tests/home-dashboard-live-market-summary-acquisition-cadence-policy-foundation.test.ts', 'utf8');

const requiredSource = [
  'HOME_DASHBOARD_LIVE_MARKET_SUMMARY_VISIBLE_ACQUISITION_INTERVAL_MS = 5_000',
  "'entry'",
  "'resume'",
  "'periodic'",
  "'visible' | 'hidden'",
  'acquireNow: false',
  'nextVisibleAcquisitionAfterMs: null',
  'acquireNow: true',
];
for (const token of requiredSource) {
  if (!source.includes(token)) throw new Error(`missing cadence-policy evidence: ${token}`);
}

const forbidden = [
  'setInterval(', 'setTimeout(', 'document.', 'visibilityState', 'addEventListener(',
  'fetch(', 'WebSocket', 'Date.now(', 'new Date(', 'React', 'useEffect(', 'useState(',
  'Binance', 'quoteVolume24h', 'stablecoin', 'TopN', 'FRESH', 'STALE', 'EXPIRED',
];
for (const token of forbidden) {
  if (source.includes(token)) throw new Error(`cadence policy leaked forbidden ownership: ${token}`);
}

if (!test.includes("toBe(5000)")) throw new Error('missing exact five-second policy test');
if (!test.includes("'hidden'")) throw new Error('missing hidden-suspension test');
console.log('Home Dashboard live-market acquisition cadence policy foundation verifier PASS');
