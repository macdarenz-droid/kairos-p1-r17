import { readFileSync } from 'node:fs';

const source = readFileSync('src/app/homeDashboardLiveCryptoBubbleReactRadiusScaleViewModel.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-react-radius-scale-view-model-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_REACT_RADIUS_SCALE_VIEW_MODEL_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'HomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel',
  "areaWeightViewModel: HomeDashboardLiveCryptoBubbleReactAreaWeightViewModel",
  "runtimeState: HomeDashboardLiveCryptoBubbleReactAreaWeightViewModel['runtimeState']",
  'radiusScaleProjection: HomeDashboardLiveCryptoBubbleRadiusScaleProjectionResult | null',
  'projectHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel',
  'const runtimeState = areaWeightViewModel.runtimeState',
  'const areaWeightProjection = areaWeightViewModel.areaWeightProjection',
  'if (areaWeightProjection === null)',
  'radiusScaleProjection: null',
  'projectHomeDashboardLiveCryptoBubbleRadiusScales(areaWeightProjection)',
]) {
  if (!source.includes(token)) throw new Error(`React radius-scale view-model evidence missing: ${token}`);
}

if ((source.match(/projectHomeDashboardLiveCryptoBubbleRadiusScales\(/g) ?? []).length !== 1) {
  throw new Error('React radius-scale view model must delegate to Gate364 exactly once');
}

for (const forbidden of [
  "from 'react'", 'useEffect', 'useState', 'useMemo', 'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'startBinanceHomeDashboard', '.sort(', '.filter(', '.reverse(',
  'decimalAdd(', 'decimalSubtract(', 'decimalMultiply(', 'decimalDivide(', 'parseDecimalString(',
  'Math.sqrt(', 'Math.pow(', 'borderRadius', 'radius:', 'minRadius', 'maxRadius', 'width:', 'height:', 'left:', 'top:',
  'className=', '<div', '<svg', 'neutralMaxAbsoluteMovementPercent', 'stablecoin', 'topN', 'Top 30',
  'freshMaxAgeMs', 'staleMaxAgeMs', 'indexedDB',
]) {
  if (source.includes(forbidden)) throw new Error(`React radius-scale view model broadened ownership: ${forbidden}`);
}

for (const token of [
  'preserves exact area-weight view-model and runtime-state references before radius evidence exists',
  'delegates the exact successful area-weight projection once into released Gate364 radius-scale evidence',
  'preserves released area-weight failure evidence through Gate364 without fabricating radius output',
  'keeps last authoritative radius evidence composable when runtime status reports a later acquisition failure',
]) {
  if (!test.includes(token)) throw new Error(`Missing React radius-scale view-model regression: ${token}`);
}

for (const token of [
  'one pure app-level composition seam',
  'preserves that exact object and its exact `runtimeState` reference',
  'passes only the exact `areaWeightProjection` reference into `projectHomeDashboardLiveCryptoBubbleRadiusScales(...)` once',
  'No React hook/state/effect or wall clock',
  'Live Crypto Bubble Map and Your Trades Bubble Map remain separate truth domains',
]) {
  if (!report.includes(token)) throw new Error(`React radius-scale view-model report evidence missing: ${token}`);
}

const verifyName = 'verify:home-dashboard-live-crypto-bubble-react-radius-scale-view-model-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-home-dashboard-live-crypto-bubble-react-radius-scale-view-model-foundation.mjs') {
  throw new Error('React radius-scale view-model verifier registration mismatch');
}

console.log('PASS: Home Live Crypto Bubble React radius-scale view model composes released area-weight evidence with Gate364 without owning pixels, React state, or market truth.');
