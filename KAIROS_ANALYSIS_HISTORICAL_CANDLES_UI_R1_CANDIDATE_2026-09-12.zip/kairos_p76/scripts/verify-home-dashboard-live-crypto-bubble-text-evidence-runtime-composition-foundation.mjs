import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const component = readFileSync('src/app/HomeDashboardLiveCryptoBubbleTextEvidenceRuntime.tsx', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-text-evidence-runtime-composition-foundation.test.tsx', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-text-evidence-runtime-composition-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-text-evidence-runtime-composition-foundation.mjs',
);

for (const required of [
  "import { HomeDashboardLiveCryptoBubbleTextEvidence }",
  'useHomeDashboardLiveCryptoBubbleReactAreaWeightViewModel',
  'readonly readObservedAt: BinanceSpot24hPublicRestBaselineObservedAtSource',
  'readonly readEvaluationTimeMs: HomeDashboardLiveMarketSummaryFreshnessEvaluationTimeSource',
  'readonly options: HomeDashboardLiveCryptoBubbleReactRuntimeBindingOptions',
  'readObservedAt,',
  'readEvaluationTimeMs,',
  'options,',
  '<HomeDashboardLiveCryptoBubbleTextEvidence model={model} />',
]) {
  assert.ok(component.includes(required), `runtime composition missing required released delegation: ${required}`);
}

for (const forbidden of [
  'useState(',
  'useEffect(',
  'useMemo(',
  'useCallback(',
  'setInterval(',
  'setTimeout(',
  'requestAnimationFrame(',
  'Date.now(',
  'new Date(',
  'decimalDivide(',
  'decimalMultiply(',
  'decimalSubtract(',
  'parseDecimalString(',
  'Math.sqrt(',
  '<svg',
  '<circle',
  '<canvas',
  'style=',
  "import './",
  'HomeRoute',
  'indexedDB',
]) {
  assert.ok(!component.includes(forbidden), `runtime composition must not own forbidden behavior: ${forbidden}`);
}

assert.equal((component.match(/useHomeDashboardLiveCryptoBubbleReactAreaWeightViewModel\(/g) ?? []).length, 1);
assert.equal((component.match(/<HomeDashboardLiveCryptoBubbleTextEvidence model=\{model\} \/>/g) ?? []).length, 1);
assert.ok(test.includes('expect(hookMock).toHaveBeenCalledTimes(1)'));
assert.ok(test.includes('expect(observedAtArg).toBe(readObservedAt)'));
assert.ok(test.includes('expect(evaluationArg).toBe(readEvaluationTimeMs)'));
assert.ok(test.includes('expect(optionsArg).toBe(options)'));
assert.ok(test.includes('renderToStaticMarkup'));

console.log('PASS: Home Live Crypto Bubble textual-evidence runtime composition joins released Gate355 hook output to released Gate356 presenter without owning defaults, runtime state, arithmetic, geometry, styling, route wiring, or persistence.');
