import { readFileSync } from 'node:fs';

const source = readFileSync('src/application/dashboard/homeDashboardLiveCryptoBubblePresentationStateObservationBridge.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-presentation-state-observation-bridge-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_PRESENTATION_STATE_OBSERVATION_BRIDGE_FOUNDATION_REPORT_2026-09-10.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'createHomeDashboardLiveCryptoBubblePresentationStateObservationSink',
  'HomeDashboardLiveCryptoBubbleMetricObservationSink',
  'readonly metricObservation: HomeDashboardLiveCryptoBubbleMetricObservation',
  'readonly presentationStateProjection: HomeDashboardLiveCryptoBubblePresentationStateProjectionResult',
  'policy: HomeDashboardLiveCryptoBubblePresentationPolicy',
  'projectHomeDashboardLiveCryptoBubblePresentationState(',
  'metricObservation,',
  'policy,',
  'presentationStateProjection,',
  'sink.onError?.(error)',
]) {
  if (!source.includes(token)) throw new Error(`Bubble presentation-state observation bridge evidence missing: ${token}`);
}

if ((source.match(/projectHomeDashboardLiveCryptoBubblePresentationState\(/g) ?? []).length !== 1) {
  throw new Error('Bubble presentation-state projection must be delegated exactly once in the bridge source');
}

for (const forbidden of [
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'fetch(', 'XMLHttpRequest', 'WebSocket(',
  "from 'react'", 'useEffect', 'useState', 'indexedDB', 'AbortController', '.sort(', '.filter(', '.reduce(',
  '15_000', '60_000', 'freshMaxAgeMs', 'staleMaxAgeMs', 'priceChangePercent',
  'borderRadius', 'width:', 'height:', 'left:', 'top:', 'transform:', 'className=', '<div', '<svg',
  'startBinanceHomeDashboardLiveCryptoBubbleObservedRuntime(',
]) {
  if (source.includes(forbidden)) throw new Error(`Bubble presentation-state observation bridge broadened ownership: ${forbidden}`);
}

for (const token of [
  'preserves the exact metric observation and applies the exact caller-owned presentation policy once',
  'keeps deterministic presentation-state projection failure as observation data rather than lifecycle error',
  'forwards the upstream error channel unchanged',
  'does not swallow downstream presentation-state observation sink failures',
]) {
  if (!test.includes(token)) throw new Error(`Missing Bubble presentation-state observation bridge regression: ${token}`);
}

for (const token of [
  'provider-neutral Home Dashboard Live Crypto Bubble presentation-state observation bridge below React',
  'exact original Bubble metric-observation object',
  'Deterministic Gate346 projection failures remain observation data',
  'does not start the Binance runtime or render Bubble UI',
]) {
  if (!report.includes(token)) throw new Error(`Bubble presentation-state observation bridge report evidence missing: ${token}`);
}

const verifyName = 'verify:home-dashboard-live-crypto-bubble-presentation-state-observation-bridge-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-home-dashboard-live-crypto-bubble-presentation-state-observation-bridge-foundation.mjs') {
  throw new Error('Bubble presentation-state observation bridge verifier registration mismatch');
}

console.log('PASS: Home Live Crypto Bubble presentation-state observation bridge preserves exact observation truth and remains below React/runtime/style ownership.');
