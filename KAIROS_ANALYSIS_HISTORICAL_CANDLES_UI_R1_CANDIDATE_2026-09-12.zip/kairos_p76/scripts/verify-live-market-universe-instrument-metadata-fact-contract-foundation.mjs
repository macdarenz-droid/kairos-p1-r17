import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/liveMarketUniverseInstrumentMetadataFact.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_LIVE_MARKET_UNIVERSE_INSTRUMENT_METADATA_FACT_CONTRACT_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');

for (const token of [
  'export interface LiveMarketUniverseInstrumentMetadataFact',
  'readonly instrument: MarketDataInstrument;',
  'readonly baseAsset: string;',
  'readonly quoteAsset: string;',
  'readonly tradingEnabled: boolean;',
  'validateLiveMarketUniverseInstrumentMetadataFact',
  "'instrument-required'",
  "'base-asset-required'",
  "'quote-asset-required'",
]) if (!source.includes(token)) throw new Error(`universe metadata fact evidence missing: ${token}`);

if (!index.includes("export * from './liveMarketUniverseInstrumentMetadataFact';")) throw new Error('universe metadata fact public export missing');

for (const forbidden of [
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'Date.now(', 'new Date(', 'setInterval(', 'setTimeout(',
  '.sort(', '.filter(', 'USDT', 'Top 30', 'stablecoin', 'quoteVolume24h', 'indexedDB', 'React', 'useEffect',
]) if (source.includes(forbidden)) throw new Error(`metadata fact broadened into forbidden policy/transport/presentation scope: ${forbidden}`);

for (const token of [
  'provider-neutral market-data metadata fact contract',
  'Released `LiveMarketSummaryFact` already owns `quoteVolume24h`',
  'No Binance HTTP request, decoder, exchangeInfo adapter, transport, polling or cache',
  'separate deterministic universe-policy owner',
]) if (!report.includes(token)) throw new Error(`universe metadata report evidence missing: ${token}`);

console.log('Live Market Universe instrument metadata fact contract verification passed.');
