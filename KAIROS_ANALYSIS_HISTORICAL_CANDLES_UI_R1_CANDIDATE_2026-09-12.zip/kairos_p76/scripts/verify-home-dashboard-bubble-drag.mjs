import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = path => readFileSync(path, 'utf8');
const motion = read('src/app/homeDashboardGlassMotion.ts');
const hook = read('src/app/useHomeDashboardGlassMotion.ts');
const drag = read('src/app/homeDashboardGlassDrag.ts');
const css = read('src/app/homeDashboardGlassBubbleMap.css');
for (const [owner, source] of [['physics', motion], ['runtime', hook], ['gesture', drag]]) {
  for (const forbidden of [/indexedDB|localStorage|sessionStorage/, /\bfetch\s*\(|WebSocket|setInterval\s*\(/, /from\s+['"][^'"]*(?:application|domain|data|services)\//, /calculateTradeMetrics|grossPnl|quoteVolume24h|movementPercent24h/]) assert(!forbidden.test(source), `${owner} must remain presentation only: ${forbidden}`);
}
assert.equal((hook.match(/bindHomeDashboardGlassDrag\(field/g) ?? []).length, 1, 'One shared gesture binding');
for (const owner of ['src/app/HomeDashboardGlassBubbleMap.tsx', 'src/app/HomeDashboardYourTrades.tsx']) {
  assert(read(owner).includes('useHomeDashboardGlassMotion('), `${owner} must use the shared motion owner`);
  assert(!/pointerdown|touchmove|stepGlassBodies\(/.test(read(owner)), 'No per-view competing physics or gestures');
}
for (const contract of ['constrainGlassPoint', 'GLASS_MAX_SPEED', 'Math.exp(-3*dt)', 'a===held?0', 'b===held?0', 'reducedMotion']) assert(motion.includes(contract), contract);
for (const contract of ['GLASS_HOLD_MS', 'SCROLL_SLOP', 'passive: false', 'event.cancelable', 'pointercancel', 'lostpointercapture', 'touchcancel', 'multiTouch', 'event.detail !== 0', 'dispose()', 'clearTimeout']) assert(drag.includes(contract), contract);
for (const contract of ['synchronize', 'state.bodies.get(c.key)', 'visibilitychange', 'prefers-reduced-motion: reduce', 'input.cancel()', 'input.dispose()', 'cancelAnimationFrame']) assert(hook.includes(contract), contract);
assert(css.includes('touch-action: manipulation'));
assert(!/touch-action:\s*none/.test(css), 'Do not globally block page pan or pinch');
assert(css.includes('[data-glass-dragging="true"]'));
assert(css.includes('var(--kairos-state-focus)'));
assert(read('src/app/HomeDashboardYourTrades.tsx').includes('onClick={()=>setSelected(trade.id)}'), 'Trade selection stays React-owned');
console.log('PASS: one shared bounded motion/gesture owner, native scroll, lifecycle/reduced-motion guards, theme feedback and separate market/trade truth.');
