import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/liveMarketUniverseAcquisitionOrchestration.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_LIVE_MARKET_UNIVERSE_ACQUISITION_ORCHESTRATION_FOUNDATION_REPORT_2026-09-09.md', import.meta.url), 'utf8');

for (const token of [
  'LiveMarketUniverseInstrumentMetadataAcquisitionPort',
  'LiveMarketSummaryBaselineAcquisitionPort',
  'extends LiveMarketUniverseCompositionOptions',
  'metadataAcquisitionPort.acquireInstrumentMetadata',
  'isLiveMarketUniverseInstrumentEligible(fact, options)',
  'baselineAcquisitionPort.acquireBaseline(eligibleScope',
  'composeLiveMarketUniverse(',
  "if (eligibleScope.length === 0) return { ok: true, instruments: [] }",
  "return { ok: false, reason: 'acquisition-failed' }",
]) if (!source.includes(token)) throw new Error(`universe acquisition orchestration evidence missing: ${token}`);

if (!index.includes("export * from './liveMarketUniverseAcquisitionOrchestration';")) {
  throw new Error('universe acquisition orchestration public export missing');
}

for (const forbidden of [
  "quoteAsset === 'USDT'", 'tradingEnabled', 'quoteVolume24h', '.sort(', '.slice(',
  'DEFAULT_LIVE_MARKET_UNIVERSE_TOP_N_COUNT', '= 30', 'fetch(', 'XMLHttpRequest',
  'WebSocket(', 'JSON.parse(', 'setInterval(', 'setTimeout(', 'Date.now(', 'new Date(',
  'indexedDB', 'createChart(', 'React', 'useEffect', 'bubbleSize', 'marketCap', 'retry',
]) if (source.includes(forbidden)) throw new Error(`universe acquisition orchestration duplicated/broadened ownership: ${forbidden}`);

for (const token of [
  'provider-neutral one-shot Live Market Universe acquisition orchestration',
  'metadata acquisition',
  'released eligibility policy',
  'exact eligible acquisition scope',
  'baseline acquisition',
  'Gate334 composition',
  'empty eligible scope',
  'No provider choice or request/transport/decode/mapping',
  'No freshness/cadence/lifecycle',
  'No React/Home/Bubble presentation',
]) if (!report.includes(token)) throw new Error(`universe acquisition orchestration report evidence missing: ${token}`);

console.log('Live Market Universe acquisition orchestration verification passed.');
