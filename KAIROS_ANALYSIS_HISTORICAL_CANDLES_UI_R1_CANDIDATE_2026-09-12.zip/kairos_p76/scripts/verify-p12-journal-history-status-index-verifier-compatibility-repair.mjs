import { readFile } from 'node:fs/promises';
const read = (p) => readFile(new URL(`../${p}`, import.meta.url), 'utf8');
const [schema,p5,p9,migrations] = await Promise.all([
  read('src/data/database/schema.ts'),
  read('scripts/verify-p5-database-kernel.mjs'),
  read('scripts/verify-p9-trade-persistence.mjs'),
  read('src/data/database/migrations.ts'),
]);
const checks = [
  [schema.includes('KAIROS_DB_SCHEMA_VERSION = 4 as const') && schema.includes('KAIROS_V3_STORES'), 'current schema must be v4 while V3 remains preserved'],
  [schema.includes("trades: '&id,status,symbol,updatedAt'"), 'released V2 trade schema history must remain present'],
  [schema.includes("trades: '&id,status,symbol,updatedAt,[status+updatedAt]'"), 'released V3 compound index must remain present'],
  [p5.includes('Released V3 status+updatedAt index is missing.'), 'P5 verifier must validate released V3 while allowing current V4'],
  [p9.includes('Current schema must be v4 while preserving the P12 V3 index migration'), 'P9 verifier must allow current V4 while preserving V3'],
  [p9.includes('V4 must append to immutable V1/V2/V3 history'), 'P9 verifier must require append-only V1/V2/V3/V4 history'],
  [migrations.includes('KAIROS_V1_MIGRATION') && migrations.includes('KAIROS_V2_MIGRATION') && migrations.includes('KAIROS_V3_MIGRATION') && migrations.includes('KAIROS_V4_MIGRATION'), 'V1/V2/V3/V4 migrations must all be registered'],
];
for (const [ok,message] of checks) if (!ok) throw new Error(message);
console.log('P12.4R3 historical verifier compatibility repair: PASS');
