import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const source = readFileSync('src/app/useHomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleViewModel.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-configured-browser-radius-scale-hook-composition-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_CONFIGURED_BROWSER_RADIUS_SCALE_HOOK_COMPOSITION_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

const verifyName = 'verify:home-dashboard-live-crypto-bubble-configured-browser-radius-scale-hook-composition-foundation';
assert.equal(
  pkg.scripts?.[verifyName],
  'node scripts/verify-home-dashboard-live-crypto-bubble-configured-browser-radius-scale-hook-composition-foundation.mjs',
);

for (const required of [
  'useHomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleViewModel',
  'configuration: HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration',
  'composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions(configuration)',
  'useHomeDashboardLiveCryptoBubbleBrowserRadiusScaleViewModel(options)',
]) {
  assert.ok(source.includes(required), `Configured browser radius-scale hook evidence missing: ${required}`);
}

assert.equal((source.match(/composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions\(configuration\)/g) ?? []).length, 1);
assert.equal((source.match(/useHomeDashboardLiveCryptoBubbleBrowserRadiusScaleViewModel\(options\)/g) ?? []).length, 1);

for (const forbidden of [
  'new Set(', 'neutralMaxAbsoluteMovementPercent:', 'excludedStablecoinBaseAssets:', 'topNCount:', 'lifecycle:',
  'useState(', 'useEffect(', 'useMemo(', 'useCallback(', 'useRef(',
  'Date.now(', 'new Date(', 'setInterval(', 'setTimeout(', 'requestAnimationFrame(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'indexedDB', 'localStorage',
  'Math.sqrt(', 'Math.pow(', 'radiusScale =', 'radiusPx', 'minRadius', 'maxRadius',
  '<svg', '<circle', '<canvas', 'className=', 'style=', 'HomeRoute', 'YourTrades',
]) {
  assert.ok(!source.includes(forbidden), `Configured browser radius-scale hook must not own forbidden behavior: ${forbidden}`);
}

for (const phrase of [
  'delegates the exact caller configuration through Gate360 into Gate368 exactly once',
  'returns the exact released Gate368 result unchanged',
  'does not retain a second configured radius-scale result owner across rerenders',
]) {
  assert.ok(test.includes(phrase), `Missing configured browser radius-scale regression: ${phrase}`);
}

for (const phrase of [
  'exact caller-owned product configuration',
  'Gate360 remains runtime-options composition owner',
  'Gate368 remains browser radius-scale hook owner',
  'No concrete stablecoin exclusion, neutral-movement value, pixel radius or viewport value',
  'Live Crypto Bubble Map and Your Trades Bubble Map remain separate authoritative truth domains',
]) {
  assert.ok(report.includes(phrase), `Foundation report missing ownership evidence: ${phrase}`);
}

console.log('PASS: configured browser radius-scale hook delegates exact caller configuration through Gate360 into Gate368 once without adding product values, clocks, state, geometry, route, persistence, or Your Trades truth.');
