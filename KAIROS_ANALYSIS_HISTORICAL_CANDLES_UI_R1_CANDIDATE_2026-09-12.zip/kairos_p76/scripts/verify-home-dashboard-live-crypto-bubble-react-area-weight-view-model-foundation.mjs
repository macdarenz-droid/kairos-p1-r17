import { readFileSync } from 'node:fs';

const source = readFileSync('src/app/homeDashboardLiveCryptoBubbleReactAreaWeightViewModel.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-react-area-weight-view-model-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_REACT_AREA_WEIGHT_VIEW_MODEL_FOUNDATION_REPORT_2026-09-10.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'HomeDashboardLiveCryptoBubbleReactAreaWeightViewModel',
  'runtimeState: HomeDashboardLiveCryptoBubbleReactRuntimeState',
  'areaWeightProjection: HomeDashboardLiveCryptoBubbleAreaWeightProjectionResult | null',
  'projectHomeDashboardLiveCryptoBubbleReactAreaWeightViewModel',
  'const observation = runtimeState.latestObservation',
  'if (observation === null)',
  'return { runtimeState, areaWeightProjection: null }',
  'projectHomeDashboardLiveCryptoBubbleAreaWeights(',
  'observation.presentationStateProjection',
]) {
  if (!source.includes(token)) throw new Error(`React area-weight view-model evidence missing: ${token}`);
}

if ((source.match(/projectHomeDashboardLiveCryptoBubbleAreaWeights\(/g) ?? []).length !== 1) {
  throw new Error('React area-weight view model must delegate to Gate352 exactly once');
}

for (const forbidden of [
  "from 'react'", 'useEffect', 'useState', 'useMemo', 'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'startBinanceHomeDashboard', '.sort(', '.filter(', '.reverse(',
  'decimalAdd(', 'decimalSubtract(', 'decimalMultiply(', 'decimalDivide(', 'parseDecimalString(',
  'Math.sqrt(', 'Math.pow(', 'borderRadius', 'radius:', 'minRadius', 'maxRadius', 'width:', 'height:', 'left:', 'top:',
  'className=', '<div', '<svg', 'neutralMaxAbsoluteMovementPercent', 'stablecoin', 'topN', 'Top 30',
  'freshMaxAgeMs', 'staleMaxAgeMs', 'indexedDB',
]) {
  if (source.includes(forbidden)) throw new Error(`React area-weight view model broadened ownership: ${forbidden}`);
}

for (const token of [
  'preserves exact Gate351 runtime state and exposes no fabricated area weights before the first observation',
  'derives released Gate352 area weights from the exact latest semantic projection while preserving runtime-state identity',
  'keeps the last authoritative area-weight evidence available when acquisition later fails',
  'preserves bootstrap error state without fabricating area-weight evidence when no observation exists',
  'preserves a released semantic projection failure as exact Gate352 non-renderable evidence',
]) {
  if (!test.includes(token)) throw new Error(`Missing React area-weight view-model regression: ${token}`);
}

for (const token of [
  'pure app-level composition seam',
  'preserves the exact Gate351 runtime-state object by reference',
  'passes only the exact `presentationStateProjection` into `projectHomeDashboardLiveCryptoBubbleAreaWeights(...)`',
  'Pixel radius, minimum/maximum radius, square-root conversion, collision/layout, theme palette/tokens',
  'Your Trades/journal truth remains completely separate',
]) {
  if (!report.includes(token)) throw new Error(`React area-weight view-model report evidence missing: ${token}`);
}

const verifyName = 'verify:home-dashboard-live-crypto-bubble-react-area-weight-view-model-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-home-dashboard-live-crypto-bubble-react-area-weight-view-model-foundation.mjs') {
  throw new Error('React area-weight view-model verifier registration mismatch');
}

console.log('PASS: Home Live Crypto Bubble React area-weight view model composes Gate351 state with Gate352 evidence without owning rendering or market truth.');
