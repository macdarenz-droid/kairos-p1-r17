import { readFileSync } from 'node:fs';
const source=readFileSync(new URL('../src/services/market-data/liveMarketUniverseTopNSelectionPolicy.ts',import.meta.url),'utf8');
const index=readFileSync(new URL('../src/services/market-data/index.ts',import.meta.url),'utf8');
for(const token of ['DEFAULT_LIVE_MARKET_UNIVERSE_TOP_N_COUNT = 30','Number.isInteger(value)','value < 1',"throw new RangeError('Live Market Universe Top-N count must be a positive integer.')",'orderedFacts.slice(0, resolveTopNCount(count))','LiveMarketSummaryFact']) if(!source.includes(token)) throw new Error('missing '+token);
if(!index.includes("export * from './liveMarketUniverseTopNSelectionPolicy';")) throw new Error('missing Top-N selection policy export');
for(const forbidden of ['.sort(','decimalSubtract','quoteVolume24h','excludedStablecoinBaseAssets','quoteAsset','fetch(','setInterval(','Date.now(','indexedDB','createChart(','React']) if(source.includes(forbidden)) throw new Error('broadened '+forbidden);
console.log('Live Market Universe Top-N selection policy verification passed.');
