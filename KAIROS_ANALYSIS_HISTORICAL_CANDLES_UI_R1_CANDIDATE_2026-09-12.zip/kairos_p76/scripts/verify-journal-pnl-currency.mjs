import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = path => readFileSync(path, 'utf8');
const field = read('src/app/JournalPriceCurrencyField.tsx');
const history = read('src/application/journal/historyQuery.ts');
const update = read('src/application/trades/updateOpenManualTrade.ts');
assert(history.includes('grossPnlCurrency: trade.grossPnlCurrency'), 'History delegates explicit stored currency to P11');
assert(history.includes('calculateTradeMetrics(trade.side, executions, undefined, fees)'), 'Legacy unknown-currency path remains');
assert(update.includes('t.grossPnlCurrency ?? null]'), 'Currency participates in stale-snapshot guard');
assert(update.includes('recorded-currency-immutable') && update.includes('!addsCurrency'), 'Only missing currency is appendable');
assert(field.includes('readOnly={recorded}') && field.includes('aria-labelledby='));
for (const source of [field, read('src/app/JournalHistoryList.tsx')]) {
  for (const forbidden of ['indexedDB', '.transaction(', 'calculateTradeMetrics(', 'parseFloat(', 'fetch(', 'WebSocket']) assert(!source.includes(forbidden), forbidden);
}
for (const path of ['src/application/trades/saveManualTrade.ts', 'src/application/trades/updateOpenManualTrade.ts', 'src/application/journal/historyQuery.ts']) {
  for (const forbidden of ['endsWith(\'USDT\')', 'split(\'/\')', 'fetch(', 'WebSocket', 'parseFloat(']) assert(!read(path).includes(forbidden), path + ': no currency inference or alternate calculator');
}
console.log('PASS: explicit currency capture, immutable recorded unit, stale guard and existing P11/P12 ownership.');
