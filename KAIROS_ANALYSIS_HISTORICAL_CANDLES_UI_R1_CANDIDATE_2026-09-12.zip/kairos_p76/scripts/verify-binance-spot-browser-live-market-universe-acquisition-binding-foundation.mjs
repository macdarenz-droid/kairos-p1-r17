import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpotBrowserLiveMarketUniverseAcquisitionBinding.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_BINANCE_SPOT_BROWSER_LIVE_MARKET_UNIVERSE_ACQUISITION_BINDING_FOUNDATION_REPORT_2026-09-09.md', import.meta.url), 'utf8');

for (const token of [
  'acquireLiveMarketUniverseOnce',
  'LiveMarketUniverseAcquisitionOptions',
  'LiveMarketUniverseAcquisitionResult',
  'BinanceSpot24hPublicRestBaselineObservedAtSource',
  'createBinanceSpotExchangeInfoBrowserInstrumentMetadataAcquisitionPort()',
  'createBinanceSpot24hBrowserPublicRestBaselineAcquisitionPort(readObservedAt)',
  'options,',
]) if (!source.includes(token)) throw new Error(`Binance browser universe binding evidence missing: ${token}`);

if (!index.includes("export * from './providers/binance/binanceSpotBrowserLiveMarketUniverseAcquisitionBinding';")) {
  throw new Error('Binance browser universe acquisition binding public export missing');
}

for (const forbidden of [
  "quoteAsset === 'USDT'", 'tradingEnabled', 'quoteVolume24h', '.sort(', '.slice(',
  'DEFAULT_LIVE_MARKET_UNIVERSE_TOP_N_COUNT', '= 30', 'JSON.parse(', 'setInterval(',
  'setTimeout(', 'Date.now(', 'new Date(', 'indexedDB', 'createChart(', 'React',
  'useEffect', 'bubbleSize', 'marketCap', 'retry', 'WebSocket(',
]) if (source.includes(forbidden)) throw new Error(`Binance browser universe binding duplicated/broadened ownership: ${forbidden}`);

for (const token of [
  'Binance Spot browser Live Market Universe acquisition binding',
  'Gate335 one-shot provider-neutral orchestration',
  'browser-ready metadata acquisition port',
  'browser-ready baseline acquisition port',
  'caller-owned readObservedAt',
  'caller-owned options and AbortSignal',
  'No universe-policy duplication',
  'No freshness/cadence/lifecycle ownership',
  'No state/session/persistence ownership',
  'No React/Home/Bubble presentation ownership',
]) if (!report.includes(token)) throw new Error(`Binance browser universe binding report evidence missing: ${token}`);

console.log('Binance Spot browser Live Market Universe acquisition binding verification passed.');
