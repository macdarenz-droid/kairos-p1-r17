import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const component = readFileSync(
  'src/app/HomeDashboardLiveCryptoBubbleConfiguredBrowserPixelRadiusTextEvidenceRuntime.tsx',
  'utf8',
);
const test = readFileSync(
  'tests/home-dashboard-live-crypto-bubble-configured-browser-pixel-radius-text-evidence-runtime-composition-foundation.test.tsx',
  'utf8',
);
const report = readFileSync(
  'KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_CONFIGURED_BROWSER_PIXEL_RADIUS_TEXT_EVIDENCE_RUNTIME_COMPOSITION_FOUNDATION_REPORT_2026-09-11.md',
  'utf8',
);
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts[
    'verify:home-dashboard-live-crypto-bubble-configured-browser-pixel-radius-text-evidence-runtime-composition-foundation'
  ],
  'node scripts/verify-home-dashboard-live-crypto-bubble-configured-browser-pixel-radius-text-evidence-runtime-composition-foundation.mjs',
);

for (const required of [
  "import { HomeDashboardLiveCryptoBubblePixelRadiusTextEvidence }",
  'readonly configuration: HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration',
  'readonly policy: HomeDashboardLiveCryptoBubblePixelRadiusPolicy',
  'useHomeDashboardLiveCryptoBubbleConfiguredBrowserPixelRadiusViewModel(',
  'configuration,',
  'policy,',
  'model.pixelRadiusProjection === null',
  'data-pixel-radius-projection-status="unavailable"',
  'projection={model.pixelRadiusProjection}',
]) {
  assert.ok(component.includes(required), `configured pixel-radius text runtime missing exact released delegation: ${required}`);
}

assert.equal(
  (
    component.match(
      /useHomeDashboardLiveCryptoBubbleConfiguredBrowserPixelRadiusViewModel\(/g,
    ) ?? []
  ).length,
  1,
);
assert.equal(
  (component.match(/<HomeDashboardLiveCryptoBubblePixelRadiusTextEvidence/g) ?? []).length,
  1,
);

for (const forbidden of [
  'composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions(',
  'new Set(',
  'neutralMaxAbsoluteMovementPercent:',
  'excludedStablecoinBaseAssets:',
  'topNCount:',
  'lifecycle:',
  'useState(',
  'useEffect(',
  'useMemo(',
  'useCallback(',
  'Date.now(',
  'new Date(',
  'setInterval(',
  'setTimeout(',
  'requestAnimationFrame(',
  'fetch(',
  'XMLHttpRequest',
  'WebSocket(',
  'indexedDB',
  'localStorage',
  'Math.sqrt(',
  'decimalDivide(',
  'decimalMultiply(',
  'parseDecimalString(',
  '<svg',
  '<circle',
  '<canvas',
  'style=',
  "import './",
  'HomeRoute',
]) {
  assert.ok(
    !component.includes(forbidden),
    `configured pixel-radius text runtime must not own forbidden behavior: ${forbidden}`,
  );
}

for (const requiredTestEvidence of [
  'expect(configuredPixelRadiusHookMock).toHaveBeenCalledTimes(1)',
  'expect(configuredPixelRadiusHookMock).toHaveBeenCalledWith(configuration, policy)',
  'expect(pixelRadiusTextEvidenceMock).toHaveBeenCalledTimes(1)',
  'expect(props.projection).toBe(pixelRadiusProjection)',
  'expect(pixelRadiusTextEvidenceMock).not.toHaveBeenCalled()',
  "expect(markup).toContain('data-pixel-radius-projection-status=\"unavailable\"')",
]) {
  assert.ok(test.includes(requiredTestEvidence), `test missing identity/null evidence: ${requiredTestEvidence}`);
}

for (const phrase of [
  'exact caller-owned product configuration',
  'exact caller-owned pixel-radius policy',
  'Gate380 remains configured browser pixel-radius hook owner',
  'Gate376 remains pure pixel-radius textual-evidence presenter owner',
  'No concrete pixel radius, responsive breakpoint, viewport measurement, collision, packing, layout',
  'No `HomeRoute` mutation',
  'A null pixel-radius projection remains null/unavailable evidence',
]) {
  assert.ok(report.includes(phrase), `foundation report missing ownership evidence: ${phrase}`);
}

console.log(
  'PASS: Home Live Crypto Bubble configured browser pixel-radius textual runtime composes exact caller configuration/policy through released Gate380 hook truth into released Gate376 projection evidence once, preserves null as unavailable, and leaves defaults, viewport, layout, rendering, route, provider, state and persistence ownership outside this boundary.',
);
