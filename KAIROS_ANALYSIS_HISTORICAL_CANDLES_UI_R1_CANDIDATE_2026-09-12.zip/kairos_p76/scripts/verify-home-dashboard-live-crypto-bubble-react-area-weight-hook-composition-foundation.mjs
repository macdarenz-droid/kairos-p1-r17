import { readFileSync } from 'node:fs';

const source = readFileSync('src/app/useHomeDashboardLiveCryptoBubbleReactAreaWeightViewModel.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-react-area-weight-hook-composition-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_REACT_AREA_WEIGHT_HOOK_COMPOSITION_FOUNDATION_REPORT_2026-09-10.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'useHomeDashboardLiveCryptoBubbleReactAreaWeightViewModel',
  'useHomeDashboardLiveCryptoBubblePresentationObservedRuntime(',
  'projectHomeDashboardLiveCryptoBubbleReactAreaWeightViewModel(runtimeState)',
  'readObservedAt',
  'readEvaluationTimeMs',
  'options: HomeDashboardLiveCryptoBubbleReactRuntimeBindingOptions',
]) {
  if (!source.includes(token)) throw new Error(`React area-weight hook composition evidence missing: ${token}`);
}

if ((source.match(/useHomeDashboardLiveCryptoBubblePresentationObservedRuntime\(/g) ?? []).length !== 1) {
  throw new Error('React area-weight hook must delegate to the released Gate351 runtime hook exactly once');
}
if ((source.match(/projectHomeDashboardLiveCryptoBubbleReactAreaWeightViewModel\(runtimeState\)/g) ?? []).length !== 1) {
  throw new Error('React area-weight hook must delegate the exact runtime state to Gate354 exactly once');
}

for (const forbidden of [
  'useEffect', 'useState', 'useMemo', 'useRef', 'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'startBinanceHomeDashboard', 'createHomeDashboard',
  '.sort(', '.filter(', '.reverse(', 'decimalAdd(', 'decimalSubtract(', 'decimalMultiply(', 'decimalDivide(',
  'parseDecimalString(', 'Math.sqrt(', 'Math.pow(', 'areaWeight =', 'quoteVolume24h /', 'borderRadius',
  'minRadius', 'maxRadius', 'className=', '<div', '<svg', 'HomeRoute', 'indexedDB',
]) {
  if (source.includes(forbidden)) throw new Error(`React area-weight hook composition broadened ownership: ${forbidden}`);
}

for (const token of [
  'delegates caller-owned runtime inputs unchanged and projects the exact released runtime state once',
  'does not retain a second runtime-state owner when the released runtime binding returns a new state',
  'keeps the released projector result exact instead of reshaping area-weight evidence in the hook',
]) {
  if (!test.includes(token)) throw new Error(`Missing React area-weight hook regression: ${token}`);
}

for (const token of [
  'one React-ready composition seam',
  'Caller-owned runtime inputs remain unchanged',
  'does not add a second state/effect owner',
  'Pixel radius, collision/layout, theme palette/tokens and visible `HomeRoute` rendering remain later responsibilities',
  'Your Trades/journal truth remains completely separate',
]) {
  if (!report.includes(token)) throw new Error(`React area-weight hook report evidence missing: ${token}`);
}

const verifyName = 'verify:home-dashboard-live-crypto-bubble-react-area-weight-hook-composition-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-home-dashboard-live-crypto-bubble-react-area-weight-hook-composition-foundation.mjs') {
  throw new Error('React area-weight hook composition verifier registration mismatch');
}

console.log('PASS: Home Live Crypto Bubble React area-weight hook composes released Gate351 runtime state and Gate354 view model without adding rendering or market truth.');
