import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const component = readFileSync('src/app/HomeDashboardLiveCryptoBubbleBrowserTextEvidenceRuntime.tsx', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-browser-text-evidence-runtime-composition-foundation.test.tsx', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_BROWSER_TEXT_EVIDENCE_RUNTIME_COMPOSITION_FOUNDATION_REPORT_2026-09-10.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-browser-text-evidence-runtime-composition-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-browser-text-evidence-runtime-composition-foundation.mjs',
);

for (const required of [
  "import { HomeDashboardLiveCryptoBubbleTextEvidenceRuntime }",
  'readHomeDashboardLiveCryptoBubbleBrowserEvaluationTimeMs',
  'readHomeDashboardLiveCryptoBubbleBrowserObservedAt',
  'readonly options: HomeDashboardLiveCryptoBubbleReactRuntimeBindingOptions',
  'readObservedAt={readHomeDashboardLiveCryptoBubbleBrowserObservedAt}',
  'readEvaluationTimeMs={readHomeDashboardLiveCryptoBubbleBrowserEvaluationTimeMs}',
  'options={options}',
]) {
  assert.ok(component.includes(required), `browser composition missing exact released delegation: ${required}`);
}

for (const forbidden of [
  'useState(', 'useEffect(', 'useMemo(', 'useCallback(',
  'setInterval(', 'setTimeout(', 'requestAnimationFrame(',
  'Date.now(', 'new Date(',
  'decimalDivide(', 'decimalMultiply(', 'decimalSubtract(', 'parseDecimalString(', 'Math.sqrt(',
  '<svg', '<circle', '<canvas', 'style=', "import './HomeRoute", 'indexedDB',
  'excludedStablecoinBaseAssets:', 'topNCount:', 'neutralMaxAbsoluteMovementPercent:',
]) {
  assert.ok(!component.includes(forbidden), `browser composition must not own forbidden behavior: ${forbidden}`);
}

assert.equal((component.match(/<HomeDashboardLiveCryptoBubbleTextEvidenceRuntime/g) ?? []).length, 1);
assert.ok(test.includes('expect(runtimeMock).toHaveBeenCalledTimes(1)'));
assert.ok(test.includes('expect(props.readObservedAt).toBe(readHomeDashboardLiveCryptoBubbleBrowserObservedAt)'));
assert.ok(test.includes('expect(props.readEvaluationTimeMs).toBe(readHomeDashboardLiveCryptoBubbleBrowserEvaluationTimeMs)'));
assert.ok(test.includes('expect(props.options).toBe(options)'));
for (const phrase of [
  'caller-owned `HomeDashboardLiveCryptoBubbleReactRuntimeBindingOptions`',
  'No `HomeRoute` or router wiring',
  'Gate358 remains browser wall-clock source owner',
]) {
  assert.ok(report.includes(phrase), `foundation report missing ownership evidence: ${phrase}`);
}

console.log('PASS: Home Live Crypto Bubble browser-clock textual-evidence runtime composition injects exact Gate358 clock sources into Gate357 once while retaining runtime configuration, route, geometry, policy, and persistence ownership outside this boundary.');
