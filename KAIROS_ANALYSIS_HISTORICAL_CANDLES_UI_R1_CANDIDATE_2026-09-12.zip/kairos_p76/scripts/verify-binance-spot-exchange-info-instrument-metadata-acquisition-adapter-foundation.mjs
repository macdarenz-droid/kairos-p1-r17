import { readFileSync } from 'node:fs';
const adapter = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpotExchangeInfoInstrumentMetadataAcquisitionAdapter.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_BINANCE_SPOT_EXCHANGE_INFO_INSTRUMENT_METADATA_ACQUISITION_ADAPTER_FOUNDATION_REPORT_2026-09-09.md', import.meta.url), 'utf8');
for (const token of [
  'createBinanceSpotExchangeInfoInstrumentMetadataAcquisitionPort(',
  'LiveMarketUniverseInstrumentMetadataAcquisitionPort',
  'composeBinanceSpotExchangeInfoPublicRestRoundTrip(connect, options)',
  "return { ok: false, reason: 'acquisition-failed' }",
  'return { ok: true, facts: result.facts }',
]) if (!adapter.includes(token)) throw new Error(`metadata adapter evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpotExchangeInfoInstrumentMetadataAcquisitionAdapter';")) throw new Error('metadata adapter barrel export missing');
for (const forbidden of [
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'new Response(', 'new AbortController(',
  'AbortSignal.any(', 'AbortSignal.timeout(', 'setTimeout(', 'setInterval(', 'indexedDB',
  'quoteVolume', 'Top 30', 'stablecoin',
]) if (adapter.includes(forbidden)) throw new Error(`metadata adapter broadened scope: ${forbidden}`);
for (const token of [
  'No concrete browser `fetch`/XHR/WebSocket transport',
  'No retry/backoff/rate/request-weight policy',
  'No cache, polling',
  'No USDT eligibility',
  'No Home/Live Crypto Bubble UI',
]) if (!report.includes(token)) throw new Error(`metadata adapter report evidence missing: ${token}`);
console.log('Binance Spot exchangeInfo instrument metadata acquisition adapter verification PASS');
