import { readFileSync } from 'node:fs';

const source = readFileSync('src/app/homeDashboardLiveMarketSummaryBrowserLifecycleAdapter.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-market-summary-browser-lifecycle-adapter-foundation.test.ts', 'utf8');

for (const token of [
  'createHomeDashboardLiveMarketSummaryAcquisitionLifecycle',
  "visibilityState === 'hidden'",
  "addEventListener('visibilitychange'",
  "removeEventListener('visibilitychange'",
  'globalThis.setTimeout',
  'globalThis.clearTimeout',
  'lifecycle.setVisibility',
  'lifecycle.enter()',
  'lifecycle.close()',
]) {
  if (!source.includes(token)) throw new Error(`missing browser lifecycle adapter evidence: ${token}`);
}

for (const forbidden of [
  '5000', 'fetch(', 'WebSocket', 'Binance', 'quoteVolume24h', 'stablecoin', 'TopN',
  'FRESH', 'STALE', 'EXPIRED', 'createLiveMarketSummaryStateSession', 'indexedDB',
  'React', 'useEffect(', 'useState(', 'createChart(',
]) {
  if (source.includes(forbidden)) throw new Error(`browser lifecycle adapter leaked forbidden ownership: ${forbidden}`);
}

for (const token of [
  "createBrowserDocument('visible')",
  "createBrowserDocument('hidden')",
  "setVisibility('hidden')",
  "setVisibility('visible')",
  'toBe(5000)',
  'removeEventListener',
  'signal.aborted',
]) {
  if (!test.includes(token)) throw new Error(`missing browser lifecycle adapter regression evidence: ${token}`);
}

console.log('Home Dashboard live-market browser lifecycle adapter verification passed.');
