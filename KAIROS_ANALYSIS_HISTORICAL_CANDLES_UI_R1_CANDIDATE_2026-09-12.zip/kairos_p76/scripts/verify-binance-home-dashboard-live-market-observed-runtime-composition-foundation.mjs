import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/app/binanceHomeDashboardLiveMarketObservedRuntimeComposition.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_BINANCE_HOME_DASHBOARD_LIVE_MARKET_OBSERVED_RUNTIME_COMPOSITION_FOUNDATION_REPORT_2026-09-10.md', import.meta.url), 'utf8');

for (const token of [
  'startBinanceHomeDashboardLiveMarketObservedRuntime',
  "extends Omit<BinanceHomeDashboardLiveMarketRuntimeBootstrapOptions, 'lifecycle'>",
  "Omit<HomeDashboardLiveMarketSummaryBrowserLifecycleAdapterOptions, 'observer'>",
  'createHomeDashboardLiveMarketSummaryFreshnessObservationObserver(',
  'readEvaluationTimeMs,',
  'options.observationSink,',
  '...options.lifecycle,',
  'observer,',
  'startBinanceHomeDashboardLiveMarketRuntime(readObservedAt, {',
  'universe: options.universe,',
  'lifecycle,',
]) if (!source.includes(token)) throw new Error(`observed-runtime composition evidence missing: ${token}`);

for (const forbidden of [
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'fetch(', 'XMLHttpRequest', 'WebSocket(',
  'document.', 'visibilityState', 'indexedDB', 'useEffect', 'useState', 'React',
  '.sort(', '.filter(', '.reduce(', '15_000', '60_000', 'freshMaxAgeMs', 'staleMaxAgeMs',
  'acquireBinanceSpotBrowserLiveMarketUniverseOnce', 'createLiveMarketSummaryStateSession',
  'createBinanceHomeDashboardLiveMarketSummaryScopedSnapshotAcquisitionPort',
  'createHomeDashboardLiveMarketSummaryBrowserLifecycleAdapter(',
]) if (source.includes(forbidden)) throw new Error(`observed-runtime composition broadened ownership: ${forbidden}`);

for (const token of [
  'app-level non-presentation composition',
  'lifecycle `observer` field is deliberately omitted',
  'creates exactly one Gate340 observer',
  "returns Gate337's bootstrap result unchanged",
  'No React/Home/Bubble rendering',
]) if (!report.includes(token)) throw new Error(`observed-runtime composition report evidence missing: ${token}`);

console.log('Binance Home Dashboard Live Market Observed Runtime Composition Foundation verification passed.');
