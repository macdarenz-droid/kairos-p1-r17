import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/liveMarketSummaryFreshnessClassificationPolicy.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_LIVE_MARKET_SUMMARY_FRESHNESS_CLASSIFICATION_POLICY_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');

for (const token of [
  "'fresh' | 'stale' | 'expired'",
  'freshMaxAgeMs: 15_000',
  'staleMaxAgeMs: 60_000',
  'classifyLiveMarketSummaryObservationAge',
  "if (ageMs <= policy.freshMaxAgeMs) return 'fresh';",
  "if (ageMs <= policy.staleMaxAgeMs) return 'stale';",
  "return 'expired';",
]) if (!source.includes(token)) throw new Error(`freshness policy evidence missing: ${token}`);

if (!index.includes("export * from './liveMarketSummaryFreshnessClassificationPolicy';")) throw new Error('freshness policy public export missing');

for (const forbidden of [
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'fetch(', 'XMLHttpRequest', 'WebSocket(',
  'document.', 'visibilityState', 'React', 'useEffect', 'useState', 'indexedDB', 'sourceTimestamp',
  '.sort(', '.filter(', 'AbortController',
]) if (source.includes(forbidden)) throw new Error(`freshness policy broadened into forbidden scope: ${forbidden}`);

for (const token of [
  'provider-neutral deterministic freshness-classification policy owner',
  'already-computed caller-owned observation age',
  'No `Date.now()` / `new Date()` / internal wall-clock ownership',
  'Visible-dashboard cadence, stale/expired presentation, and universe policy remain separate later responsibilities',
]) if (!report.includes(token)) throw new Error(`freshness policy report evidence missing: ${token}`);

console.log('Live Market Summary freshness classification policy verification passed.');
