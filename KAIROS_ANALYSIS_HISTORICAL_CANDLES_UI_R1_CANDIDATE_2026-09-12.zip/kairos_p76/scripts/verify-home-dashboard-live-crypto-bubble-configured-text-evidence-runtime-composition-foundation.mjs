import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const component = readFileSync('src/app/HomeDashboardLiveCryptoBubbleConfiguredTextEvidenceRuntime.tsx', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-configured-text-evidence-runtime-composition-foundation.test.tsx', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_CONFIGURED_TEXT_EVIDENCE_RUNTIME_COMPOSITION_FOUNDATION_REPORT_2026-09-10.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-configured-text-evidence-runtime-composition-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-configured-text-evidence-runtime-composition-foundation.mjs',
);

for (const required of [
  "import { HomeDashboardLiveCryptoBubbleBrowserTextEvidenceRuntime }",
  'composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions',
  'readonly configuration: HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration',
  'composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions(configuration)',
  '<HomeDashboardLiveCryptoBubbleBrowserTextEvidenceRuntime options={options} />',
]) {
  assert.ok(component.includes(required), `configured runtime composition missing exact released delegation: ${required}`);
}

assert.equal((component.match(/composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions\(configuration\)/g) ?? []).length, 1);
assert.equal((component.match(/<HomeDashboardLiveCryptoBubbleBrowserTextEvidenceRuntime/g) ?? []).length, 1);

for (const forbidden of [
  'new Set(', 'neutralMaxAbsoluteMovementPercent:', 'excludedStablecoinBaseAssets:', 'topNCount:', 'lifecycle:',
  'useState(', 'useEffect(', 'useMemo(', 'useCallback(',
  'Date.now(', 'new Date(', 'setInterval(', 'setTimeout(', 'requestAnimationFrame(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'indexedDB', 'localStorage',
  '<svg', '<circle', '<canvas', 'style=', 'HomeRoute',
]) {
  assert.ok(!component.includes(forbidden), `configured runtime composition must not own forbidden behavior: ${forbidden}`);
}

assert.ok(test.includes('expect(composeRuntimeOptionsMock).toHaveBeenCalledTimes(1)'));
assert.ok(test.includes('expect(composeRuntimeOptionsMock).toHaveBeenCalledWith(configuration)'));
assert.ok(test.includes('expect(browserRuntimeMock).toHaveBeenCalledTimes(1)'));
assert.ok(test.includes('expect(props.options).toBe(composedOptions)'));

for (const phrase of [
  'exact caller-owned product configuration',
  'Gate360 remains runtime-options composition owner',
  'Gate359 remains browser textual-evidence runtime owner',
  'No concrete stablecoin exclusion or neutral-movement value',
  'No `HomeRoute` or Bubble geometry wiring',
]) {
  assert.ok(report.includes(phrase), `foundation report missing ownership evidence: ${phrase}`);
}

console.log('PASS: Home Live Crypto Bubble configured textual-evidence runtime composition delegates exact caller configuration through Gate360 into Gate359 once while leaving product values, route, geometry, provider, state, and persistence ownership outside this boundary.');
