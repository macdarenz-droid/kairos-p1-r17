import { readFileSync } from 'node:fs';

const source = readFileSync('src/app/useHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-react-radius-scale-hook-composition-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_REACT_RADIUS_SCALE_HOOK_COMPOSITION_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'useHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel',
  'useHomeDashboardLiveCryptoBubbleReactAreaWeightViewModel(',
  'projectHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel(areaWeightViewModel)',
  'readObservedAt',
  'readEvaluationTimeMs',
  'options: HomeDashboardLiveCryptoBubbleReactRuntimeBindingOptions',
]) {
  if (!source.includes(token)) throw new Error(`React radius-scale hook composition evidence missing: ${token}`);
}

if ((source.match(/useHomeDashboardLiveCryptoBubbleReactAreaWeightViewModel\(/g) ?? []).length !== 1) {
  throw new Error('React radius-scale hook must delegate to the released area-weight hook exactly once');
}
if ((source.match(/projectHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel\(areaWeightViewModel\)/g) ?? []).length !== 1) {
  throw new Error('React radius-scale hook must delegate the exact area-weight view model to Gate365 exactly once');
}

for (const forbidden of [
  'useEffect', 'useState', 'useMemo', 'useRef', 'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'startBinanceHomeDashboard', 'createHomeDashboard',
  '.sort(', '.filter(', '.reverse(', 'decimalAdd(', 'decimalSubtract(', 'decimalMultiply(', 'decimalDivide(',
  'parseDecimalString(', 'Math.sqrt(', 'Math.pow(', 'areaWeight =', 'radiusScale =', 'borderRadius',
  'minRadius', 'maxRadius', 'className=', '<div', '<svg', 'HomeRoute', 'indexedDB',
]) {
  if (source.includes(forbidden)) throw new Error(`React radius-scale hook composition broadened ownership: ${forbidden}`);
}

for (const token of [
  'delegates caller-owned runtime inputs unchanged and projects the exact released area-weight view model once',
  'does not retain a second app-level radius-scale state owner across rerenders',
  'returns the exact released Gate365 radius-scale view-model result unchanged',
]) {
  if (!test.includes(token)) throw new Error(`Missing React radius-scale hook regression: ${token}`);
}

for (const token of [
  'one thin React composition seam',
  'calls `useHomeDashboardLiveCryptoBubbleReactAreaWeightViewModel(...)` exactly once',
  'passes the exact returned area-weight view-model reference once',
  'adds no second retained state/effect owner',
  'Pixel min/max radius, viewport breakpoints, collision/packing/layout',
  'Live Crypto Bubble Map and Your Trades Bubble Map remain separate truth domains',
]) {
  if (!report.includes(token)) throw new Error(`React radius-scale hook report evidence missing: ${token}`);
}

const verifyName = 'verify:home-dashboard-live-crypto-bubble-react-radius-scale-hook-composition-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-home-dashboard-live-crypto-bubble-react-radius-scale-hook-composition-foundation.mjs') {
  throw new Error('React radius-scale hook composition verifier registration mismatch');
}

console.log('PASS: Home Live Crypto Bubble React radius-scale hook composes released area-weight hook output with Gate365 without adding state, pixels, or market truth.');
