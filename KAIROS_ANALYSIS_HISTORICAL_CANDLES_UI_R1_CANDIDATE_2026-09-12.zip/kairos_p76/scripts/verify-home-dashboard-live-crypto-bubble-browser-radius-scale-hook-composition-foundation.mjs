import { readFileSync } from 'node:fs';

const source = readFileSync('src/app/useHomeDashboardLiveCryptoBubbleBrowserRadiusScaleViewModel.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-browser-radius-scale-hook-composition-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_BROWSER_RADIUS_SCALE_HOOK_COMPOSITION_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'useHomeDashboardLiveCryptoBubbleBrowserRadiusScaleViewModel',
  'readHomeDashboardLiveCryptoBubbleBrowserObservedAt',
  'readHomeDashboardLiveCryptoBubbleBrowserEvaluationTimeMs',
  'useHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel(',
  'options: HomeDashboardLiveCryptoBubbleReactRuntimeBindingOptions',
]) {
  if (!source.includes(token)) throw new Error(`Browser radius-scale hook evidence missing: ${token}`);
}

if ((source.match(/useHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel\(/g) ?? []).length !== 1) {
  throw new Error('Browser radius-scale hook must delegate to Gate366 exactly once');
}
if (!source.includes('readHomeDashboardLiveCryptoBubbleBrowserObservedAt,\n    readHomeDashboardLiveCryptoBubbleBrowserEvaluationTimeMs,\n    options,')) {
  throw new Error('Browser radius-scale hook must forward exact Gate358 sources and exact options in order');
}

for (const forbidden of [
  'useEffect', 'useState', 'useMemo', 'useRef', 'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'startBinanceHomeDashboard', '.sort(', '.filter(', '.reverse(',
  'decimalAdd(', 'decimalSubtract(', 'decimalMultiply(', 'decimalDivide(', 'parseDecimalString(',
  'Math.sqrt(', 'Math.pow(', 'radiusScale =', 'minRadius', 'maxRadius', 'borderRadius',
  'className=', '<div', '<svg', 'HomeRoute', 'indexedDB', 'YourTrades',
]) {
  if (source.includes(forbidden)) throw new Error(`Browser radius-scale hook broadened ownership: ${forbidden}`);
}

for (const token of [
  'injects the exact released Gate358 browser clock sources and caller options into Gate366 once',
  'returns the exact released Gate366 result unchanged',
  'does not retain a second browser radius-scale result owner across rerenders',
]) {
  if (!test.includes(token)) throw new Error(`Missing browser radius-scale hook regression: ${token}`);
}

for (const token of [
  'thin browser-specific React composition seam',
  'Gate358 remains the concrete browser wall-clock owner',
  'exact caller-owned runtime-options reference is forwarded unchanged',
  'Live Crypto Bubble Map and Your Trades Bubble Map remain separate authoritative truth domains',
]) {
  if (!report.includes(token)) throw new Error(`Browser radius-scale hook report evidence missing: ${token}`);
}

const verifyName = 'verify:home-dashboard-live-crypto-bubble-browser-radius-scale-hook-composition-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-home-dashboard-live-crypto-bubble-browser-radius-scale-hook-composition-foundation.mjs') {
  throw new Error('Browser radius-scale hook verifier registration mismatch');
}

console.log('PASS: browser radius-scale hook injects released Gate358 clocks into Gate366 without adding state, market policy, pixels, or route truth.');
