import { readFileSync } from 'node:fs';
const port = readFileSync(new URL('../src/services/market-data/LiveMarketUniverseInstrumentMetadataAcquisitionPort.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
for (const token of [
  'export type LiveMarketUniverseInstrumentMetadataAcquisitionResult =',
  'readonly facts: readonly LiveMarketUniverseInstrumentMetadataFact[];',
  "readonly reason: 'acquisition-failed';",
  'export interface LiveMarketUniverseInstrumentMetadataAcquisitionPort',
  'acquireInstrumentMetadata(',
  'options?: { readonly signal?: AbortSignal }',
  'Promise<LiveMarketUniverseInstrumentMetadataAcquisitionResult>',
]) if (!port.includes(token)) throw new Error(`metadata acquisition port evidence missing: ${token}`);
if (!index.includes("export * from './LiveMarketUniverseInstrumentMetadataAcquisitionPort';")) throw new Error('metadata acquisition port export missing');
for (const forbidden of ['binance', 'fetch(', 'WebSocket', 'EventSource', 'setInterval(', 'setTimeout(', 'indexedDB', 'USDT', 'stablecoin', 'quoteVolume', 'Top 30', 'bubble']) {
  if (port.includes(forbidden)) throw new Error(`metadata acquisition port widened into forbidden scope: ${forbidden}`);
}
console.log('Live Market Universe Instrument Metadata Acquisition Port Contract verification passed.');
