import { readFileSync } from 'node:fs';
const connector=readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpotExchangeInfoBrowserPublicRestConnector.ts', import.meta.url),'utf8');
const index=readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url),'utf8');
for (const token of ['connectBinanceSpotExchangeInfoBrowserPublicRestRequest','BinanceSpotExchangeInfoPublicRestRequestConnector<string>','globalThis.fetch(request.url,','method: request.method','signal: options?.signal','return response.text()']) if(!connector.includes(token)) throw new Error(`missing ${token}`);
if(!index.includes("export * from './providers/binance/binanceSpotExchangeInfoBrowserPublicRestConnector';")) throw new Error('export missing');
for (const forbidden of ['response.ok','response.status','response.headers','new AbortController(','AbortSignal.any(','AbortSignal.timeout(','setTimeout(','setInterval(','JSON.parse(','indexedDB','WebSocket(','XMLHttpRequest','credentials:','headers:','cache:','redirect:']) if(connector.includes(forbidden)) throw new Error(`forbidden ${forbidden}`);
console.log('exchangeInfo browser connector verification passed.');
