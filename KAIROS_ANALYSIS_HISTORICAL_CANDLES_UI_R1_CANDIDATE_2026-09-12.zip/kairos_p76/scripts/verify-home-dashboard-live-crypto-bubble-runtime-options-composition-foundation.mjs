import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const source = readFileSync('src/app/homeDashboardLiveCryptoBubbleRuntimeOptionsComposition.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-runtime-options-composition-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_RUNTIME_OPTIONS_COMPOSITION_FOUNDATION_REPORT_2026-09-10.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-runtime-options-composition-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-runtime-options-composition-foundation.mjs',
);

for (const required of [
  'HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration',
  'readonly excludedStablecoinBaseAssets: ReadonlySet<string>',
  'readonly neutralMaxAbsoluteMovementPercent: DecimalString',
  'composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions',
  'excludedStablecoinBaseAssets: configuration.excludedStablecoinBaseAssets',
  'neutralMaxAbsoluteMovementPercent: configuration.neutralMaxAbsoluteMovementPercent',
]) {
  assert.ok(source.includes(required), `runtime-options composition missing exact delegation: ${required}`);
}

for (const forbidden of [
  'new Set(', 'topNCount', 'lifecycle:', 'Date.now(', 'new Date(',
  'setInterval(', 'setTimeout(', 'requestAnimationFrame(',
  'fetch(', 'indexedDB', 'HomeRoute', '<svg', '<circle', '<canvas', 'style=',
  'useState(', 'useEffect(', 'useMemo(', 'useCallback(',
]) {
  assert.ok(!source.includes(forbidden), `runtime-options composition must not own forbidden behavior: ${forbidden}`);
}

assert.ok(test.includes("expect(options.universe.excludedStablecoinBaseAssets).toBe(excludedStablecoinBaseAssets)"));
assert.ok(test.includes("expect('topNCount' in options.universe).toBe(false)"));
assert.ok(test.includes("expect('lifecycle' in options).toBe(false)"));
assert.ok(test.includes('neutralMaxAbsoluteMovementPercent'));

for (const phrase of [
  'exact caller-owned excluded-stablecoin set',
  'exact caller-owned neutral-movement threshold',
  'Top-30 default remains owned by the released Top-N policy',
  'browser lifecycle defaults remain owned by the released lifecycle adapter',
  'No `HomeRoute` or Bubble geometry wiring',
]) {
  assert.ok(report.includes(phrase), `foundation report missing ownership evidence: ${phrase}`);
}

console.log('PASS: Home Live Crypto Bubble runtime-options composition preserves exact caller-owned product configuration while leaving released Top-N/lifecycle defaults and all route, geometry, provider, state, and persistence ownership outside this boundary.');
