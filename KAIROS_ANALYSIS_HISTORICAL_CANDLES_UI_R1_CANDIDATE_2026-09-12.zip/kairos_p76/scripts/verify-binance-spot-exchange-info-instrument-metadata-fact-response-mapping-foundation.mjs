import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpotExchangeInfoInstrumentMetadataFactResponse.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_BINANCE_SPOT_EXCHANGE_INFO_INSTRUMENT_METADATA_FACT_RESPONSE_MAPPING_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');

for (const token of [
  'BinanceSpotExchangeInfoInstrumentMetadataFactResponseResult',
  'mapBinanceSpotExchangeInfoInstrumentMetadataFactResponse',
  "reason: 'response-invalid'",
  'mapBinanceSpotExchangeInfoInstrumentMetadataFactCollection(response.symbols)',
]) if (!source.includes(token)) throw new Error(`exchangeInfo metadata response mapper evidence missing: ${token}`);

if (!index.includes("export * from './providers/binance/binanceSpotExchangeInfoInstrumentMetadataFactResponse';")) {
  throw new Error('exchangeInfo instrument metadata response mapper barrel export missing');
}

for (const forbidden of [
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'JSON.parse(', 'decodeBinanceSpotExchangeInfoPublicRestResponse(',
  '.filter(', '.sort(', "quoteAsset === 'USDT'", "quoteAsset !== 'USDT'", 'quoteVolume24h',
  'Top 30', 'topN', 'stablecoin', 'new Map(', 'new Set(', 'setTimeout(', 'setInterval(', 'Date.now(',
  'new Date(', 'indexedDB', 'React', 'useEffect', 'timezone', 'serverTime', 'rateLimits', 'exchangeFilters',
]) if (source.includes(forbidden)) throw new Error(`metadata response mapper broadened into forbidden scope: ${forbidden}`);

for (const token of [
  'one whole already-decoded exchangeInfo value',
  'reads only its `symbols` property',
  'delegates that exact property value unchanged',
  'A non-object or array outer value returns `response-invalid`',
  "released collection mapper's exact `collection-invalid` result",
  'Invalid symbol entries surface the released exact first-invalid-entry index and entry reason unchanged',
  'No interpretation of `timezone`, `serverTime`, `rateLimits`, `exchangeFilters`',
  'No USDT eligibility filtering or symbol-suffix inference',
  'No stablecoin exclusion',
  'No 24h quote-volume lookup, ranking/sorting, symbol tie-break, Top-N/Top-30',
  'No freshness-age/classification changes',
  'No Home React wiring',
  'No Your Trades/journal ownership',
]) if (!report.includes(token)) throw new Error(`exchangeInfo metadata response mapper report evidence missing: ${token}`);

console.log('Binance Spot exchangeInfo instrument metadata fact response mapping verification passed.');
