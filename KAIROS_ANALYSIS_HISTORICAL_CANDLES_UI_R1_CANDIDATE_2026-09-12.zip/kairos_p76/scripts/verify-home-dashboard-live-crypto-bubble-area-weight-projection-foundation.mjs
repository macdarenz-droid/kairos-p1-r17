import { readFileSync } from 'node:fs';

const source = readFileSync('src/application/dashboard/homeDashboardLiveCryptoBubbleAreaWeightProjection.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-area-weight-projection-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_AREA_WEIGHT_PROJECTION_FOUNDATION_REPORT_2026-09-10.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'projectHomeDashboardLiveCryptoBubbleAreaWeights',
  'HomeDashboardLiveCryptoBubbleAreaWeightProjectionEntry',
  'areaWeight: DecimalString | null',
  'presentationStateProjection: SuccessfulPresentationStateProjection',
  "reason: 'presentation-state-projection-invalid'",
  "reason: 'area-weight-entry-inconsistent'",
  "reason: 'area-weight-derivation-invalid'",
  'parseDecimalString(String(entry.metricInput.quoteVolume24h))',
  'decimalSubtract(quoteVolume, maximumPresentQuoteVolume)',
  'decimalDivide(quoteVolume, maximumPresentQuoteVolume)',
  "maximumPresentQuoteVolume === '0'",
  'entries.push({ presentationEntry, areaWeight: null })',
]) {
  if (!source.includes(token)) throw new Error(`Bubble area-weight projection evidence missing: ${token}`);
}

for (const forbidden of [
  '.sort(', '.filter(', '.reverse(', 'Math.sqrt(', 'Math.pow(', 'Date.now(', 'new Date(',
  'setTimeout(', 'setInterval(', 'fetch(', 'XMLHttpRequest', 'WebSocket(', "from 'react'", 'useEffect', 'useState',
  'indexedDB', 'borderRadius', 'radius:', 'minRadius', 'maxRadius', 'width:', 'height:', 'left:', 'top:',
  'className=', '<div', '<svg', 'neutralMaxAbsoluteMovementPercent', 'stablecoin', 'topN', 'Top 30',
  'freshMaxAgeMs', 'staleMaxAgeMs', 'startBinanceHomeDashboardLiveCryptoBubble',
]) {
  if (source.includes(forbidden)) throw new Error(`Bubble area-weight projection broadened ownership: ${forbidden}`);
}

for (const token of [
  'normalizes present 24h quote volume against the maximum while preserving exact entry order and semantic references',
  'does not sort or rerank when a later entry has the largest quote volume',
  'keeps missing entries explicitly missing and does not invent a visible minimum area',
  'keeps all present zero-volume entries at exact zero instead of inventing a minimum radius',
  'preserves an upstream presentation-state failure exactly as non-renderable evidence',
  'fails closed when a released presentation entry is inconsistent instead of fabricating area truth',
]) {
  if (!test.includes(token)) throw new Error(`Missing Bubble area-weight regression: ${token}`);
}

for (const token of [
  'provider-neutral normalized area-weight projection below React rendering',
  '24h quote volume remains the authoritative size metric',
  'areaWeight = quoteVolume24h / maximum present quoteVolume24h',
  'Missing entries remain explicit with `areaWeight: null`',
  'Pixel radius, minimum visible radius, collision/layout and theme color remain later presentation owners',
]) {
  if (!report.includes(token)) throw new Error(`Bubble area-weight report evidence missing: ${token}`);
}

const verifyName = 'verify:home-dashboard-live-crypto-bubble-area-weight-projection-foundation';
if (pkg.scripts?.[verifyName] !== 'node scripts/verify-home-dashboard-live-crypto-bubble-area-weight-projection-foundation.mjs') {
  throw new Error('Bubble area-weight projection verifier registration mismatch');
}

console.log('PASS: Home Live Crypto Bubble area-weight projection preserves quote-volume truth without owning pixels, layout, theme, policy, or React.');
