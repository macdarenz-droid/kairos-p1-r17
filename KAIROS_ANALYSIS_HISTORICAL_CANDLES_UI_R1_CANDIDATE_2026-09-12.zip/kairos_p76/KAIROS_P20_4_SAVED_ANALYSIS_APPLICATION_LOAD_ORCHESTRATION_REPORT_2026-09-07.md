# KAIROS P20.4 — Saved Analysis Application Load Orchestration

## Authority
Built only from canonical P20.3 GOLDEN after exact artifact/source inspection.

## Source-proven gap
P20.1 owns the Saved Analysis logical contract and stable `SavedAnalysisId`. P20.2 already owns raw persistence, including `SavedAnalysisRepository.get(id)`. P20.3 owns only save orchestration. Exact canonical source search found no application-layer Saved Analysis read consumer. Existing Kairos architecture keeps persistence access behind application/query boundaries instead of making UI a second persistence owner.

## Responsibility
P20.4 owns one application read operation: load exactly one Saved Analysis by canonical stable id, using `SavedAnalysisRepository.get`. It returns a detached logical record on success, an explicit not-found result for an absent id, or an explicit storage error when persistence access fails.

## Non-scope
- No UI, route, dashboard, provider, Lightweight Charts, pixels, or presentation state.
- No list/update/delete orchestration.
- No DB/schema/migration/backup changes.
- No secondary indexes or speculative query APIs.
- No new Saved Analysis metadata, name, timeframe, timestamps, or ownership changes.
- No mutation of P17/P18/P19 truth, P20.1 logical truth, P20.2 persistence truth, or P20.3 save semantics.

## Verification intent
Focused tests cover successful single-id load, explicit not-found behavior, explicit storage failure, and detached caller-facing data. Dedicated verifier enforces the exact owner/boundary and forbids broader CRUD/UI scope.
