# Home Dashboard Live Crypto Bubble layout-bounds policy contract foundation

## Canonical base

Gate383 canonical GOLDEN candidate: `KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_CONFIGURED_RUNTIME_LIFECYCLE_STABILITY_REPAIR_CANDIDATE_2026-09-11.zip`, size `1,700,687`, SHA-256 `2204855d3ed2aabf81fcb8502f94c2de8c6527e460e435cfd86f85ffd9dc93f1`, Git blob `491b2dbedabdcf8f60f50c716d98fe13900efea5`.

## Responsibility

`src/application/dashboard/homeDashboardLiveCryptoBubbleLayoutBoundsPolicy.ts` adds one caller-owned layout-bounds policy contract and validator for a later controlled Bubble layout boundary.

It accepts exact `widthCssPixels` and `heightCssPixels` values, accepts only finite non-negative numbers, returns deterministic `width-invalid` or `height-invalid` failure, and preserves the exact successful policy reference. Zero is deliberately valid so the contract does not invent a minimum viewport or visibility rule.

## Explicit non-scope

- No default width or height values and no responsive breakpoints.
- No viewport or element measurement, browser globals, observers, timers or React ownership.
- No collision, packing, placement or renderer behavior.
- No padding, gap, label-fit, hit-target, SVG, canvas, DOM, CSS, palette, dimming or motion policy.
- No radius arithmetic or minimum/maximum radius values.
- No provider, acquisition, universe, ranking, Top-N, freshness or movement semantics.
- No `HomeRoute`, persistence, Saved Analysis or Your Trades ownership.

## Dependency boundary

Gate383 stabilizes the configured runtime consumed by the existing textual Home path and released caller-bounded pixel-radius path. A future layout owner requires an explicit rectangular extent, but current authority supplies no concrete size or measurement source. This contract exposes only the default-free caller boundary needed by such a future owner; it does not select visual design values.

Live Crypto Bubble and Your Trades Bubble remain separate truth domains. Any later generic presentation machinery may be shared only after their authoritative data owners have produced presentation inputs.

## Verification intent

The dedicated regression proves finite non-negative acceptance, exact reference preservation, zero-bounds acceptance and deterministic rejection of negative, NaN and infinite values without fallbacks. Static verification rejects defaults, browser/DOM measurement, React lifecycle, radius arithmetic, collision/packing, styling/rendering, market/provider policy, persistence and Your Trades ownership.
