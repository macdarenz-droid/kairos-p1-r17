# Kairos Home Dashboard Live Crypto Bubble Configured Text-Evidence Runtime Composition Foundation

## Authority

Base: canonical Gate360 runtime-options composition foundation.

## Responsibility

This slice owns exactly one thin configured browser textual-runtime composition edge between the released Gate360 runtime-options composer and the released Gate359 browser textual-evidence runtime.

`HomeDashboardLiveCryptoBubbleConfiguredTextEvidenceRuntime`:
- accepts one exact caller-owned product configuration through `HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration`;
- delegates that exact configuration once to `composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions`;
- passes only the resulting runtime options to `HomeDashboardLiveCryptoBubbleBrowserTextEvidenceRuntime`; and
- renders that released Gate359 browser runtime exactly once.

Gate360 remains runtime-options composition owner. Gate359 remains browser textual-evidence runtime owner. This boundary neither reads nor transforms either product value itself.

## Explicit non-scope

No concrete stablecoin exclusion or neutral-movement value is selected here. No Top-N default. No browser lifecycle override. No state/effects/memo/callbacks. No clocks, timers, page visibility, provider request/acquisition/retry/cadence, or freshness ownership. No arithmetic, validation, normalization, cloning, or hidden defaults. No CSS/theme/palette/dimming. No Bubble radius/layout/collision/labels/SVG/canvas/interactions. No `HomeRoute` or Bubble geometry wiring. No persistence/Saved Analysis. No Your Trades Bubble Map, journal/trade truth, chart, Risk/Reward, Calculation Brain, navigation, or transitions.

## Dependency ownership preserved

Gate360 owns pure composition of the exact caller-owned excluded-stablecoin set and neutral-movement threshold into the released runtime binding options. Gate359 owns the concrete browser-clock-to-textual-runtime edge. Existing released owners retain Top-30, browser lifecycle and visible-cadence defaults, universe/freshness policy, provider/data acquisition, React runtime state, presentation mapping, and lower-layer market truth.

This slice closes only the unowned technical seam between Gate360 and Gate359. The eventual application/route owner still must supply the two explicit product configuration values after those material user-facing choices are authoritatively released.
