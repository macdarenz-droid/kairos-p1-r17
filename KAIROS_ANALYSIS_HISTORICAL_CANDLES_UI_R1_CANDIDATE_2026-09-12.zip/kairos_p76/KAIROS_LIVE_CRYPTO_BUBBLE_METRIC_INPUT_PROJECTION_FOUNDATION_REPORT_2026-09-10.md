# Live Crypto Bubble Metric-Input Projection Foundation

## Authority
Base: exact canonical Gate342 Live Market Summary 24h percentage-movement candidate, promoted by `Kairos Controlled Roadmap Gate` #342 / run `34425285844`.

## Source-proven responsibility
The approved P21 Live Crypto Bubble Map requires two numeric metric truths below presentation: `quoteVolume24h` for bubble size and 24h percentage movement for bubble color. Gate342 now owns provider-neutral percentage-movement derivation; Gate338 already owns provider-neutral per-fact freshness evaluation over the released scoped snapshot. No production owner composes those released truths into a single Bubble-ready metric-input projection.

This slice adds only that composition. It accepts the released freshness-evaluation result rather than recomputing freshness. A failed freshness evaluation fails closed and preserves its deterministic upstream reason. For a successful evaluation, entry order and exact instrument/fact/age/freshness association are preserved. A missing fact stays explicit missing with null size and movement metrics, never numeric zero. A present fact exposes its exact canonical `quoteVolume24h` and delegates 24h percentage movement only to the released Gate342 derivation. Any delegated movement failure fails closed with the exact entry index and delegated reason.

## Explicit non-scope
No ranking or Top-N selection; no stablecoin exclusion; no provider-specific second truth; no color/palette or positive/negative/near-zero visual policy; no bubble radius/area scaling, geometry, collision/layout or labels; no stale/expired dimming or visibility treatment; no acquisition/cadence/lifecycle/retry/universe refresh; no session mutation; no React/Home/Bubble rendering; no persistence/IndexedDB; no navigation, Your Trades, journal, chart, Risk/Reward, Calculation Brain, Saved Analysis or transition ownership.
