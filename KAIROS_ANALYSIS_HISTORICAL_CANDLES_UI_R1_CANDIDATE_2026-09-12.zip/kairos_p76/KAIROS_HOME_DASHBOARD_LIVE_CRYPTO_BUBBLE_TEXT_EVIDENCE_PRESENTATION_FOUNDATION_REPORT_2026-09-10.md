# Home Dashboard Live Crypto Bubble Text Evidence Presentation Foundation

## Responsibility

Introduce the first truthful React presentation consumer for released Home Live Crypto Bubble evidence before any Bubble geometry/design decisions are made.

The component accepts one exact released Gate354 view-model value as a prop. It exposes the released Gate351 runtime status/error-presence evidence and the released Gate352 area-weight projection evidence. On successful projection it preserves entry order and renders only already-released symbol, availability, freshness, movement semantic, 24h quote volume, 24h movement percentage and area weight. Missing and failed projection states remain explicit.

## Ownership boundaries

This foundation does not call the Gate355 runtime/view-model hook and does not own provider transport, acquisition, retries, clocks, lifecycle, market-universe/ranking/Top-N/stablecoin policy, movement/freshness/area-weight arithmetic, retained state/effects/timers, CSS/theme/palette, radius/geometry/layout/collision/labels, SVG/canvas, `HomeRoute` wiring, persistence/Saved Analysis, Your Trades/journal/chart/Risk-Reward/navigation/transitions.

The authoritative Bubble-size metric remains 24h quote volume. Area weight remains only Gate352 normalized presentation evidence. No pixel-radius conversion is introduced.

## Why this slice is dependency-safe

Gate355 canonically closes the app-level React composition gap, while current design-system ownership still does not define Bubble-specific radius, layout, palette, dimming or label rules. A textual semantic presentation boundary follows the existing Kairos P14 pattern of exposing exact facts before geometry. It is reversible, testable and does not invent a user-facing Bubble design contract.
