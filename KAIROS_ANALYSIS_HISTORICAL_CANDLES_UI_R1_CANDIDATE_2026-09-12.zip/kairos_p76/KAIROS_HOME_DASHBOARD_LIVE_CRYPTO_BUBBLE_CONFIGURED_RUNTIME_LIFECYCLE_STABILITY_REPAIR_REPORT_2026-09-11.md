# Configured Bubble runtime lifecycle stability repair

Base: canonical Gate382, run 34586253466, head c8527f2429411e02a5c4d0763d3074ec9b5f8aac.

## Proven defect

The configured normalized-radius and pixel-radius hooks compose new universe and presentation-policy wrappers on each render. The released React runtime effect depended on those wrapper identities. An observation/error update therefore restarted the effect and reset its evidence. A bounded integration regression with only the runtime bootstrap mocked failed against Gate382: error evidence became null in both configured paths. Existing composition tests mocked intermediate hooks and did not exercise this interaction.

## Controlled change

Only the existing React runtime lifecycle owner changes production behavior. Its effect now depends on the two caller clocks, exclusion-set reference, Top-N count, abort signal, document, timer and neutral threshold. Recreating equivalent wrapper objects does not restart acquisition. Replacing any effective caller input still cleans up and restarts once. Readonly sets remain caller-owned and must be replaced rather than mutated in place; this patch does not introduce deep comparison or hidden caches.

One state owner and one effect remain. Exact input delegation, observation/error references, cancellation of superseded callbacks, asynchronous bootstrap cleanup, provider acquisition, freshness, configuration values, persistence, chart/navigation and presentation boundaries are preserved.

## Verification

New behavioral regression exercises both real configured hook chains through the real runtime state owner, including observation/error and bootstrap state updates, equivalent-wrapper rerenders and unmount cleanup. Eight input-change cases prove restart/cleanup and reject late errors from a superseded runtime. Existing runtime-binding regressions remain unchanged.

The dedicated static verifier guards effect inputs and sole lifecycle ownership. Full canonical regression remains required; local checks are supporting evidence only.

## UI impact

This repairs the runtime consumed by Home's existing textual dashboard and the released pixel-radius runtime. No bubble circles, radius defaults, responsive layout, palette or transitions are added. Gate382 remains GOLDEN until the new candidate passes the full canonical gate with both artifacts.
