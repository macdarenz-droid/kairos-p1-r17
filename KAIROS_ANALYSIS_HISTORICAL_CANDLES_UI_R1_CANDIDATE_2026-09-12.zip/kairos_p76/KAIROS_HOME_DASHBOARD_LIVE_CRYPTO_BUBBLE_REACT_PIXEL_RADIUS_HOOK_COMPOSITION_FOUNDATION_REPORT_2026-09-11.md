# KAIROS Home Dashboard Live Crypto Bubble React Pixel-Radius Hook Composition Foundation Report

Date: 2026-09-11
Base: canonical Gate377 Home Live Crypto Bubble React pixel-radius view-model foundation.

## Responsibility

This candidate adds one thin React composition seam between the released Gate366 normalized-radius hook and the released Gate377 pixel-radius view-model projector.

`useHomeDashboardLiveCryptoBubbleReactPixelRadiusViewModel(...)` accepts the exact caller-owned observed-at source, freshness evaluation-time source, Gate351 runtime-binding options, and exact caller-supplied Gate374 pixel-radius policy. It calls `useHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel(...)` exactly once with the exact runtime references, passes the exact returned radius-scale view-model reference plus exact caller policy exactly once to `projectHomeDashboardLiveCryptoBubbleReactPixelRadiusViewModel(...)`, and returns that exact Gate377 result unchanged.

## Semantics

- Caller-owned runtime inputs and pixel-radius policy remain unchanged; this layer chooses no provider, universe, lifecycle, product, visual-size or rendering defaults.
- The released Gate351→Gate366 hook chain remains the single React runtime lifecycle/state owner.
- Gate369 remains the normalized-radius React view-model owner.
- Gate374 remains the caller-owned pixel-radius policy validator/contract.
- Gate375 remains the CSS-pixel radius projection owner.
- Gate377 remains the pure radius-scale-view-model-to-pixel-radius-view-model owner.
- This hook adds no second retained state/effect owner, cache, timer, observer, viewport source, policy validation, arithmetic or error taxonomy.
- The exact Gate377 result is returned without reshaping runtime, normalized-radius or pixel-radius evidence.

## Ownership / non-scope

This seam owns no request/acquisition/retry, provider, universe, ranking, Top-N, stablecoin exclusion, movement, freshness, clock, persistence or market-truth behavior. It performs no radius arithmetic and chooses no minimum/maximum CSS-pixel values.

Responsive breakpoints, browser viewport measurement, collision/packing/layout, labels, hit targets, renderer choice, theme palette/tokens, CSS, stale/expired opacity, animation and visible Bubble rendering remain later presentation responsibilities. `HomeRoute` wiring remains unchanged. Live Crypto Bubble Map and Your Trades Bubble Map remain separate truth domains.

## Verification intent

Dedicated regression proves exact caller-runtime and policy delegation, exactly one released radius-scale-hook call and exactly one Gate377 projection call per render, no second app-level pixel-radius state owner across rerenders, and exact unchanged return of Gate377 evidence. Static verification rejects state/effect/cache ownership, clocks/timers, viewport/DOM access, transport/provider/product-policy logic, radius arithmetic/defaults, styling, `HomeRoute`, persistence and Your Trades ownership.
