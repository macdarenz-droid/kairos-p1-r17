# Home Dashboard Live Bubble Label Formatting Repair

## Root cause

The live crypto bubble data path was healthy, but the movement label rendered the authoritative high-precision decimal string directly. That made values such as `7.1260876703...%` wrap inside small bubbles and overlap nearby labels.

## Repair

- Keep the authoritative movement decimal unchanged for ranking, sizing, coloring, and data ownership.
- Format only the presentation label with bounded, signed, human-readable precision.
- Use compact notation for very large values and a readable significant-value format for very small non-zero values.
- Prevent label text from wrapping across the bubble boundary; truncate within the label instead.
- Preserve the existing Binance Spot truth, Top-30 ranking, bubble sizing/color, and animation ownership.

## Validation

- TypeScript typecheck passed.
- Focused bubble formatting and dashboard tests passed (11 tests).
- Production build passed.
- The full Vitest process completed without a reported failure, but its terminal summary was not available before the runtime polling limit; canonical verification remains authoritative.
