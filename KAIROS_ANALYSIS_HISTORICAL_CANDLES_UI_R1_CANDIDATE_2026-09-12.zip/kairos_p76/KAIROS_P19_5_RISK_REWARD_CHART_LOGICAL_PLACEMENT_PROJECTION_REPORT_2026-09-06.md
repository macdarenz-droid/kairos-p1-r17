# KAIROS P19.5 — Risk/Reward Chart Logical Placement Projection

## Authority
Base: canonical P19.4 Risk/Reward Chart Semantic Style Projection, `Kairos Controlled Roadmap Gate` run #277 / `34015419305`.

## Scope
Adds one app-boundary pure projection that combines authoritative P19 Risk/Reward semantics with caller-supplied logical horizontal extent using the already-owned generic `ChartTimestamp` type. The projection preserves Risk/Reward analysis identity plus logical `start` and `end` only.

## Ownership
P19 application semantics remain free of chart-feature dependencies. `ChartTimestamp` remains owned/exported by generic chart infrastructure. Horizontal extent is ephemeral presentation input during P19; P20 may later persist equivalent logical timestamps under Saved Analysis without P19 implementing persistence.

## Non-scope
No timestamp order validation or normalization, Risk/Reward or price math, provider/Lightweight Charts production APIs, pixel/screen geometry, P18 contract widening, DOM/UI/CSS, edit/drag/delete behavior, P20 persistence, P14 journal/execution mutation, P11 calculation duplication, semantic styling ownership, or hard-coded colors.
