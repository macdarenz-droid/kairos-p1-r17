# KAIROS P21.17 — Live Market Summary Baseline State Orchestration Foundation

## Authority
Base: canonical P21.16 Live Market Summary Delivery State Foundation, canonical gate #301 / run `34133279485`.

## Source-proven responsibility
Canonical P21.15 exposes the browser-ready P21.4 baseline acquisition port but explicitly owns no market state. Canonical P21.16 owns provider-neutral current-summary delivery state and P21.3 delivery application but explicitly owns no acquisition. Exact canonical source search shows no production owner that composes these released seams. The smallest dependency-safe next responsibility is therefore provider-neutral orchestration of one caller-requested baseline acquisition into one existing P21.16 state value, without selecting scope or adding lifecycle policy.

## Contract
- Accept an existing `LiveMarketSummaryDeliveryState`, an existing `LiveMarketSummaryBaselineAcquisitionPort`, and an explicit caller-owned scope.
- Invoke `acquireBaseline` exactly once and forward the caller-owned scope and optional acquisition options unchanged.
- On `acquisition-failed`, return the exact prior state unchanged.
- On successful acquisition, apply the returned complete-for-scope delivery only through released `applyLiveMarketSummaryDeliveryState`.
- Preserve released P21.16 `delivery-invalid` semantics and exact prior-state behavior rather than creating a new validation/error taxonomy.
- Return the resulting provider-neutral state only; add no state store, scheduler, universe policy, persistence, or UI owner.

## Explicit non-scope
- No market-universe/scope selection, ranking, filtering, grouping, sorting, Bubble metric/color/geometry/interaction, or Home wiring.
- No Binance/provider mapping, fetch/XHR/WebSocket/Response ownership, endpoint/query/status/header/error/retry/rate-limit/credentials/timeout policy.
- No clock/`Date`, observation-time acquisition, timestamp arbitration, freshness TTL, stale eviction, polling, reconnect, scheduling, or randomness.
- No new delivery completeness, decode, ticker, validation, or instrument-identity semantics.
- No persistence, repository/schema/backup, direct IndexedDB, journal, Your Trades Bubble Map, Saved Analysis, chart, or transition ownership.
