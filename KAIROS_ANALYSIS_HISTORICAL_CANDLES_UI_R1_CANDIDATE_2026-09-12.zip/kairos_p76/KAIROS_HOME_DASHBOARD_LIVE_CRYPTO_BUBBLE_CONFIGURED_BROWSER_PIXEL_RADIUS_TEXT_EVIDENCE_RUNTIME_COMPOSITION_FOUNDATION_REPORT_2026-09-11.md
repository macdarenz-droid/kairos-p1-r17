# Kairos Home Dashboard Live Crypto Bubble — Configured Browser Pixel-Radius Text-Evidence Runtime Composition Foundation

## Authority

Base: canonical Gate380 configured browser pixel-radius hook composition.

This slice adds one thin presentation-runtime composition edge only. It consumes already-released configured browser pixel-radius hook truth and already-released pure pixel-radius textual evidence. It does not create a new market/runtime owner.

## Responsibility

`HomeDashboardLiveCryptoBubbleConfiguredBrowserPixelRadiusTextEvidenceRuntime`:
- accepts the exact caller-owned product configuration;
- accepts the exact caller-owned pixel-radius policy;
- invokes `useHomeDashboardLiveCryptoBubbleConfiguredBrowserPixelRadiusViewModel(configuration, policy)` exactly once;
- when the returned model contains a non-null `pixelRadiusProjection`, passes that exact projection reference once to `HomeDashboardLiveCryptoBubblePixelRadiusTextEvidence`;
- when the returned model contains no projection, renders an explicit `unavailable` evidence state and does not invent pixel-radius data.

Gate380 remains configured browser pixel-radius hook owner. Gate376 remains pure pixel-radius textual-evidence presenter owner. Lower released owners retain pixel-radius projection arithmetic/policy validation, normalized radius, area weight, presentation semantics, market observation, freshness, universe/ranking, provider acquisition and the sole runtime lifecycle/state chain.

## Non-scope

No concrete pixel radius, responsive breakpoint, viewport measurement, collision, packing, layout, label-fit, hit-target, SVG/canvas/DOM renderer, CSS/theme/motion value, provider policy, market policy, persistence, Your Trades truth, navigation or transition ownership is introduced here.

No `HomeRoute` mutation is included.

No second hook lifecycle, state/effect/cache/timer, browser clock or acquisition path is introduced.

A null pixel-radius projection remains null/unavailable evidence. It is never replaced with a zero/default/estimated radius.

## Future boundary

Visible Bubble geometry/rendering remains a later controlled presentation responsibility. This slice only proves that exact configured browser pixel-radius truth can cross into the existing pure React textual evidence boundary without duplicating business/data/runtime ownership.
