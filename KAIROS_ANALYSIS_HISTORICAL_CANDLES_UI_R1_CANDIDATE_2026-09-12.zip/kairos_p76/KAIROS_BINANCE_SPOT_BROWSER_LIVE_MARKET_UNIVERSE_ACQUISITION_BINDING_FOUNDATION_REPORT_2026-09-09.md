# KAIROS Binance Spot Browser Live Market Universe Acquisition Binding Foundation

Base: exact canonical Gate #335 GOLDEN Live Market Universe acquisition-orchestration candidate.

This slice owns one Binance Spot browser Live Market Universe acquisition binding responsibility only. It composes the already-released browser-ready metadata acquisition port from the Binance Spot exchangeInfo chain, the already-released browser-ready baseline acquisition port from the Binance Spot 24h chain, and Gate335 one-shot provider-neutral orchestration.

The binding creates the two released concrete Binance browser ports and delegates them unchanged to `acquireLiveMarketUniverseOnce(...)`. The caller-owned readObservedAt source and caller-owned options and AbortSignal remain upstream inputs. `readObservedAt` is passed only to the released baseline browser binding. Gate335 options, including stablecoin-exclusion configuration and optional Top-N count, are passed unchanged to Gate335. The returned Gate335 result is returned unchanged.

Ownership constraints:
- No universe-policy duplication: active/exact-USDT/stablecoin eligibility, quote-volume ordering, symbol tie-break and Top-N remain released policy/composition owners.
- No provider request/transport/decode/mapping changes: the existing Binance browser metadata and 24h baseline chains remain authoritative.
- No observation-time or freshness ownership: `readObservedAt` stays caller-owned and existing lower boundaries continue to stamp authoritative facts.
- No freshness/cadence/lifecycle ownership: no visibility, timers, 5-second cadence, polling, retry or race semantics.
- No state/session/persistence ownership.
- No React/Home/Bubble presentation ownership.
- No Your Trades/journal/chart/navigation/transitions ownership.

Verification covers successful end-to-end dependency composition through mocked browser fetch, exact caller AbortSignal propagation across both lower browser acquisition chains, metadata failure short circuit, empty eligible-scope short circuit without baseline/observedAt use, baseline failure preservation, exact public export, exact controlled file scope, production typecheck/build, full unit regression and all registered verifier regressions.
