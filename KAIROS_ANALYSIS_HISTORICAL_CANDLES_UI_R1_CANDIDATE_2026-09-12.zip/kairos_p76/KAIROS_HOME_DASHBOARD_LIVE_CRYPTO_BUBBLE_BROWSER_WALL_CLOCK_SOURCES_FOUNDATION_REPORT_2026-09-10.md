# Home Dashboard Live Crypto Bubble Browser Wall Clock Sources Foundation

## Authority
Base: exact canonical Gate357 Home Live Crypto Bubble textual-evidence runtime composition, `Kairos Controlled Roadmap Gate` #357 / run `34488586757`.

## Responsibility
Provide the two concrete browser wall-clock source functions required by the released Gate357 runtime-composition path while preserving their existing separate caller-owned interfaces.

`readHomeDashboardLiveCryptoBubbleBrowserObservedAt()` returns the current browser wall-clock instant as an ISO-8601 string when acquisition asks for `observedAt`.

`readHomeDashboardLiveCryptoBubbleBrowserEvaluationTimeMs()` returns the current browser wall-clock epoch-millisecond value when freshness evaluation asks for its evaluation time.

The two functions read the wall clock independently on every call. They do not capture one shared timestamp and therefore do not collapse acquisition observation time into later freshness-evaluation time.

## Ownership boundaries
This foundation owns only browser wall-clock source adaptation. It does not change freshness thresholds, parse market timestamps, choose universe/stablecoin/Top-N values, choose neutral-movement threshold values, create lifecycle/timer/document options, perform provider requests, own cadence/retry, derive market facts, create React state/effects, render `HomeRoute`, choose Bubble radius/layout/palette/labels, persist data, or touch Your Trades/journal/chart/navigation/transitions.

Gate351 remains React lifecycle/state owner. Gate352 remains normalized area-weight arithmetic owner. Gate354 remains pure area-weight view-model owner. Gate355 remains hook composition owner. Gate356 remains textual semantic presentation owner. Gate357 remains textual-evidence runtime composition owner.

## Why this slice is dependency-safe
Fresh Gate357 source requires separate `() => string` acquisition-observed-at and `() => number` freshness-evaluation-time dependencies. The released freshness policy explicitly avoids internal wall-clock ownership, and no released Home Bubble app/browser owner currently supplies these concrete sources. Binding only the browser wall clock closes that missing dependency without selecting the still-separate product/configuration or visual contracts.
