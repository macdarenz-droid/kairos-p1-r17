# Live Market Summary Freshness Classification Policy Foundation

## Authority
Base: exact canonical Binance Home Dashboard Live Market Summary Scoped Snapshot Acquisition Port Adapter Foundation promoted by `Kairos Controlled Roadmap Gate` #311 / run `34173799325`.

Current user-approved P21 Live Crypto Bubble Map V1 product authority defines freshness from deterministic evaluation time minus canonical caller-owned `observedAt`: `fresh` through 15 seconds, `stale` above 15 seconds through 60 seconds, and `expired` above 60 seconds.

## Responsibility
This slice introduces one provider-neutral deterministic freshness-classification policy owner above released market facts and below presentation. It maps an already-computed caller-owned observation age in milliseconds to `fresh | stale | expired`.

V1 defaults are policy-owned/configurable inputs: `freshMaxAgeMs = 15_000` and `staleMaxAgeMs = 60_000`. The classification boundary is inclusive at 15s for fresh and 60s for stale.

## Explicit non-scope
No `Date.now()` / `new Date()` / internal wall-clock ownership; no `observedAt` parsing or evaluation-time ownership; no acquisition, polling, scheduling, page visibility/resume, retry, cancellation or background work; no provider/Binance transport change; no market-universe/default-scope/ranking/filter/top-N/stablecoin policy; no Home React wiring/hooks/UI state; no stale dimming or expired rendering; no Bubble geometry/size/color/interactions; no Your Trades/journal ownership; no persistence/IndexedDB/Saved Analysis/chart/navigation/transition ownership.

## Follow-on boundary
A later separately controlled owner may compute deterministic observation age from canonical `observedAt` plus caller-owned evaluation time and consume this policy. Visible-dashboard cadence, stale/expired presentation, and universe policy remain separate later responsibilities.
