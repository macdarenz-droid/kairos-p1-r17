# Kairos Home Dashboard Live Crypto Bubble React Pixel-Radius View-Model Foundation

## Responsibility

This slice adds one pure app-level composition seam over already released owners. It accepts the exact released `HomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel` plus an exact caller-supplied Gate374 `HomeDashboardLiveCryptoBubblePixelRadiusPolicy`.

The view model preserves that exact radius-scale view-model object and its exact `runtimeState` reference. When `radiusScaleProjection` is absent it keeps `pixelRadiusProjection` null without interpreting the policy. When projection evidence exists, it passes only the exact `radiusScaleProjection` reference and exact caller policy into `projectHomeDashboardLiveCryptoBubblePixelRadii(...)` once and exposes the exact Gate375 result.

## Ownership boundary

This slice owns no normalized-radius arithmetic, no pixel interpolation, no policy validation, no concrete/default radius bounds, no responsive breakpoints or browser viewport APIs, no collision/packing/layout/label-fit/hit-target logic, and no visible Bubble renderer.

It owns no React hook/state/effect or wall clock, no network/provider/acquisition/freshness/universe policy, no HomeRoute wiring, no CSS/theme/motion, no persistence, and no Your Trades truth.

Live Crypto Bubble Map and Your Trades Bubble Map remain separate truth domains.

## Dependency proof

- Gate369 already releases the pure React radius-scale view-model boundary.
- Gate374 releases caller-owned pixel-radius bounds validation.
- Gate375 releases deterministic pixel-radius projection from normalized radius evidence plus caller-supplied bounds.
- Gate376 releases a pure pixel-radius text-evidence presenter and explicitly leaves runtime/hook/renderer/default sizing outside its ownership.

Therefore composing Gate369 evidence with Gate375 through exact caller-supplied Gate374 policy is the smallest dependency-safe next technical seam. It does not choose any unresolved product/design sizing value.
