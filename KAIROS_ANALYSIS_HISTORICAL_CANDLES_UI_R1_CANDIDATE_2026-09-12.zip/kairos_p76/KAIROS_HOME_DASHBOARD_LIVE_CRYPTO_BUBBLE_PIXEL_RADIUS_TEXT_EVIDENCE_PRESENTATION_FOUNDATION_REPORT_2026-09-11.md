# KAIROS Home Dashboard Live Crypto Bubble Pixel-Radius Text Evidence Presentation Foundation

Date: 2026-09-11
Base: canonical Gate375 pixel-radius projection GOLDEN.

## Responsibility

Add one pure React presentation boundary that accepts the exact caller-produced `HomeDashboardLiveCryptoBubblePixelRadiusProjectionResult` released by Gate375 and exposes only its CSS-pixel radius evidence.

The presenter preserves projection success/failure semantics, exact released entry order, instrument association, exact failed entry index when present, and released policy/upstream failure evidence. It renders each exact `radiusCssPixels` value and preserves `null` as visibly `missing`. It performs no radius arithmetic and does not call a runtime hook.

## Explicit non-scope

No concrete/default minimum or maximum Bubble radii; no policy construction or validation; no normalized-radius or pixel-radius arithmetic; no React state/effects/memo/cache; no clocks/timers/cadence; no browser viewport APIs or responsive breakpoints; no collision/packing/layout/labels/hit targets; no SVG/canvas/DOM Bubble renderer; no palette/theme/CSS/motion; no HomeRoute wiring; no provider/request/acquisition/product policy; no persistence/IndexedDB/Saved Analysis; no Your Trades/journal/chart/Risk-Reward truth.

## Controlled delta

Exactly five candidate paths relative to Gate375:
1. this report;
2. `package.json` verifier registration;
3. `scripts/verify-home-dashboard-live-crypto-bubble-pixel-radius-text-evidence-presentation-foundation.mjs`;
4. `src/app/HomeDashboardLiveCryptoBubblePixelRadiusTextEvidence.tsx`;
5. `tests/home-dashboard-live-crypto-bubble-pixel-radius-text-evidence-presentation-foundation.test.tsx`.

No existing path is removed.
