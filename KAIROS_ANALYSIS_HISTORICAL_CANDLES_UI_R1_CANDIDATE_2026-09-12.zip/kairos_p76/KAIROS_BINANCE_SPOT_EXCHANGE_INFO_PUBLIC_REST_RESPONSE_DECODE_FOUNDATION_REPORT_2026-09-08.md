# Binance Spot Exchange Information Public REST Response Decode Foundation

## Authority
Base: canonical Binance Spot Exchange Information Public REST Request Execution Boundary Foundation, `Kairos Controlled Roadmap Gate` #315 / run `34206420246`.

## Responsibility
Canonical #315 can execute one already-described public Binance Spot exchangeInfo request through an injected connector but deliberately does not own response representation or JSON parsing. Released Binance 24h REST architecture already separates execution from a pure JSON-text response decoder. This slice applies that same proven ownership boundary to exchangeInfo: accept already-received response data, accept only text under the existing provider convention, parse JSON exactly once, return `payload: unknown` on success, and return deterministic unsupported-data / invalid-JSON failures.

## Explicit non-scope
- No fetch/XHR/WebSocket/browser transport or concrete `Response` acquisition.
- No HTTP status/header/body acquisition or interpretation.
- No exchangeInfo semantic validation or interpretation of `symbols`, `symbol`, `status`, `baseAsset`, `quoteAsset`, filters or permissions.
- No mapping to `LiveMarketUniverseInstrumentMetadataFact`; no `status -> tradingEnabled` policy.
- No request descriptor/execution widening.
- No cache/polling/refresh/retry/backoff/request-weight/rate-limit policy.
- No USDT eligibility filtering, stablecoin exclusion, quote-volume ranking, tie-break or Top-N.
- No freshness changes, Home React wiring, stale presentation or Bubble rendering.
- No Your Trades/journal, persistence/IndexedDB, Saved Analysis, chart/navigation or transition ownership.
