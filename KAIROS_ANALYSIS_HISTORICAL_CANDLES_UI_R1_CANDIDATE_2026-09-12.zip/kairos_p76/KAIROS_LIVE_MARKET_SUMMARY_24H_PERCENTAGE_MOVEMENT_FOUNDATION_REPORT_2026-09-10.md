# Live Market Summary 24h Percentage Movement Foundation

## Authority
Base: exact canonical Gate341 Binance Home observed-runtime composition candidate, promoted by `Kairos Controlled Roadmap Gate` #341 / run `34419801691`.

## Source-proven responsibility
The approved P21 Live Crypto Bubble Map uses 24h quote volume as bubble-size truth and 24h percentage movement as bubble-color truth. `LiveMarketSummaryFact` already owns canonical `lastPrice`, strictly-positive `open24h`, and `quoteVolume24h`, but no provider-neutral production owner derives 24h percentage movement.

This slice adds only that missing provider-neutral derivation for one already-canonical `LiveMarketSummaryFact`. It first delegates complete fact validation to `validateLiveMarketSummaryFact`. It then computes signed change as `lastPrice - open24h` through released `decimalSubtract`, and computes percentage movement through released `calculatePercentage(change, open24h)`. The result preserves the exact validated fact and instrument association by reference and exposes only the derived `movementPercent24h` DecimalString. Successful fact validation already guarantees a strictly-positive denominator; any unexpected Decimal-kernel/calculator failure still fails closed as `movement-calculation-invalid`.

## Explicit non-scope
No Binance `priceChangePercent` or provider-specific second truth; no JavaScript Number/parseFloat floating-price arithmetic; no color palette or positive/negative/neutral threshold; no bubble radius/geometry/layout; no quote-volume ranking, Top-N or stablecoin policy; no freshness, cadence, visibility/lifecycle, retry or universe refresh; no session mutation; no React/Home/Bubble state/rendering; no persistence/IndexedDB; no navigation, Your Trades, journal, chart, Risk/Reward, Calculation Brain, Saved Analysis or transition ownership.
