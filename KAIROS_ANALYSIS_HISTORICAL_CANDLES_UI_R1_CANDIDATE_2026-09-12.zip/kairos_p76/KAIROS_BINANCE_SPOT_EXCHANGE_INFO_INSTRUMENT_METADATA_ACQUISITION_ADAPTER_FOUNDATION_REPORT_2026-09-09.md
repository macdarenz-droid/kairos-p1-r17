# Binance Spot exchangeInfo Instrument Metadata Acquisition Adapter Foundation

## Canonical base
Gate #322 — Live Market Universe Instrument Metadata Acquisition Port Contract Foundation.

## Source-proven responsibility
Implement the released provider-neutral metadata acquisition port through the already-released Binance Spot exchangeInfo public REST round trip. Forward optional caller-owned cancellation unchanged through the released execution seam. Return successful authoritative metadata facts unchanged. Translate released provider/decode/mapping failure or connector rejection to the existing provider-neutral `acquisition-failed` result.

## Explicit non-scope
- No concrete browser `fetch`/XHR/WebSocket transport or HTTP status/header/body ownership.
- No retry/backoff/rate/request-weight policy.
- No cache, polling, visibility, resume, session lifecycle, freshness or cadence ownership.
- No USDT eligibility, stablecoin exclusion, 24h quote-volume ranking, symbol tie-break or Top-N policy.
- No Home/Live Crypto Bubble UI, Your Trades, journal, persistence, chart, navigation or transitions.
