# Binance Spot Exchange Information Public REST Round Trip Composition Foundation

Base: canonical Gate #320 response-delivery composition GOLDEN.

Responsibility: compose the already-released unconditional exchangeInfo request descriptor, injected execution seam and response-delivery seam for one round trip. Caller-owned execution options are forwarded only through the released execution owner. Connector rejection propagates unchanged.

Non-scope: concrete transport/HTTP Response semantics, retry/backoff/rate policy, acquisition adapter/polling/resume, universe filtering/stablecoin exclusion/ranking/Top-N, freshness, Home/Bubble UI, Your Trades, persistence/chart/navigation/transitions.
