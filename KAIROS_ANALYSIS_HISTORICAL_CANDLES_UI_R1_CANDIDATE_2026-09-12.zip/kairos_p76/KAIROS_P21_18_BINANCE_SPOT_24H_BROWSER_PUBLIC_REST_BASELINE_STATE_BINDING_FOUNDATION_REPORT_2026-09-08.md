# KAIROS P21.18 — Binance Spot 24h Browser Public REST Baseline State Binding Foundation

## Authority
Base: canonical P21.17 Live Market Summary Baseline State Orchestration Foundation, canonical gate #302 / run `34140732046`.

## Source-proven responsibility
Canonical P21.15 exposes `createBinanceSpot24hBrowserPublicRestBaselineAcquisitionPort(readObservedAt)` as the browser-ready P21.4 acquisition-port binding while deliberately owning no current-summary state. Canonical P21.17 exposes `acquireLiveMarketSummaryBaselineIntoState(state, acquisitionPort, scope, options?)` as provider-neutral one-shot acquisition-to-P21.16-state orchestration while deliberately requiring an already-created acquisition port. Exact current source search finds no production owner composing these released seams, and P21.17's verifier explicitly forbids the P21.15 browser acquisition factory inside the provider-neutral orchestration module. The smallest dependency-safe next responsibility is therefore one browser-ready state-binding entry point that composes only P21.15 and P21.17.

## Contract
- Accept an existing `LiveMarketSummaryDeliveryState`, caller-owned `readObservedAt`, explicit caller-owned scope, and optional caller-owned acquisition options.
- Create the acquisition port only through released `createBinanceSpot24hBrowserPublicRestBaselineAcquisitionPort(readObservedAt)`.
- Delegate acquisition and state application only through released `acquireLiveMarketSummaryBaselineIntoState`.
- Preserve released `acquisition-failed`, `delivery-invalid`, cancellation/options forwarding, and exact-prior-state semantics unchanged.
- Add no new transport, provider decode, validation, state store, lifecycle, freshness, ranking, persistence, or UI owner.

## Explicit non-scope
- No market-universe/scope selection, ranking, filtering, grouping, sorting, Bubble metric/color/geometry/interaction, or Home wiring.
- No new fetch/XHR/WebSocket/Response ownership, endpoint/query/provider mapping, HTTP status/header/error/retry/rate-limit/credentials/timeout policy.
- No `Date.now`, `new Date`, observation-time acquisition, timestamp arbitration, freshness TTL, stale eviction, polling, reconnect, scheduling, or randomness.
- No new delivery completeness, decode, ticker, validation, or instrument-identity semantics.
- No state store, persistence, repository/schema/backup, direct IndexedDB, journal, Your Trades Bubble Map, Saved Analysis, chart, or transition ownership.
