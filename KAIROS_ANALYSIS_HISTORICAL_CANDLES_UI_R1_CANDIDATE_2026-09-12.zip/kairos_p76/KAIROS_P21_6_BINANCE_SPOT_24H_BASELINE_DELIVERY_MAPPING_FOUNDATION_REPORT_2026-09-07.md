# KAIROS P21.6 — Binance Spot 24h Baseline Delivery Mapping Foundation

## Authority
Base: canonical P21.5 Binance Spot 24h Summary Fact Mapping Foundation, `Kairos Controlled Roadmap Gate` #290 / run `34074736949`.

## Responsibility
P21.4 requires an explicit caller-provided scope and a validated P21.3 `complete-for-scope` delivery. P21.5 maps one decoded Binance Spot 24h ticker entry into one canonical P21.2 fact. P21.6 adds only the missing pure provider-composition seam: explicit caller scope + decoded single-entry or entry-array payload + caller-owned `observedAt` -> P21.5 per-entry mapping -> P21.3 complete-for-scope composition -> P21.4 success validation.

Invalid payload shapes, invalid mapped entries, duplicate facts, out-of-scope facts or missing requested-scope facts reject rather than infer completeness. Provider response order is not promoted into ranking or universe truth.

## Explicit non-scope
- No HTTP/fetch/browser transport, REST host/path/query construction, endpoint selection, or `symbol` versus `symbols` query policy.
- No symbol batching, request-weight, rate-limit, credential, retry, polling, subscription or reconnect policy.
- No concrete P21.4 acquisition-port adapter orchestration and no market-universe selection/ranking.
- No accumulator/state/order/freshness/reset ownership.
- No Bubble Map sizing/color/grouping/filtering/geometry/interactions or Home wiring.
- No persistence, journal/Your-Trades semantics, direct IndexedDB UI access, or dashboard transition motion.
