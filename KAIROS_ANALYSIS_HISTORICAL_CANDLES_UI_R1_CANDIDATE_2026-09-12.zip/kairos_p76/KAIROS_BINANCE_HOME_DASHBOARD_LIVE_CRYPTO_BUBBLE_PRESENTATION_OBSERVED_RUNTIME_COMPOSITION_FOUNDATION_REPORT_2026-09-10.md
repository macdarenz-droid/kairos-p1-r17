# Kairos Binance Home Dashboard Live Crypto Bubble Presentation-Observed Runtime Composition Foundation

## Responsibility

This slice adds the app-level Binance Home Live Crypto Bubble presentation-observed runtime composition below React.

It preserves the exact caller-owned Gate345 runtime dependencies and constructs exactly one Gate349 semantic observation adapter from the caller-owned Gate346 presentation policy plus optional semantic observation sink. That adapter is passed unchanged as Gate345's Bubble metric observation sink. The wrapper delegates exactly once to Gate345 and returns Gate345's runtime bootstrap result unchanged.

## Contract

- Preserve exact `readObservedAt` and `readEvaluationTimeMs` references.
- Preserve exact Gate345 `universe` and optional browser `lifecycle` options.
- Require one caller-owned `HomeDashboardLiveCryptoBubblePresentationPolicy`.
- Accept one optional Gate349 `HomeDashboardLiveCryptoBubblePresentationStateObservationSink`.
- Construct exactly one Gate349 semantic observation adapter.
- Pass that exact adapter as Gate345's `observationSink`.
- Delegate exactly once to `startBinanceHomeDashboardLiveCryptoBubbleObservedRuntime(...)`.
- Return Gate345's runtime bootstrap result unchanged.

## Explicit non-scope

No second raw metric/freshness observation sink. No internal clock/time source. No Binance/provider transport or response mapping. No active-USDT/stablecoin/ranking/Top-N policy. No freshness thresholds or acquisition cadence. No runtime/session mutation beyond delegation to Gate345. No design-system palette/tokens, color choice, radius scaling, geometry/collision/layout, labels/icons, accessibility copy, interactions or animation. No React/Home/Bubble rendering, DOM lifecycle or component state. No persistence/IndexedDB/Saved Analysis. No Your Trades Bubble Map, journal/trade truth, chart, Risk/Reward, navigation or transitions.

## Boundary

This is an application composition seam only. Gate345 remains the owner of Binance Home Bubble observed-runtime composition. Gate349 remains the owner of metric-observation to semantic presentation-state adaptation. Gate346 remains the owner of pure semantic presentation-state projection. A later Home/React slice may consume the released semantic observation stream without absorbing provider/runtime/business truth.
