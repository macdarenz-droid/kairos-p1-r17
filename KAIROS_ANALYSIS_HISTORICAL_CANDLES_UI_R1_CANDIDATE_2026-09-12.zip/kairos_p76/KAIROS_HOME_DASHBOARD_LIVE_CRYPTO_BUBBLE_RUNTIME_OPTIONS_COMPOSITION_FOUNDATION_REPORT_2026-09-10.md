# Home Live Crypto Bubble Runtime-Options Composition Foundation

## Authority

Base: exact canonical Gate359 Home Live Crypto Bubble browser text-evidence runtime composition, `Kairos Controlled Roadmap Gate` #359 / run `34503359548`.

## Responsibility

`composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions(...)` is a pure app-level composition boundary for the two product-configuration values that remain caller-owned after Gate359:
- it accepts the exact caller-owned excluded-stablecoin set reference;
- it accepts the exact caller-owned neutral-movement threshold Decimal value;
- it places those exact values into the already-released `HomeDashboardLiveCryptoBubbleReactRuntimeBindingOptions` shape;
- it deliberately does not provide `topNCount`, so the Top-30 default remains owned by the released Top-N policy; and
- it deliberately does not provide lifecycle overrides, so browser lifecycle defaults remain owned by the released lifecycle adapter and cadence policy.

The boundary does not validate, derive, clone, expand, or replace either caller-owned product value.

## Explicit non-scope

- No concrete stablecoin symbol/base-asset list is chosen here.
- No concrete neutral movement threshold is chosen here.
- No provider transport, acquisition/retry/cadence, visibility, clocks, freshness thresholds, universe eligibility semantics, ordering, tie-break, or metric arithmetic.
- No React state/effects/memo, browser timers, DOM, CSS, palette, radius, collision, layout, labels, SVG/canvas, interaction, animation, or transitions.
- No `HomeRoute` or Bubble geometry wiring.
- No persistence/IndexedDB/Saved Analysis.
- No Your Trades Bubble Map, journal/trade, chart, Risk/Reward, Calculation Brain, or navigation ownership.

## Ownership preservation

Gate351 remains React lifecycle/state owner. Gate352 remains normalized area-weight arithmetic owner. Gate354 remains view-model owner. Gate355 remains hook composition owner. Gate356 remains semantic textual presenter. Gate357 remains injected runtime-to-presenter owner. Gate358 remains browser wall-clock owner. Gate359 remains browser-clock-to-runtime composition owner.

The released universe eligibility policy still owns eligibility semantics, the released Top-N policy still owns its default count of 30, and the released browser lifecycle/cadence policies still own their defaults. Concrete excluded-stablecoin contents and the neutral threshold remain caller/product-configuration truth until separately released.
