# KAIROS P21.13 — Binance Spot 24h Public REST Baseline Acquisition Adapter Foundation

## Authority
Base: canonical P21.12 caller cancellation propagation, canonical gate #297 / run `34110678855`.

## Source-proven responsibility
Canonical P21.4 defines `LiveMarketSummaryBaselineAcquisitionPort.acquireBaseline(scope, options)` with explicit `acquisition-failed`, but owns no Binance implementation. Canonical P21.11 composes request description, one injected connector execution and response delivery. Canonical P21.12 explicitly records cancellation propagation as the smallest prerequisite before a concrete P21.4 adapter. Therefore this slice owns only the missing Binance composition adapter from P21.4 to the already-released P21.11/P21.12 seams.

## Contract
- Factory receives the existing injected P21.8 connector; no network implementation is created here.
- Factory receives a caller-owned observation-time source and reads it once per acquisition; no clock/freshness policy is introduced.
- `acquireBaseline(scope, options)` forwards P21.4 caller cancellation unchanged through P21.12.
- Successful P21.11 delivery is revalidated through the existing P21.4 success validator before returning the P21.4 success result.
- Existing request/response composition failures and connector rejection map to the P21.4 `acquisition-failed` result; no transport-specific error taxonomy is invented.

## Explicit non-scope
- No concrete `fetch`/XHR/WebSocket/browser transport and no `Response`/HTTP status/header/body acquisition.
- No `AbortController` creation, signal combination, timeout, abort-cause interpretation or error translation.
- No retry/backoff/throttle/rate-limit/request-weight/credentials/polling/reconnect.
- No market-universe selection/ranking, batching/chunking, or new request/decode/ticker/completeness semantics.
- No market state accumulator, freshness TTL, reset/reconnect state machine or persistence.
- No Live Crypto Bubble Map sizing/color/grouping/filtering/geometry/Home wiring.
- No Your Trades Bubble Map, journal reads, Saved Analysis, direct IndexedDB UI access or dashboard transitions.
