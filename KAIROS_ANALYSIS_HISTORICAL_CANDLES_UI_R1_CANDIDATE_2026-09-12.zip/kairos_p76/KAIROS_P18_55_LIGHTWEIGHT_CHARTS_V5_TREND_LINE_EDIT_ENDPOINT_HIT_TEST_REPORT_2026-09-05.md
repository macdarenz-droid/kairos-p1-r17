# KAIROS P18.55 — Lightweight Charts v5 Trend-Line Edit Endpoint Hit-Test Geometry

Date: 2026-09-05  
Authoritative base: **P18.54 — Chart Trend-Line Edit Initiation Coordination**  
Canonical base evidence: **Kairos Controlled Roadmap Gate #265 / run 33968683537 / head 1d4db6d9c77ac19ead6a040cc00c414b550d5657 — SUCCESS**  
Canonical base candidate artifact: **KAIROS_CURRENT_CANDIDATE artifact 9970327476**

## Source-derived missing seam

Canonical P18.54 establishes edit initiation only after the caller already has typed P18.48 endpoint evidence:

- P18.5 owns forward logical drawing -> provider screen-segment projection and already exposes exact projected `start` and `end` points.
- P18.12 owns provider-side pure trend-line hit-test geometry, but its current whole-segment result carries drawing identity only and does not distinguish `start` from `end`.
- P18.48 owns the authoritative endpoint vocabulary: `start | end`.
- P18.54 accepts that typed endpoint evidence and authoritative selected drawing state to initiate the existing `start-editing` transition.

Fresh canonical source search found no production owner that derives the P18.48 endpoint vocabulary from the existing P18.5 projected endpoint geometry. Without that seam, a later provider/UI edge would have to reimplement endpoint-distance geometry or invent endpoint authority itself.

No new Lightweight Charts API behavior is required for this slice: it operates only on the already-established P18.5 projected screen-segment contract. Therefore no external provider research is needed for P18.55.

## P18.55 responsibility

P18.55 deliberately extends the **existing P18.12 hit-test geometry owner** instead of creating a second geometry module.

It adds:

`hitTestLightweightChartsV5TrendLineEditEndpoints(segments, x, y, tolerancePx)`

Behavior:
1. consume only already-projected P18.5 trend-line screen segments;
2. validate the same finite/non-negative hit-test input contract already used by P18.12;
3. inspect projected `start` and `end` points only;
4. preserve P18.12 reverse-order top-most/latest segment precedence;
5. return the exact drawing ID plus existing P18.48 `start | end` endpoint when within tolerance;
6. when both endpoints of the same top-most segment are within tolerance, choose the nearer endpoint;
7. if both endpoint distances are exactly equal, fail closed to `null` rather than inventing authority;
8. return `null` outside endpoint tolerance and never fall back to whole-segment selection semantics.

The existing P18.12 whole-segment hit-test API remains unchanged.

## Ownership preservation

- P18.5 remains sole logical -> screen projection owner.
- P18.12 remains sole provider-side trend-line hit-test geometry owner; P18.55 is a controlled extension inside that module.
- P18.13 remains primitive/provider hit-shape binding owner.
- P18.48 remains endpoint vocabulary/edit-construction owner.
- P18.54 remains selected-state + typed endpoint -> edit-intent coordinator.
- P18.55 owns only projected endpoint proximity -> typed endpoint evidence.

## Explicit non-scope

No provider click/pointer/drag subscription; no primitive hit-shape amendment; no interaction dispatch/state mutation; no edit initiation/execution; no provider coordinate reverse projection; no collection mutation; no presentation refresh; no handle rendering/style/UI; no persistence/restore; no undo/redo; no new drawing kind; no Risk/Reward/P19; no journal/calculation/navigation truth; no toolchain migration.

## Focused runtime evidence

The focused P18.55 test proves:
- exact start and end endpoint evidence derives from projected geometry;
- the nearer endpoint wins when both are in range, while exact ties fail closed;
- top-most/latest projected segment precedence remains intact;
- line-body hits do not masquerade as endpoint hits;
- invalid input reuses the established P18.12 failure contract.

## Canonical promotion requirement

Promotion requires exact P18.54 -> P18.55 scope, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.55 verifier/runtime, focused P18.55 tests, historical P18.54/P18.12/P18.5/P18.48 compatibility, full units, full controlled roadmap regression through P18.55, P18.55 -> P17 chart regressions, historical closures, candidate artifact, and gate evidence.


## Local/static evidence actually completed

PASS:
- dedicated P18.55 verifier;
- historical P18.54, P18.12, P18.5, and P18.48 verifier contracts;
- all P18 verifier contracts through P18.55: **55/55**;
- all other non-P1-wrapper roadmap verifier contracts: **152/152**;
- P1 static contract: **214 source files / 17 pinned package versions**.

A clean dependency-backed attempt for `npm ci` -> TypeScript -> production build -> focused P18.55/P18.12/P18.54/P18.48 Vitest ended in a container transport timeout during dependency installation before usable completion evidence was produced. Partial dependency/build residue was removed and is not treated as evidence. Therefore local dependency install, TypeScript, build, focused Vitest, and full P1 are **not claimed** for P18.55; canonical GitHub Actions must establish them before promotion.
