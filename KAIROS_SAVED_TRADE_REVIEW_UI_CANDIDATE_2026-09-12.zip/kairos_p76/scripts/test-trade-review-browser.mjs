import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { spawn } from 'node:child_process';
const require = createRequire(resolve(process.env.KAIROS_BROWSER_PACKAGE_DIR ?? '.', 'package.json'));
const { chromium } = require('playwright');
const evidence = resolve('.trade-review-evidence'); mkdirSync(evidence, { recursive: true });
const variables = [...new Set([...readFileSync('src/app/tradeReview.css', 'utf8').matchAll(/var\(\s*(--[\w-]+)/g)].map(match => match[1]))];
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', '--host', '127.0.0.1', '--port', '4178', '--strictPort'], { stdio: 'pipe' });
let log = ''; server.stdout.on('data', x => log += x); server.stderr.on('data', x => log += x);
let browser, page;
try {
  let ready = false;
  for (let i = 0; i < 100; i++) { try { if ((await fetch('http://127.0.0.1:4178/')).ok) { ready = true; break; } } catch {} await new Promise(r => setTimeout(r, 200)); }
  assert(ready, log);
  browser = await chromium.launch({ headless: true, ...(process.env.KAIROS_CHROMIUM_EXECUTABLE ? { executablePath: process.env.KAIROS_CHROMIUM_EXECUTABLE, args: ['--no-sandbox', '--disable-dev-shm-usage', '--no-zygote', '--single-process'] } : {}) });
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, timezoneId: 'Australia/Melbourne', reducedMotion: 'reduce' });
  page = await context.newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
  await page.route('https://**/*', route => route.abort());
  // Full production route tree, with test-only mounting; direct URLs and reloads
  // use BrowserRouter and the actual persisted browser database.
  await page.route('http://127.0.0.1:4178/**', route => route.request().resourceType() === 'document' ? route.fulfill({ contentType: 'text/html', body: '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0}</style><div id="execution-test-root"></div><script type="module">import RefreshRuntime from "/@react-refresh";RefreshRuntime.injectIntoGlobalHook(window);window.$RefreshReg$=()=>{};window.$RefreshSig$=()=>type=>type;window.__vite_plugin_react_preamble_installed__=true;const f=await import("/tests/fixtures/tradeReviewBrowser.tsx");await f.mount();</script>' }) : route.continue());
  const savedFacts = () => page.evaluate(async () => (await import('/tests/fixtures/tradeReviewBrowser.tsx')).readSavedFacts());
  await page.goto('http://127.0.0.1:4178/journal');
  for (const [label, value] of [['Market', 'crypto'], ['Direction', 'long'], ['Status', 'closed']]) await page.getByLabel(new RegExp('^' + label)).selectOption(value);
  await page.getByLabel(/^Symbol/).fill('BTCUSDT');
  await page.getByLabel(/^Opened/).fill('2026-09-12T14:00'); await page.getByLabel(/^Closed/).fill('2026-09-12T15:00');
  await page.getByRole('textbox', { name: 'P&L currency', exact: true }).fill('USDT');
  await page.locator('summary').filter({ hasText: 'Trade plan' }).click();
  for (const [label, value] of [['Planned entry', '90'], ['Planned stop', '80'], ['Planned target', '130'], ['Planned quantity', '2']]) await page.getByLabel(label, { exact: true }).fill(value);
  for (const [type, price, time] of [['entry', '100', '2026-09-12T14:00'], ['exit', '120', '2026-09-12T15:00']]) {
    await page.getByRole('button', { name: `Add ${type}`, exact: true }).click();
    const label = type === 'entry' ? 'Entry' : 'Exit';
    const index = type === 'entry' ? 1 : 2;
    await page.getByLabel(`${label} ${index} price`).fill(price); await page.getByLabel(`${label} ${index} quantity`).fill('2'); await page.getByLabel(`${label} ${index} date and time`).fill(time);
  }
  await page.locator('summary').filter({ hasText: 'Fees' }).click(); await page.getByRole('button', { name: 'Add fee', exact: true }).click();
  await page.getByLabel('Fee 1 amount').fill('0.3'); await page.getByLabel('Fee 1 currency').fill('USDT');
  await page.getByRole('button', { name: 'Save trade', exact: true }).click();
  await page.getByText('Trade saved to your journal.', { exact: true }).waitFor();
  const first = (await savedFacts()).trades[0];
  // Repeated symbol, distinct identity and status: must never open the wrong one.
  for (const [label, value] of [['Market', 'crypto'], ['Direction', 'short'], ['Status', 'draft']]) await page.getByLabel(new RegExp('^' + label)).selectOption(value);
  await page.getByLabel(/^Symbol/).fill('BTCUSDT'); await page.getByRole('button', { name: 'Save trade', exact: true }).click();
  await page.waitForFunction(() => document.querySelectorAll('.kairos-history-card').length === 2);
  const original = await savedFacts(), second = original.trades.find(t => t.id !== first.id);
  assert.equal(original.executions.length, 2); assert.equal(original.fees.length, 1);
  await page.locator('.kairos-history-card').filter({ hasText: '39.7 USDT' }).getByRole('link', { name: 'View trade', exact: true }).click();
  const reviewed = () => page.locator('[data-review-trade-id]');
  await reviewed().waitFor(); assert.equal(await reviewed().getAttribute('data-review-trade-id'), first.id);
  await page.waitForFunction(() => document.activeElement?.id === 'kairos-review-title');
  assert.equal(new URL(page.url()).searchParams.get('trade'), first.id);
  await page.getByRole('region', { name: 'Saved plan', exact: true }).getByText('90', { exact: true }).waitFor();
  await page.getByRole('region', { name: 'Actual executions', exact: true }).getByText('100', { exact: true }).waitFor();
  await page.getByRole('region', { name: 'Recorded fees', exact: true }).getByText('0.3 USDT', { exact: true }).waitFor();
  assert.equal(await page.getByRole('region', { name: 'Recorded result', exact: true }).getByText('39.7 USDT', { exact: true }).count(), 2);
  await page.reload(); await reviewed().waitFor(); assert.equal(await reviewed().getAttribute('data-review-trade-id'), first.id);
  const measurements = [];
  for (const width of [320, 390]) {
    await page.setViewportSize({ width, height: 844 }); let geometry;
    for (const theme of ['kairos-depth', 'cosmic', 'ocean']) {
      await page.evaluate(async theme => (await import('/tests/fixtures/tradeReviewBrowser.tsx')).theme(theme), theme);
      const actual = await page.evaluate(variables => ({
        missing: variables.filter(v => !getComputedStyle(document.documentElement).getPropertyValue(v).trim()),
        overflow: document.documentElement.scrollWidth > innerWidth,
        cards: [...document.querySelectorAll('.kairos-review__card')].map(e => { const r = e.getBoundingClientRect(), s = getComputedStyle(e); return { width: r.width, height: r.height, padding: parseFloat(s.paddingLeft), border: parseFloat(s.borderTopWidth) }; }),
        controls: [...document.querySelectorAll('.kairos-review button, .kairos-review a')].map(e => ({ height: e.getBoundingClientRect().height }))
      }), variables);
      assert.deepEqual(actual.missing, []); assert(!actual.overflow); assert(actual.cards.every(c => c.padding >= 12 && c.border >= 1)); assert(actual.controls.every(c => c.height >= 44));
      if (geometry) assert.deepEqual(actual.cards, geometry, 'Theme preserves geometry'); else geometry = actual.cards;
      measurements.push({ width, theme, ...actual });
      await page.evaluate(() => scrollTo(0, 0)); await page.screenshot({ path: resolve(evidence, `review-${width}-${theme}.png`), fullPage: true });
    }
  }
  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole('link', { name: 'Choose another trade', exact: true }).click();
  await page.getByRole('combobox', { name: 'Saved trade', exact: true }).selectOption(second.id);
  await reviewed().waitFor(); assert.equal(await reviewed().getAttribute('data-review-trade-id'), second.id);
  await page.getByText('No executions recorded.', { exact: true }).waitFor();
  await page.getByRole('link', { name: 'Home', exact: true }).click(); await page.getByRole('button', { name: 'Your Trades', exact: true }).click();
  const bubble = page.locator(`[data-glass-key="${first.id}"]`); await bubble.waitFor();
  const center = await bubble.evaluate(e => { const r = e.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; });
  await page.mouse.click(center.x, center.y);
  await page.getByRole('complementary', { name: 'Selected trade', exact: true }).getByRole('link', { name: 'View trade', exact: true }).click();
  await reviewed().waitFor(); assert.equal(await reviewed().getAttribute('data-review-trade-id'), first.id);
  await page.goto('http://127.0.0.1:4178/analysis?trade=missing'); await page.getByRole('heading', { name: 'Trade not found', exact: true }).waitFor();
  assert.equal(await reviewed().count(), 0);
  assert.deepEqual(await savedFacts(), original, 'Review/navigation/reloads/theme changes do not modify facts');
  assert.deepEqual(errors, []);
  writeFileSync(resolve(evidence, 'trade-review-browser-report.json'), JSON.stringify({ passed: true, source: 'real save UI and production BrowserRouter, no seeded trades', exactJournalIdentity: first.id, duplicateSymbolIdentity: second.id, reloadAndDirectLinks: true, yourTradesLink: true, planSeparateFromActual: true, result: '39.7 USDT', savedFactsUnchanged: true, measurements, errors }, null, 2));
  console.log('PASS: exact saved trade from Journal/Your Trades, direct URL/reload, repeated symbols, plan/fill/fee/result display, missing state and 320/390px × three themes.');
} catch (error) {
  if (page) { writeFileSync(resolve(evidence, 'failure.html'), await page.content()); await page.screenshot({ path: resolve(evidence, 'failure.png'), fullPage: true }); }
  throw error;
} finally { await browser?.close(); server.kill('SIGTERM'); }
