# Kairos P6.4 — Transactional Validated Replacement

Status: HOLD pending dependency-backed GitHub gate.
Base: P6.3 Restore Preflight + Recovery — PASS/LOCKED (GitHub run #68, commit e3205370721f3bc5c4cbf684ffff732f5f4768f1).

## Objective
Add the first destructive restore mutation, but only behind P6.3 preparation. Replacement must be one short atomic transaction, rollback completely on failure, and pass the existing database integrity owner after commit.

## Research
- MDN IndexedDB guidance: clear + replacement writes must be combined in one transaction; otherwise interruption between transactions can leave an empty database.
- MDN IDBTransaction.abort(): abort rolls back all changes associated with the transaction.
- Dexie transaction docs: `db.transaction('rw', tables, callback)` commits when the transaction promise resolves and aborts on uncaught failure.
- Dexie bulkPut docs: bulkPut failures must be contained by a transaction when partial persistence is unacceptable.

## Implementation
- Added `src/data/backup/restoreReplacement.ts`.
- Added `replaceKairosDatabaseFromPreparedRestore(db, prepared)`; accepts only P6.3 prepared restore data.
- Uses the existing P5.5 `runKairosAtomicWrite()` owner with explicit `metadata` scope.
- Extended `MetadataRepository` with `replaceAll()` so backup code does not directly own table mutation.
- `replaceAll()` clears and bulk-writes inside the same transaction.
- After commit, runs `assertKairosDatabaseIntegrity()` and only then reports success.
- Added `tests/restore-replacement.test.ts` covering successful replacement, rollback after a synthetic failure following clear, empty replacement, recovery snapshot preservation, post-import integrity, and unchanged schema.
- Added `verify:p6:restore-replacement` static contract.

## Protected behavior / non-scope
- No schema change: DB remains V1, metadata-only.
- No dependency change; package lock unchanged.
- No merge restore.
- No file-picker/download UI.
- No encryption/compression/hash claim.
- No automatic recovery replay yet.
- No future trade tables.

## Verification
All locally executable static contracts P2.1 through P6.4 PASS.
Dependency-backed Vitest/typecheck/build are intentionally left to the GitHub release gate because dependencies are not installed in this environment.
Package-lock SHA-256: 2b7a654d6f69ad43053d5b327dd9ef191982b713314906cdc7587451721025bf

Promotion rule: HOLD until GitHub runs the complete P1→P6.4 gate successfully and uploads both evidence artifacts.
