# KAIROS P17.15 — Chart Viewport History Demand Composition

## BASE
P17.14R2 Series Logical Range Scope and Artifact Repair — canonical GitHub Actions Run #191 / 33752918781 PASS.

## OBJECTIVE
Compose the P17.13 visible logical viewport boundary and P17.14 loaded-series coverage boundary into one provider-neutral history-demand signal without acquiring history, calling a provider, mutating chart data, persisting state, or owning a fixed preload threshold.

## RESEARCH
Current official Lightweight Charts v5.2 documentation states that `ISeriesApi.barsInLogicalRange(range)` can be combined with visible logical range changes to determine when historical data may need to be loaded. Its example uses a bars-before threshold, but that example value is application policy rather than library truth. `ITimeScaleApi` documentation also points callers to `getVisibleLogicalRange()` together with `barsInLogicalRange()` for complete viewport/series information.

Sources:
- https://tradingview.github.io/lightweight-charts/docs/api/interfaces/ISeriesApi
- https://tradingview.github.io/lightweight-charts/docs/api/interfaces/ITimeScaleApi
- https://tradingview.github.io/lightweight-charts/docs/release-notes

## OWNER TRACE
- P17.13 owns visible logical range observation/subscription.
- P17.14 owns loaded-series coverage evidence for a supplied logical range.
- P17.15 owns only composition of those two P17 signals into provider-neutral demand evidence.
- The caller injects `minimumBarsBefore`; P17.15 does not hard-code TradingView's documentation example threshold.
- P15 remains provider-neutral market-data transport owner.
- P16 remains concrete Binance live-feed owner.
- No historical acquisition/provider request owner is added here.
- P18 remains drawing/overlay owner.

## CHANGE
- Add `ChartViewportHistoryDemandPolicy`, `ChartViewportHistoryDemandSignal`, listener, and port.
- Add `createChartViewportHistoryDemandPort()` composition.
- `getCurrentDemand()` evaluates the current visible range against loaded-series coverage.
- `subscribeDemandChange()` composes existing visible-range subscription with coverage queries.
- Emit a demand signal only when coverage is present and `barsBefore` is below the caller-injected minimum.
- Preserve null for no viewport, no coverage, or sufficient coverage.
- Validate injected policy as finite and non-negative.
- Add exports, dedicated tests, verifier, and package script.

## NON-SCOPE
No fetch. No WebSocket. No Binance REST/API. No historical candle request. No retry/backoff. No persistence. No chart `setData()`/`update()`. No execution/journal reconciliation. No calculations. No drawings/markers. No navigation/theme/motion changes.

## DATA FLOW
P17.13 visible logical range -> P17.14 coverage query -> P17.15 injected policy comparison -> demand signal or null.

There is no reverse mutation or acquisition path.

## OFFLINE / PERFORMANCE
Fully local synchronous evaluation. One coverage query per explicit current-demand evaluation or visible-range callback. No polling/timer/observer beyond the already-owned P17.13 subscription.

## TEST PLAN
- Dedicated static verifier.
- Dedicated Vitest covering demand, sufficient coverage, null viewport, null coverage, subscription behavior, unsubscribe delegation, and invalid policy.
- Production TypeScript/build.
- Full unit regression.
- Full controlled roadmap regression through P17.15.
- P17.14 through P17.1 runtime regressions and historical closures in canonical CI.

## STATUS
Candidate only until canonical GitHub gate PASS.

## NEXT only if PASS
Re-inspect P17 responsibilities from authoritative P17.15. Do not invent another slice from numbering; if no material Chart Engine responsibility remains, create the mandatory P17 system closure patch before P18.
