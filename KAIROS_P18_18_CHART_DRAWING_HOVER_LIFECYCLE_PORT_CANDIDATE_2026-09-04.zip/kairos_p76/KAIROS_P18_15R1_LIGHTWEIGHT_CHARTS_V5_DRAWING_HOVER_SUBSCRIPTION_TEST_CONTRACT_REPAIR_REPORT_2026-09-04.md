# KAIROS P18.15R1 — Lightweight Charts v5 Drawing Hover Subscription Test Contract Repair

## Authority
- Authoritative base: canonical P18.14, GitHub run #213, head `6e0b52447d247eb5639e50120e1e497feb039b44`.
- Failed P18.15 runs #214/#215 are evidence only and are not authoritative bases.

## Failure evidence
- Run #214 exposed a gate-only expected-verifier-filename defect; the gate was repaired without changing the candidate.
- Run #215 passed exact scope, deterministic install, and exact `lightweight-charts@5.2.1` dependency proof, then failed production TypeScript compilation because the P18.15 test fixture supplied `{ price: number }` where canonical `RendererPricePoint` requires `{ value: number }`.
- Exact compiler errors were TS2353 at the test fixture `start` and `end` points.

## Repair
P18.15R1 is rebuilt from canonical P18.14. The intended P18.15 provider hover-subscription lifecycle changes are reapplied, and only the test fixture contract is repaired from `price` to canonical renderer field `value`.

## Ownership preserved
- P18.14 remains the sole `hoveredObjectId` -> Kairos drawing-hover projection owner.
- P18.15R1 owns only `subscribeCrosshairMove` / `unsubscribeCrosshairMove` lifecycle and delivery of P18.14 projections.
- No click handling, selection truth, drag/edit behavior, drawing truth mutation, persistence, calculations, market acquisition, journal truth, toolbar state, navigation truth, or P19 behavior is added.

## Local evidence
- TypeScript compilation, production build, dedicated P18.15 verifier, and targeted P18.15/P18.14 tests are run locally for this repair candidate.
- Canonical promotion still requires a new GitHub gate PASS.
