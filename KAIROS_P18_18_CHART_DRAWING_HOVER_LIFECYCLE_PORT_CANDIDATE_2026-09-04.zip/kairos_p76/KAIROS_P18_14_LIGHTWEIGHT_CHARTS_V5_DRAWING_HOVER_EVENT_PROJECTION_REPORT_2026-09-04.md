# KAIROS P18.14 — Lightweight Charts v5 Drawing Hover Event Projection

## Authority
Built from canonical P18.13R1 after GitHub Actions run #212 completed successfully.

## Scope
Adds one provider presentation-boundary projection from Lightweight Charts v5 `MouseEventParams.hoveredObjectId` shape to a Kairos drawing-hover observation, filtered against the current renderer drawing snapshot.

## Ownership
- P18.13 remains the primitive `hitTest()` / `externalId` source owner.
- P18.14 owns only provider hover-event identity projection and current-snapshot filtering.
- No chart subscription lifecycle is added.
- No selection, click state, drag/edit, drawing truth mutation, persistence, calculations, market acquisition, journal truth, toolbar state, or P19 behavior is added.

## Official API evidence
Lightweight Charts v5.2 documents that series primitive `hitTest(x, y)` registers object ids for crosshair/click events. Chart `subscribeCrosshairMove` and `subscribeClick` use `MouseEventParams`, whose hovered object identity is exposed as `hoveredObjectId`. This slice deliberately stops before subscription lifecycle composition.

## Controlled files
1. `KAIROS_P18_14_LIGHTWEIGHT_CHARTS_V5_DRAWING_HOVER_EVENT_PROJECTION_REPORT_2026-09-04.md`
2. `package.json`
3. `scripts/verify-p18-14-lightweight-charts-v5-drawing-hover-projection.mjs`
4. `src/features/chart/index.ts`
5. `src/features/chart/lightweightChartsV5DrawingHoverProjection.ts`
6. `tests/lightweight-charts-v5-drawing-hover-projection.test.ts`
