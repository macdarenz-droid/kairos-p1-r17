# KAIROS P18.9 — Lightweight Charts v5 Provider Series Resolution Binding

## Authority
Built directly from canonical P18.8 after GitHub Actions run #205 (`33766621087`) completed successfully at head `0fb38fb73ac1aacf2b25a4767bcfaea00e065b29`.

## Controlled purpose
Expose the already-existing Lightweight Charts v5 neutral-handle-to-vendor-series identity map through a narrow provider-specific binding, without contaminating `ChartEngineSeriesHandle` with vendor APIs. This supplies the missing provider series resolution seam required before P18 can safely compose the canonical P18.4 primitive attach/detach lifecycle with the canonical P18.8 trend-line primitive factory.

## Production ownership
`lightweightChartsV5ModuleAdapter.ts` continues to own the handle-to-vendor-series map it already maintained internally. P18.9 makes that map available through `createLightweightChartsV5DriverBinding()` while preserving `createLightweightChartsV5Driver()` as the existing provider-neutral driver entry point. Resolution fails closed for unknown, removed, or chart-cleared handles.

## Official API evidence
Current Lightweight Charts 5.2 documentation defines `ISeriesApi.attachPrimitive()` and `detachPrimitive()` as methods on the concrete series API, while series primitives receive the concrete chart and series APIs when attached. Therefore the next drawing integration layer requires a safe way to resolve Kairos' neutral series handle back to the concrete provider series without moving vendor methods onto the neutral handle itself.

## Explicit non-scope
No primitive attach/detach calls, no primitive factory composition, no Canvas rendering, no coordinate conversion, no hit testing, pointer/crosshair capture, drag/edit state, toolbar, persistence, autoscale ownership, calculations, market acquisition, journal truth, or P19 risk/reward behavior.

## Exact controlled diff from P18.8
1. `KAIROS_P18_9_LIGHTWEIGHT_CHARTS_V5_PROVIDER_SERIES_RESOLUTION_BINDING_REPORT_2026-09-04.md`
2. `package.json`
3. `scripts/verify-p18-9-lightweight-charts-v5-provider-series-resolution-binding.mjs`
4. `src/features/chart/index.ts`
5. `src/features/chart/lightweightChartsV5ModuleAdapter.ts`
6. `tests/lightweight-charts-v5-provider-series-resolution-binding.test.ts`

## Verification status before canonical gate
Dedicated P18.9 static verifier is run locally. Any local TypeScript/build/Vitest results are reported separately; canonical GitHub Actions remains authoritative for promotion.
