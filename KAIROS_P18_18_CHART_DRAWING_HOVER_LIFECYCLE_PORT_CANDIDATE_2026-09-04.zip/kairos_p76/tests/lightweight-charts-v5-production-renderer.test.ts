import { describe, expect, it } from 'vitest';
import { createLightweightChartsV5ProductionRendererFactory } from '../src/features/chart/lightweightChartsV5ProductionRenderer';

describe('P17.10 Lightweight Charts v5 production renderer composition', () => {
  it('composes the real package into the existing renderer factory without creating presentation resources eagerly', () => {
    const factory = createLightweightChartsV5ProductionRendererFactory();
    expect(factory).toBeDefined();
    expect(typeof factory.create).toBe('function');
  });
});
