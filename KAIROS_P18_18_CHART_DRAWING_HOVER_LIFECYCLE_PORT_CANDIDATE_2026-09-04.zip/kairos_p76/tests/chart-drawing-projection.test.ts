import { describe, expect, it } from 'vitest';
import { parsePositiveDecimalString, type DecimalString } from '../src/domain/trades';
import {
  projectChartDrawing,
  projectChartDrawingAnchor,
  type ChartDrawingAnchor,
  type ChartTrendLineDrawing,
} from '../src/features/chart';

function decimal(value: string): DecimalString {
  const parsed = parsePositiveDecimalString(value);
  if (!parsed.ok) throw new Error(`invalid positive decimal fixture: ${value}`);
  return parsed.value;
}

describe('P18.2 chart drawing projection boundary', () => {
  it('reuses the chart renderer projection for drawing anchors', () => {
    const anchor: ChartDrawingAnchor = {
      timestamp: '2026-09-03T00:00:00.000Z',
      price: decimal('100.25'),
    };

    expect(projectChartDrawingAnchor(anchor)).toEqual({
      time: 1788393600,
      value: 100.25,
    });
  });

  it('projects a trend line without changing drawing identity or kind', () => {
    const drawing: ChartTrendLineDrawing = {
      id: 'drawing-1',
      kind: 'trend-line',
      start: {
        timestamp: '2026-09-03T00:00:00.000Z',
        price: decimal('100'),
      },
      end: {
        timestamp: '2026-09-03T00:05:00.000Z',
        price: decimal('105.5'),
      },
    };

    expect(projectChartDrawing(drawing)).toEqual({
      id: 'drawing-1',
      kind: 'trend-line',
      start: { time: 1788393600, value: 100 },
      end: { time: 1788393900, value: 105.5 },
    });
  });

  it('keeps the source drawing anchored in DecimalString truth', () => {
    const price = decimal('101.125');
    const drawing: ChartTrendLineDrawing = {
      id: 'drawing-2',
      kind: 'trend-line',
      start: { timestamp: '2026-09-03T00:00:00.000Z', price },
      end: { timestamp: '2026-09-03T00:01:00.000Z', price },
    };

    projectChartDrawing(drawing);
    expect(drawing.start.price).toBe(price);
    expect(drawing.end.price).toBe(price);
  });

  it('inherits invalid-time rejection from the existing chart projection owner', () => {
    expect(() => projectChartDrawingAnchor({
      timestamp: 'not-a-time',
      price: decimal('100'),
    })).toThrow('invalid-chart-timestamp');
  });
});
