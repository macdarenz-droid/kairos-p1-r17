import { describe, expect, it, vi } from 'vitest';
import {
  createChartDrawingHoverPortFromDriver,
  type ChartDrawingHoverDriver,
  type ChartDrawingHoverObservation,
  type ChartEngineSeriesHandle,
  type RendererChartDrawing,
} from '../src/features/chart';

function seriesHandle(): ChartEngineSeriesHandle {
  return {
    setPriceLineData() {},
    setCandleData() {},
    updatePriceLine() {},
    updateCandle() {},
  };
}

const drawings: readonly RendererChartDrawing[] = [{
  id: 'trend-1',
  kind: 'trend-line',
  start: { time: 100, value: 10 },
  end: { time: 200, value: 20 },
}];

describe('P18.18 chart drawing hover lifecycle port', () => {
  it('attaches through the injected provider-neutral driver with renderer drawings and listener', () => {
    const detach = vi.fn();
    const attach = vi.fn(() => ({ detach }));
    const driver: ChartDrawingHoverDriver = { attach };
    const target = seriesHandle();
    const onHover = vi.fn<(hover: ChartDrawingHoverObservation | null) => void>();

    createChartDrawingHoverPortFromDriver(driver).attach(target, drawings, onHover);

    expect(attach).toHaveBeenCalledTimes(1);
    expect(attach).toHaveBeenCalledWith(target, drawings, onHover);
  });

  it('keeps hover observations provider-neutral and supports explicit clear', () => {
    let listener: ((hover: ChartDrawingHoverObservation | null) => void) | null = null;
    const driver: ChartDrawingHoverDriver = {
      attach(_series, _drawings, onHover) {
        listener = onHover;
        return { detach() {} };
      },
    };
    const observed: Array<ChartDrawingHoverObservation | null> = [];

    createChartDrawingHoverPortFromDriver(driver).attach(seriesHandle(), drawings, (hover) => {
      observed.push(hover);
    });

    listener?.({ kind: 'drawing-hover', drawingId: 'trend-1' });
    listener?.(null);
    expect(observed).toEqual([
      { kind: 'drawing-hover', drawingId: 'trend-1' },
      null,
    ]);
  });

  it('detaches provider-owned hover resources exactly once', () => {
    const detach = vi.fn();
    const driver: ChartDrawingHoverDriver = {
      attach: () => ({ detach }),
    };

    const session = createChartDrawingHoverPortFromDriver(driver).attach(
      seriesHandle(),
      drawings,
      vi.fn(),
    );
    session.destroy();
    session.destroy();

    expect(detach).toHaveBeenCalledTimes(1);
  });
});
