import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/chartDrawingHoverPort.ts', 'utf8');
const projection = readFileSync('src/features/chart/lightweightChartsV5DrawingHoverProjection.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));

for (const required of [
  "import type { ChartEngineSeriesHandle } from './chartEngineDriver'",
  "import type { ChartDrawingId } from './chartDrawingContract'",
  "import type { RendererChartDrawing } from './chartDrawingProjection'",
  'export interface ChartDrawingHoverObservation',
  "readonly kind: 'drawing-hover'",
  'readonly drawingId: ChartDrawingId',
  'export interface ChartDrawingHoverDriverHandle',
  'detach(): void',
  'export interface ChartDrawingHoverDriver',
  'export interface ChartDrawingHoverSession',
  'export interface ChartDrawingHoverPort',
  'export function createChartDrawingHoverPortFromDriver',
  'handle.detach()',
]) {
  if (!source.includes(required)) throw new Error(`P18.18 drawing-hover port missing: ${required}`);
}

for (const forbidden of [
  'lightweight-charts',
  'subscribeCrosshairMove',
  'unsubscribeCrosshairMove',
  'subscribeClick',
  'hitTest(',
  'IndexedDB',
  'Dexie',
  'fetch(',
  'WebSocket',
  'localStorage',
  'risk-reward',
]) {
  if (source.includes(forbidden)) throw new Error(`P18.18 crossed controlled scope: ${forbidden}`);
}

if (!projection.includes('export type ChartDrawingHoverProjection = ChartDrawingHoverObservation')) {
  throw new Error('P18.18 P18.14 projection is not aliased to the provider-neutral hover observation');
}
if (!index.includes("from './chartDrawingHoverPort'")) {
  throw new Error('P18.18 chart index export missing');
}
if (
  packageJson.scripts?.['verify:p18:18-chart-drawing-hover-port'] !==
  'node scripts/verify-p18-18-chart-drawing-hover-port.mjs'
) {
  throw new Error('P18.18 package verifier script missing');
}

console.log('P18.18 chart drawing hover lifecycle port verification passed.');
