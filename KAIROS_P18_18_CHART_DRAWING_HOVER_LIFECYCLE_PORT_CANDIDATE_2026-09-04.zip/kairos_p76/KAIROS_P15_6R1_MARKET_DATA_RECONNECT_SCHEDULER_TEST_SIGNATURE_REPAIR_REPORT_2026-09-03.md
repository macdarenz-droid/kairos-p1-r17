# KAIROS P15.6R1 — Market Data Reconnect Scheduler Test Signature Repair

## BASE
P15.5 canonical PASS — Run #130 / SHA 7ff6975de7488c070b67e3ded248cfae1018d88f.

## FAILED CANDIDATE
P15.6 — Run #131 / SHA 9ff65d49b176b2acd14313ac33335493a0d6d6b5.

## FAILURE
Canonical build failed with TS2493 because the fake test scheduler was inferred as a one-argument mock while the test inspected argument index 1 for the forwarded delay.

## ROOT CAUSE
Test-double TypeScript signature mismatch only. Production scheduler ownership and behavior were not implicated.

## REPAIR
Changed only the fake scheduler callback signature from `(next)` to `(next, _delayMs)` so its inferred tuple matches the production scheduler contract and the delay-forwarding assertion is type-valid.

## PRODUCTION CHANGE
None.

## NON-SCOPE
No production behavior change, provider, network, timer implementation, persistence, UI, calculation, P&L, or architecture change.

## RESULT
HOLD pending canonical GitHub gate.
