import fs from 'node:fs';

const files = [
  'src/domain/calculations/riskCalculator.ts',
  'tests/risk-calculator.test.ts',
];

for (const file of files) {
  if (!fs.existsSync(file)) {
    throw new Error(`Missing ${file}`);
  }
}

const source = fs.readFileSync(
  'src/domain/calculations/riskCalculator.ts',
  'utf8',
);

for (const token of [
  'calculateRiskPriceDistance',
  'decimalSubtract',
  'decimalAbs',
  "'invalid-decimal'",
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P11.8 risk contract: ${token}`);
  }
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error(
    'P11.8 Risk Calculator must not use native numeric arithmetic/coercion.',
  );
}

for (const forbidden of [
  'decimalMultiply',
  'plannedQuantity',
  'TradePlanRecord',
  'TradeExecutionRecord',
  'TradeFeeRecord',
  'marketType',
  'grossPnl',
  'netPnl',
  'initialRisk',
  'realizedR',
  'leverage',
  'multiplier',
  'tickValue',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
  'exchangeRate',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.8 out-of-scope policy/owner detected: ${forbidden}`);
  }
}

console.log('P11.8 risk price-distance primitive verification PASS');
