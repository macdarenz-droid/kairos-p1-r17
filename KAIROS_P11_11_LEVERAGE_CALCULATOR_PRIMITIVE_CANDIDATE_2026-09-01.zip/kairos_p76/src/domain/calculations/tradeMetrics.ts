import type {
  DecimalString,
  TradeExecutionRecord,
  TradeSide,
} from '../trades';
import { assessExecutionBalance } from './executionBalance';
import { calculateFlatTradeGrossRealizedPnl } from './grossRealizedPnl';

export type TradeMetricsState =
  | 'unrealized'
  | 'partially-realized'
  | 'realized';

export interface TradeMetricsCompleteness {
  readonly hasEntryExecutions: boolean;
  readonly hasExitExecutions: boolean;
  readonly hasAverageEntryPrice: boolean;
  readonly hasAverageExitPrice: boolean;
  readonly hasGrossPnl: boolean;
  readonly hasTotalFees: false;
  readonly hasNetPnl: false;
  readonly hasPnlPercent: false;
  readonly hasInitialRisk: false;
  readonly hasRealizedR: false;
}

export interface TradeMetrics {
  readonly grossPnl: DecimalString | null;
  readonly totalFees: null;
  readonly netPnl: null;
  readonly pnlPercent: null;
  readonly initialRisk: null;
  readonly realizedR: null;
  readonly averageEntryPrice: DecimalString | null;
  readonly averageExitPrice: DecimalString | null;
  readonly totalEnteredQuantity: DecimalString;
  readonly totalExitedQuantity: DecimalString;
  readonly remainingQuantity: DecimalString;
  readonly state: TradeMetricsState | null;
  readonly completeness: TradeMetricsCompleteness;
}

export type TradeMetricsResult =
  | { readonly ok: true; readonly value: TradeMetrics }
  | {
      readonly ok: false;
      readonly reason:
        | 'invalid-execution-decimal'
        | 'exit-without-entry'
        | 'over-exited';
    };

function toMetricsState(
  balanceState: 'empty' | 'open' | 'partially-exited' | 'flat',
): TradeMetricsState | null {
  if (balanceState === 'empty') return null;
  if (balanceState === 'open') return 'unrealized';
  if (balanceState === 'partially-exited') return 'partially-realized';
  return 'realized';
}

export function calculateTradeMetrics(
  side: TradeSide,
  executions: readonly TradeExecutionRecord[],
): TradeMetricsResult {
  const balance = assessExecutionBalance(executions);
  if (!balance.ok) {
    return { ok: false, reason: balance.reason };
  }

  const grossPnlResult = calculateFlatTradeGrossRealizedPnl(side, executions);
  if (!grossPnlResult.ok) {
    return { ok: false, reason: grossPnlResult.reason };
  }

  const { entry, exit, netQuantity } = balance.aggregate;
  const grossPnl = grossPnlResult.available
    ? grossPnlResult.grossRealizedPnl
    : null;

  return {
    ok: true,
    value: Object.freeze({
      grossPnl,
      totalFees: null,
      netPnl: null,
      pnlPercent: null,
      initialRisk: null,
      realizedR: null,
      averageEntryPrice: entry.weightedAveragePrice,
      averageExitPrice: exit.weightedAveragePrice,
      totalEnteredQuantity: entry.quantity,
      totalExitedQuantity: exit.quantity,
      remainingQuantity: netQuantity,
      state: toMetricsState(balance.state),
      completeness: Object.freeze({
        hasEntryExecutions: entry.quantity !== '0',
        hasExitExecutions: exit.quantity !== '0',
        hasAverageEntryPrice: entry.weightedAveragePrice !== null,
        hasAverageExitPrice: exit.weightedAveragePrice !== null,
        hasGrossPnl: grossPnl !== null,
        hasTotalFees: false,
        hasNetPnl: false,
        hasPnlPercent: false,
        hasInitialRisk: false,
        hasRealizedR: false,
      }),
    }),
  };
}
