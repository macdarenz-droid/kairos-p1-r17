import type { DecimalString } from '../trades';
import {
  decimalAbs,
  decimalSubtract,
} from './decimalKernel';

export type RiskPriceDistanceResult =
  | { readonly ok: true; readonly value: DecimalString }
  | { readonly ok: false; readonly reason: 'invalid-decimal' };

export function calculateRiskPriceDistance(
  plannedEntryPrice: DecimalString,
  plannedStopPrice: DecimalString,
): RiskPriceDistanceResult {
  const difference = decimalSubtract(plannedEntryPrice, plannedStopPrice);
  if (!difference.ok) {
    return { ok: false, reason: 'invalid-decimal' };
  }

  const distance = decimalAbs(difference.value);
  if (!distance.ok) {
    return { ok: false, reason: 'invalid-decimal' };
  }

  return {
    ok: true,
    value: distance.value,
  };
}
