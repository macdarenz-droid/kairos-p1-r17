export const APP_VERSION = '0.1.0-p1';
export const BUILD_ID = import.meta.env.VITE_BUILD_ID?.trim() || 'dev-local';

export const buildInfo = Object.freeze({
  appName: 'Kairos Trading Journal',
  appVersion: APP_VERSION,
  buildId: BUILD_ID,
});
