# KAIROS P16.17R1 — Browser Public Trade Reconnect Test Fixture Repair

## OBJECTIVE
Repair only the failed P16.17 runtime test fixture from the canonical P16.16 base semantics.

## FAILURE CLASSIFICATION
Canonical Run #166 passed exact scope, deterministic install, and production build. Full unit regression failed only in the two new P16.17 tests. Both failed before reconnect execution because the test fixture used venue `BINANCE_SPOT`, while the canonical P16.1/P16.16 venue contract is `binance-spot`.

## CHANGE
Change only the P16.17 test instrument venue from `BINANCE_SPOT` to canonical `binance-spot`. Production reconnect implementation is unchanged.

## NON-SCOPE
No production behavior change, reconnect-policy change, scheduler change, transport change, lifecycle change, chart/P17 work, persistence, journal mutation, credentials, or order execution.

## REGRESSION
The repair preserves the original six-file P16.17 controlled scope relative to P16.16, with the repair report replacing the failed candidate report.

## RESULT
HOLD pending canonical P16.17R1 gate.
