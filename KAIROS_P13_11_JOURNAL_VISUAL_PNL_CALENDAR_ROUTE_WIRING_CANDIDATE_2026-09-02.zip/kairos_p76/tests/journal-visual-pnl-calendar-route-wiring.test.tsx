import 'fake-indexeddb/auto';
import '@testing-library/jest-dom/vitest';
import { afterEach, describe, expect, it } from 'vitest';
import { render, screen } from '@testing-library/react';
import { JournalRoute } from '../src/app/JournalRoute';
import { createKairosDatabase, openKairosDatabase } from '../src/data/database';
import { createKairosRepositories } from '../src/data/repositories';
import { writeVisualPnlTimeZonePreference } from '../src/application/visual-pnl';
import { createTradeDomainId, type TradeId } from '../src/domain/trades';

const names = new Set<string>();

function dbName(label: string): string {
  const value = `kairos-p1311-${label}-${crypto.randomUUID()}`;
  names.add(value);
  return value;
}

afterEach(async () => {
  for (const name of names) {
    await new Promise<void>((resolve, reject) => {
      const request = indexedDB.deleteDatabase(name);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
      request.onblocked = () => reject(new Error('blocked'));
    });
  }
  names.clear();
});

async function openFixture(label: string) {
  const db = createKairosDatabase(dbName(label));
  await openKairosDatabase(db);
  return { db, repositories: createKairosRepositories(db) };
}

async function putClosedTrade(
  repositories: ReturnType<typeof createKairosRepositories>,
  closedAt: string,
): Promise<void> {
  await repositories.trades.put({
    id: createTradeDomainId<TradeId>(),
    symbol: 'ZONE',
    marketType: 'stock',
    side: 'long',
    status: 'closed',
    source: 'manual',
    openedAt: '2026-09-02T13:00:00.000Z',
    closedAt,
    createdAt: '2026-09-02T13:00:00.000Z',
    updatedAt: closedAt,
  });
}

describe('P13.11 Journal Visual P&L calendar route wiring', () => {
  it('renders an explicit unconfigured state instead of inferring the runtime timezone', async () => {
    const { db, repositories } = await openFixture('unconfigured');
    await putClosedTrade(repositories, '2026-09-02T14:30:00.000Z');

    render(<JournalRoute db={db} />);

    expect(await screen.findByRole('heading', { name: 'Daily results' })).toBeInTheDocument();
    expect(await screen.findByText('Choose a time zone in Settings to view daily results.')).toBeInTheDocument();
    expect(screen.queryByText('03/09/2026')).not.toBeInTheDocument();
    db.close();
  });

  it('uses the persisted explicit timezone to query and render P13.8/P13.9 daily results', async () => {
    const { db, repositories } = await openFixture('configured');
    await writeVisualPnlTimeZonePreference(
      repositories.metadata,
      'Australia/Sydney',
      '2026-09-02T10:00:00.000Z',
    );
    await putClosedTrade(repositories, '2026-09-02T14:30:00.000Z');

    render(<JournalRoute db={db} />);

    expect(await screen.findByRole('heading', { name: 'Daily results' })).toBeInTheDocument();
    expect(await screen.findByText('03/09/2026')).toBeInTheDocument();
    expect(screen.getByText('Time zone: Australia/Sydney')).toBeInTheDocument();
    expect(screen.getByText('Result unavailable')).toBeInTheDocument();
    db.close();
  });

  it('keeps a persisted UTC policy distinct from Australia/Sydney day attribution', async () => {
    const { db, repositories } = await openFixture('utc');
    await writeVisualPnlTimeZonePreference(
      repositories.metadata,
      'UTC',
      '2026-09-02T10:00:00.000Z',
    );
    await putClosedTrade(repositories, '2026-09-02T14:30:00.000Z');

    render(<JournalRoute db={db} />);

    expect(await screen.findByText('02/09/2026')).toBeInTheDocument();
    expect(screen.queryByText('03/09/2026')).not.toBeInTheDocument();
    expect(screen.getByText('Time zone: UTC')).toBeInTheDocument();
    db.close();
  });
});
