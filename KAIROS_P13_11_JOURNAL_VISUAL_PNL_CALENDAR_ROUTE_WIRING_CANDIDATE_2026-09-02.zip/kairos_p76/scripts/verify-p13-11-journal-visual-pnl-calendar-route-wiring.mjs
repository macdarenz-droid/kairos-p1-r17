import { readFileSync } from 'node:fs';

const route = readFileSync('src/app/JournalRoute.tsx', 'utf8');
const tests = readFileSync('tests/journal-visual-pnl-calendar-route-wiring.test.tsx', 'utf8');

const requireText = (text, value, label) => {
  if (!text.includes(value)) throw new Error(`P13.11 missing ${label}: ${value}`);
};

requireText(route, 'readVisualPnlTimeZonePreference(repositories.metadata)', 'P13.10R1 timezone preference owner reuse');
requireText(route, 'listJournalVisualPnlDailySummary(db, timeZone)', 'P13.8 Journal daily query reuse');
requireText(route, '<VisualPnlCalendar projection={dailyVisualPnl.projection} />', 'P13.9 calendar presentation reuse');
requireText(route, "kind: 'unconfigured'", 'explicit no-timezone state');
requireText(route, 'Choose a time zone in Settings to view daily results.', 'plain unconfigured guidance');
requireText(route, 'visualPnlRequestSequence', 'stale async result guard');
requireText(route, 'Promise.all([refreshHistory(), refreshDailyVisualPnl()])', 'post-commit refresh composition');
requireText(tests, "'Australia/Sydney'", 'configured timezone regression');
requireText(tests, "'UTC'", 'distinct timezone regression');
requireText(tests, 'queryByText(\'03/09/2026\')', 'no device fallback regression');

for (const forbidden of [
  'resolvedOptions().timeZone',
  'getTimezoneOffset',
  "timeZone: 'Australia/Sydney'",
  "timeZone: 'UTC'",
  'decimalSum',
  'decimalAdd',
  'parseFloat',
  'exchangeRate',
]) {
  if (route.includes(forbidden)) {
    throw new Error(`P13.11 rejected duplicate/fallback owner in JournalRoute: ${forbidden}`);
  }
}

console.log('PASS P13.11 Journal Visual P&L calendar route wiring verifier');
