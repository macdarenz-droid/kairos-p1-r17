# KAIROS P10.1 Manual Trade Save Command Foundation Patch Report

Date: 2026-09-01
Status: HOLD pending authoritative GitHub full gate
Base: P9.2R4 Activation Backup Count Contract Repair — PASS / LOCKED

## OBJECTIVE
Add the application command boundary that will own manual trade creation before any P10 form UI is allowed to persist data.

## RESEARCH
Re-checked current React form guidance, MDN constraint-validation guidance, and Dexie transaction behavior. UI-native validation can improve feedback but cannot be the authoritative domain validation boundary. Dexie read/write transactions commit or roll back as one scoped unit. Kairos already owns that boundary through `runKairosAtomicWrite()`.

## OWNER TRACE
Manual trade save orchestration is owned by `src/application/trades/saveManualTrade.ts`. Trade facts remain owned by the P9 trade domain and P9 repositories. P10.1 adds no calculation owner and no direct IndexedDB access.

## PRE-CHANGE FLOW
P9 could model, validate and persist Trade / Plan / Execution / Fee records, but there was no application command that accepted manual user input and coordinated validation, normalization and one atomic aggregate write. A UI built directly on the repositories would have violated the controlling Save Trade flow and A3.

## CHANGE
- Added `SaveManualTradeInput` and typed save outcomes.
- Added raw decimal validation/normalization before the transaction.
- Normalizes symbol/currency casing and preserves canonical decimal strings.
- Missing optional plan values remain `null`; they are never converted to zero.
- Creates stable IDs once during command preparation.
- Persists Trade + optional Plan + multiple Executions + multiple trade-level Fees in one short atomic write.
- Returns typed validation/storage failures instead of UI-facing technical exceptions.
- Added deterministic command tests for success, validation-before-write, rollback and missing-data behavior.
- Advanced app identity to `0.1.0-p10.1` while preserving DB schema V2 and backup format V2.

## NON-SCOPE
- No Manual Trade form/UI yet.
- No edit/delete/close-trade UI.
- No P&L, R-multiple, average entry, leverage or position-size calculation (P11).
- No live market/API validation.
- No event bus or dashboard invalidation.
- No schema/migration/backup-format change.
- No theme/layout changes.

## DATA / STATE FLOW
Future Trade Form -> `saveManualTrade()` -> structural/domain normalization -> `runKairosAtomicWrite()` -> Trade / Plan / Executions / Fees repositories -> commit -> typed success. Validation failure returns before transaction entry. Storage failure rolls back the aggregate.

## PERSISTENCE
Uses existing P9.2R4 DB schema V2 only. No migration. The command declares only stores required by the submitted aggregate. All required records commit or roll back together.

## SECURITY
No secret, network or remote authority surface. Raw form input remains data. Technical storage failures are collapsed to a safe typed result.

## THEME
No impact.

## OFFLINE
Fully local/offline. No network dependency added.

## TESTS
New P10.1 tests cover:
- normalized multi-record manual trade save;
- invalid decimal rejected before persistence;
- synthetic write failure rolls back all records and returns storage-error;
- missing optional financial values persist as null rather than zero.

## REGRESSION
Authoritative GitHub gate must run build, full unit suite, P1-P9 regressions, then the new P10.1 verifier.

## PERFORMANCE
No background work, observers or render-time computation. One user-triggered command performs bounded validation before one short IndexedDB transaction.

## KNOWN LIMITATIONS
Fees are trade-level in P10.1 (`executionId: null`). Execution-specific fee association can be added only when a P10 UI requirement needs it. Manual UI and post-commit route/query behavior remain later P10 substeps.

## REAL-DEVICE STATUS
Not required for this non-UI command-foundation patch.

## RESULT
HOLD pending authoritative GitHub full-gate PASS.

## NEXT
Only after PASS: audit and build the smallest Manual Trade Form subpatch wired exclusively through this command boundary.
