# KAIROS P18.56 — Chart Trend-Line Edit Endpoint-Hit Coordination

Date: 2026-09-05  
Authoritative base: **P18.55 — Lightweight Charts v5 Trend-Line Edit Endpoint Hit-Test Geometry**  
Canonical base evidence: **Kairos Controlled Roadmap Gate #266 / run 33969653539 / head 715b264133f7032d8676a145bec9e5c324873a16 — SUCCESS**  
Canonical base candidate artifact: **KAIROS_CURRENT_CANDIDATE artifact 9970637173**

## Source-derived missing seam

Canonical P18.55 establishes typed endpoint-hit evidence `{ id, endpoint }` from existing P18.5 projected geometry. Canonical P18.54 establishes authoritative selected-state + typed endpoint -> `start-editing` initiation, deliberately refusing any caller-supplied drawing identity.

Fresh canonical source search found no production composition that binds these two owners. Without that seam, a provider/UI caller could pass the endpoint from one drawing hit while P18.54 independently edits whatever drawing is currently selected. P18.56 closes only that identity-binding gap.

No new Lightweight Charts API behavior is required. P18.56 consumes already-established internal evidence and interaction contracts only, so no external provider research is required for this slice.

## P18.56 responsibility

P18.56 adds:

`coordinateChartTrendLineEditEndpointHit(interaction, hit)`

Behavior:
1. null endpoint-hit evidence is a strict no-op;
2. read current authoritative interaction state;
3. proceed only when state is `selected`;
4. require `selected.drawingId === hit.id`;
5. delegate only `hit.endpoint` to P18.54 `initiateChartTrendLineEditFromSelection`;
6. return P18.54's accepted editing state or `null` unchanged;
7. rely on P18.54's own second authoritative state read to fail closed if selection changes between identity binding and initiation.

## Ownership preservation

- P18.55 remains sole projected endpoint hit-test geometry/evidence owner.
- P18.24 remains sole active interaction state/dispatch owner.
- P18.48 remains endpoint vocabulary owner.
- P18.54 remains sole selected-state + endpoint -> edit-intent initiation coordinator.
- P18.56 owns only endpoint-hit drawing identity ↔ authoritative selected identity binding before delegation.

P18.56 does not dispatch `start-editing` itself.

## Explicit non-scope

No provider click/pointer/drag subscription; no endpoint geometry; no logical↔screen projection; no direct interaction dispatch/event ownership; no edit execution; no collection mutation; no presentation refresh; no handle rendering/style/UI; no persistence/restore; no undo/redo; no deletion changes; no new drawing kind; no Risk/Reward/P19; no journal/calculation/navigation truth; no toolchain migration.

## Focused runtime evidence

The focused P18.56 test proves:
- matching endpoint-hit identity initiates the selected drawing with the exact endpoint;
- null hit evidence is a no-op;
- a hit for another drawing can never be applied to the selected drawing;
- non-selected authoritative state is a no-op;
- if authoritative state changes between P18.56's identity check and P18.54's revalidation, initiation fails closed without dispatch.

## Canonical promotion requirement

Promotion requires exact P18.55 -> P18.56 scope, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.56 verifier/runtime, focused P18.56 tests, historical P18.55/P18.54/P18.24/P18.48 compatibility, full units, full controlled roadmap regression through P18.56, P18.56 -> P17 chart regressions, historical closures, candidate artifact, and gate evidence.


## Local/static evidence actually completed

PASS:
- dedicated P18.56 verifier;
- historical P18.55 and P18.54 ownership verifier contracts;
- all P18 verifier contracts through P18.56: **56/56**;
- all other non-P1-wrapper roadmap verifier contracts: **152/152**;
- P1 static contract: **215 source files / 17 pinned package versions**;
- exact canonical P18.55 -> P18.56 seven-file scope.

A clean dependency-backed attempt for `npm ci` -> TypeScript -> production build -> focused P18.56/P18.55/P18.54 Vitest ended in a container transport timeout during dependency installation before usable completion evidence was produced. Partial dependency/build residue was removed and is not treated as evidence. Therefore local dependency install, TypeScript, build, focused Vitest, and full P1 are **not claimed** for P18.56; canonical GitHub Actions must establish them before promotion.
