# KAIROS P18.49 — Chart Trend-Line Edit Endpoint Interaction Semantics

## Authority
Built directly from canonical P18.48, Kairos Controlled Roadmap Gate #255 / run `33959073188` / head `acab5131cb01b4191ca7b6d63435069205bd9a29`.

## Proven missing responsibility
Canonical P18.38 already requires edit/delete initiation to match the authoritative selected drawing identity, and canonical P18.48 now defines the exact provider-neutral editable trend-line endpoint vocabulary (`start | end`). However, canonical `editing` state still retained only `drawingId`, while `start-editing` intent carried only `drawingId`. A later edit mutation coordinator would therefore have to accept the endpoint as an arbitrary execution-time caller argument, recreating the same class of authority gap P18.38 removed for drawing identity.

## Added responsibility
P18.49 is a controlled amendment to the existing P18.21/P18.22/P18.23 interaction owners:

- `start-editing` now carries an explicit `ChartTrendLineEditEndpoint`;
- an accepted `editing` state preserves that exact endpoint together with the matching drawing ID;
- the reducer still accepts editing only from `selected` when `state.drawingId === event.drawingId`;
- invalid state/identity combinations remain no-ops;
- P18.24 remains the sole current-state storage/dispatch owner and requires no second edit state store.

## Ownership preserved
- P18.21 remains interaction-state shape owner; P18.49 extends that same contract.
- P18.22 remains interaction-event vocabulary owner; P18.49 extends that same contract.
- P18.23 remains sole transition-semantics owner; P18.49 extends its existing start-editing transition.
- P18.24 remains sole active interaction-state/dispatch owner.
- P18.48 remains the sole trend-line edit-endpoint vocabulary and pure edit-construction owner.
- P18.33/P18.44 remain sole committed drawing collection/mutation owner.

## Research disposition
No external API research was required. This slice is provider-neutral interaction semantics over already-canonical Kairos contracts and introduces no Lightweight Charts API behavior.

## Explicit non-scope
No provider pointer/drag subscription; no hit testing; no anchor projection; no edit construction change; no collection replacement; no edit execution; no presentation refresh; no deletion execution change; no persistence/restore; no undo/redo; no toolbar/UI styling; no new drawing kinds; no Risk/Reward/P19; no journal/calculation/navigation truth; no dependency/toolchain migration.

## Canonical requirement
Before promotion, the controlled roadmap gate must prove exact scope from canonical P18.48, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.49 verifier/runtime, historical P18.21/P18.22/P18.23/P18.24/P18.38/P18.48 compatibility, focused runtime tests, full units, full roadmap through P18.49, P18.49->P17 regressions, historical closures, candidate artifact, and gate evidence.

## Historical verifier compatibility repair
The first local regression run found that the P18.48 verifier hard-coded the exact pre-P18.49 single-line editing-state shape (`drawingId` only). P18.49 intentionally extends that same state with `endpoint`. The P18.48 verifier was minimally amended to continue asserting that authoritative editing state contains `status: editing` and `drawingId`, without forbidding later fields. No P18.48 production constructor guarantee or forbidden-boundary check was weakened.

## Local verification
PASS:
- dedicated P18.49 verifier;
- historical P18.21 interaction-state verifier;
- historical P18.22 interaction-event verifier;
- historical P18.23 interaction-reducer verifier;
- historical P18.24 interaction-port verifier;
- historical P18.38 selection interaction semantics verifier;
- historical P18.48 edit-construction verifier after the narrow compatibility repair above;
- all `verify:p18:*` scripts through P18.49 (49/49);
- all other `verify:p*` scripts except the dependency-backed `verify:p1` wrapper (152/152), for 201/201 non-P1-wrapper roadmap verifier contracts overall;
- P1 static/toolchain contract: 209 source files, 17 pinned package versions.

Local limitation:
- a clean `npm ci --no-audit --no-fund` attempt again exceeded the local execution window and was terminated/cleaned; therefore local TypeScript, production build, Vitest/full-unit, and dependency-backed P1 PASS are not claimed. Canonical GitHub Actions must establish them before promotion.
