import fs from 'node:fs';

const read = (path) => fs.readFileSync(path, 'utf8');
const fail = (message) => {
  console.error(`P18.49 chart trend-line edit endpoint interaction semantics verification FAIL: ${message}`);
  process.exit(1);
};

const stateSource = read('src/features/chart/chartDrawingInteractionContract.ts');
const eventSource = read('src/features/chart/chartDrawingInteractionEvent.ts');
const reducerSource = read('src/features/chart/chartDrawingInteractionReducer.ts');
const portSource = read('src/features/chart/chartDrawingInteractionPort.ts');
const editSource = read('src/features/chart/chartTrendLineEditConstruction.ts');
const reducerTest = read('tests/chart-drawing-interaction-reducer.test.ts');
const eventTest = read('tests/chart-drawing-interaction-event.test.ts');
const contractTest = read('tests/chart-drawing-interaction-contract.test.ts');
const selectionTest = read('tests/chart-drawing-selection-interaction.test.ts');
const packageSource = read('package.json');

for (const token of [
  "import type { ChartTrendLineEditEndpoint } from './chartTrendLineEditConstruction'",
  "readonly status: 'editing'",
  'readonly drawingId: ChartDrawingId',
  'readonly endpoint: ChartTrendLineEditEndpoint',
]) {
  if (!stateSource.includes(token)) fail(`editing state does not preserve endpoint authority: ${token}`);
}
for (const token of [
  "import type { ChartTrendLineEditEndpoint } from './chartTrendLineEditConstruction'",
  "readonly type: 'start-editing'",
  'readonly drawingId: ChartDrawingId',
  'readonly endpoint: ChartTrendLineEditEndpoint',
]) {
  if (!eventSource.includes(token)) fail(`start-editing event does not carry endpoint authority: ${token}`);
}
for (const token of [
  "case 'start-editing'",
  "state.status === 'selected'",
  'state.drawingId === event.drawingId',
  "status: 'editing'",
  'drawingId: event.drawingId',
  'endpoint: event.endpoint',
]) {
  if (!reducerSource.includes(token)) fail(`reducer does not preserve endpoint transition semantics: ${token}`);
}
if (!portSource.includes('reduceChartDrawingInteraction(currentState, event)')) {
  fail('P18.24 interaction session no longer delegates all transitions to P18.23');
}
for (const token of [
  "export type ChartTrendLineEditEndpoint = 'start' | 'end'",
  'constructChartTrendLineEdit(',
]) {
  if (!editSource.includes(token)) fail(`P18.48 edit contract regressed: ${token}`);
}
for (const [name, source] of [
  ['reducer', reducerTest],
  ['event', eventTest],
  ['contract', contractTest],
  ['selection', selectionTest],
]) {
  if (!source.includes('endpoint:')) fail(`${name} runtime contract does not pin endpoint payload/state`);
}
for (const endpoint of ["endpoint: 'start'", "endpoint: 'end'"]) {
  if (!(reducerTest + eventTest + contractTest + selectionTest).includes(endpoint)) {
    fail(`runtime tests do not cover ${endpoint}`);
  }
}
if (!packageSource.includes('verify:p18:49-chart-trend-line-edit-endpoint-interaction-semantics')) {
  fail('package verifier registration is missing');
}
for (const source of [stateSource, eventSource, reducerSource]) {
  for (const forbidden of [
    'lightweight-charts',
    'subscribeClick',
    'unsubscribeClick',
    'subscribeCrosshairMove',
    'setPointerCapture',
    'IndexedDB',
    'Dexie',
    'localStorage',
    '.put(',
    '.add(',
    '.delete(',
    'replaceDrawing(',
    'removeDrawing(',
    'riskReward',
    'risk-reward',
  ]) {
    if (source.includes(forbidden)) fail(`interaction semantics crossed protected boundary: ${forbidden}`);
  }
}

console.log('P18.49 chart trend-line edit endpoint interaction semantics verification passed.');
