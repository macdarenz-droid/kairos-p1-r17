import { useEffect, useState } from 'react';
import type { LiveMarketUniverseInstrumentMetadataAcquisitionPort } from '../services/market-data/LiveMarketUniverseInstrumentMetadataAcquisitionPort';
import type { LiveMarketUniverseInstrumentMetadataFact } from '../services/market-data/liveMarketUniverseInstrumentMetadataFact';
import type { MarketCandleHistoryPort, MarketCandleHistoryResult } from '../services/market-data/MarketCandleHistoryPort';
import { BINANCE_SPOT_CANDLE_INTERVALS } from '../services/market-data/providers/binance/binanceSpotCandleHistoryRequest';
import { BINANCE_SPOT_VENUE } from '../services/market-data/providers/binance/binanceSpotTradeStream';
import { analysisHistoryPorts } from './analysisHistoryPorts';
import { AnalysisCandleCanvas } from './AnalysisCandleCanvas';
import './analysisHistory.css';

type Ports = { readonly metadata: LiveMarketUniverseInstrumentMetadataAcquisitionPort; readonly history: MarketCandleHistoryPort };
type Metadata = { readonly phase: 'loading' | 'ready' | 'error'; readonly facts: readonly LiveMarketUniverseInstrumentMetadataFact[] };
type History = { readonly key: string; readonly result: MarketCandleHistoryResult | null; readonly timedOut?: boolean };
export const ANALYSIS_HISTORY_REQUEST_TIMEOUT_MS = 15000;

function historyFailure(result: MarketCandleHistoryResult | null, timedOut?: boolean): string {
  if (timedOut) return 'The candle request timed out. Check your connection and try again.';
  if (result && !result.ok && result.reason === 'http-error') {
    if (result.status === 429 || result.status === 418) return 'The market-data service is limiting requests. Wait before refreshing.';
    if (result.status === 403 || result.status === 451) return 'Binance Spot data is unavailable from this connection or region.';
  }
  return 'Candles are unavailable. Check your connection or try another supported symbol.';
}

/** Ephemeral Analysis selection/request lifecycle. No journal or saved-analysis writes. */
export function AnalysisHistoryWorkspace({ ports = analysisHistoryPorts }: { readonly ports?: Ports }) {
  const [metadata, setMetadata] = useState<Metadata>({ phase: 'loading', facts: [] });
  const [metadataRevision, setMetadataRevision] = useState(0);
  const [symbol, setSymbol] = useState('');
  const [interval, setTimeframe] = useState('');
  const [revision, setRevision] = useState(0);
  const [history, setHistory] = useState<History | null>(null);
  const fact = metadata.phase === 'ready' ? metadata.facts.find(item => item.instrument.symbol === symbol) : undefined;
  const key = JSON.stringify([fact?.instrument.venue, fact?.instrument.symbol, interval, revision]);
  const selected = Boolean(fact && interval);
  const current = history?.key === key ? history : null;
  const pending = selected && (!current || current.result === null && !current.timedOut);
  const snapshot = current?.result?.ok ? current.result.snapshot : null;

  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    setMetadata({ phase: 'loading', facts: [] });
    const timeout = window.setTimeout(() => {
      if (!active) return;
      active = false; controller.abort(); setMetadata({ phase: 'error', facts: [] });
    }, ANALYSIS_HISTORY_REQUEST_TIMEOUT_MS);
    void ports.metadata.acquireInstrumentMetadata({ signal: controller.signal }).then(result => {
      if (!active) return;
      window.clearTimeout(timeout);
      if (!result.ok) { setMetadata({ phase: 'error', facts: [] }); return; }
      const counts = new Map<string, number>();
      for (const item of result.facts) if (item.instrument.venue === BINANCE_SPOT_VENUE) counts.set(item.instrument.symbol, (counts.get(item.instrument.symbol) ?? 0) + 1);
      const facts = result.facts.filter(item => item.instrument.venue === BINANCE_SPOT_VENUE && item.tradingEnabled && counts.get(item.instrument.symbol) === 1).slice().sort((a, b) => a.instrument.symbol.localeCompare(b.instrument.symbol));
      setMetadata({ phase: 'ready', facts });
    }).catch(() => { if (active) { window.clearTimeout(timeout); setMetadata({ phase: 'error', facts: [] }); } });
    return () => { active = false; window.clearTimeout(timeout); controller.abort(); };
  }, [ports.metadata, metadataRevision]);

  useEffect(() => {
    if (!fact || !interval) return;
    let active = true;
    const controller = new AbortController();
    setHistory({ key, result: null });
    const timeout = window.setTimeout(() => {
      if (!active) return;
      active = false; controller.abort(); setHistory({ key, result: null, timedOut: true });
    }, ANALYSIS_HISTORY_REQUEST_TIMEOUT_MS);
    void ports.history.acquireHistory({ instrument: fact.instrument, interval, limit: 500 }, { signal: controller.signal }).then(result => {
      if (!active) return;
      window.clearTimeout(timeout);
      // A misbound port must not render a response under a different identity.
      const received = result.ok ? result.snapshot.request : null;
      if (received && (received.instrument.venue !== fact.instrument.venue || received.instrument.symbol !== fact.instrument.symbol || received.interval !== interval || received.limit !== 500 || received.startTimeMs !== undefined || received.endTimeMs !== undefined)) {
        setHistory({ key, result: { ok: false, reason: 'invalid-response', detail: 'scope-mismatch' } }); return;
      }
      setHistory({ key, result });
    }).catch(() => { if (active) { window.clearTimeout(timeout); setHistory({ key, result: { ok: false, reason: 'transport-failed' } }); } });
    return () => { active = false; window.clearTimeout(timeout); controller.abort(); };
  }, [ports.history, fact, interval, key]);

  return <section className="kairos-analysis-chart" aria-labelledby="kairos-chart-title">
    <div className="kairos-analysis-chart__heading"><h2 id="kairos-chart-title">Market chart</h2><span>Binance Spot · Historical</span></div>
    <div className="kairos-analysis-chart__selection">
      <label><span>Chart symbol</span><select aria-label="Chart symbol" value={fact ? symbol : ''} onChange={event => setSymbol(event.target.value)} disabled={metadata.phase !== 'ready' || !metadata.facts.length}>
        <option value="">Choose symbol</option>{metadata.facts.map(item => <option key={item.instrument.symbol} value={item.instrument.symbol}>{item.instrument.symbol} · {item.baseAsset}/{item.quoteAsset}</option>)}
      </select></label>
      <label><span>Timeframe</span><select aria-label="Timeframe" value={interval} onChange={event => setTimeframe(event.target.value)}><option value="">Choose timeframe</option>{BINANCE_SPOT_CANDLE_INTERVALS.map(value => <option key={value} value={value}>{value === '1M' ? '1 month' : value}</option>)}</select></label>
    </div>
    {metadata.phase === 'loading' ? <p role="status">Loading supported symbols…</p> : metadata.phase === 'error' ? <div role="alert"><p>Supported symbols are unavailable. Check your connection.</p><button type="button" onClick={() => setMetadataRevision(value => value + 1)}>Retry symbols</button></div> : !metadata.facts.length ? <p role="status">No supported symbols are available.</p> : !selected ? <div className="kairos-analysis-chart__empty"><p>Choose a symbol and timeframe to explore its candles.</p><p className="kairos-analysis-chart__note">You can use this chart without a saved trade.</p></div> : null}
    {selected ? <>
      <div className="kairos-analysis-chart__heading"><strong>{symbol} · {interval === '1M' ? '1 month' : interval}</strong><button type="button" onClick={() => setRevision(value => value + 1)} disabled={pending}>Refresh candles</button></div>
      {pending ? <p role="status" className="kairos-analysis-chart__empty">Loading candles…</p> : snapshot ? snapshot.candles.length ? <>
        <AnalysisCandleCanvas snapshot={snapshot} />
        <p className="kairos-analysis-chart__note">{snapshot.candles.length} candles · Prices in {fact?.quoteAsset} · Times in UTC</p>
        <p className="kairos-analysis-chart__note">Snapshot received {snapshot.observedAt.replace('T', ' ').replace('Z', ' UTC')}. Refresh for newer data. The final candle may be unfinished.</p>
        <details className="kairos-analysis-chart__data"><summary>Candle values</summary><div className="kairos-analysis-chart__table-scroll" tabIndex={0} role="region" aria-label="Candle values table"><table><caption>{symbol} · {interval} · UTC · {fact?.quoteAsset}</caption><thead><tr><th scope="col">Open time</th><th scope="col">Open</th><th scope="col">High</th><th scope="col">Low</th><th scope="col">Close</th></tr></thead><tbody>{snapshot.candles.map(candle => <tr key={candle.openTime}><th scope="row">{candle.openTime.replace('T', ' ').replace('.000Z', '')}</th><td>{candle.open}</td><td>{candle.high}</td><td>{candle.low}</td><td>{candle.close}</td></tr>)}</tbody></table></div></details>
      </> : <p role="status" className="kairos-analysis-chart__empty">No candles were returned for this selection.</p> : <p role="alert" className="kairos-analysis-chart__empty">{historyFailure(current?.result ?? null, current?.timedOut)}</p>}
      <p className="kairos-analysis-chart__note">Latest available page, up to 500 candles. Earlier history and continuous updates are not loaded in this view.</p>
    </> : null}
    <p className="kairos-analysis-chart__note">Market reference only. Saved trade prices and results stay separate.</p>
    <a href="https://www.tradingview.com/" target="_blank" rel="noreferrer">Charts powered by TradingView Lightweight Charts™</a>
  </section>;
}
