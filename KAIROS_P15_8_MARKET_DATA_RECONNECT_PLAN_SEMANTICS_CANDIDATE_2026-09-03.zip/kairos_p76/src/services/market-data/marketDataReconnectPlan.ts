import {
  getMarketDataReconnectDecision,
  type MarketDataReconnectPolicy,
} from './marketDataReconnectPolicy';
import { applyMarketDataReconnectFullJitter } from './marketDataReconnectJitter';

export type MarketDataReconnectPlan =
  | {
      readonly kind: 'retry';
      readonly attempt: number;
      readonly baseDelayMs: number;
      readonly delayMs: number;
    }
  | {
      readonly kind: 'stop';
      readonly reason: 'attempt-limit';
    }
  | {
      readonly kind: 'invalid';
      readonly reason: 'invalid-policy' | 'invalid-sample';
    };

export function planNextMarketDataReconnect(
  policy: MarketDataReconnectPolicy,
  attempt: number,
  sample: number,
): MarketDataReconnectPlan {
  const decision = getMarketDataReconnectDecision(policy, attempt);

  if (decision.kind === 'invalid') {
    return { kind: 'invalid', reason: 'invalid-policy' };
  }

  if (decision.kind === 'stop') {
    return { kind: 'stop', reason: 'attempt-limit' };
  }

  const jitter = applyMarketDataReconnectFullJitter(decision.delayMs, sample);

  if (!jitter.accepted) {
    return { kind: 'invalid', reason: 'invalid-sample' };
  }

  return {
    kind: 'retry',
    attempt,
    baseDelayMs: decision.delayMs,
    delayMs: jitter.delayMs,
  };
}
