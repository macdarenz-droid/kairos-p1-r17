# Kairos P8.1 Navigation Shell Patch Report — 2026-09-01

## Status
Candidate only until the complete P1–P8.1 gate passes. P7.9 remains the authoritative PASS base while this candidate is under verification.

## Objective
Create the first P8 navigation ownership layer without entering Trade Domain V1 or adding journal feature behavior.

## Research basis
- Current React Router documentation supports nested/layout routing with child content rendered through `Outlet`.
- Current React Router `NavLink` behavior supplies active-route state and `aria-current="page"` for the active destination.
- Current browser safe-area guidance uses `env(safe-area-inset-*)`; the shell therefore owns top and bottom device insets rather than individual route components.

## Controlled changes
- Added one navigation registry for primary and More destinations.
- Upgraded the existing AppShell to own header, route content, primary navigation, safe-area placement, and responsive mobile/desktop navigation presentation.
- Added real `/more` route and a minimal secondary-destination list.
- Preserved `/practice`, `/goals`, `/settings`, and `/profile` routes.
- Kept Home, Journal, Analysis, Library, and all secondary routes as placeholders only.
- Added P8.1 navigation tests and a static P8.1 verification script.
- Advanced candidate app version identity to `0.1.0-p8.1`.

## Explicit non-scope
No trade entity, trade entry form, calculations, chart data, goals behavior, Library content, persistence schema, backup format, activation authority, service-worker behavior, or database ownership changes.

## Protected behavior
- P1–P7 contracts remain unchanged.
- ActivationBootstrap still gates RouterProvider.
- Database and backup schema versions are unchanged.
- PWA/service worker and theme owners are unchanged.
- No separate MobileApp/DesktopApp product trees were introduced.

## Verification required before promotion
- deterministic install
- typecheck/build
- existing unit/regression suite
- P1 through P7 verification scripts
- P8.1 navigation-shell verification
- route/navigation tests
- responsive/static safe-area contract checks

A HOLD or FAIL leaves P7.9 authoritative.
