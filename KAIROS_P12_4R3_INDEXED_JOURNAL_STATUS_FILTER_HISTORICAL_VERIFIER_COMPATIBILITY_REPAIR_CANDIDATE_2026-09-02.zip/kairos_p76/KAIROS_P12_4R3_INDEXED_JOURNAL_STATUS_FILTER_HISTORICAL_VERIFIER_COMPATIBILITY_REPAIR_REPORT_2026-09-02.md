# KAIROS P12.4R3 — Indexed Journal Status Filter Historical Verifier Compatibility Repair

Base: P12.3R1 canonical PASS.

Purpose: preserve the P12.4R2 implementation that already passed build and 314/314 unit tests, while updating only stale historical static verifiers that incorrectly froze the *current* schema at v2.

Changes:
- P5 verifier now preserves immutable V1 and released V2 checks while accepting the current v3 schema and requiring the new `[status+updatedAt]` index.
- P9 verifier now preserves V1/V2 persistence and recovery invariants while requiring append-only V3 migration registration and the new current trade index.
- Added dedicated P12.4R3 verifier to ensure verifier compatibility without weakening migration history.
- No business logic, UI, backup format, restore semantics, database record shape, or P13 scope added.
