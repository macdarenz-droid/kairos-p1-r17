import { readFileSync } from 'node:fs';

const test = readFileSync('tests/journal-history-performance.test.tsx', 'utf8');
const historyQuery = readFileSync('src/application/journal/historyQuery.ts', 'utf8');
const repositories = readFileSync('src/data/repositories/TradeRepositories.ts', 'utf8');

const checks = [
  [test.includes('USER_HEAVY_TRADE_COUNT = 10_500'), 'USER_HEAVY fixture must contain more than 10,000 trades'],
  [test.includes('JOURNAL_PERFORMANCE_BUDGET_MS = 5_000'), 'journal performance canary must have an explicit regression budget'],
  [test.includes("screen.findByText('100 shown')"), 'first-render canary must verify the bounded 100-row UI result'],
  [test.includes("value: 'closed'"), 'filter-query canary must exercise a real status-filter transition'],
  [test.includes('firstRenderMs') && test.includes('filterQueryMs'), 'canary must track journal first render and filter-query durations'],
  [test.includes('db.trades.bulkPut(trades)'), 'heavy fixture setup must use bulk insertion rather than 10,000 serial writes'],
  [historyQuery.includes('listRecentByUpdatedAt(normalizeHistoryLimit(options.limit))'), 'unfiltered journal query must remain bounded at the repository/index owner'],
  [historyQuery.includes('listRecentByStatusAndUpdatedAt(options.status, normalizeHistoryLimit(options.limit))'), 'status filter must remain bounded at the repository/index owner'],
  [repositories.includes("orderBy('updatedAt').reverse().limit(limit).toArray()"), 'unfiltered repository query must remain index ordered and limited'],
  [repositories.includes("where('[status+updatedAt]')") && repositories.includes('.reverse()') && repositories.includes('.limit(limit)'), 'status repository query must remain compound-indexed, newest-first, and limited'],
  [!historyQuery.includes('.listAll(') && !historyQuery.includes('.filter('), 'application journal query must not regress to load-all or in-memory filtering'],
];

const failed = checks.filter(([ok]) => !ok).map(([, message]) => message);
if (failed.length) {
  console.error('P12.6 journal history heavy performance verification failed:');
  for (const message of failed) console.error(` - ${message}`);
  process.exit(1);
}

console.log('P12.6 journal history heavy performance static verification passed.');
