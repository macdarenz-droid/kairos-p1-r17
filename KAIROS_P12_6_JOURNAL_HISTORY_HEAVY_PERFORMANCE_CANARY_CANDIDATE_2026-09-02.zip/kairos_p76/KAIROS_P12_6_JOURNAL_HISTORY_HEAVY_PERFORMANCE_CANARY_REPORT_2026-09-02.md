# KAIROS P12.6 Journal History Heavy Performance Canary Report — 2026-09-02

## Status
HOLD pending canonical GitHub gate.

## Base
KAIROS_P12_5_JOURNAL_STATUS_FILTER_UI_WIRING_CANDIDATE_2026-09-02.zip — canonical PASS from gate #63.

## Objective
Add the roadmap-required USER_HEAVY performance canary for Journal History without changing production journal behavior.

## Research
Current Dexie documentation confirms that compound indexes support efficient compound-key queries and that Collection.reverse().limit() remains an indexed bounded query path. Dexie also recommends bulkPut() for large fixture insertion rather than serial put() calls.

## Owner trace
Production flow remains unchanged:
JournalRoute -> listJournalHistory() -> TradeRepository -> Dexie indexed query -> bounded evidence composition -> JournalHistoryList.

The new performance test is verification-only. It does not create a new application owner.

## Change
- Add a permanent 10,500-trade USER_HEAVY journal fixture inside the P12.6 test.
- Track journal first-render duration.
- Track a real Closed-status filter transition duration.
- Require each canary path to stay under a deliberately broad 5,000 ms regression ceiling in the canonical CI environment.
- Assert only 100 journal rows render from the 10,500-trade fixture.
- Add a static verifier that protects the indexed/bounded query path and prohibits application-level load-all/filter regressions.

## Non-scope
- No production UI changes.
- No journal query implementation changes.
- No database schema or migration changes.
- No backup/restore changes.
- No calculation changes.
- No P13 Visual P&L work.

## Persistence
No production persistence change. Test fixture setup uses Dexie bulkPut() directly only to construct USER_HEAVY efficiently.

## Performance
Canary target: USER_HEAVY = 10,500 trades.
Tracked paths:
- Journal first render.
- Indexed status filter query/render.
Regression budget: < 5,000 ms for each path in canonical GitHub CI.
Structural guards additionally require newest-first index ordering, limit(), compound [status+updatedAt], and no listAll()/application-memory filter path.

## Verification
Local static P12.6 verifier must pass before packaging. Clean dependency-backed build/unit/performance execution belongs to the canonical GitHub gate.

## Result
HOLD until canonical gate succeeds.
