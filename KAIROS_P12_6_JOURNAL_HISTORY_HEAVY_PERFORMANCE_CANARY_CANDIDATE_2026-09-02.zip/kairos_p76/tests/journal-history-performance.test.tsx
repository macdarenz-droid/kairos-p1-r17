import 'fake-indexeddb/auto';
import '@testing-library/jest-dom/vitest';
import { afterEach, describe, expect, it } from 'vitest';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { JournalRoute } from '../src/app/JournalRoute';
import { createKairosDatabase, openKairosDatabase } from '../src/data/database';
import type { DatabaseTradeRecord } from '../src/data/database/schema';
import type { TradeId, TradeStatus } from '../src/domain/trades';

const USER_HEAVY_TRADE_COUNT = 10_500;
const JOURNAL_PERFORMANCE_BUDGET_MS = 5_000;
const names = new Set<string>();
const dbName = () => { const value = `kairos-p126-heavy-${crypto.randomUUID()}`; names.add(value); return value; };

function heavyTrade(index: number): DatabaseTradeRecord {
  const statuses: readonly TradeStatus[] = ['draft', 'open', 'closed', 'cancelled'];
  const status = statuses[index % statuses.length];
  const updatedAt = new Date(Date.UTC(2026, 8, 2, 0, 0, index)).toISOString();
  const openedAt = status === 'open' || status === 'closed' ? updatedAt : null;
  const closedAt = status === 'closed' ? new Date(Date.UTC(2026, 8, 2, 0, 0, index + 1)).toISOString() : null;
  return {
    id: `trade-heavy-${index.toString().padStart(5, '0')}` as TradeId,
    symbol: `HEAVY${index.toString().padStart(5, '0')}`,
    marketType: 'crypto',
    side: index % 2 === 0 ? 'long' : 'short',
    status,
    source: 'manual',
    openedAt,
    closedAt,
    createdAt: updatedAt,
    updatedAt,
  };
}

async function seedUserHeavy(db: ReturnType<typeof createKairosDatabase>): Promise<void> {
  const trades = Array.from({ length: USER_HEAVY_TRADE_COUNT }, (_, index) => heavyTrade(index));
  await db.trades.bulkPut(trades);
}

afterEach(async () => {
  for (const name of names) {
    await new Promise<void>((resolve, reject) => {
      const request = indexedDB.deleteDatabase(name);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
      request.onblocked = () => reject(new Error('blocked'));
    });
  }
  names.clear();
});

describe('P12.6 USER_HEAVY journal performance canary', () => {
  it('keeps journal first render and indexed status filtering bounded with 10,000+ trades', async () => {
    const db = createKairosDatabase(dbName());
    await openKairosDatabase(db);
    await seedUserHeavy(db);

    const firstRenderStartedAt = performance.now();
    render(<JournalRoute db={db} />);
    expect(await screen.findByText('100 shown')).toBeInTheDocument();
    const firstRenderMs = performance.now() - firstRenderStartedAt;

    expect(firstRenderMs).toBeLessThan(JOURNAL_PERFORMANCE_BUDGET_MS);
    expect(screen.getAllByRole('article')).toHaveLength(100);

    const filter = screen.getByLabelText('Show trades');
    const filterStartedAt = performance.now();
    fireEvent.change(filter, { target: { value: 'closed' } });
    await waitFor(() => expect(filter).toHaveValue('closed'));
    await waitFor(() => expect(screen.getByText('100 shown')).toBeInTheDocument());
    await waitFor(() => expect(screen.getAllByRole('article')).toHaveLength(100));
    const filterQueryMs = performance.now() - filterStartedAt;

    expect(filterQueryMs).toBeLessThan(JOURNAL_PERFORMANCE_BUDGET_MS);
    expect(screen.getAllByText('Closed').length).toBeGreaterThanOrEqual(100);

    console.info(JSON.stringify({
      canary: 'P12.6_USER_HEAVY',
      trades: USER_HEAVY_TRADE_COUNT,
      renderedRows: 100,
      firstRenderMs: Math.round(firstRenderMs * 100) / 100,
      filterQueryMs: Math.round(filterQueryMs * 100) / 100,
      budgetMs: JOURNAL_PERFORMANCE_BUDGET_MS,
    }));

    db.close();
  });
});
