# KAIROS P18.47 — Chart Drawing Collection Presentation Drawing-Refresh Coordination

## Authority
Built directly from canonical P18.46, Kairos Controlled Roadmap Gate #253 / run 33956440408 / head `bb577bc633cb8d426277b206a84fd28397ba21dc`.

## Proven missing responsibility
Canonical P18.46 extends the existing P18.11/P18.20 presentation owner with `replaceDrawings(drawings)` so committed drawing mutations can refresh drawing presentation without tearing down the active market series. However, canonical P18.37 remains the sole committed-collection -> presentation coordinator and still exposes only the full `replace(series, drawings)` path. Without extending P18.37, later mutation flows would have to duplicate `collection.getDrawings()` -> P18.36 projection -> P18.46 drawing-only refresh outside the existing coordination owner.

## Added responsibility
P18.47 adds one controlled extension inside the existing P18.37 collection-to-presentation coordination module:

- `refreshChartDrawingPresentationFromCollection(presentation, collection)` reads exactly one authoritative committed collection snapshot;
- it delegates domain drawing -> renderer drawing projection to existing P18.36 `projectChartDrawings`;
- it delegates presentation to P18.46 `replaceDrawings` on an already-active presentation session;
- an empty committed collection refreshes as an empty renderer drawing snapshot;
- a destroyed collection fails before any presentation refresh call.

The original P18.37 `replaceChartDrawingPresentationFromCollection(presentation, series, collection)` path remains unchanged for initial/full presentation.

## Ownership preserved
- P18.33/P18.44 remain the sole committed drawing collection/mutation owner.
- P18.2/P18.36 remain the sole domain drawing -> renderer projection owner.
- P18.11/P18.20/P18.46 remain the sole presentation/hover resource-order owner.
- P18.37 remains the sole committed collection -> presentation coordination seam; P18.47 extends that same module rather than adding a second coordinator owner.
- P18.45 remains deletion execution coordination.
- P18.23/P18.24/P18.38 remain interaction transition/current-state owners.

## Research disposition
No external API research was required. This slice is provider-neutral composition of already-canonical Kairos owners and introduces no new Lightweight Charts API surface.

## Explicit non-scope
No committed drawing mutation; no deletion execution; no edit construction/gesture; no interaction event/reducer/dispatch change; no provider subscription or primitive API; no series creation/removal; no persistence/restore; no undo/redo; no toolbar/UI selection styling; no new drawing kinds; no Risk/Reward/P19; no journal/calculation/navigation truth; no dependency/toolchain migration.

## Canonical requirement
Before promotion, the controlled roadmap gate must prove exact scope from canonical P18.46, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.47 runtime/verifier, historical P18.37/P18.46 compatibility, focused runtime tests, full units, full roadmap through P18.47, P18.47->P17 regressions, historical closures, candidate artifact, and gate evidence.

## Local verification
PASS:
- dedicated P18.47 verifier;
- historical P18.37 collection-presentation coordination verifier;
- P18.46 drawing-only presentation refresh verifier;
- P18.45 deletion coordination verifier;
- all `verify:p18:*` scripts through P18.47 (47/47);
- all other `verify:p*` scripts except the clean-install `verify:p1` wrapper (152/152), for 199/199 non-P1-wrapper roadmap verifier contracts overall;
- P1 static/toolchain contract: 208 source files, 17 pinned package versions.

Local limitation:
- clean `npm ci` again exceeded the local execution window, so local TypeScript, production build, Vitest/full-unit, and the dependency-backed P1 gate are not claimed. Canonical GitHub Actions must establish them before promotion.
