import { readFileSync } from 'node:fs';

const production = readFileSync('src/features/chart/chartTrendLineEditPresentationCoordination.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const tests = readFileSync('tests/chart-trend-line-edit-presentation-coordination.test.ts', 'utf8');
const presentationPort = readFileSync('src/features/chart/chartDrawingPresentationPort.ts', 'utf8');
const projection = readFileSync('src/features/chart/chartDrawingProjection.ts', 'utf8');
const historicalRefreshTests = readFileSync('tests/chart-drawing-collection-presentation-drawing-refresh-coordination.test.ts', 'utf8');

function fail(message) {
  console.error(`P18.51R3 verification failed: ${message}`);
  process.exit(1);
}

for (const token of [
  'executeChartTrendLineEditAndRefreshPresentation(',
  'executeChartTrendLineEdit(interaction, collection, anchor)',
  'if (edited === null) return null;',
  'refreshChartDrawingPresentationFromCollection(presentation, collection)',
  'return edited;',
]) {
  if (!production.includes(token)) fail(`production coordination missing token: ${token}`);
}

for (const forbidden of [
  'collection.replaceDrawing(',
  'collection.removeDrawing(',
  'interaction.dispatch(',
  "type: 'start-editing'",
  'projectChartDrawings(',
  'presentation.replaceDrawings(',
  'lightweight-charts',
  'subscribeClick(',
  'subscribeCrosshairMove(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'riskReward',
]) {
  if (production.includes(forbidden)) fail(`production coordination leaked protected ownership: ${forbidden}`);
}

if (!index.includes("export { executeChartTrendLineEditAndRefreshPresentation } from './chartTrendLineEditPresentationCoordination';")) {
  fail('chart index production export missing');
}

if (!presentationPort.includes('export interface ChartDrawingPresentationDrawingRefreshSession')) {
  fail('P18.46 drawing-refresh session owner missing');
}

if (!projection.includes('export function projectChartDrawings(')) {
  fail('P18.36 renderer projection owner missing');
}

if (!tests.includes("from '../src/features/chart/chartDrawingPresentationPort';")) {
  fail('focused test must import drawing-refresh session type directly from its owner module');
}

if (index.includes('ChartDrawingPresentationDrawingRefreshSession')) {
  fail('repair must not expand public chart barrel solely for a test-only type import');
}

if (tests.includes('ReturnType<typeof vi.fn>')) {
  fail('focused test must not widen vi.fn through overloaded ReturnType');
}

if (!tests.includes('function presentation(replaceDrawings = vi.fn()): ChartDrawingPresentationDrawingRefreshSession')) {
  fail('focused test must use the canonical-safe inferred callable vi.fn helper pattern');
}

if (!historicalRefreshTests.includes('function presentation(replaceDrawings = vi.fn()): ChartDrawingPresentationDrawingRefreshSession')) {
  fail('historical P18.47 canonical-safe mock helper evidence missing');
}

for (const token of [
  'start: { time: 1788606000, value: 100.25 }',
  'end: { time: 1788606240, value: 105.25 }',
  'start: { time: 1788606120, value: 102.25 }',
  'end: { time: 1788606180, value: 103.75 }',
]) {
  if (!tests.includes(token)) fail(`focused success-path renderer expectation missing: ${token}`);
}

for (const token of [
  'refreshes current committed drawing presentation exactly once after a successful edit',
  'does not refresh presentation when authoritative interaction state does not execute an edit',
  'does not refresh presentation for a stale authoritative edit target',
  'never rolls back committed edit truth when presentation refresh fails',
]) {
  if (!tests.includes(token)) fail(`focused runtime test missing case: ${token}`);
}

console.log('P18.51R3 chart trend-line edit presentation coordination runtime projection expectation repair verification passed.');
