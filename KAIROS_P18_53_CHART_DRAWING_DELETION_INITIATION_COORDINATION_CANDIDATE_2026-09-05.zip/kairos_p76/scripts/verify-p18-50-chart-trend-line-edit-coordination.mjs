import { readFileSync } from 'node:fs';

const sourcePath = 'src/features/chart/chartTrendLineEditCoordination.ts';
const indexPath = 'src/features/chart/index.ts';
const packagePath = 'package.json';
const testPath = 'tests/chart-trend-line-edit-coordination.test.ts';

const source = readFileSync(sourcePath, 'utf8');
const index = readFileSync(indexPath, 'utf8');
const pkg = JSON.parse(readFileSync(packagePath, 'utf8'));
const test = readFileSync(testPath, 'utf8');

const requiredSource = [
  'executeChartTrendLineEdit(',
  "if (state.status !== 'editing') return null;",
  'collection.getDrawing(state.drawingId)',
  'constructChartTrendLineEdit(drawing, state.endpoint, anchor)',
  'collection.replaceDrawing(state.drawingId, edited)',
  "interaction.dispatch({ type: 'reset-interaction' })",
  "throw new Error('chart-trend-line-edit-reset-rejected')",
];
for (const token of requiredSource) {
  if (!source.includes(token)) throw new Error(`P18.50 source token missing: ${token}`);
}

const forbiddenSource = [
  'start-editing',
  'subscribeClick',
  'subscribeCrosshairMove',
  'subscribeMouse',
  'subscribePointer',
  'replaceDrawings(',
  'refreshChartDrawingPresentationFromCollection',
  'lightweight-charts',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'riskReward',
];
for (const token of forbiddenSource) {
  if (source.includes(token)) throw new Error(`P18.50 ownership leakage: ${token}`);
}

if (!index.includes("export { executeChartTrendLineEdit } from './chartTrendLineEditCoordination';")) {
  throw new Error('P18.50 index export missing');
}

const scriptName = 'verify:p18:50-chart-trend-line-edit-coordination';
if (pkg.scripts?.[scriptName] !== 'node scripts/verify-p18-50-chart-trend-line-edit-coordination.mjs') {
  throw new Error('P18.50 package verifier registration missing');
}

for (const testName of [
  'edits exactly the authoritative endpoint and resets interaction after committed replacement',
  'uses the authoritative editing endpoint rather than accepting an execution-time endpoint argument',
  'does not initiate editing from selected state',
  'fails closed when authoritative editing state points at a stale committed identity',
]) {
  if (!test.includes(testName)) throw new Error(`P18.50 runtime test missing: ${testName}`);
}

console.log('PASS P18.50 chart trend-line edit coordination verifier');
