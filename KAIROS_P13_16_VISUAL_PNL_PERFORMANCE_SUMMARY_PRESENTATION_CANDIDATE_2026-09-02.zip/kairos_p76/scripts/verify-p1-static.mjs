import { readFile, readdir } from 'node:fs/promises';
import { extname, join, relative } from 'node:path';

const root = new URL('../', import.meta.url);
const packageJson = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));
const allVersions = [...Object.values(packageJson.dependencies ?? {}), ...Object.values(packageJson.devDependencies ?? {})];
if (allVersions.some((version) => version === 'latest' || /^[~^]/.test(version))) {
  throw new Error('P1 dependencies must be pinned exactly for reproducible verification.');
}
if (packageJson.scripts?.['verify:doctor'] !== 'node scripts/p1-environment-doctor.mjs') {
  throw new Error('P1 environment doctor must have one package script owner.');
}
if (packageJson.scripts?.['verify:toolchain'] !== 'node scripts/verify-p1-toolchain.mjs') {
  throw new Error('P1 toolchain verification must have one package script owner.');
}
if (packageJson.scripts?.['release:p1'] !== 'node scripts/run-p1-release-gate.mjs') {
  throw new Error('P1 one-command release gate must have one package script owner.');
}
if (packageJson.scripts?.['verify:p1'] !== 'npm run verify:toolchain && npm run verify:static && npm run verify:gate') {
  throw new Error('P1 portable verification must have one package script owner.');
}
if (!packageJson.devDependencies?.['@testing-library/dom']) {
  throw new Error('React Testing Library v16 requires @testing-library/dom.');
}

const requiredFiles = [
  'scripts/verify-p1-gate.mjs',
  'scripts/p1-gate-result.mjs',
  'scripts/test-p1-gate-result.mjs',
  'scripts/p1-environment-doctor.mjs',
  'scripts/resolve-p1-lock.mjs',
  'scripts/verify-p1-lock.mjs',
  'scripts/run-p1-release-gate.mjs',
  'scripts/test-p1-lock-verifier.mjs',
  'scripts/verify-p1-toolchain.mjs',
  '.github/workflows/p1-gate.yml',
  '.gitignore',
  'src/main.tsx',
  'src/app/router.tsx',
  'src/app/routes.tsx',
  'src/app/ErrorBoundary.tsx',
  'src/diagnostics/DiagnosticsService.ts',
  'src/testing/setup.ts',
  'tests/diagnostics.test.ts',
  'tests/router.test.tsx',
  'tests/error-boundary.test.tsx',
];
for (const file of requiredFiles) await readFile(new URL(`../${file}`, import.meta.url));

const routerSource = await readFile(new URL('../src/app/router.tsx', import.meta.url), 'utf8');
const routerTestSource = await readFile(new URL('../tests/router.test.tsx', import.meta.url), 'utf8');
if (!/createBrowserRouter\(appRoutes\)/.test(routerSource) || !/createMemoryRouter\(appRoutes/.test(routerTestSource)) {
  throw new Error('Production and test routers must consume the same appRoutes owner.');
}

const shellCss = await readFile(new URL('../src/shell.css', import.meta.url), 'utf8');
if (/#[0-9a-f]{3,8}\b|\brgb\(|\bhsl\(|font-family|padding|border-radius|box-shadow/i.test(shellCss)) {
  throw new Error('P1 shell CSS must remain presentation-neutral; visual tokens belong to P2.');
}

async function walk(dirUrl) {
  const entries = await readdir(dirUrl, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const child = new URL(`${entry.name}${entry.isDirectory() ? '/' : ''}`, dirUrl);
    if (entry.isDirectory()) files.push(...await walk(child));
    else files.push(child);
  }
  return files;
}

const sourceFiles = await walk(new URL('../src/', import.meta.url));
const forbiddenBusinessTerms = /\b(decimal\.js|dexie|indexeddb|websocket|tradeexecution|trademetrics|marketdata|serviceworker|localstorage|sessionstorage)\b/i;
const approvedPresentationStorageOwners = new Set([
  'src/design-system/themes/themePreference.ts',
]);
const approvedPwaInfrastructureOwners = new Set([
  'src/pwa/serviceWorkerRegistration.ts',
]);
const approvedDatabaseInfrastructurePrefix = 'src/data/database/';
const approvedCalculationDomainPrefix = 'src/domain/calculations/';
const approvedVisualPnlApplicationPrefix = 'src/application/visual-pnl/';
for (const fileUrl of sourceFiles) {
  if (!['.ts', '.tsx', '.css'].includes(extname(fileUrl.pathname))) continue;
  const text = await readFile(fileUrl, 'utf8');
  const relativePath = relative(root.pathname, fileUrl.pathname);
  if (
    forbiddenBusinessTerms.test(text)
    && !approvedPresentationStorageOwners.has(relativePath)
    && !approvedPwaInfrastructureOwners.has(relativePath)
    && !relativePath.startsWith(approvedDatabaseInfrastructurePrefix)
    && !relativePath.startsWith(approvedCalculationDomainPrefix)
    && !relativePath.startsWith(approvedVisualPnlApplicationPrefix)
  ) {
    throw new Error(`P1 scope leak detected in ${relativePath}.`);
  }
}

const visualPnlApplicationSourceFiles = sourceFiles.filter((fileUrl) =>
  relative(root.pathname, fileUrl.pathname).startsWith(approvedVisualPnlApplicationPrefix),
);
for (const fileUrl of visualPnlApplicationSourceFiles) {
  const text = await readFile(fileUrl, 'utf8');
  const relativePath = relative(root.pathname, fileUrl.pathname);
  const visualPnlForbiddenInfrastructureTerms = /\b(decimal\.js|dexie|indexeddb|websocket|marketdata|serviceworker|localstorage|sessionstorage|tradeexecution)\b/i;
  if (visualPnlForbiddenInfrastructureTerms.test(text)) {
    throw new Error(`P13 Visual P&L application ownership leak detected in ${relativePath}.`);
  }
}

const calculationSourceFiles = sourceFiles.filter((fileUrl) =>
  relative(root.pathname, fileUrl.pathname).startsWith(approvedCalculationDomainPrefix),
);
for (const fileUrl of calculationSourceFiles) {
  const text = await readFile(fileUrl, 'utf8');
  const relativePath = relative(root.pathname, fileUrl.pathname);
  const calculationForbiddenTerms = /\b(dexie|indexeddb|websocket|marketdata|serviceworker|localstorage|sessionstorage)\b/i;
  if (calculationForbiddenTerms.test(text)) {
    throw new Error(`P11 calculation-domain ownership leak detected in ${relativePath}.`);
  }
}

const themePreferenceSource = await readFile(
  new URL('../src/design-system/themes/themePreference.ts', import.meta.url),
  'utf8',
);
const themePreferenceForbiddenTerms = /\b(decimal\.js|dexie|indexeddb|websocket|tradeexecution|trademetrics|marketdata|serviceworker|sessionstorage)\b/i;
if (themePreferenceForbiddenTerms.test(themePreferenceSource)) {
  throw new Error('Theme preference storage owner may only use localStorage for presentation preference persistence.');
}
if (!/window\.localStorage/.test(themePreferenceSource)) {
  throw new Error('Approved theme preference owner must remain the single localStorage presentation preference adapter.');
}

const serviceWorkerRegistrationSource = await readFile(
  new URL('../src/pwa/serviceWorkerRegistration.ts', import.meta.url),
  'utf8',
);
const pwaForbiddenTerms = /\b(decimal\.js|dexie|indexeddb|websocket|tradeexecution|trademetrics|marketdata|localstorage|sessionstorage)\b/i;
if (pwaForbiddenTerms.test(serviceWorkerRegistrationSource)) {
  throw new Error('PWA service-worker registration owner may only manage service-worker lifecycle infrastructure.');
}
if (!/navigator\.serviceWorker\.register/.test(serviceWorkerRegistrationSource)) {
  throw new Error('Approved PWA infrastructure owner must remain the single service-worker registration adapter.');
}

const databaseSourceFiles = sourceFiles.filter((fileUrl) => relative(root.pathname, fileUrl.pathname).startsWith(approvedDatabaseInfrastructurePrefix));
for (const fileUrl of databaseSourceFiles) {
  const text = await readFile(fileUrl, 'utf8');
  const relativePath = relative(root.pathname, fileUrl.pathname);
  const databaseForbiddenTerms = /\b(decimal\.js|websocket|tradeexecution|trademetrics|marketdata|serviceworker|localstorage|sessionstorage)\b/i;
  if (databaseForbiddenTerms.test(text)) {
    throw new Error(`P5 database infrastructure scope leak detected in ${relativePath}.`);
  }
}

console.log('P1 static contract: PASS');
console.log(`Checked ${sourceFiles.length} source files and ${allVersions.length} pinned package versions.`);
