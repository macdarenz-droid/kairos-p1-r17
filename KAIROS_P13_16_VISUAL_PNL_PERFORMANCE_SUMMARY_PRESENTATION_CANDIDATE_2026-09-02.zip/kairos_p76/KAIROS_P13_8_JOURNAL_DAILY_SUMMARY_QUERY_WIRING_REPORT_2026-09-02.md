# KAIROS PATCH REPORT

Patch: P13.8 — Journal Daily Visual P&L Query Wiring
Base: P13.7 canonical PASS, Run #84, gate SHA cc690e20bfc8ac850b1194028b9de88024d2a5e2

## OBJECTIVE
Expose P13.7 daily Visual P&L composition through a bounded Journal application query without adding a second database, calculation, timezone, or presentation owner.

## OWNERSHIP TRACE
- Journal History remains the only database selection/hydration owner.
- Existing status+updatedAt repository index selects closed trades.
- Existing Journal History limit remains the bound and is validated before child hydration.
- P13.6 remains the closedAt + explicit timezone day-key owner.
- P13.7 remains the grouping and aggregate-composition owner.
- P13.8 only composes these owners into a Journal-facing consumer query.

## CHANGE
- Add listJournalVisualPnlDailySummary(db, timeZone, options).
- Force the existing Journal History query to status='closed'.
- Preserve optional bounded limit; default remains the existing Journal History default.
- Delegate returned entries directly to summarizeVisualPnlByDay.
- Export the contract from application/journal.
- Add integration tests for explicit timezone, closed-only selection, bounded limit, invalid-limit rejection, and invalid-zone no-fallback behavior.

## NON-SCOPE
No UI/calendar/heatmap, no timezone preference persistence, no DB schema/index change, no unbounded scan, no financial arithmetic, no FX, no theme change.

## PERFORMANCE
No new database path. Selection still uses the existing indexed status + updatedAt query and applies the Journal History bound before child evidence hydration. P13.7 then operates over that bounded result.

## RESULT
HOLD pending canonical GitHub gate.

## NEXT
Only after PASS: define the first accessible calendar/heatmap presentation contract against this query, while keeping unavailable/mixed-currency days explicit and never relying on color alone.
