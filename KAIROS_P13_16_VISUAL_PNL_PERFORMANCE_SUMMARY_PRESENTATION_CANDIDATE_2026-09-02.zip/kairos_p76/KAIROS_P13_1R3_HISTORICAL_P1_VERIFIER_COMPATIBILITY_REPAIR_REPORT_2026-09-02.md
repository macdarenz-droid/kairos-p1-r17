# KAIROS P13.1R3 Historical P1 Verifier Compatibility Repair Report

## Patch
P13.1R3 — Historical P1 Verifier Compatibility Repair

## Base
Canonical PASS base: P12.7R2 Journal History Closure Async Wait Repair.

## Objective
Preserve the already-green P13.1 Visual P&L outcome projection implementation and test contract while repairing the historical P1 static verifier so that it recognizes the legitimate later-phase `src/application/visual-pnl/` application boundary without weakening P1 infrastructure/business ownership protections.

## Canonical failure evidence addressed
P13.1R2 canonical Run #72 passed exact scope, deterministic install, production build, and the full 324-test unit suite. The subsequent historical verifier chain failed at `verify:p1` because `verify-p1-static.mjs` treated the `TradeMetrics` type import in `src/application/visual-pnl/outcomeProjection.ts` as a P1 scope leak.

## Owner trace
- Financial truth remains owned by P11 `TradeMetrics` and decimal-domain owners.
- P13 Visual P&L remains an application projection consumer only.
- P13 performs no financial aggregation, fee composition, FX conversion, or storage access.
- P1 verifier remains the historical guard for shell/toolchain/infrastructure scope.

## Change
1. Preserve P13.1R2 production projection unchanged.
2. Preserve P13.1R2 corrected tests unchanged.
3. Add one narrow historical P1 verifier compatibility prefix for `src/application/visual-pnl/`.
4. Add a dedicated secondary P1 guard over that prefix that still rejects direct `decimal.js`, Dexie/IndexedDB, websocket/market-data, service-worker, local/session storage, and `TradeExecution` ownership.
5. Extend the P13 verifier to assert that this narrow historical compatibility repair remains present and guarded.

## Non-scope
No trade calculation changes. No P11 changes. No database/schema/query changes. No UI wiring. No theme changes. No FX conversion. No daily aggregation. No P13.2 feature expansion.

## Data flow
Persisted evidence -> P12 indexed Journal History query -> P11 `TradeMetrics` composition -> P13 Visual P&L outcome projection.

## Persistence
No persistence changes.

## Security
No secret, network, or executable-content changes.

## Theme / accessibility
No presentation change. Existing P13 projection retains explicit text semantics (`Profit`, `Loss`, `Break-even`, `Not available`) so color is not the sole carrier of outcome meaning.

## Offline
No change; projection remains local-only.

## Tests / regression
Expected canonical gate:
- exact controlled scope
- deterministic install
- production build
- full unit regression
- full roadmap verifier chain including repaired `verify:p1`
- focused P13 verifier/test
- P12 closure integration
- USER_HEAVY 10,500-trade bounded-query canary

## Performance
No new renderer, observer, DB query, loop over journal data, or arithmetic owner. Historical verifier-only compatibility change has no runtime impact.

## Known limitations
Visual P&L remains per-trade semantic projection only. Day-level aggregation/heatmap/equity visuals are not part of this repair.

## Real-device status
Not applicable to this non-UI foundation repair.

## Result
Candidate ready for canonical gate. PASS/HOLD/FAIL is determined only by GitHub gate evidence.

## Next
If and only if canonical P13.1R3 passes, promote it as the authoritative base and continue to the next dependency-ordered P13 Visual P&L slice.
