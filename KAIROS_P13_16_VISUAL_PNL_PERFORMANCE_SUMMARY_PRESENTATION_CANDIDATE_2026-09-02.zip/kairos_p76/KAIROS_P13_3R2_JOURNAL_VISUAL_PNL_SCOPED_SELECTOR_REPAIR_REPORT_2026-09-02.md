# Kairos P13.3R2 — Journal Visual P&L Scoped Selector Repair

## Status
Candidate repair prepared after canonical Run #77 failed one presentation test because `screen.getByText('Not available')` matched multiple legitimate elements.

## Controlled repair
- Production code is unchanged from P13.3R1.
- Preserves `plans: []` in the typed `JournalHistoryEntry` fixture.
- Replaces the ambiguous global label lookup in the parameterized outcome test with a selector scoped to the authoritative `[data-outcome="<kind>"]` presentation element.
- Retains explicit assertions for outcome label, non-color mark, and amount text.
- Adds a dedicated verifier preventing regression to the ambiguous selector.

## Ownership / safety
No calculation, persistence, database, routing, currency, FX, or financial arithmetic changes.
P13.2 remains authoritative until this repair passes the canonical gate.
