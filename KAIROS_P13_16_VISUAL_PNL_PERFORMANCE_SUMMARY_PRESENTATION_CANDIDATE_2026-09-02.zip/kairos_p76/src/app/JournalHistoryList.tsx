import type { JournalHistoryEntry } from '../application/journal';
import type { TradeStatus } from '../domain/trades';

interface JournalHistoryListProps {
  readonly entries: readonly JournalHistoryEntry[];
  readonly isLoading: boolean;
  readonly errorMessage: string | null;
  readonly statusFilter: TradeStatus | '';
  readonly onStatusFilterChange: (status: TradeStatus | '') => void;
}

function statusLabel(status: JournalHistoryEntry['trade']['status']): string {
  if (status === 'draft') return 'Draft';
  if (status === 'open') return 'Open';
  if (status === 'closed') return 'Closed';
  return 'Cancelled';
}

function sideLabel(side: JournalHistoryEntry['trade']['side']): string {
  return side === 'long' ? 'Long' : 'Short';
}

function visualPnlAmount(entry: JournalHistoryEntry): string {
  const { visualPnl } = entry;
  if (visualPnl.amount === null) return 'Not available';
  return visualPnl.currency ? `${visualPnl.amount} ${visualPnl.currency}` : visualPnl.amount;
}

function formatTimestamp(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(date);
}

export function JournalHistoryList({ entries, isLoading, errorMessage, statusFilter, onStatusFilterChange }: JournalHistoryListProps) {
  return (
    <section className="kairos-history" aria-labelledby="kairos-history-title" aria-busy={isLoading || undefined}>
      <div className="kairos-history__heading">
        <div>
          <p className="kairos-journal__eyebrow">Saved locally</p>
          <h2 id="kairos-history-title">Trade history</h2>
        </div>
        <span className="kairos-history__count">{entries.length} shown</span>
      </div>

      <div className="kairos-history__controls">
        <label className="kairos-field kairos-history__filter" htmlFor="kairos-history-status-filter">
          <span>Show trades</span>
          <select
            id="kairos-history-status-filter"
            name="historyStatusFilter"
            value={statusFilter}
            onChange={(event) => onStatusFilterChange(event.target.value as TradeStatus | '')}
          >
            <option value="">All trades</option>
            <option value="draft">Draft</option>
            <option value="open">Open</option>
            <option value="closed">Closed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </label>
      </div>

      {errorMessage ? <p className="kairos-history__state kairos-history__state--error" role="alert">{errorMessage}</p> : null}
      {isLoading ? <p className="kairos-history__state" aria-live="polite">Loading trade history…</p> : null}
      {!isLoading && !errorMessage && entries.length === 0 ? (
        <p className="kairos-history__state">
          {statusFilter === '' ? 'No saved trades yet. Your first saved trade will appear here.' : `No ${statusLabel(statusFilter).toLowerCase()} trades found.`}
        </p>
      ) : null}

      {!isLoading && !errorMessage && entries.length > 0 ? (
        <ol className="kairos-history__list">
          {entries.map((entry) => {
            const timestamp = entry.trade.closedAt ?? entry.trade.openedAt ?? entry.trade.updatedAt;
            return (
              <li className="kairos-history-card" key={entry.trade.id}>
                <div className="kairos-history-card__topline">
                  <strong>{entry.trade.symbol}</strong>
                  <span>{sideLabel(entry.trade.side)}</span>
                  <span>{statusLabel(entry.trade.status)}</span>
                </div>
                <time dateTime={timestamp}>{formatTimestamp(timestamp)}</time>
                <div className={`kairos-history-card__outcome kairos-history-card__outcome--${entry.visualPnl.outcome}`} data-outcome={entry.visualPnl.outcome}>
                  <span className="kairos-history-card__outcome-mark" aria-hidden="true">{entry.visualPnl.outcome === 'profit' ? '▲' : entry.visualPnl.outcome === 'loss' ? '▼' : entry.visualPnl.outcome === 'breakeven' ? '—' : '·'}</span>
                  <span>{entry.visualPnl.label}</span>
                  <strong>{visualPnlAmount(entry)}</strong>
                </div>
                <dl className="kairos-history-card__facts">
                  <div><dt>Executions</dt><dd>{entry.executions.length}</dd></div>
                  <div><dt>Fees</dt><dd>{entry.fees.length}</dd></div>
                  <div><dt>Gross P&amp;L</dt><dd>{entry.metrics?.grossPnl ?? 'Not available'}</dd></div>
                  <div><dt>Net P&amp;L</dt><dd>{entry.metrics?.netPnl ?? 'Not available'}</dd></div>
                </dl>
                {entry.metricsError ? <p className="kairos-history-card__notice">Some performance values are unavailable for this trade.</p> : null}
              </li>
            );
          })}
        </ol>
      ) : null}
    </section>
  );
}
