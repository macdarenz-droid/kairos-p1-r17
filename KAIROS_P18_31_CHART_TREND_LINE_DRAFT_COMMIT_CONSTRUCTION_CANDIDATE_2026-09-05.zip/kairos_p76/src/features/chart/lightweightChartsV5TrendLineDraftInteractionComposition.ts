import type { ChartEngineSeriesHandle } from './chartEngineDriver';
import type { ChartDrawingInteractionStateListener } from './chartDrawingInteractionPort';
import {
  createChartTrendLineDraftInteractionPort,
  type ChartTrendLineDraftInteractionSession,
} from './chartTrendLineDraftInteractionCoordination';
import { createLightweightChartsV5DrawingClickSubscriptionFromBinding } from './lightweightChartsV5DrawingClickBindingComposition';
import type { LightweightChartsV5DrawingClickSubscription } from './lightweightChartsV5DrawingClickSubscription';
import type { LightweightChartsV5DriverBinding } from './lightweightChartsV5ModuleAdapter';

/**
 * P18.30 Lightweight Charts v5 trend-line draft interaction composition.
 *
 * This boundary owns only lifecycle composition between the already-authoritative
 * provider click binding (P18.27) and provider-neutral trend-line draft
 * interaction session (P18.29). Provider clicks are forwarded as neutral anchor
 * evidence to P18.29; all interaction state, transition semantics, and draft
 * anchor storage remain owned by P18.24/P18.23/P18.28R1 through P18.29.
 *
 * Provider subscription setup failure destroys the just-created neutral session
 * before rethrowing. destroy() detaches provider click delivery before destroying
 * the neutral session and is idempotent through the composed owners.
 *
 * No provider subscribe/unsubscribe API is reimplemented here. No coordinate
 * conversion, drawing ID allocation, committed drawing construction/mutation,
 * persistence, toolbar/UI state, selection, drag/edit/delete execution, undo/redo,
 * new drawing kinds, journal truth, or P19 Risk/Reward behavior lives here.
 */
export function createLightweightChartsV5TrendLineDraftInteractionFromBinding(
  binding: Pick<LightweightChartsV5DriverBinding, 'resolveChart' | 'resolveSeries'>,
  handle: ChartEngineSeriesHandle,
  onStateChange: ChartDrawingInteractionStateListener,
): ChartTrendLineDraftInteractionSession {
  const draftInteraction = createChartTrendLineDraftInteractionPort().create(onStateChange);

  let clickSubscription: LightweightChartsV5DrawingClickSubscription;
  try {
    clickSubscription = createLightweightChartsV5DrawingClickSubscriptionFromBinding(
      binding,
      handle,
      (anchor) => {
        draftInteraction.acceptAnchor(anchor);
      },
    );
  } catch (error) {
    draftInteraction.destroy();
    throw error;
  }

  let destroyed = false;

  return {
    getState() {
      return draftInteraction.getState();
    },
    getAnchors() {
      return draftInteraction.getAnchors();
    },
    dispatch(event) {
      return draftInteraction.dispatch(event);
    },
    acceptAnchor(anchor) {
      return draftInteraction.acceptAnchor(anchor);
    },
    destroy(): void {
      if (destroyed) return;
      destroyed = true;
      clickSubscription.destroy();
      draftInteraction.destroy();
    },
  };
}
