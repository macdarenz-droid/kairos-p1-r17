# KAIROS P29.2 — Real-Result Isolation

**Patch label:** P29.2 · P29 Practice foundation: paper trades · owner phase P29 (active from the Gate508 canonical PASS) · definition: the explicit source scope on the one released history seam so practice trades never enter real results, applied by the repository on the released indexed path.

## Authority
Base: canonical Gate509 (P29.1 practice trade command). Autonomous continuation under the user's 18 September 2026 rule.

## Research settled before implementation
- `listJournalHistory` (P12) is the only history seam behind the Journal history, Home Your Trades, the P13 daily results, the P26 Goals progress and the trade review selection; every consumer calls it, so one scope there isolates all of them.
- The P12 verifiers pin the application query to the repository's indexed newest-first bounded paths and forbid application-side filtering and load-all; adding a `[source+…]` index would bump the P5 schema and the P6 backup contract. The scope is therefore applied by a read-only repository view (`SourceScopedTradeRepository`) that walks the same `updatedAt` and `[status+updatedAt]` indexes newest-first, skips records outside the scope as the cursor passes them, and stops at the released bound: index order, bound and the pinned query literals are unchanged.
- Exact-id review (`getJournalHistoryEntry`) stays unscoped: an identity read must not silently fail, and the entry carries its `source`.

## Result
`JournalHistoryScope` (`real` | `practice`), `JOURNAL_HISTORY_SOURCES` (real: `manual`, `import`, `broker-import`; practice: `paper`, `replay`) and the optional `scope` on `JournalHistoryQueryOptions` (default `real`); `TradeRepository.scopedBySource(sources)` returning the scoped view. Every released consumer keeps its lines and now reads real trades only. Unit tests prove the source sets, the default and requested scopes with the status and limit paths, the unscoped exact-id read, and that a practice trade appears in none of the daily results, Home Your Trades, Goals progress or trade review selection. The Gate508 (P28.4) and Gate509 (P29.1) verifier pins that asserted the seam carried no source literal advanced to the scope literal; nothing was relaxed. UI VISIBLE:NO.

## Ownership
P29.2 owns only the scope contract and the scoped repository view. P12 keeps the seam, hydration and bound; P5 keeps the store and indexes; P29.1 keeps the practice write.

## Non-scope
No route (P29.3). No index or schema change. No change to exact-id review. No consumer line changed.

## Next dependency boundary
P29.3 mounts the Practice route: the practice trade form over P29.1 and the practice history over the `practice` scope.

## Canonical requirement
This scope becomes authoritative only after the exact P29.2 candidate receives a full `Kairos Controlled Roadmap Gate` PASS with both canonical artifacts and main carries the same commit with its own canonical PASS. P29.3 may not begin before that PASS.
