import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/liveMarketSummaryStateSessionScopedSnapshotBinding.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_22_LIVE_MARKET_SUMMARY_STATE_SESSION_SCOPED_SNAPSHOT_BINDING_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');
for (const token of [
  'LiveMarketSummaryStateSession',
  'readLiveMarketSummaryScopedStateSnapshot',
  'readLiveMarketSummaryStateSessionScopedSnapshot(',
  'const state = session.getState()',
  'return readLiveMarketSummaryScopedStateSnapshot(state, scope)',
]) if (!source.includes(token)) throw new Error(`P21.22 binding evidence missing: ${token}`);
if (!index.includes("export * from './liveMarketSummaryStateSessionScopedSnapshotBinding';")) throw new Error('P21.22 binding export missing');
const getStateCalls = (source.match(/session\.getState\(\)/g) || []).length;
if (getStateCalls !== 1) throw new Error(`P21.22 must read session state exactly once, found ${getStateCalls}`);
for (const forbidden of [
  '.transition(', '.sort(', '.filter(', '.reduce(', 'new Map(', 'new Set(',
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'fetch(', 'XMLHttpRequest',
  'WebSocket(', 'indexedDB', 'AbortController', 'createChart(',
]) if (source.includes(forbidden)) throw new Error(`P21.22 broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'no production owner composing those seams',
  'Read `session.getState()` exactly once per caller invocation',
  'Return the released scoped snapshot unchanged',
  'No universe/default-symbol/default-scope discovery',
  'No Bubble sizing/color/geometry/interactions/animation or Home wiring',
  'No persistence/IndexedDB/repository/schema/backup/journal/Your Trades/Saved Analysis/chart/transitions',
]) if (!report.includes(token)) throw new Error(`P21.22 report evidence missing: ${token}`);
console.log('P21.22 Live Market Summary State Session Scoped Snapshot Binding verification passed.');
