import { readFileSync } from 'node:fs';

const pkg = JSON.parse(readFileSync('package.json', 'utf8'));
const required = [
  'verify:p14:1r1-trade-visualizer-fixture-contract',
  'verify:p14:2-trade-visualizer-display-semantics',
  'verify:p14:3-journal-trade-visualizer-projection',
  'verify:p14:4-journal-trade-map-presentation',
  'verify:p14:5-journal-trade-map-svg-shell',
  'verify:p14:6-journal-trade-map-marker-semantics',
  'verify:p14:7-journal-trade-map-execution-time',
  'verify:p14:8-journal-trade-map-motion-semantics',
  'verify:p14:10-journal-trade-map-actual-entry',
];
for (const name of required) {
  if (!pkg.scripts?.[name]) throw new Error(`Missing P14 closure dependency: ${name}`);
}

const map = readFileSync('src/app/JournalTradeMap.tsx', 'utf8');
const graphic = readFileSync('src/app/JournalTradeMapGraphic.tsx', 'utf8');
const css = readFileSync('src/app/journalRoute.css', 'utf8');

const contracts = [
  [map.includes('projectJournalTradeVisualizer(entry)'), 'JournalTradeMap must consume the shared P14 projection owner'],
  [map.includes('Visual guide · Not to scale'), 'categorical Trade Map must retain Not-to-scale disclosure'],
  [map.includes("level.kind === 'executed-exit' && level.executedAt !== null"), 'execution time must remain limited to authoritative executed exits'],
  [map.includes('<time dateTime={level.executedAt}>{level.executedAt}</time>'), 'authoritative execution timestamp must remain machine-readable and visible'],
  [graphic.includes('data-level-kind={level.kind}'), 'SVG marker semantics must remain explicit'],
  [css.includes('kairos-trade-map-executed-exit-reveal'), 'P14.8 executed-exit reveal contract must remain registered'],
  [css.includes('var(--kairos-motion-normal)'), 'P14 motion must remain on the registered design-system token'],
];
for (const [ok, message] of contracts) if (!ok) throw new Error(message);

const forbidden = [
  /requestAnimationFrame\s*\(/,
  /setInterval\s*\(/,
  /WebSocket\s*\(/,
  /EventSource\s*\(/,
];
const presentation = `${map}\n${graphic}`;
for (const pattern of forbidden) {
  if (pattern.test(presentation)) throw new Error(`P14 closure forbids live/synthetic presentation owner: ${pattern}`);
}

console.log('PASS P14.9 Trade Visualizer system closure verifier');
