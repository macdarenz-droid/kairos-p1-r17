import { readFileSync } from 'node:fs';

const production = readFileSync('src/features/chart/lightweightChartsV5TrendLineDraftInteractionComposition.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const tests = readFileSync('tests/lightweight-charts-v5-trend-line-edit-click-execution-lifecycle-composition.test.ts', 'utf8');
const editPresentation = readFileSync('src/features/chart/chartTrendLineEditPresentationCoordination.ts', 'utf8');
const clickSubscription = readFileSync('src/features/chart/lightweightChartsV5DrawingClickSubscription.ts', 'utf8');
const p1858Verifier = readFileSync('scripts/verify-p18-58-lightweight-charts-v5-trend-line-edit-endpoint-click-lifecycle-composition.mjs', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

function fail(message) {
  console.error(`P18.59 verification failed: ${message}`);
  process.exit(1);
}

for (const token of [
  'LightweightChartsV5TrendLineEditClickExecutionLifecycleOptions',
  'readonly collection: ChartDrawingCollectionSession;',
  'readonly presentation: ChartDrawingPresentationDrawingRefreshSession;',
  'editExecution?: LightweightChartsV5TrendLineEditClickExecutionLifecycleOptions,',
  'let routeProjectedAnchorToExistingEdit = false;',
  "editExecution !== undefined && draftInteraction.getState().status === 'editing';",
  'const shouldExecuteEdit = routeProjectedAnchorToExistingEdit;',
  'routeProjectedAnchorToExistingEdit = false;',
  'if (shouldExecuteEdit && editExecution !== undefined)',
  'executeChartTrendLineEditAndRefreshPresentation(',
  'editExecution.collection,',
  'editExecution.presentation,',
  'acceptProjectedAnchor,',
  'if (getCurrentRendererDrawings === undefined)',
  'coordinateLightweightChartsV5TrendLineEditEndpointClick(',
  'coordinateLightweightChartsV5DrawingSelectionInteraction(',
]) {
  if (!production.includes(token)) fail(`missing lifecycle execution invariant: ${token}`);
}

const preClickSnapshotIndex = production.indexOf("editExecution !== undefined && draftInteraction.getState().status === 'editing';");
const endpointInitiationIndex = production.indexOf('coordinateLightweightChartsV5TrendLineEditEndpointClick(');
if (preClickSnapshotIndex < 0 || endpointInitiationIndex < 0 || preClickSnapshotIndex > endpointInitiationIndex) {
  fail('pre-click editing state must be captured before same-click endpoint initiation');
}

if (!production.includes("import { executeChartTrendLineEditAndRefreshPresentation } from './chartTrendLineEditPresentationCoordination';")) {
  fail('P18.59 must delegate execution + refresh to P18.51R3 owner');
}
if (!editPresentation.includes('export function executeChartTrendLineEditAndRefreshPresentation(')) {
  fail('P18.51R3 edit execution/presentation owner missing');
}
if (!clickSubscription.includes('onProviderClick?.(event);\n    onAnchor(')) {
  fail('P18.40 raw-provider-click-before-anchor ordering regressed');
}
if ((clickSubscription.match(/chart\.subscribeClick\(handleClick\)/g) || []).length !== 1) {
  fail('P18.26 must remain the single subscribeClick implementation owner');
}

for (const forbidden of [
  'chart.subscribeClick(',
  'chart.unsubscribeClick(',
  "type: 'start-editing'",
  'hitTestLightweightChartsV5TrendLineEditEndpoints(',
  'projectLightweightChartsV5TrendLineSegments(',
  'replaceDrawing(',
  'refreshChartDrawingPresentationFromCollection(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'riskReward',
  'risk-reward',
]) {
  if (production.includes(forbidden)) fail(`P18.59 crossed protected ownership: ${forbidden}`);
}

if (!index.includes('type LightweightChartsV5TrendLineEditClickExecutionLifecycleOptions,')) {
  fail('chart index execution lifecycle options export missing');
}
if (
  pkg.scripts?.['verify:p18:59-lightweight-charts-v5-trend-line-edit-click-execution-lifecycle-composition'] !==
  'node scripts/verify-p18-59-lightweight-charts-v5-trend-line-edit-click-execution-lifecycle-composition.mjs'
) {
  fail('P18.59 package verifier script missing');
}
if (!p1858Verifier.includes('later edit execution composition must delegate P18.51R3 rather than reimplement it')) {
  fail('P18.58 historical verifier compatibility amendment missing');
}

for (const token of [
  'keeps the endpoint-initiation click as edit intent only, then executes the edit from a later provider click anchor',
  'fails closed on a null replacement anchor and preserves authoritative editing state for a later retry click',
  'preserves one exact provider unsubscribe lifecycle after edit execution composition',
]) {
  if (!tests.includes(token)) fail(`focused runtime test missing case: ${token}`);
}

console.log('P18.59 Lightweight Charts v5 trend-line edit click execution lifecycle composition verification passed.');
