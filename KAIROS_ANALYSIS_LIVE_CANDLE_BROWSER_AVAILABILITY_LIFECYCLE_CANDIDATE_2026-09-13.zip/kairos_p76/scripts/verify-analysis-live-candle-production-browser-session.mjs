import { existsSync, readFileSync } from 'node:fs';

const sourcePath = 'src/app/binanceAnalysisLiveCandleProductionBrowserSession.ts';
const testPath = 'tests/binance-analysis-live-candle-production-browser-session.test.ts';
for (const file of [sourcePath, testPath]) {
  if (!existsSync(file)) throw new Error(`missing-live-candle-production-browser-session:${file}`);
}

const source = readFileSync(sourcePath, 'utf8');
const test = readFileSync(testPath, 'utf8');

for (const token of [
  'startBinanceAnalysisLiveCandleProductionBrowserSession',
  'binanceAnalysisLiveCandleBrowserRuntimeSources',
  'subscribeBinanceAnalysisLiveCandleBrowserSession',
  'receiptTimestamp: runtimeSources.receiptTimestamp',
  'scheduler: runtimeSources.scheduler',
  'reconnectSample: runtimeSources.reconnectSample',
  "'receiptTimestamp' | 'scheduler' | 'reconnectSample'",
]) if (!source.includes(token)) throw new Error(`missing-production-browser-session-token:${token}`);

for (const token of [
  'binds the released browser sources to the released session unchanged',
  'forwards an injected low-level subscription for deterministic composition tests',
  'does not invent reconnect policy or lifecycle callbacks',
]) if (!test.includes(token)) throw new Error(`missing-production-browser-session-evidence:${token}`);

for (const forbidden of [
  'new WebSocket', 'fetch(', 'indexedDB', 'localStorage', 'Dexie', 'setTimeout(',
  'Math.random(', 'Date.now(', 'initialDelayMs:', 'maxDelayMs:', 'maxAttempts:',
  'createTrade', 'updateTrade', 'calculateTrade', 'createSeriesMarkers', 'AnalysisRoute',
]) if (source.includes(forbidden)) throw new Error(`production-browser-session-ownership-violation:${forbidden}`);

console.log('Analysis live candle production browser session verifier PASS');
