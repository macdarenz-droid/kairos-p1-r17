import { readFileSync } from 'node:fs';
const component=readFileSync('src/app/VisualPnlPerformanceSummary.tsx','utf8');
const child=readFileSync('src/app/JournalDailyResults.tsx','utf8');
const css=readFileSync('src/app/journalRoute.css','utf8');
const tests=readFileSync('tests/visual-pnl-performance-summary-presentation.test.tsx','utf8');
for(const required of ['VisualPnlDailyPerformanceSummary','▲ Profit','▼ Loss','— Break-even','Available','· Unavailable','No result days yet']) {
  if(!component.includes(required)) throw new Error(`P13.16 presentation contract missing: ${required}`);
}
for(const required of ['summarizeVisualPnlDailyPerformance','<VisualPnlPerformanceSummary','state.projection.days']) {
  if(!child.includes(required)) throw new Error(`P13.16 established-owner wiring missing: ${required}`);
}
for(const required of ['--kairos-border-subtle','--kairos-surface-raised','--kairos-text-secondary']) {
  if(!css.includes(required)) throw new Error(`P13.16 semantic token missing: ${required}`);
}
const summaryStyle=css.split('.kairos-pnl-performance-summary {')[1]?.split('}')[0];
const gridStyle=css.split('.kairos-pnl-performance-summary__grid {')[1]?.split('}')[0];
for(const required of ['var(--kairos-border-subtle)','var(--kairos-surface-raised)']) {
  if(!summaryStyle?.includes(required)) throw new Error(`P13.16 summary card must use its registered semantic owner: ${required}`);
}
if(!gridStyle?.includes('var(--kairos-text-secondary)')) throw new Error('P13.16 summary values must use the registered secondary text owner');
for(const required of ['without percentages','unavailable result days separately','explicit empty state']) {
  if(!tests.includes(required)) throw new Error(`P13.16 test evidence missing: ${required}`);
}
for(const forbidden of ['Number(','parseFloat(','parseInt(','Decimal','Intl.','Date(','indexedDB','Dexie','localStorage','sessionStorage','exchangeRate','Math.']) {
  if(component.includes(forbidden)) throw new Error(`P13.16 presentation ownership violation: ${forbidden}`);
}
console.log('PASS P13.16 Visual P&L performance summary presentation verifier');
