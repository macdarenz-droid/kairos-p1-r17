import { readFileSync } from 'node:fs';
const binding = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hBrowserPublicRestBaselineStateBinding.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_18_BINANCE_SPOT_24H_BROWSER_PUBLIC_REST_BASELINE_STATE_BINDING_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');
for (const token of [
  'acquireBinanceSpot24hBrowserPublicRestBaselineIntoState(',
  'LiveMarketSummaryDeliveryState',
  'BinanceSpot24hPublicRestBaselineObservedAtSource',
  'createBinanceSpot24hBrowserPublicRestBaselineAcquisitionPort(readObservedAt)',
  'acquireLiveMarketSummaryBaselineIntoState(state, acquisitionPort, scope, options)',
  'LiveMarketSummaryBaselineStateOrchestrationResult',
]) if (!binding.includes(token)) throw new Error(`P21.18 binding evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpot24hBrowserPublicRestBaselineStateBinding';")) throw new Error('P21.18 browser baseline state binding export missing');
for (const forbidden of [
  'globalThis.fetch(', 'fetch(', 'XMLHttpRequest', 'WebSocket(', 'Response(', 'JSON.parse(',
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'indexedDB', '.sort(', 'createChart(',
  'connectBinanceSpot24hBrowserPublicRestBaselineRequest(',
  'createBinanceSpot24hPublicRestBaselineAcquisitionPort(',
  'applyLiveMarketSummaryDeliveryState(',
]) if (binding.includes(forbidden)) throw new Error(`P21.18 broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'Canonical P21.15 exposes `createBinanceSpot24hBrowserPublicRestBaselineAcquisitionPort(readObservedAt)`',
  'Canonical P21.17 exposes `acquireLiveMarketSummaryBaselineIntoState(state, acquisitionPort, scope, options?)`',
  'no production owner composing these released seams',
  'Create the acquisition port only through released',
  'Delegate acquisition and state application only through released',
  'Preserve released `acquisition-failed`, `delivery-invalid`, cancellation/options forwarding, and exact-prior-state semantics unchanged',
  'No market-universe/scope selection, ranking, filtering, grouping, sorting',
  'No state store, persistence, repository/schema/backup, direct IndexedDB',
]) if (!report.includes(token)) throw new Error(`P21.18 report evidence missing: ${token}`);
console.log('P21.18 Binance Spot browser public REST baseline state binding verification passed.');
