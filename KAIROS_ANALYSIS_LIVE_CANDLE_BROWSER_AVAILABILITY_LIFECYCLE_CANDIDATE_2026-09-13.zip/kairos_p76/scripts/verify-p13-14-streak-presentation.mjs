import { readFileSync } from 'node:fs';

const component = readFileSync('src/app/VisualPnlStreak.tsx', 'utf8');
const child = readFileSync('src/app/JournalDailyResults.tsx', 'utf8');
const css = readFileSync('src/app/journalRoute.css', 'utf8');
const tests = readFileSync('tests/visual-pnl-streak-presentation.test.tsx', 'utf8');

for (const required of ['VisualPnlDailyStreakProjection', 'Profit streak', 'Loss streak', 'Break-even streak', 'No available streak', 'aria-hidden']) {
  if (!component.includes(required)) throw new Error(`P13.14 presentation contract missing: ${required}`);
}
for (const required of ['projectVisualPnlDailyStreak', '<VisualPnlStreak', 'state.projection.days']) {
  if (!child.includes(required)) throw new Error(`P13.14 established-owner wiring missing: ${required}`);
}
for (const required of ['--kairos-trade-profit', '--kairos-trade-loss', '--kairos-text-secondary']) {
  if (!css.includes(required)) throw new Error(`P13.14 semantic token missing: ${required}`);
}
for (const [selector, token] of [['.kairos-pnl-streak--profit strong', '--kairos-trade-profit'], ['.kairos-pnl-streak--loss strong', '--kairos-trade-loss'], ['.kairos-pnl-streak--empty strong', '--kairos-text-secondary']]) {
  const declaration = css.split(selector)[1]?.split('}')[0];
  if (!declaration?.includes(`color: var(${token})`)) throw new Error(`P13.14 streak must use its registered semantic owner: ${selector}`);
}
for (const required of ['Profit streak', 'Loss streak', 'Break-even streak', 'No available streak']) {
  if (!tests.includes(required)) throw new Error(`P13.14 test evidence missing: ${required}`);
}
for (const forbidden of ['Number(', 'parseFloat(', 'parseInt(', 'Decimal', 'Intl.', 'Date(', 'indexedDB', 'Dexie', 'localStorage', 'sessionStorage', 'exchangeRate']) {
  if (component.includes(forbidden)) throw new Error(`P13.14 presentation ownership violation: ${forbidden}`);
}
console.log('PASS P13.14 Visual P&L streak presentation verifier');
