import { existsSync, readFileSync } from 'node:fs';

const sourcePath = 'src/app/binanceAnalysisLiveCandleBrowserAvailabilityLifecycle.ts';
const testPath = 'tests/binance-analysis-live-candle-browser-availability-lifecycle.test.ts';
for (const file of [sourcePath, testPath]) if (!existsSync(file)) throw new Error(`missing-browser-availability-lifecycle:${file}`);
const source = readFileSync(sourcePath, 'utf8');
const test = readFileSync(testPath, 'utf8');

for (const token of [
  'createBinanceAnalysisLiveCandleBrowserAvailabilityLifecycle',
  "visibilityState === 'hidden'",
  'browserWindow.navigator.onLine',
  "addEventListener('visibilitychange', reconcile)",
  "addEventListener('online', reconcile)",
  "addEventListener('offline', reconcile)",
  "reason: 'browser-unavailable'",
  'recovery.replace(options)',
  'recovery.stop();',
  'ticket !== generation',
  "removeEventListener('visibilitychange', reconcile)",
]) if (!source.includes(token)) throw new Error(`missing-browser-availability-lifecycle-token:${token}`);

for (const token of [
  'starts an exact selected scope only while visible and online',
  'retains selection but does not acquire when initially $availability',
  'stops when hidden and reacquires authoritative history once on visible resume',
  'stays stopped when online resumes under a hidden document',
  'uses only the latest selection after an unavailable replacement',
  'suppresses a late activation after suspension',
  'removes all listeners, stops once and never resumes after close',
]) if (!test.includes(token)) throw new Error(`missing-browser-availability-lifecycle-evidence:${token}`);

for (const forbidden of [
  'new WebSocket', 'fetch(', 'indexedDB', 'localStorage', 'Dexie', 'setTimeout(',
  'setInterval(', 'Math.random(', 'Date.now(', 'initialDelayMs:', 'maxDelayMs:',
  'maxAttempts:', 'createTrade', 'updateTrade', 'calculateTrade', 'createSeriesMarkers',
  'AnalysisRoute', 'AnalysisHistoryWorkspace',
]) if (source.includes(forbidden)) throw new Error(`browser-availability-lifecycle-ownership-violation:${forbidden}`);

console.log('Analysis live candle browser availability lifecycle verifier PASS');
