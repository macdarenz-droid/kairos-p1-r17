import { readFileSync } from 'node:fs';

const source = readFileSync('src/services/market-data/providers/binance/binanceSpotTradeCandleUpdateProjection.ts', 'utf8');
const tests = readFileSync('tests/binance-spot-trade-candle-update-projection.test.ts', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));
const fail = message => { throw new Error(`P16.19 trade candle update projection verifier FAIL: ${message}`); };

for (const token of [
  'projectBinanceSpotTradeCandleUpdate',
  "kind: 'updated-current' | 'appended-next'",
  "kind: 'ignored-stale'",
  "'gap-requires-backfill'",
  'observation.sourceTimestamp === null',
  'sourceBucket.openMs !== expectedNext.openMs',
  "interval === '1M'",
]) if (!source.includes(token)) fail(`missing contract token ${token}`);

for (const forbidden of ['setInterval(', 'setTimeout(', 'WebSocket', 'indexedDB', 'TradeRecord', 'calculatePnl', 'journalExecutions']) {
  if (source.includes(forbidden)) fail(`crossed owner boundary with ${forbidden}`);
}
for (const phrase of ['updates only the forming candle', 'requires authoritative backfill', 'calendar-month UTC boundaries']) {
  if (!tests.includes(phrase)) fail(`missing runtime evidence ${phrase}`);
}
if (pkg.scripts['verify:p16:19-binance-spot-trade-candle-update-projection'] !== 'node scripts/verify-p16-19-binance-spot-trade-candle-update-projection.mjs') fail('package registration missing');
console.log('PASS P16.19 Binance Spot trade candle update projection verifier');
