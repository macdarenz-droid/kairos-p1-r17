import { existsSync, readFileSync } from 'node:fs';

const sourcePath = 'src/app/binanceAnalysisLiveCandleBrowserRuntimeSources.ts';
const testPath = 'tests/binance-analysis-live-candle-browser-runtime-sources.test.ts';
for (const file of [sourcePath, testPath]) {
  if (!existsSync(file)) throw new Error(`missing-live-candle-browser-runtime-sources:${file}`);
}

const source = readFileSync(sourcePath, 'utf8');
const test = readFileSync(testPath, 'utf8');

for (const token of [
  'createBinanceAnalysisLiveCandleBrowserRuntimeSources',
  'binanceAnalysisLiveCandleBrowserRuntimeSources',
  'new Date(host.readCurrentTimeMs()).toISOString()',
  'host.scheduleTimeout(callback, delayMs)',
  'host.cancelTimeout(handle)',
  'host.readReconnectSample()',
  'readCurrentTimeMs: () => Date.now()',
  'window.setTimeout(callback, delayMs)',
  'window.clearTimeout(handle as number)',
  'readReconnectSample: () => Math.random()',
]) if (!source.includes(token)) throw new Error(`missing-live-candle-browser-runtime-source-token:${token}`);

for (const token of [
  'reads receipt time and reconnect entropy independently on demand',
  'forwards timer schedule and cancellation without owning retry policy',
  'binds production browser Date timer and Math sources lazily',
]) if (!test.includes(token)) throw new Error(`missing-live-candle-browser-runtime-source-evidence:${token}`);

for (const forbidden of [
  'WebSocket', 'fetch(', 'indexedDB', 'localStorage', 'Dexie', 'setInterval(',
  'initialDelayMs', 'maxDelayMs', 'maxAttempts', 'subscribeBinance',
  'createBinanceAnalysisLiveCandleProjectionRendererSession', 'AnalysisRoute',
  'createTrade', 'updateTrade', 'calculateTrade', 'createSeriesMarkers',
]) if (source.includes(forbidden)) throw new Error(`live-candle-browser-runtime-source-ownership-violation:${forbidden}`);

console.log('Analysis live candle browser runtime sources verifier PASS');
