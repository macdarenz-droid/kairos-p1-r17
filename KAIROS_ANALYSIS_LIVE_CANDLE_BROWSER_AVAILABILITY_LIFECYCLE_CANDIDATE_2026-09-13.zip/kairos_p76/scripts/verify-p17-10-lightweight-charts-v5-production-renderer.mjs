import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/lightweightChartsV5ProductionRenderer.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

const required = [
  'createIncrementalChartEnginePortFromDriver',
  'createLightweightChartsV5Driver',
  'lightweightChartsV5Package',
  'createProjectedIncrementalCandleRendererFactory',
  'createLightweightChartsV5ProductionRendererFactory',
  'updateLatestCandle',
];
for (const token of required) {
  if (!source.includes(token)) throw new Error(`missing-production-composition-token:${token}`);
}
if (!index.includes("createLightweightChartsV5ProductionRendererFactory")) {
  throw new Error('missing-production-renderer-export');
}
if (pkg.dependencies?.['lightweight-charts'] !== '5.2.1') {
  throw new Error('lightweight-charts-version-drift');
}
for (const forbidden of ['WebSocket', 'indexedDB', 'localStorage', 'Dexie', 'Binance', 'reconnect', 'createSeriesMarkers']) {
  if (source.includes(forbidden)) throw new Error(`forbidden-ownership:${forbidden}`);
}
console.log('P17.10 Lightweight Charts v5 production renderer composition verifier PASS');
