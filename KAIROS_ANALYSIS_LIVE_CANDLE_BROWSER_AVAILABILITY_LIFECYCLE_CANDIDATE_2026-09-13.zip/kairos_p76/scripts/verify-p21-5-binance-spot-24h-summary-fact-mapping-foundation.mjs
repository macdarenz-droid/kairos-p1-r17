import { readFileSync } from 'node:fs';
const mapper = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hSummaryFact.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_5_BINANCE_SPOT_24H_SUMMARY_FACT_MAPPING_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');
for (const token of [
  'export type BinanceSpot24hSummaryFactResult =',
  'export function mapBinanceSpot24hSummaryFact(',
  'validateLiveMarketSummaryFact(fact)',
  'BINANCE_SPOT_VENUE',
  'payload.lastPrice', 'payload.openPrice', 'payload.highPrice', 'payload.lowPrice',
  'payload.volume', 'payload.quoteVolume', 'payload.closeTime',
]) if (!mapper.includes(token)) throw new Error(`P21.5 mapper evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpot24hSummaryFact';")) throw new Error('P21.5 mapper barrel export missing');
for (const forbidden of ['fetch(', 'WebSocket', 'EventSource', 'indexedDB', '/api/v3/', 'acquireBaseline(', 'createChart(', 'bubbleSize', 'marketCap']) {
  if (mapper.includes(forbidden)) throw new Error(`P21.5 broadened into forbidden implementation scope: ${forbidden}`);
}
for (const token of ['# KAIROS P21.5 — Binance Spot 24h Summary Fact Mapping Foundation', 'No HTTP/fetch', 'No P21.4 acquisition-port implementation', 'No market-universe selection/ranking', 'No Bubble Map metric', 'No persistence']) {
  if (!report.includes(token)) throw new Error(`P21.5 report evidence missing: ${token}`);
}
console.log('P21.5 Binance Spot 24h summary fact mapping verification passed.');
