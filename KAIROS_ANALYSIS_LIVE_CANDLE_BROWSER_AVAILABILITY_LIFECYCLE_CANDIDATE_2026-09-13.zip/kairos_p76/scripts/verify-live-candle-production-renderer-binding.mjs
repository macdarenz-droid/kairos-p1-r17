import { existsSync, readFileSync } from 'node:fs';

for (const file of [
  'src/features/chart/projectedChartRenderer.ts',
  'src/features/chart/lightweightChartsV5ProductionRenderer.ts',
  'tests/projected-incremental-candle-renderer.test.ts',
]) {
  if (!existsSync(file)) throw new Error(`missing-live-candle-renderer-binding:${file}`);
}

const projected = readFileSync('src/features/chart/projectedChartRenderer.ts', 'utf8');
const production = readFileSync('src/features/chart/lightweightChartsV5ProductionRenderer.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync('tests/projected-incremental-candle-renderer.test.ts', 'utf8');

for (const token of [
  'createProjectedIncrementalCandleRendererFactory',
  "activeSeriesKind !== 'candles'",
  'projectChartCandle(candle)',
  "kind: 'candles'",
  'session.updateLatest',
  "throw new Error('chart-renderer-destroyed')",
  "throw new Error('chart-series-kind-mismatch')",
]) if (!projected.includes(token)) throw new Error(`missing-projected-binding-token:${token}`);

for (const token of [
  'createIncrementalChartEnginePortFromDriver',
  'createProjectedIncrementalCandleRendererFactory',
  'updateLatestCandle(candle)',
  'renderer.updateLatestCandle(candle)',
]) if (!production.includes(token)) throw new Error(`missing-production-binding-token:${token}`);

if (!index.includes('createProjectedIncrementalCandleRendererFactory')) {
  throw new Error('missing-incremental-renderer-export');
}
for (const token of [
  'without replacing the active series',
  "toHaveBeenCalledTimes(1)",
  "toThrow('chart-series-kind-mismatch')",
  "toThrow('chart-renderer-destroyed')",
]) if (!test.includes(token)) throw new Error(`missing-binding-test-evidence:${token}`);

for (const forbidden of [
  'WebSocket', 'fetch(', 'indexedDB', 'localStorage', 'Dexie', 'setTimeout(',
  'setInterval(', 'reconnect', 'subscribeBinance', 'createTrade', 'updateTrade',
  'calculateTrade', 'createSeriesMarkers',
]) {
  if (projected.includes(forbidden) || production.includes(forbidden)) {
    throw new Error(`live-candle-renderer-ownership-violation:${forbidden}`);
  }
}

console.log('Live candle production renderer binding verifier PASS');
