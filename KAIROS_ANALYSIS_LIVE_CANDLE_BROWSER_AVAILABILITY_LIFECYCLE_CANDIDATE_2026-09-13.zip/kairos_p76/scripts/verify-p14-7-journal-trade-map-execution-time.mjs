import { readFileSync } from 'node:fs';

const map = readFileSync(new URL('../src/app/JournalTradeMap.tsx', import.meta.url), 'utf8');
const css = readFileSync(new URL('../src/app/journalRoute.css', import.meta.url), 'utf8');

for (const token of [
  "level.kind === 'executed-exit'",
  'level.executedAt !== null',
  '<time dateTime={level.executedAt}>{level.executedAt}</time>',
  'Executed ',
]) {
  if (!map.includes(token)) throw new Error(`P14.7 missing JournalTradeMap token: ${token}`);
}
for (const forbidden of ['new Date(', 'toLocaleString(', 'fetch(', 'WebSocket', 'indexedDB']) {
  if (map.includes(forbidden)) throw new Error(`P14.7 forbidden JournalTradeMap token: ${forbidden}`);
}
if (!css.includes('.kairos-trade-map__execution-time')) throw new Error('P14.7 missing execution-time style');
const executionTimeStyle = css.split('.kairos-trade-map__execution-time')[1]?.split('}')[0];
if (!executionTimeStyle?.includes('var(--kairos-text-secondary)')) throw new Error('P14.7 execution-time style must use its registered semantic theme token');
console.log('P14.7 Journal Trade Map execution-time presentation verifier PASS');
