import { readFileSync } from 'node:fs';

const read = path => readFileSync(path, 'utf8');
const facts = read('src/application/trade-visualizer/tradeVisualizerFacts.ts');
const display = read('src/application/trade-visualizer/tradeVisualizerDisplayModel.ts');
const map = read('src/app/JournalTradeMap.tsx');
const graphic = read('src/app/JournalTradeMapGraphic.tsx');
const css = read('src/app/journalRoute.css');
const unit = read('tests/journal-trade-map-actual-entry.test.tsx');
const browser = read('scripts/test-journal-execution-browser.mjs');

for (const token of ["execution.type === 'entry'", 'executionId: execution.id', 'executedEntries: Object.freeze(executedEntries)']) {
  if (!facts.includes(token)) throw new Error(`P14.10 missing authoritative entry projection: ${token}`);
}
for (const token of ["kind: 'executed-entry'", 'Actual entry', 'quantity: entry.quantity', 'executedAt: entry.executedAt']) {
  if (!display.includes(token)) throw new Error(`P14.10 missing entry display semantic: ${token}`);
}
for (const token of ["level.kind === 'executed-entry'", 'Quantity {level.quantity}', '<time dateTime={level.executedAt}>{level.executedAt}</time>']) {
  if (!map.includes(token)) throw new Error(`P14.10 missing exact entry presentation: ${token}`);
}
for (const token of ['data-marker-shape="cross"', "kind === 'executed-entry'", '.kairos-trade-map__marker--actual-entry', "[data-level-kind='executed-entry']"]) {
  if (!graphic.includes(token) && !css.includes(token)) throw new Error(`P14.10 missing non-colour entry marker contract: ${token}`);
}
for (const token of ['Actual entry 1', 'Actual entry 2', 'Quantity 0.5', 'data-marker-shape="cross"']) {
  if (!unit.includes(token)) throw new Error(`P14.10 missing unit evidence: ${token}`);
}
for (const token of ['tradeMapActualEntry: true', 'saved-execution-trade-map.png', 'Actual entry uses its non-colour marker shape']) {
  if (!browser.includes(token)) throw new Error(`P14.10 missing real-browser evidence: ${token}`);
}
for (const source of [facts, display, map, graphic]) {
  for (const forbidden of ['calculateTradeMetrics', 'parseFloat(', 'parseInt(', 'indexedDB', 'fetch(', 'WebSocket']) {
    if (source.includes(forbidden)) throw new Error(`P14.10 ownership violation: ${forbidden}`);
  }
}
console.log('PASS P14.10 exact actual-entry Trade Map projection and presentation verifier');
