import { existsSync, readFileSync } from 'node:fs';

const sourcePath = 'src/app/binanceAnalysisLiveCandleBrowserSubscriptionComposition.ts';
const testPath = 'tests/binance-analysis-live-candle-browser-subscription-composition.test.ts';
for (const file of [sourcePath, testPath]) {
  if (!existsSync(file)) throw new Error(`missing-live-candle-browser-subscription-composition:${file}`);
}

const source = readFileSync(sourcePath, 'utf8');
const test = readFileSync(testPath, 'utf8');

for (const token of [
  'subscribeBinanceAnalysisLiveCandleBrowserSession',
  'createBinanceAnalysisLiveCandleProjectionRendererSession({',
  'subscribeBinanceSpotBrowserPublicTradeStreamWithReconnect',
  'const disposition = session.accept(observation)',
  'options.onDisposition?.(disposition)',
  'onStateChange: options.onStateChange',
  'onError: options.onError',
  'options.receiptTimestamp',
  'options.scheduler',
  'options.reconnectPolicy',
  'options.reconnectSample',
]) if (!source.includes(token)) throw new Error(`missing-live-candle-browser-subscription-token:${token}`);

for (const token of [
  'forwards exact subscription configuration',
  'retains session state across adjacent',
  'exact backfill request across gaps',
  'stale and rejected observations',
  'connection state, transport errors and close lifecycle unchanged',
  'subscription validation failure unchanged',
]) if (!test.includes(token)) throw new Error(`missing-live-candle-browser-subscription-evidence:${token}`);

for (const forbidden of [
  'new WebSocket', 'fetch(', 'indexedDB', 'localStorage', 'Dexie', 'setTimeout(',
  'setInterval(', 'createTrade', 'updateTrade', 'calculateTrade',
  'createSeriesMarkers', 'replaceSeries(', 'AnalysisRoute', 'document.', 'window.',
]) if (source.includes(forbidden)) throw new Error(`live-candle-browser-subscription-ownership-violation:${forbidden}`);

console.log('Analysis live candle browser subscription composition verifier PASS');
