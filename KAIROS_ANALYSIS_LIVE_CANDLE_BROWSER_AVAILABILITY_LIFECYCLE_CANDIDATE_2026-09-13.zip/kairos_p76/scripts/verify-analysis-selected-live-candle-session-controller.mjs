import { existsSync, readFileSync } from 'node:fs';

const sourcePath = 'src/app/binanceAnalysisSelectedLiveCandleSessionController.ts';
const testPath = 'tests/binance-analysis-selected-live-candle-session-controller.test.ts';
for (const file of [sourcePath, testPath]) {
  if (!existsSync(file)) throw new Error(`missing-selected-live-candle-session-controller:${file}`);
}

const source = readFileSync(sourcePath, 'utf8');
const test = readFileSync(testPath, 'utf8');
for (const token of [
  'createBinanceAnalysisSelectedLiveCandleSessionController',
  'startBinanceAnalysisLiveCandleProductionBrowserSession',
  'const ticket = ++generation',
  'active = null',
  'previous?.close()',
  'if (current(ticket)) options.onBackfillRequired(request)',
  'if (current(ticket)) options.onDisposition?.(disposition)',
  'if (current(ticket)) options.onStateChange?.(state)',
  'if (current(ticket)) options.onError?.(error)',
]) if (!source.includes(token)) throw new Error(`missing-selected-session-token:${token}`);

for (const token of [
  'closes the previous selected session before starting its replacement',
  'suppresses late callbacks from a replaced selection while forwarding current callbacks',
  'forwards only the current selection disposition and backfill demand',
  'leaves no active session when replacement validation fails',
  'stops idempotently and invalidates callbacks before cleanup',
]) if (!test.includes(token)) throw new Error(`missing-selected-session-evidence:${token}`);

for (const forbidden of [
  'new WebSocket', 'fetch(', 'indexedDB', 'localStorage', 'Dexie', 'setTimeout(',
  'Math.random(', 'Date.now(', 'initialDelayMs:', 'maxDelayMs:', 'maxAttempts:',
  'createTrade', 'updateTrade', 'calculateTrade', 'createSeriesMarkers', 'AnalysisRoute',
]) if (source.includes(forbidden)) throw new Error(`selected-session-ownership-violation:${forbidden}`);

console.log('Analysis selected live candle session controller verifier PASS');
