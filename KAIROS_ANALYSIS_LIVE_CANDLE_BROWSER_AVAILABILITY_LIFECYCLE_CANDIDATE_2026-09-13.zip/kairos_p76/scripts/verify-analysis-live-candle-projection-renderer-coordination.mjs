import { existsSync, readFileSync } from 'node:fs';

const sourcePath = 'src/app/binanceAnalysisLiveCandleProjectionRendererCoordination.ts';
const testPath = 'tests/binance-analysis-live-candle-projection-renderer-coordination.test.ts';
for (const file of [sourcePath, testPath]) {
  if (!existsSync(file)) throw new Error(`missing-live-candle-coordination:${file}`);
}

const source = readFileSync(sourcePath, 'utf8');
const test = readFileSync(testPath, 'utf8');

for (const token of [
  'createBinanceAnalysisLiveCandleProjectionRendererSession',
  'projectBinanceSpotTradeCandleUpdate(',
  'options.renderer.updateLatestCandle(projected.candle)',
  "projected.reason === 'gap-requires-backfill'",
  'options.onBackfillRequired(',
  "kind: 'ignored-stale'",
  "kind: 'rejected'",
  'current = projected.candle',
]) if (!source.includes(token)) throw new Error(`missing-live-candle-coordination-token:${token}`);

for (const token of [
  'advances current state only to the projected candle',
  'uses it for the following current-bucket update',
  'without rendering or changing the current candle',
  'signals authoritative backfill across a gap',
  'invalid identity or missing source time',
  'does not advance current state when the renderer rejects',
]) if (!test.includes(token)) throw new Error(`missing-live-candle-coordination-evidence:${token}`);

for (const forbidden of [
  'WebSocket', 'fetch(', 'indexedDB', 'localStorage', 'Dexie', 'setTimeout(',
  'setInterval(', 'subscribeBinance', 'connectBinance', 'createTrade',
  'updateTrade', 'calculateTrade', 'createSeriesMarkers', 'replaceSeries(',
]) if (source.includes(forbidden)) throw new Error(`live-candle-coordination-ownership-violation:${forbidden}`);

console.log('Analysis live candle projection-to-renderer coordination verifier PASS');
