import { existsSync, readFileSync } from 'node:fs';

const sourcePath = 'src/app/binanceAnalysisLiveCandleGapBackfillRecoveryCoordination.ts';
const testPath = 'tests/binance-analysis-live-candle-gap-backfill-recovery-coordination.test.ts';
for (const file of [sourcePath, testPath]) if (!existsSync(file)) throw new Error(`missing-gap-backfill-recovery:${file}`);
const source = readFileSync(sourcePath, 'utf8');
const test = readFileSync(testPath, 'utf8');

for (const token of [
  'createBinanceAnalysisLiveCandleGapBackfillRecoveryCoordinator',
  'bootstrap.replace({',
  'onBackfillRequired: request => {',
  'if (!current(ticket) || recovering) return;',
  "reason: 'backfill-scope-mismatch'",
  'recovering = true;',
  'void launch(ticket, options).then(result => {',
  'if (!result.ok) active = null;',
  'bootstrap.stop();',
]) if (!source.includes(token)) throw new Error(`missing-gap-backfill-recovery-token:${token}`);

for (const token of [
  'reacquires and rerenders one exact-scope gap through the released bootstrap',
  'coalesces duplicate gap demand while one authoritative recovery is pending',
  'rejects mismatched gap scope without stopping or acquiring another page',
  'suppresses recovery completion after selection replacement',
  'reports failed authoritative recovery and leaves no live claim',
  'stops the released bootstrap and suppresses late recovery completion',
]) if (!test.includes(token)) throw new Error(`missing-gap-backfill-recovery-evidence:${token}`);

for (const forbidden of [
  'new WebSocket', 'fetch(', 'indexedDB', 'localStorage', 'Dexie', 'setTimeout(',
  'Math.random(', 'Date.now(', 'initialDelayMs:', 'maxDelayMs:', 'maxAttempts:',
  'createTrade', 'updateTrade', 'calculateTrade', 'createSeriesMarkers', 'AnalysisRoute',
]) if (source.includes(forbidden)) throw new Error(`gap-backfill-recovery-ownership-violation:${forbidden}`);

console.log('Analysis live candle gap backfill recovery coordinator verifier PASS');
