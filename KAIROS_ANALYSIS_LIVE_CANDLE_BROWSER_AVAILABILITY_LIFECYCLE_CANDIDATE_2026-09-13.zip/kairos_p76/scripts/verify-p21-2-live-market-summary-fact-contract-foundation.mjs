import { readFileSync } from 'node:fs';

const types = readFileSync(new URL('../src/services/market-data/marketDataTypes.ts', import.meta.url), 'utf8');
const semantics = readFileSync(new URL('../src/services/market-data/liveMarketSummaryFactSemantics.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const adapter = readFileSync(new URL('../src/services/market-data/MarketDataAdapter.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_2_LIVE_MARKET_SUMMARY_FACT_CONTRACT_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');

for (const token of [
  'export interface LiveMarketSummaryFact',
  'readonly lastPrice: DecimalString;',
  'readonly open24h: DecimalString;',
  'readonly high24h: DecimalString;',
  'readonly low24h: DecimalString;',
  'readonly baseVolume24h: DecimalString;',
  'readonly quoteVolume24h: DecimalString;',
  'readonly observedAt: string;',
  'readonly sourceTimestamp: string | null;',
]) if (!types.includes(token)) throw new Error(`P21.2 fact contract evidence missing: ${token}`);

for (const token of [
  'export function validateLiveMarketSummaryFact(',
  "'base-volume-24h-invalid'",
  "'quote-volume-24h-invalid'",
  "'source-timestamp-invalid'",
]) if (!semantics.includes(token)) throw new Error(`P21.2 validation evidence missing: ${token}`);

if (!index.includes("export * from './liveMarketSummaryFactSemantics';")) throw new Error('P21.2 market-data export missing');
if (!adapter.includes('subscribe(')) throw new Error('P21.2 must preserve existing P15 single-instrument adapter ownership');

for (const forbidden of [
  'fetch(', 'WebSocket', 'EventSource', 'indexedDB', 'createChart(', 'bubbleSize', 'marketCap', 'rank(',
]) if (semantics.includes(forbidden)) throw new Error(`P21.2 fact semantics broadened into forbidden scope: ${forbidden}`);

for (const token of [
  '# KAIROS P21.2 — Live Market Summary Fact Contract Foundation',
  'two separate Bubble Maps',
  'No Bubble Map renderer',
  'No market-universe selection',
  'No persistence/schema/index work',
  'No journal/trade-history reads',
]) if (!report.includes(token)) throw new Error(`P21.2 report evidence missing: ${token}`);

console.log('P21.2 Live Market Summary fact-contract foundation verification passed.');
