import { readFileSync } from 'node:fs';

const port = readFileSync(new URL('../src/services/market-data/LiveMarketSummaryBaselineAcquisitionPort.ts', import.meta.url), 'utf8');
const semantics = readFileSync(new URL('../src/services/market-data/liveMarketSummaryBaselineAcquisitionSemantics.ts', import.meta.url), 'utf8');
const adapter = readFileSync(new URL('../src/services/market-data/MarketDataAdapter.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_4_LIVE_MARKET_SUMMARY_BASELINE_ACQUISITION_PORT_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');

for (const token of [
  'export type LiveMarketSummaryBaselineAcquisitionResult =',
  "readonly reason: 'acquisition-failed';",
  'export interface LiveMarketSummaryBaselineAcquisitionPort',
  'acquireBaseline(',
  'scope: readonly MarketDataInstrument[]',
  'Promise<LiveMarketSummaryBaselineAcquisitionResult>',
]) if (!port.includes(token)) throw new Error(`P21.4 port evidence missing: ${token}`);

for (const token of [
  'export function validateLiveMarketSummaryBaselineSuccess(',
  'validateLiveMarketSummaryDelivery(delivery)',
  "'delivery-invalid'",
  "'requested-scope-mismatch'",
]) if (!semantics.includes(token)) throw new Error(`P21.4 semantics evidence missing: ${token}`);

if (!index.includes("export * from './LiveMarketSummaryBaselineAcquisitionPort';")) throw new Error('P21.4 port export missing');
if (!index.includes("export * from './liveMarketSummaryBaselineAcquisitionSemantics';")) throw new Error('P21.4 semantics export missing');

for (const token of ['subscribe(', 'instrument: MarketDataInstrument', 'MarketDataSubscription']) {
  if (!adapter.includes(token)) throw new Error(`P15 single-instrument adapter boundary changed/missing: ${token}`);
}

for (const source of [port, semantics]) for (const forbidden of [
  'fetch(', 'WebSocket', 'EventSource', 'indexedDB', 'createChart(', 'bubbleSize', 'marketCap', 'setInterval(', 'setTimeout(',
]) if (source.includes(forbidden)) throw new Error(`P21.4 broadened into forbidden implementation scope: ${forbidden}`);

for (const token of [
  '# KAIROS P21.4 — Live Market Summary Baseline Acquisition Port Foundation',
  'The caller supplies the explicit instrument scope.',
  'No Binance implementation',
  'No market-universe selection/ranking policy',
  'No accumulator/state store',
  'No Bubble Map sizing',
  'No journal reads',
  'No dashboard transition/motion implementation',
]) if (!report.includes(token)) throw new Error(`P21.4 report evidence missing: ${token}`);

console.log('P21.4 Live Market Summary baseline acquisition port verification passed.');
