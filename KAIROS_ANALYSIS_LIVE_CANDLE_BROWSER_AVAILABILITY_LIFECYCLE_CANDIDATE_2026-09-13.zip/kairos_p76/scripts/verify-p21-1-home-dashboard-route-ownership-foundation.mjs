import { readFileSync } from 'node:fs';

const routes = readFileSync(new URL('../src/app/routes.tsx', import.meta.url), 'utf8');
const home = readFileSync(new URL('../src/app/HomeRoute.tsx', import.meta.url), 'utf8');
const shell = readFileSync(new URL('../src/app/AppShell.tsx', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_1_HOME_DASHBOARD_ROUTE_OWNERSHIP_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');

for (const token of [
  "import { HomeRoute } from './HomeRoute';",
  '{ index: true, element: <HomeRoute /> }',
]) if (!routes.includes(token)) throw new Error(`P21.1 route wiring missing: ${token}`);
if (routes.includes('<PlaceholderRoute title="Home" />')) throw new Error('P21.1 must remove only the Home placeholder ownership');

for (const token of [
  'export function HomeRoute()',
  'className="kairos-route"',
  'aria-labelledby="kairos-route-home"',
  'id="kairos-route-home">Home</h1>',
  'data-kairos-home-dashboard="live-crypto-text-runtime"',
  'id="kairos-home-dashboard-heading">Live Crypto Bubble</h2>',
  'HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime',
  'createHomeDashboardLiveCryptoBubbleDefaultRuntimeProductConfiguration',
]) if (!home.includes(token)) throw new Error(`P21.1 HomeRoute ownership/integration evidence missing: ${token}`);

if (home.includes('HomeDashboardLiveCryptoBubbleConfiguredTextEvidenceRuntime')) {
  throw new Error('P21.1 HomeRoute must not retain the superseded configured area-weight textual runtime consumer');
}

for (const forbidden of [
  'indexedDB', 'SavedAnalysisRepository', 'TradeRepository', 'lightweight-charts', 'createChart(',
  'fetch(', 'WebSocket', 'EventSource', 'PnL', 'profit', 'loss', 'riskReward', 'goal', 'discipline',
  "'USDC'", "'FDUSD'", "'0.25'", 'new Set(', '<svg', '<circle', '<canvas', 'style=',
  'Math.sqrt(', 'minRadius', 'maxRadius', 'radiusPx', 'collision', 'viewport',
]) if (home.includes(forbidden)) throw new Error(`P21.1 HomeRoute broadened into forbidden owner/scope: ${forbidden}`);

if (!shell.includes('<Outlet />')) throw new Error('P21.1 must retain AppShell outlet ownership');

for (const token of [
  '# KAIROS P21.1 — Home Dashboard Route Ownership Foundation',
  'P20.5',
  'existing `/` index route',
  'No bubble-map algorithm or geometry',
  'No new persistence, query, calculation, provider, or navigation owner',
]) if (!report.includes(token)) throw new Error(`P21.1 report evidence missing: ${token}`);

console.log('P21.1 Home Dashboard route ownership foundation verification passed with the released configured browser normalized-radius textual runtime integrated and preserved non-owner boundaries.');
