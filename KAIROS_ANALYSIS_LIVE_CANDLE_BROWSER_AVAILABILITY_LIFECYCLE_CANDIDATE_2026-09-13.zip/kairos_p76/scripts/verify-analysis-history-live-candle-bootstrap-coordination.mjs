import { existsSync, readFileSync } from 'node:fs';

const sourcePath = 'src/app/binanceAnalysisHistoryLiveCandleBootstrapCoordination.ts';
const testPath = 'tests/binance-analysis-history-live-candle-bootstrap-coordination.test.ts';
for (const file of [sourcePath, testPath]) if (!existsSync(file)) throw new Error(`missing-history-live-bootstrap:${file}`);
const source = readFileSync(sourcePath, 'utf8');
const test = readFileSync(testPath, 'utf8');

for (const token of [
  'createBinanceAnalysisHistoryLiveCandleBootstrapCoordinator',
  'history.acquireHistory(request, { signal: requestController.signal })',
  'pending?.abort()',
  'sessions.stop()',
  "return { ok: false, reason: 'superseded' }",
  "return { ok: false, reason: 'history-scope-mismatch' }",
  "return { ok: false, reason: 'history-empty' }",
  'renderer = renderHistory(result.snapshot)',
  'initialCandle: result.snapshot.candles[result.snapshot.candles.length - 1]',
  'const live = sessions.replace({',
]) if (!source.includes(token)) throw new Error(`missing-history-live-bootstrap-token:${token}`);

for (const token of [
  'acquires the exact recent scope, renders history and starts live from the final candle',
  'aborts and suppresses an older history result when selection changes',
  'rejects a mismatched history scope before rendering or starting live',
  'keeps empty or failed history unavailable instead of inventing a live anchor',
  'stops pending acquisition and active live ownership idempotently',
]) if (!test.includes(token)) throw new Error(`missing-history-live-bootstrap-evidence:${token}`);

for (const forbidden of [
  'new WebSocket', 'fetch(', 'indexedDB', 'localStorage', 'Dexie', 'setTimeout(',
  'Math.random(', 'Date.now(', 'initialDelayMs:', 'maxDelayMs:', 'maxAttempts:',
  'createTrade', 'updateTrade', 'calculateTrade', 'createSeriesMarkers', 'AnalysisRoute',
]) if (source.includes(forbidden)) throw new Error(`history-live-bootstrap-ownership-violation:${forbidden}`);

console.log('Analysis history to live candle bootstrap coordination verifier PASS');
