import { readFileSync } from 'node:fs';

const graphic = readFileSync(new URL('../src/app/JournalTradeMapGraphic.tsx', import.meta.url), 'utf8');
const css = readFileSync(new URL('../src/app/journalRoute.css', import.meta.url), 'utf8');
const test = readFileSync(new URL('../tests/journal-trade-map-marker-semantics.test.tsx', import.meta.url), 'utf8');

for (const forbidden of ['parseFloat(', 'parseInt(', 'new Decimal(', 'fetch(', 'WebSocket', 'indexedDB', '<canvas']) {
  if (graphic.includes(forbidden)) throw new Error(`P14.6 forbidden graphic token: ${forbidden}`);
}
const mapCss = css.slice(css.indexOf('.kairos-trade-map {'));
for (const required of [
  'data-marker-shape="circle"',
  'data-marker-shape="square"',
  'data-marker-shape="triangle"',
  'data-marker-shape="diamond"',
  'distinct marker shapes',
  'Not to scale',
  'model.levels.map',
]) {
  if (!graphic.includes(required)) throw new Error(`P14.6 missing graphic contract: ${required}`);
}
for (const required of [
  '.kairos-trade-map__lane--planned-stop',
  '.kairos-trade-map__lane--planned-target',
  '.kairos-trade-map__lane--executed-exit',
  'stroke-dasharray',
  'var(--kairos-text-secondary)',
  'var(--kairos-surface-raised)',
  'var(--kairos-border-subtle)',
]) {
  if (!mapCss.includes(required)) throw new Error(`P14.6 missing CSS contract: ${required}`);
}
for (const required of ['planned-entry', 'planned-stop', 'planned-target', 'executed-exit', 'Visual guide · Not to scale']) {
  if (!test.includes(required)) throw new Error(`P14.6 missing runtime contract: ${required}`);
}
console.log('PASS P14.6 Journal Trade Map categorical marker semantics verifier');
