# KAIROS P16.17 — Binance Spot Browser Public Trade Reconnect Subscription

## OBJECTIVE
Compose the canonical P16.16 browser public trade subscription with P16.15 serverShutdown reconnect execution while retaining P15 as the sole reconnect-policy/scheduling owner.

## RESEARCH
Current Binance Spot WebSocket documentation states raw streams use `/ws/<streamName>`, symbols are lowercase, connections are valid for 24 hours, and `serverShutdown` is sent before shutdown with guidance to establish a new connection promptly.

## OWNER TRACE
- P16.16: browser-ready public trade subscription composition.
- P16.14: provider `serverShutdown` -> transient disconnect cause.
- P16.15: provider evidence -> P15 reconnect execution.
- P15: retry disposition, bounded policy, jitter-derived planning, scheduler and cancellation.
- P16.17: active-subscription composition only.

## CHANGE
Add one browser-ready reconnecting public-trade subscription entry point. It intercepts valid `serverShutdown`, delegates planning/scheduling to P16.15/P15, closes the old subscription only when the scheduled reconnect executes, and opens the replacement through existing owners.

## NON-SCOPE
No chart/P17 work, persistence, journal mutation, credentials, account data, orders, new timers, new clocks, new randomness, or second reconnect policy.

## DATA/STATE FLOW
Binance message -> P16.14 classification -> P16.15/P15 reconnect execution -> injected scheduler -> existing P16.16 component owners -> replacement public trade subscription.

## PERSISTENCE
None.

## SECURITY
Public read-only market data only.

## OFFLINE
Local journal remains independent; reconnect failure cannot mutate journal truth.

## TESTS
Dedicated static verifier and runtime tests cover serverShutdown scheduling/reconnect, non-delivery as price data, pending-schedule cancellation, and idempotent close.

## REGRESSION
P16.16 remains available unchanged. Existing P15/P16 owners are reused rather than duplicated.

## PERFORMANCE
O(1) per inbound event and at most one tracked pending reconnect schedule.

## KNOWN LIMITATIONS
Only Binance `serverShutdown` is wired to reconnect execution in this slice. Generic abnormal-close policy remains outside this provider-specific evidence path.

## RESULT
Candidate pending canonical gate.
