import { useEffect, useRef, useState } from 'react';
import { composeTimeAssistedTradeSnapshot, type EstimatedMarketReference, type TimeAssistedTradeSide, type TimeAssistedTradeSnapshotResult } from '../application/market-reference';
import type { MarketCandleHistoryPort } from '../services/market-data/MarketCandleHistoryPort';
import type { MarketDataInstrument } from '../services/market-data/marketDataTypes';
import { analysisHistoryPorts } from './analysisHistoryPorts';

export interface AnalysisTimeAssistedSnapshotControlsProps {
  /** The released P15/P16 history port (the Analysis browser composition by default); the controls make no other network call. */
  readonly history?: Pick<MarketCandleHistoryPort, 'acquireHistory'>;
  /** The exact selected market; null hides the controls. */
  readonly instrument: MarketDataInstrument | null;
  /** The clock for the future-instant check (tests inject a fixed one). */
  readonly now?: () => number;
}

type Status =
  | { readonly kind: 'idle' }
  | { readonly kind: 'estimating' }
  | { readonly kind: 'ready'; readonly result: TimeAssistedTradeSnapshotResult };

const deviceTimeZone = (): string => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'device time'; } catch { return 'device time'; } };
const utcClock = (iso: string): string => iso.replace('T', ' ').replace(/\.\d{3}Z$/, ' UTC');
const seconds = (ms: number): string => `${Math.round(ms / 1000)}s`;
const duration = (ms: number): string => {
  const total = Math.round(ms / 1000), h = Math.floor(total / 3600), m = Math.floor((total % 3600) / 60), s = total % 60;
  return [h ? `${h}h` : '', m ? `${m}m` : '', s || (!h && !m) ? `${s}s` : ''].filter(Boolean).join(' ');
};
const invalidText = (reason: Extract<TimeAssistedTradeSnapshotResult, { kind: 'invalid' }>['reason']): string => {
  switch (reason) {
    case 'side-invalid': return 'Choose long or short.';
    case 'opened-at-invalid': return 'Enter the opening date and time.';
    case 'closed-at-invalid': return 'The closing date and time is not valid.';
    case 'closed-before-opened': return 'The closing time must not be before the opening time.';
  }
};
const unavailableText = (reason: Extract<EstimatedMarketReference, { kind: 'unavailable' }>['reason']): string => {
  switch (reason) {
    case 'future-instant': return 'That time is in the future; no market candle exists yet.';
    case 'invalid-instant': return 'That time could not be read.';
    case 'no-candle': return 'No market candle exists for that minute on this venue.';
    case 'candle-mismatch': return 'The venue returned a candle for a different minute; nothing is estimated.';
    case 'http-error': return 'The venue refused the history request.';
    case 'transport-failed': case 'cancelled': return 'The history request did not complete. Check your connection.';
    default: return 'The venue response could not be used.';
  }
};

function Estimate({ label, estimate }: { readonly label: string; readonly estimate: EstimatedMarketReference }) {
  if (estimate.kind === 'unavailable') return <div className="kairos-time-assisted__estimate" data-estimate={label.toLowerCase()} data-estimate-kind="unavailable"><strong>{label}</strong><p>{unavailableText(estimate.reason)}</p></div>;
  const { candle } = estimate;
  return <div className="kairos-time-assisted__estimate" data-estimate={label.toLowerCase()} data-estimate-kind="candle-range" data-candle-open-time={candle.openTime} data-candle-low={candle.low} data-candle-high={candle.high}>
    <strong>{label}</strong>
    <p>Estimated from the 1-minute market candle at {utcClock(candle.openTime)}, {seconds(estimate.gapMs)} after its open. Not your fill.</p>
    <dl>
      <div><dt>Range</dt><dd>{candle.low} – {candle.high}</dd></div>
      <div><dt>Open</dt><dd>{candle.open}</dd></div>
      <div><dt>Close</dt><dd>{candle.close}</dd></div>
    </dl>
  </div>;
}

/** Time-assisted preview: instrument from the Analysis selection, side and instants from the user, estimates from the released P22.2 composition. No journal access, no chart drawing. */
export function AnalysisTimeAssistedSnapshotControls({ history = analysisHistoryPorts.history, instrument, now }: AnalysisTimeAssistedSnapshotControlsProps) {
  const [side, setSide] = useState<TimeAssistedTradeSide>('long');
  const [openedAt, setOpenedAt] = useState('');
  const [closedAt, setClosedAt] = useState('');
  const [status, setStatus] = useState<Status>({ kind: 'idle' });
  const controller = useRef<AbortController | null>(null);
  const marketKey = instrument === null ? null : `${instrument.venue}|${instrument.symbol}`;
  useEffect(() => { setStatus({ kind: 'idle' }); return () => { controller.current?.abort(); controller.current = null; }; }, [marketKey]);
  if (instrument === null) return null;

  const estimate = () => {
    controller.current?.abort();
    const next = new AbortController(); controller.current = next;
    setStatus({ kind: 'estimating' });
    composeTimeAssistedTradeSnapshot(history, { instrument, side, openedAt, closedAt: closedAt.trim() === '' ? null : closedAt }, { signal: next.signal, ...(now === undefined ? {} : { now }) })
      .then(result => { if (!next.signal.aborted) setStatus({ kind: 'ready', result }); }, () => { if (!next.signal.aborted) setStatus({ kind: 'ready', result: { kind: 'invalid', reason: 'opened-at-invalid' } }); });
  };
  const result = status.kind === 'ready' ? status.result : null;
  const dataStatus = status.kind === 'ready' ? result!.kind : status.kind;

  return <section className="kairos-time-assisted" aria-labelledby="kairos-time-assisted-title" data-time-assisted-status={dataStatus}>
    <h3 id="kairos-time-assisted-title">Time-assisted snapshot</h3>
    <p className="kairos-analysis-chart__note">Enter when a trade opened and closed to see the market candle at each moment. Times are in your device time zone ({deviceTimeZone()}). Estimates are market references, never your fill, and nothing is saved.</p>
    <form className="kairos-time-assisted__form" onSubmit={event => { event.preventDefault(); estimate(); }}>
      <label><span>Side</span><select aria-label="Snapshot side" value={side} onChange={event => setSide(event.target.value as TimeAssistedTradeSide)}><option value="long">Long</option><option value="short">Short</option></select></label>
      <label><span>Opened at</span><input aria-label="Snapshot opened at" type="datetime-local" step="1" value={openedAt} onChange={event => setOpenedAt(event.target.value)} /></label>
      <label><span>Closed at</span><input aria-label="Snapshot closed at" type="datetime-local" step="1" value={closedAt} onChange={event => setClosedAt(event.target.value)} /></label>
      <button type="submit" disabled={status.kind === 'estimating'}>Estimate</button>
    </form>
    <div aria-live="polite" data-time-assisted-result="true">
      {status.kind === 'estimating' ? <p className="kairos-analysis-chart__note">Looking up market candles…</p> : null}
      {result?.kind === 'invalid' ? <p role="alert">{invalidText(result.reason)}</p> : null}
      {result?.kind === 'snapshot' ? <>
        <p className="kairos-analysis-chart__note">{result.side === 'long' ? 'Long' : 'Short'} · {result.durationMs === null ? 'still open' : `held ${duration(result.durationMs)}`} · {instrument.symbol} on {instrument.venue}</p>
        <Estimate label="Entry" estimate={result.opening} />
        {result.closing === null ? null : <Estimate label="Exit" estimate={result.closing} />}
      </> : null}
    </div>
  </section>;
}
