import { readFile, readdir } from 'node:fs/promises';
import { extname, relative } from 'node:path';

const root = new URL('../', import.meta.url);
const packageJson = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));

if (packageJson.scripts?.['verify:p5:repositories'] !== 'node scripts/verify-p5-repositories.mjs') {
  throw new Error('P5.2 repository verifier must have one package-script owner.');
}

const schema = await readFile(new URL('../src/data/database/schema.ts', import.meta.url), 'utf8');
if (!/KAIROS_DB_SCHEMA_VERSION\s*=\s*1\s+as const/.test(schema) || !/metadata:\s*'&key'/.test(schema)) {
  throw new Error('P5.2 must preserve the immutable P5.1 V1 metadata-only schema.');
}

const repository = await readFile(new URL('../src/data/repositories/MetadataRepository.ts', import.meta.url), 'utf8');
if (!/class MetadataRepository/.test(repository) || !/this\.db\.metadata\.(get|put|delete)/.test(repository)) {
  throw new Error('P5.2 must establish a concrete metadata repository over the authoritative database owner.');
}
if (/fetch\(|WebSocket|navigator\.|localStorage|sessionStorage|new Dexie|indexedDB/i.test(repository)) {
  throw new Error('P5.2 repository must not own network, UI, browser storage, or a second Dexie database.');
}
if (/trades|tradePlans|tradeExecutions|tradeFees|chartAnalyses|chartDrawings|strategies|strategyRules|goals|attachments/i.test(repository)) {
  throw new Error('P5.2 must not introduce future domain repository ownership early.');
}

const registry = await readFile(new URL('../src/data/repositories/index.ts', import.meta.url), 'utf8');
if (!/createKairosRepositories/.test(registry) || !/metadata:\s*new MetadataRepository\(db\)/.test(registry)) {
  throw new Error('P5.2 must expose one injectable repository registry bound to one KairosDatabase owner.');
}

async function walk(dirUrl) {
  const entries = await readdir(dirUrl, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const child = new URL(`${entry.name}${entry.isDirectory() ? '/' : ''}`, dirUrl);
    if (entry.isDirectory()) files.push(...await walk(child));
    else files.push(child);
  }
  return files;
}

const sourceFiles = await walk(new URL('../src/', import.meta.url));
for (const fileUrl of sourceFiles) {
  if (!['.ts', '.tsx'].includes(extname(fileUrl.pathname))) continue;
  const relativePath = relative(root.pathname, fileUrl.pathname);
  if (relativePath === 'src/data/database/KairosDatabase.ts' || relativePath === 'src/data/repositories/MetadataRepository.ts') continue;
  const text = await readFile(fileUrl, 'utf8');
  if (/\.metadata\.(get|put|add|update|delete|clear|bulkAdd|bulkPut|bulkDelete)\s*\(/.test(text)) {
    throw new Error(`P5.2 direct metadata-table access escaped repository ownership in ${relativePath}.`);
  }
}

console.log('P5.2 repository ownership / metadata repository contract: PASS');
