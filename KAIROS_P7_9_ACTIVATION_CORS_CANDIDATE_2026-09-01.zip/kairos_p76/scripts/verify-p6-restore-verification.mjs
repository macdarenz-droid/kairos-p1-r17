import fs from 'node:fs';

const verification = fs.readFileSync('src/data/backup/restoreVerification.ts', 'utf8');
const replacement = fs.readFileSync('src/data/backup/restoreReplacement.ts', 'utf8');
const schema = fs.readFileSync('src/data/database/schema.ts', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));

const checks = [
  ['verification owner exists', verification.includes('restoreAndVerifyKairosDatabase')],
  ['replacement remains transactional owner', verification.includes('replaceKairosDatabaseFromPreparedRestore(db, prepared)')],
  ['database connection is closed before reopen verification', verification.includes('closeKairosDatabase(db)')],
  ['database lifecycle owner performs reopen', verification.includes('openKairosDatabase(db)')],
  ['post-reopen integrity required', verification.includes('assertKairosDatabaseIntegrity(db)')],
  ['authoritative repository re-query required', verification.includes('repositories.metadata.listAll()')],
  ['mismatch has typed failure', verification.includes("'REQUERY_MISMATCH'")],
  ['reopen failure has typed failure', verification.includes("'REOPEN_FAILED'")],
  ['recovery snapshot stays attached to failures/results', verification.includes('prepared.recovery')],
  ['schema remains V1', /KAIROS_DB_SCHEMA_VERSION\s*=\s*1/.test(schema)],
  ['metadata remains only V1 store', schema.includes("metadata: '&key'")],
  ['verification script registered', pkg.scripts['verify:p6:restore-verification'] === 'node scripts/verify-p6-restore-verification.mjs'],
  ['P6.4 post-import integrity remains intact', replacement.includes('assertKairosDatabaseIntegrity(db)')],
];

let failed = false;
for (const [label, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'}: ${label}`);
  if (!ok) failed = true;
}
if (failed) process.exit(1);
console.log('P6.5 post-restore reopen/re-query verification static contract PASS');
