import fs from 'node:fs';

const read = (path) => fs.readFileSync(path, 'utf8');
const fail = (message) => {
  console.error(`P5.5 transaction verification FAIL: ${message}`);
  process.exit(1);
};

const schema = read('src/data/database/schema.ts');
const transactions = read('src/data/database/transactions.ts');
const databaseIndex = read('src/data/database/index.ts');
const tests = read('tests/database-transactions.test.ts');
const packageJson = JSON.parse(read('package.json'));

if (!schema.includes('KAIROS_DB_SCHEMA_VERSION = 1 as const') || !schema.includes("metadata: '&key'")) {
  fail('P5.5 must preserve production schema V1 / metadata-only.');
}
for (const forbidden of ['trades:', 'tradePlans:', 'tradeExecutions:', 'tradeFees:', 'chartAnalyses:', 'chartDrawings:']) {
  if (schema.includes(forbidden) || transactions.includes(forbidden)) fail(`future domain store introduced early: ${forbidden}`);
}
if (!transactions.includes('runKairosAtomicWrite') || !transactions.includes("db.transaction('rw'")) {
  fail('atomic readwrite transaction owner is missing.');
}
if (!transactions.includes('createKairosRepositories(db)')) {
  fail('transaction callback must consume the existing repository owner.');
}
if (!transactions.includes('storeNames.length === 0') || !transactions.includes('Object.hasOwn(KAIROS_V1_STORES')) {
  fail('transaction scope validation is missing.');
}
for (const forbidden of ['Dexie.waitFor', 'ignoreTransaction', "'rw!'", 'fetch(', 'setTimeout(', 'setInterval(']) {
  if (transactions.includes(forbidden)) fail(`long-lived or bypass transaction behavior introduced: ${forbidden}`);
}
if (!databaseIndex.includes("from './transactions'")) {
  fail('transaction owner is not exported through the data/database boundary.');
}
if (!tests.includes('rolls back every write') || !tests.includes('Dexie.currentTransaction')) {
  fail('atomic rollback/transaction-zone regression coverage is missing.');
}
if (packageJson.scripts?.['verify:p5:transactions'] !== 'node scripts/verify-p5-transactions.mjs') {
  fail('verify:p5:transactions package script is missing or changed.');
}

console.log('P5.5 transaction foundation verification PASS');
