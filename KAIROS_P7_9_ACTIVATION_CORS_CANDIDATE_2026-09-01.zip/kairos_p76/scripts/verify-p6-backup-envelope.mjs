import fs from 'node:fs';

const required = [
  'src/data/backup/backupFormat.ts',
  'src/data/backup/backupEnvelope.ts',
  'src/data/backup/backupValidation.ts',
  'src/data/backup/backupSerialization.ts',
  'tests/backup-envelope.test.ts',
];
for (const file of required) {
  if (!fs.existsSync(file)) throw new Error(`P6.1 missing required file: ${file}`);
}
const format = fs.readFileSync('src/data/backup/backupFormat.ts', 'utf8');
const build = fs.readFileSync('src/app/buildInfo.ts', 'utf8');
const schema = fs.readFileSync('src/data/database/schema.ts', 'utf8');
const validation = fs.readFileSync('src/data/backup/backupValidation.ts', 'utf8');
if (!format.includes("KAIROS_BACKUP_FORMAT_NAME = 'kairos-full-backup'")) throw new Error('P6.1 format name missing');
if (!format.includes('KAIROS_BACKUP_FORMAT_VERSION = 1')) throw new Error('P6.1 format version missing');
if (!build.includes('backupFormatVersion: KAIROS_BACKUP_FORMAT_VERSION')) throw new Error('A40 backup format identity missing');
if (!schema.includes('KAIROS_DB_SCHEMA_VERSION = 1')) throw new Error('P6.1 must not change DB schema');
if (!schema.includes("metadata: '&key'")) throw new Error('P6.1 must preserve metadata-only V1');
if (!validation.includes('UNSUPPORTED_FORMAT_VERSION')) throw new Error('P6.1 must reject unsupported backup versions');
for (const forbidden of ['Dexie.waitFor', 'crypto.subtle', 'AES-GCM']) {
  const all = required.map((f) => fs.readFileSync(f, 'utf8')).join('\n');
  if (all.includes(forbidden)) throw new Error(`P6.1 forbidden scope expansion: ${forbidden}`);
}
console.log('P6.1 backup envelope verification: PASS');
