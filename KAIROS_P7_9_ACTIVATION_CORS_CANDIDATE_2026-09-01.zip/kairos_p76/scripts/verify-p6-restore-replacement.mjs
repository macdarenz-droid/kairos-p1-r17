import fs from 'node:fs';

const replacement = fs.readFileSync('src/data/backup/restoreReplacement.ts', 'utf8');
const repository = fs.readFileSync('src/data/repositories/MetadataRepository.ts', 'utf8');
const schema = fs.readFileSync('src/data/database/schema.ts', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));

const checks = [
  ['replacement owner exists', replacement.includes('replaceKairosDatabaseFromPreparedRestore')],
  ['uses atomic write owner', replacement.includes("runKairosAtomicWrite(db, ['metadata']")],
  ['post-import integrity required', replacement.includes('assertKairosDatabaseIntegrity(db)')],
  ['repository owns replacement', repository.includes('async replaceAll(')],
  ['clear and bulk put are repository operations', repository.includes('.clear()') && repository.includes('.bulkPut(')],
  ['schema remains V1', /KAIROS_DB_SCHEMA_VERSION\s*=\s*1/.test(schema)],
  ['metadata remains only V1 store', schema.includes("metadata: '&key'")],
  ['verification script registered', pkg.scripts['verify:p6:restore-replacement'] === 'node scripts/verify-p6-restore-replacement.mjs'],
  ['no Dexie waitFor escape', !replacement.includes('waitFor') && !replacement.includes('ignoreTransaction')],
];

let failed = false;
for (const [label, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'}: ${label}`);
  if (!ok) failed = true;
}
if (failed) process.exit(1);
console.log('P6.4 transactional validated replacement static contract PASS');
