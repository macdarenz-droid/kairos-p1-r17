import fs from 'node:fs';

const read = (path) => fs.readFileSync(path, 'utf8');
const fail = (message) => {
  console.error(`P5.4 integrity verification FAIL: ${message}`);
  process.exit(1);
};

const schema = read('src/data/database/schema.ts');
const integrity = read('src/data/database/integrity.ts');
const databaseIndex = read('src/data/database/index.ts');
const tests = read('tests/database-integrity.test.ts');
const packageJson = JSON.parse(read('package.json'));

if (!schema.includes('KAIROS_DB_SCHEMA_VERSION = 1 as const') || !schema.includes("metadata: '&key'")) {
  fail('P5.4 must preserve production schema V1 / metadata-only.');
}
for (const forbidden of ['trades:', 'tradePlans:', 'tradeExecutions:', 'tradeFees:', 'chartAnalyses:', 'chartDrawings:']) {
  if (schema.includes(forbidden) || integrity.includes(forbidden)) fail(`future domain store introduced early: ${forbidden}`);
}
if (!integrity.includes('inspectKairosDatabaseIntegrity') || !integrity.includes('assertKairosDatabaseIntegrity')) {
  fail('read-only inspect/assert integrity service is missing.');
}
if (!integrity.includes("'schema-version'") || !integrity.includes("'store-set'") || !integrity.includes("'metadata-record-shape'")) {
  fail('required schema/store/record invariants are not represented.');
}
if (!integrity.includes('DatabaseIntegrityError')) {
  fail('typed integrity failure path is missing.');
}
if (/\.put\s*\(|\.add\s*\(|\.delete\s*\(|\.clear\s*\(|\.bulkPut\s*\(|\.bulkDelete\s*\(/.test(integrity)) {
  fail('integrity service must remain read-only and may not auto-repair persistent data.');
}
if (!databaseIndex.includes("from './integrity'")) {
  fail('database integrity owner is not exported through the data/database boundary.');
}
if (!tests.includes('without mutating or deleting it') || !tests.includes('instead of masquerading corruption as empty data')) {
  fail('corruption/no-auto-repair regression coverage is missing.');
}
if (packageJson.scripts?.['verify:p5:integrity'] !== 'node scripts/verify-p5-integrity.mjs') {
  fail('verify:p5:integrity package script is missing or changed.');
}

console.log('P5.4 database integrity verification PASS');
