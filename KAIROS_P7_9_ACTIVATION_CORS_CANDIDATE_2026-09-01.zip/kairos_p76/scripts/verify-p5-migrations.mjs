import fs from 'node:fs';

const read = (path) => fs.readFileSync(path, 'utf8');
const fail = (message) => {
  console.error(`P5.3 migration verification FAIL: ${message}`);
  process.exit(1);
};

const schema = read('src/data/database/schema.ts');
const migrations = read('src/data/database/migrations.ts');
const database = read('src/data/database/KairosDatabase.ts');
const lifecycle = read('src/data/database/databaseLifecycle.ts');
const tests = read('tests/database-migrations.test.ts');
const packageJson = JSON.parse(read('package.json'));

if (!schema.includes("KAIROS_DB_SCHEMA_VERSION = 1 as const")) {
  fail('production schema version changed; P5.3 must remain v1');
}
if (!schema.includes("metadata: '&key'")) {
  fail('historical v1 metadata schema changed');
}
for (const forbidden of ['trades:', 'tradePlans:', 'tradeExecutions:', 'tradeFees:', 'chartAnalyses:', 'chartDrawings:']) {
  if (schema.includes(forbidden) || migrations.includes(forbidden)) {
    fail(`future domain store introduced early: ${forbidden}`);
  }
}
if (!migrations.includes('KAIROS_DATABASE_MIGRATIONS') || !migrations.includes('registerKairosMigrations')) {
  fail('migration registry/registration owner is missing');
}
if (!migrations.includes('contiguous and append-only')) {
  fail('migration sequence validation is missing');
}
if (!database.includes('registerKairosMigrations(this)')) {
  fail('KairosDatabase does not delegate schema history to the migration harness');
}
if (database.includes('.version(')) {
  fail('KairosDatabase bypasses the migration registry with an inline version declaration');
}
if (!lifecycle.includes("db.on('blocked'")) {
  fail('upgrade-blocked lifecycle handling is missing');
}
if (!tests.includes('old fixture -> versioned upgrade -> integrity read -> reload')) {
  fail('required migration fixture regression is missing');
}
if (packageJson.scripts?.['verify:p5:migrations'] !== 'node scripts/verify-p5-migrations.mjs') {
  fail('verify:p5:migrations package script is missing or changed');
}

console.log('P5.3 migration verification PASS');
