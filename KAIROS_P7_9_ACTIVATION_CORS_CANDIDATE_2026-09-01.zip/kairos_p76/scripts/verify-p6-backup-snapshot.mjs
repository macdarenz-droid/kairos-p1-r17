import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const fail = (message) => { console.error(`P6.2 verification failed: ${message}`); process.exitCode = 1; };
const requireText = (source, token, message) => { if (!source.includes(token)) fail(message); };

const snapshot = read('src/data/backup/backupSnapshot.ts');
const repository = read('src/data/repositories/MetadataRepository.ts');
const backupIndex = read('src/data/backup/index.ts');
const test = read('tests/backup-snapshot.test.ts');
const pkg = JSON.parse(read('package.json'));
const schema = read('src/data/database/schema.ts');

requireText(snapshot, 'assertKairosDatabaseIntegrity(db)', 'snapshot must fail closed through the authoritative integrity owner');
requireText(snapshot, "db.transaction('r', db.metadata", 'snapshot must use an explicitly scoped read-only transaction');
requireText(snapshot, 'repositories.metadata.listAll()', 'snapshot must read through repository ownership');
requireText(snapshot, 'createKairosBackupEnvelope', 'snapshot must feed the locked P6.1 envelope owner');
requireText(repository, 'async listAll()', 'metadata repository must expose the read-all operation used by snapshot ownership');
requireText(backupIndex, "export * from './backupSnapshot';", 'snapshot API must be exported through backup boundary');
requireText(test, 'fails closed when database integrity is invalid', 'corruption fail-closed coverage is required');
requireText(test, 'returns detached backup records', 'detached snapshot coverage is required');
requireText(schema, "metadata: '&key'", 'production V1 metadata schema must remain unchanged');

if (/\.(?:delete|clear|bulkPut|put|add|update)\s*\(/.test(snapshot)) {
  fail('backup snapshot owner must remain read-only');
}
if (pkg.scripts?.['verify:p6:backup-snapshot'] !== 'node scripts/verify-p6-backup-snapshot.mjs') {
  fail('package script verify:p6:backup-snapshot is missing or changed');
}

if (!process.exitCode) console.log('P6.2 backup snapshot ownership contract verified.');
