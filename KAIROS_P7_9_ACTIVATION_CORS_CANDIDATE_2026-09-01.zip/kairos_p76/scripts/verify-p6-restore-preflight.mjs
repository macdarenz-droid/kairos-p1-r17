import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const fail = (message) => { console.error(`P6.3 verification failed: ${message}`); process.exitCode = 1; };
const requireText = (source, token, message) => { if (!source.includes(token)) fail(message); };

const preflight = read('src/data/backup/restorePreflight.ts');
const backupIndex = read('src/data/backup/index.ts');
const test = read('tests/restore-preflight.test.ts');
const pkg = JSON.parse(read('package.json'));
const schema = read('src/data/database/schema.ts');

requireText(preflight, 'parseKairosBackup(serializedIncomingBackup)', 'incoming backup must be parsed/validated through P6.1 ownership first');
requireText(preflight, 'assertRestoreCompatibility(incoming)', 'restore-specific compatibility validation is required');
requireText(preflight, 'DUPLICATE_METADATA_KEY', 'duplicate persistent keys must be rejected');
requireText(preflight, 'INCOMPATIBLE_DATABASE_SCHEMA', 'unsupported database schema must be rejected');
requireText(preflight, 'createKairosDatabaseSnapshot(db)', 'recovery snapshot must reuse authoritative P6.2 snapshot ownership');
requireText(preflight, 'serializeKairosBackup(envelope)', 'recovery snapshot must be independently serializable');
requireText(preflight, 'const preflight = preflightKairosRestore(serializedIncomingBackup);', 'incoming validation must occur before recovery snapshot creation');
requireText(preflight, 'const recovery = await createKairosRecoverySnapshot(db);', 'recoverable current-state snapshot must be created before future destructive import');
requireText(backupIndex, "export * from './restorePreflight';", 'P6.3 API must be exported through backup boundary');
requireText(test, 'without replacing data', 'P6.3 must prove that preparation does not replace current data');
requireText(test, 'fails before recovery snapshot creation when incoming JSON is invalid', 'invalid incoming data must fail before recovery work');
requireText(schema, "metadata: '&key'", 'production V1 metadata schema must remain unchanged');

if (/\.(?:delete|clear|bulkPut|put|update)\s*\(/.test(preflight)) {
  fail('P6.3 preflight owner must not perform destructive or persistent restore writes');
}
if (pkg.scripts?.['verify:p6:restore-preflight'] !== 'node scripts/verify-p6-restore-preflight.mjs') {
  fail('package script verify:p6:restore-preflight is missing or changed');
}

if (!process.exitCode) console.log('P6.3 restore preflight and recovery snapshot contract verified.');
