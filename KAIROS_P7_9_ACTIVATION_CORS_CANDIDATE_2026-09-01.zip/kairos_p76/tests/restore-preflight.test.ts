import 'fake-indexeddb/auto';
import Dexie from 'dexie';
import { afterEach, describe, expect, it } from 'vitest';
import {
  KairosRestorePreflightError,
  createKairosBackupEnvelope,
  prepareKairosRestore,
  preflightKairosRestore,
  serializeKairosBackup,
} from '../src/data/backup';
import { createKairosDatabase } from '../src/data/database';

const databaseNames: string[] = [];

function testDatabaseName(label: string): string {
  const name = `kairos-p6-3-${label}-${crypto.randomUUID()}`;
  databaseNames.push(name);
  return name;
}

afterEach(async () => {
  for (const name of databaseNames.splice(0)) await Dexie.delete(name);
});

function serializedIncoming(metadata = [{ key: 'incoming', value: 'new', updatedAt: '2026-08-31T08:30:00.000Z' }]): string {
  return serializeKairosBackup(createKairosBackupEnvelope({
    metadata,
    exportedAt: new Date('2026-08-31T08:31:00.000Z'),
    appVersion: 'incoming-app',
    buildId: 'incoming-build',
  }));
}

describe('P6.3 restore preflight and recovery snapshot ownership', () => {
  it('validates incoming backup and creates a recoverable snapshot of the current database without replacing data', async () => {
    const db = createKairosDatabase(testDatabaseName('prepare'));
    await db.open();
    await db.metadata.put({ key: 'current', value: 'keep-me', updatedAt: '2026-08-31T08:20:00.000Z' });

    const prepared = await prepareKairosRestore(db, serializedIncoming());

    expect(prepared.preview).toMatchObject({ metadataRecords: 1, totalRecords: 1, databaseSchemaVersion: 1 });
    expect(prepared.incoming.payload.metadata[0]?.key).toBe('incoming');
    expect(prepared.recovery.envelope.payload.metadata[0]).toMatchObject({ key: 'current', value: 'keep-me' });
    expect(JSON.parse(prepared.recovery.serialized).payload.metadata[0].key).toBe('current');
    expect(await db.metadata.toArray()).toEqual([
      { key: 'current', value: 'keep-me', updatedAt: '2026-08-31T08:20:00.000Z' },
    ]);
    db.close();
  });

  it('rejects a backup claiming an unsupported database schema before creating a recovery snapshot', async () => {
    const envelope = createKairosBackupEnvelope({
      metadata: [],
      databaseSchemaVersion: 2,
    });

    expect(() => preflightKairosRestore(JSON.stringify(envelope))).toThrowError(KairosRestorePreflightError);
    try {
      preflightKairosRestore(JSON.stringify(envelope));
    } catch (error) {
      expect((error as KairosRestorePreflightError).code).toBe('INCOMPATIBLE_DATABASE_SCHEMA');
    }
  });

  it('rejects duplicate persistent keys that would make replacement ambiguous', () => {
    const serialized = serializedIncoming([
      { key: 'same', value: '1', updatedAt: '2026-08-31T08:30:00.000Z' },
      { key: 'same', value: '2', updatedAt: '2026-08-31T08:30:01.000Z' },
    ]);

    expect(() => preflightKairosRestore(serialized)).toThrowError(KairosRestorePreflightError);
    try {
      preflightKairosRestore(serialized);
    } catch (error) {
      expect((error as KairosRestorePreflightError).code).toBe('DUPLICATE_METADATA_KEY');
    }
  });

  it('fails before recovery snapshot creation when incoming JSON is invalid', async () => {
    const db = createKairosDatabase(testDatabaseName('invalid-first'));
    await db.open();
    await db.metadata.put({ key: 'current', value: 'safe', updatedAt: '2026-08-31T08:20:00.000Z' });

    await expect(prepareKairosRestore(db, '{not-json')).rejects.toThrow('Backup is not valid JSON');
    expect((await db.metadata.get('current'))?.value).toBe('safe');
    db.close();
  });

  it('contains no destructive restore mutation operations', async () => {
    const source = await import('../src/data/backup/restorePreflight?raw');
    expect(source.default).not.toMatch(/\.(?:delete|clear|bulkPut|put|update)\s*\(/);
  });
});
