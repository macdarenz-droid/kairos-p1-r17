import { describe, expect, it } from 'vitest';
import { buildInfo } from '../src/app/buildInfo';
import {
  KAIROS_BACKUP_FORMAT_NAME,
  KAIROS_BACKUP_FORMAT_VERSION,
  KairosBackupValidationError,
  createKairosBackupEnvelope,
  parseKairosBackup,
  serializeKairosBackup,
  validateKairosBackupEnvelope,
} from '../src/data/backup';

describe('P6.1 backup envelope', () => {
  const metadata = [{ key: 'theme', value: 'dark', updatedAt: '2026-08-31T08:00:00.000Z' }];

  it('creates a versioned Kairos-owned envelope with independent schema and backup versions', () => {
    const envelope = createKairosBackupEnvelope({
      metadata,
      exportedAt: new Date('2026-08-31T08:30:00.000Z'),
      appVersion: 'test-app',
      buildId: 'test-build',
      databaseSchemaVersion: 1,
    });
    expect(envelope).toMatchObject({
      formatName: KAIROS_BACKUP_FORMAT_NAME,
      formatVersion: KAIROS_BACKUP_FORMAT_VERSION,
      appVersion: 'test-app',
      buildId: 'test-build',
      databaseSchemaVersion: 1,
      recordCounts: { metadata: 1, total: 1 },
    });
    expect(buildInfo.backupFormatVersion).toBe(KAIROS_BACKUP_FORMAT_VERSION);
  });

  it('round-trips valid JSON through strict validation', () => {
    const envelope = createKairosBackupEnvelope({ metadata });
    expect(parseKairosBackup(serializeKairosBackup(envelope))).toEqual(envelope);
  });

  it('rejects foreign formats and unsupported future format versions before payload use', () => {
    const envelope = createKairosBackupEnvelope({ metadata });
    expect(() => validateKairosBackupEnvelope({ ...envelope, formatName: 'other-app' })).toThrow(
      KairosBackupValidationError,
    );
    expect(() => validateKairosBackupEnvelope({ ...envelope, formatVersion: 2 })).toThrowError(
      expect.objectContaining({ code: 'UNSUPPORTED_FORMAT_VERSION' }),
    );
  });

  it('rejects malformed records and count mismatches', () => {
    const envelope = createKairosBackupEnvelope({ metadata });
    expect(() =>
      validateKairosBackupEnvelope({
        ...envelope,
        payload: { metadata: [{ key: '', value: 'x', updatedAt: 'not-a-date' }] },
      }),
    ).toThrowError(expect.objectContaining({ code: 'INVALID_PAYLOAD' }));
    expect(() =>
      validateKairosBackupEnvelope({ ...envelope, recordCounts: { metadata: 0, total: 0 } }),
    ).toThrowError(expect.objectContaining({ code: 'INVALID_RECORD_COUNTS' }));
  });

  it('does not implement restore, merge, encryption, compression, or integrity hashing in P6.1', () => {
    const envelope = createKairosBackupEnvelope({ metadata });
    expect(envelope).not.toHaveProperty('integrityHash');
    expect(envelope).not.toHaveProperty('encryption');
    expect(envelope).not.toHaveProperty('compression');
  });
});
