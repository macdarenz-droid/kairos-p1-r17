import type { KairosBackupEnvelopeV1 } from './backupFormat';
import { KairosBackupValidationError, validateKairosBackupEnvelope } from './backupValidation';

export function serializeKairosBackup(envelope: KairosBackupEnvelopeV1): string {
  validateKairosBackupEnvelope(envelope);
  return JSON.stringify(envelope);
}

export function parseKairosBackup(serialized: string): KairosBackupEnvelopeV1 {
  let parsed: unknown;
  try {
    parsed = JSON.parse(serialized) as unknown;
  } catch {
    throw new KairosBackupValidationError('INVALID_JSON', 'Backup is not valid JSON.');
  }
  return validateKairosBackupEnvelope(parsed);
}
