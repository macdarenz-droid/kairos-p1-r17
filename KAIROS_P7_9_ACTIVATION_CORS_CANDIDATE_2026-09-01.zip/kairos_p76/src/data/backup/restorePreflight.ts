import { KAIROS_DB_SCHEMA_VERSION } from '../database/schema';
import type { KairosDatabase } from '../database/KairosDatabase';
import { createKairosDatabaseSnapshot } from './backupSnapshot';
import type { KairosBackupEnvelopeV1 } from './backupFormat';
import { parseKairosBackup, serializeKairosBackup } from './backupSerialization';

export type KairosRestorePreflightCode =
  | 'INCOMPATIBLE_DATABASE_SCHEMA'
  | 'DUPLICATE_METADATA_KEY';

export class KairosRestorePreflightError extends Error {
  constructor(
    public readonly code: KairosRestorePreflightCode,
    message: string,
  ) {
    super(message);
    this.name = 'KairosRestorePreflightError';
  }
}

export interface KairosRestorePreviewV1 {
  readonly formatVersion: number;
  readonly databaseSchemaVersion: number;
  readonly exportedAt: string;
  readonly metadataRecords: number;
  readonly totalRecords: number;
}

export interface KairosRecoverySnapshotV1 {
  readonly envelope: KairosBackupEnvelopeV1;
  readonly serialized: string;
}

export interface KairosPreparedRestoreV1 {
  readonly incoming: KairosBackupEnvelopeV1;
  readonly preview: KairosRestorePreviewV1;
  readonly recovery: KairosRecoverySnapshotV1;
}

function assertRestoreCompatibility(envelope: KairosBackupEnvelopeV1): void {
  if (envelope.databaseSchemaVersion !== KAIROS_DB_SCHEMA_VERSION) {
    throw new KairosRestorePreflightError(
      'INCOMPATIBLE_DATABASE_SCHEMA',
      'Backup database schema is not supported by this build.',
    );
  }

  const keys = new Set<string>();
  for (const record of envelope.payload.metadata) {
    if (keys.has(record.key)) {
      throw new KairosRestorePreflightError(
        'DUPLICATE_METADATA_KEY',
        `Backup contains duplicate metadata key: ${record.key}`,
      );
    }
    keys.add(record.key);
  }
}

function createRestorePreview(envelope: KairosBackupEnvelopeV1): KairosRestorePreviewV1 {
  return Object.freeze({
    formatVersion: envelope.formatVersion,
    databaseSchemaVersion: envelope.databaseSchemaVersion,
    exportedAt: envelope.exportedAt,
    metadataRecords: envelope.recordCounts.metadata,
    totalRecords: envelope.recordCounts.total,
  });
}

export function preflightKairosRestore(serializedIncomingBackup: string): {
  readonly incoming: KairosBackupEnvelopeV1;
  readonly preview: KairosRestorePreviewV1;
} {
  const incoming = parseKairosBackup(serializedIncomingBackup);
  assertRestoreCompatibility(incoming);

  return Object.freeze({
    incoming,
    preview: createRestorePreview(incoming),
  });
}

export async function createKairosRecoverySnapshot(
  db: KairosDatabase,
): Promise<KairosRecoverySnapshotV1> {
  const envelope = await createKairosDatabaseSnapshot(db);
  return Object.freeze({
    envelope,
    serialized: serializeKairosBackup(envelope),
  });
}

export async function prepareKairosRestore(
  db: KairosDatabase,
  serializedIncomingBackup: string,
): Promise<KairosPreparedRestoreV1> {
  // Validate the untrusted incoming backup before touching even the recovery path.
  const preflight = preflightKairosRestore(serializedIncomingBackup);
  // Preserve the current authoritative state before any future destructive import is allowed.
  const recovery = await createKairosRecoverySnapshot(db);

  return Object.freeze({
    incoming: preflight.incoming,
    preview: preflight.preview,
    recovery,
  });
}
