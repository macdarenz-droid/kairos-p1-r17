import type { DatabaseMetadataRecord } from '../database/schema';

export const KAIROS_BACKUP_FORMAT_NAME = 'kairos-full-backup' as const;
export const KAIROS_BACKUP_FORMAT_VERSION = 1 as const;

export interface KairosBackupPayloadV1 {
  readonly metadata: readonly DatabaseMetadataRecord[];
}

export interface KairosBackupRecordCountsV1 {
  readonly metadata: number;
  readonly total: number;
}

export interface KairosBackupEnvelopeV1 {
  readonly formatName: typeof KAIROS_BACKUP_FORMAT_NAME;
  readonly formatVersion: typeof KAIROS_BACKUP_FORMAT_VERSION;
  readonly appVersion: string;
  readonly buildId: string;
  readonly exportedAt: string;
  readonly databaseSchemaVersion: number;
  readonly recordCounts: KairosBackupRecordCountsV1;
  readonly payload: KairosBackupPayloadV1;
}

export type KairosBackupEnvelope = KairosBackupEnvelopeV1;
