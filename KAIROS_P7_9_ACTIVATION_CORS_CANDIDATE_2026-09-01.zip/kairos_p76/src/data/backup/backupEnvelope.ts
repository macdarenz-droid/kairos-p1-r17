import { APP_VERSION, BUILD_ID } from '../../app/buildInfo';
import { KAIROS_DB_SCHEMA_VERSION, type DatabaseMetadataRecord } from '../database/schema';
import {
  KAIROS_BACKUP_FORMAT_NAME,
  KAIROS_BACKUP_FORMAT_VERSION,
  type KairosBackupEnvelopeV1,
  type KairosBackupPayloadV1,
} from './backupFormat';

export interface CreateKairosBackupEnvelopeOptions {
  readonly metadata: readonly DatabaseMetadataRecord[];
  readonly exportedAt?: Date;
  readonly appVersion?: string;
  readonly buildId?: string;
  readonly databaseSchemaVersion?: number;
}

function cloneMetadata(records: readonly DatabaseMetadataRecord[]): DatabaseMetadataRecord[] {
  return records.map((record) => ({ ...record }));
}

export function createKairosBackupEnvelope(
  options: CreateKairosBackupEnvelopeOptions,
): KairosBackupEnvelopeV1 {
  const payload: KairosBackupPayloadV1 = Object.freeze({
    metadata: Object.freeze(cloneMetadata(options.metadata)),
  });
  const metadataCount = payload.metadata.length;

  return Object.freeze({
    formatName: KAIROS_BACKUP_FORMAT_NAME,
    formatVersion: KAIROS_BACKUP_FORMAT_VERSION,
    appVersion: options.appVersion ?? APP_VERSION,
    buildId: options.buildId ?? BUILD_ID,
    exportedAt: (options.exportedAt ?? new Date()).toISOString(),
    databaseSchemaVersion: options.databaseSchemaVersion ?? KAIROS_DB_SCHEMA_VERSION,
    recordCounts: Object.freeze({ metadata: metadataCount, total: metadataCount }),
    payload,
  });
}
