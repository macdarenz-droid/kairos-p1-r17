import type { KairosDatabase } from '../database/KairosDatabase';
import { assertKairosDatabaseIntegrity, type DatabaseIntegrityReport } from '../database/integrity';
import { runKairosAtomicWrite } from '../database/transactions';
import type { KairosPreparedRestoreV1 } from './restorePreflight';

export interface KairosRestoreResultV1 {
  readonly restoredMetadataRecords: number;
  readonly integrity: DatabaseIntegrityReport;
}

/**
 * Replaces backup-scoped V1 contents from an already-prepared restore while retaining installation-local control state.
 *
 * Preflight validation and recovery snapshot creation must happen before this
 * function is called. The destructive clear + write unit is intentionally one
 * short atomic transaction so any failure aborts the complete replacement.
 */
export async function replaceKairosDatabaseFromPreparedRestore(
  db: KairosDatabase,
  prepared: KairosPreparedRestoreV1,
): Promise<KairosRestoreResultV1> {
  const incomingMetadata = prepared.incoming.payload.metadata.map((record) => ({ ...record }));

  await runKairosAtomicWrite(db, ['metadata'], async ({ repositories }) => {
    await repositories.metadata.replaceAll(incomingMetadata);
  });

  // A committed transaction is not enough to call restore successful. Re-read
  // the authoritative database and require the normal integrity owner to pass.
  const integrity = await assertKairosDatabaseIntegrity(db);

  return Object.freeze({
    restoredMetadataRecords: incomingMetadata.length,
    integrity,
  });
}
