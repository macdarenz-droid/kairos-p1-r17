import {
  KAIROS_BACKUP_FORMAT_NAME,
  KAIROS_BACKUP_FORMAT_VERSION,
  type KairosBackupEnvelopeV1,
} from './backupFormat';

export type KairosBackupValidationCode =
  | 'INVALID_JSON'
  | 'INVALID_ROOT'
  | 'FORMAT_NAME_MISMATCH'
  | 'UNSUPPORTED_FORMAT_VERSION'
  | 'INVALID_HEADER'
  | 'INVALID_RECORD_COUNTS'
  | 'INVALID_PAYLOAD';

export class KairosBackupValidationError extends Error {
  constructor(
    public readonly code: KairosBackupValidationCode,
    message: string,
  ) {
    super(message);
    this.name = 'KairosBackupValidationError';
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}

function isMetadataRecord(value: unknown): boolean {
  return (
    isRecord(value) &&
    isNonEmptyString(value.key) &&
    typeof value.value === 'string' &&
    isNonEmptyString(value.updatedAt) &&
    !Number.isNaN(Date.parse(value.updatedAt))
  );
}

export function validateKairosBackupEnvelope(input: unknown): KairosBackupEnvelopeV1 {
  if (!isRecord(input)) {
    throw new KairosBackupValidationError('INVALID_ROOT', 'Backup root must be an object.');
  }
  if (input.formatName !== KAIROS_BACKUP_FORMAT_NAME) {
    throw new KairosBackupValidationError('FORMAT_NAME_MISMATCH', 'Backup format name is not Kairos.');
  }
  if (input.formatVersion !== KAIROS_BACKUP_FORMAT_VERSION) {
    throw new KairosBackupValidationError(
      'UNSUPPORTED_FORMAT_VERSION',
      'Backup format version is not supported by this build.',
    );
  }
  if (
    !isNonEmptyString(input.appVersion) ||
    !isNonEmptyString(input.buildId) ||
    !isNonEmptyString(input.exportedAt) ||
    Number.isNaN(Date.parse(input.exportedAt)) ||
    !Number.isInteger(input.databaseSchemaVersion) ||
    (input.databaseSchemaVersion as number) < 1
  ) {
    throw new KairosBackupValidationError('INVALID_HEADER', 'Backup header is incomplete or invalid.');
  }
  if (!isRecord(input.payload) || !Array.isArray(input.payload.metadata)) {
    throw new KairosBackupValidationError('INVALID_PAYLOAD', 'Backup payload is invalid.');
  }
  if (!input.payload.metadata.every(isMetadataRecord)) {
    throw new KairosBackupValidationError('INVALID_PAYLOAD', 'Backup metadata contains an invalid record.');
  }
  if (!isRecord(input.recordCounts)) {
    throw new KairosBackupValidationError('INVALID_RECORD_COUNTS', 'Backup record counts are invalid.');
  }
  const expected = input.payload.metadata.length;
  if (input.recordCounts.metadata !== expected || input.recordCounts.total !== expected) {
    throw new KairosBackupValidationError(
      'INVALID_RECORD_COUNTS',
      'Backup record counts do not match the payload.',
    );
  }
  return input as unknown as KairosBackupEnvelopeV1;
}
