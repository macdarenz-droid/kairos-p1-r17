import Dexie, { type EntityTable } from 'dexie';
import { registerKairosMigrations } from './migrations';
import {
  KAIROS_DATABASE_NAME,
  type DatabaseMetadataRecord,
} from './schema';

export class KairosDatabase extends Dexie {
  readonly metadata!: EntityTable<DatabaseMetadataRecord, 'key'>;

  constructor(name = KAIROS_DATABASE_NAME) {
    super(name);
    registerKairosMigrations(this);
  }
}
