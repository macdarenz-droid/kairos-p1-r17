import type { KairosDatabase } from './KairosDatabase';
import { KAIROS_DB_SCHEMA_VERSION } from './schema';

export type DatabaseIntegrityCheckId =
  | 'database-open'
  | 'schema-version'
  | 'store-set'
  | 'metadata-primary-key'
  | 'metadata-record-shape';

export interface DatabaseIntegrityCheck {
  readonly id: DatabaseIntegrityCheckId;
  readonly ok: boolean;
  readonly detail: string;
}

export interface DatabaseIntegrityReport {
  readonly ok: boolean;
  readonly schemaVersion: number;
  readonly checkedAt: string;
  readonly metadataRecordCount: number;
  readonly checks: readonly DatabaseIntegrityCheck[];
}

export class DatabaseIntegrityError extends Error {
  readonly report: DatabaseIntegrityReport;

  constructor(report: DatabaseIntegrityReport) {
    const failed = report.checks.filter((check) => !check.ok).map((check) => check.id).join(', ');
    super(`Kairos database integrity check failed: ${failed || 'unknown invariant'}.`);
    this.name = 'DatabaseIntegrityError';
    this.report = report;
  }
}

function check(id: DatabaseIntegrityCheckId, ok: boolean, detail: string): DatabaseIntegrityCheck {
  return Object.freeze({ id, ok, detail });
}

function isIsoTimestamp(value: unknown): value is string {
  if (typeof value !== 'string' || value.length === 0) return false;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) && new Date(parsed).toISOString() === value;
}

function isMetadataRecord(value: unknown): boolean {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return false;
  const record = value as Record<string, unknown>;
  return typeof record.key === 'string'
    && record.key.length > 0
    && typeof record.value === 'string'
    && isIsoTimestamp(record.updatedAt);
}

export async function inspectKairosDatabaseIntegrity(db: KairosDatabase): Promise<DatabaseIntegrityReport> {
  const checks: DatabaseIntegrityCheck[] = [];
  const isOpen = db.isOpen();
  checks.push(check('database-open', isOpen, isOpen ? 'Database connection is open.' : 'Database connection is not open.'));

  const schemaVersionOk = db.verno === KAIROS_DB_SCHEMA_VERSION;
  checks.push(check(
    'schema-version',
    schemaVersionOk,
    `Expected schema v${KAIROS_DB_SCHEMA_VERSION}; found v${db.verno}.`,
  ));

  const storeNames = db.tables.map((table) => table.name).sort();
  const storeSetOk = storeNames.length === 1 && storeNames[0] === 'metadata';
  checks.push(check(
    'store-set',
    storeSetOk,
    `Expected metadata-only store set; found ${storeNames.join(', ') || 'none'}.`,
  ));

  const metadataTable = db.tables.find((table) => table.name === 'metadata');
  const primaryKeyPath = metadataTable?.schema.primKey.keyPath;
  const metadataPrimaryKeyOk = primaryKeyPath === 'key';
  checks.push(check(
    'metadata-primary-key',
    metadataPrimaryKeyOk,
    `Expected metadata primary key "key"; found ${String(primaryKeyPath ?? 'missing')}.`,
  ));

  let metadataRecordCount = 0;
  let metadataShapeOk = false;
  let metadataShapeDetail = 'Metadata records were not inspected because the database/store is unavailable.';

  if (isOpen && metadataTable) {
    const records = await metadataTable.toArray();
    metadataRecordCount = records.length;
    const invalidIndex = records.findIndex((record) => !isMetadataRecord(record));
    metadataShapeOk = invalidIndex === -1;
    metadataShapeDetail = metadataShapeOk
      ? `Validated ${metadataRecordCount} metadata record(s).`
      : `Metadata record at index ${invalidIndex} violates the V1 record contract.`;
  }

  checks.push(check('metadata-record-shape', metadataShapeOk, metadataShapeDetail));

  return Object.freeze({
    ok: checks.every((item) => item.ok),
    schemaVersion: db.verno,
    checkedAt: new Date().toISOString(),
    metadataRecordCount,
    checks: Object.freeze(checks),
  });
}

export async function assertKairosDatabaseIntegrity(db: KairosDatabase): Promise<DatabaseIntegrityReport> {
  const report = await inspectKairosDatabaseIntegrity(db);
  if (!report.ok) throw new DatabaseIntegrityError(report);
  return report;
}
