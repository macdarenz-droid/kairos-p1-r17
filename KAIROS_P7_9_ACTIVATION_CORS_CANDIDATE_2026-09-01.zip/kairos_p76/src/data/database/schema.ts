export const KAIROS_DATABASE_NAME = 'kairos';
export const KAIROS_DB_SCHEMA_VERSION = 1 as const;

export const KAIROS_V1_STORES = Object.freeze({
  metadata: '&key',
});

export interface DatabaseMetadataRecord {
  readonly key: string;
  readonly value: string;
  readonly updatedAt: string;
}
