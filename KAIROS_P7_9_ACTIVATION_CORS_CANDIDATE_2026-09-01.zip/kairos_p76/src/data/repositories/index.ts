import { kairosDatabase } from '../database/databaseLifecycle';
import type { KairosDatabase } from '../database/KairosDatabase';
import { MetadataRepository } from './MetadataRepository';

export interface KairosRepositories {
  readonly metadata: MetadataRepository;
}

export function createKairosRepositories(db: KairosDatabase): KairosRepositories {
  return Object.freeze({
    metadata: new MetadataRepository(db),
  });
}

export const kairosRepositories = createKairosRepositories(kairosDatabase);

export { MetadataRepository } from './MetadataRepository';

export { KAIROS_DEVICE_METADATA_PREFIX, isKairosDeviceScopedMetadataKey } from './metadataScope';
