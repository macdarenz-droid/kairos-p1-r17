import { Outlet } from 'react-router';
import { buildInfo } from './buildInfo';

export function AppShell() {
  return <div data-app="kairos"><header><strong>Kairos</strong></header><Outlet /><footer><small>{buildInfo.appVersion}</small></footer></div>;
}
