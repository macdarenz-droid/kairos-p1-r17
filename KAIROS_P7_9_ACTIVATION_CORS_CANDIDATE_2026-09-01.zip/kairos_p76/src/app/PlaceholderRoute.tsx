export function PlaceholderRoute({ title }: { title: string }) {
  return <main><h1>{title}</h1><p>This area is ready for a future Kairos patch.</p></main>;
}
