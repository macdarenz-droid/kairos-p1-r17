# KAIROS P18.13 — Lightweight Charts v5 Trend-Line Primitive Hit-Test Binding

## Authority
Base: canonical P18.12, promoted by GitHub Actions run #210 (`33819236565`) at head `969c3f9faeb8d26adf70f1956a37752e020e3488`.

## Controlled purpose
Bind the already-canonical P18.12 screen-space trend-line hit-test geometry to the existing P18.7/P18.8 provider primitive lifecycle without creating a second geometry owner or an interaction owner.

## Production change
`lightweightChartsV5TrendLinePrimitive.ts` now keeps the P18.5 projected segment snapshot that already feeds P18.6 rendering and exposes the provider `hitTest(x, y)` method over that same snapshot. A hit is adapted to the Lightweight Charts v5 primitive hover contract with `externalId`, `zOrder: normal`, pointer cursor, line-style hit priority, and primitive item type. `detached()` clears both rendered and hoverable presentation geometry.

## Official provider contract checked
Lightweight Charts v5.2 documents `ISeriesPrimitiveBase.hitTest(x, y)` as the primitive hook called during cursor movement; it returns the top-most `PrimitiveHoveredItem`. `PrimitiveHoveredItem` requires `externalId` and `zOrder`, and supports `cursorStyle`, `distance`, `hitTestPriority`, and `itemType`. `PrimitivePaneViewZOrder` accepts `bottom`, `normal`, or `top`.

## Ownership preserved
- P18.2: renderer-safe drawing projection input.
- P18.5: time/price -> screen coordinates.
- P18.6: Canvas rendering.
- P18.12: point-to-segment hit-test geometry and top-most resolution.
- P18.13: provider primitive hover-shape adaptation only.

## Regression evidence added
1. No hover item before projected geometry exists.
2. Canonical P18.12 hit becomes the provider primitive hover object.
3. Viewport reprojection refreshes the same geometry snapshot for rendering and hit testing.
4. Detach clears hover geometry.

## Explicit non-scope
No chart mouse/crosshair subscription, click selection, drag/edit state, toolbar, drawing-truth mutation, persistence, autoscale ownership, financial calculation, market acquisition, journal truth, or P19 risk/reward behavior.

## Local evidence
Dedicated P18.13 static verifier: PASS.
No claim of canonical TypeScript/build/unit/full-regression PASS is made locally. GitHub canonical gate remains authoritative.
