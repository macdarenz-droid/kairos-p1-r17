# KAIROS P12.7 — Journal History Closure / Orchestration Gate

## Status
HOLD pending canonical GitHub gate.

## Authoritative base
P12.6R1 Journal History Heavy Performance Canary Test Contract Repair — canonical PASS from run #66 / 33583877839.

## Objective
Close P12 Journal History only after proving that the independently gated query, persistence, presentation, filtering, compatibility and USER_HEAVY performance contracts compose coherently without creating a second calculation or storage owner.

## Research / controlling decision
The controlling Kairos roadmap places Journal History in P12 and Visual P&L in P13. The performance architecture requires index-backed journal queries plus measured journal first-render and filter-query canaries, with USER_HEAVY defined as 10,000+ trades. P12.6R1 now satisfies that performance evidence with 10,500 trades. Therefore the correct next dependency-ordered slice is a P12 closure gate, not an early P13 visual feature.

## Owner trace
IndexedDB/Dexie remains persistence authority. Trade repositories own indexed bounded retrieval. `listJournalHistory` owns Journal History aggregation and delegates derived financial truth to the P11 Calculation Brain. `JournalRoute` owns temporary filter/loading/request-sequence UI state and save-triggered refresh. `JournalHistoryList` is presentation only.

## Pre-change flow
Persisted trade -> indexed bounded trade repository query -> bounded child evidence hydration -> P11 `calculateTradeMetrics` -> immutable Journal History entry -> Journal route/list presentation. Status selection remains local UI state and delegates back into the indexed query owner. Successful P10 manual save commits first, then refreshes the active history filter.

## Controlled change
No production implementation changes.

Adds only:
- one P12 closure integration regression;
- one P12 static closure verifier;
- one package verification script entry;
- this closure report.

## Closure coverage
- newest-first bounded history remains repository/index owned;
- status filtering remains compound-index owned and bounded before hydration;
- child plan/execution/fee evidence is loaded only for selected trades;
- P11 remains sole financial metric owner;
- missing currency comparability remains unavailable rather than guessed;
- route has no direct IndexedDB/query ownership;
- current filter survives async races through latest-request-wins sequencing;
- successful manual save refreshes the active history;
- accessible native status filter and list semantics remain intact;
- schema/backup compatibility verifiers from P12.4 remain registered;
- USER_HEAVY remains 10,500 trades with bounded 100-row first render and status filter timing budgets.

## Persistence / migration
None. Database schema remains v3 and backup format remains v2-compatible as already gated in P12.4R4/P12.5 lineage.

## Security / theme / offline
No security, network, activation, theme-token, service-worker or deployment change. Journal History remains local-first/offline-capable through existing database owners.

## Non-scope
No charting, Visual P&L system, trade visualizer, market feed, drawing tools, new financial formula, FX conversion, pagination/infinite scroll, search, edit/delete history workflow, cloud sync or deployment change. Those are not required to close the current P12 slice and must not be pulled forward from later roadmap items.

## Promotion rule
P12.7 may close P12 only if the canonical GitHub gate passes exact scope, deterministic install, production build, full unit regression, the complete existing controlled verifier chain through P12.6R1, the new P12.7 closure verifier/test, and the explicit USER_HEAVY timing canary. Until then P12.6R1 remains authoritative.

## Next
Only after canonical PASS: mark P12 Journal History closed and allow the next controlled roadmap item, P13 Visual P&L System, to begin from the exact P12.7 PASS artifact.
