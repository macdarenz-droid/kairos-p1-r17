import { readFileSync } from 'node:fs';
const source=readFileSync('src/application/trade-visualizer/tradeVisualizerFacts.ts','utf8');
for(const required of ['plannedEntryPrice','plannedStopPrice','plannedTargetPrice',"execution.type === 'exit'",'executedExits','No candle/path']) if(!source.includes(required)) throw new Error(`missing ${required}`);
for(const forbidden of ['Number(','parseFloat(','parseInt(','decimalAdd','calculateTradeMetrics','indexedDB','Dexie','fetch(','WebSocket','exchangeRate']) if(source.includes(forbidden)) throw new Error(`ownership violation ${forbidden}`);
console.log('PASS P14.1 trade visualizer facts boundary verifier');
