import { describe, expect, it } from 'vitest';
import { projectTradeVisualizerFacts } from '../src/application/trade-visualizer';
import { parseDecimalString, type TradeExecutionRecord, type TradePlanRecord, type TradeRecord } from '../src/domain/trades';

function dec(v: string) { const r=parseDecimalString(v); if(!r.ok) throw new Error('bad fixture'); return r.value; }
const trade={id:'t1',symbol:'BTCUSD',marketType:'crypto',side:'long',status:'closed',source:'manual',openedAt:'2026-09-01T00:00:00Z',closedAt:'2026-09-02T00:00:00Z',createdAt:'2026-09-01T00:00:00Z',updatedAt:'2026-09-02T00:00:00Z'} as TradeRecord;

describe('P14.1 trade visualizer facts boundary',()=>{
  it('keeps planned levels separate and exposes only authoritative exit executions',()=>{
    const plan={id:'p1',tradeId:trade.id,plannedEntryPrice:dec('100'),plannedStopPrice:dec('90'),plannedTargetPrice:dec('120'),plannedQuantity:dec('2'),createdAt:'2026-09-01T00:00:00Z',updatedAt:'2026-09-01T00:00:00Z'} as TradePlanRecord;
    const executions=[
      {id:'e1',tradeId:trade.id,type:'entry',price:dec('101'),quantity:dec('2'),executedAt:'2026-09-01T01:00:00Z',createdAt:'2026-09-01T01:00:00Z'},
      {id:'e2',tradeId:trade.id,type:'exit',price:dec('115'),quantity:dec('1'),executedAt:'2026-09-01T03:00:00Z',createdAt:'2026-09-01T03:00:00Z'},
      {id:'e3',tradeId:trade.id,type:'exit',price:dec('118'),quantity:dec('1'),executedAt:'2026-09-02T00:00:00Z',createdAt:'2026-09-02T00:00:00Z'},
    ] as readonly TradeExecutionRecord[];
    const result=projectTradeVisualizerFacts(trade,[plan],executions);
    expect(result.planned).toEqual({entry:dec('100'),stop:dec('90'),target:dec('120')});
    expect(result.executedExits.map(x=>x.price)).toEqual([dec('115'),dec('118')]);
  });
  it('does not invent an exit for an open trade',()=>{
    const open={...trade,status:'open',closedAt:null} as TradeRecord;
    expect(projectTradeVisualizerFacts(open,[],[]).executedExits).toEqual([]);
  });
});
