import type {
  DecimalString,
  TradeExecutionRecord,
  TradePlanRecord,
  TradeRecord,
} from '../../domain/trades';

export interface TradeVisualizerPlannedLevels {
  readonly entry: DecimalString | null;
  readonly stop: DecimalString | null;
  readonly target: DecimalString | null;
}

export interface TradeVisualizerExecutedExit {
  readonly price: DecimalString;
  readonly quantity: DecimalString;
  readonly executedAt: string;
}

export interface TradeVisualizerFactsProjection {
  readonly tradeId: TradeRecord['id'];
  readonly symbol: string;
  readonly side: TradeRecord['side'];
  readonly status: TradeRecord['status'];
  readonly planned: TradeVisualizerPlannedLevels;
  readonly executedExits: readonly TradeVisualizerExecutedExit[];
}

/**
 * P14 fact boundary: logged trade facts only.
 *
 * Planned levels remain planned. Executed exits come only from authoritative
 * exit executions. No candle/path, live/current price, guessed exit, market
 * data, P&L arithmetic, or synthetic price history is created here.
 */
export function projectTradeVisualizerFacts(
  trade: TradeRecord,
  plans: readonly TradePlanRecord[],
  executions: readonly TradeExecutionRecord[],
): TradeVisualizerFactsProjection {
  const latestPlan = plans.length === 0
    ? null
    : plans.reduce((latest, candidate) =>
        candidate.updatedAt > latest.updatedAt ? candidate : latest);

  const executedExits = executions
    .filter((execution) => execution.type === 'exit')
    .map((execution) => Object.freeze({
      price: execution.price,
      quantity: execution.quantity,
      executedAt: execution.executedAt,
    }));

  return Object.freeze({
    tradeId: trade.id,
    symbol: trade.symbol,
    side: trade.side,
    status: trade.status,
    planned: Object.freeze({
      entry: latestPlan?.plannedEntryPrice ?? null,
      stop: latestPlan?.plannedStopPrice ?? null,
      target: latestPlan?.plannedTargetPrice ?? null,
    }),
    executedExits: Object.freeze(executedExits),
  });
}
