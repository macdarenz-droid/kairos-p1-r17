import type { KairosDatabase } from '../../data/database';
import { createKairosRepositories } from '../../data/repositories';
import { calculateTradeMetrics, type TradeMetrics, type TradeMetricsResult } from '../../domain/calculations';
import type { TradeExecutionRecord, TradeFeeRecord, TradePlanRecord, TradeRecord } from '../../domain/trades';

export interface JournalHistoryEntry {
  readonly trade: TradeRecord;
  readonly plans: readonly TradePlanRecord[];
  readonly executions: readonly TradeExecutionRecord[];
  readonly fees: readonly TradeFeeRecord[];
  readonly metrics: TradeMetrics | null;
  readonly metricsError: Extract<TradeMetricsResult, { readonly ok: false }>['reason'] | null;
}

function historyTimestamp(trade: TradeRecord): string {
  return trade.closedAt ?? trade.openedAt ?? trade.createdAt;
}

export async function listJournalHistory(db: KairosDatabase): Promise<readonly JournalHistoryEntry[]> {
  const repositories = createKairosRepositories(db);
  const trades = await repositories.trades.listAll();

  const entries = await Promise.all(trades.map(async (trade): Promise<JournalHistoryEntry> => {
    const [plans, executions, fees] = await Promise.all([
      repositories.tradePlans.listByTradeId(trade.id),
      repositories.tradeExecutions.listByTradeId(trade.id),
      repositories.tradeFees.listByTradeId(trade.id),
    ]);
    const metricsResult = calculateTradeMetrics(trade.side, executions, undefined, fees);
    return Object.freeze({
      trade,
      plans: Object.freeze(plans),
      executions: Object.freeze(executions),
      fees: Object.freeze(fees),
      metrics: metricsResult.ok ? metricsResult.value : null,
      metricsError: metricsResult.ok ? null : metricsResult.reason,
    });
  }));

  entries.sort((a, b) => {
    const byTime = historyTimestamp(b.trade).localeCompare(historyTimestamp(a.trade));
    return byTime || b.trade.id.localeCompare(a.trade.id);
  });
  return Object.freeze(entries);
}
