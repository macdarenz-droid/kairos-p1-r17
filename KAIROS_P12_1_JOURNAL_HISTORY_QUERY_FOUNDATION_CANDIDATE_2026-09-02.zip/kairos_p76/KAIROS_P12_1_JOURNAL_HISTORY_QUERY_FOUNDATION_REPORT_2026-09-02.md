# KAIROS P12.1 Journal History Query Foundation Report — 2026-09-02

## Status
HOLD pending canonical GitHub gate.

## Authoritative base
KAIROS_P11_24_CALCULATION_BRAIN_CLOSURE_CANDIDATE_2026-09-02.zip — P11 Calculation Brain closure PASS.

## Objective
Start P12 Journal History with the read-model/query dependency, before adding history UI. Build one application-owned history query that reads the existing P9 persistence aggregate and reuses P11 Calculation Brain outputs without creating a second database or calculation owner.

## Research
Current Dexie documentation was rechecked before implementation. Dexie continues to support repository/query composition over its existing singleton IndexedDB owner; its React guidance recommends reactive live queries when UI observation is later introduced. P12.1 intentionally does not add `dexie-react-hooks` or UI reactivity yet because this sub-patch is the history read foundation only.

## Owner trace
P9 trade schema/repositories -> P12.1 journal history query -> P11 `calculateTradeMetrics` -> future P12 renderer.

## Pre-change flow
P10 can persist manual trades and P11 can calculate metrics, but there was no application-level query that reconstructed journal history aggregates for a renderer.

## Change
- Added `src/application/journal/historyQuery.ts`.
- Added `src/application/journal/index.ts`.
- Added P12.1 regression tests and static verifier.
- Registered `verify:p12:journal-history-query`.

The query returns every persisted trade with its plans, executions, fees, and available P11 metrics, ordered newest-first by closed/opened/created chronology with stable-ID tie breaking.

## Non-scope
No history UI, filtering, search, pagination, edit/delete, schema/migration changes, live-query hook, visual P&L, charting, market data, new financial formulas, FX assumptions, or P13 work.

## Data/state flow
IndexedDB -> existing P9 repositories -> P12.1 `listJournalHistory()` -> existing P11 `calculateTradeMetrics()` -> immutable history entries -> future P12 consumer.

## Persistence
Read-only. No schema or migration change.

## Security
No new network or secret surface.

## Theme
None; no renderer introduced.

## Offline
Fully local; reads existing IndexedDB state.

## Tests
- Reconstructs multiple trade aggregates and orders them newest-first.
- Reuses P11 gross-P&L/fee evidence.
- Proves net P&L stays unavailable when gross-P&L currency evidence is absent.
- Preserves a trade whose persisted execution evidence is invalid and exposes the P11 error rather than silently dropping the record.

## Performance
One trade-list query followed by per-trade aggregate reads. This is deliberately correct-first for the initial history foundation; pagination/index optimization is deferred until the P12 history UI/query requirements are defined and measured.

## Known limitations
No reactive UI subscription or pagination yet.

## Real-device status
Not required: no UI change.

## Result
HOLD until canonical GitHub gate passes build, full tests, P1-P11.24 regression, and P12.1 verification.
