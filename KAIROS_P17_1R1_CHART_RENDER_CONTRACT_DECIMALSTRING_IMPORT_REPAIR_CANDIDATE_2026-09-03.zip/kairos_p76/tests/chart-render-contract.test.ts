import { describe, expect, it } from 'vitest';
import { createChartRenderModel } from '../src/features/chart';

describe('P17.1 chart render contract', () => {
  it('preserves market-reference and journal-execution truths as separate inputs', () => {
    const model = createChartRenderModel({
      market: { venue: 'binance-spot', instrument: 'BTCUSDT', source: 'market-reference' },
      series: { kind: 'price-line', points: [{ timestamp: '2026-09-03T00:00:00.000Z', price: '100.00' }] },
      journalExecutions: [{ executionId: 'execution-1', timestamp: '2026-09-03T00:00:01.000Z', price: '99.50', source: 'journal-execution' }],
    });
    expect(model.market.source).toBe('market-reference');
    expect(model.journalExecutions[0]?.source).toBe('journal-execution');
  });
});
