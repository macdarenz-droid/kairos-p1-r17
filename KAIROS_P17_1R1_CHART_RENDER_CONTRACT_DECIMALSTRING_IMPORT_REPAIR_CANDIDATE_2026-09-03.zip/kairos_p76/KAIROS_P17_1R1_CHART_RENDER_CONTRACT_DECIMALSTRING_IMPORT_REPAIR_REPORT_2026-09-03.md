# KAIROS P17.1R1 — Chart Render Contract DecimalString Import Repair

Canonical P17.1 Run #170 failed at build with TS2307 because the chart contract imported DecimalString from a non-existent `../../services/market-data/types` path.

P17.1R1 changes only the import owner to the canonical existing trade-domain export: `../../domain/trades`. No chart behavior, market data, journal truth, persistence, reconnect, timers, credentials, orders, or later-phase scope changes are introduced.

Local static/verifier checks are required; canonical CI remains authoritative.
