import { existsSync, readFileSync } from 'node:fs';
for (const file of ['src/features/chart/chartRenderContract.ts','src/features/chart/index.ts','tests/chart-render-contract.test.ts']) {
  if (!existsSync(file)) throw new Error(`Missing P17.1 file: ${file}`);
}
const source=readFileSync('src/features/chart/chartRenderContract.ts','utf8');
for (const token of ["from '../../domain/trades'","source: 'market-reference'","source: 'journal-execution'",'DecimalString','ChartRenderModel']) {
  if (!source.includes(token)) throw new Error(`Missing P17.1 token: ${token}`);
}
for (const forbidden of ['indexedDB','localStorage','Dexie','WebSocket','setTimeout(','setInterval(','Math.random','decimal.js','subscribeBinance','executeMarketDataReconnect']) {
  if (source.includes(forbidden)) throw new Error(`P17.1 ownership violation: ${forbidden}`);
}
console.log('P17.1 chart render contract foundation verifier PASS');
