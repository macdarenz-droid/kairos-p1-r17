import fs from 'node:fs';

const sourceFile = 'src/domain/calculations/tradeMetrics.ts';
const testFile = 'tests/trade-metrics-fee-evidence.test.ts';
const legacyTradeMetricsTestFile = 'tests/trade-metrics.test.ts';
for (const file of [sourceFile, testFile, legacyTradeMetricsTestFile]) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const source = fs.readFileSync(sourceFile, 'utf8');
for (const token of [
  'calculateTotalFees',
  'fees?: readonly TradeFeeRecord[]',
  'totalFees: DecimalString | null',
  'totalFeesCurrency: string | null',
  'hasTotalFees: boolean',
  "'invalid-fee-decimal'",
  "'mixed-fee-currency'",
]) {
  if (!source.includes(token)) throw new Error(`Missing P11.18R2 contract: ${token}`);
}

if (!source.includes('netPnl: null') || !source.includes('hasNetPnl: false')) {
  throw new Error('P11.18R2 must not wire net P&L yet.');
}
if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error('P11.18R2 must not introduce native numeric authority.');
}
for (const forbidden of ['exchangeRate', 'currencyConversion', 'calculateNetPnl(', 'Dexie', 'indexedDB', 'fetch(', 'WebSocket']) {
  if (source.includes(forbidden)) throw new Error(`P11.18R2 out-of-scope owner detected: ${forbidden}`);
}
const legacyTest = fs.readFileSync(legacyTradeMetricsTestFile, 'utf8');
if (!legacyTest.includes('totalFeesCurrency: null')) {
  throw new Error('P11.18R2 legacy TradeMetrics expectation must preserve explicit null fee currency evidence.');
}
console.log('P11.18R2 TradeMetrics fee evidence verification PASS');
