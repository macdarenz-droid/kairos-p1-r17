# Kairos P18.33 — Chart Drawing Collection

## Authority
Built from canonical P18.32 authority (Kairos Controlled Roadmap Gate #238, run 33889855828, head 9e2c11a74ec80452de443c8138dc1b50d45d3b74).

## Added responsibility
P18.33 introduces one provider-neutral runtime owner for the committed drawing set:

1. Start one active drawing collection empty.
2. Add only already-constructed P18.1 `ChartDrawing` values.
3. Preserve insertion order for presentation consumers.
4. Resolve committed drawings by exact caller-owned `ChartDrawingId`.
5. Reject duplicate identities without replacing existing committed truth.
6. Destroy idempotently and fail closed on later access.

## Ownership preserved
- P18.1 remains drawing shape/identity contract owner.
- P18.23/P18.24 remain sole interaction transition/current-state owners.
- P18.28R1 remains sole ephemeral draft-anchor owner.
- P18.29 remains draft-interaction lifecycle coordinator.
- P18.31 remains sole draft-to-trend-line constructor.
- P18.32 remains sole draft commit coordinator.
- P18.33 owns only the committed in-memory drawing collection.
- P20 remains the future saved-analysis/persistence boundary.

## Explicit non-scope
No ID allocation; no draft construction; no interaction dispatch; no edit/delete mutation; no persistence/restore; no provider APIs; no coordinate conversion; no projection/rendering; no toolbar/UI state; no undo/redo; no new drawing kinds; no Risk/Reward/P19 semantics; no journal truth; no calculations/navigation/toolchain migration.
