# KAIROS P11.19 — Net P&L Currency Comparability Policy

Status: HOLD pending canonical GitHub gate.

## Authoritative base
P11.18R2 TradeMetrics Fee Evidence Wiring Compatibility Repair.

## Objective
Add the Calculation Engine policy boundary required before TradeMetrics may compose gross P&L and fees into net P&L. Kairos must never silently subtract unlike or unknown monetary currencies.

## Architecture basis
The controlling handoff requires derived financial metrics to originate in the Calculation Engine, treats missing financial evidence as unknown rather than zero, and explicitly forbids assuming a missing FX rate is 1.0. Instrument/currency ownership remains outside random UI code.

## Contract
`assessNetPnlCurrencyCompatibility(totalFees, grossPnlCurrency, totalFeesCurrency)`:
- validates fee amount through the locked decimal kernel;
- authoritative zero fees are unit-neutral and may be composed without currency invention;
- non-zero fees require explicit gross-P&L currency evidence;
- non-zero fees require explicit fee currency evidence;
- non-zero fees require exact matching currency evidence;
- unlike currencies return `currency-mismatch`;
- malformed decimals return `invalid-decimal`;
- performs no FX conversion or currency inference.

## Owner trace
Calculation Engine owns this pure comparability policy. It does not write persistence, call network providers, inspect UI state, or modify TradeMetrics yet.

## Non-scope
- no `netPnl` wiring into TradeMetrics;
- no FX conversion;
- no account/quote-currency inference;
- no P33 Currency Engine work;
- no persistence/schema/UI/navigation changes.

## Controlled changed files
1. `KAIROS_P11_19_NET_PNL_CURRENCY_COMPARABILITY_POLICY_REPORT_2026-09-01.md`
2. `package.json`
3. `scripts/verify-p11-net-pnl-currency-policy.mjs`
4. `src/domain/calculations/index.ts`
5. `src/domain/calculations/netPnlCurrencyPolicy.ts`
6. `tests/net-pnl-currency-policy.test.ts`

## Tests
Dedicated tests cover zero-fee unit neutrality, same-currency non-zero evidence, missing gross currency, missing fee currency, currency mismatch, and malformed decimals.

## Performance / persistence / security
Pure synchronous calculation only; no persistence, observers, timers, network, UI, or new main-thread lifecycle machinery.

## Result
HOLD pending canonical GitHub gate.
