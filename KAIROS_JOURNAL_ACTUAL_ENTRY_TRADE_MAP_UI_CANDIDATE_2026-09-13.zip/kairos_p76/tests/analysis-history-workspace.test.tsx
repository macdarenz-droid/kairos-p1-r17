import { afterEach, expect, it, vi } from 'vitest';
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { AnalysisHistoryWorkspace, ANALYSIS_HISTORY_REQUEST_TIMEOUT_MS } from '../src/app/AnalysisHistoryWorkspace';
import type { MarketCandleHistoryRequest, MarketCandleHistoryResult } from '../src/services/market-data/MarketCandleHistoryPort';
import type { LiveMarketUniverseInstrumentMetadataFact } from '../src/services/market-data/liveMarketUniverseInstrumentMetadataFact';
vi.mock('../src/app/AnalysisCandleCanvas', () => ({ AnalysisCandleCanvas: ({ snapshot }: { snapshot: { request: MarketCandleHistoryRequest } }) => <div data-testid="candle-canvas">{snapshot.request.instrument.symbol}/{snapshot.request.interval}</div> }));
const instrument = (symbol: string): LiveMarketUniverseInstrumentMetadataFact => ({ instrument: { venue: 'binance-spot', symbol }, baseAsset: symbol === 'ETHUSDT' ? 'ETH' : 'BTC', quoteAsset: 'USDT', tradingEnabled: true });
const facts = [instrument('BTCUSDT'), instrument('ETHUSDT')];
const ok = (request: MarketCandleHistoryRequest): MarketCandleHistoryResult => ({ ok: true, snapshot: { source: 'market-reference', timeZone: 'UTC', request, observedAt: '2026-09-12T00:00:00.000Z', candles: [] } });
function deferred<T>() { let resolve!: (value: T) => void; const promise = new Promise<T>(r => { resolve = r; }); return { promise, resolve }; }
function ports() { return { metadata: { acquireInstrumentMetadata: vi.fn(async () => ({ ok: true as const, facts })) }, history: { acquireHistory: vi.fn(async (request: MarketCandleHistoryRequest, _options?: { signal?: AbortSignal }) => ok(request)) } }; }
async function select(symbol = 'ETHUSDT', interval = '5m') {
  await waitFor(() => expect(screen.getByLabelText('Chart symbol')).toBeEnabled());
  fireEvent.change(screen.getByLabelText('Chart symbol'), { target: { value: symbol } });
  fireEvent.change(screen.getByLabelText('Timeframe'), { target: { value: interval } });
}
afterEach(() => { cleanup(); vi.restoreAllMocks(); vi.useRealTimers(); });

it('requires explicit symbol and interval, uses exact metadata and never infers a default or alias', async () => {
  const p = ports(); render(<AnalysisHistoryWorkspace ports={p} />);
  await waitFor(() => expect(screen.getByLabelText('Chart symbol')).toBeEnabled());
  expect(p.history.acquireHistory).not.toHaveBeenCalled();
  expect(screen.queryByRole('option', { name: /^BTCUSD ·/ })).toBeNull();
  fireEvent.change(screen.getByLabelText('Chart symbol'), { target: { value: 'ETHUSDT' } });
  expect(p.history.acquireHistory).not.toHaveBeenCalled();
  fireEvent.change(screen.getByLabelText('Timeframe'), { target: { value: '1M' } });
  await screen.findByText('No candles were returned for this selection.');
  expect(p.history.acquireHistory).toHaveBeenCalledWith({ instrument: facts[1].instrument, interval: '1M', limit: 500 }, { signal: expect.any(AbortSignal) });
});
it('excludes halted, foreign and duplicate instrument identities', async () => {
  const p = ports(); p.metadata.acquireInstrumentMetadata.mockResolvedValue({ ok: true, facts: [...facts, instrument('BTCUSDT'), { ...instrument('HALTED'), tradingEnabled: false }, { ...instrument('OTHER'), instrument: { venue: 'other', symbol: 'OTHER' } }] });
  render(<AnalysisHistoryWorkspace ports={p} />);
  await waitFor(() => expect(screen.getByLabelText('Chart symbol')).toBeEnabled());
  const select = screen.getByLabelText('Chart symbol') as HTMLSelectElement;
  expect([...select.options].map(o => o.value)).toEqual(['', 'ETHUSDT']);
});
it('aborts superseded history, hides stale results immediately and ignores late responses', async () => {
  const p = ports(), first = deferred<MarketCandleHistoryResult>(), second = deferred<MarketCandleHistoryResult>();
  p.history.acquireHistory.mockImplementationOnce(() => first.promise).mockImplementationOnce(() => second.promise);
  render(<AnalysisHistoryWorkspace ports={p} />); await select();
  const oldSignal = p.history.acquireHistory.mock.calls[0][1]!.signal!;
  fireEvent.change(screen.getByLabelText('Chart symbol'), { target: { value: 'BTCUSDT' } });
  expect(oldSignal.aborted).toBe(true);
  await act(async () => second.resolve(ok(p.history.acquireHistory.mock.calls[1][0])));
  await screen.findByText('No candles were returned for this selection.');
  await act(async () => first.resolve({ ok: false, reason: 'transport-failed' }));
  expect(screen.queryByRole('alert')).toBeNull();
  expect(p.history.acquireHistory).toHaveBeenCalledTimes(2);
});
it('rejects a returned snapshot for a different instrument or interval', async () => {
  const p = ports(); p.history.acquireHistory.mockImplementation(async request => ok({ ...request, instrument: facts[0].instrument }));
  render(<AnalysisHistoryWorkspace ports={p} />); await select();
  expect(await screen.findByRole('alert')).toHaveTextContent('Candles are unavailable');
  expect(screen.queryByTestId('candle-canvas')).toBeNull();
});
it('shows rate limits and refreshes only on an explicit action', async () => {
  const p = ports(); p.history.acquireHistory.mockResolvedValueOnce({ ok: false, reason: 'http-error', status: 429, retryAfter: '30' });
  render(<AnalysisHistoryWorkspace ports={p} />); await select();
  expect(await screen.findByRole('alert')).toHaveTextContent('limiting requests');
  fireEvent.focus(window); fireEvent(window, new Event('online'));
  expect(p.history.acquireHistory).toHaveBeenCalledTimes(1);
  fireEvent.click(screen.getByRole('button', { name: 'Refresh candles' }));
  await screen.findByText('No candles were returned for this selection.');
  expect(p.history.acquireHistory).toHaveBeenCalledTimes(2);
});
it('times out an uncooperative history request and rejects its late success', async () => {
  const p = ports(), pending = deferred<MarketCandleHistoryResult>();
  p.history.acquireHistory.mockImplementation(() => pending.promise);
  render(<AnalysisHistoryWorkspace ports={p} />); await select();
  vi.useFakeTimers();
  // Restart under the fake clock to exercise the request-owned deadline.
  fireEvent.change(screen.getByLabelText('Timeframe'), { target: { value: '15m' } });
  await act(async () => { vi.advanceTimersByTime(ANALYSIS_HISTORY_REQUEST_TIMEOUT_MS); });
  expect(screen.getByRole('alert')).toHaveTextContent('timed out');
  const call = p.history.acquireHistory.mock.calls[1]; expect(call[1]!.signal!.aborted).toBe(true);
  await act(async () => pending.resolve(ok(call[0])));
  expect(screen.getByRole('alert')).toHaveTextContent('timed out');
});
it('aborts metadata and history on unmount without processing late completion', async () => {
  const p = ports(), pending = deferred<MarketCandleHistoryResult>(); p.history.acquireHistory.mockImplementation(() => pending.promise);
  const ui = render(<AnalysisHistoryWorkspace ports={p} />); await select();
  const call = p.history.acquireHistory.mock.calls[0]; ui.unmount();
  expect(call[1]!.signal!.aborted).toBe(true);
  await act(async () => pending.resolve(ok(call[0])));
  expect(document.querySelector('.kairos-analysis-chart')).toBeNull();
});
it('offers metadata retry and keeps the chart usable without any journal dependency', async () => {
  const p = ports(); p.metadata.acquireInstrumentMetadata.mockRejectedValueOnce(new Error('offline'));
  render(<AnalysisHistoryWorkspace ports={p} />);
  expect(await screen.findByRole('alert')).toHaveTextContent('Supported symbols are unavailable');
  fireEvent.click(screen.getByRole('button', { name: 'Retry symbols' })); await select();
  await screen.findByText('No candles were returned for this selection.');
  expect(p.metadata.acquireInstrumentMetadata).toHaveBeenCalledTimes(2);
});
