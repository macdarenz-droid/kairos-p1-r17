import { readFileSync } from 'node:fs';
const adapter = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hPublicRestBaselineAcquisitionAdapter.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_13_BINANCE_SPOT_24H_PUBLIC_REST_BASELINE_ACQUISITION_ADAPTER_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');
for (const token of [
  'createBinanceSpot24hPublicRestBaselineAcquisitionPort(',
  'LiveMarketSummaryBaselineAcquisitionPort',
  'composeBinanceSpot24hPublicRestBaselineRoundTrip(',
  'validateLiveMarketSummaryBaselineSuccess(scope, result.delivery)',
  "return { ok: false, reason: 'acquisition-failed' }",
  'readObservedAt()',
  'options,',
]) if (!adapter.includes(token)) throw new Error(`P21.13 adapter evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpot24hPublicRestBaselineAcquisitionAdapter';")) throw new Error('P21.13 adapter export missing');
for (const forbidden of [
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'new Response(', 'new AbortController(',
  'AbortSignal.any(', 'AbortSignal.timeout(', 'setTimeout(', 'setInterval(', 'indexedDB',
]) if (adapter.includes(forbidden)) throw new Error(`P21.13 broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'Canonical P21.4 defines `LiveMarketSummaryBaselineAcquisitionPort.acquireBaseline(scope, options)`',
  'Canonical P21.12 explicitly records cancellation propagation as the smallest prerequisite before a concrete P21.4 adapter.',
  'No concrete `fetch`/XHR/WebSocket/browser transport',
  'No `AbortController` creation',
  'No retry/backoff/throttle/rate-limit',
  'No market-universe selection/ranking',
  'No market state accumulator',
  'No Live Crypto Bubble Map sizing',
  'No Your Trades Bubble Map',
]) if (!report.includes(token)) throw new Error(`P21.13 report evidence missing: ${token}`);
console.log('P21.13 Binance Spot baseline acquisition adapter verification passed.');
