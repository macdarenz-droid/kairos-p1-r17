import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpotExchangeInfoPublicRestRequest.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_BINANCE_SPOT_EXCHANGE_INFO_PUBLIC_REST_REQUEST_DESCRIPTOR_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');

for (const token of [
  "BINANCE_SPOT_PUBLIC_REST_MARKET_DATA_BASE_URL",
  "'/api/v3/exchangeInfo'",
  "method: 'GET'",
  "query: ''",
  'describeBinanceSpotExchangeInfoPublicRestRequest()',
  'BINANCE_SPOT_VENUE',
]) if (!source.includes(token)) throw new Error(`exchangeInfo request descriptor evidence missing: ${token}`);

if (!index.includes("export * from './providers/binance/binanceSpotExchangeInfoPublicRestRequest';")) {
  throw new Error('exchangeInfo request descriptor barrel export missing');
}

for (const forbidden of [
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'JSON.parse(', 'baseAsset:', 'quoteAsset:', 'tradingEnabled:',
  'USDT', 'stablecoin', '.sort(', 'Top 30', 'topN', 'setTimeout(', 'setInterval(', 'indexedDB',
]) if (source.includes(forbidden)) throw new Error(`request descriptor broadened into forbidden scope: ${forbidden}`);

for (const token of [
  'No fetch/XHR/WebSocket/browser transport',
  'No JSON parsing',
  'No mapping to `LiveMarketUniverseInstrumentMetadataFact`',
  'No caching',
  'No USDT eligibility filtering',
  'No freshness changes',
  'No Your Trades/journal',
]) if (!report.includes(token)) throw new Error(`request descriptor report evidence missing: ${token}`);

console.log('Binance Spot exchangeInfo public REST request descriptor verification passed.');
