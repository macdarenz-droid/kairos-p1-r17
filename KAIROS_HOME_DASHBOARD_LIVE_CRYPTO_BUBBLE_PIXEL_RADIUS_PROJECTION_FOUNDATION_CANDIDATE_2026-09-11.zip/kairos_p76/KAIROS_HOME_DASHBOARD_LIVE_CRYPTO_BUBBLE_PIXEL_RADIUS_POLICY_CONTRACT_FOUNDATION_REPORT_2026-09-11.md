# Kairos Home Dashboard Live Crypto Bubble Pixel-Radius Policy Contract Foundation — 2026-09-11

## Authority

This candidate starts only from the exact Gate373 canonical GOLDEN candidate `KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_HOME_ROUTE_RADIUS_SCALE_TEXT_RUNTIME_INTEGRATION_AMENDMENT_CANDIDATE_2026-09-11.zip`, size `1,726,756` bytes, SHA-256 `2097fc3a416362e7cbeca85eb8b0dc1fb6878c57d6c207c560f43e182e9d05e3`, root exactly `kairos_p76/`.

Gate373 canonically brings the configured-browser normalized-radius evidence runtime to `HomeRoute`. Released radius-scale ownership deliberately stops before concrete pixel sizing. Current source and generic design-system geometry tokens provide no authoritative Live Crypto Bubble minimum/maximum radius values, responsive breakpoints, collision/packing policy or label-fit policy. Those values must not be guessed.

## Released responsibility

`src/application/dashboard/homeDashboardLiveCryptoBubblePixelRadiusPolicy.ts` adds only a caller-owned pixel-radius **policy contract and validator** for a future renderer boundary.

The contract carries `minimumRadiusCssPixels` and `maximumRadiusCssPixels`. The validator:

- accepts only finite non-negative caller-owned values;
- rejects a maximum below the minimum;
- accepts equal bounds because variation itself remains caller policy;
- preserves a valid policy by exact reference; and
- never supplies, clamps, swaps or defaults either bound.

CSS-pixel units establish only the renderer-facing coordinate contract; no actual size values are selected by this slice.

## Explicit non-scope

- No default minimum or maximum Bubble radius values.
- No responsive breakpoints or viewport/device measurements.
- No interpolation from released `radiusScale` and no radius arithmetic.
- No collision, packing, layout, label-fit, hit-target or interaction behavior.
- No SVG/canvas/DOM/React renderer and no `HomeRoute` mutation.
- No palette, CSS, theme, opacity/dimming or motion.
- No provider/request/acquisition/freshness/ranking/Top-N/stablecoin changes.
- No persistence/IndexedDB/Saved Analysis.
- No Your Trades, journal, chart, Risk/Reward or Calculation Brain ownership.

Live Crypto Bubble and Your Trades Bubble remain separate truth domains.

## Why this slice is dependency-safe

The released normalized radius scale already expresses relative Bubble size without pixels. A future pixel projection cannot be validated or composed safely until its caller-owned bounds have an explicit contract. This foundation introduces that missing contract without choosing the material product/design values that remain unresolved.

A later slice may consume this contract together with released normalized `radiusScale`, but no concrete default values may be introduced until authoritative product/design policy supplies them.
