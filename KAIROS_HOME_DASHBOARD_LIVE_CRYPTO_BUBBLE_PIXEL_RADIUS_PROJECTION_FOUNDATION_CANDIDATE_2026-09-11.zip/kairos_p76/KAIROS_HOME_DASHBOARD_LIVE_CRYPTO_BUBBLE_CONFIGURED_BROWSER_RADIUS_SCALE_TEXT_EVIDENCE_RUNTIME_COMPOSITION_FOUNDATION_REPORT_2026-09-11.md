# Kairos Home Dashboard Live Crypto Bubble Configured Browser Radius-Scale Text-Evidence Runtime Composition Foundation

## Authority

Base: canonical Gate371 normalized radius-scale textual-evidence presentation foundation.

## Responsibility

This slice owns exactly one thin configured browser radius-scale textual-evidence runtime composition edge between the released Gate369 configured browser radius-scale hook and the released Gate371 normalized radius textual-evidence presenter.

`HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime`:
- accepts one exact caller-owned product configuration through `HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration`;
- delegates that exact configuration once to `useHomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleViewModel`;
- passes the exact returned `HomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel` reference once to `HomeDashboardLiveCryptoBubbleRadiusScaleTextEvidence`; and
- returns the released presenter without transforming radius truth or runtime evidence.

Gate369 remains configured browser radius-scale hook owner. Gate371 remains normalized radius textual-evidence presenter owner. This boundary adds no second owner for either responsibility.

## Explicit non-scope

No concrete stablecoin exclusion, neutral-movement, Top-N, or lifecycle value is selected here. No state/effects/memo/callbacks. No clocks, timers, page visibility, provider request/acquisition/retry/cadence, or freshness ownership. No radius arithmetic, validation, normalization, cloning, fallback geometry, or hidden defaults. No concrete pixel radius, breakpoint, collision, packing, or label-fit value is selected here. No SVG/canvas/bubble layout. No CSS/theme/palette/dimming/motion. No `HomeRoute` mutation. No persistence/Saved Analysis. No Your Trades Bubble Map, journal/trade truth, chart, Risk/Reward, Calculation Brain, navigation, or transitions.

## Dependency ownership preserved

The exact caller-owned product configuration remains caller truth. Gate360 remains product-configuration-to-runtime-options composition owner below the released configured hook chain. Gate358 remains browser observation/evaluation clock owner. Gate369 remains the configured browser radius-scale hook owner. Gate371 remains the pure textual presenter of released normalized radius evidence. Existing owners retain Top-30, browser lifecycle, acquisition cadence, universe/freshness policy, provider/data acquisition, React runtime state, presentation mapping, area-weight/radius-scale arithmetic, and lower-layer market truth.

This slice closes only the unowned technical seam between the released configured browser radius-scale hook and the released normalized-radius textual presenter. `HomeRoute` wiring and any future pixel sizing/layout policy remain separate future responsibilities. No concrete pixel radius, breakpoint, collision, packing, or label-fit value is authorized by this slice and none is guessed.
