# Kairos Home Dashboard Live Crypto Bubble Browser Text-Evidence Runtime Composition Foundation

## Authority

Base: canonical Gate358 browser wall-clock source foundation.

## Responsibility

This slice owns exactly one thin React composition edge between the released Gate358 browser wall-clock sources and the released Gate357 textual-evidence runtime component.

`HomeDashboardLiveCryptoBubbleBrowserTextEvidenceRuntime`:
- accepts one exact caller-owned `HomeDashboardLiveCryptoBubbleReactRuntimeBindingOptions` value;
- injects `readHomeDashboardLiveCryptoBubbleBrowserObservedAt` unchanged as Gate357 `readObservedAt`;
- injects `readHomeDashboardLiveCryptoBubbleBrowserEvaluationTimeMs` unchanged as Gate357 `readEvaluationTimeMs`;
- forwards the exact options reference unchanged; and
- renders the Gate357 component exactly once.

The component does not read either clock itself. The released Gate358 sources remain separate and are read only by their downstream owners when requested.

## Explicit non-scope

No own React state/effects/memo/callbacks. No timers, animation frames, `Date.now()` or `new Date()`. No provider/request/acquisition/retry/cadence ownership. No freshness thresholds or classification. No universe eligibility, stablecoin exclusion contents, ranking/tie-break/Top-N values. No neutral movement threshold or palette/design defaults. No arithmetic. No CSS/theme/dimming. No Bubble radius/layout/collision/labels/SVG/canvas/interactions. No `HomeRoute` or router wiring. No persistence/Saved Analysis. No Your Trades Bubble Map, journal/trade truth, chart, Risk/Reward, Calculation Brain, navigation, or transitions.

## Dependency ownership preserved

Gate351 remains React lifecycle/state owner. Gate352 remains normalized area-weight arithmetic owner. Gate354 remains pure view-model owner. Gate355 remains the area-weight hook composition owner. Gate356 remains semantic textual presentation owner. Gate357 remains injected runtime-to-presenter composition owner. Gate358 remains browser wall-clock source owner. This slice only binds the exact Gate358 source references into Gate357 while leaving runtime configuration caller-owned.
