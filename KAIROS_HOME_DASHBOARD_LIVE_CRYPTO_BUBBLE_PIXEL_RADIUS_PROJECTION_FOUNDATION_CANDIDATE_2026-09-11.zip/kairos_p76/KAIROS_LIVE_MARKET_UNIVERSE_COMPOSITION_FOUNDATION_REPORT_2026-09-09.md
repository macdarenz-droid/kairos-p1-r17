# KAIROS Live Market Universe Composition Foundation

Base: exact canonical Gate #333 GOLDEN Home Dashboard live-market browser lifecycle adapter candidate.

This slice owns one provider-neutral Live Market Universe composition responsibility only. It consumes already-authoritative `LiveMarketUniverseInstrumentMetadataFact` values and already-available `LiveMarketSummaryFact` values, plus caller-owned stablecoin-exclusion configuration and optional Top-N count. It delegates to the released eligibility Gate326 policy, performs only the exact instrument-identity join needed to associate eligible metadata with matching summary facts, delegates to the released quote-volume ordering Gate327 policy, delegates to the released Top-N selection Gate328 policy, and returns only the selected `MarketDataInstrument` scope.

Missing summary facts are omitted; composition never synthesizes market facts. Instrument identity follows the released market-data convention of trimmed venue plus trimmed symbol. Primitive eligibility, ordering, tie-break, and Top-N policy are not duplicated here.

Explicit non-scope: No provider transport, request execution, response decoding, or mapping. No observedAt/freshness/session ownership. No freshness/cadence/lifecycle, visibility, timers, abort, polling, or scheduling. No persistence or IndexedDB. No React/Home/Bubble presentation, geometry, size/color, interaction, navigation, chart, or transitions. No Your Trades, journal, or Saved Analysis truth.
