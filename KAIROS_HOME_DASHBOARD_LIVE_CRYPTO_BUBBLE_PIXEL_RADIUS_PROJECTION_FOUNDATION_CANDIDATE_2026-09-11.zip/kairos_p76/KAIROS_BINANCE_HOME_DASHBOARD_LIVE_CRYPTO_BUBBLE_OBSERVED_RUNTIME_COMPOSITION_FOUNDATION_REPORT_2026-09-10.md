# Binance Home Dashboard Live Crypto Bubble Observed Runtime Composition Foundation

## Authority
Base: exact canonical Gate344 Home Dashboard Live Crypto Bubble metric-observation bridge candidate, promoted by `Kairos Controlled Roadmap Gate` #344 / run `34436437129`.

## Source-proven responsibility
Gate341 already owns the app-level Binance Home live-market observed runtime and accepts caller-owned acquisition `readObservedAt`, freshness `readEvaluationTimeMs`, universe options, browser lifecycle options, and one raw Gate340 freshness-observation sink. Gate344 now owns the provider-neutral adapter that turns a caller-owned Bubble metric observation sink into that exact Gate340-compatible sink. No production owner composes those two released seams, while `HomeRoute` remains presentation-only placeholder state.

This slice adds only the app-level Binance Home Live Crypto Bubble observed-runtime composition. `startBinanceHomeDashboardLiveCryptoBubbleObservedRuntime(...)` preserves the exact caller-owned observation/evaluation time dependencies and Gate341 universe/lifecycle options, constructs exactly one Gate344 adapter from the caller's Bubble metric observation sink, passes that adapter as Gate341's sole raw `observationSink`, delegates exactly once to Gate341, and returns Gate341's runtime bootstrap result unchanged.

The wrapper deliberately omits Gate341's raw `observationSink` from its public options and replaces it with the Gate344 downstream Bubble metric observation sink type, preventing a second raw freshness sink from being merged or silently overridden at this boundary.

## Error and lifecycle boundary
- Initial universe failure remains Gate341/Gate337 runtime truth and is returned unchanged.
- Authoritative empty selected scope remains the existing successful idle runtime behavior.
- Non-empty lifecycle cadence/visibility and close semantics remain released lower-owner behavior.
- Gate344 projection failures remain observation data through the released adapter; this wrapper does not reinterpret them.
- Caller observation/evaluation time sources are passed by reference and are not invoked by this wrapper.

## Explicit non-scope
No React/Home/Bubble rendering or component state; no Bubble palette/color threshold, size/radius scaling, geometry/layout/labels/interactions, or stale/expired/missing visibility treatment; no provider transport, active-USDT/stablecoin/ranking/Top-N policy; no acquisition cadence, visibility lifecycle, retry/backoff, universe refresh or session mutation; no internal clock or freshness threshold; no persistence/IndexedDB; no Your Trades/journal/chart/Risk-Reward/Calculation Brain/navigation/transitions.
