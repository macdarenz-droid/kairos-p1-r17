# Kairos Home Dashboard Live Crypto Bubble React Area-Weight View-Model Foundation

## Responsibility

This candidate adds one pure app-level composition seam between the canonically released Gate351 React runtime state and the Gate352 normalized area-weight projection. It prepares released state for a later visible renderer without selecting any user-facing geometry or design semantics.

The view model preserves the exact Gate351 runtime-state object by reference. When no semantic observation exists it exposes `areaWeightProjection: null`. When one exists it passes only the exact `presentationStateProjection` into `projectHomeDashboardLiveCryptoBubbleAreaWeights(...)` and exposes that exact Gate352 result separately.

## Semantics

- No observation means no fabricated area-weight evidence.
- The exact Gate351 runtime-state reference is always preserved, including status and error evidence.
- The exact latest Gate349 semantic observation remains reachable through that released runtime-state reference.
- Gate352 receives only the exact released semantic projection and remains the sole normalized area-weight derivation owner.
- A later acquisition failure does not erase the last authoritative semantic observation or its derived area-weight evidence.
- An upstream semantic-projection failure remains exact Gate352 non-renderable evidence.

## Ownership / non-scope

This seam owns no acquisition, retry, provider, universe, ranking, Top-N, stablecoin-exclusion, movement, freshness, clock, persistence or market-truth behavior. It does not sort/filter entries or duplicate Gate352 arithmetic.

Pixel radius, minimum/maximum radius, square-root conversion, collision/layout, theme palette/tokens, labels, accessibility copy, interaction, animation, DOM/React rendering and `HomeRoute` wiring remain later presentation responsibilities. Your Trades/journal truth remains completely separate.

## Verification intent

Dedicated regression proves no-observation behavior, exact runtime-state reference preservation, exact Gate352 delegation for a successful semantic observation, last-snapshot preservation across later acquisition failure, bootstrap-error separation, and exact propagation of an upstream semantic-projection failure. Static verification rejects provider/runtime ownership, clocks, sorting/filtering, direct Decimal arithmetic, radius/geometry, styling and visible rendering.
