# Live Market Summary Freshness Evaluation Projection Foundation

## Authority
Base: exact canonical Gate337 Home live-market runtime-bootstrap candidate, promoted by `Kairos Controlled Roadmap Gate` #337 / run `34399961306`.

## Source-proven responsibility
Released scoped-state snapshots preserve exact caller-requested instrument associations and represent a missing current fact explicitly as `null`. Released `LiveMarketSummaryFact` validates canonical caller-owned `observedAt` as a UTC instant. Released freshness classification owns only mapping an already-computed non-negative age to `fresh | stale | expired` and explicitly reserves observation-age computation for a later owner. Gate337 now creates the Home live-market runtime below presentation, but fresh source inspection finds no production consumer of that classification owner.

This slice therefore adds one provider-neutral deterministic freshness-evaluation projection below presentation. It accepts an already-released scoped snapshot plus an explicit caller-owned evaluation time expressed as epoch milliseconds, computes age only for present validated facts, delegates classification to the released policy, and preserves exact instrument/fact association.

## Edge semantics
- Missing `fact: null` stays missing with `ageMs: null` and `freshness: null`; missing is never reinterpreted as zero, fresh, stale, or expired.
- Non-finite or negative caller evaluation time returns `evaluation-time-invalid`; this owner never creates its own clock.
- Present facts are validated only through the released fact validator; failure returns `fact-invalid`.
- If canonical `observedAt` is after the caller evaluation time, return `observation-after-evaluation` rather than clamping a negative age to zero or allowing it to masquerade as current truth.
- Thresholds are not duplicated here; caller-supplied released policy configuration is forwarded unchanged to `classifyLiveMarketSummaryObservationAge(...)`.

## Explicit non-scope
No acquisition, provider/Binance transport, request/response mapping, polling/cadence/visibility/lifecycle/retry/cancellation, universe/ranking/Top-N/stablecoin policy, internal `Date.now()`/`new Date()` clock ownership, state/session mutation, persistence/IndexedDB, React/Home rendering, stale dimming or expired visuals, Bubble geometry/size/color/interactions, Your Trades/journal, chart/navigation/Saved Analysis/transitions.

This foundation intentionally stops at deterministic freshness projection. Later presentation wiring must consume the released projection without owning thresholds, acquisition truth, or observation-time semantics.
