# Home Dashboard Live Crypto Bubble Metric Observation Bridge Foundation

## Authority
Base: exact canonical Gate343 Live Crypto Bubble metric-input projection candidate, promoted by `Kairos Controlled Roadmap Gate` #343 / run `34434160306`.

## Source-proven responsibility
Gate340 already emits one provider-neutral `HomeDashboardLiveMarketSummaryFreshnessObservation` for each resolved Home lifecycle result, preserving acquisition/session status separately from the exact released freshness-evaluation result. Gate341 composes that observer into the Binance Home runtime and exposes the Gate340 observation sink. Gate343 now owns provider-neutral numeric Bubble metric-input projection from the exact freshness-evaluation result. No production owner connects a Gate340 observation to Gate343, while `HomeRoute` remains presentation-only placeholder state.

This slice adds only that provider-neutral Home Dashboard Live Crypto Bubble metric-observation bridge. `createHomeDashboardLiveCryptoBubbleMetricObservationSink(...)` returns the released Gate340 sink shape. For each upstream observation it delegates the exact `freshnessObservation.freshnessEvaluation` value once to Gate343, then emits the exact original freshness-observation object and exact Gate343 Bubble metric projection as separate fields. This keeps acquisition/session truth, freshness truth, and Bubble metric truth independently inspectable.

## Error boundary
- Deterministic Gate343 projection failures remain observation data and are not converted into lifecycle errors or presentation decisions.
- The upstream Gate340 `onError(error)` channel is forwarded unchanged to the downstream error sink.
- Downstream sink callback failures are not caught or reinterpreted; callback behavior remains caller ownership.
- The bridge owns no time source and cannot create or reinterpret freshness age/classification.

## Explicit non-scope
No React/Home/Bubble rendering or route/component state; no provider/Binance transport or universe policy; no active-USDT/stablecoin/ranking/Top-N logic; no color/palette/neutral threshold, radius/geometry/layout/labels/interactions, or stale/expired/missing visibility treatment; no acquisition/cadence/lifecycle scheduling/session mutation; no clock/freshness thresholds; no persistence/IndexedDB; no Your Trades/journal/chart/Risk-Reward/Calculation Brain/navigation/transitions.
