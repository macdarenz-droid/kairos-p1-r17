# Kairos Home Dashboard Live Crypto Bubble Presentation-State Observation Bridge Foundation

## Responsibility

This slice adds the provider-neutral Home Dashboard Live Crypto Bubble presentation-state observation bridge below React. It adapts the already-released Gate344 Bubble metric-observation sink seam to the already-released Gate346 semantic presentation-state projection without taking ownership of numeric market truth, freshness truth, lifecycle, or rendering.

For every exact upstream Bubble metric observation, the bridge delegates exactly once to Gate346 using the exact caller-owned presentation policy. The downstream observation preserves the exact original Bubble metric-observation object and the exact Gate346 projection result as separate inspectable fields.

Deterministic Gate346 projection failures remain observation data rather than being rewritten as lifecycle errors. The upstream error channel is forwarded unchanged. Downstream callback failure behavior remains caller-owned.

## Explicit non-scope

No clocks or time generation. No Binance/provider transport or response mapping. No active-USDT universe, stablecoin exclusion, quote-volume ranking, symbol tie-break, Top-N, cadence, lifecycle, freshness thresholds, or session mutation. No CSS/design-token values, palette, radius scaling, geometry/collision/layout, labels, DOM/React state, route startup/teardown, animation, persistence, Your Trades, journal, chart, Risk/Reward, navigation, or transitions.

## Dependency boundary

The bridge returns the released Gate344 `HomeDashboardLiveCryptoBubbleMetricObservationSink` shape, accepts the released Gate346 `HomeDashboardLiveCryptoBubblePresentationPolicy`, and emits a caller-owned semantic observation containing the exact metric observation plus the exact `HomeDashboardLiveCryptoBubblePresentationStateProjectionResult`.

A later React/Home composition may consume this released semantic stream. This slice intentionally does not start the Binance runtime or render Bubble UI.
