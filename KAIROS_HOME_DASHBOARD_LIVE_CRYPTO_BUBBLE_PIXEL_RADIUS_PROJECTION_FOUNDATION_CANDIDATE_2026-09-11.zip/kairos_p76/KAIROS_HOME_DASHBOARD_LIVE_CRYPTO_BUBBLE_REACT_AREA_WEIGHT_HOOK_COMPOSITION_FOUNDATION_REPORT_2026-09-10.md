# Kairos Home Dashboard Live Crypto Bubble React Area-Weight Hook Composition Foundation

## Responsibility

This candidate adds one React-ready composition seam between the released Gate351 runtime hook and the released Gate354 area-weight view model. It closes the remaining app-level consumer gap before visible `HomeRoute` rendering without selecting user-facing geometry or design semantics.

The hook delegates the caller-owned observed-at source, evaluation-time source and exact runtime-binding options unchanged to `useHomeDashboardLiveCryptoBubblePresentationObservedRuntime(...)`. It then passes the exact returned runtime-state reference to `projectHomeDashboardLiveCryptoBubbleReactAreaWeightViewModel(...)` and returns that released projector result unchanged.

## Semantics

- Caller-owned runtime inputs remain unchanged; this layer chooses no universe, lifecycle or presentation-policy defaults.
- Gate351 remains the sole React lifecycle/state owner.
- Gate354 remains the sole React area-weight view-model projection owner.
- The composition does not add a second state/effect owner, cache, timer, observer, provider call or error taxonomy.
- Runtime-state changes flow directly into the released Gate354 projector on the same React render.
- The exact Gate354 result is returned without reshaping its runtime-state or area-weight evidence.

## Ownership / non-scope

This seam owns no acquisition, retry, provider, universe, ranking, Top-N, stablecoin-exclusion, movement, freshness, clock, persistence or market-truth behavior. It performs no Decimal arithmetic and does not re-derive Gate352 area weights.

Pixel radius, collision/layout, theme palette/tokens and visible `HomeRoute` rendering remain later responsibilities, as do labels, accessibility copy, interaction and animation. Your Trades/journal truth remains completely separate.

## Verification intent

Dedicated regression proves exact caller-input delegation, exactly one released runtime-hook call per render, exact Gate351 runtime-state delegation into Gate354, no second retained runtime-state owner on rerender, and unchanged return of released Gate354 evidence. Static verification rejects state/effect ownership, clocks/timers, transport/provider composition, market-policy logic, Decimal/radius arithmetic, styling, DOM/JSX and `HomeRoute` wiring.
