# KAIROS Home Dashboard Live Crypto Bubble React Radius-Scale Hook Composition Foundation Report

Date: 2026-09-11
Base: canonical Gate365 Home Live Crypto Bubble React radius-scale view-model foundation.

## Responsibility

This candidate adds one thin React composition seam between the released Gate355 area-weight hook and the released Gate365 radius-scale view-model projector.

`useHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel(...)` accepts the exact caller-owned observed-at source, evaluation-time source and Gate351 runtime-binding options. It calls `useHomeDashboardLiveCryptoBubbleReactAreaWeightViewModel(...)` exactly once with those exact references, passes the exact returned area-weight view-model reference once to `projectHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel(...)`, and returns that released Gate365 result unchanged.

## Semantics

- Caller-owned runtime inputs remain unchanged; this layer chooses no provider, universe, lifecycle, product or rendering defaults.
- Gate351 remains the React runtime lifecycle/state owner through the already released area-weight hook chain.
- Gate354 remains the area-weight React view-model owner.
- Gate364 remains the normalized radius-scale arithmetic owner.
- Gate365 remains the pure area-weight-view-model-to-radius-scale-view-model owner.
- This hook adds no second retained state/effect owner, cache, timer, observer, provider call or error taxonomy.
- The exact Gate365 result is returned without reshaping its runtime, area-weight or radius-scale evidence.

## Ownership / non-scope

This seam owns no request/acquisition/retry, provider, universe, ranking, Top-N, stablecoin exclusion, movement, freshness, clock, persistence or market-truth behavior. It performs no Decimal arithmetic and no radius arithmetic.

Pixel min/max radius, viewport breakpoints, collision/packing/layout, labels, interaction, theme palette/tokens, CSS, stale/expired opacity, animation and visible Bubble rendering remain later presentation responsibilities. `HomeRoute` wiring remains unchanged. Live Crypto Bubble Map and Your Trades Bubble Map remain separate truth domains.

## Verification intent

Dedicated regression proves exact caller-input delegation, exactly one released area-weight-hook call per render, exact returned area-weight view-model delegation into Gate365, no second app-level radius-scale state owner across rerenders, and unchanged return of released Gate365 evidence. Static verification rejects state/effect ownership, clocks/timers, transport/provider/product-policy logic, arithmetic, styling, DOM/JSX, `HomeRoute`, persistence and Your Trades ownership.
