# KAIROS Live Market Universe Acquisition Orchestration Foundation

Base: exact canonical Gate #334 GOLDEN Live Market Universe composition candidate.

This slice owns one provider-neutral one-shot Live Market Universe acquisition orchestration responsibility only. It composes the released provider-neutral instrument metadata acquisition port, released eligibility policy, released provider-neutral 24h baseline acquisition port, and released Gate334 composition owner.

The orchestration performs exactly one metadata acquisition. On authoritative metadata success it delegates eligibility to the released policy and passes the resulting instrument values, in their surviving metadata order, as the exact eligible acquisition scope to one baseline acquisition. It forwards the same optional caller-owned AbortSignal to both acquisition ports without becoming a cancellation-policy owner. On baseline success it delegates authoritative metadata facts plus the returned authoritative summary facts to Gate334 composition, which continues to own identity association, quote-volume ordering, symbol tie-break, and Top-N selection. Both released acquisition-port failure shapes remain the single existing `acquisition-failed` result; no new provider error taxonomy is invented.

An empty eligible scope returns an authoritative empty selected scope without calling the baseline port. This is dependency orchestration, not universe policy: the released Binance 24h request descriptor rejects empty scope, and no summary acquisition is required when eligibility produced no instruments.

Explicit non-scope: No provider choice or request/transport/decode/mapping. No browser connector/fetch binding changes. No observedAt or freshness policy. No freshness/cadence/lifecycle, visibility, timers, polling, retry, scheduling, or new cancellation policy. No persistence or IndexedDB. No React/Home/Bubble presentation, geometry, size/color, interaction, navigation, chart, or transitions. No Your Trades, journal, Calculation Brain, Risk/Reward, or Saved Analysis truth. No new stablecoin exclusion, quote-volume ordering, tie-break, or Top-N policy.
