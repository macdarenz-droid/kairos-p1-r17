# Binance Home Dashboard Live Market Observed Runtime Composition Foundation

## Authority
Base: exact canonical Gate340 Home lifecycle-result freshness-observation bridge candidate, promoted by `Kairos Controlled Roadmap Gate` #340 / run `34414358508`.

## Source-proven responsibility
Gate337 already owns the one-shot Binance Home universe bootstrap, summary-state session, scoped-snapshot port and browser lifecycle adapter. Gate340 separately owns construction of the provider-neutral freshness-observation lifecycle observer. The released Gate337 bootstrap accepts the lifecycle observer slot but no app-level owner yet composes the two.

This slice adds only that app-level non-presentation composition. It accepts the caller-owned acquisition observation-time source and the separate caller-owned freshness evaluation-time source. Its options preserve the released universe options and allow only document/timer lifecycle overrides; the lifecycle `observer` field is deliberately omitted from the public options type so this composition owns that slot unambiguously. It creates exactly one Gate340 observer, forwards the optional Gate340 observation sink unchanged, builds one lifecycle options object preserving caller document/timer references, delegates exactly once to Gate337, and returns Gate337's bootstrap result unchanged.

## Preserved edge behavior
Because all execution delegates to Gate337 unchanged, initial universe `acquisition-failed` remains unchanged before any lifecycle result exists; an authoritative empty selected scope remains Gate337's successful idle runtime and therefore emits no lifecycle observation; a non-empty scope continues to use the existing browser lifecycle; and `close` remains Gate337/lifecycle ownership. Observer construction itself reads neither caller-owned time source.

## Explicit non-scope
No React/Home/Bubble rendering or state; no stale/expired visual treatment; no bubble geometry/size/color/interactions; no provider transport/decode/mapping; no active-USDT/stablecoin/ranking/Top-N policy; no new clock or freshness thresholds; no acquisition cadence, visibility scheduling, retry/backoff or universe refresh; no persistence/IndexedDB; no navigation, Your Trades, journal, chart, Risk/Reward, Calculation Brain, Saved Analysis or transition ownership.
