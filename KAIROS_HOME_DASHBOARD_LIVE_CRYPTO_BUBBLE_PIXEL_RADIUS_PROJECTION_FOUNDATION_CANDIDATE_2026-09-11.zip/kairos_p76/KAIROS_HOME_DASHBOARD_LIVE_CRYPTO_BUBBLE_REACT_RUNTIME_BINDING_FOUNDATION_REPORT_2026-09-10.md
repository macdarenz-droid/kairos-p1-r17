# Home Dashboard Live Crypto Bubble React Runtime Binding Foundation

## Authority
Base: exact canonical Gate350 Binance Home Live Crypto Bubble presentation-observed runtime composition, `Kairos Controlled Roadmap Gate` #350 / run `34454131565`.

## Source-proven responsibility
Gate350 canonically releases the complete Binance Home Live Crypto Bubble semantic observed runtime below React. P21.1 already owns `HomeRoute` presentation, but current production source has no React consumer of Gate350. The smallest dependency-safe next step is therefore a React lifecycle/state binding that consumes Gate350 without choosing still-caller-owned market/presentation policy values or visible Bubble geometry.

## Contract
`useHomeDashboardLiveCryptoBubblePresentationObservedRuntime(...)`:
- accepts the exact caller-owned observedAt source, evaluation-time source, universe configuration, browser-lifecycle options and Gate346 presentation policy;
- owns the Gate350 semantic observation-sink slot for React state only;
- starts one Gate350 runtime per effect activation;
- preserves the latest exact Gate349 semantic observation by reference;
- records upstream observation errors separately without erasing the latest semantic observation;
- preserves Gate350 bootstrap acquisition failure as explicit `acquisition-failed` state;
- preserves unexpected bootstrap exceptions/rejections as explicit `bootstrap-error` evidence through an internal async `try/catch` boundary;
- closes the exact successfully resolved runtime on teardown, including when asynchronous bootstrap resolves after unmount.

## Explicit non-scope
No concrete stablecoin exclusion set or neutral-movement threshold is selected or hard-coded. No provider transport/request/decode/mapping, universe eligibility/ranking/Top-N semantics, freshness thresholds/cadence, internal clocks, direct browser document/timer ownership, persistence/IndexedDB, design palette/tokens, Bubble radius/geometry/collision/layout, labels/copy, accessibility semantics, interactions, animation, visible Bubble circles, HomeRoute rendering changes, Your Trades Bubble Map, journal/chart/Risk-Reward/navigation/transitions.

This slice is React lifecycle/state plumbing only. A later controlled presentation slice may render visible Home Live Crypto Bubbles from this released React state boundary while continuing to consume explicit product/configuration inputs.
