# KAIROS Home Dashboard Live Crypto Bubble React Radius-Scale View-Model Foundation Report

Date: 2026-09-11
Base: canonical Gate364 Home Live Crypto Bubble normalized radius-scale projection foundation.

## Responsibility

This candidate adds one pure app-level composition seam between the released React area-weight view model and the released Gate364 normalized radius-scale projection.

`projectHomeDashboardLiveCryptoBubbleReactRadiusScaleViewModel(...)` accepts the exact existing `HomeDashboardLiveCryptoBubbleReactAreaWeightViewModel`, preserves that exact object and its exact `runtimeState` reference, exposes `radiusScaleProjection: null` when no area-weight projection exists, and otherwise passes only the exact `areaWeightProjection` reference into `projectHomeDashboardLiveCryptoBubbleRadiusScales(...)` once.

Gate364 remains the sole owner of square-root conversion and radius-scale validation. This seam does not reimplement `Math.sqrt`, reorder/filter entries, or reinterpret upstream failures.

## Explicit non-scope

No React hook/state/effect or wall clock; no network/provider/acquisition/retry; no universe/ranking/Top-30/stablecoin/freshness/product-policy changes; no pixel radius/minimum/maximum radius; no viewport, collision/packing/layout, labels, hit targets or interactions; no palette/theme/CSS/stale opacity/motion; no HomeRoute mutation; no persistence/IndexedDB/Saved Analysis; no Your Trades/journal/chart/Risk-Reward/Calculation-Brain ownership.

Live Crypto Bubble Map and Your Trades Bubble Map remain separate truth domains.

## Verification intent

Dedicated static verification proves the exact delegation shape, reference-preserving contract, null behavior, absence of forbidden ownership, focused regression coverage, and package-script registration. Full TypeScript/build/unit/current/historical verification remains required by the controlled helper and canonical gate before promotion.
