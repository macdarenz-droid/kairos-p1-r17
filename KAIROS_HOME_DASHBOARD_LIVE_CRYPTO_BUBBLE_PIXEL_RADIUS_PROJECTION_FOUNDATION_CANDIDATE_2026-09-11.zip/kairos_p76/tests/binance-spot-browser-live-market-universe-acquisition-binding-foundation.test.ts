import { afterEach, describe, expect, it, vi } from 'vitest';
import { acquireBinanceSpotBrowserLiveMarketUniverseOnce } from '../src/services/market-data';

const originalFetch = globalThis.fetch;
const observedAt = '2026-09-09T17:00:00.000Z';
const exchangeInfoPayload = JSON.stringify({ symbols: [
  { symbol: 'BTCUSDT', status: 'TRADING', baseAsset: 'BTC', quoteAsset: 'USDT' },
  { symbol: 'USDCUSDT', status: 'TRADING', baseAsset: 'USDC', quoteAsset: 'USDT' },
  { symbol: 'SOLUSDT', status: 'BREAK', baseAsset: 'SOL', quoteAsset: 'USDT' },
  { symbol: 'ETHFDUSD', status: 'TRADING', baseAsset: 'ETH', quoteAsset: 'FDUSD' },
] });
const btc24hPayload = JSON.stringify({
  symbol: 'BTCUSDT', openPrice: '62000', highPrice: '65000', lowPrice: '61000',
  lastPrice: '64000', volume: '1234', quoteVolume: '78000000', closeTime: 1770000000000,
});

afterEach(() => {
  globalThis.fetch = originalFetch;
  vi.restoreAllMocks();
});

describe('Binance Spot browser Live Market Universe acquisition binding foundation', () => {
  it('composes the released browser metadata and baseline ports through Gate335 without duplicating universe policy', async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      if (url.includes('/api/v3/exchangeInfo')) return { text: async () => exchangeInfoPayload };
      if (url.includes('/api/v3/ticker/24hr')) return { text: async () => btc24hPayload };
      throw new Error(`unexpected URL: ${url}`);
    });
    globalThis.fetch = fetchMock as unknown as typeof fetch;
    const readObservedAt = vi.fn(() => observedAt);

    await expect(acquireBinanceSpotBrowserLiveMarketUniverseOnce(readObservedAt, {
      excludedStablecoinBaseAssets: new Set(['USDC']),
      topNCount: 1,
    })).resolves.toEqual({
      ok: true,
      instruments: [{ venue: 'binance-spot', symbol: 'BTCUSDT' }],
    });
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(readObservedAt).toHaveBeenCalledTimes(1);
  });

  it('forwards the exact caller-owned AbortSignal through both released browser acquisition chains', async () => {
    const controller = new AbortController();
    const capturedSignals: Array<AbortSignal | null | undefined> = [];
    const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      capturedSignals.push(init?.signal);
      const url = String(input);
      if (url.includes('/api/v3/exchangeInfo')) return { text: async () => JSON.stringify({ symbols: [
        { symbol: 'BTCUSDT', status: 'TRADING', baseAsset: 'BTC', quoteAsset: 'USDT' },
      ] }) };
      if (url.includes('/api/v3/ticker/24hr')) return { text: async () => btc24hPayload };
      throw new Error(`unexpected URL: ${url}`);
    });
    globalThis.fetch = fetchMock as unknown as typeof fetch;

    await expect(acquireBinanceSpotBrowserLiveMarketUniverseOnce(() => observedAt, {
      excludedStablecoinBaseAssets: new Set(),
      signal: controller.signal,
    })).resolves.toMatchObject({ ok: true });
    expect(capturedSignals).toEqual([controller.signal, controller.signal]);
  });

  it('preserves Gate335 metadata acquisition failure and does not call the baseline browser chain', async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      if (String(input).includes('/api/v3/exchangeInfo')) throw new Error('metadata-native-failure');
      throw new Error('baseline must not run');
    });
    globalThis.fetch = fetchMock as unknown as typeof fetch;
    const readObservedAt = vi.fn(() => observedAt);

    await expect(acquireBinanceSpotBrowserLiveMarketUniverseOnce(readObservedAt, {
      excludedStablecoinBaseAssets: new Set(),
    })).resolves.toEqual({ ok: false, reason: 'acquisition-failed' });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(readObservedAt).not.toHaveBeenCalled();
  });

  it('preserves Gate335 empty eligible-scope short circuit without baseline request or observation time', async () => {
    const fetchMock = vi.fn(async () => ({ text: async () => JSON.stringify({ symbols: [
      { symbol: 'USDCUSDT', status: 'TRADING', baseAsset: 'USDC', quoteAsset: 'USDT' },
    ] }) }));
    globalThis.fetch = fetchMock as unknown as typeof fetch;
    const readObservedAt = vi.fn(() => observedAt);

    await expect(acquireBinanceSpotBrowserLiveMarketUniverseOnce(readObservedAt, {
      excludedStablecoinBaseAssets: new Set(['USDC']),
    })).resolves.toEqual({ ok: true, instruments: [] });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(readObservedAt).not.toHaveBeenCalled();
  });

  it('preserves Gate335 baseline acquisition failure unchanged', async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      if (url.includes('/api/v3/exchangeInfo')) return { text: async () => JSON.stringify({ symbols: [
        { symbol: 'BTCUSDT', status: 'TRADING', baseAsset: 'BTC', quoteAsset: 'USDT' },
      ] }) };
      if (url.includes('/api/v3/ticker/24hr')) throw new Error('baseline-native-failure');
      throw new Error(`unexpected URL: ${url}`);
    });
    globalThis.fetch = fetchMock as unknown as typeof fetch;

    await expect(acquireBinanceSpotBrowserLiveMarketUniverseOnce(() => observedAt, {
      excludedStablecoinBaseAssets: new Set(),
    })).resolves.toEqual({ ok: false, reason: 'acquisition-failed' });
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });
});
