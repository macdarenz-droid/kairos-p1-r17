# Home Dashboard Live Crypto Bubble Text Evidence Runtime Composition Foundation

## Responsibility

Join the released Gate355 Home Live Crypto Bubble runtime/view-model hook to the released Gate356 textual evidence presenter through one thin React component while keeping all concrete runtime inputs caller-owned.

The component accepts exact `readObservedAt`, `readEvaluationTimeMs`, and Gate351 runtime-binding options as props; delegates those exact references once to the released Gate355 hook; and passes the exact returned Gate354 view-model reference directly to the released Gate356 textual presenter.

## Ownership boundaries

This foundation introduces no default clock or time source, no market-universe/runtime option defaults, no presentation-policy defaults, no provider/acquisition/retry/cadence logic, no own state/effect/memo/timer/observer, no sorting/filtering/ranking/Top-N/stablecoin policy, no movement/freshness/area-weight arithmetic, no CSS/theme/palette, no Bubble radius/geometry/layout/collision/labels, no SVG/canvas, no `HomeRoute` wiring, no persistence/Saved Analysis, and no Your Trades/journal/chart/Risk-Reward/navigation/transitions ownership.

Gate351 remains runtime lifecycle/state owner. Gate352 remains normalized area-weight arithmetic owner. Gate354 remains pure area-weight view-model owner. Gate355 remains the hook composition owner. Gate356 remains the textual semantic presentation owner.

## Why this slice is dependency-safe

Fresh Gate356 GOLDEN provides the released hook and presenter but no composition component joins them. `HomeRoute` still has no released concrete owner for observed-at/evaluation clocks, runtime/universe options, or presentation-policy defaults, and Bubble-specific geometry/design rules remain unreleased. Joining only the already-released hook and presenter with injected inputs closes one missing React edge without inventing those later contracts.
