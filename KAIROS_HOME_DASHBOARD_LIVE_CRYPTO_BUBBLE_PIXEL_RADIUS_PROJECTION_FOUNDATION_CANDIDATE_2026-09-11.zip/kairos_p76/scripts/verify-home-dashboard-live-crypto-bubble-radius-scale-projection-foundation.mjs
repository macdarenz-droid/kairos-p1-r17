import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const source = readFileSync('src/application/dashboard/homeDashboardLiveCryptoBubbleRadiusScaleProjection.ts', 'utf8');
const test = readFileSync('tests/home-dashboard-live-crypto-bubble-radius-scale-projection-foundation.test.ts', 'utf8');
const report = readFileSync('KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_RADIUS_SCALE_PROJECTION_FOUNDATION_REPORT_2026-09-11.md', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

assert.equal(
  pkg.scripts['verify:home-dashboard-live-crypto-bubble-radius-scale-projection-foundation'],
  'node scripts/verify-home-dashboard-live-crypto-bubble-radius-scale-projection-foundation.mjs',
);

for (const required of [
  'HomeDashboardLiveCryptoBubbleRadiusScaleProjectionEntry',
  'areaWeightEntry: HomeDashboardLiveCryptoBubbleAreaWeightProjectionEntry',
  'radiusScale: number | null',
  'projectHomeDashboardLiveCryptoBubbleRadiusScales',
  "reason: 'area-weight-projection-invalid'",
  "reason: 'radius-scale-entry-invalid'",
  'if (!areaWeightProjection.ok)',
  'entries.push({ areaWeightEntry, radiusScale: null })',
  'const areaWeightNumber = Number(areaWeightEntry.areaWeight)',
  'Number.isFinite(areaWeightNumber)',
  'areaWeightNumber < 0',
  'areaWeightNumber > 1',
  'const radiusScale = Math.sqrt(areaWeightNumber)',
  'entries.push({ areaWeightEntry, radiusScale })',
]) {
  assert.ok(source.includes(required), `radius-scale projection missing exact evidence: ${required}`);
}

assert.equal(
  (source.match(/Math\.sqrt\(/g) ?? []).length,
  1,
  'radius-scale projection must own exactly one square-root transform',
);

for (const forbidden of [
  '.sort(', '.filter(', '.reverse(',
  'minRadius', 'maxRadius', 'radiusPx', 'pixelRadius', 'viewport', 'ResizeObserver',
  "from 'react'", 'useEffect', 'useState', 'useMemo', 'useRef',
  '<svg', '<circle', '<canvas', 'className=', 'style=', 'borderRadius',
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'requestAnimationFrame(',
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'indexedDB', 'localStorage',
  'topN', 'Top 30', 'stablecoin', 'neutralMaxAbsoluteMovementPercent',
  'freshMaxAgeMs', 'staleMaxAgeMs', 'HomeRoute',
]) {
  assert.ok(!source.includes(forbidden), `radius-scale projection broadened ownership: ${forbidden}`);
}

for (const evidence of [
  'derives the approved square-root radius scale while preserving exact entry references and order',
  'does not sort or rerank when later entries have larger radius scales',
  'preserves an upstream area-weight projection failure by exact reference',
  'fails closed for %s successful area-weight evidence',
  'toEqual([1, 0.5, 0, null])',
  'toEqual([0.2, 1, 0.9])',
]) {
  assert.ok(test.includes(evidence), `radius-scale regression evidence missing: ${evidence}`);
}

for (const phrase of [
  'Gate363 canonical GOLDEN candidate',
  'circle area is proportional to `areaWeight`, therefore normalized radius is proportional to `sqrt(areaWeight)`',
  'maps `areaWeight: null` to `radiusScale: null`',
  'No pixel radius, minimum/maximum pixel radius or minimum visible-size choice',
  'Live Crypto Bubble and Your Trades Bubble remain separate truth domains',
  'stops before responsive pixel sizing and collision/layout',
]) {
  assert.ok(report.includes(phrase), `radius-scale report missing ownership evidence: ${phrase}`);
}

console.log('PASS: Home Live Crypto Bubble radius-scale projection performs only the approved sqrt(areaWeight) normalized presentation transform and preserves every market, pixel/layout, theme, persistence and Your Trades ownership boundary.');
