import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/services/market-data/liveMarketSummary24hPercentageMovement.ts', import.meta.url), 'utf8');
const barrel = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_LIVE_MARKET_SUMMARY_24H_PERCENTAGE_MOVEMENT_FOUNDATION_REPORT_2026-09-10.md', import.meta.url), 'utf8');
const packageJson = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

for (const token of [
  'deriveLiveMarketSummary24hPercentageMovement',
  'validateLiveMarketSummaryFact(fact)',
  'decimalSubtract(validation.fact.lastPrice, validation.fact.open24h)',
  'calculatePercentage(change.value, validation.fact.open24h)',
  "reason: 'fact-invalid'",
  "reason: 'movement-calculation-invalid'",
  'instrument: validation.fact.instrument',
  'fact: validation.fact',
  'movementPercent24h: percentage.value',
]) if (!source.includes(token)) throw new Error(`24h movement source evidence missing: ${token}`);

for (const forbidden of [
  'parseFloat(', 'parseInt(', 'Number(', 'Math.', 'priceChangePercent',
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'fetch(', 'WebSocket(',
  '.sort(', '.filter(', '.reduce(', 'topCount', 'excludedStablecoin',
  'freshMaxAgeMs', 'staleMaxAgeMs', 'useState', 'useEffect', 'React', 'indexedDB',
]) if (source.includes(forbidden)) throw new Error(`24h movement source broadened ownership: ${forbidden}`);

if (!barrel.includes("export * from './liveMarketSummary24hPercentageMovement';")) {
  throw new Error('24h movement owner is not exported by the market-data barrel');
}

if (packageJson.scripts?.['verify:live-market-summary-24h-percentage-movement-foundation']
  !== 'node scripts/verify-live-market-summary-24h-percentage-movement-foundation.mjs') {
  throw new Error('24h movement verifier registration missing');
}

for (const token of [
  '24h percentage movement as bubble-color truth',
  'released `decimalSubtract`',
  'released `calculatePercentage(change, open24h)`',
  'preserves the exact validated fact and instrument association by reference',
  'No Binance `priceChangePercent`',
  'no color palette',
  'no bubble radius/geometry/layout',
  'no React/Home/Bubble state/rendering',
]) if (!report.includes(token)) throw new Error(`24h movement report evidence missing: ${token}`);

console.log('Live Market Summary 24h Percentage Movement Foundation verification passed.');
