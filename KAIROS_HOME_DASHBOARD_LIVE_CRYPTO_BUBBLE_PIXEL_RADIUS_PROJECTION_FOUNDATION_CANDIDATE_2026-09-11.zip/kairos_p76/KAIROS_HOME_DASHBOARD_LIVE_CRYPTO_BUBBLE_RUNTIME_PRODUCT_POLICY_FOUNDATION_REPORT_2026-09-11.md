# Kairos Home Dashboard Live Crypto Bubble Runtime Product Policy Foundation Report — 2026-09-11

## Authority

This candidate starts from the exact Gate361 canonical GOLDEN candidate:
`KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_CONFIGURED_TEXT_EVIDENCE_RUNTIME_COMPOSITION_FOUNDATION_CANDIDATE_2026-09-10.zip`, size `1,676,282` bytes, SHA-256 `89f14c02b5387382c5de67793212ff9de849676e0fe21deda72d329df46ee0fc`, root exactly `kairos_p76/`.

The user explicitly released the prior HOLD_USER boundary by approving the researched P21 Bubble Map policy package. This slice implements only the two approved values consumed by the already-released Gate360 runtime-options boundary.

## Released responsibility

`src/app/homeDashboardLiveCryptoBubbleRuntimeProductPolicy.ts` becomes the single default runtime product-policy owner for:

- the exact approved default stablecoin base-asset exclusion set: `USDC`, `FDUSD`, `XUSD`, `USDS`, `U`, `TUSD`, `USDP`, `DAI`, `EURI`, `AEUR`;
- the neutral threshold is exactly `0.25` percent absolute 24h movement; and
- creation of a fresh `HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration` value for a caller that elects to use these approved defaults.

`USDT` remains the required quote asset and is not excluded. `PAXG` is not treated as a stablecoin. The exclusion Set is recreated for each configuration so callers do not share a mutable Set instance.

## Preserved ownership

Top-30 selection remains owned by the released universe policy. Existing quote-volume ranking, symbol tie-break, provider acquisition, browser lifecycle, visible 5-second cadence, freshness thresholds, observed-at/evaluation clocks, and runtime state ownership remain unchanged.

Gate360 remains the runtime-options composition owner and Gate361 remains the configured browser textual-runtime composition owner. This product-policy slice does not wire either boundary into a route.

## Explicit non-scope

- No `HomeRoute` or visible Bubble renderer wiring.
- No Bubble radius, square-root conversion, min/max radius, collision/packing/layout, labels, SVG/canvas, theme-token mapping, dimming intensity, or motion.
- No provider/request/response/acquisition/retry behavior.
- No Top-N count/ranking/tie-break changes.
- No freshness/cadence/lifecycle/timer/clock changes.
- No persistence, IndexedDB, Saved Analysis, Your Trades Bubble Map, journal, chart, Risk/Reward, navigation, or transition changes.

The approved renderer policy—area proportional to released `areaWeight`, radius proportional to its square root, theme-token semantic colours, and stale/expired presentation behavior—remains for later controlled presentation slices after this concrete runtime product configuration is canonically released.
