# KAIROS Binance Home Dashboard Live Market Runtime Bootstrap Foundation

Base: exact canonical Gate #336 GOLDEN Binance Spot browser Live Market Universe acquisition binding candidate.

This slice owns one non-presentation Home live-market runtime bootstrap responsibility only. It sequences the already-released concrete Binance browser and provider-neutral runtime owners without moving their semantics into presentation.

The bootstrap first delegates one initial universe acquisition to the Gate336 one-shot selected scope owner. An initial acquisition failure from Gate336 preserves the existing `acquisition-failed` result and starts no session or browser lifecycle work. On a successful authoritative empty selected scope it returns a successful idle runtime and does not invoke the Home summary baseline chain, because the released Binance 24h request owner rejects empty scope and Gate335 already defines empty eligible scope as authoritative empty success.

For a non-empty selected scope, the bootstrap creates exactly one released state session, creates the released Binance Home scoped-snapshot port using the same caller-owned readObservedAt source supplied to Gate336, and starts the released browser lifecycle adapter for that exact selected scope. The released lifecycle adapter continues to own entry/resume/visible cadence, hidden suspension, in-flight cancellation, browser visibility listener, timers, and idempotent close behavior. The bootstrap exposes only the selected instrument scope and one close handle required by later wiring; the session remains internal.

Ownership constraints:
- Gate336 remains the only initial universe acquisition/provider dependency binding owner.
- Existing universe eligibility, stablecoin exclusion, quote-volume ordering, symbol tie-break and Top-N owners remain unchanged.
- No universe refresh cadence is invented; Gate336 universe acquisition remains one-shot.
- No freshness policy ownership or observedAt reinterpretation; the same caller-owned readObservedAt source flows into both initial universe baseline acquisition and later Home summary acquisition.
- No retry/backoff or new failure taxonomy.
- No persistence or IndexedDB.
- No React/Home/Bubble presentation ownership, bubble geometry/size/color, navigation, chart, transitions, Your Trades, journal, Risk/Reward, Calculation Brain, or Saved Analysis truth.

Verification covers Gate336 success/failure/authoritative-empty behavior, same observation-time source reuse, exact selected-scope lifecycle start, released five-second cadence delegation without duplicating the value here, observer result flow, and idempotent close delegation including abort/cancel/listener cleanup.
