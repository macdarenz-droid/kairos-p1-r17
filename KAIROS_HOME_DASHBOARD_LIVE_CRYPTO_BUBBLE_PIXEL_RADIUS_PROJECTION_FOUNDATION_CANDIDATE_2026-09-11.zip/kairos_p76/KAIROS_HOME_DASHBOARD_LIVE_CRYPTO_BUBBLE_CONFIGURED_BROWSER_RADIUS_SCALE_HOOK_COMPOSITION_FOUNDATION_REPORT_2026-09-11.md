# Kairos Home Dashboard Live Crypto Bubble Configured Browser Radius-Scale Hook Composition Foundation

## Authority

Base: canonical Gate368 browser radius-scale hook composition foundation.

## Responsibility

This slice owns exactly one thin configured browser React radius-scale hook composition edge between released Gate360 runtime-options composition and released Gate368 browser radius-scale hook composition.

`useHomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleViewModel(...)`:
- accepts one exact caller-owned product configuration through `HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration`;
- delegates that exact caller-owned product configuration once to `composeHomeDashboardLiveCryptoBubbleRuntimeBindingOptions(...)`;
- passes the exact returned runtime-options object once to `useHomeDashboardLiveCryptoBubbleBrowserRadiusScaleViewModel(...)`; and
- returns the exact released Gate368 radius-scale view-model result unchanged.

Gate360 remains runtime-options composition owner. Gate368 remains browser radius-scale hook owner. This boundary neither reads nor transforms the stablecoin-exclusion set or neutral-movement threshold itself.

## Explicit non-scope

No concrete stablecoin exclusion, neutral-movement value, pixel radius or viewport value is selected here. No Top-N default. No browser lifecycle override. No state/effects/memo/callback/ref owner. No clocks, timers, page visibility, provider request/acquisition/retry/cadence, or freshness ownership. No radius arithmetic, pixel min/max, breakpoints, collision/packing/layout, labels, interactions, SVG/canvas, CSS/theme/palette/dimming, or animation. No `HomeRoute` mutation. No persistence/Saved Analysis. No Your Trades Bubble Map, journal/trade truth, chart, Risk/Reward, Calculation Brain, navigation, or transitions.

## Dependency ownership preserved

Gate360 owns pure composition of the exact caller-owned product configuration into the released runtime-binding options. Gate368 owns the browser-clock injection edge into the released Gate366 React radius-scale hook. Gate364 remains normalized radius-scale arithmetic owner and Gate351 remains React runtime state owner.

This slice closes only the unowned technical dependency edge from caller-owned runtime product configuration to the released browser radius-scale hook. Concrete pixel sizing and visible Bubble layout/rendering remain later controlled presentation responsibilities.

Live Crypto Bubble Map and Your Trades Bubble Map remain separate authoritative truth domains.
