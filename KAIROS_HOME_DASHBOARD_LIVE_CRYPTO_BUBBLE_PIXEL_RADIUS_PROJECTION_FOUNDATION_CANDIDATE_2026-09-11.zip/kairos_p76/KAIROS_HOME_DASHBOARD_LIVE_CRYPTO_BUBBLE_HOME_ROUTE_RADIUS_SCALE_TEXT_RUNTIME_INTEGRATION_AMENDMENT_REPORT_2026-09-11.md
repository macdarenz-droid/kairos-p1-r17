# Kairos Home Dashboard Live Crypto Bubble Home Route Radius-Scale Text Runtime Integration Amendment Report — 2026-09-11

## Authority

This controlled amendment starts only from the exact Gate372 canonical GOLDEN candidate `KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_CONFIGURED_BROWSER_RADIUS_SCALE_TEXT_EVIDENCE_RUNTIME_COMPOSITION_FOUNDATION_CANDIDATE_2026-09-11.zip`, size `1,724,390` bytes, SHA-256 `4189c15eb44908c46a1010108c873b838939cfc24322525c3b8b06e99983160a`, root exactly `kairos_p76/`.

Gate372 canonically releases the complete configured-browser normalized-radius textual evidence runtime. The existing HomeRoute still delegates to the earlier configured area-weight textual runtime, so this amendment updates only that presentation integration seam from latest GOLDEN.

## Amended responsibility

`src/app/HomeRoute.tsx` keeps the existing route owner and exact released default product-configuration owner, then:

1. requests the default product configuration exactly once through `createHomeDashboardLiveCryptoBubbleDefaultRuntimeProductConfiguration()`;
2. forwards that exact released default product configuration reference exactly once to Gate372 `HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime`; and
3. is the controlled amendment to replace the superseded configured area-weight textual runtime consumer instead of rendering two competing Live Crypto runtime consumers.

The route marker, Home heading, Live Crypto Bubble heading, shell ownership and route accessibility boundary remain unchanged.

## Controlled verifier/test amendment

The existing HomeRoute integration verifier/test contract and P21.1 route-ownership verifier are amended in place because they are the current canonical guards for this exact route seam. The generic router-shell test now mocks Gate372's configured runtime so route navigation stays deterministic and cannot acquire live market data as a side effect.

The historical Gate362 route-integration foundation report and P21.1 foundation report remain unchanged as released history. This amendment adds new evidence rather than rewriting earlier canonical history.

## Explicit non-scope

- No pixel radius values, min/max radii, breakpoints, collision packing, viewport layout or label-fit policy.
- No radius arithmetic or reinterpretation of released `radiusScale` evidence.
- No Bubble geometry, canvas/SVG renderer, palette, CSS, theme or motion.
- No provider/request/response/acquisition/retry changes.
- No ranking, Top-N, stablecoin, movement or freshness recalculation.
- No timers, clocks, lifecycle or cadence ownership.
- No IndexedDB, persistence or Saved Analysis changes.
- No Your Trades, journal, chart, Risk/Reward or Calculation Brain changes.
- No navigation ownership change beyond the already-released `/` -> `HomeRoute` boundary.

Live Crypto Bubble and Your Trades remain separate truth domains. Concrete visual Bubble sizing/layout remains intentionally unresolved until authoritative product/design policy supplies those values; this amendment does not guess them.
