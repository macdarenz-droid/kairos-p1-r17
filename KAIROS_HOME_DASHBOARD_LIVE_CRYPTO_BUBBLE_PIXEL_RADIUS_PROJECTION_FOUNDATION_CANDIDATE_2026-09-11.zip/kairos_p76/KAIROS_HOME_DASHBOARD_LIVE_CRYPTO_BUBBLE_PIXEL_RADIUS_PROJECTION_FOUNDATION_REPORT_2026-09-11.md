# Kairos Home Dashboard Live Crypto Bubble Pixel-Radius Projection Foundation — 2026-09-11

## Base authority

This candidate is based only on the Gate374 canonical GOLDEN candidate `KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_PIXEL_RADIUS_POLICY_CONTRACT_FOUNDATION_CANDIDATE_2026-09-11.zip` (`1,732,158` bytes; SHA-256 `a95edc13e580b44c51f59b77cb2754c71d64442e3517e1a6365b222b0b107a6f`; Git blob `dfd11e339d47dfbedfae5b729b1a5b14c30d416a`; root exactly `kairos_p76/`).

## Single responsibility

The candidate adds one pure provider-neutral pixel-radius projection boundary. It accepts one exact released `HomeDashboardLiveCryptoBubbleRadiusScaleProjectionResult` plus one caller-supplied `HomeDashboardLiveCryptoBubblePixelRadiusPolicy`.

It preserves an upstream radius-scale failure by exact reference. For a successful upstream projection it delegates the caller policy exactly once to released Gate374 `validateHomeDashboardLiveCryptoBubblePixelRadiusPolicy(...)`; invalid policy evidence is returned without fallback or policy rewriting.

For each successful radius-scale entry, exact input order and the exact `radiusScaleEntry` reference are preserved. `radiusScale: null` maps to `radiusCssPixels: null`. A present finite normalized `radiusScale` in `[0,1]` is mapped only inside the caller-owned bounds using linear interpolation:

`minimumRadiusCssPixels + radiusScale * (maximumRadiusCssPixels - minimumRadiusCssPixels)`.

Equal caller bounds remain equal for every present radius scale. Invalid normalized scale evidence fails closed rather than being clamped, sorted, filtered, or substituted.

## Explicit non-scope

This foundation introduces **no default minimum or maximum Bubble radius values**. It does not choose responsive breakpoints, read browser viewport APIs, own collision/packing/layout/label-fit/hit-target policy, render SVG/canvas/DOM/React Bubble geometry, mutate HomeRoute, choose palette/CSS/theme/motion, or own provider/acquisition/freshness/ranking/Top-N/stablecoin semantics. It does not own persistence, Saved Analysis, Your Trades, journal, chart, Risk/Reward, or Calculation Brain truth.

The projection is presentation arithmetic only. The authoritative size metric remains released 24h quote-volume truth upstream; this layer only maps released normalized presentation evidence into caller-bounded CSS-pixel radius.

Live Crypto Bubble and Your Trades Bubble remain separate truth domains.

## Next boundary remains unresolved by design

This candidate still supplies no concrete default radius values and no visible Bubble renderer/layout. Default bounds, responsive breakpoints, collision/packing, label fit, interactions, and visual rendering remain later controlled product/design/presentation boundaries and must not be guessed.
