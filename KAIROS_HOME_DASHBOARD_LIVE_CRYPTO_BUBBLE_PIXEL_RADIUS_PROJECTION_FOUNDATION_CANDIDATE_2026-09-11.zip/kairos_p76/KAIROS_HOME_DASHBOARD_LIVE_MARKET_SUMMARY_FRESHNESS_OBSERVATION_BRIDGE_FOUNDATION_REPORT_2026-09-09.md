# Home Dashboard Live Market Summary Freshness Observation Bridge Foundation

## Authority
Base: exact canonical Gate338 freshness-evaluation projection candidate, promoted by `Kairos Controlled Roadmap Gate` #338 / run `34405539024`.

## Source-proven responsibility
The released Home lifecycle observer already separates resolved acquisition results (`onResult`) from rejected/throwing acquisition work (`onError`). Each resolved scoped-snapshot acquisition result preserves both orchestration/session status and the exact scoped snapshot. Released baseline-state orchestration deliberately retains prior authoritative facts on acquisition failure. Gate338 separately owns deterministic fact freshness from exact scoped snapshot + explicit caller-owned evaluation time. No production owner yet composes these two released truths.

This slice therefore adds one provider-neutral non-presentation observation bridge. For each lifecycle `onResult`, it reads the caller-owned evaluation-time source exactly once, delegates the exact `result.scopedSnapshot` unchanged to Gate338, and emits the original acquisition result and Gate338 freshness evaluation as separate fields. Acquisition/session failure is never reinterpreted as stale/expired; retained facts may still be independently evaluated. The existing lifecycle `onError` channel is forwarded unchanged.

## Error boundary
- A deterministic Gate338 result such as `evaluation-time-invalid`, `fact-invalid`, or `observation-after-evaluation` remains observation data and is not converted into a lifecycle error.
- If the injected evaluation-time source itself throws, the bridge forwards that exact error through its sink error channel and emits no observation for that lifecycle result.
- The bridge does not catch or reinterpret sink callback failures; sink behavior remains caller ownership.

## Explicit non-scope
No provider/Binance transport, request/decode/mapping, acquisition/session mutation, 5-second cadence/visibility/lifecycle scheduling, retry/cancellation, universe/ranking/Top-N/stablecoin policy, freshness thresholds, internal wall clock, persistence/IndexedDB, React/Home/Bubble rendering, stale/expired visual treatment, Bubble geometry/size/color/interactions, Your Trades/journal, chart/navigation/Saved Analysis/transitions.

This foundation intentionally stops at a provider-neutral observation seam. Later Home runtime/presentation wiring may inject it into the already-released lifecycle observer option without moving acquisition or freshness truth into React.
