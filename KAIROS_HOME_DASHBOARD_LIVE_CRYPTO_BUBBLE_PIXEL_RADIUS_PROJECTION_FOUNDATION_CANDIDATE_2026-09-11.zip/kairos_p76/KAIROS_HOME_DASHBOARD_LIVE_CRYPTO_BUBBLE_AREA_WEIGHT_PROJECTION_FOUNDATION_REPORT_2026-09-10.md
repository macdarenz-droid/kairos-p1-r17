# Kairos Home Dashboard Live Crypto Bubble Area-Weight Projection Foundation

## Responsibility

This candidate adds one provider-neutral normalized area-weight projection below React rendering. It consumes one already-released Home Dashboard Live Crypto Bubble presentation-state projection and adds only a deterministic relative visual-area preparation value.

The 24h quote volume remains the authoritative size metric. The new projection does not replace or rewrite that metric: each output entry preserves the exact upstream presentation entry by reference and derives only `areaWeight = quoteVolume24h / maximum present quoteVolume24h` with the released Decimal kernel.

## Semantics

- Upstream presentation-state failure is preserved as exact non-renderable evidence.
- Present entries use only the already-released non-negative `quoteVolume24h`.
- The largest present quote volume receives exact Decimal weight `1`.
- Other present entries receive an exact Decimal ratio in the inclusive `[0,1]` range implied by the released non-negative metric contract.
- Missing entries remain explicit with `areaWeight: null`.
- If every present quote volume is zero, every present `areaWeight` stays exact Decimal zero. This layer does not invent a minimum visible size.
- Entry order and upstream metric/freshness/movement semantic identity are unchanged.

## Ownership / non-scope

This is a presentation-only preparation boundary. It does not sort, filter, rank, choose Top-N, select stablecoin exclusions, reclassify movement/freshness, or create provider/runtime/session truth. It has no clock, acquisition, persistence, DOM, React lifecycle, interaction, animation, or Your Trades/journal ownership.

Pixel radius, minimum visible radius, collision/layout and theme color remain later presentation owners. This candidate deliberately performs no square-root conversion, no pixel geometry, no CSS/design-token selection, and no visible rendering.

## Verification intent

Dedicated regression proves exact order/reference preservation, maximum-relative Decimal normalization, explicit missing values, all-zero behavior, upstream failure preservation, and fail-closed handling for inconsistent released entry shape. Static verification rejects sorting, policy constants, clocks, provider/runtime calls, React, pixel/radius/layout and styling ownership.
