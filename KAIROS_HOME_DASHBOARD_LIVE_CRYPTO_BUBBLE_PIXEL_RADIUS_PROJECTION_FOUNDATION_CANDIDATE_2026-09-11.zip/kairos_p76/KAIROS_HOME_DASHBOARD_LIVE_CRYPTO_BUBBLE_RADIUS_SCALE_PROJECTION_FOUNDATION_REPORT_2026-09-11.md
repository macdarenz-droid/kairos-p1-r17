# Kairos Home Dashboard Live Crypto Bubble Radius-Scale Projection Foundation Report — 2026-09-11

## Authority

This candidate starts only from the exact Gate363 canonical GOLDEN candidate `KAIROS_HOME_DASHBOARD_LIVE_CRYPTO_BUBBLE_HOME_ROUTE_TEXT_RUNTIME_INTEGRATION_FOUNDATION_CANDIDATE_2026-09-11.zip`, size `1,686,493` bytes, SHA-256 `24718bc32095bd249cf00b01ec8d6e6b0cac13e5ad66f8c17fc95a68ffd55b71`, root exactly `kairos_p76/`.

Gate363 canonically releases HomeRoute textual-runtime integration. Gate352 already owns normalized Bubble `areaWeight` evidence. The user-approved renderer policy states that visual circle area is proportional to `areaWeight`, therefore normalized radius is proportional to `sqrt(areaWeight)`. No released owner currently performs that presentation-only square-root conversion.

## Released responsibility

`src/application/dashboard/homeDashboardLiveCryptoBubbleRadiusScaleProjection.ts` adds one pure normalized radius-scale projection below DOM/React rendering.

It:
- accepts one exact Gate352 `HomeDashboardLiveCryptoBubbleAreaWeightProjectionResult`;
- preserves an upstream Gate352 failure by exact reference as non-renderable evidence;
- preserves each exact successful Gate352 area-weight entry by reference and preserves entry order;
- maps `areaWeight: null` to `radiusScale: null`;
- maps finite normalized values in `[0,1]` to `radiusScale = sqrt(areaWeight)`, including exact boundary behavior `0 -> 0` and `1 -> 1`; and
- fails closed with the exact entry index if a value presented as successful is non-finite or outside `[0,1]`.

The conversion to JavaScript `number` is presentation-only. It does not replace, round, mutate or feed back into the authoritative quote-volume metric or Gate352 Decimal `areaWeight` evidence.

## Explicit non-scope

- No pixel radius, minimum/maximum pixel radius or minimum visible-size choice.
- No viewport/device measurement, collision/packing/layout, label fit or interaction.
- No SVG/canvas/DOM/React rendering.
- No theme token, palette, CSS, opacity/dimming or motion.
- No provider/request/response/acquisition/retry behavior.
- No ranking, Top-N, stablecoin, movement, freshness, lifecycle, cadence, timer or clock ownership.
- No persistence/IndexedDB/Saved Analysis.
- No Your Trades, journal, chart, Risk/Reward or Calculation Brain changes.

Live Crypto Bubble and Your Trades Bubble remain separate truth domains.

## Verification intent

Dedicated regression proves exact reference/order preservation, `1 -> 1`, `0.25 -> 0.5`, `0 -> 0`, explicit missing radius scale, non-sorting behavior, exact upstream failure-reference preservation and fail-closed handling for non-finite/out-of-range successful inputs. Static verification rejects pixel/layout/theme/React/provider/persistence ownership.

This slice deliberately stops before responsive pixel sizing and collision/layout. Those remain the next renderer/pixel-policy responsibilities and must consume this normalized radius scale without reinterpreting market or area truth.
