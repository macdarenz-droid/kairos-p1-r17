import 'fake-indexeddb/auto';
import Dexie from 'dexie';
import { afterEach, describe, expect, it } from 'vitest';
import {
  KAIROS_BACKUP_FORMAT_NAME,
  KAIROS_BACKUP_FORMAT_VERSION,
  createKairosDatabaseSnapshot,
} from '../src/data/backup';
import { createKairosDatabase } from '../src/data/database';

const databaseNames: string[] = [];

function testDatabaseName(label: string): string {
  const name = `kairos-p6-2-${label}-${crypto.randomUUID()}`;
  databaseNames.push(name);
  return name;
}

afterEach(async () => {
  for (const name of databaseNames.splice(0)) await Dexie.delete(name);
});

describe('P6.2 database snapshot/export ownership', () => {
  it('exports authoritative metadata through a read-only database snapshot', async () => {
    const db = createKairosDatabase(testDatabaseName('snapshot'));
    await db.open();
    await db.metadata.bulkPut([
      { key: 'z-last', value: '2', updatedAt: '2026-08-31T08:00:02.000Z' },
      { key: 'a-first', value: '1', updatedAt: '2026-08-31T08:00:01.000Z' },
    ]);

    const envelope = await createKairosDatabaseSnapshot(db, {
      exportedAt: new Date('2026-08-31T08:40:00.000Z'),
      appVersion: 'snapshot-test',
      buildId: 'snapshot-build',
    });

    expect(envelope).toMatchObject({
      formatName: KAIROS_BACKUP_FORMAT_NAME,
      formatVersion: KAIROS_BACKUP_FORMAT_VERSION,
      appVersion: 'snapshot-test',
      buildId: 'snapshot-build',
      databaseSchemaVersion: 1,
      recordCounts: { metadata: 2, total: 2 },
    });
    expect(envelope.payload.metadata.map((record) => record.key)).toEqual(['a-first', 'z-last']);
    expect(await db.metadata.count()).toBe(2);
    db.close();
  });

  it('returns detached backup records so later object mutation cannot alter persisted data', async () => {
    const db = createKairosDatabase(testDatabaseName('detached'));
    await db.open();
    await db.metadata.put({ key: 'theme', value: 'dark', updatedAt: '2026-08-31T08:00:00.000Z' });

    const envelope = await createKairosDatabaseSnapshot(db);
    const exported = envelope.payload.metadata[0] as { key: string; value: string; updatedAt: string };
    exported.value = 'light';

    expect((await db.metadata.get('theme'))?.value).toBe('dark');
    db.close();
  });

  it('fails closed when database integrity is invalid instead of exporting corrupt data as a valid backup', async () => {
    const db = createKairosDatabase(testDatabaseName('corrupt'));
    await db.open();
    await db.metadata.put({ key: 'theme', value: 'dark', updatedAt: 'not-an-iso-date' });

    await expect(createKairosDatabaseSnapshot(db)).rejects.toThrow('database integrity check failed');
    expect(await db.metadata.count()).toBe(1);
    db.close();
  });

  it('does not perform restore, delete, clear, bulkPut, put, add, or update operations', async () => {
    const source = await import('../src/data/backup/backupSnapshot?raw');
    expect(source.default).not.toMatch(/\.(?:delete|clear|bulkPut|put|add|update)\s*\(/);
  });
});
