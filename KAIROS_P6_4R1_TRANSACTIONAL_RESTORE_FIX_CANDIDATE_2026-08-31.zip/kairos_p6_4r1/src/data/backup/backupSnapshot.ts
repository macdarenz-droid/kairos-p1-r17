import type { KairosDatabase } from '../database/KairosDatabase';
import { assertKairosDatabaseIntegrity } from '../database/integrity';
import { createKairosRepositories, type KairosRepositories } from '../repositories';
import { createKairosBackupEnvelope } from './backupEnvelope';
import type { KairosBackupEnvelopeV1 } from './backupFormat';

export interface CreateKairosDatabaseSnapshotOptions {
  readonly exportedAt?: Date;
  readonly appVersion?: string;
  readonly buildId?: string;
}

function sortMetadataByKey<T extends { readonly key: string }>(records: readonly T[]): T[] {
  return [...records].sort((left, right) => left.key.localeCompare(right.key));
}

export async function createKairosDatabaseSnapshot(
  db: KairosDatabase,
  options: CreateKairosDatabaseSnapshotOptions = {},
): Promise<KairosBackupEnvelopeV1> {
  await assertKairosDatabaseIntegrity(db);
  const repositories: KairosRepositories = createKairosRepositories(db);

  const metadata = await db.transaction('r', db.metadata, async () => {
    const records = await repositories.metadata.listAll();
    return sortMetadataByKey(records);
  });

  return createKairosBackupEnvelope({
    metadata,
    exportedAt: options.exportedAt,
    appVersion: options.appVersion,
    buildId: options.buildId,
    databaseSchemaVersion: db.verno,
  });
}
