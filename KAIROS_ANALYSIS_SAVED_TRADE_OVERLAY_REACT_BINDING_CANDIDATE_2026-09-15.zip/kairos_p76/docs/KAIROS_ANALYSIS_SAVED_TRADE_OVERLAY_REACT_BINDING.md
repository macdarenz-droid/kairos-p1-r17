# Analysis saved-trade overlay React binding

Status: Gate460 candidate from FULL canonical Gate459  
UI visible: no

## Purpose

`useAnalysisSavedTradeOverlayPresentationSession` owns one shared session per mounted hook around Gate459. It exposes Gate459's exact renderer factory and delegates the same P12-hydrated saved trade, caller-authoritative chart scope, caller-authoritative history snapshot, chart theme, logical time extent, style source and revision through that single session.

Marker and Risk/Reward results independently refresh the exact Gate459 presentation snapshot. Marker projection waits for the caller-authoritative history snapshot. If either released lower owner rejects ambiguous evidence, the hook retains the last accepted aggregate result and records only that owner's exact error. A synchronous construction failure exposes no renderer or presentation. Unmount closes only the hook's own Gate459 session.

## Ownership boundaries

- Gate459 remains the sole marker/Risk-Reward application and shared-renderer composition owner.
- Gate443 and Gate455 remain the exact lower projection owners.
- P14 owns saved plan and execution facts; P17 owns chart rendering and conversions; P19 owns Risk/Reward semantics; P20 remains the Saved Analysis persistence owner.
- The hook does not import or mount the Analysis route, workspace or live-candle canvas.
- There is no history acquisition, transport, provider primitive, scale/Canvas duplication, persistence, journal mutation, arithmetic or normalization, and no execution, venue, FX or P&L inference.

## Verification

- one Gate459 session and exact renderer-factory identity per mount;
- exact independent marker and Risk/Reward input delegation;
- marker wait for authoritative history;
- stable session reuse across selection, theme, extent, style and revision changes;
- preservation of the last complete presentation after either lower owner rejects ambiguity;
- construction failure and idempotent unmount cleanup;
- lower-owner verifiers, focused tests, TypeScript, production build and full regression.

This remains an unmounted non-UI prerequisite. Live-candle composition, workspace mounting and accessible Risk/Reward evidence are later bounded responsibilities. P21 remains active.
