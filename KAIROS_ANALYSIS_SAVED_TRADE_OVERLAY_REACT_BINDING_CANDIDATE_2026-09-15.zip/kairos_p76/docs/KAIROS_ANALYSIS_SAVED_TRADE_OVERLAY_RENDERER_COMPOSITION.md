# Analysis saved-trade overlay renderer composition

UI visible: no.

Gate457 is the FULL canonical base. This item-5 prerequisite lets the already-released saved-execution marker binding and saved-trade Risk/Reward primitive binding share one exact P17 production candlestick-series lifecycle.

`analysisSavedTradeOverlayRendererSession.ts` exposes one renderer factory and creates both lower bindings only when that factory reports the exact active candlestick series. Marker and Risk/Reward inputs remain independent, unchanged caller evidence; each lower owner retains its own provider plugin or primitive. Series replacement closes both bindings before attaching replacements, reapplies only the latest exact evidence, rejects overlapping or mismatched lifecycle evidence, and closes idempotently in reverse attachment order.

This slice deliberately does not replace Gate443 or Gate455 application projection ownership and is not imported by a React hook, live canvas, workspace or route. A later composition may delegate their exact marker and Risk/Reward results into this shared renderer session before any visible mount.

There is no new history request, transport, provider implementation, scale conversion, Canvas drawing logic, P18 interaction, P20 persistence, journal read or mutation, arithmetic or normalization, and no execution, venue, FX or P&L inference. P14 preserves saved execution/plan truth, P17 preserves production renderer and series lifecycle truth, and P19 preserves Risk/Reward semantics. Missing evidence never becomes zero.

Verification includes dedicated shared-series, replacement, unavailable, rollback, mismatch and idempotent-close regressions; all released marker/Risk/Reward lower-owner tests; TypeScript; production build; fresh-extract root/path/integrity checks; and the complete canonical gate under exact Node 22.16.0, npm 10.9.2 and Lightweight Charts 5.2.1.
