# Analysis saved-trade Risk/Reward live-candle composition

UI visible: no.

Gate456 is the FULL canonical base. This item-5 slice composes its React-owned saved-trade Risk/Reward presentation session with the released live-candle canvas without mounting that composition in the Analysis route or workspace.

Gate456 receives the exact P12-hydrated saved trade, caller-authoritative chart scope, logical extent, style source and refresh revision. Its exact renderer factory is injected into the existing live-candle route session, which retains the only authoritative history request, provider lifecycle and production candlestick renderer. The composition waits until that renderer factory exists before starting the live owner and delegates selection replacement through exact venue, symbol, interval and caller revision evidence.

Gate456 retains logical Risk/Reward and renderer-presentation ownership. Gate455 remains the application composition owner, Gate454 remains production Risk/Reward renderer lifecycle owner, and the released live-candle chain retains acquisition, transport, provider, reconnect, gap recovery, hidden/offline and status ownership. P14/P17/P18/P19/P20 are unchanged.

`AnalysisRoute`, `AnalysisHistoryWorkspace`, `AnalysisSavedTradeLiveCandleCanvas` and the mounted workspace path remain unchanged, so there is no visible UI change. This slice adds no history request, transport, snapshot inference, provider expansion, persistence or journal mutation, duplicates no scale or Canvas behavior, performs no arithmetic or normalization, and makes no execution, venue, FX or P&L inference. Missing evidence never becomes zero.

Verification includes a dedicated ownership verifier, focused React composition and released lower-owner regressions, TypeScript, production build, fresh-extract root/path/integrity checks, and the complete canonical gate with exact Node 22.16.0, npm 10.9.2 and Lightweight Charts 5.2.1.
