import { readFileSync } from 'node:fs';
const format=readFileSync('src/data/backup/backupFormat.ts','utf8');
const validation=readFileSync('src/data/backup/backupValidation.ts','utf8');
const snapshot=readFileSync('src/data/backup/backupSnapshot.ts','utf8');
const preflight=readFileSync('src/data/backup/restorePreflight.ts','utf8');
const schema=readFileSync('src/data/database/schema.ts','utf8');
const tests=readFileSync('tests/backup-envelope.test.ts','utf8');
const checks=[
 [format.includes('KAIROS_BACKUP_FORMAT_VERSION = 2 as const'), 'backup format version must remain V2'],
 [format.includes('KairosBackupDatabaseSchemaVersionV2 = 2 | 3'), 'V2 format must explicitly support schema 2 and 3'],
 [validation.includes('input.databaseSchemaVersion !== 2 && input.databaseSchemaVersion !== 3'), 'validation must reject schemas outside supported 2/3'],
 [snapshot.includes('databaseSchemaVersion: KAIROS_DB_SCHEMA_VERSION'), 'new snapshots must report current DB schema'],
 [schema.includes('KAIROS_DB_SCHEMA_VERSION = 3 as const'), 'current DB schema must remain v3'],
 [preflight.includes('envelope.databaseSchemaVersion !== 2 && envelope.databaseSchemaVersion !== 3'), 'restore preflight must preserve schema-v2 backup compatibility'],
 [tests.includes('existing V2-format schema V2 backup'), 'schema-v2 backup compatibility regression fixture required'],
 [tests.includes('databaseSchemaVersion:3'), 'current backup envelope must identify schema v3'],
];
for (const [ok,msg] of checks) { if(!ok){ console.error(`P12.4R1 verification FAIL: ${msg}`); process.exit(1); } }
console.log('P12.4R1 status-index backup compatibility repair verification PASS');
