import { readFileSync } from 'node:fs';
const route=readFileSync('src/app/JournalRoute.tsx','utf8');
const list=readFileSync('src/app/JournalHistoryList.tsx','utf8');
const tests=readFileSync('tests/journal-history-route.test.tsx','utf8');
const checks=[
 [route.includes('listJournalHistory(db)'), 'route must consume P12 query owner'],
 [route.includes('await refreshHistory()'), 'successful save must refresh history'],
 [route.includes('<JournalHistoryList'), 'journal route must render history component'],
 [!list.toLowerCase().includes('indexeddb') && !list.includes('createKairosRepositories'), 'history renderer must not own storage/repositories'],
 [list.includes("entry.metrics?.netPnl ?? 'Not available'"), 'missing net P&L must render as unavailable'],
 [list.includes('entry.metricsError'), 'calculation evidence errors must remain visible'],
 [list.includes('aria-busy') && list.includes('role="alert"'), 'loading/error accessibility states required'],
 [list.includes('aria-live="polite"'), 'loading state must remain politely announced'],
 [!list.includes('role="status">Loading trade history'), 'history loading must not collide with P10 save status role'],
 [tests.includes("findByRole('status')") && tests.includes('Trade saved to your journal.'), 'P10 save status accessibility regression must be pinned'],
];
for(const [ok,msg] of checks){if(!ok){console.error(`P12.3R1 verification FAIL: ${msg}`);process.exit(1)}}
console.log('P12.3R1 journal history route repair verification PASS');
