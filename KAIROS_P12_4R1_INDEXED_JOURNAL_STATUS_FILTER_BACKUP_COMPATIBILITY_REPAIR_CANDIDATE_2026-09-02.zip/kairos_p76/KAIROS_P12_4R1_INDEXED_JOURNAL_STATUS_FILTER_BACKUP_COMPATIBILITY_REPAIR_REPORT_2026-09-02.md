# KAIROS P12.4R1 Indexed Journal Status Filter + Backup Compatibility Repair

## Status
HOLD pending canonical GitHub gate.

## Authoritative base
Exact P12.3R1 canonical PASS artifact from run #57.

## Failed predecessor
P12.4 run #58 failed at TypeScript build because schema v3 widened `KAIROS_DB_SCHEMA_VERSION` while the V2 backup envelope type still hard-coded database schema v2.

## Repair decision
Keep backup **format version 2** because the v3 database migration adds only an IndexedDB index and does not change persisted record payload shapes. V2-format backups may therefore identify database schema 2 or 3. Existing schema-v2 backups remain accepted; new snapshots identify the current schema v3. Legacy V1 backups still migrate to the established V2 restore model with schema 2.

## P12.4 functionality retained
- DB schema v3 adds `[status+updatedAt]`.
- repository performs bounded newest-first status query through the compound index.
- `listJournalHistory` delegates status filtering to repository before child hydration.
- no UI filter controls in this patch.

## Compatibility updates
- backup format remains V2.
- V2 envelope schema header accepts only 2 or 3.
- current snapshots/recovery snapshots report schema 3.
- restore preflight accepts schema 2 and 3 V2-format backups.
- current-schema regression assertions advance to v3; synthetic v2 migration and legacy backup fixtures remain v2.

## Non-scope
No backup-format V3, no payload shape changes, no journal UI filter, no edit/delete, no P13 work.
