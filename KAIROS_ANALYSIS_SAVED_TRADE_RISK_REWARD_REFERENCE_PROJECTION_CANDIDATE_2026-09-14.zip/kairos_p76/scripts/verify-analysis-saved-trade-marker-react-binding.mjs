import { existsSync, readFileSync } from 'node:fs';

const hookPath = 'src/app/useAnalysisSavedTradeMarkerPresentationSession.ts';
const testPath = 'tests/analysis-saved-trade-marker-react-binding.test.tsx';
const docPath = 'docs/KAIROS_ANALYSIS_SAVED_TRADE_MARKER_REACT_BINDING.md';
for (const file of [hookPath, testPath, docPath]) {
  if (!existsSync(file)) throw new Error(`missing-analysis-saved-trade-marker-react-binding:${file}`);
}

const hook = readFileSync(hookPath, 'utf8');
const tests = readFileSync(testPath, 'utf8');
const report = readFileSync(docPath, 'utf8');

for (const expected of [
  "from './analysisSavedTradeMarkerPresentationSession'",
  'createSession = createAnalysisSavedTradeMarkerPresentationSession',
  'created.rendererFactory',
  'snapshot === null',
  'current.present({ entry, scope, snapshot, theme })',
  'presentation, lastError: null',
  'created.close()',
  'scope.instrument.venue',
  'scope.instrument.symbol',
  'scope.quoteAsset',
]) if (!hook.includes(expected)) throw new Error(`analysis-saved-trade-marker-react-binding-drift:${expected}`);

for (const forbidden of [
  'AnalysisRoute', 'AnalysisHistoryWorkspace', 'AnalysisLiveCandleCanvas',
  'fetch(', 'WebSocket', 'setTimeout(', 'setInterval(', 'Date.now(', 'Math.random(',
  'indexedDB', 'localStorage', 'Dexie', 'createTrade', 'updateTrade', 'calculateTrade',
  'createSeriesMarkers', 'grossPnl', 'netPnl', 'executionVenue:',
]) if (hook.includes(forbidden)) throw new Error(`analysis-saved-trade-marker-react-binding-owner-violation:${forbidden}`);

for (const expected of [
  'mounts one released Gate443 session',
  'waits for and delegates the exact caller-authoritative snapshot',
  'reuses the same session for exact trade, scope, theme and caller-revision changes',
  'retains the last complete result',
  'closes only its own released session once on unmount',
  'synchronous session construction failure',
]) if (!tests.includes(expected)) throw new Error(`missing-analysis-saved-trade-marker-react-binding-regression:${expected}`);

for (const expected of [
  'UI visible: no', 'Gate443', 'one session per mounted hook',
  'caller-authoritative history snapshot', 'last complete result',
  'does not import or mount the Analysis route',
  'no execution, venue, FX or P&L inference',
]) if (!report.includes(expected)) throw new Error(`analysis-saved-trade-marker-react-binding-doc-drift:${expected}`);

console.log('Analysis saved-trade marker React binding verifier PASS');
