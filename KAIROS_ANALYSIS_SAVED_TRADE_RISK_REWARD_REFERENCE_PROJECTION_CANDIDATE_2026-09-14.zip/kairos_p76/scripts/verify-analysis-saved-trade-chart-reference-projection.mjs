import { readFileSync } from 'node:fs';

const read = path => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const source = read('src/app/analysisSavedTradeChartReferenceProjection.ts');
const tests = read('tests/analysis-saved-trade-chart-reference-projection.test.ts');
const report = read('docs/KAIROS_ANALYSIS_SAVED_TRADE_CHART_REFERENCE_PROJECTION.md');

for (const expected of [
  'projectTradeVisualizerFacts',
  "entry.trade.marketType !== 'crypto'",
  'entry.trade.symbol !== scope.instrument.symbol',
  "priceCurrency == null || priceCurrency === ''",
  'priceCurrency !== scope.quoteAsset',
  "kind: 'reference-ready'",
  'executionVenue: null',
]) if (!source.includes(expected)) throw new Error(`missing exact chart-reference boundary: ${expected}`);

for (const forbidden of [
  'parseFloat(', 'Number(', 'calculateTradeMetrics', 'indexedDB', 'localStorage',
  'WebSocket', 'fetch(', 'acquireHistory(', 'createChart(',
]) if (source.includes(forbidden)) throw new Error(`forbidden chart-reference owner: ${forbidden}`);

for (const expected of [
  'executionId: entryId',
  "executedAt: '2026-09-01T01:02:03.004Z'",
  "'market-type-mismatch'",
  "'symbol-mismatch'",
  "'price-currency-missing'",
  "'price-currency-mismatch'",
  'preserves missing executions as empty facts',
]) if (!tests.includes(expected)) throw new Error(`missing chart-reference regression: ${expected}`);

for (const expected of [
  'P14 remains the sole saved plan/execution projection owner',
  'execution venue remains not recorded',
  'no visible UI change',
  'no journal mutation',
  'no execution, FX or P&L inference',
]) if (!report.includes(expected)) throw new Error(`missing scope boundary: ${expected}`);

console.log('PASS: exact saved-trade facts are eligible only for a symbol/quote-aligned market-reference chart, with missing venue evidence explicit and no financial inference.');
