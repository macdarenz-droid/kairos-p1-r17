import { existsSync, readFileSync } from 'node:fs';

const files = [
  'src/app/AnalysisSavedTradeMarkerEvidencePresentation.tsx',
  'src/app/AnalysisSavedTradeLiveCandleCanvas.tsx',
  'tests/analysis-saved-trade-marker-evidence-presentation.test.tsx',
  'docs/KAIROS_ANALYSIS_SAVED_TRADE_MARKER_EVIDENCE_PRESENTATION.md',
];
for (const file of files) if (!existsSync(file)) throw new Error(`missing-saved-trade-marker-evidence-presentation:${file}`);

const view = readFileSync(files[0], 'utf8');
const canvas = readFileSync(files[1], 'utf8');
const tests = readFileSync(files[2], 'utf8');
const report = readFileSync(files[3], 'utf8');

for (const expected of [
  'AnalysisSavedTradeMarkerPresentationResult',
  'presentation.markers.kind === \'unavailable\'',
  'Saved trade markers · {markers.length} shown · {unplacedExecutions.length} not shown',
  'Saved execution marker evidence table',
  'row.executedAt', 'row.price', 'row.quantity', 'row.candle',
  'saved execution time is invalid', 'before available candle history',
  'after available candle history', 'candle history has a gap at this time',
  'last complete details remain unchanged',
]) if (!view.includes(expected)) throw new Error(`saved-trade-marker-evidence-presentation-drift:${expected}`);

for (const forbidden of [
  'JournalHistoryEntry', 'acquireHistory', 'fetch(', 'WebSocket', 'indexedDB', 'localStorage',
  'createTrade', 'updateTrade', 'calculateTrade', 'Decimal(', 'executionVenue:',
  'grossPnl', 'netPnl', 'lastError.message', 'String(lastError)',
]) if (view.includes(forbidden)) throw new Error(`saved-trade-marker-evidence-owner-violation:${forbidden}`);

for (const expected of [
  "from './AnalysisSavedTradeMarkerEvidencePresentation'",
  'presentation={marker.presentation}',
  'lastError={marker.lastError}',
  'quoteAsset={quoteAsset}',
  'if (createSession === null) return evidence',
]) if (!canvas.includes(expected)) throw new Error(`saved-trade-marker-evidence-canvas-drift:${expected}`);

for (const expected of [
  'announces preparation without claiming any marker placement',
  'presents exact placed and unplaced execution evidence accessibly',
  'explains exact fail-closed reference eligibility without inventing marker facts',
  'retains complete evidence and never exposes a lower-owner error',
]) if (!tests.includes(expected)) throw new Error(`missing-saved-trade-marker-evidence-regression:${expected}`);

for (const expected of [
  'UI visible: yes', 'Gate446', 'exact saved execution facts', 'explicitly unplaced',
  'no execution, venue, FX or P&L inference', 'P19', 'P18', 'P20',
]) if (!report.includes(expected)) throw new Error(`saved-trade-marker-evidence-report-drift:${expected}`);

console.log('Analysis saved-trade marker evidence presentation verifier PASS');
