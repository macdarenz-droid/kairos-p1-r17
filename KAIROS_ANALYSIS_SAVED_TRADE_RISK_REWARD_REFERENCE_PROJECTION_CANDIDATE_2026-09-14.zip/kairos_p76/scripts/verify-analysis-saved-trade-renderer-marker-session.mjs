import { readFileSync } from 'node:fs';

const read = path => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const source = read('src/app/analysisSavedTradeRendererMarkerSession.ts');
const renderer = read('src/features/chart/lightweightChartsV5ProductionRenderer.ts');
const tests = read('tests/analysis-saved-trade-renderer-marker-session.test.ts');
const rendererTests = read('tests/lightweight-charts-v5-production-renderer.test.ts');
const report = read('docs/KAIROS_ANALYSIS_SAVED_TRADE_RENDERER_MARKER_SESSION.md');

for (const expected of [
  'LightweightChartsV5ProductionCandlestickSeriesLifecycle',
  'createLightweightChartsV5ProductionRendererFactory',
  'createAnalysisSavedTradeLightweightChartsV5MarkerBinding',
  "kind: 'pending-series'",
  'next.present(latest.projection, latest.theme)',
  "throw new Error('analysis-saved-trade-renderer-marker-series-already-active')",
  "throw new Error('analysis-saved-trade-renderer-marker-series-mismatch')",
  "throw new Error('analysis-saved-trade-renderer-marker-session-closed')",
  'previous?.close()',
]) if (!source.includes(expected)) throw new Error(`missing renderer-marker session boundary: ${expected}`);

for (const expected of [
  'definition === lightweightChartsV5Package.CandlestickSeries',
  'candlestickSeriesLifecycle?.attach(series)',
  'candlestickSeriesLifecycle?.detach(observedCandlestickSeries)',
]) if (!renderer.includes(expected)) throw new Error(`missing production series lifecycle seam: ${expected}`);

for (const forbidden of [
  'indexedDB', 'localStorage', 'WebSocket', 'fetch(', 'calculateTradeMetrics',
  'decimalAdd', 'decimalSubtract', 'executionVenue', 'grossPnl', 'netPnl',
]) if (source.includes(forbidden)) throw new Error(`forbidden renderer-marker session owner: ${forbidden}`);

for (const expected of [
  'retains exact marker evidence until the production candle series is attached',
  'same active binding', 'renderer series replacement', 'overlapping or mismatched series lifecycles',
  'retained evidence fails during series activation', 'closes once',
]) if (!tests.includes(expected)) throw new Error(`missing renderer-marker session regression: ${expected}`);

for (const expected of [
  'exact active candlestick series lifecycle', "expect('series' in renderer).toBe(false)",
]) if (!rendererTests.includes(expected)) throw new Error(`missing production renderer seam regression: ${expected}`);

for (const expected of [
  'P17 remains the sole renderer and provider-series lifecycle owner',
  'P14 remains the sole saved execution-fact owner',
  'P18 drawing-tool ownership is unchanged',
  'no visible UI change', 'no journal mutation',
  'no execution, venue, FX or P&L inference',
]) if (!report.includes(expected)) throw new Error(`missing renderer-marker scope boundary: ${expected}`);

console.log('PASS: Gate441 marker binding composes with the exact released renderer candle series without widening saved-fact or drawing ownership.');
