import { readFileSync } from 'node:fs';

const read = path => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const source = read('src/app/analysisSavedTradeExecutionMarkerProjection.ts');
const tests = read('tests/analysis-saved-trade-execution-marker-projection.test.ts');
const report = read('docs/KAIROS_ANALYSIS_SAVED_TRADE_EXECUTION_MARKER_PROJECTION.md');

for (const expected of [
  "window.kind !== 'window-ready'",
  "markerId: `journal-execution:${execution.executionId}`",
  'candleAnchorTime: execution.placement.candleOpenTime',
  'candleCloseTime: execution.placement.candleCloseTime',
  'executedAt: execution.executedAt',
  'price: execution.price',
  'quantity: execution.quantity',
  'unplacedExecutions.push',
  "throw new Error('analysis-saved-trade-execution-marker-id-duplicate')",
]) if (!source.includes(expected)) throw new Error(`missing exact marker boundary: ${expected}`);

for (const forbidden of [
  'parseFloat(', 'Number(', 'calculateTradeMetrics', 'decimalAdd', 'decimalSubtract',
  'indexedDB', 'localStorage', 'WebSocket', 'fetch(', 'createChart(', 'createSeriesMarkers', 'setMarkers(',
]) if (source.includes(forbidden)) throw new Error(`forbidden marker-projection owner: ${forbidden}`);

for (const expected of [
  'exact authoritative candle', 'exact execution instant and zero price', 'instead of snapping',
  'history-scope-mismatch', 'duplicate execution identities', 'Object.isFrozen(result.markers)',
]) if (!tests.includes(expected)) throw new Error(`missing execution-marker regression: ${expected}`);

for (const expected of [
  'P14 remains the sole saved execution-fact owner',
  'candle anchor is presentation placement, not an execution-time rewrite',
  'missing is not zero', 'no visible UI change', 'no journal mutation',
  'no execution, venue, FX or P&L inference',
]) if (!report.includes(expected)) throw new Error(`missing marker scope boundary: ${expected}`);

console.log('PASS: exact saved executions become immutable provider-neutral marker facts only when Gate439 supplies an authoritative candle anchor.');
