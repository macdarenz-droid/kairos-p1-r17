import { existsSync, readFileSync } from 'node:fs';

const policyPath = 'src/app/analysisLiveCandleProductPolicy.ts';
const workspacePath = 'src/app/AnalysisHistoryWorkspace.tsx';
const routeSessionPath = 'src/app/analysisLiveCandleRouteSession.ts';
const bootstrapPath = 'src/app/binanceAnalysisHistoryLiveCandleBootstrapCoordination.ts';
const testPath = 'tests/analysis-live-candle-product-policy.test.ts';
const historicalVerifierPath = 'scripts/verify-analysis-history-workspace.mjs';
for (const file of [policyPath, workspacePath, routeSessionPath, bootstrapPath, testPath, historicalVerifierPath]) {
  if (!existsSync(file)) throw new Error(`missing-analysis-live-candle-product-policy:${file}`);
}

const policy = readFileSync(policyPath, 'utf8');
const workspace = readFileSync(workspacePath, 'utf8');
const routeSession = readFileSync(routeSessionPath, 'utf8');
const bootstrap = readFileSync(bootstrapPath, 'utf8');
const test = readFileSync(testPath, 'utf8');
const historicalVerifier = readFileSync(historicalVerifierPath, 'utf8');

for (const token of [
  'ANALYSIS_LIVE_CANDLE_HISTORY_LIMIT = 500',
  'ANALYSIS_LIVE_CANDLE_RECONNECT_POLICY',
  'initialDelayMs: 1_000',
  'maxDelayMs: 8_000',
  'maxAttempts: 4',
  'Object.freeze',
]) if (!policy.includes(token)) throw new Error(`missing-analysis-product-policy-token:${token}`);

for (const token of [
  "from './analysisLiveCandleProductPolicy'",
  '{ANALYSIS_LIVE_CANDLE_HISTORY_LIMIT} candles',
]) if (!workspace.includes(token)) throw new Error(`workspace-policy-drift:${token}`);

for (const token of [
  "from './analysisLiveCandleProductPolicy'",
  'historyLimit: ANALYSIS_LIVE_CANDLE_HISTORY_LIMIT',
]) if (!routeSession.includes(token)) throw new Error(`route-session-policy-drift:${token}`);

for (const token of [
  'limit: historyLimit',
  'received.limit !== request.limit',
]) if (!bootstrap.includes(token)) throw new Error(`bootstrap-policy-drift:${token}`);

for (const token of ['acquireHistory(', 'received.limit', 'historyLimit:']) {
  if (workspace.includes(token)) throw new Error(`duplicate-workspace-history-policy:${token}`);
}

for (const token of [
  'ANALYSIS_LIVE_CANDLE_HISTORY_LIMIT = 500',
  'historyLimit: ANALYSIS_LIVE_CANDLE_HISTORY_LIMIT',
  'received.limit !== request.limit',
]) if (!historicalVerifier.includes(token)) throw new Error(`historical-verifier-policy-drift:${token}`);

for (const token of [
  'shares the released 500-candle authoritative history limit',
  'publishes one immutable bounded reconnect policy',
  'delegates exponential delay and attempt-limit decisions to released P15',
  'decideMarketDataReconnect',
]) if (!test.includes(token)) throw new Error(`missing-analysis-product-policy-evidence:${token}`);

for (const forbidden of [
  'WebSocket', 'fetch(', 'setTimeout(', 'setInterval(', 'Math.random(', 'Date.now(',
  'indexedDB', 'localStorage', 'Dexie', 'createTrade', 'updateTrade', 'calculateTrade',
  'createSeriesMarkers', 'AnalysisRoute', 'useEffect', 'useState',
]) if (policy.includes(forbidden)) throw new Error(`analysis-product-policy-ownership-violation:${forbidden}`);

console.log('Analysis live candle product policy verifier PASS');
