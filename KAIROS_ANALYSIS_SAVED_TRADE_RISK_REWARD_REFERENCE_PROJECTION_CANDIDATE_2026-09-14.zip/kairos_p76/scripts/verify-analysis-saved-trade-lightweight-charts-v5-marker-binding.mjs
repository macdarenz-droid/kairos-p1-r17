import { readFileSync } from 'node:fs';

const read = path => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const source = read('src/app/analysisSavedTradeLightweightChartsV5MarkerBinding.ts');
const tests = read('tests/analysis-saved-trade-lightweight-charts-v5-marker-binding.test.ts');
const report = read('docs/KAIROS_ANALYSIS_SAVED_TRADE_LIGHTWEIGHT_CHARTS_V5_MARKER_BINDING.md');

for (const expected of [
  "from 'lightweight-charts'",
  'createSeriesMarkers(series, markers)',
  'projectChartTimestamp(marker.candleAnchorTime)',
  'projectChartDecimal(marker.price)',
  "position: 'atPriceMiddle'",
  "shape: marker.role === 'entry' ? 'circle' : 'square'",
  'theme.drawingPrimary',
  'theme.drawingSecondary',
  'projection.unplacedExecutions',
  "throw new Error('analysis-saved-trade-marker-binding-closed')",
  'plugin?.detach()',
]) if (!source.includes(expected)) throw new Error(`missing exact provider-marker boundary: ${expected}`);

for (const forbidden of [
  'indexedDB', 'localStorage', 'WebSocket', 'fetch(', 'calculateTradeMetrics',
  'decimalAdd', 'decimalSubtract', 'executionVenue', 'grossPnl', 'netPnl',
]) if (source.includes(forbidden)) throw new Error(`forbidden provider-marker owner: ${forbidden}`);

for (const expected of [
  'preserving zero as an exact marker price', 'without creating a second marker owner',
  'projection evidence becomes unavailable', 'no placed markers',
  'invalid exact time or decimal evidence', 'detaches once on close',
]) if (!tests.includes(expected)) throw new Error(`missing provider-marker regression: ${expected}`);

for (const expected of [
  'P17 remains the sole timestamp and decimal renderer-conversion owner',
  'P14 remains the sole saved execution-fact owner',
  'P18 drawing-tool ownership is unchanged',
  'missing is not zero', 'no visible UI change', 'no journal mutation',
  'no execution, venue, FX or P&L inference',
]) if (!report.includes(expected)) throw new Error(`missing provider-marker scope boundary: ${expected}`);

console.log('PASS: Gate440 exact execution markers bind to one Lightweight Charts v5 marker plugin without changing saved facts or drawing ownership.');
