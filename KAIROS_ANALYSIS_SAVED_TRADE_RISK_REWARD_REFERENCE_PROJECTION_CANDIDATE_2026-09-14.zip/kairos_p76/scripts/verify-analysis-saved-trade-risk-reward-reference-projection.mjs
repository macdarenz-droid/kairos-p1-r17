import { existsSync, readFileSync } from 'node:fs';

const files = [
  'src/app/analysisSavedTradeRiskRewardReferenceProjection.ts',
  'tests/analysis-saved-trade-risk-reward-reference-projection.test.ts',
  'docs/KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_REFERENCE_PROJECTION.md',
];
for (const file of files) if (!existsSync(file)) throw new Error(`missing-saved-trade-risk-reward-reference:${file}`);

const source = readFileSync(files[0], 'utf8');
const tests = readFileSync(files[1], 'utf8');
const report = readFileSync(files[2], 'utf8');

for (const expected of [
  'AnalysisSavedTradeChartReferenceProjection',
  'defineRiskRewardAnalysis',
  'projectRiskRewardChartSemantics',
  'projectRiskRewardChartStyle',
  'projectRiskRewardChartPlacement',
  'projectRiskRewardChartObject',
  "entry === null", "stop === null", "target === null",
  "id: `journal-risk-reward:${reference.tradeId}`",
  "kind: 'risk-reward-ready'",
  "unavailable('reference-unavailable'",
]) if (!source.includes(expected)) throw new Error(`saved-trade-risk-reward-reference-drift:${expected}`);

for (const forbidden of [
  'JournalHistoryEntry', 'executedEntries[', 'executedExits[', 'parseFloat(',
  'Decimal(', 'calculate', 'grossPnl', 'netPnl', 'executionVenue:',
  'fetch(', 'WebSocket', 'indexedDB', 'localStorage', 'createChart(',
]) if (source.includes(forbidden)) throw new Error(`saved-trade-risk-reward-owner-violation:${forbidden}`);

for (const expected of [
  'delegates exact planned levels and caller time extent through released P19 owners',
  'preserves short-side source ordering without normalizing prices',
  'keeps missing planned evidence explicit instead of substituting executions or candle prices',
  'treats an exact zero DecimalString as present rather than missing',
  'propagates exact chart-reference unavailability without creating Risk/Reward facts',
  'fails closed for invalid or reversed caller time evidence',
  'freezes the complete projection without mutating the caller reference',
]) if (!tests.includes(expected)) throw new Error(`missing-saved-trade-risk-reward-regression:${expected}`);

for (const expected of [
  'UI visible: no', 'Gate447', 'P14', 'P19', 'caller-authoritative time extent',
  'missing does not equal zero', 'no execution, venue, FX or P&L inference', 'P18', 'P20',
]) if (!report.includes(expected)) throw new Error(`saved-trade-risk-reward-report-drift:${expected}`);

console.log('Analysis saved-trade Risk/Reward reference projection verifier PASS');
