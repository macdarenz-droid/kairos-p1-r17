import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { spawn } from 'node:child_process';
const require = createRequire(resolve(process.env.KAIROS_BROWSER_PACKAGE_DIR ?? '.', 'package.json'));
const { chromium } = require('playwright');
const evidence = resolve('.analysis-history-evidence'); mkdirSync(evidence, { recursive: true });
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', '--host', '127.0.0.1', '--port', '4182', '--strictPort'], { stdio: 'pipe' });
let log = ''; server.stdout.on('data', x => log += x); server.stderr.on('data', x => log += x);
const documentBody = '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0}</style><div id="analysis-test-root"></div><script type="module">import RefreshRuntime from "/@react-refresh";RefreshRuntime.injectIntoGlobalHook(window);window.$RefreshReg$=()=>{};window.$RefreshSig$=()=>type=>type;window.__vite_plugin_react_preamble_installed__=true;const f=await import("/tests/fixtures/analysisHistoryBrowser.tsx");await f.mount();</script>';
const metadata = JSON.stringify({ symbols: [
  { symbol: 'ETHUSDT', status: 'TRADING', baseAsset: 'ETH', quoteAsset: 'USDT' },
  { symbol: 'BTCUSDT', status: 'TRADING', baseAsset: 'BTC', quoteAsset: 'USDT' },
  { symbol: 'TINYUSDT', status: 'TRADING', baseAsset: 'TINY', quoteAsset: 'USDT' },
] });
function rows(interval, symbol) {
  const duration = interval === '15m' ? 900000 : 300000, tiny = symbol === 'TINYUSDT';
  return Array.from({ length: 500 }, (_, i) => {
    const t = Date.UTC(2026, 8, 10) + i * duration;
    const open = 2000 + i * .5 + Math.sin(i * .3) * 25, close = open + (i % 3 ? 5 : -8);
    const price = n => tiny ? (n / 1e11).toFixed(12) : n.toFixed(2);
    return [t, price(open), price(Math.max(open, close) + 4), price(Math.min(open, close) - 3), price(close), '1', t + duration - 1, '1', 1, '1', '1', '0'];
  });
}
let browser, page;
try {
  let ready = false;
  for (let i = 0; i < 100; i++) { try { if ((await fetch('http://127.0.0.1:4182/')).ok) { ready = true; break; } } catch {} await new Promise(r => setTimeout(r, 200)); }
  assert(ready, log);
  browser = await chromium.launch({ headless: true, ...(process.env.KAIROS_CHROMIUM_EXECUTABLE ? { executablePath: process.env.KAIROS_CHROMIUM_EXECUTABLE, args: ['--no-sandbox', '--disable-dev-shm-usage', '--no-zygote', '--single-process'] } : {}) });
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, reducedMotion: 'reduce' });
  page = await context.newPage(); const errors = []; page.on('pageerror', e => { errors.push(e.message); console.error(e.stack); });
  const requests = [], liveSockets = []; let mode = 'metadata-offline';
  await page.routeWebSocket('wss://stream.binance.com:9443/ws/*', socket => {
    liveSockets.push(socket.url());
  });
  await page.route('https://**/*', async route => {
    const url = new URL(route.request().url()); requests.push(url.pathname + url.search);
    if (url.pathname === '/api/v3/exchangeInfo') {
      if (mode === 'metadata-offline') return route.abort();
      return route.fulfill({ status: 200, contentType: 'application/json', body: metadata });
    }
    if (url.pathname !== '/api/v3/klines') return route.abort();
    assert.equal(url.searchParams.get('timeZone'), '0'); assert.equal(url.searchParams.get('limit'), '500');
    if (mode === 'limited') return route.fulfill({ status: 429, headers: { 'Retry-After': '30' }, body: '{}' });
    if (mode === 'offline') return route.abort();
    return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(mode === 'empty' ? [] : rows(url.searchParams.get('interval'), url.searchParams.get('symbol'))) });
  });
  await page.route('http://127.0.0.1:4182/**', route => route.request().resourceType() === 'document' ? route.fulfill({ contentType: 'text/html', body: documentBody }) : route.continue());
  await page.goto('http://127.0.0.1:4182/analysis');
  await page.getByText('Supported symbols are unavailable. Check your connection.').waitFor();
  await page.getByText('No saved trades yet.', { exact: true }).waitFor();
  const original = await page.evaluate(async () => (await import('/tests/fixtures/analysisHistoryBrowser.tsx')).readSavedFacts());
  mode = 'ready'; await page.getByRole('button', { name: 'Retry symbols' }).click();
  await page.getByLabel('Chart symbol', { exact: true }).selectOption('ETHUSDT');
  assert.equal(requests.filter(x => x.startsWith('/api/v3/klines')).length, 0);
  await page.getByLabel('Timeframe', { exact: true }).selectOption('5m');
  await page.getByText('500 candles · Prices in USDT · Times in UTC', { exact: true }).waitFor();
  await page.getByText(/Live candles connected/).waitFor();
  assert.equal(await page.locator('[data-live-candle-status="live"]').count(), 1);
  assert.deepEqual(liveSockets, ['wss://stream.binance.com:9443/ws/ethusdt@trade']);
  await page.locator('.kairos-analysis-chart__canvas canvas').first().waitFor();
  const canvasPixels = () => page.locator('.kairos-analysis-chart__canvas').evaluate(el => {
    const canvas = el.querySelector('canvas'), data = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height).data;
    let up = 0, down = 0, hash = 0;
    for (let i = 0; i < data.length; i += 4) { if (data[i] === 69 && data[i+1] === 215 && data[i+2] === 167) up++; if (data[i] === 255 && data[i+1] === 111 && data[i+2] === 135) down++; hash = (hash + data[i] * (i + 1)) % 2147483647; }
    return { up, down, hash, width: canvas.width, height: canvas.height };
  });
  await page.waitForTimeout(600); const initial = await canvasPixels(); assert(initial.up > 40 && initial.down > 40, JSON.stringify({ initial, errors }));
  await page.screenshot({ path: resolve(evidence, '390-initial-candles.png'), fullPage: true });
  await page.getByRole('button', { name: 'Zoom in', exact: true }).click(); await page.waitForTimeout(100);
  const zoomed = await canvasPixels(); assert.notEqual(zoomed.hash, initial.hash);
  const chart = page.getByRole('group', { name: 'ETHUSDT 5m live candlestick chart', exact: true });
  await chart.focus(); await page.keyboard.press('ArrowLeft'); await page.waitForTimeout(100); assert.notEqual((await canvasPixels()).hash, zoomed.hash);
  // Touch pan through Chromium's actual input pipeline.
  await chart.scrollIntoViewIfNeeded(); const bounds = await chart.boundingBox(); const cdp = await context.newCDPSession(page);
  const x = bounds.x + bounds.width * .55, y = bounds.y + bounds.height * .4;
  const beforePan = await canvasPixels();
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] });
  for (let i = 1; i <= 6; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: x + i * 8, y }] });
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); await page.waitForTimeout(100);
  assert.notEqual((await canvasPixels()).hash, beforePan.hash);
  // Two-finger pinch changes the visible scale.
  const beforePinch = await canvasPixels();
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: x - 20, y }, { x: x + 20, y }] });
  for (let i = 1; i <= 5; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: x - 20 - i * 6, y }, { x: x + 20 + i * 6, y }] });
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); await page.waitForTimeout(100);
  assert.notEqual((await canvasPixels()).hash, beforePinch.hash);
  await page.getByRole('button', { name: 'Fit candles' }).click();
  await page.getByLabel('Chart symbol', { exact: true }).selectOption('TINYUSDT');
  await page.getByRole('group', { name: 'TINYUSDT 5m live candlestick chart', exact: true }).waitFor();
  await page.locator('summary').filter({ hasText: 'Candle values' }).click();
  await page.locator('tbody tr').first().getByText('0.000000020000', { exact: true }).waitFor();
  await page.setViewportSize({ width: 320, height: 900 });
  await page.evaluate(async () => {
    await (await import('/tests/fixtures/analysisHistoryBrowser.tsx')).theme('kairos-depth');
    const style = document.createElement('style');
    style.id = 'legacy-expanded-values-sizing';
    style.textContent = '.kairos-analysis-chart__data{min-width:auto!important}.kairos-analysis-chart__table-scroll{width:auto!important;min-width:auto!important;max-width:none!important}';
    document.head.append(style);
  });
  await page.waitForTimeout(120);
  const legacyExpanded = await page.evaluate(() => ({
    viewport: visualViewport?.width ?? document.documentElement.clientWidth,
    layoutViewport: innerWidth,
    pageWidth: document.documentElement.scrollWidth,
  }));
  assert(legacyExpanded.pageWidth > legacyExpanded.viewport + 1, JSON.stringify(legacyExpanded));
  await page.screenshot({ path: resolve(evidence, '320-legacy-expanded-values-overflow.png'), fullPage: true });
  await page.evaluate(() => document.getElementById('legacy-expanded-values-sizing')?.remove());
  for (const width of [320, 390]) {
    await page.setViewportSize({ width, height: 900 });
    for (const theme of ['kairos-depth', 'cosmic', 'ocean']) {
      await page.evaluate(async id => (await import('/tests/fixtures/analysisHistoryBrowser.tsx')).theme(id), theme);
      await page.waitForTimeout(120);
      const expanded = await page.evaluate(() => {
        const card = document.querySelector('.kairos-analysis-chart');
        const details = document.querySelector('.kairos-analysis-chart__data');
        const region = document.querySelector('.kairos-analysis-chart__table-scroll');
        return {
          viewport: visualViewport?.width ?? document.documentElement.clientWidth,
          layoutViewport: innerWidth,
          pageWidth: document.documentElement.scrollWidth,
          cardWidth: card.getBoundingClientRect().width,
          detailsWidth: details.getBoundingClientRect().width,
          regionWidth: region.getBoundingClientRect().width,
          regionScrollWidth: region.scrollWidth,
        };
      });
      assert(expanded.pageWidth <= expanded.viewport + 1, JSON.stringify(expanded));
      assert(expanded.detailsWidth <= expanded.cardWidth + 1, JSON.stringify(expanded));
      assert(expanded.regionWidth <= expanded.detailsWidth + 1, JSON.stringify(expanded));
      assert(expanded.regionScrollWidth > expanded.regionWidth, JSON.stringify(expanded));
      await page.screenshot({ path: resolve(evidence, `${width}-${theme}-expanded-values.png`), fullPage: true });
    }
  }
  await page.locator('summary').filter({ hasText: 'Candle values' }).click();
  await page.getByLabel('Chart symbol', { exact: true }).selectOption('ETHUSDT');
  await page.getByRole('group', { name: 'ETHUSDT 5m live candlestick chart', exact: true }).waitFor();
  const measurements = [];
  for (const width of [320, 390, 768, 1280]) {
    await page.setViewportSize({ width, height: 900 });
    for (const theme of ['kairos-depth', 'cosmic', 'ocean']) {
      await page.evaluate(async id => (await import('/tests/fixtures/analysisHistoryBrowser.tsx')).theme(id), theme);
      await page.waitForTimeout(120);
      const measured = await page.evaluate(() => ({ viewport: innerWidth, content: document.documentElement.scrollWidth, chart: document.querySelector('.kairos-analysis-chart__canvas').getBoundingClientRect().width, count: document.querySelectorAll('.kairos-analysis-chart__canvas .tv-lightweight-charts').length, background: getComputedStyle(document.querySelector('.kairos-analysis-chart__canvas')).backgroundColor }));
      assert(measured.content <= measured.viewport + 1, JSON.stringify(measured)); assert(measured.chart > 200); assert.equal(measured.count, 1);
      const pixels = await canvasPixels(); assert(pixels.up > 10 && pixels.down > 10);
      measurements.push({ width, theme, ...measured, pixels });
      await page.screenshot({ path: resolve(evidence, `${width}-${theme}.png`), fullPage: true });
    }
  }
  await page.getByLabel('Chart symbol', { exact: true }).selectOption('TINYUSDT');
  await page.getByRole('group', { name: 'TINYUSDT 5m live candlestick chart', exact: true }).waitFor();
  await page.locator('summary').filter({ hasText: 'Candle values' }).click();
  await page.locator('tbody tr').first().getByText('0.000000020000', { exact: true }).waitFor();
  await page.locator('summary').filter({ hasText: 'Candle values' }).click();
  mode = 'limited'; await page.getByRole('button', { name: 'Refresh candles' }).click();
  await page.getByText('The market-data service is limiting requests. Try again later.').waitFor();
  assert.equal(await page.locator('.kairos-analysis-chart__canvas canvas').count(), 0);
  mode = 'empty'; await page.getByRole('button', { name: 'Refresh candles' }).click(); await page.getByText('No authoritative candles are available for this selection.').waitFor();
  mode = 'offline'; await page.getByRole('button', { name: 'Refresh candles' }).click(); await page.getByText('Authoritative candle history could not be loaded.').waitFor();
  mode = 'ready'; await page.getByLabel('Timeframe', { exact: true }).selectOption('15m'); await page.getByRole('button', { name: 'Fit candles' }).waitFor();
  assert.deepEqual(await page.evaluate(async () => (await import('/tests/fixtures/analysisHistoryBrowser.tsx')).readSavedFacts()), original);
  await page.getByRole('link', { name: 'Back to Journal', exact: true }).click(); await page.locator('.kairos-analysis-chart__canvas').waitFor({ state: 'detached' });
  assert.deepEqual(errors, []);
  // Separate, unmocked browser request. Availability is evidence, not a fake-data pass.
  const nativePage = await context.newPage();
  await nativePage.route('http://127.0.0.1:4182/**', route => route.fulfill({ contentType: 'text/html', body: '<!doctype html><title>Native provider probe</title>' }));
  await nativePage.goto('http://127.0.0.1:4182/');
  const nativeProvider = await nativePage.evaluate(async () => {
    const url = 'https://data-api.binance.vision/api/v3/klines?symbol=ETHUSDT&interval=5m&limit=2&timeZone=0';
    try { const response = await fetch(url, { signal: AbortSignal.timeout(7000), credentials: 'omit', redirect: 'error', cache: 'no-store' }); const body = await response.text(); return { url, mocked: false, status: response.status, body: body.slice(0, 2000) }; }
    catch (error) { return { url, mocked: false, available: false, error: String(error) }; }
  });
  await nativePage.close();
  writeFileSync(resolve(evidence, 'result.json'), JSON.stringify({ passed: true, fixtureRegression: true, realRenderer: true, liveWorkspaceMounted: true, exactProviderConnectedStatus: true, oneHistoryOwner: true, touchPan: true, pinchZoom: true, keyboard: true, exactDecimals: true, expandedMobileTable: true, legacyExpandedOverflowReproduced: true, noJournalMutation: true, requests, liveSockets, measurements, errors, nativeProvider }, null, 2));
  console.log('PASS: live Analysis workspace, exact selection/history ownership, provider-connected status, renderer pixels, touch pan/pinch, keyboard, expanded mobile table containment, resize/themes and unchanged journal. Native availability recorded separately.');
} catch (error) {
  console.error(error);
  if (page && !page.isClosed()) { writeFileSync(resolve(evidence, 'failure.html'), await page.content()); await page.screenshot({ path: resolve(evidence, 'failure.png'), fullPage: true }); }
  throw error;
} finally { await browser?.close(); server.kill('SIGTERM'); }
