import { readFileSync } from 'node:fs';

const read = path => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const route = read('src/app/AnalysisRoute.tsx');
const workspace = read('src/app/AnalysisHistoryWorkspace.tsx');
const tests = read('tests/analysis-history-workspace.test.tsx');
const report = read('docs/KAIROS_ANALYSIS_SAVED_TRADE_WORKSPACE_MOUNT.md');

for (const expected of [
  "const selectedEntry = result?.kind === 'trade' ? result.entry : null",
  'const savedTradePending = selectedId !== null && loading',
  '<AnalysisHistoryWorkspace entry={selectedEntry} savedTradePending={savedTradePending} />',
]) if (!route.includes(expected)) throw new Error(`saved-trade route mount drift:${expected}`);

if (!(route.indexOf('<AnalysisHistoryWorkspace') < route.indexOf('<TradeReviewDetails entry='))) {
  throw new Error('saved-trade chart must retain chart-first route ordering');
}

for (const expected of [
  "import type { JournalHistoryEntry } from '../application/journal'",
  'AnalysisSavedTradeLiveCandleCanvas',
  'SavedTradeLiveCanvas = AnalysisSavedTradeLiveCandleCanvas',
  'readonly entry?: JournalHistoryEntry | null',
  'readonly savedTradePending?: boolean',
  'fact && savedTradePending',
  'fact && !savedTradePending && entry',
  '<SavedTradeLiveCanvas entry={entry} instrument={fact.instrument} interval={interval} quoteAsset={fact.quoteAsset} revision={revision} />',
  'fact && !savedTradePending && !entry',
  '<LiveCanvas instrument={fact.instrument} interval={interval} quoteAsset={fact.quoteAsset} revision={revision} />',
]) if (!workspace.includes(expected)) throw new Error(`saved-trade workspace mount drift:${expected}`);

for (const forbidden of [
  'loadTradeReview', 'acquireHistory(', 'MarketCandleHistoryPort', 'WebSocket',
  'indexedDB', 'localStorage', 'createKairosRepositories', 'saveManualTrade',
  'calculateTradeMetrics', 'grossPnl', 'netPnl',
]) if (workspace.includes(forbidden)) throw new Error(`saved-trade workspace owner violation:${forbidden}`);

for (const expected of [
  'mounts the released saved-trade composition only for the exact P12 entry',
  'waits for a pending saved-trade read instead of starting a replaceable base session',
  'expect(LiveCanvas).not.toHaveBeenCalled()',
  'expect(p.history.acquireHistory).not.toHaveBeenCalled()',
]) if (!tests.includes(expected)) throw new Error(`missing saved-trade workspace regression:${expected}`);

for (const expected of [
  'UI visible: yes', 'Gate445 R1', 'P12-hydrated', 'exact symbol and quote-asset',
  'remains usable without a selected saved trade', 'no additional history request',
  'no execution, venue, FX or P&L inference',
]) if (!report.includes(expected)) throw new Error(`saved-trade workspace report drift:${expected}`);

console.log('Analysis saved-trade live-candle workspace mount verifier PASS');
