import { readFileSync } from 'node:fs';

const read = path => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const source = read('src/app/analysisSavedTradeMarkerPresentationSession.ts');
const tests = read('tests/analysis-saved-trade-marker-presentation-session.test.ts');
const report = read('docs/KAIROS_ANALYSIS_SAVED_TRADE_MARKER_PRESENTATION_SESSION.md');

for (const expected of [
  'projectAnalysisSavedTradeChartReference',
  'projectAnalysisSavedTradeCandleWindow',
  'projectAnalysisSavedTradeExecutionMarkers',
  'createAnalysisSavedTradeRendererMarkerSession',
  'rendererFactory: rendererMarkerSession.rendererFactory',
  'projectReference(input.entry, input.scope)',
  'projectWindow(reference, input.snapshot)',
  'projectMarkers(window)',
  'rendererMarkerSession.present(markers, input.theme)',
  "throw new Error('analysis-saved-trade-marker-presentation-session-closed')",
  'rendererMarkerSession.close()',
]) if (!source.includes(expected)) throw new Error(`missing saved-trade marker presentation composition: ${expected}`);

for (const forbidden of [
  'AnalysisRoute', 'AnalysisHistoryWorkspace', 'AnalysisLiveCandleCanvas',
  'indexedDB', 'localStorage', 'WebSocket', 'fetch(', 'calculateTradeMetrics',
  'decimalAdd', 'decimalSubtract', 'executionVenue:', 'grossPnl', 'netPnl',
]) if (source.includes(forbidden)) throw new Error(`forbidden saved-trade marker presentation owner: ${forbidden}`);

for (const expected of [
  'delegates exact caller and authoritative snapshot evidence through the released projection chain',
  'preserves unavailable and unplaced evidence instead of manufacturing a marker',
  'does not replace the current successful result when a lower owner fails closed',
  'closes the renderer-marker owner once',
]) if (!tests.includes(expected)) throw new Error(`missing saved-trade marker presentation regression: ${expected}`);

for (const expected of [
  'P14 remains the sole saved execution-fact owner',
  'Gate438 remains the exact chart-reference eligibility owner',
  'Gate439 remains the authoritative candle-window placement owner',
  'Gate440 remains the provider-neutral marker-fact owner',
  'Gate442 remains the renderer-marker lifecycle owner',
  'no visible UI change', 'no journal mutation',
  'no execution, venue, FX or P&L inference',
]) if (!report.includes(expected)) throw new Error(`missing saved-trade marker presentation scope boundary: ${expected}`);

console.log('PASS: exact saved-trade and authoritative history evidence composes through released marker owners without widening financial or provider ownership.');
