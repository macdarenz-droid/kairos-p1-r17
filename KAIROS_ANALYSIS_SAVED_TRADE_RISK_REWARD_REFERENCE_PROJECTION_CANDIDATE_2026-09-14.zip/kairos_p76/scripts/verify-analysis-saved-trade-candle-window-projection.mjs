import { readFileSync } from 'node:fs';

const read = path => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const source = read('src/app/analysisSavedTradeCandleWindowProjection.ts');
const tests = read('tests/analysis-saved-trade-candle-window-projection.test.ts');
const report = read('docs/KAIROS_ANALYSIS_SAVED_TRADE_CANDLE_WINDOW_PROJECTION.md');

for (const expected of [
  "reference.kind !== 'reference-ready'",
  "reason: 'history-scope-mismatch'",
  "reason: 'history-empty'",
  "reason: 'history-window-invalid'",
  "reason: 'execution-time-invalid'",
  "reason: 'before-history'",
  "reason: 'after-history'",
  "reason: 'not-covered'",
  'executionMs >= window.openMs && executionMs <= window.closeMs',
  'price: execution.price',
  'quantity: execution.quantity',
  'executedAt: execution.executedAt',
]) if (!source.includes(expected)) throw new Error(`missing exact candle-window boundary: ${expected}`);

for (const forbidden of [
  'parseFloat(', 'calculateTradeMetrics', 'decimalAdd', 'decimalSubtract', 'indexedDB',
  'localStorage', 'WebSocket', 'fetch(', 'acquireHistory(', 'createChart(', 'createSeriesMarkers',
]) if (source.includes(forbidden)) throw new Error(`forbidden candle-window owner: ${forbidden}`);

for (const expected of [
  'inclusive authoritative candle bounds',
  'not-covered', 'before-history', 'after-history',
  'history-scope-mismatch', 'history-empty', 'history-window-invalid', 'execution-time-invalid',
  "price: decimal('101.25')", "executedAt: 'invalid'",
]) if (!tests.includes(expected)) throw new Error(`missing candle-window regression: ${expected}`);

for (const expected of [
  'P14 remains the sole saved execution-fact owner',
  'no candle OHLC value becomes an execution price',
  'no visible UI change',
  'no journal mutation',
  'no execution, venue, FX or P&L inference',
]) if (!report.includes(expected)) throw new Error(`missing scope boundary: ${expected}`);

console.log('PASS: exact saved execution instants are placed only inside authoritative candle windows, with gaps and unavailable bounds explicit and no financial inference.');
