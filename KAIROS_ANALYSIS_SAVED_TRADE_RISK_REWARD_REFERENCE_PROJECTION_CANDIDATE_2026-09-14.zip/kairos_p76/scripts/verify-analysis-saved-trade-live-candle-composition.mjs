import { existsSync, readFileSync } from 'node:fs';

const compositionPath = 'src/app/AnalysisSavedTradeLiveCandleCanvas.tsx';
const canvasPath = 'src/app/AnalysisLiveCandleCanvas.tsx';
const testPath = 'tests/analysis-saved-trade-live-candle-composition.test.tsx';
const canvasTestPath = 'tests/analysis-live-candle-canvas-presentation.test.tsx';
const docPath = 'docs/KAIROS_ANALYSIS_SAVED_TRADE_LIVE_CANDLE_COMPOSITION.md';
for (const file of [compositionPath, canvasPath, testPath, canvasTestPath, docPath]) {
  if (!existsSync(file)) throw new Error(`missing-analysis-saved-trade-live-candle-composition:${file}`);
}

const composition = readFileSync(compositionPath, 'utf8');
const canvas = readFileSync(canvasPath, 'utf8');
const tests = readFileSync(testPath, 'utf8');
const canvasTests = readFileSync(canvasTestPath, 'utf8');
const report = readFileSync(docPath, 'utf8');

for (const expected of [
  "from './useAnalysisSavedTradeMarkerPresentationSession'",
  "from './AnalysisLiveCandleCanvas'",
  "from './analysisLiveCandleRouteSession'",
  "from './analysisCandleRendererSession'",
  'const snapshot = scopedSnapshot.key === key ? scopedSnapshot.snapshot : null',
  'const marker = useMarkerBinding({ entry, scope, snapshot, theme, revision })',
  'if (rendererFactory === null) return null',
  'createLiveSession({',
  'createRendererSession({ ...input, factory: rendererFactory })',
  'onAuthoritativeSnapshot={publishSnapshot}',
]) if (!composition.includes(expected)) throw new Error(`analysis-saved-trade-live-candle-composition-drift:${expected}`);

for (const forbidden of [
  'AnalysisRoute', 'AnalysisHistoryWorkspace', 'loadTradeReview', 'acquireHistory',
  'fetch(', 'WebSocket', 'setTimeout(', 'setInterval(', 'Date.now(', 'Math.random(',
  'indexedDB', 'localStorage', 'Dexie', 'createTrade', 'updateTrade', 'calculateTrade',
  'grossPnl', 'netPnl', 'executionVenue:',
]) if (composition.includes(forbidden)) throw new Error(`analysis-saved-trade-live-candle-composition-owner-violation:${forbidden}`);

for (const expected of [
  'readonly createSession?: typeof createAnalysisLiveCandleRouteSession',
  'readonly onAuthoritativeSnapshot?: (snapshot: MarketCandleHistorySnapshot | null) => void',
  'onAuthoritativeSnapshot?.(snapshot)',
  'onAuthoritativeSnapshot?.(null)',
  'activationSnapshot.request.instrument.venue === instrument.venue',
  'activationSnapshot.request.instrument.symbol === instrument.symbol',
  'activationSnapshot.request.interval === interval',
]) if (!canvas.includes(expected)) throw new Error(`analysis-live-candle-composition-seam-drift:${expected}`);

for (const expected of [
  'composes Gate444 with the released live canvas only after its exact renderer factory exists',
  'injects only Gate444 renderer ownership into the released route session',
  'returns the exact authoritative live history page to the same marker owner',
  'fails closed across scope changes instead of projecting a stale snapshot',
  'does not start the live owner when Gate444 has no renderer factory',
]) if (!tests.includes(expected)) throw new Error(`missing-analysis-saved-trade-live-candle-composition-regression:${expected}`);

if (!canvasTests.includes('forwards a higher composition session factory and reports only the authoritative activation snapshot')) {
  throw new Error('missing-analysis-live-candle-composition-seam-regression');
}
if (!canvasTests.includes('rejects a stale activation snapshot before reporting it to a higher composition owner')) {
  throw new Error('missing-analysis-live-candle-composition-stale-snapshot-regression');
}

for (const expected of [
  'UI visible: no', 'Gate444', 'exact successful activation snapshot',
  'keyed by exact venue, symbol, interval and caller revision',
  '`AnalysisRoute`, `AnalysisHistoryWorkspace`',
  'no execution, venue, FX or P&L inference',
]) if (!report.includes(expected)) throw new Error(`analysis-saved-trade-live-candle-composition-doc-drift:${expected}`);

console.log('Analysis saved-trade live-candle composition verifier PASS');
