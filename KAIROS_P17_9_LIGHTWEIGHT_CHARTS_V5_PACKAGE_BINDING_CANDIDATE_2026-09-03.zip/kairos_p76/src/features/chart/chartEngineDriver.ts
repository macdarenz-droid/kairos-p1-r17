import type {
  RendererCandle,
  RendererPricePoint,
  RendererSeriesProjection,
} from './chartSeriesProjection';
import type {
  ChartEnginePort,
  ChartEngineSession,
} from './chartEnginePort';

export interface ChartEngineSeriesHandle {
  setPriceLineData(data: readonly RendererPricePoint[]): void;
  setCandleData(data: readonly RendererCandle[]): void;
}

export interface ChartEngineDriver {
  createChart(container: HTMLElement): {
    addPriceLineSeries(): ChartEngineSeriesHandle;
    addCandlestickSeries(): ChartEngineSeriesHandle;
    removeSeries(series: ChartEngineSeriesHandle): void;
    remove(): void;
  };
}

/**
 * Adapts a concrete chart-library-shaped driver to the narrow Kairos P17 engine port.
 * The injected driver owns only presentation resources.
 */
export function createChartEnginePortFromDriver(
  driver: ChartEngineDriver,
): ChartEnginePort {
  return {
    create(container: HTMLElement): ChartEngineSession {
      const chart = driver.createChart(container);
      let activeSeries: ChartEngineSeriesHandle | null = null;
      let destroyed = false;

      const clearActiveSeries = (): void => {
        if (activeSeries === null) return;
        chart.removeSeries(activeSeries);
        activeSeries = null;
      };

      return {
        replaceSeries(series: RendererSeriesProjection): void {
          if (destroyed) {
            throw new Error('chart-engine-session-destroyed');
          }

          clearActiveSeries();

          if (series.kind === 'price-line') {
            const next = chart.addPriceLineSeries();
            next.setPriceLineData(series.data);
            activeSeries = next;
            return;
          }

          const next = chart.addCandlestickSeries();
          next.setCandleData(series.data);
          activeSeries = next;
        },

        destroy(): void {
          if (destroyed) return;
          destroyed = true;
          activeSeries = null;
          chart.remove();
        },
      };
    },
  };
}
