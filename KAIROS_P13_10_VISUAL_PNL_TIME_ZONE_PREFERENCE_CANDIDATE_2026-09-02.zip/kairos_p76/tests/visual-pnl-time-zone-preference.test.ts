import { beforeEach, describe, expect, it } from 'vitest';
import {
  clearVisualPnlTimeZonePreference,
  readVisualPnlTimeZonePreference,
  visualPnlTimeZonePreferenceStorageKey,
  writeVisualPnlTimeZonePreference,
} from '../src/application/visual-pnl';

describe('P13.10 explicit Visual P&L timezone preference', () => {
  beforeEach(() => {
    window.localStorage.clear();
  });

  it('defaults to explicitly unconfigured instead of inferring the device timezone', () => {
    expect(readVisualPnlTimeZonePreference()).toBeNull();
  });

  it('persists and reads an explicitly selected valid IANA timezone', () => {
    expect(writeVisualPnlTimeZonePreference('Australia/Sydney')).toEqual({
      ok: true,
      timeZone: 'Australia/Sydney',
    });
    expect(window.localStorage.getItem(visualPnlTimeZonePreferenceStorageKey)).toBe('Australia/Sydney');
    expect(readVisualPnlTimeZonePreference()).toBe('Australia/Sydney');
  });

  it('rejects invalid timezone evidence without modifying an existing valid preference', () => {
    expect(writeVisualPnlTimeZonePreference('UTC').ok).toBe(true);
    expect(writeVisualPnlTimeZonePreference('Mars/Olympus_Mons')).toEqual({
      ok: false,
      reason: 'invalid-time-zone',
    });
    expect(readVisualPnlTimeZonePreference()).toBe('UTC');
  });

  it('treats invalid persisted values as unconfigured rather than falling back silently', () => {
    window.localStorage.setItem(visualPnlTimeZonePreferenceStorageKey, 'Not/A_TimeZone');
    expect(readVisualPnlTimeZonePreference()).toBeNull();
  });

  it('does not normalize or trim user-supplied timezone evidence invisibly', () => {
    expect(writeVisualPnlTimeZonePreference(' Australia/Sydney ')).toEqual({
      ok: false,
      reason: 'invalid-time-zone',
    });
    expect(readVisualPnlTimeZonePreference()).toBeNull();
  });

  it('fails safely when persistence is unavailable', () => {
    const blockedStorage = {
      getItem() { throw new DOMException('blocked'); },
      setItem() { throw new DOMException('blocked'); },
      removeItem() { throw new DOMException('blocked'); },
    } as unknown as Storage;

    expect(readVisualPnlTimeZonePreference(blockedStorage)).toBeNull();
    expect(writeVisualPnlTimeZonePreference('UTC', blockedStorage)).toEqual({
      ok: false,
      reason: 'storage-unavailable',
    });
    expect(clearVisualPnlTimeZonePreference(blockedStorage)).toBe(false);
  });

  it('can explicitly clear the configured timezone', () => {
    expect(writeVisualPnlTimeZonePreference('America/New_York').ok).toBe(true);
    expect(clearVisualPnlTimeZonePreference()).toBe(true);
    expect(readVisualPnlTimeZonePreference()).toBeNull();
  });
});
