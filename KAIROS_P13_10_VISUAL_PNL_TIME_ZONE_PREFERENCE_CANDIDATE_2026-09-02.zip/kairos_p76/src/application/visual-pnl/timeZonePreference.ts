import { projectVisualPnlDayKey } from './dayBucket';

export const visualPnlTimeZonePreferenceStorageKey = 'kairos.visual-pnl.time-zone.v1';

export type VisualPnlTimeZonePreference = string | null;

export type VisualPnlTimeZonePreferenceWriteResult =
  | Readonly<{ ok: true; timeZone: string }>
  | Readonly<{
      ok: false;
      reason: 'invalid-time-zone' | 'storage-unavailable';
    }>;

const VALIDATION_INSTANT = '2000-01-01T00:00:00.000Z';

function getBrowserStorage(): Storage | null {
  if (typeof window === 'undefined') return null;
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

function isValidTimeZone(timeZone: string): boolean {
  if (timeZone.trim() !== timeZone || timeZone.length === 0) return false;
  return projectVisualPnlDayKey(VALIDATION_INSTANT, timeZone).available;
}

/**
 * Reads the explicit Visual P&L calendar timezone preference.
 *
 * No browser/device timezone is inferred. Missing, inaccessible, or invalid
 * persisted evidence returns null so the UI can remain explicitly unconfigured.
 */
export function readVisualPnlTimeZonePreference(
  storage: Storage | null = getBrowserStorage(),
): VisualPnlTimeZonePreference {
  if (!storage) return null;
  try {
    const stored = storage.getItem(visualPnlTimeZonePreferenceStorageKey);
    return stored !== null && isValidTimeZone(stored) ? stored : null;
  } catch {
    return null;
  }
}

/**
 * Persists only an explicitly supplied valid timezone.
 *
 * Validation delegates to the existing P13.6 day-bucket timezone contract.
 * The function never substitutes the runtime/device timezone.
 */
export function writeVisualPnlTimeZonePreference(
  timeZone: string,
  storage: Storage | null = getBrowserStorage(),
): VisualPnlTimeZonePreferenceWriteResult {
  if (!isValidTimeZone(timeZone)) {
    return Object.freeze({ ok: false, reason: 'invalid-time-zone' as const });
  }
  if (!storage) {
    return Object.freeze({ ok: false, reason: 'storage-unavailable' as const });
  }
  try {
    storage.setItem(visualPnlTimeZonePreferenceStorageKey, timeZone);
    return Object.freeze({ ok: true, timeZone });
  } catch {
    return Object.freeze({ ok: false, reason: 'storage-unavailable' as const });
  }
}

export function clearVisualPnlTimeZonePreference(
  storage: Storage | null = getBrowserStorage(),
): boolean {
  if (!storage) return false;
  try {
    storage.removeItem(visualPnlTimeZonePreferenceStorageKey);
    return true;
  } catch {
    return false;
  }
}
