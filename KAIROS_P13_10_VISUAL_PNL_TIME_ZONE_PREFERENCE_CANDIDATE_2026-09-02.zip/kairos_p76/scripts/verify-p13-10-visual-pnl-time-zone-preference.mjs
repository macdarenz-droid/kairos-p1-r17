import { readFileSync } from 'node:fs';

const source = readFileSync('src/application/visual-pnl/timeZonePreference.ts', 'utf8');
const index = readFileSync('src/application/visual-pnl/index.ts', 'utf8');
const tests = readFileSync('tests/visual-pnl-time-zone-preference.test.ts', 'utf8');

const need = (text, value, label) => {
  if (!text.includes(value)) throw new Error(`P13.10 missing ${label}: ${value}`);
};

need(source, "kairos.visual-pnl.time-zone.v1", 'versioned preference key');
need(source, 'return null;', 'explicit unconfigured fallback');
need(source, 'projectVisualPnlDayKey(VALIDATION_INSTANT, timeZone).available', 'P13.6 timezone validation owner reuse');
need(source, "reason: 'invalid-time-zone'", 'invalid timezone evidence');
need(source, "reason: 'storage-unavailable'", 'persistence failure evidence');
need(source, 'storage.removeItem', 'explicit clear path');
need(index, "export * from './timeZonePreference';", 'public export');
need(tests, 'defaults to explicitly unconfigured', 'no device inference regression');
need(tests, "' Australia/Sydney '", 'no hidden normalization regression');

for (const forbidden of [
  'resolvedOptions().timeZone',
  'Date().getTimezoneOffset',
  'new Date().getTimezoneOffset',
  'navigator.language',
  'Australia/Sydney\' as const',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P13.10 rejected hidden timezone fallback/default: ${forbidden}`);
  }
}

console.log('PASS P13.10 explicit Visual P&L timezone preference verifier');
