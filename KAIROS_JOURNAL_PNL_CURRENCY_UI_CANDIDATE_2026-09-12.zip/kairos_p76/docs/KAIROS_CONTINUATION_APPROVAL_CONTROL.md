# Kairos continuation and approval control — 12 September 2026

## Current user instruction

Continue the best dependency-safe work under the roadmap, consider UI quality and seek the user's approval before proceeding to the next slice. Turn the existing autonomous worker on after the manual job is done. This supersedes previous unconditional next-slice continuation, the completed Binance482-symbol repair pointer and the former paused control state once manual publication finishes. It does not authorize replacement workers or faster-than-supported scheduling.

## Scope approved now

Journal actual execution-entry integration from verified Gate396: expose existing entry/exit/quantity/time/fee save capability, retain plan/execution separation, delegate existing calculation and history results, compact theme-owned form presentation, and verify the real Journal-to-Your-Trades flow. Routine repairs within this scope are authorized. Live Bubble design is user-approved and remains the visual baseline.

## Approval boundary for every subsequent slice

1. Resolve the exact active canonical chain first. Monitor a running gate; repair a failure from the latest FULL canonical GOLDEN plus the approved intended delta. Gate-only defects receive gate-only fixes. Never weaken verification or create competing candidates.
2. Verify every canonical stage and both exact-run artifacts before GOLDEN. Reconcile source-owned capability with the promised user workflow; phase closure is not proof that a complete screen exists.
3. Before implementing a new slice, prepare one concrete, reviewable proposal: roadmap owner, missing user capability, exact proposed behavior/UI, dependencies, preserved data boundaries, limits, and validation plan. Include a UI preview when visual design requires a choice. Read-only investigation and review-only design preparation are allowed; approval cannot be inferred from broad roadmap intent, worker enablement, time elapsed or silence.
4. Ask the user to approve that exact proposal. Record approval identity/scope in continuity. Until explicit approval exists, do not implement/publish that new feature candidate, change metric/product meaning, start a new phase, or declare system closure. Do not repeatedly send the same approval request; remain in awaiting-approval monitoring mode.
5. Once explicitly approved, complete that slice and its evidence-based repairs autonomously, then repeat the approval boundary for the next slice.

## Worker and supervisor

Use existing V16 worker6a9d8b63fbf081918a26452faf51e747 and supervisor6a9a872c15d08191ac18ed249add1448. Scheduler-owned HOURLY recurrence; no sub-hour self-rearming, successors, duplicate tasks or artificial keepalive. User pause/stop always wins. Supervisor is GitHub/project read-only and must enforce the same approval boundary. Waiting for approval is healthy; the supervisor must not treat it as a failure requiring implementation.

Both use fresh GitHub plus the master worker rules and direct-publication instructions. Use the shared lease6a9c887ae4e881919758b86977bbc2eb before mutations, immediately verify ownership, refresh main/Actions before later writes and release after meaningful continuity. Resume automations only after the manual candidate's publication/checkpoint; never compete with a held manual lease. Preserve other automations unchanged.

## Roadmap position

P21 remains open. P10 execution capture is a supporting integration amendment. Fee/result currency evidence and the P14/P17/P19 logged-trade candle/risk-box UI are known separate gaps, requiring source inspection and a scoped proposal rather than automatic implementation. P22 Goals & Discipline follows P21 only after an explicitly approved and canonically verified closure. P40 remains release hardening, not a reason to omit required functional UI until the end.


## Current manual continuation — after Gate397 review

User message: “Okay continue nxt slice”, following the Gate397 progress report and explanation that opening/closing times are saved manually. This current explicit instruction authorizes one next contained roadmap slice selected from source: existing Open manual trades can receive additional actual entries/exits/fees and be explicitly marked Closed, keeping their identity, original facts and plan. The action was explained in live commentary before implementation. This is not an automation/timed-order or candle-chart request. See KAIROS_OPEN_TRADE_UPDATE_AMENDMENT.md for exact scope and evidence.

Gate397 is now the verified FULL canonical GOLDEN, all stages and both exact-run artifacts passed. Complete and verify the open-trade update candidate, including mobile UI evidence, then present it for review. Do not start a subsequent slice until the user approves continuation after that review. The standing review boundary remains; this recorded current instruction supersedes the older Gate397-only scope above for this one manual continuation. Worker enablement alone authorizes no further slices.


## Current explicit continuation after Gate398 — 12 September 2026

User message: “Continue nxt slice, just let me know if the update involved ui visible changes so i can have a look”. This is fresh explicit authorization to complete ONE next contained slice, superseding the prior awaiting-Gate398-review pointer for that one continuation. Source inspection selected explicit P&L currency capture: new manual trades can record their price/result currency, and Open manual trades can add a missing currency once. Existing P11 fee compatibility and P12 results are reused. The UI path and scope were explained in live commentary before implementation. No FX/inference, recorded-currency replacement, Closed-trade retrofit, candle integration, Live Bubble change or phase closure.

Gate398 is the freshly verified FULL GOLDEN (all27steps and both exact-run artifacts, exact ZIP bytes). Complete/test/publish this currency candidate and its same-scope repairs. This update IS VISIBLE: Journal optional P&L currency; Open trade -> Update trade; currency-labelled net results. Give the user review/build instructions after canonical validation. Await fresh explicit continuation before another slice. See KAIROS_JOURNAL_PNL_CURRENCY_AMENDMENT.md. Preserve existing hourly workers and shared lease; no competing work or sub-hour schedules.
