# Analysis saved-trade marker presentation session

## Scope

This item-5 slice composes the already-released saved-trade marker owners into one application boundary. The caller supplies one P12-hydrated `JournalHistoryEntry`, exact selected chart instrument and quote asset, one caller-authoritative candle-history snapshot, and the current chart theme. The session delegates those inputs unchanged through Gate438 chart-reference eligibility, Gate439 candle-window placement, Gate440 immutable execution-marker projection, and Gate442 renderer-marker presentation.

The result retains every intermediate released projection together with the final Gate442 presentation evidence. Unavailable chart eligibility, mismatched/invalid history, execution instants outside covered candle windows, and unplaced executions therefore remain explicit. No execution is snapped to a neighbouring candle, no OHLC value becomes an execution price, and missing facts never become zero. If a released lower owner rejects ambiguous evidence, the last successful result remains authoritative rather than being replaced by a partial projection.

The session exposes Gate442's exact renderer factory so a later bounded route composition can supply it to the existing live-candle renderer owner. It does not create a chart, request history, start a stream or timer, or import the Analysis route, workspace, or live-canvas presentation. Closing is idempotent, clears retained evidence, closes Gate442 once, and rejects later presentation.

P14 remains the sole saved execution-fact owner. Gate438 remains the exact chart-reference eligibility owner. Gate439 remains the authoritative candle-window placement owner. Gate440 remains the provider-neutral marker-fact owner. Gate442 remains the renderer-marker lifecycle owner. P17 keeps renderer and provider-series ownership; P18 drawing tools and P19 Risk/Reward meaning are unchanged.

This candidate makes no visible UI change, adds no provider or transport, performs no persistence and no journal mutation, and introduces no arithmetic. It makes no execution, venue, FX or P&L inference. Route/live-canvas integration, accessible visible saved-trade status, P19 Risk/Reward, P18 drawing interactions and P20 save/load remain later bounded slices.

## Verification

- dedicated static ownership and forbidden-dependency verifier;
- focused Gate438–Gate442 and new composition regressions;
- TypeScript and production build;
- fresh-extract install, dedicated/focused/typecheck/build and exact root/path-safety/integrity checks;
- canonical Node 22.16.0, npm 10.9.2 and Lightweight Charts 5.2.1 gate, browser evidence, full regression, historical closures and exact-run artifacts.
