# Analysis saved-trade marker React binding

UI visible: no.

This item-5 slice binds the released Gate443 saved-trade marker presentation session to React lifetime without mounting it. The hook creates one session per mounted hook, exposes that session's exact renderer factory for a later live-canvas composition, waits for the caller-authoritative history snapshot, and delegates the exact hydrated saved trade, selected instrument/quote scope, snapshot and theme unchanged.

Trade, chart scope, theme and caller revision changes reuse the same released session. A missing snapshot starts no projection. A complete Gate443 result replaces prior evidence atomically; if a released lower owner rejects ambiguous evidence, the hook reports that error while retaining the last complete result. Unmount closes only the hook's own session once.

Gate443 remains the reference/window/marker/presentation composition owner. P14 remains the saved execution-fact owner, P17 remains renderer/provider-series owner, P18 remains generic drawing owner, and P19 remains Risk/Reward meaning owner. The hook does not import or mount the Analysis route, workspace or live canvas; visible/accessibility presentation and route integration remain later.

The binding starts no history request, stream, timer or provider work. It adds no persistence or journal mutation, performs no arithmetic, and makes no execution, venue, FX or P&L inference. Missing facts never become zero.

Verification includes a dedicated ownership verifier, React lifecycle regressions, released Gate438–Gate443 focused regressions, TypeScript, production build, fresh-extract integrity checks, and the complete canonical gate with exact Node 22.16.0, npm 10.9.2 and Lightweight Charts 5.2.1.
