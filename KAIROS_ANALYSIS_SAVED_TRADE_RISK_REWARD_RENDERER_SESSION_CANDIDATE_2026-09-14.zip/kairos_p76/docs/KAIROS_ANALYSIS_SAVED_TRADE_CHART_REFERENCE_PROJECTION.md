# Analysis saved-trade chart reference projection

## Scope

This is the smallest dependency-safe item-5 prerequisite after the FULL Gate437 R1 workspace mount. `analysisSavedTradeChartReferenceProjection.ts` determines whether one already-hydrated saved trade can be presented against one caller-selected Binance Spot reference chart without changing either source of truth.

The projection succeeds only when the saved trade is explicitly crypto, its symbol exactly equals the selected metadata instrument symbol, and its recorded price currency exactly equals the caller-authoritative quote asset. It then delegates to P14's released `projectTradeVisualizerFacts` owner and preserves exact planned entry/stop/target plus execution IDs, prices, quantities and UTC instants. Missing executions remain empty. Missing or mismatched evidence returns a specific unavailable reason.

## Truth boundary

P14 remains the sole saved plan/execution projection owner. The selected chart contributes only its exact market-reference venue, symbol and quote asset. Because `TradeRecord` contains no execution-venue fact, execution venue remains not recorded even when the reference projection is ready. Readiness means same-symbol/same-quote chart reference, not proof that Binance was the execution venue or price source.

The module performs no decimal conversion, arithmetic, time bucketing, candle-range decision, marker geometry, renderer mutation, history acquisition or transport work. It makes no journal mutation, no execution, FX or P&L inference, and no persistence/schema/backup change. P17 retains chart rendering, P18 drawing machinery, P19 risk/reward semantics and P20 Saved Analysis persistence.

## Verification

The dedicated verifier and focused tests prove exact P14 fact preservation, immutable result snapshots, explicit null execution-venue evidence, case-sensitive scope matching and fail-closed market-type/symbol/currency outcomes. TypeScript, production build, current/historical gates and both exact-run artifacts remain mandatory.

There is no visible UI change. Marker placement, candle-window eligibility, unavailable copy, route composition, P18/P19/P20 integration and rendered browser interactions remain separate bounded slices.
