# Kairos Analysis Live Candle Product Policy

Date: 13 September 2026  
Roadmap owner: item 4 live candle continuity (P15/P16 + P17)  
UI visible: no

## Responsibility

This bounded item-4 amendment establishes the two route-owned product values needed before the released Gate423 lifecycle can be mounted: the existing authoritative page limit remains exactly 500 candles, and reconnect uses four P15-governed attempts starting at 1 second and capped at 8 seconds. The historical workspace now imports the shared limit instead of repeating the literal, so the existing snapshot and future live bootstrap cannot drift.

P15 remains authoritative for validation, attempt decisions, exponential delay and full jitter. Gate423 remains the lifecycle composition owner. The future React route owner must supply this policy and limit explicitly when it selects an exact Binance Spot instrument and interval.

## Exclusions

No history request, stream, socket, timer, route mount, visible status, renderer, provider implementation, persistence, IndexedDB access, journal mutation, calculation, execution inference, FX, drawing, marker or Live Bubble behavior is introduced. The historical Analysis UI remains visually and behaviorally unchanged. UI VISIBLE:NO. P21 remains active.

## Evidence

- The dedicated verifier proves exact shared-limit use and rejects transport, timer, route, storage, journal and calculation ownership.
- Focused tests prove the immutable values and delegate all reconnect decisions through released P15.
- Existing Analysis workspace tests continue to prove exact 500-candle request and response-scope validation.
- The inherited Analysis history verifier now proves the shared constant's exact value and both request/response call sites instead of requiring the superseded inline literal.
- TypeScript, production build, full regressions, browser evidence, historical closures and exact candidate/artifact verification remain mandatory.
