# Analysis saved-trade Risk/Reward coordinate projection

## Scope

This is the smallest dependency-safe item-5 prerequisite after the FULL Gate449 Risk/Reward renderer projection. `analysisSavedTradeRiskRewardCoordinateProjection.ts` accepts only Gate449's exact renderer-safe result and delegates its already-converted timestamps and prices through caller-owned Lightweight Charts v5 time and price scales.

The result preserves Gate449's exact logical and renderer objects by reference and creates one separate deeply frozen screen-coordinate object. It retains semantic roles, token references, identity, side and source ordering. A missing, non-finite, throwing or internally inconsistent coordinate result fails closed as `coordinate-evidence-invalid`; Gate449 unavailable evidence propagates unchanged.

## Truth and ownership boundary

P14 remains saved-plan and execution truth. P19 remains Risk/Reward semantic and provider-neutral logical-object truth. P17 retains renderer-number and active-scale ownership. This application seam reuses P18's released minimal time/price coordinate interfaces without widening the generic drawing contract or moving Risk/Reward meaning into P18.

This slice creates no Canvas pane renderer, provider primitive or attach/detach lifecycle, renderer/session mutation, visible UI, history request, transport, P18 interaction, P20 persistence, journal read or mutation, arithmetic, normalization, or execution, venue, FX or P&L inference.

## Verification

The dedicated verifier and focused tests prove exact scale delegation, preservation of logical/renderer evidence and token references, short-side ordering, unchanged unavailable evidence, fail-closed null/non-finite/throwing/inconsistent evidence and deep freezing. TypeScript, production build, current and historical gates, canonical browser evidence, full regression and both exact-run artifacts remain mandatory.

UI visible: no. A Canvas pane renderer, Lightweight Charts primitive/binding, live-canvas composition, visible Risk/Reward presentation, P18 drawing interactions, P20 save/load and rendered browser interactions remain separate bounded slices.
