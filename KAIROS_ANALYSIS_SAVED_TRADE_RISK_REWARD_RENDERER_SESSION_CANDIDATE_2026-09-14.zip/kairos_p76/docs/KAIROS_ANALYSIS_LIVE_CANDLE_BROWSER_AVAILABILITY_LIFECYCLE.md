# Kairos Analysis live-candle browser availability lifecycle

Date: 13 September 2026

## Responsibility

This bounded item-4 amendment places browser visibility and connectivity lifecycle around Gate421's released gap-recovery coordinator. A selected exact scope starts only while the document is visible and the browser reports online. Hidden or offline transitions stop pending history acquisition and the selected subscription. A later visible-and-online transition reacquires authoritative history through Gate421 before live updates resume.

Repeated unchanged events do not restart work. Selection made while unavailable is retained without acquiring, and only the latest selection may resume. Late activation after suspension or close is suppressed. All three listeners are removed on idempotent close.

## Exclusions

No provider request, stream, reconnect policy, timer, route mount, rendered status, chart presentation, persistence, IndexedDB access, journal mutation, calculation, execution inference, FX, drawing, marker or Live Bubble behavior is introduced. The caller still owns selected scope, history limit, reconnect policy, renderer creation and visible copy. UI VISIBLE:NO. P21 remains active.

## Evidence

- `npm run verify:analysis-live-candle-browser-availability-lifecycle`
- `npx vitest run tests/binance-analysis-live-candle-browser-availability-lifecycle.test.ts tests/binance-analysis-live-candle-gap-backfill-recovery-coordination.test.ts tests/binance-analysis-history-live-candle-bootstrap-coordination.test.ts`
- The dedicated verifier, 19 focused/lower-owner tests, TypeScript and production build pass locally.
- One full-suite attempt passed 311/314 files and 1,299/1,302 tests. Its three failures were inherited asynchronous Journal UI timing cases; all 34 tests in those files then passed in three consecutive isolated reruns. No unrelated source or expectation changed from that evidence.
- Fresh-extract focused/typecheck verification remains required before publication.
- Canonical Node 22.16.0, npm 10.9.2, Lightweight Charts 5.2.1, all current/historical/browser regressions and both exact-run artifacts remain mandatory.
