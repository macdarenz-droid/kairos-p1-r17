# Analysis saved-trade Risk/Reward Canvas pane renderer

## Gate451 bounded scope

Gate450 is the FULL canonical base. This non-UI item-5 slice consumes only Gate450's exact `coordinate-ready` screen evidence and creates one Lightweight Charts-compatible Canvas pane renderer. It snapshots that already-projected geometry, resolves only its existing semantic token references through a caller-owned style source, paints risk/reward zones before entry/stop/target levels in bitmap coordinate space, and restores Canvas state after every draw attempt.

Exact Gate450 unavailable evidence propagates by identity without resolving styles. Internally inconsistent screen evidence, invalid line width/zone opacity, missing token values, or a throwing token resolver fail closed as `canvas-evidence-invalid`. Short-side pixel ordering is preserved; negative Canvas rectangle extents are presentation geometry and are not normalized into financial meaning.

P14 remains saved plan/execution truth. P19 remains Risk/Reward semantic and logical-object truth. P17 remains renderer-number and active-scale ownership. P18 remains generic coordinate, Canvas/provider, primitive and interaction machinery ownership. This application composition uses the released pane-renderer interface without widening P18 or redefining any lower owner.

This slice creates no provider primitive or attach/detach lifecycle, renderer/session mutation, visible UI, chart-scale conversion, history request, transport, P18 interaction, P20 persistence, journal read or mutation, financial arithmetic, price normalization, or execution, venue, FX or P&L inference.

UI visible: no. A Lightweight Charts primitive/binding, live-canvas composition, visible Risk/Reward presentation, P18 drawing interactions, P20 save/load and rendered browser interactions remain separate bounded slices.
