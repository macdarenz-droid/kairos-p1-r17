# Analysis saved-trade renderer marker session

## Scope

This item-5 slice composes Gate441's released saved-execution marker binding with the exact active candlestick series created by the released production P17 renderer. The production renderer reports only attach/detach lifecycle events through a narrow optional seam; it does not expose the provider series on `PresentedChartRenderer`.

The session retains the caller's latest unchanged Gate440 marker projection and chart theme while no candle series exists. When the renderer creates its authoritative candle series, the session creates one Gate441 binding and presents that exact evidence. Renderer series replacement closes the prior binding and reapplies the retained evidence to the replacement series. Provider detachment, presentation failure and session close clean up deterministically.

Overlapping active series and mismatched detach evidence fail closed. Closing is idempotent, clears retained projection/theme evidence and rejects later presentation or attachment. A caller can distinguish pending-series evidence from a provider-presented or unavailable Gate441 result.

P17 remains the sole renderer and provider-series lifecycle owner. Gate441 remains the sole Lightweight Charts marker-plugin and categorical marker-mapping owner. P14 remains the sole saved execution-fact owner, and P18 drawing-tool ownership is unchanged. No saved value is recalculated, normalized, snapped or inferred.

This session is not imported by the Analysis route, workspace, live canvas or route-session lifecycle, so it makes no visible UI change. It starts no request, subscription, stream or timer, adds no provider, and performs no persistence and no journal mutation. It makes no execution, venue, FX or P&L inference. Accessible visible saved-trade presentation, P19 risk/reward, P18 tools and P20 save/load remain later bounded slices.

## Verification

- dedicated static ownership and forbidden-dependency verifier;
- focused Gate440/Gate441/session and P17 production-renderer regressions;
- TypeScript and production build;
- fresh-extract install, dedicated/focused/typecheck/build, exact root/path-safety/integrity checks;
- canonical Node 22.16.0, npm 10.9.2 and Lightweight Charts 5.2.1 gate, browser evidence, full regression, historical closures and exact-run artifacts.
