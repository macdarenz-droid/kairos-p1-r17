# Analysis saved-trade Lightweight Charts v5 marker binding

## Scope

This item-5 slice binds Gate440's immutable execution-marker projection to one caller-owned Lightweight Charts v5.2.1 candlestick series. The binding creates at most one series-markers plugin, replaces that plugin's marker set on later calls, clears unavailable evidence and detaches exactly once on close.

Each provider marker uses Gate440's stable marker identity, its authoritative candle-open anchor and its recorded execution price. Entry and exit use distinct circle/square shapes plus established chart drawing theme tokens. The exact execution timestamp, quantity and other saved facts remain unchanged in Gate440's projection; the provider marker is presentation only. P17 remains the sole timestamp and decimal renderer-conversion owner, while P14 remains the sole saved execution-fact owner. A recorded zero survives the provider conversion because missing is not zero.

Unplaced executions remain the exact Gate440 collection returned to the caller. They are not passed to the provider and are never snapped to a neighbouring candle. Invalid timestamp or decimal evidence fails before provider mutation. An unavailable projection clears prior markers and retains its exact reason.

## Ownership boundaries

This binding owns only the Lightweight Charts series-marker plugin lifecycle and the provider's categorical marker mapping. P18 drawing-tool ownership is unchanged: no generic drawing, selection, editing, deletion or hit-test owner is added or widened.

The slice does not expose or mount a renderer in Analysis, does not select a saved trade and causes no visible UI change. It creates no history request, transport, provider policy, persistence, calculation or route/workspace component. It performs no journal mutation and makes no execution, venue, FX or P&L inference. P19 risk/reward and P20 Saved Analysis remain separate released systems for later composition.

## Verification

- dedicated static ownership verifier;
- focused Gate439/Gate440/provider-binding and P17 conversion regressions;
- TypeScript and production build;
- fresh-extract install, focused verification, root/path-safety and ZIP integrity;
- unchanged canonical Node 22.16 / npm 10.9.2 / Lightweight Charts 5.2.1 browser evidence, full regression, historical closures and exact-run artifacts.
