# Kairos Analysis Live Candle Production Lifecycle

Date: 13 September 2026  
Roadmap owner: item 4 live candle continuity (P15/P16 + P17)  
UI visible: no

## Responsibility

This bounded item-4 amendment provides the production composition root for the already released live-candle owners. It binds the existing Analysis history port to Gate420's bootstrap, Gate419's selected-session owner, Gate421's gap recovery and Gate422's browser-availability lifecycle. Creation alone starts no history request, stream or timer.

The caller remains authoritative for the selected Binance Spot instrument, interval, history limit, reconnect policy, renderer, callbacks and visible copy. The returned lifecycle must be closed by its eventual route owner.

## Exclusions

No provider request or stream implementation, reconnect default, selection, React route mount, visible status, chart presentation, persistence, IndexedDB access, journal mutation, calculation, execution inference, FX, drawing, marker or Live Bubble behavior is introduced. UI VISIBLE:NO. P21 remains active.

## Evidence

- The dedicated verifier proves exact use of the released composition chain and rejects route, storage, timer, transport and policy ownership.
- Focused tests prove authoritative history precedes live start, the final returned candle seeds the live session, caller policy/renderer/callbacks pass through unchanged, hidden resume reacquires history, gap recovery is coalesced and close removes listeners.
- TypeScript, production build, focused tests, full regressions, historical closures and exact candidate/artifact verification remain mandatory.
