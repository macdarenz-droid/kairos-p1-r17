# Analysis saved-trade Risk/Reward renderer projection

## Scope

This is the smallest dependency-safe item-5 prerequisite after the FULL Gate448 Risk/Reward reference projection. `analysisSavedTradeRiskRewardRendererProjection.ts` converts only Gate448's exact ready logical chart object into renderer timestamps and numeric prices through P17's released `projectChartTimestamp` and `projectChartDecimal` owners.

The result preserves the exact Gate448 logical object by reference, including analysis identity, side, source timestamp strings, Decimal strings and P19 semantic token references. It creates a separate deeply frozen renderer object. Long- and short-side price ordering is not normalized. Gate448 unavailable evidence passes through unchanged, while inconsistent released evidence or failed renderer conversion returns the explicit `renderer-evidence-invalid` result.

## Truth and ownership boundary

P14 remains the saved plan and execution truth owner. P19 remains the Risk/Reward semantic, style-reference and provider-neutral logical-object owner. P17 remains the only timestamp and Decimal-to-renderer-number conversion owner. This integration boundary validates that the released P19 objects agree before delegating conversion; it does not calculate, normalize or manufacture a level, time, token or trade fact.

P18 retains generic drawing/provider/interaction machinery and is not widened. P20 retains Saved Analysis persistence. This slice creates no Lightweight Charts primitive or provider API binding, renderer/session mutation, visible UI, history request, transport, journal read or mutation, storage change, arithmetic, or execution, venue, FX or P&L inference.

## Verification

The dedicated verifier and focused tests prove exact P17 delegation, separate preservation of logical evidence and token references, short-side source ordering, unavailable propagation, fail-closed consistency/conversion behavior and deeply frozen renderer output. TypeScript, production build, current and historical gates, canonical browser evidence, full regression and both exact-run artifacts remain mandatory.

UI visible: no. Lightweight Charts primitive/binding, live-canvas composition, visible Risk/Reward presentation, P18 drawing interactions, P20 save/load and rendered browser interactions remain separate bounded slices.
