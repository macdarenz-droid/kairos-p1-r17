# Analysis saved-trade live-candle workspace mount

UI visible: yes.

This item-5 slice mounts Gate445 R1's released saved-trade live-candle composition through the existing chart-first Analysis route. The route supplies only its exact P12-hydrated selected entry. The workspace continues to own explicit Binance Spot metadata symbol and timeframe selection, then chooses the saved-trade composition only when that exact entry is available.

The chart remains usable without a selected saved trade through the released base live-candle canvas. While an explicitly requested saved trade is still loading, the workspace starts neither canvas, preventing a disposable base session and second sequential history acquisition. Once the entry resolves, Gate445 R1 uses the same authoritative live-candle history, renderer and transport lifecycle already released by item 4.

Gate438 continues to fail closed unless the saved trade has exact crypto market type plus exact symbol and quote-asset evidence, including case-sensitive symbol identity and recorded result currency. Therefore a selected trade never forces itself onto an unrelated chart. Gate439 keeps before-history, after-history, gaps and invalid times unplaced. Gate440 preserves recorded execution prices and exact execution identities; candle OHLC values never become execution facts.

`AnalysisHistoryWorkspace` does not read IndexedDB or load journal data. `AnalysisRoute` retains P12 read orchestration, saved facts remain immutable, and no additional history request, provider transport, persistence, journal mutation or arithmetic is introduced. There is no execution, venue, FX or P&L inference. Accessible placed/unplaced evidence remains the next presentation responsibility; P18 drawing ownership and P19 risk/reward remain unchanged.

Verification covers exact route-to-workspace entry handoff, pending-read suppression, saved-trade versus base-canvas exclusivity, chart-first ordering, zero workspace history ownership, lower-owner marker/live-candle regressions, TypeScript, production build, fresh-archive integrity and the complete canonical gate with Node 22.16.0, npm 10.9.2 and Lightweight Charts 5.2.1.
