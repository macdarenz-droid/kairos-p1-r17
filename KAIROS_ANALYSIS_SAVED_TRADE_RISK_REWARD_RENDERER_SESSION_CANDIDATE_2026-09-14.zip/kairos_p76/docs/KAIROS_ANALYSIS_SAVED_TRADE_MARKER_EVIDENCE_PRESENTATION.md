# Kairos Analysis saved-trade marker evidence presentation

## Scope

Gate447 closes the accessible presentation gap left after the FULL Gate446 workspace mount. UI visible: yes.

`AnalysisSavedTradeMarkerEvidencePresentation` receives only Gate444/Gate443's already-complete presentation result and the exact caller-authoritative quote asset. `AnalysisSavedTradeLiveCandleCanvas` places that view beside the existing marker-enabled live chart. It performs no journal read, history request, renderer mutation or provider operation.

## Truthful states

- Before an authoritative snapshot produces a complete result, the view says that marker details are being prepared. It does not claim that any marker is placed.
- A fail-closed Gate438 or Gate439 result remains unavailable with specific, user-safe scope/history guidance. It does not invent marker facts.
- A complete result states the exact number of markers shown and executions not shown.
- The expandable table preserves exact saved execution facts: role, timestamp, price and quantity. A shown execution also preserves its authoritative candle anchor. An explicitly unplaced execution retains its exact invalid-time, before-history, after-history or uncovered-gap reason and is never snapped to a candle.
- If a lower owner rejects a refresh, a generic alert says the last complete details remain unchanged. Raw error content is never displayed.

The caption identifies prices in the exact validated quote asset and times in UTC. It does not claim that the chart provider was the execution venue.

## Ownership boundaries

- P12 remains the saved-trade read owner and P14 remains the exact execution-fact owner.
- Gate438–Gate440 remain eligibility, candle-window and marker-fact owners.
- Gate441/Gate442 remain provider marker and renderer-session owners.
- Gate443/Gate444 remain complete-result and React-lifecycle owners.
- Gate446 remains route/workspace mount owner.
- P18 drawing tools, P19 risk/reward and P20 save/load remain separate later responsibilities.

This adds no execution, venue, FX or P&L inference. No persistence, journal mutation, financial arithmetic, provider expansion or direct UI IndexedDB access is added.

## Verification

The dedicated verifier and focused component/lower-owner tests prove preparation, ready, fail-closed unavailable and retained-result error states; exact placed/unplaced evidence; accessible status/table semantics; and raw-error suppression. TypeScript, production build, exact archive identity and the complete canonical gate remain mandatory.
