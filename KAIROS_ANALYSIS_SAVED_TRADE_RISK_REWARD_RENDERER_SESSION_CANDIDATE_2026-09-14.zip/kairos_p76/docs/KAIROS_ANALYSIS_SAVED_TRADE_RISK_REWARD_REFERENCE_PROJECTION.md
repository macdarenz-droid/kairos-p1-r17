# Analysis saved-trade Risk/Reward reference projection

## Scope

This is the smallest dependency-safe item-5 prerequisite after the FULL Gate447 marker-evidence presentation. `analysisSavedTradeRiskRewardReferenceProjection.ts` consumes Gate438's exact chart-reference result and a caller-authoritative time extent, then delegates exact recorded planned entry, stop and target levels through the already-released P19 semantic, style-reference, logical-placement and chart-object owners.

The result is ready only when Gate438's symbol/quote eligibility is ready, all three planned levels are present, and the exact caller extent contains valid, non-reversed timestamps. Missing evidence remains explicit: missing does not equal zero, and an exact zero `DecimalString` is preserved. Long- and short-side price ordering is not normalized.

## Truth and ownership boundary

P14 remains the sole saved plan/execution projection owner. This amendment reads only the planned levels already projected by P14; it never substitutes an execution or candle OHLC value. P19 remains the sole Risk/Reward semantic and provider-neutral logical chart-object owner. The integration boundary supplies a stable saved-trade analysis identity and delegates unchanged levels and the exact caller-authoritative time extent through P19.

P18 retains generic provider/drawing lifecycle and interaction machinery. P20 retains Saved Analysis persistence. This slice creates no provider primitive, renderer/session mutation, UI, history request, transport, journal read or mutation, schema/storage change, or arithmetic, and makes no execution, venue, FX or P&L inference. It does not validate or manufacture trade direction, price ordering, R multiple, position size, or result currency.

## Verification

The dedicated verifier and focused tests prove exact planned-level and time preservation, explicit missing/reference/extent outcomes, zero-versus-missing behavior, short-side order preservation, released P19 delegation and deeply frozen outputs. TypeScript, production build, current and historical gates, canonical browser evidence, full regression and both exact-run artifacts remain mandatory.

UI visible: no. Provider binding, live-canvas composition, visible Risk/Reward presentation, P18 drawing tools, P20 save/load and rendered browser interactions remain separate bounded slices.
