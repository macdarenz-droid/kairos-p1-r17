# Analysis saved-trade live-candle composition

UI visible: no.

This item-5 slice composes Gate444's React-owned saved-trade marker session with the released live-candle canvas without mounting that composition in the Analysis route or workspace. Gate444 supplies the exact renderer factory that owns the saved-execution marker plugin. The existing live-candle route session uses that factory for its one authoritative candlestick renderer, then returns only its exact successful activation snapshot to Gate444 for reference, candle-window and marker projection.

The composition waits until Gate444 has a renderer factory before starting the live owner. Its snapshot is keyed by exact venue, symbol, interval and caller revision, so selection replacement cannot briefly project a prior page against a new scope. The existing live canvas gains only two narrow higher-owner seams: an optional released route-session factory and a callback carrying the exact successful snapshot already rendered by that canvas.

Gate444 retains saved-trade marker lifecycle and exact P14 execution evidence. The released live-candle chain retains history acquisition, scope validation, renderer replacement, transport, reconnect, gap recovery, hidden/offline behavior and truthful status. P17 retains renderer/provider-series behavior; P18 and P19 remain unchanged.

`AnalysisRoute`, `AnalysisHistoryWorkspace` and the currently mounted `AnalysisLiveCandleCanvas` path are unchanged, so there is no visible UI change. This slice adds no history request, transport, persistence or journal mutation, performs no arithmetic, and makes no execution, venue, FX or P&L inference. Missing evidence never becomes zero.

Verification includes a dedicated ownership verifier, exact React composition regressions, the released live-canvas and Gate438–Gate444 regressions, TypeScript, production build, fresh-extract integrity checks, and the complete canonical gate with exact Node 22.16.0, npm 10.9.2 and Lightweight Charts 5.2.1.
