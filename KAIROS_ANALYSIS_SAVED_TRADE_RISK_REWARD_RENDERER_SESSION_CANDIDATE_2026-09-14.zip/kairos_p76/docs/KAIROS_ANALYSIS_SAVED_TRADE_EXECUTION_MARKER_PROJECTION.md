# Analysis saved-trade execution-marker projection

## Scope

This item-5 prerequisite converts Gate439's exact candle-window placement evidence into immutable provider-neutral marker facts. A placed execution receives one stable `journal-execution:<executionId>` marker identity and the authoritative candle open/close/index needed by a later renderer binding.

The candle anchor is presentation placement, not an execution-time rewrite. The projection retains the exact execution ID, entry/exit role, price, quantity and `executedAt` value. P14 remains the sole saved execution-fact owner. A recorded zero price is preserved because missing is not zero.

Executions outside the authoritative page or inside a gap stay in `unplacedExecutions` with their exact Gate439 reason. They are never snapped to a neighbouring candle. An unavailable Gate439 result remains unavailable, and duplicate execution IDs fail closed rather than producing ambiguous marker identities.

## Ownership boundaries

This slice introduces no Lightweight Charts call, marker shape/color, renderer/session mutation, history request, transport, provider policy, persistence, calculation or route/workspace component. It performs no journal mutation, makes no execution, venue, FX or P&L inference, and causes no visible UI change.

Later bounded slices may bind these facts to the released renderer, add accessible visible presentation, compose P19 planned risk/reward, and integrate P18/P20 tools. Those later owners must continue to preserve the exact saved facts and explicit unavailable evidence.

## Verification

- dedicated static ownership verifier;
- focused Gate438/Gate439/marker and P14 fact regressions;
- TypeScript and production build;
- fresh-extract install, focused verification, root/path-safety and ZIP integrity;
- the unchanged canonical Node 22.16 / npm 10.9.2 / Lightweight Charts 5.2.1 gate, browser evidence, full regression, historical closures and both exact-run artifacts.
