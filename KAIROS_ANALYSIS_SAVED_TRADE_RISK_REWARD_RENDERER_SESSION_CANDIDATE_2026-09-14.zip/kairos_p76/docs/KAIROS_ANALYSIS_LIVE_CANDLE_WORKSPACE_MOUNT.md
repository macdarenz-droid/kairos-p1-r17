# Analysis live-candle workspace mount

## Bounded item-4 result

Gate436 replaces the duplicate historical request/renderer lifecycle inside `AnalysisHistoryWorkspace` with the released Gate435 `AnalysisLiveCandleCanvas`. The chart remains first in `AnalysisRoute` and still works without selecting a saved trade.

The workspace retains only its existing caller responsibilities:

- acquire and filter exact Binance Spot instrument metadata;
- require an explicit supported symbol and timeframe;
- supply the selected immutable instrument identity and caller-authoritative quote asset;
- own the explicit refresh revision key; and
- preserve the market-reference/saved-trade separation and attribution.

The released live-candle route session now owns the single authoritative 500-candle acquisition, scope validation, renderer creation, selected-session replacement, bounded reconnect, gap recovery and browser visibility/connectivity lifecycle. The workspace does not make a second history request or create a second renderer/transport state.

## Visible behavior

UI VISIBLE:YES.

After a user chooses a symbol and timeframe, Analysis now shows the released historical-to-live canvas, truthful provider lifecycle status, exact snapshot count/quote asset/UTC receipt details, unchanged OHLC strings, and the released pan/zoom/fit controls. A live claim appears only after the exact provider connection reports `live`. Hidden/offline, reconnect, recovery, empty, unavailable, scope-rejection and renderer-failure states retain Gate433's distinct safe copy. Refresh changes only the caller revision for the exact selected scope.

The saved-trade picker/review remains below the chart. No saved-trade fact, execution, fee, result or journal record is changed.

## Preserved boundaries

- No provider expansion or provider-policy change.
- No journal mutation, calculation, execution inference, FX conversion or P&L inference.
- No saved-analysis write, direct UI IndexedDB access or persistence/schema change.
- No drawing, marker, risk-box, Live Bubble or phase closure.
- P14, P18 and P19 remain separate existing owners; P21 remains active and P40 remains later.

## Verification

The dedicated verifier proves the default workspace mount, exact metadata-to-canvas props, explicit refresh revision, absence of workspace history/transport ownership, chart-first route order and retained lower-owner scope/empty checks.

Focused React regressions prove no default/alias selection, duplicate/halted/foreign filtering, exact selection replacement, no direct history acquisition, explicit-only refresh, metadata retry and timeout/unmount cancellation. Real-browser evidence must prove one mocked provider-connected WebSocket scope, one authoritative history request per activation, real renderer pixels, touch pan, pinch zoom, keyboard controls, responsive themes, exact decimal Candle Values, mobile overflow containment, truthful failure states and unchanged saved facts.

Canonical verification remains authoritative under Node 22.16.0, npm 10.9.2, Lightweight Charts 5.2.1 and Playwright 1.62.1. The candidate must preserve every current, historical, browser, full-unit and controlled-roadmap gate plus both exact-run artifacts before promotion.

## Gate437 R1 canonical repair

Gate436 failed only because the inherited product-policy verifier still expected history request and returned-limit checks inside `AnalysisHistoryWorkspace`. This workspace intentionally delegates those responsibilities to the released route-session/bootstrap chain. R1 changes no product or visible UI bytes: it strengthens that verifier to prove the exact 500-candle constant at the route-session owner, exact requested-limit validation at the bootstrap owner, and continued absence of duplicate workspace history policy.
