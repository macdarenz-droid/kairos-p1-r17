# Analysis saved-trade candle-window projection

## Scope

This bounded item-5 prerequisite places the exact saved entry and exit execution instants released by Gate438 inside one caller-authoritative candle-history page. Placement succeeds only when the history instrument exactly matches the already-eligible chart reference and the instant is within an authoritative candle's inclusive open/close bounds. Before-history, after-history, uncovered-gap and invalid-time outcomes remain explicit instead of being snapped to a neighbouring candle.

P14 remains the sole saved execution-fact owner. The projection carries its exact execution ID, type, price, quantity and timestamp unchanged; no candle OHLC value becomes an execution price. The returned history observation and interval are also caller-authoritative. Outputs are frozen.

This slice creates no marker geometry, renderer call, route/workspace mount, provider/history acquisition, stream, timer, persistence or IndexedDB access. There is no journal mutation. It performs no execution, venue, FX or P&L inference and makes no visible UI change. P18 drawing and P19 risk/reward ownership remain unchanged; presentation and provider marker binding are later slices. P21 remains active.

## Verification

- The dedicated verifier requires exact scope checks, inclusive placement, explicit gap/boundary failures and unchanged execution facts while rejecting financial arithmetic, transport, storage, renderer and marker-provider ownership.
- Focused tests cover inclusive candle bounds, history gaps, before/after bounds, unavailable reference, exact instrument mismatch, empty/invalid history, invalid execution time and immutable outputs.
- TypeScript, production build, full regression, historical checks, browser evidence and both exact-run artifacts remain canonical requirements.
