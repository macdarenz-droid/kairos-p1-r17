# KAIROS P17.13 — Chart Visible Range Boundary

## OBJECTIVE
Expose visible logical range as provider-neutral presentation demand so later history orchestration can react to viewport needs without moving acquisition ownership into P17.

## AUTHORITATIVE BASE
P17.12 Incremental Chart Engine Driver Composition — canonical PASS, Run #184 / Run ID 33745472138.

## RESEARCH
Lightweight Charts v5.2 exposes getVisibleLogicalRange(), subscribeVisibleLogicalRangeChange(), and matching unsubscribe on ITimeScaleApi. Logical ranges can extend beyond loaded data, so they are suitable as viewport demand without inventing historical market truth.

## CHANGE
Provider-neutral visible-range contract; narrow Lightweight Charts time-scale seam; adapter with exact idempotent subscription cleanup; dedicated tests/verifier.

## NON-SCOPE
No historical fetch, Binance request, candle aggregation, persistence, journal mutation, calculations, drawings, markers, navigation, styling, or P18.

## OWNERSHIP
P17 owns viewport presentation demand only. P15/P16 retain provider/acquisition ownership. Visible range is not market truth.

## RESULT
Candidate prepared from exact P17.12 canonical artifact. Canonical GitHub CI required for promotion.
