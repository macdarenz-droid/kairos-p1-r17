import { readFileSync } from 'node:fs';
const contract=readFileSync('src/features/chart/chartVisibleRange.ts','utf8');
const adapter=readFileSync('src/features/chart/lightweightChartsV5VisibleRange.ts','utf8');
const vendor=readFileSync('src/features/chart/lightweightChartsV5ModuleAdapter.ts','utf8');
for(const token of ['getVisibleLogicalRange()','subscribeVisibleLogicalRangeChange'])
  if(!contract.includes(token)) throw new Error(`missing-contract:${token}`);
for(const token of ['timeScale.getVisibleLogicalRange()','timeScale.subscribeVisibleLogicalRangeChange(handler)','timeScale.unsubscribeVisibleLogicalRangeChange(handler)'])
  if(!adapter.includes(token)) throw new Error(`missing-adapter:${token}`);
for(const token of ['getVisibleLogicalRange(): LightweightChartsV5LogicalRange | null','subscribeVisibleLogicalRangeChange','unsubscribeVisibleLogicalRangeChange'])
  if(!vendor.includes(token)) throw new Error(`missing-vendor-seam:${token}`);
for(const forbidden of ['fetch(', 'indexedDB', 'localStorage'])
  if(contract.includes(forbidden)||adapter.includes(forbidden)) throw new Error(`forbidden-owner:${forbidden}`);
console.log('P17.13 chart visible range boundary verifier: PASS');
