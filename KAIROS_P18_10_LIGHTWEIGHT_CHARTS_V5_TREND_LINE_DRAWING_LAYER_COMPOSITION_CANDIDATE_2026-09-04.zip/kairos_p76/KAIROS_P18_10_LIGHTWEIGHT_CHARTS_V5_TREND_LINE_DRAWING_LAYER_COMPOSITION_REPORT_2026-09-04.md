# KAIROS P18.10 — Lightweight Charts v5 Trend-Line Drawing-Layer Composition

## Scope
Compose the already-canonical P18 drawing boundaries into one provider drawing-layer port:
P18.3 neutral lifecycle + P18.4 provider primitive lifecycle + P18.8 trend-line primitive factory + P18.9 provider-series resolution.

## Ownership
- P18.3 owns neutral drawing-layer session semantics.
- P18.4 owns attachPrimitive/detachPrimitive replacement semantics.
- P18.8 owns creation of fresh trend-line primitives.
- P18.9 owns neutral-handle to vendor-series identity resolution.
- P18.10 owns composition only.

## Non-scope
No drawing truth changes, coordinate conversion, Canvas implementation, hit testing, pointer/crosshair capture, drag/edit state, toolbar, persistence, autoscale ownership, calculations, market acquisition, journal truth, or P19 risk/reward behavior.

## Local evidence
Dedicated static verifier passes. Canonical GitHub gate remains authoritative for deterministic install, TypeScript, production build, Vitest, full roadmap regression, and historical closures.
