import { createChartDrawingLayerPortFromDriver, type ChartDrawingLayerPort } from './chartDrawingLayerPort';
import { createLightweightChartsV5DrawingLayerDriver } from './lightweightChartsV5DrawingLayerDriver';
import type { LightweightChartsV5DriverBinding } from './lightweightChartsV5ModuleAdapter';
import { createLightweightChartsV5TrendLinePrimitiveFactory } from './lightweightChartsV5TrendLinePrimitiveFactory';
import type { LightweightChartsV5TrendLineStrokeStyle } from './lightweightChartsV5TrendLinePaneRenderer';

/**
 * P18.10 production drawing-layer composition invariant:
 * - P18.3 remains the provider-neutral drawing-layer lifecycle owner
 * - P18.4 remains the provider primitive attach/detach owner
 * - P18.8 remains the trend-line primitive factory owner
 * - P18.9 remains the neutral-handle -> vendor-series identity owner
 * - this composition only wires those existing owners into one drawing-layer port
 * - no drawing truth, coordinate conversion, Canvas rendering, hit testing, interaction,
 *   persistence, calculations, market acquisition, journal truth, or P19 behavior lives here
 */
export function createLightweightChartsV5TrendLineDrawingLayerPort(
  binding: LightweightChartsV5DriverBinding,
  style: LightweightChartsV5TrendLineStrokeStyle,
): ChartDrawingLayerPort {
  const primitiveFactory = createLightweightChartsV5TrendLinePrimitiveFactory(style);
  const driver = createLightweightChartsV5DrawingLayerDriver(
    (series) => binding.resolveSeries(series),
    primitiveFactory,
  );
  return createChartDrawingLayerPortFromDriver(driver);
}
