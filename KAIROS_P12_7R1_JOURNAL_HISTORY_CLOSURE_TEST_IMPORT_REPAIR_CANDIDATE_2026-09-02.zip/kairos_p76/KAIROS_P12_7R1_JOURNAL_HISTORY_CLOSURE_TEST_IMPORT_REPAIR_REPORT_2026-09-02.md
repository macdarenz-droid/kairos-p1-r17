# KAIROS P12.7R1 — Journal History Closure Test Import Repair

Status: CANDIDATE / HOLD pending canonical GitHub gate.
Base: canonical P12.6R1 PASS.

## Objective
Repair the P12.7 closure candidate build failure without changing production code. The failed P12.7 test imported a nonexistent `decimalFromString` member from the Calculation Brain barrel. The authoritative decimal validation/parser for persisted trade-domain decimal strings is `parseDecimalString` from `src/domain/trades`.

## Controlled scope
Exactly four files differ from P12.6R1:
1. this report;
2. `package.json` — registers the P12 Journal History closure verifier;
3. `scripts/verify-p12-journal-history-closure.mjs` — closure orchestration verifier plus an explicit guard requiring `parseDecimalString` and forbidding `decimalFromString`;
4. `tests/journal-history-closure.test.tsx` — closure integration test repaired to use `parseDecimalString`.

No `src/` production file changes.

## Closure contract retained
The integration regression persists a closed trade, executions, and fee evidence through authoritative repositories; queries through `listJournalHistory`; verifies P11-owned gross P&L and fee composition; preserves unavailable net P&L where fee/result currencies are not proven comparable; renders the Journal route; and exercises the indexed status filter.

The closure verifier continues to require bounded/index-backed history retrieval, child-evidence composition, latest-wins route orchestration, no load-all/application `.filter()` query regression, USER_HEAVY 10,500-trade timing coverage, and route presentation/accessibility contracts.

## Repair rationale
`decimalFromString` is not exported by `src/domain/calculations/index.ts` and does not exist in the authoritative P12.6R1 source. `parseDecimalString` is exported by `src/domain/trades/index.ts` via `tradeValidation.ts` and returns the validated `DecimalString` required by persisted execution/fee records.

## Local verification
Static closure verifier and dependent P12 verifiers are required before packaging. Canonical GitHub gate must run clean `npm ci`, production build, full unit regression, the full controlled P1–P12 verifier chain, explicit closure integration test, and the USER_HEAVY timing canary.
