import fs from 'node:fs';

const requiredFiles = [
  'src/application/journal/historyQuery.ts',
  'src/data/repositories/TradeRepositories.ts',
  'src/app/JournalRoute.tsx',
  'src/app/JournalHistoryList.tsx',
  'tests/journal-history-query.test.ts',
  'tests/journal-history-route.test.tsx',
  'tests/journal-history-performance.test.tsx',
  'tests/journal-history-closure.test.tsx',
];
for (const file of requiredFiles) if (!fs.existsSync(file)) throw new Error(`P12.7R1 missing Journal History artifact: ${file}`);

const query = fs.readFileSync('src/application/journal/historyQuery.ts','utf8');
for (const evidence of [
  'DEFAULT_JOURNAL_HISTORY_LIMIT = 100',
  'MAX_JOURNAL_HISTORY_LIMIT = 500',
  'listRecentByUpdatedAt',
  'listRecentByStatusAndUpdatedAt',
  'calculateTradeMetrics',
  'repositories.tradePlans.listByTradeId',
  'repositories.tradeExecutions.listByTradeId',
  'repositories.tradeFees.listByTradeId',
]) if (!query.includes(evidence)) throw new Error(`P12.7R1 query contract missing: ${evidence}`);
if (query.includes('.listAll(') || query.includes('.filter(')) throw new Error('P12.7R1 journal query regressed to load-all/application filtering.');

const repo = fs.readFileSync('src/data/repositories/TradeRepositories.ts','utf8');
for (const evidence of ["orderBy('updatedAt')", ".reverse()", ".limit(limit)", "where('[status+updatedAt]')"]) {
  if (!repo.includes(evidence)) throw new Error(`P12.7R1 repository index contract missing: ${evidence}`);
}

const route = fs.readFileSync('src/app/JournalRoute.tsx','utf8');
for (const evidence of ['historyRequestSequence','listJournalHistory(db,','await refreshHistory()']) {
  if (!route.includes(evidence)) throw new Error(`P12.7R1 route orchestration missing: ${evidence}`);
}
if (/indexedDB|\.trades\.(?:where|orderBy|toArray|filter)/.test(route)) throw new Error('P12.7R1 route acquired direct storage/query ownership.');

const list = fs.readFileSync('src/app/JournalHistoryList.tsx','utf8');
for (const evidence of ['Trade history','Show trades','All trades','No ${statusLabel(statusFilter).toLowerCase()} trades found.','Gross P&amp;L','Net P&amp;L']) {
  if (!list.includes(evidence)) throw new Error(`P12.7R1 history presentation contract missing: ${evidence}`);
}

const performance = fs.readFileSync('tests/journal-history-performance.test.tsx','utf8');
for (const evidence of ['10_500','HISTORY_PAGE_LIMIT = 100','INITIAL_RENDER_BUDGET_MS = 5_000','STATUS_FILTER_BUDGET_MS = 3_000',"value: 'closed'","getAllByRole('listitem')"]) {
  if (!performance.includes(evidence)) throw new Error(`P12.7R1 USER_HEAVY canary missing: ${evidence}`);
}

const closure = fs.readFileSync('tests/journal-history-closure.test.tsx','utf8');
if (!closure.includes('parseDecimalString')) throw new Error('P12.7R1 closure test must use authoritative trade-domain decimal parsing.');
if (closure.includes('decimalFromString')) throw new Error('P12.7R1 closure test retained nonexistent decimalFromString import.');
for (const evidence of ["grossPnl).toBe('40')","totalFees).toBe('5')",'netPnl).toBeNull()',"value:'closed'","getAllByRole('listitem')"]) {
  if (!closure.includes(evidence)) throw new Error(`P12.7R1 closure regression missing: ${evidence}`);
}

console.log('P12.7R1 Journal History closure verification PASS');
