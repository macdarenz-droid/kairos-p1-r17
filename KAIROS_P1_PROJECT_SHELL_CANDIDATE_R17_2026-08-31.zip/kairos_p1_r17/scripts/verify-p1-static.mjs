import { readFile, readdir } from 'node:fs/promises';
import { extname, join, relative } from 'node:path';

const root = new URL('../', import.meta.url);
const packageJson = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));
const allVersions = [...Object.values(packageJson.dependencies ?? {}), ...Object.values(packageJson.devDependencies ?? {})];
if (allVersions.some((version) => version === 'latest' || /^[~^]/.test(version))) {
  throw new Error('P1 dependencies must be pinned exactly for reproducible verification.');
}
if (packageJson.scripts?.['verify:doctor'] !== 'node scripts/p1-environment-doctor.mjs') {
  throw new Error('P1 environment doctor must have one package script owner.');
}
if (packageJson.scripts?.['verify:toolchain'] !== 'node scripts/verify-p1-toolchain.mjs') {
  throw new Error('P1 toolchain verification must have one package script owner.');
}
if (packageJson.scripts?.['release:p1'] !== 'node scripts/run-p1-release-gate.mjs') {
  throw new Error('P1 one-command release gate must have one package script owner.');
}
if (packageJson.scripts?.['verify:p1'] !== 'npm run verify:toolchain && npm run verify:static && npm run verify:gate') {
  throw new Error('P1 portable verification must have one package script owner.');
}
if (!packageJson.devDependencies?.['@testing-library/dom']) {
  throw new Error('React Testing Library v16 requires @testing-library/dom.');
}

const requiredFiles = [
  'scripts/verify-p1-gate.mjs',
  'scripts/p1-gate-result.mjs',
  'scripts/test-p1-gate-result.mjs',
  'scripts/p1-environment-doctor.mjs',
  'scripts/resolve-p1-lock.mjs',
  'scripts/verify-p1-lock.mjs',
  'scripts/run-p1-release-gate.mjs',
  'scripts/test-p1-lock-verifier.mjs',
  'scripts/verify-p1-toolchain.mjs',
  '.github/workflows/p1-gate.yml',
  '.gitignore',
  'src/main.tsx',
  'src/app/router.tsx',
  'src/app/routes.tsx',
  'src/app/ErrorBoundary.tsx',
  'src/diagnostics/DiagnosticsService.ts',
  'src/testing/setup.ts',
  'tests/diagnostics.test.ts',
  'tests/router.test.tsx',
  'tests/error-boundary.test.tsx',
];
for (const file of requiredFiles) await readFile(new URL(`../${file}`, import.meta.url));

const routerSource = await readFile(new URL('../src/app/router.tsx', import.meta.url), 'utf8');
const routerTestSource = await readFile(new URL('../tests/router.test.tsx', import.meta.url), 'utf8');
if (!/createBrowserRouter\(appRoutes\)/.test(routerSource) || !/createMemoryRouter\(appRoutes/.test(routerTestSource)) {
  throw new Error('Production and test routers must consume the same appRoutes owner.');
}

const shellCss = await readFile(new URL('../src/shell.css', import.meta.url), 'utf8');
if (/#[0-9a-f]{3,8}\b|\brgb\(|\bhsl\(|font-family|padding|border-radius|box-shadow/i.test(shellCss)) {
  throw new Error('P1 shell CSS must remain presentation-neutral; visual tokens belong to P2.');
}

async function walk(dirUrl) {
  const entries = await readdir(dirUrl, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const child = new URL(`${entry.name}${entry.isDirectory() ? '/' : ''}`, dirUrl);
    if (entry.isDirectory()) files.push(...await walk(child));
    else files.push(child);
  }
  return files;
}

const sourceFiles = await walk(new URL('../src/', import.meta.url));
const forbiddenBusinessTerms = /\b(decimal\.js|dexie|indexeddb|websocket|tradeexecution|trademetrics|marketdata|serviceworker|localstorage|sessionstorage)\b/i;
for (const fileUrl of sourceFiles) {
  if (!['.ts', '.tsx', '.css'].includes(extname(fileUrl.pathname))) continue;
  const text = await readFile(fileUrl, 'utf8');
  if (forbiddenBusinessTerms.test(text)) {
    throw new Error(`P1 scope leak detected in ${relative(root.pathname, fileUrl.pathname)}.`);
  }
}

console.log('P1 static contract: PASS');
console.log(`Checked ${sourceFiles.length} source files and ${allVersions.length} pinned package versions.`);
