import { readFileSync } from 'node:fs';

const production = readFileSync('src/app/SettingsRoute.tsx', 'utf8');
const tests = readFileSync('tests/settings-visual-pnl-time-zone.test.tsx', 'utf8');

for (const required of [
  "screen.getByRole('textbox', { name: 'Time zone' })",
  "await waitFor(() => expect(input).toBeEnabled())",
  "const input = await readyTimeZoneInput()",
  "readVisualPnlTimeZonePreference(repositories.metadata)",
]) {
  if (!tests.includes(required)) throw new Error(`P13.12R1 missing async test repair evidence: ${required}`);
}

for (const forbidden of [
  'resolvedOptions().timeZone',
  'getTimezoneOffset',
  'navigator.language',
  'localStorage',
  'sessionStorage',
  'indexedDB.',
]) {
  if (production.includes(forbidden)) throw new Error(`P13.12R1 production ownership regression: ${forbidden}`);
}

console.log('PASS P13.12R1 async Settings test-contract verifier');
