# KAIROS P34.2 — Profile Data Safety

**Patch label:** P34.2 · P34 Profile data safety: backup freshness and persistent storage · owner phase P34 (active from the Gate524 canonical PASS) · definition: the Profile device card extended with the last-backup moment, the storage-durability state and the persistent-storage request, proven in unit tests and a real browser.

## Authority
Base: canonical Gate525 (P34.1 last-backup record). Autonomous continuation under the user's 18 September 2026 rule.

## Research settled before implementation
- `src/pwa/storageDurability.ts` already publishes a subscribable status and owns the request, so the card subscribes and asks through ports whose stable default is the released owner; nothing about persistence is decided in the route.
- The browser's answer to a persistence request is not Kairos's to promise, so the card reports the answer as given (persistent, or declined with a plain-word note) and never claims durability the browser did not grant.
- The last backup is recorded only after the hand-off succeeded, through the P34.1 command over the same metadata repository the activation receipt already uses.

## Result
The This device card shows the last backup (or never) and the storage-durability state, offers Keep my data on this device on a best-effort browser and reports the outcome. The P28.3 receipts literal and the P34.1 pin advanced; nothing was relaxed. Details: `docs/KAIROS_PROFILE_DATA_SAFETY.md`. UI VISIBLE:YES.

## Ownership
P34.2 owns only the card extension and its ports. P34.1 keeps the record, the storage-durability owner its inspection and request, P28 the page, P5 the metadata store.

## Non-scope
No reminder policy; no eviction handling; no change to export, restore or import.

## Next dependency boundary
P34.3 closes the phase: ledger closure, roadmap update and the whole-phase verifier.

## Canonical requirement
This extension becomes authoritative only after the exact P34.2 candidate receives a full `Kairos Controlled Roadmap Gate` PASS with both canonical artifacts and main carries the same commit with its own canonical PASS. P34.3 may not begin before that PASS.
