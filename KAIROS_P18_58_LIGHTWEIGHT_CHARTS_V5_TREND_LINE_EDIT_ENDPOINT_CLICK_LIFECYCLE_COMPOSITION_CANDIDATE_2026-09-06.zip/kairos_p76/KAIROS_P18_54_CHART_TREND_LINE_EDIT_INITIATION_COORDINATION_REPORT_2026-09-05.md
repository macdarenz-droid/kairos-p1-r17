# KAIROS P18.54 — Chart Trend-Line Edit Initiation Coordination

Date: 2026-09-05  
Authoritative base: **P18.53 — Chart Drawing Deletion Initiation Coordination**  
Canonical base evidence: **Kairos Controlled Roadmap Gate #264 / run 33967407409 / head 923f28071ddfe1157c5a0c755b65078fe60ce3d4 — SUCCESS**  
Canonical base candidate artifact: **KAIROS_CURRENT_CANDIDATE artifact 9969983695**

## Source-derived missing seam

Canonical P18.53 source establishes the downstream edit path but still has no production initiation coordinator:

- P18.48 owns the exact trend-line edit endpoint vocabulary: `start | end`.
- P18.49R1 extends the existing interaction event/state/reducer owners so `start-editing` carries one drawing ID plus one exact endpoint and is accepted only for the matching selected identity.
- P18.24 remains the sole active interaction-state/dispatch owner.
- P18.50 executes an edit only from an already-authoritative `editing` state.
- P18.51R3 composes a successful P18.50 edit into P18.47 drawing-only presentation refresh.

Fresh canonical source search found no production coordinator that reads the authoritative selected drawing identity and initiates the existing `start-editing` transition while allowing the caller to provide only endpoint evidence. Leaving that seam to a future provider/UI edge would duplicate selected-identity lookup and permit arbitrary execution-time drawing identity to leak into edit initiation.

## P18.54 responsibility

P18.54 adds one provider-neutral initiation seam:

`initiateChartTrendLineEditFromSelection(interaction, endpoint)`

Behavior:
1. read one current authoritative interaction snapshot;
2. proceed only when that state is `selected`;
3. accept only the existing typed P18.48 `ChartTrendLineEditEndpoint` as caller evidence;
4. dispatch the existing `start-editing` event with exactly `selected.drawingId` plus that endpoint;
5. return the resulting state only when the authoritative interaction owner confirms `editing` for the same identity and endpoint;
6. otherwise fail closed to `null`.

The public function accepts **no drawing ID argument**.

## Ownership preservation

- P18.21 remains interaction-state shape owner.
- P18.22 remains event vocabulary owner.
- P18.23/P18.38/P18.49R1 remain sole transition-acceptance/editing-state owners.
- P18.24 remains sole active interaction state/dispatch owner.
- P18.48 remains sole edit-endpoint vocabulary and pure edit-construction owner.
- P18.50 remains sole edit-execution coordinator.
- P18.51R3 remains sole edit-to-presentation composition owner.
- P18.54 owns only selected-state + typed endpoint -> edit-intent coordination.

## Explicit non-scope

No endpoint/handle hit-test ownership; no provider click/pointer/drag subscription; no provider coordinate conversion; no edit execution; no collection read/write; no presentation refresh; no new interaction state/event; no deletion changes; no persistence/restore; no undo/redo; no toolbar/UI styling; no new drawing kinds; no Risk/Reward/P19; no journal/calculation/navigation truth; no toolchain migration.

## Focused runtime evidence

The focused P18.54 test proves:
- exact authoritative selected identity and requested endpoint enter editing;
- both existing P18.48 endpoint values are preserved without redefining the vocabulary;
- idle/deleting and other non-selected states do not initiate editing;
- no caller-supplied drawing identity exists in the public API and selected identity is read/forwarded exactly once;
- a rejecting or endpoint-changing interaction owner fails closed to `null`.

## Canonical promotion requirement

Promotion requires exact P18.53 -> P18.54 scope, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.54 verifier/runtime, focused P18.54 tests, historical P18.53/P18.51R3/P18.50/P18.49R1/P18.48/P18.24 compatibility, full units, full controlled roadmap regression through P18.54, P18.54 -> P17 chart regressions, historical closures, candidate artifact, and gate evidence.

## Local/static evidence actually completed

PASS:
- dedicated P18.54 verifier;
- historical P18.53, P18.51R3, P18.50, P18.49R1, P18.48, and P18.24 verifier contracts;
- all P18 verifier contracts through P18.54: **54/54**;
- all other non-P1-wrapper roadmap verifier contracts: **152/152**;
- P1 static contract: **214 source files / 17 pinned package versions**;
- P1 toolchain proof: Node 22.16.0 / npm 10.9.2.

The full P1 wrapper reached its clean dependency-install stage and timed out locally. A separate clean dependency-backed attempt for `npm ci` -> TypeScript -> production build -> focused Vitest also ended in a container transport timeout before a usable completion result was returned. Any partial dependency/build residue was removed and is not treated as evidence. Therefore local dependency install, TypeScript, build, focused Vitest, and full P1 are **not claimed** for P18.54; canonical GitHub Actions must establish them before promotion.
