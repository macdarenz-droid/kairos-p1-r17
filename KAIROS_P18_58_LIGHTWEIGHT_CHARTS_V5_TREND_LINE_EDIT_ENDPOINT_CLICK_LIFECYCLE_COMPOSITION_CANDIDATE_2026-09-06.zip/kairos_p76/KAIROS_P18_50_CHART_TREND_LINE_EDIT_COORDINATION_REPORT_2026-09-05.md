# KAIROS P18.50 — Chart Trend-Line Edit Coordination

## Authority
Built directly from canonical P18.49R1, Kairos Controlled Roadmap Gate #257 / run `33961026207` / head `52a76811052ff2bd55ebf1e2aa59f71aae97b1af`.

Failed P18.49 run #256 remains evidence only and is not a base.

## Source-derived gap
Canonical P18.49R1 establishes authoritative `editing` state with both drawing identity and exact P18.48 `start | end` endpoint. Canonical source also already contains:
- P18.48 pure identity-preserving trend-line edit construction;
- P18.33/P18.44 sole committed collection replace owner;
- P18.23/P18.24 sole interaction transition/current-state owner.

No production module composes those owners into one edit execution boundary. Without a coordinator, later provider gesture code would have to duplicate collection lookup, endpoint consumption, construction, replacement, and reset ordering.

## P18.50 responsibility
Add one provider-neutral `executeChartTrendLineEdit(...)` coordination seam that:
1. reads the current authoritative P18.24 interaction state;
2. proceeds only when state is `editing`;
3. reads exactly the committed drawing named by that state;
4. fails closed with `null` if that committed identity is stale;
5. delegates edit construction to P18.48 using the endpoint stored in authoritative state and the caller-supplied replacement market anchor;
6. delegates identity-preserving commit to P18.33/P18.44 `replaceDrawing`;
7. dispatches the existing `reset-interaction` event only after committed replacement succeeds;
8. requires resulting interaction state to be `idle`, otherwise throws `chart-trend-line-edit-reset-rejected`;
9. returns the committed edited trend line.

The execution API intentionally accepts no drawing ID and no endpoint argument. Those facts come only from authoritative editing state.

## Ownership preserved
- P18.21 owns interaction-state shape.
- P18.22 owns interaction-event vocabulary.
- P18.23 owns transition semantics.
- P18.24 owns active interaction state/dispatch.
- P18.48 owns edit endpoint vocabulary and pure edited trend-line construction.
- P18.33/P18.44 own committed collection truth and replace mutation.
- P18.50 owns only composition/order across those existing owners.

## Explicit non-scope
No edit initiation; no provider pointer/mouse/drag subscription; no provider coordinate conversion; no hit testing; no new interaction state/event; no collection owner change; no presentation refresh; no hover renewal; no deletion change; no persistence/restore; no undo/redo; no toolbar/UI styling; no new drawing kinds; no Risk/Reward/P19; no journal/calculation/navigation truth; no dependency/toolchain migration.

## Canonical requirement
Before promotion, the canonical gate must prove exact P18.49R1 -> P18.50 scope, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.50 verifier/runtime, historical P18.48/P18.49R1/P18.44/P18.24 compatibility, focused runtime tests, full units, full roadmap through P18.50, P18.50 -> P17 regressions, historical closures, candidate artifact, and gate evidence.

## Local verification
PASS:
- dedicated P18.50 edit-coordination verifier;
- historical P18.49R1 edit-endpoint interaction semantics repair verifier;
- historical P18.48 edit-construction verifier;
- historical P18.44 collection-mutation verifier;
- historical P18.21/P18.22/P18.23/P18.24 interaction owner verifiers;
- all `verify:p18:*` scripts through P18.50: 50/50;
- all other `verify:p*` scripts except dependency-backed `verify:p1`: 152/152;
- 202/202 non-P1-wrapper roadmap verifier contracts overall;
- P1 static/toolchain contract: 210 source files, 17 pinned package versions.

Local dependency limitation:
- a clean `npm ci --no-audit --no-fund` attempt exceeded the local container transport window;
- any partial dependency/build/cache residue was removed before packaging;
- therefore local production TypeScript/build/Vitest/full-unit/dependency-backed P1 PASS are not claimed. Canonical GitHub Actions must establish them.
