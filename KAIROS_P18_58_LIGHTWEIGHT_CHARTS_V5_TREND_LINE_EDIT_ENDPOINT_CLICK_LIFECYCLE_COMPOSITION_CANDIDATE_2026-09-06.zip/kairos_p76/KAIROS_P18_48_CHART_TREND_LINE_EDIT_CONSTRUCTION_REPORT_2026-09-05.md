# KAIROS P18.48 — Chart Trend-Line Edit Construction

## Authority
Built directly from canonical P18.47, Kairos Controlled Roadmap Gate #254 / run `33957917429` / head `559c78051a4e71049bc85964e8b5c67b2b10b43c`.

## Proven missing responsibility
Canonical P18.38 already establishes authoritative `editing` interaction state, and canonical P18.44 already gives the sole P18.33 committed collection owner strict identity-preserving replacement. Canonical source still had no provider-neutral boundary that can construct the replacement committed trend-line truth itself from an existing committed trend line, an explicit endpoint, and one replacement anchor. Without that constructor, later edit coordination would either mutate drawing truth ad hoc or duplicate committed-shape construction inside gesture/collection orchestration.

## Added responsibility
P18.48 adds one pure provider-neutral trend-line edit-construction boundary:

- `ChartTrendLineEditEndpoint` is exactly `'start' | 'end'`;
- `constructChartTrendLineEdit(drawing, endpoint, anchor)` preserves the existing drawing ID and `trend-line` kind;
- editing `start` replaces exactly the start anchor and preserves the previous end anchor;
- editing `end` replaces exactly the end anchor and preserves the previous start anchor;
- returned anchors are detached snapshots so caller-owned committed/evidence objects are not mutated or reused as mutable construction storage;
- an unsupported runtime endpoint fails closed with `chart-trend-line-edit-endpoint-unsupported` instead of guessing a target.

## Ownership preserved
- P18.1 remains the committed drawing-truth shape owner.
- P18.25 remains provider event/coordinate -> neutral anchor projection owner.
- P18.23/P18.24/P18.38 remain editing transition/current-state owners.
- P18.33/P18.44 remain the sole committed collection/mutation owner.
- P18.46/P18.47 remain drawing-only presentation refresh owners/coordinators.
- P18.48 constructs one candidate edited drawing only; it stores or commits nothing.

## Research disposition
No external API research was required. This slice is provider-neutral pure construction over already-canonical Kairos contracts and introduces no new Lightweight Charts API surface.

## Explicit non-scope
No provider pointer/drag subscription; no hit testing; no edit initiation; no interaction event/reducer/dispatch change; no collection replacement; no presentation refresh; no deletion execution; no persistence/restore; no undo/redo; no toolbar/UI styling; no new drawing kinds; no Risk/Reward/P19; no journal/calculation/navigation truth; no dependency/toolchain migration.

## Canonical requirement
Before promotion, the controlled roadmap gate must prove exact scope from canonical P18.47, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.48 runtime/verifier, historical P18.1/P18.38/P18.44 compatibility, focused runtime tests, full units, full roadmap through P18.48, P18.48->P17 regressions, historical closures, candidate artifact, and gate evidence.

## Local verification
PASS:
- dedicated P18.48 verifier;
- historical P18.1 drawing contract verifier;
- historical P18.38 selection/editing interaction semantics verifier;
- historical P18.44 collection mutation verifier;
- historical P18.47 collection-presentation refresh coordination verifier;
- all `verify:p18:*` scripts through P18.48 (48/48);
- all other `verify:p*` scripts except the clean-install `verify:p1` wrapper (152/152), for 200/200 non-P1-wrapper roadmap verifier contracts overall;
- P1 static/toolchain contract: 209 source files, 17 pinned package versions.

Local limitation:
- the dependency-backed `verify:p1` wrapper reached clean `npm ci` and exceeded the local execution window, so local TypeScript, production build, Vitest/full-unit, and dependency-backed P1 PASS are not claimed. Canonical GitHub Actions must establish them before promotion.
