# KAIROS P18.46 — Chart Drawing Presentation Drawing-Only Refresh

## Authority
Built directly from canonical P18.45, Kairos Controlled Roadmap Gate #252 / run 33955449400 / head `1171b3d0aa514866eb905ff2cca1be4183d128a6`.

## Proven missing responsibility
Canonical P18.45 can now remove committed drawing truth through the existing P18.33/P18.44 collection owner, but canonical P18.37 still refreshes collection presentation by calling P18.11 `replace(series, drawings)`. Canonical P18.11 intentionally clears/recreates the active market series on that path. The controlling architecture handoff explicitly warns not to use full series replacement after every drawing mutation. In addition, P18.15/P18.18 hover observation is scoped to an immutable renderer drawing snapshot for each hover-session lifetime, so a drawing-only refresh must renew hover snapshot evidence as well as the drawing layer.

## Added responsibility
P18.46 adds one controlled extension inside the existing P18.11/P18.20 presentation owner:

- sessions created by `ChartDrawingPresentationPort` expose `replaceDrawings(drawings)` in an extended session contract while the original `ChartDrawingPresentationSession` remains valid for existing callers;
- drawing-only refresh requires an already-active series/drawing-layer presentation;
- it reuses the exact active market series and exact attached drawing-layer session;
- it sends the new renderer drawing snapshot through the existing P18.3 drawing-layer `replaceDrawings()` lifecycle;
- when hover integration is enabled, it attaches one fresh hover session against the new immutable drawing snapshot, then retires the previous hover session;
- if new hover attachment fails, it rolls the drawing layer back to the previous renderer snapshot while the previous hover session remains authoritative;
- if that rollback itself fails, it clears the active presentation resources rather than leaving a knowingly mixed drawing/hover snapshot;
- refresh before initial full presentation fails closed with `chart-drawing-presentation-inactive`;
- refresh after destroy continues to fail with the existing `chart-drawing-presentation-destroyed` contract.

## Ownership preserved
- P18.11 remains the sole series/drawing presentation resource-order owner; P18.46 extends that same module rather than creating another presentation port.
- P18.20 remains hover-to-presentation integration ownership; P18.46 renews the hover session through the existing P18.18 port without implementing provider subscription APIs.
- P18.3 remains the drawing-layer lifecycle owner; P18.46 calls its existing `replaceDrawings()` method only.
- P18.15 remains the sole provider crosshair subscribe/unsubscribe owner.
- P18.33/P18.44 remain committed drawing truth/mutation owners.
- P18.36 remains drawing collection -> renderer projection owner.
- P18.45 remains deletion execution coordination.

## Research disposition
No external API research was required. This slice changes only provider-neutral Kairos presentation coordination and uses existing proven P18 lifecycle contracts. No new Lightweight Charts API surface is introduced.

## Explicit non-scope
No committed drawing mutation; no deletion execution; no edit construction/gesture; no interaction reducer/event/state change; no provider subscribe/unsubscribe implementation; no series creation/removal on successful drawing-only refresh; no persistence/restore; no undo/redo; no toolbar/UI styling; no new drawing kinds; no Risk/Reward/P19; no journal/calculation/navigation ownership; no dependency/toolchain migration.

## Canonical requirement
Before promotion, the controlled roadmap gate must prove exact scope from canonical P18.45, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.46 runtime/verifier, historical P18.11/P18.20 compatibility, full units, full roadmap through P18.46, P18.46->P17 regressions, historical closures, candidate artifact, and gate evidence.

## Local verification
PASS:
- dedicated P18.46 verifier;
- historical P18.11 presentation coordination verifier;
- historical P18.20 hover-presentation integration verifier;
- all `verify:p18:*` scripts through P18.46 (46/46);
- all other `verify:p*` scripts except the clean-install `verify:p1` wrapper (152/152), for 198/198 non-P1-wrapper roadmap verifier contracts overall;
- P1 static/toolchain contract: 208 source files, 17 pinned package versions.

Local limitation:
- clean `npm ci` again exceeded the local execution window, so local TypeScript, production build, Vitest/full-unit, and the full dependency-backed P1 gate are not claimed. Canonical GitHub Actions must establish them before promotion.
