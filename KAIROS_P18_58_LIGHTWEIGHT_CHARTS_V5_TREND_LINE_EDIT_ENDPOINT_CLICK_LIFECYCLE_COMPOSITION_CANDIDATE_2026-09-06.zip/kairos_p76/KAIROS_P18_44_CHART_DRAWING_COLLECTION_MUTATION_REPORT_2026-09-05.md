# KAIROS P18.44 — Chart Drawing Collection Mutation

## Authority
Built directly from canonical P18.43, Kairos Controlled Roadmap Gate #250 / run 33953629222 / head `9cc2e002d4c421541f260967c4e4b50f8123d474`.

## Proven missing responsibility
Canonical P18.43 projects authoritative selected/editing/deleting interaction state into current renderer selection-presentation evidence. The sole committed in-memory drawing-set owner remains P18.33 `chartDrawingCollection.ts`, but canonical source only supports add/read and explicitly stops before edit/delete mutation. Starting edit/delete execution without first extending that same owner would force a later coordinator to mutate committed drawing truth outside P18.33's collection boundary, creating a second committed-set mutation owner.

## Added responsibility
P18.44 extends the existing P18.33 committed collection owner with strict provider-neutral mutation operations:

- `replaceDrawing(drawingId, drawing)` replaces only an existing drawing;
- replacement requires `drawing.id === drawingId`, so identity cannot be silently changed;
- replacement preserves Map insertion order;
- `removeDrawing(drawingId)` removes exactly one existing drawing;
- missing replacement/removal identity fails closed with `chart-drawing-collection-missing-id`;
- identity mismatch fails closed with `chart-drawing-collection-identity-mismatch`;
- destroyed sessions reject both operations through the existing P18.33 lifecycle guard.

## Ownership preserved
- P18.1 remains committed drawing-shape truth.
- P18.23 remains sole interaction transition semantics.
- P18.24 remains sole active interaction state/dispatch owner.
- P18.33 remains the sole committed in-memory drawing-set owner; P18.44 is a controlled owner extension inside that same module, not a second collection.
- P18.36 remains collection -> renderer projection.
- P18.37 remains collection -> presentation coordination.
- P18.43 remains interaction state + current renderer snapshot -> selection-presentation projection.

The P18.33 historical verifier is amended only to stop forbidding `Map.delete()` now that deletion is an explicit controlled extension of the same owner. Its original add/read/duplicate/destroy guarantees remain pinned and continue to run.

## Research disposition
No external API research was required. This slice is provider-neutral and changes no library/provider behavior.

## Explicit non-scope
No edit gesture or edit construction; no delete interaction coordinator; no reducer/event changes; no interaction dispatch; no selection logic; no presentation refresh; no renderer/provider API; no click/hover lifecycle; no persistence/restore; no undo/redo; no toolbar/UI; no new drawing kinds; no Risk/Reward/P19; no journal/calculation/navigation ownership; no dependency/toolchain migration.

## Canonical requirement
Before promotion, the controlled roadmap gate must prove exact scope from canonical P18.43, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.44 runtime/verifier, full units, full roadmap through P18.44, P18.44->P17 regressions, historical closures, candidate artifact, and gate evidence.

## Local verification
PASS:
- dedicated P18.44 verifier;
- P18.33 historical collection verifier after controlled compatibility amendment;
- all `verify:p18:*` scripts through P18.44 (44/44);
- all `verify:p*` scripts except the clean-install `verify:p1` wrapper (196/196);
- P1 toolchain/static contract: Node 22.16.0, npm 10.9.2, 207 source files, 17 pinned package versions.

Local limitation:
- clean `npm ci` again exceeded the local execution window, so local TypeScript, production build, Vitest/full-unit, and the full dependency-backed P1 gate are not claimed. Canonical GitHub Actions must establish them before promotion.
