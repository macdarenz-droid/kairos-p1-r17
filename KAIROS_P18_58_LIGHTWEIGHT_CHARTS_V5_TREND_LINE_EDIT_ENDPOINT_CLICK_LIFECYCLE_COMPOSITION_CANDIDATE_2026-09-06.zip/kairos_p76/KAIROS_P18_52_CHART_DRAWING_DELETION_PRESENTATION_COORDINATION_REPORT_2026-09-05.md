# KAIROS P18.52 — Chart Drawing Deletion Presentation Coordination

Date: 2026-09-05  
Authoritative base: **P18.51R3 — Chart Trend-Line Edit Presentation Coordination Runtime Projection Expectation Repair**  
Canonical base evidence: **Kairos Controlled Roadmap Gate #262 / run 33964759458 / head bddb699d81b423f2e98cb604f22c6c80d33709ba — SUCCESS**  
Canonical base candidate artifact: **KAIROS_CURRENT_CANDIDATE artifact 9969170741**  
Failed evidence only: **P18.51 gate #259 / P18.51R1 #260 / P18.51R2 #261**

## Source-derived missing seam

Canonical P18.51R3 source establishes all required owners individually:

- P18.45 `executeChartDrawingDeletion(...)` consumes already-authoritative `deleting` interaction state, removes exactly that committed drawing through P18.33/P18.44, then resets interaction only after successful committed removal.
- P18.47 `refreshChartDrawingPresentationFromCollection(...)` reads current committed collection truth, delegates domain -> renderer projection to P18.36, then delegates drawing-only refresh to P18.46.
- P18.51R3 already proves the matching edit-side composition rule: committed mutation first, presentation refresh second, with no rollback of authoritative truth when presentation refresh fails.

Fresh canonical source search found no production module composing P18.45 deletion execution with P18.47 drawing-only presentation refresh. Therefore deletion remained the committed mutation path that could complete authoritatively while leaving the active drawing presentation stale until some unrelated refresh occurred.

## P18.52 responsibility

P18.52 adds exactly one provider-neutral composition seam:

`executeChartDrawingDeletionAndRefreshPresentation(interaction, collection, presentation)`

Behavior:
1. delegate authoritative deletion execution to P18.45;
2. if P18.45 returns `null`, return `null` and do not refresh presentation;
3. after a real committed deletion, refresh exactly once through P18.47 from the current committed collection snapshot;
4. return the deleted drawing evidence;
5. if presentation refresh throws after commit, propagate the presentation error without rolling back committed drawing truth or the already-completed interaction reset.

## Ownership preservation

- P18.21/P18.22/P18.23/P18.24/P18.38 remain interaction owners.
- P18.33/P18.44 remain committed collection/mutation owners.
- P18.45 remains sole deletion-execution coordinator.
- P18.36 remains sole drawing-domain -> renderer projection owner.
- P18.46 remains drawing-refresh presentation-session owner.
- P18.37/P18.47 remain collection-to-presentation coordination owners.
- P18.51R3 remains edit-to-presentation composition owner.
- P18.52 owns only successful-deletion-to-presentation composition.

## Failure/reconciliation semantics

Committed collection truth remains authoritative. Presentation refresh is downstream presentation work.

Therefore P18.52 intentionally does **not** attempt a compensating re-add when presentation refresh fails. Such rollback would make a presentation failure capable of rewriting authoritative committed state and could itself fail or conflict with interaction state. Instead the refresh error propagates so a higher presentation/reconciliation boundary can retry rendering from the current committed collection truth.

## Explicit non-scope

No deletion initiation; no drawing-ID parameter; no edit behavior change; no pointer/mouse/drag subscription; no provider coordinate conversion; no hit testing; no new interaction state/event; no direct collection mutation; no new renderer projection owner; no presentation resource lifecycle implementation; no persistence/restore; no undo/redo; no toolbar/UI styling; no new drawing kinds; no Risk/Reward/P19; no journal/calculation/navigation truth; no dependency/toolchain migration.

## Focused runtime evidence

The focused P18.52 test proves:
- exactly one drawing-only presentation refresh after successful authoritative deletion;
- the presentation boundary receives the correct P18.36 renderer projection of the remaining committed drawing (`{time, value}`), while committed truth remains domain-shaped;
- selected/non-deleting state does not initiate deletion or refresh;
- stale authoritative deleting identity fails closed with no refresh;
- presentation failure after committed deletion never restores deleted authoritative truth and leaves interaction idle.

## Canonical promotion requirement

Promotion requires exact P18.51R3 -> P18.52 scope, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.52 verifier/runtime, focused P18.52 tests, historical P18.51R3/P18.47/P18.45/P18.44/P18.24 compatibility, full units, full controlled roadmap regression through P18.52, P18.52 -> P17 chart regressions, historical closures, candidate artifact, and gate evidence.

## Local/static evidence actually completed

PASS:
- dedicated P18.52 verifier;
- historical P18.51R3, P18.47, P18.45, P18.44, and P18.24 verifier contracts;
- all P18 verifier contracts through P18.52: **52/52**;
- all other non-P1-wrapper roadmap verifier contracts: **152/152**;
- P1 static contract: **212 source files / 17 pinned package versions**.

A clean local dependency-backed attempt again exceeded the container transport window before a usable completion result was returned. Any partial dependency/build residue was removed and is not treated as evidence. Therefore local TypeScript/build/Vitest are **not claimed** for P18.52. Canonical GitHub Actions must prove the dependency-backed runtime and full regression chain before promotion.
