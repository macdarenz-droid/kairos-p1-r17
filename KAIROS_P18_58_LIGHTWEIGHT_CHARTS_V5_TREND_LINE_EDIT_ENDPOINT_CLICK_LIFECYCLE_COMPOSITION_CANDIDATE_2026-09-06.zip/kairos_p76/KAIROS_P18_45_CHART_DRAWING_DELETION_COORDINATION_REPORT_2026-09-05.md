# KAIROS P18.45 — Chart Drawing Deletion Coordination

## Authority
Built directly from canonical P18.44, Kairos Controlled Roadmap Gate #251 / run 33954549994 / head `426949aa46aff86e4871a87363b50ef7169f3e2b`.

## Proven missing responsibility
Canonical P18.38 already owns the provider-neutral selected/editing/deleting interaction semantics, and canonical P18.44 extends the sole P18.33 committed drawing collection owner with strict identity-preserving removal. Canonical source still had no boundary that consumes an already-authoritative `deleting` interaction state, verifies the same committed identity still exists, delegates exactly one removal to the existing collection owner, and clears interaction state only after successful removal.

## Added responsibility
P18.45 adds one provider-neutral deletion-execution coordinator:

- accepts the existing P18.24 interaction session and P18.33/P18.44 committed collection session;
- proceeds only when authoritative interaction state is already `deleting`;
- validates the exact `drawingId` still exists in the committed collection;
- delegates the actual mutation to P18.44 `removeDrawing()`;
- dispatches only the existing `reset-interaction` event after successful removal;
- returns the removed committed drawing as confirmed deletion evidence;
- non-deleting state or stale identity fails closed with `null` and no collection mutation.

## Ownership preserved
- P18.23 remains the sole transition-semantics owner.
- P18.24 remains the sole active interaction state/dispatch owner.
- P18.38 remains deletion-initiation semantics through the existing `start-deleting` event; P18.45 does not dispatch that event.
- P18.33/P18.44 remain the sole committed drawing-set/mutation owner; P18.45 calls `removeDrawing()` and stores no collection truth.
- P18.36 remains collection -> renderer projection.
- P18.37 remains collection -> presentation coordination.
- P18.43 remains interaction-state -> selection-presentation evidence projection.

## Research disposition
No external API research was required. This slice is provider-neutral and changes no Lightweight Charts or browser API behavior.

## Explicit non-scope
No deletion initiation; no reducer/event/state-shape amendment; no presentation refresh; no renderer/provider API; no click/hover lifecycle; no edit gesture/construction; no persistence/restore; no undo/redo; no toolbar/UI; no new drawing kinds; no Risk/Reward/P19; no journal/calculation/navigation ownership; no dependency/toolchain migration.

## Canonical requirement
Before promotion, the controlled roadmap gate must prove exact scope from canonical P18.44, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.45 runtime/verifier, full units, full roadmap through P18.45, P18.45->P17 regressions, historical closures, candidate artifact, and gate evidence.

## Local verification
PASS:
- dedicated P18.45 verifier;
- all `verify:p18:*` scripts through P18.45 (45/45);
- all other `verify:p*` scripts except the clean-install `verify:p1` wrapper (152/152), for 197/197 non-P1-wrapper roadmap verifier contracts overall;
- P1 static/toolchain contract: 208 source files, 17 pinned package versions.

Local limitation:
- clean `npm ci` again exceeded the local execution window, so local TypeScript, production build, Vitest/full-unit, and the full dependency-backed P1 gate are not claimed. Canonical GitHub Actions must establish them before promotion.
