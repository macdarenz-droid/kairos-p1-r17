# KAIROS P18.57 — Lightweight Charts v5 Trend-Line Edit Endpoint-Click Coordination

Date: 2026-09-05  
Authoritative base: **P18.56 — Chart Trend-Line Edit Endpoint-Hit Coordination**  
Canonical base evidence: **Kairos Controlled Roadmap Gate #267 / run 33970666322 / head a2e3ec2d5a2b03c09a671654f9d606553b152a68 — SUCCESS**  
Canonical base candidate artifact: **KAIROS_CURRENT_CANDIDATE artifact 9970902845**

## Source-derived missing seam

Canonical P18.26/P18.40 already exposes the exact raw provider click event through the existing single `subscribeClick` lifecycle. That event already contains optional screen `point` evidence. Canonical P18.55 owns endpoint geometry from already-projected P18.5 trend-line screen segments. Canonical P18.56 owns endpoint-hit identity -> authoritative selected drawing edit initiation.

Fresh canonical P18.56 source search found no production coordinator composing one raw provider click point with the current projected segment snapshot through P18.55 and then P18.56. P18.57 closes only that coordination gap.

No new Lightweight Charts API behavior is introduced or assumed. This slice consumes the existing raw click evidence type and already-projected screen segments, so no provider capability expansion or external API research is required.

## P18.57 responsibility

P18.57 adds:

`coordinateLightweightChartsV5TrendLineEditEndpointClick(interaction, segments, event, tolerancePx)`

Behavior:
1. accept an existing P18.24 interaction session surface, current P18.5 projected trend-line segment snapshot, existing P18.26/P18.40 raw click event, and presentation tolerance;
2. missing provider `point` evidence is a strict no-op;
3. delegate present point coordinates and tolerance to P18.55 `hitTestLightweightChartsV5TrendLineEditEndpoints`;
4. preserve P18.55 top-most, ambiguity, and invalid-input semantics unchanged;
5. delegate the resulting endpoint hit (including `null`) to P18.56 `coordinateChartTrendLineEditEndpointHit`;
6. return P18.56's authoritative edit-initiation state or `null` unchanged.

## Ownership preservation

- P18.26 remains sole `subscribeClick`/`unsubscribeClick` owner.
- P18.40 remains raw provider-click evidence fan-out owner.
- P18.5 remains sole renderer logical coordinates -> provider screen segment projection owner.
- P18.55 remains sole endpoint hit-test geometry/evidence owner.
- P18.56 remains sole endpoint-hit drawing identity -> authoritative selected identity coordination owner.
- P18.54 remains sole selected-state + endpoint -> `start-editing` initiation owner.
- P18.57 owns only raw click point + already-projected segment evidence -> P18.55 -> P18.56 composition.

## Explicit non-scope

No provider subscription lifecycle; no provider chart/series resolution; no provider time/price coordinate capability expansion; no screen-segment projection; no direct interaction dispatch/event ownership; no edit execution; no committed collection mutation; no presentation refresh; no drag lifecycle; no handle rendering/style/UI; no persistence/restore; no undo/redo; no deletion changes; no new drawing kind; no Risk/Reward/P19; no journal/calculation/navigation truth; no toolchain migration.

## Focused runtime evidence

The focused P18.57 test proves:
- a raw provider click on the selected drawing endpoint routes through P18.55/P18.56 into exact edit initiation;
- missing raw click point evidence is a no-op;
- a line-body click is not converted into endpoint edit intent;
- an endpoint click for another drawing cannot be applied to the authoritative selected drawing;
- present invalid point/tolerance evidence preserves P18.55's existing invalid-input ownership rather than duplicating validation semantics.

## Canonical promotion requirement

Promotion requires exact P18.56 -> P18.57 scope, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.57 verifier/runtime, focused P18.57 tests, historical P18.56/P18.55/P18.54/P18.40/P18.26 compatibility, full units, full controlled roadmap regression through P18.57, P18.57 -> P17 chart regressions, historical closures, candidate artifact, and gate evidence.

## Local/static evidence actually completed

PASS:
- dedicated P18.57 verifier;
- historical P18.56/P18.55/P18.54/P18.40/P18.26 ownership verifier contracts;
- all P18 verifier contracts through P18.57: **57/57**;
- all other non-P1-wrapper roadmap verifier contracts: **152/152**;
- P1 static contract: **PASS** over **216 source files / 17 pinned package versions**;
- exact P18.56 -> P18.57 seven-file scope;
- clean package root / generated-residue hygiene;
- fresh-extracted dedicated verifier and P1 static contract before handoff.

A clean dependency-backed `npm ci -> typecheck -> build -> focused Vitest` attempt was made, but the container transport timed out during `npm ci` before usable dependency-backed evidence existed. Therefore local dependency install, TypeScript, production build, focused Vitest, full unit regression, and full P1 are **not claimed** for P18.57. Canonical GitHub CI must establish them before promotion.
