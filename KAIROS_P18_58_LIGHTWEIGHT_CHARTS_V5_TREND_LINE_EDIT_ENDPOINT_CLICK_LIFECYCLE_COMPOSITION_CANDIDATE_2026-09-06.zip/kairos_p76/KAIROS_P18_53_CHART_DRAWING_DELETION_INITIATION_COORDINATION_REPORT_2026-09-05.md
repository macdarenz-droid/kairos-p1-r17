# KAIROS P18.53 — Chart Drawing Deletion Initiation Coordination

Date: 2026-09-05  
Authoritative base: **P18.52 — Chart Drawing Deletion Presentation Coordination**  
Canonical base evidence: **Kairos Controlled Roadmap Gate #263 / run 33966025163 / head f7a45a99d420cb27ea97aebc53ddfec437045075 — SUCCESS**  
Canonical base candidate artifact: **KAIROS_CURRENT_CANDIDATE artifact 9969558372**

## Source-derived missing seam

Canonical P18.52 source establishes the downstream deletion path but still requires an already-authoritative `deleting` interaction state:

- P18.38/P18.23 already define `start-deleting` as a valid transition only from the matching `selected` drawing identity.
- P18.24 remains the sole active interaction-state/dispatch owner.
- P18.45 executes deletion only from an already-authoritative `deleting` state.
- P18.52 composes a successful P18.45 deletion into P18.47 drawing-only presentation refresh.

Fresh canonical source search found no production coordinator that reads the authoritative selected identity and initiates the existing `start-deleting` transition without accepting a caller-supplied drawing ID. Leaving that gap to a future toolbar/provider caller would duplicate identity-selection logic at the edge and allow arbitrary execution-time identity to leak into deletion initiation.

## P18.53 responsibility

P18.53 adds one provider-neutral initiation seam:

`initiateChartDrawingDeletionFromSelection(interaction)`

Behavior:
1. read one current authoritative interaction snapshot;
2. proceed only when that state is `selected`;
3. dispatch the existing `start-deleting` event with exactly `selected.drawingId`;
4. return the resulting state only when the authoritative interaction owner confirms `deleting` for that same identity;
5. otherwise fail closed to `null`.

The public function accepts **no drawing ID argument**.

## Ownership preservation

- P18.21 remains interaction-state shape owner.
- P18.22 remains event vocabulary owner.
- P18.23/P18.38 remain sole transition-acceptance owners.
- P18.24 remains sole active interaction state/dispatch owner.
- P18.45 remains sole deletion-execution coordinator.
- P18.52 remains sole deletion-to-presentation composition owner.
- P18.53 owns only selected-state -> deletion-intent coordination.

## Explicit non-scope

No deletion execution; no presentation refresh; no collection read/write; no provider click/pointer/drag subscription; no coordinate conversion; no hit testing; no edit initiation; no new interaction state/event; no persistence/restore; no undo/redo; no toolbar/UI styling; no new drawing kinds; no Risk/Reward/P19; no journal/calculation/navigation truth; no toolchain migration.

## Focused runtime evidence

The focused P18.53 test proves:
- selected authoritative identity is forwarded exactly once into `start-deleting`;
- idle/editing and other non-selected states do not initiate deletion;
- no caller-supplied drawing identity exists in the public API;
- a rejecting interaction owner fails closed to `null`.

## Canonical promotion requirement

Promotion requires exact P18.52 -> P18.53 scope, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.53 verifier/runtime, focused P18.53 tests, historical P18.52/P18.45/P18.38/P18.24 compatibility, full units, full controlled roadmap regression through P18.53, P18.53 -> P17 chart regressions, historical closures, candidate artifact, and gate evidence.

## Local/static evidence actually completed

PASS:
- dedicated P18.53 verifier;
- historical P18.52, P18.45, P18.38, and P18.24 verifier contracts as part of the full P18 sweep;
- all P18 verifier contracts through P18.53: **53/53**;
- all other non-P1-wrapper roadmap verifier contracts: **152/152**;
- P1 static contract: **213 source files / 17 pinned package versions**.

A clean local dependency-backed attempt again ended in a container transport timeout before a usable completion result was returned. Any partial dependency/build residue was removed and is not treated as evidence. Therefore local TypeScript/build/Vitest are **not claimed** for P18.53; canonical GitHub Actions must establish those before promotion.
