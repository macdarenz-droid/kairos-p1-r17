# Kairos P18.34 — Chart Drawing Identity

## Authority
Built from canonical P18.33 authority (Kairos Controlled Roadmap Gate #239, run 33899960984, head 956fb6da8b8ad2627fa1ef8cb5a533feb6848493).

## Proven missing responsibility
P18.32 requires a caller-supplied `ChartDrawingId` before it can commit a completed trend-line draft. P18.33 rejects duplicate committed drawing IDs. Canonical P18.33 contains no chart drawing identity allocator; the only existing UUID owner is trade-domain-specific and must not be reused as chart-domain ownership.

## Added responsibility
P18.34 introduces one chart-specific fresh identity owner:

1. `createChartDrawingId()` allocates a fresh P18.1 `ChartDrawingId`.
2. Allocation uses the same platform `crypto.randomUUID()` mechanism already established by Kairos trade identity without importing or delegating to trade-domain identity.
3. The generated ID is provider-neutral and carries no drawing geometry, interaction state, collection state, persistence, or business semantics.

## Ownership preserved
- P18.1 remains drawing contract/shape owner.
- P18.23/P18.24 remain interaction transition/current-state owners.
- P18.28R1 remains ephemeral draft-anchor owner.
- P18.29 remains draft-interaction lifecycle coordinator.
- P18.31 remains draft-to-trend-line constructor.
- P18.32 remains draft commit coordinator.
- P18.33 remains committed in-memory drawing collection owner.
- P18.34 owns only fresh chart drawing ID allocation.
- P20 remains future saved-analysis/persistence ownership.

## Research disposition
No external/provider research was needed for this slice. Current canonical Kairos source already establishes `crypto.randomUUID()` as the project identity-allocation mechanism in `src/domain/trades/tradeIdentity.ts`; P18.34 mirrors only that platform mechanism while preserving a separate chart identity owner.

## Explicit non-scope
No drawing construction; no draft mutation; no interaction dispatch; no collection mutation; no persistence/restore; no provider APIs; no coordinate conversion; no projection/rendering; no toolbar/UI; no selection/edit/delete execution; no undo/redo; no new drawing kinds; no Risk/Reward/P19; no journal/calculation/navigation ownership; no dependency/toolchain migration.
