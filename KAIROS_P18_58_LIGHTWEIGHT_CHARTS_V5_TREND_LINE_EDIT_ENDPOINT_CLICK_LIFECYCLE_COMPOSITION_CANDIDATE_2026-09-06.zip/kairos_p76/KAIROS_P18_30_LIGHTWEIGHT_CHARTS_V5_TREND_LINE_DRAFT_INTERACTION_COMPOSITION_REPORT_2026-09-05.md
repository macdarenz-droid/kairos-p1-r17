# KAIROS P18.30 — Lightweight Charts v5 Trend-Line Draft Interaction Composition

## Authoritative base
P18.29 Chart Trend-Line Draft Interaction Coordination canonical PASS #235 / run 33882557679 / head `c6346e82aaddb6821f8d83d6051ef10f3c276a51`.

## Proven missing responsibility
The authoritative source ends P18.27 provider click handling at a neutral `ChartDrawingAnchor | null` callback and P18.29 begins provider-neutral draft interaction at `acceptAnchor(anchor)`. No current source composes those two already-authoritative boundaries, so real provider click evidence is not yet wired into the sole P18.24/P18.28R1 interaction/draft owners.

P18.30 fills only that composition gap.

## Responsibility
P18.30 creates one provider-specific lifecycle composition that:
- creates the existing P18.29 provider-neutral trend-line draft interaction session;
- binds the exact neutral chart series handle through the existing P18.27 provider click composition;
- forwards each P18.27 neutral anchor result directly to P18.29 `acceptAnchor`;
- destroys the neutral session if provider subscription setup fails;
- detaches provider click delivery before destroying the neutral session;
- preserves idempotent destruction through the composed owners.

## Ownership preserved
- P18.9/P18.16 remain provider series/chart identity owners.
- P18.25R1 remains provider event/price-coordinate -> neutral anchor projection owner.
- P18.26 remains provider click subscribe/unsubscribe lifecycle owner.
- P18.27 remains provider resolution/capability/click-binding composition owner.
- P18.23 remains sole interaction transition-semantics owner.
- P18.24 remains sole active interaction-state owner.
- P18.28R1 remains sole ephemeral 0/1/2 draft-anchor owner.
- P18.29 remains sole neutral coordination owner between interaction state and draft-anchor evidence.
- P18.30 stores no parallel interaction state and no parallel anchor collection.

## Research
No new external API behavior is introduced. P18.30 does not call Lightweight Charts APIs directly; it composes the existing canonical P18.27 provider binding with P18.29. Therefore current authoritative source contracts are sufficient for this slice and no new vendor API research is required.

## Explicit non-scope
No direct `subscribeClick`/`unsubscribeClick`, coordinate conversion, provider event projection, drawing ID allocation, committed drawing construction/mutation, persistence/restore, toolbar/UI state, selection rendering, drag/edit/delete execution, undo/redo, new drawing kinds, Risk/Reward behavior/visuals, journal truth, calculations, navigation, dependency migration, or P19 work.

## Exact changed-file contract relative to canonical P18.29
Exactly six files:
1. `KAIROS_P18_30_LIGHTWEIGHT_CHARTS_V5_TREND_LINE_DRAFT_INTERACTION_COMPOSITION_REPORT_2026-09-05.md`
2. `package.json`
3. `scripts/verify-p18-30-lightweight-charts-v5-trend-line-draft-interaction-composition.mjs`
4. `src/features/chart/lightweightChartsV5TrendLineDraftInteractionComposition.ts`
5. `src/features/chart/index.ts`
6. `tests/lightweight-charts-v5-trend-line-draft-interaction-composition.test.ts`

## Verification intent
Dedicated verification must prove delegation to P18.27 and P18.29, provider null-anchor no-op behavior, preserved cancel/reset semantics, fail-closed setup, teardown ordering, and absence of duplicated provider/state/anchor/persistence/P19 ownership. Canonical GitHub must still prove exact scope, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, focused P18.30 runtime, full unit regression, full controlled roadmap regression, P18/P17 regressions, historical closures, candidate artifact, and gate evidence before promotion.

## Result
Candidate only. P18.29 remains authoritative until P18.30 passes the canonical gate.
