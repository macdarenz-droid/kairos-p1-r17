# Kairos P18.35 — Chart Trend-Line Commit Collection Coordination

## Authority
Built from canonical P18.34 authority (Kairos Controlled Roadmap Gate #240, run 33902824839, head f2e088d1e1e2b4ddb0a27b1ec8386357ffa1804c).

## Proven missing responsibility
Canonical P18.34 contains all three required provider-neutral owners separately but no source composes them: P18.34 allocates fresh `ChartDrawingId` values, P18.32 commits a complete preview draft only when supplied an ID, and P18.33 owns the committed in-memory drawing set. Source search shows no production caller of `commitChartTrendLineDraft`, `createChartDrawingId`, or `addDrawing` outside their defining boundaries.

## Added responsibility
P18.35 introduces one provider-neutral coordination seam:

1. Require the existing P18.29 session to be in `preview` for `trend-line` before creating committed truth.
2. Allocate the identity only through P18.34.
3. Preflight the P18.33 collection for active lifecycle and identity collision before attempting the commit transition.
4. Delegate the authoritative preview -> committed transition and drawing construction to P18.32.
5. Add only the drawing returned after P18.32 confirms matching committed state to the P18.33 collection.
6. Return that same committed drawing to the caller without storing parallel state.

## Ownership preserved
- P18.1 remains drawing contract/shape owner.
- P18.23/P18.24 remain sole interaction transition/current-state owners.
- P18.28R1 remains ephemeral draft-anchor owner.
- P18.29 remains draft-interaction lifecycle coordinator.
- P18.31 remains draft-to-trend-line constructor.
- P18.32 remains authoritative draft commit coordinator.
- P18.33 remains committed in-memory drawing collection owner.
- P18.34 remains fresh chart drawing identity owner.
- P18.35 owns only orchestration across those existing owners.
- P20 remains future saved-analysis/persistence ownership.

## Research disposition
No external/provider research was needed. This slice composes only current canonical Kairos contracts and does not introduce or change external API behavior.

## Explicit non-scope
No direct UUID generation; no drawing construction; no direct reducer/dispatch ownership; no new collection implementation; no persistence/restore; no provider APIs; no coordinate conversion; no projection/rendering; no toolbar/UI; no selection/edit/delete execution; no undo/redo; no new drawing kinds; no Risk/Reward/P19; no journal/calculation/navigation ownership; no dependency/toolchain migration.
