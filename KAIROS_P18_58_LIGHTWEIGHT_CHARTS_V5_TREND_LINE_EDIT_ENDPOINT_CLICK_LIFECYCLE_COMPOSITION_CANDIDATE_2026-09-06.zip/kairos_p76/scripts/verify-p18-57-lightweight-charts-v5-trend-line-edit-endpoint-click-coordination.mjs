import { readFileSync } from 'node:fs';

const production = readFileSync('src/features/chart/lightweightChartsV5TrendLineEditEndpointClickCoordination.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const tests = readFileSync('tests/lightweight-charts-v5-trend-line-edit-endpoint-click-coordination.test.ts', 'utf8');
const click = readFileSync('src/features/chart/lightweightChartsV5DrawingClickSubscription.ts', 'utf8');
const hitTest = readFileSync('src/features/chart/lightweightChartsV5TrendLineHitTest.ts', 'utf8');
const endpointCoordination = readFileSync('src/features/chart/chartTrendLineEditEndpointHitCoordination.ts', 'utf8');

function fail(message) {
  console.error(`P18.57 verification failed: ${message}`);
  process.exit(1);
}

for (const token of [
  'coordinateLightweightChartsV5TrendLineEditEndpointClick(',
  'const point = event.point;',
  'if (point === undefined) return null;',
  'hitTestLightweightChartsV5TrendLineEditEndpoints(',
  'point.x,',
  'point.y,',
  'tolerancePx,',
  'coordinateChartTrendLineEditEndpointHit(interaction, hit)',
]) {
  if (!production.includes(token)) fail(`production coordination missing token: ${token}`);
}

for (const forbidden of [
  'subscribeClick(',
  'unsubscribeClick(',
  'interaction.dispatch(',
  "type: 'start-editing'",
  'initiateChartTrendLineEditFromSelection(',
  'executeChartTrendLineEdit(',
  'executeChartTrendLineEditAndRefreshPresentation(',
  'collection.',
  'replaceDrawing(',
  'refreshChartDrawingPresentationFromCollection(',
  'projectLightweightChartsV5TrendLineSegments(',
  '.timeScale()',
  'priceToCoordinate(',
  'coordinateToPrice(',
  "from 'lightweight-charts'",
  'IndexedDB',
  'Dexie',
  'localStorage',
  'riskReward',
]) {
  if (production.includes(forbidden)) fail(`production coordination leaked protected ownership: ${forbidden}`);
}

if (!production.includes("import type { LightweightChartsV5DrawingClickEvent } from './lightweightChartsV5DrawingClickSubscription';")) {
  fail('production must consume the existing P18.26/P18.40 raw provider-click evidence type');
}
if (!production.includes("import type { LightweightChartsV5TrendLineScreenSegment } from './lightweightChartsV5TrendLineCoordinateProjection';")) {
  fail('production must consume already-projected P18.5 screen segment evidence');
}
if (!production.includes("import {\n  hitTestLightweightChartsV5TrendLineEditEndpoints,\n} from './lightweightChartsV5TrendLineHitTest';")) {
  fail('production must delegate endpoint geometry to P18.55');
}
if (!production.includes("import { coordinateChartTrendLineEditEndpointHit } from './chartTrendLineEditEndpointHitCoordination';")) {
  fail('production must delegate endpoint-hit identity coordination to P18.56');
}
if (!index.includes("export { coordinateLightweightChartsV5TrendLineEditEndpointClick } from './lightweightChartsV5TrendLineEditEndpointClickCoordination';")) {
  fail('chart index production export missing');
}
if (!click.includes('onProviderClick?.(event);')) {
  fail('P18.40 raw provider click fan-out owner missing');
}
if (!hitTest.includes('export function hitTestLightweightChartsV5TrendLineEditEndpoints(')) {
  fail('P18.55 endpoint-hit geometry owner missing');
}
if (!endpointCoordination.includes('export function coordinateChartTrendLineEditEndpointHit(')) {
  fail('P18.56 endpoint-hit coordination owner missing');
}

for (const token of [
  'routes a provider click on the selected drawing endpoint through P18.55 and P18.56',
  'does nothing when the provider click has no point evidence',
  'does not convert a line-body click into endpoint edit intent',
  'never applies an endpoint click from a different drawing to the selected drawing',
  'preserves P18.55 invalid-input ownership for present provider point evidence',
]) {
  if (!tests.includes(token)) fail(`focused runtime test missing case: ${token}`);
}

console.log('P18.57 Lightweight Charts v5 trend-line edit endpoint-click coordination verification passed.');
