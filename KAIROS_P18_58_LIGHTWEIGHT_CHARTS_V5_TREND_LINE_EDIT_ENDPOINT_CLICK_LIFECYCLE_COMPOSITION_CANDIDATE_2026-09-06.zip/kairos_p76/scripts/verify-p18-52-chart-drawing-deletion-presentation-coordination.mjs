import { readFileSync } from 'node:fs';

const production = readFileSync('src/features/chart/chartDrawingDeletionPresentationCoordination.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const tests = readFileSync('tests/chart-drawing-deletion-presentation-coordination.test.ts', 'utf8');
const deletion = readFileSync('src/features/chart/chartDrawingDeletionCoordination.ts', 'utf8');
const refresh = readFileSync('src/features/chart/chartDrawingCollectionPresentationCoordination.ts', 'utf8');
const projection = readFileSync('src/features/chart/chartDrawingProjection.ts', 'utf8');

function fail(message) {
  console.error(`P18.52 verification failed: ${message}`);
  process.exit(1);
}

for (const token of [
  'executeChartDrawingDeletionAndRefreshPresentation(',
  'executeChartDrawingDeletion(interaction, collection)',
  'if (deleted === null) return null;',
  'refreshChartDrawingPresentationFromCollection(presentation, collection)',
  'return deleted;',
]) {
  if (!production.includes(token)) fail(`production coordination missing token: ${token}`);
}

for (const forbidden of [
  'collection.replaceDrawing(',
  'collection.removeDrawing(',
  'interaction.dispatch(',
  "type: 'start-deleting'",
  'projectChartDrawings(',
  'presentation.replaceDrawings(',
  'lightweight-charts',
  'subscribeClick(',
  'subscribeCrosshairMove(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'riskReward',
]) {
  if (production.includes(forbidden)) fail(`production coordination leaked protected ownership: ${forbidden}`);
}

if (!index.includes("export { executeChartDrawingDeletionAndRefreshPresentation } from './chartDrawingDeletionPresentationCoordination';")) {
  fail('chart index production export missing');
}

if (!deletion.includes('export function executeChartDrawingDeletion(')) {
  fail('P18.45 deletion execution owner missing');
}

if (!refresh.includes('export function refreshChartDrawingPresentationFromCollection(')) {
  fail('P18.47 drawing-refresh coordination owner missing');
}

if (!projection.includes('export function projectChartDrawings(')) {
  fail('P18.36 renderer projection owner missing');
}

if (!tests.includes("from '../src/features/chart/chartDrawingPresentationPort';")) {
  fail('focused test must import drawing-refresh session type directly from its owner module');
}

if (index.includes('ChartDrawingPresentationDrawingRefreshSession')) {
  fail('P18.52 must not expand public chart barrel solely for a test-only type import');
}

for (const token of [
  'start: { time: 1788609720, value: 102.25 }',
  'end: { time: 1788609780, value: 103.75 }',
]) {
  if (!tests.includes(token)) fail(`focused success-path renderer expectation missing: ${token}`);
}

for (const token of [
  'refreshes current committed drawing presentation exactly once after a successful deletion',
  'does not refresh presentation when authoritative interaction state does not execute a deletion',
  'does not refresh presentation for a stale authoritative deletion target',
  'never rolls back committed deletion truth when presentation refresh fails',
]) {
  if (!tests.includes(token)) fail(`focused runtime test missing case: ${token}`);
}

console.log('P18.52 chart drawing deletion presentation coordination verification passed.');
