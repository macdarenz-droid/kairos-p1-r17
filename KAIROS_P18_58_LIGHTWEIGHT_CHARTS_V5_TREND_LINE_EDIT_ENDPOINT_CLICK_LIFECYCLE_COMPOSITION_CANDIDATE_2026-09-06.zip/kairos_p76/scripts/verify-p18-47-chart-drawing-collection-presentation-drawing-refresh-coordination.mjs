import { readFileSync } from 'node:fs';

const production = readFileSync('src/features/chart/chartDrawingCollectionPresentationCoordination.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));
const test = readFileSync('tests/chart-drawing-collection-presentation-drawing-refresh-coordination.test.ts', 'utf8');

for (const token of [
  'ChartDrawingPresentationDrawingRefreshSession',
  'refreshChartDrawingPresentationFromCollection(',
  'projectChartDrawings(collection.getDrawings())',
  'presentation.replaceDrawings(drawings)',
]) {
  if (!production.includes(token)) throw new Error(`P18.47 production token missing: ${token}`);
}

const start = production.indexOf('export function refreshChartDrawingPresentationFromCollection(');
if (start < 0) throw new Error('P18.47 refresh function missing');
const body = production.slice(start);
for (const forbidden of [
  'addDrawing(',
  'replaceDrawing(',
  'removeDrawing(',
  'dispatch(',
  'createChartDrawingId',
  'chart.removeSeries',
  'lightweight-charts',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'riskReward',
]) {
  if (body.includes(forbidden)) throw new Error(`P18.47 forbidden ownership token present: ${forbidden}`);
}

if (!index.includes('refreshChartDrawingPresentationFromCollection')) {
  throw new Error('P18.47 index export missing');
}
if (pkg.scripts?.['verify:p18:47-chart-drawing-collection-presentation-drawing-refresh-coordination'] !== 'node scripts/verify-p18-47-chart-drawing-collection-presentation-drawing-refresh-coordination.mjs') {
  throw new Error('P18.47 package verifier registration missing');
}
for (const token of [
  'refreshes the current committed collection through the drawing-only presentation path',
  'refreshes an empty committed collection as an empty renderer snapshot',
  'fails closed before presentation refresh when the collection is destroyed',
]) {
  if (!test.includes(token)) throw new Error(`P18.47 runtime evidence missing: ${token}`);
}

console.log('PASS P18.47 chart drawing collection presentation drawing-refresh coordination verifier');
