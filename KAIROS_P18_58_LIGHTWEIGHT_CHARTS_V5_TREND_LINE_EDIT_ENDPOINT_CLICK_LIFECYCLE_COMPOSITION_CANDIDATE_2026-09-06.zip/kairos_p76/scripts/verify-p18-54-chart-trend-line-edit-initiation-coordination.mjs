import { readFileSync } from 'node:fs';

const production = readFileSync('src/features/chart/chartTrendLineEditInitiationCoordination.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const tests = readFileSync('tests/chart-trend-line-edit-initiation-coordination.test.ts', 'utf8');
const reducer = readFileSync('src/features/chart/chartDrawingInteractionReducer.ts', 'utf8');
const events = readFileSync('src/features/chart/chartDrawingInteractionEvent.ts', 'utf8');
const construction = readFileSync('src/features/chart/chartTrendLineEditConstruction.ts', 'utf8');
const execution = readFileSync('src/features/chart/chartTrendLineEditCoordination.ts', 'utf8');
const presentation = readFileSync('src/features/chart/chartTrendLineEditPresentationCoordination.ts', 'utf8');

function fail(message) {
  console.error(`P18.54 verification failed: ${message}`);
  process.exit(1);
}

for (const token of [
  'initiateChartTrendLineEditFromSelection(',
  'const selected = interaction.getState();',
  "if (selected.status !== 'selected') return null;",
  "type: 'start-editing'",
  'drawingId: selected.drawingId',
  'endpoint,',
  "next.status === 'editing'",
  'next.drawingId === selected.drawingId',
  'next.endpoint === endpoint',
]) {
  if (!production.includes(token)) fail(`production coordination missing token: ${token}`);
}

for (const forbidden of [
  'executeChartTrendLineEdit(',
  'executeChartTrendLineEditAndRefreshPresentation(',
  'collection.',
  'replaceDrawing(',
  'refreshChartDrawingPresentationFromCollection(',
  'projectChartDrawings(',
  'hitTestLightweightChartsV5TrendLineSegments(',
  'lightweight-charts',
  'subscribeClick(',
  'subscribeCrosshairMove(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'riskReward',
]) {
  if (production.includes(forbidden)) fail(`production coordination leaked protected ownership: ${forbidden}`);
}

const signatureStart = production.indexOf('export function initiateChartTrendLineEditFromSelection(');
const signatureEnd = production.indexOf('): ChartDrawingInteractionState | null {', signatureStart);
const signature = production.slice(signatureStart, signatureEnd + '): ChartDrawingInteractionState | null {'.length);
if (signature.includes('drawingId')) fail('public production signature must not accept drawing identity');
if (!signature.includes('endpoint: ChartTrendLineEditEndpoint')) fail('public production signature must accept only typed edit endpoint evidence besides interaction');

if (!index.includes("export { initiateChartTrendLineEditFromSelection } from './chartTrendLineEditInitiationCoordination';")) {
  fail('chart index production export missing');
}
if (!events.includes("readonly type: 'start-editing';")) fail('P18.22/P18.49 existing start-editing event owner missing');
if (!reducer.includes("case 'start-editing':")) fail('P18.23/P18.49 existing start-editing transition owner missing');
if (!construction.includes("export type ChartTrendLineEditEndpoint = 'start' | 'end';")) fail('P18.48 endpoint vocabulary owner missing');
if (!execution.includes('export function executeChartTrendLineEdit(')) fail('P18.50 edit execution owner missing');
if (!presentation.includes('export function executeChartTrendLineEditAndRefreshPresentation(')) fail('P18.51R3 edit presentation owner missing');

for (const token of [
  'initiates editing only for the exact authoritative selected drawing identity and endpoint',
  'preserves either existing P18.48 edit endpoint without becoming its vocabulary owner',
  'does not initiate editing from idle or other non-selected authoritative states',
  'never accepts caller-supplied drawing identity and forwards selected identity plus endpoint exactly once',
  'fails closed when the active interaction owner rejects or changes the delegated transition',
]) {
  if (!tests.includes(token)) fail(`focused runtime test missing case: ${token}`);
}

console.log('P18.54 chart trend-line edit initiation coordination verification passed.');
