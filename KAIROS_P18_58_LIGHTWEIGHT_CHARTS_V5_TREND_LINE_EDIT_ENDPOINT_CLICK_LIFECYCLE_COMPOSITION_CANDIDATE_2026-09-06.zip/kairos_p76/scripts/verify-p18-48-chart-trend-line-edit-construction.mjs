import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/chartTrendLineEditConstruction.ts', 'utf8');
const drawingContract = readFileSync('src/features/chart/chartDrawingContract.ts', 'utf8');
const collection = readFileSync('src/features/chart/chartDrawingCollection.ts', 'utf8');
const interaction = readFileSync('src/features/chart/chartDrawingInteractionContract.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync('tests/chart-trend-line-edit-construction.test.ts', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.48 chart trend-line edit construction verification FAIL: ${message}`);
  process.exit(1);
};

for (const token of [
  "export type ChartTrendLineEditEndpoint = 'start' | 'end'",
  'export function constructChartTrendLineEdit(',
  'drawing: ChartTrendLineDrawing',
  'endpoint: ChartTrendLineEditEndpoint',
  'anchor: ChartDrawingAnchor',
  "throw new Error('chart-trend-line-edit-endpoint-unsupported')",
  'id: drawing.id',
  "kind: 'trend-line'",
  "start: endpoint === 'start' ? { ...anchor } : { ...drawing.start }",
  "end: endpoint === 'end' ? { ...anchor } : { ...drawing.end }",
]) {
  if (!source.includes(token)) fail(`missing edit construction evidence: ${token}`);
}

for (const token of [
  'export interface ChartTrendLineDrawing',
  'readonly id: ChartDrawingId',
  "readonly kind: 'trend-line'",
  'readonly start: ChartDrawingAnchor',
  'readonly end: ChartDrawingAnchor',
]) {
  if (!drawingContract.includes(token)) fail(`P18.1 drawing truth owner regressed: ${token}`);
}

for (const token of [
  'replaceDrawing(drawingId: ChartDrawingId, drawing: ChartDrawing)',
  'drawings.set(drawingId, drawing)',
]) {
  if (!collection.includes(token)) fail(`P18.44 mutation owner regressed: ${token}`);
}

for (const token of ["readonly status: 'editing'", 'readonly drawingId: ChartDrawingId']) {
  if (!interaction.includes(token)) fail(`P18.38 editing interaction state regressed: ${token}`);
}

for (const token of ['constructChartTrendLineEdit', 'ChartTrendLineEditEndpoint']) {
  if (!index.includes(token)) fail(`P18.48 index export missing: ${token}`);
}

if (
  pkg.scripts?.['verify:p18:48-chart-trend-line-edit-construction'] !==
  'node scripts/verify-p18-48-chart-trend-line-edit-construction.mjs'
) {
  fail('P18.48 package verifier registration missing');
}

for (const token of [
  'replaces only the start anchor while preserving committed identity and kind',
  'replaces only the end anchor while preserving the untouched start anchor',
  'returns detached anchor snapshots without mutating caller-owned drawing evidence',
  'fails closed for an unsupported runtime endpoint instead of guessing an edit target',
]) {
  if (!test.includes(token)) fail(`P18.48 runtime evidence missing: ${token}`);
}

for (const forbidden of [
  'addDrawing(',
  'replaceDrawing(',
  'removeDrawing(',
  'dispatch(',
  'subscribeClick(',
  'unsubscribeClick(',
  'subscribeCrosshairMove(',
  'coordinateToPrice(',
  'replaceDrawings(',
  'randomUUID',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'riskReward',
  'lightweight-charts',
]) {
  if (source.includes(forbidden)) fail(`edit construction crossed protected boundary: ${forbidden}`);
}

console.log('PASS P18.48 chart trend-line edit construction verifier');
