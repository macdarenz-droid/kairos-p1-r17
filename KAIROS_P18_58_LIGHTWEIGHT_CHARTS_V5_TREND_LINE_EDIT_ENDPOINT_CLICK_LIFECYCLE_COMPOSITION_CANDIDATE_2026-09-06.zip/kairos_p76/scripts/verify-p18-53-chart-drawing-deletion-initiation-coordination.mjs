import { readFileSync } from 'node:fs';

const production = readFileSync('src/features/chart/chartDrawingDeletionInitiationCoordination.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const tests = readFileSync('tests/chart-drawing-deletion-initiation-coordination.test.ts', 'utf8');
const reducer = readFileSync('src/features/chart/chartDrawingInteractionReducer.ts', 'utf8');
const deletion = readFileSync('src/features/chart/chartDrawingDeletionCoordination.ts', 'utf8');
const presentation = readFileSync('src/features/chart/chartDrawingDeletionPresentationCoordination.ts', 'utf8');

function fail(message) {
  console.error(`P18.53 verification failed: ${message}`);
  process.exit(1);
}

for (const token of [
  'initiateChartDrawingDeletionFromSelection(',
  'const selected = interaction.getState();',
  "if (selected.status !== 'selected') return null;",
  "type: 'start-deleting'",
  'drawingId: selected.drawingId',
  "next.status === 'deleting' && next.drawingId === selected.drawingId",
]) {
  if (!production.includes(token)) fail(`production coordination missing token: ${token}`);
}

for (const forbidden of [
  'drawingId:',
  'executeChartDrawingDeletion(',
  'executeChartDrawingDeletionAndRefreshPresentation(',
  'collection.',
  'refreshChartDrawingPresentationFromCollection(',
  'projectChartDrawings(',
  'lightweight-charts',
  'subscribeClick(',
  'subscribeCrosshairMove(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'riskReward',
]) {
  if (forbidden === 'drawingId:') continue;
  if (production.includes(forbidden)) fail(`production coordination leaked protected ownership: ${forbidden}`);
}

const signature = production.slice(
  production.indexOf('export function initiateChartDrawingDeletionFromSelection('),
  production.indexOf('): ChartDrawingInteractionState | null {') + '): ChartDrawingInteractionState | null {'.length,
);
if (signature.includes('drawingId')) fail('public production signature must not accept drawing identity');

if (!index.includes("export { initiateChartDrawingDeletionFromSelection } from './chartDrawingDeletionInitiationCoordination';")) {
  fail('chart index production export missing');
}
if (!reducer.includes("case 'start-deleting':")) fail('P18.23 existing start-deleting transition owner missing');
if (!deletion.includes('export function executeChartDrawingDeletion(')) fail('P18.45 deletion execution owner missing');
if (!presentation.includes('export function executeChartDrawingDeletionAndRefreshPresentation(')) fail('P18.52 deletion presentation owner missing');

for (const token of [
  'initiates deletion only from the exact authoritative selected drawing identity',
  'does not initiate deletion from idle or other non-selected authoritative states',
  'never accepts caller-supplied drawing identity and forwards the selected id exactly once',
  'fails closed when the active interaction owner rejects the delegated transition',
]) {
  if (!tests.includes(token)) fail(`focused runtime test missing case: ${token}`);
}

console.log('P18.53 chart drawing deletion initiation coordination verification passed.');
