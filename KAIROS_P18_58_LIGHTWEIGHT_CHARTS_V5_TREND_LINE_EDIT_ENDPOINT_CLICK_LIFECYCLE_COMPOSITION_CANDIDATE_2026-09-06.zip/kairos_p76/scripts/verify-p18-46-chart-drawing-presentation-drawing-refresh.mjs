import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/features/chart/chartDrawingPresentationPort.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/features/chart/index.ts', import.meta.url), 'utf8');

for (const required of [
  'ChartDrawingPresentationDrawingRefreshSession',
  'replaceDrawings(drawings: readonly RendererChartDrawing[]): void',
  "throw new Error('chart-drawing-presentation-inactive')",
  'activeDrawingLayer.replaceDrawings(nextDrawings)',
  'hover.port.attach(activeSeries, nextDrawings, hover.onHover)',
  'activeDrawingLayer.replaceDrawings(previousDrawings)',
  'previousHover.destroy()',
  'activeDrawings = nextDrawings',
]) {
  if (!source.includes(required)) throw new Error(`p18.46-missing:${required}`);
}

const refreshStart = source.indexOf('replaceDrawings(drawings): void {');
const refreshEnd = source.indexOf('\n\n        destroy(): void {', refreshStart);
if (refreshStart < 0 || refreshEnd < 0) throw new Error('p18.46-refresh-body-missing');
const refreshBody = source.slice(refreshStart, refreshEnd);

for (const forbidden of [
  'createSeries(',
  'chart.addPriceLineSeries',
  'chart.addCandlestickSeries',
  'chart.removeSeries',
  'drawingLayer.attach(',
  'IndexedDB',
  'localStorage',
  'riskReward',
]) {
  if (refreshBody.includes(forbidden)) throw new Error(`p18.46-refresh-forbidden:${forbidden}`);
}

if (!index.includes("from './chartDrawingPresentationPort'")) {
  throw new Error('p18.46-index-export-missing');
}

console.log('P18.46 chart drawing presentation drawing-only refresh verifier: PASS');
