import { readFileSync } from 'node:fs';

const production = readFileSync('src/features/chart/lightweightChartsV5TrendLineHitTest.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const tests = readFileSync('tests/lightweight-charts-v5-trend-line-edit-endpoint-hit-test.test.ts', 'utf8');
const initiation = readFileSync('src/features/chart/chartTrendLineEditInitiationCoordination.ts', 'utf8');
const construction = readFileSync('src/features/chart/chartTrendLineEditConstruction.ts', 'utf8');

function fail(message) {
  console.error(`P18.55 verification failed: ${message}`);
  process.exit(1);
}

for (const token of [
  'hitTestLightweightChartsV5TrendLineEditEndpoints(',
  "kind: 'trend-line-edit-endpoint'",
  'endpoint: ChartTrendLineEditEndpoint',
  'const startDistance = squaredDistanceToPoint(x, y, segment.start);',
  'const endDistance = squaredDistanceToPoint(x, y, segment.end);',
  'if (!startHit && !endHit) continue;',
  'if (startHit && endHit && startDistance === endDistance) return null;',
  "endpoint: startHit && (!endHit || startDistance < endDistance) ? 'start' : 'end'",
]) {
  if (!production.includes(token)) fail(`endpoint hit-test owner missing token: ${token}`);
}

for (const historical of [
  'hitTestLightweightChartsV5TrendLineSegments(',
  'squaredDistanceToSegment(',
  "return { id: segment.id, kind: 'trend-line', cursorStyle: 'pointer' };",
]) {
  if (!production.includes(historical)) fail(`P18.12 historical whole-segment hit-test contract missing: ${historical}`);
}

for (const forbidden of [
  'subscribeClick(',
  'unsubscribeClick(',
  'subscribeCrosshairMove(',
  'interaction.dispatch(',
  "type: 'start-editing'",
  'executeChartTrendLineEdit(',
  'replaceDrawing(',
  'refreshChartDrawingPresentationFromCollection(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'riskReward',
]) {
  if (production.includes(forbidden)) fail(`endpoint hit-test geometry leaked protected ownership: ${forbidden}`);
}

for (const token of [
  'hitTestLightweightChartsV5TrendLineEditEndpoints,',
  'type LightweightChartsV5TrendLineEditEndpointHit,',
]) {
  if (!index.includes(token)) fail(`chart index export missing: ${token}`);
}

if (!construction.includes("export type ChartTrendLineEditEndpoint = 'start' | 'end';")) {
  fail('P18.48 endpoint vocabulary owner missing');
}
if (!initiation.includes('initiateChartTrendLineEditFromSelection(')) {
  fail('P18.54 edit-initiation coordinator missing');
}
if (!initiation.includes('endpoint: ChartTrendLineEditEndpoint')) {
  fail('P18.54 must continue consuming the existing typed endpoint vocabulary');
}

for (const token of [
  'derives exact start and end endpoint evidence from projected trend-line geometry',
  'chooses the nearer endpoint when both handles are within tolerance and fails closed on an exact tie',
  'preserves the existing top-most/latest projected segment rule for overlapping endpoint geometry',
  'returns null outside endpoint tolerance without falling back to whole-segment hit semantics',
  'reuses the existing P18.12 invalid-input failure contract',
]) {
  if (!tests.includes(token)) fail(`focused runtime test missing case: ${token}`);
}

console.log('P18.55 Lightweight Charts v5 trend-line edit endpoint hit-test geometry verification passed.');
