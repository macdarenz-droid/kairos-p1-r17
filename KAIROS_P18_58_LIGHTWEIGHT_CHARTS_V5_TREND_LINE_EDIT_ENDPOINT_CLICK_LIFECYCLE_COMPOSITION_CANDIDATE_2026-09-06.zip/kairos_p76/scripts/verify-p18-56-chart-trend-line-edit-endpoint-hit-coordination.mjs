import { readFileSync } from 'node:fs';

const production = readFileSync('src/features/chart/chartTrendLineEditEndpointHitCoordination.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const tests = readFileSync('tests/chart-trend-line-edit-endpoint-hit-coordination.test.ts', 'utf8');
const hitTest = readFileSync('src/features/chart/lightweightChartsV5TrendLineHitTest.ts', 'utf8');
const initiation = readFileSync('src/features/chart/chartTrendLineEditInitiationCoordination.ts', 'utf8');

function fail(message) {
  console.error(`P18.56 verification failed: ${message}`);
  process.exit(1);
}

for (const token of [
  'coordinateChartTrendLineEditEndpointHit(',
  'if (hit === null) return null;',
  'const selected = interaction.getState();',
  "selected.status !== 'selected'",
  'selected.drawingId !== hit.id',
  'initiateChartTrendLineEditFromSelection(interaction, hit.endpoint)',
]) {
  if (!production.includes(token)) fail(`production coordination missing token: ${token}`);
}

for (const forbidden of [
  'interaction.dispatch(',
  "type: 'start-editing'",
  'hitTestLightweightChartsV5TrendLineEditEndpoints(',
  'executeChartTrendLineEdit(',
  'executeChartTrendLineEditAndRefreshPresentation(',
  'collection.',
  'replaceDrawing(',
  'refreshChartDrawingPresentationFromCollection(',
  'projectLightweightChartsV5TrendLineSegments(',
  'lightweight-charts',
  'subscribeClick(',
  'subscribeCrosshairMove(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'riskReward',
]) {
  if (production.includes(forbidden)) fail(`production coordination leaked protected ownership: ${forbidden}`);
}

if (!production.includes("import type { LightweightChartsV5TrendLineEditEndpointHit } from './lightweightChartsV5TrendLineHitTest';")) {
  fail('production must consume the existing P18.55 endpoint-hit evidence type');
}
if (!production.includes("import { initiateChartTrendLineEditFromSelection } from './chartTrendLineEditInitiationCoordination';")) {
  fail('production must delegate edit initiation to P18.54');
}
if (!index.includes("export { coordinateChartTrendLineEditEndpointHit } from './chartTrendLineEditEndpointHitCoordination';")) {
  fail('chart index production export missing');
}
if (!hitTest.includes('export function hitTestLightweightChartsV5TrendLineEditEndpoints(')) {
  fail('P18.55 endpoint-hit geometry owner missing');
}
if (!initiation.includes('export function initiateChartTrendLineEditFromSelection(')) {
  fail('P18.54 edit-initiation owner missing');
}

for (const token of [
  'initiates editing only when endpoint-hit identity matches authoritative selected identity',
  'does nothing when there is no P18.55 endpoint-hit evidence',
  'never applies an endpoint hit from a different drawing to the selected drawing',
  'does not initiate editing from non-selected authoritative interaction state',
  'fails closed if authoritative selection changes before P18.54 delegation revalidates it',
]) {
  if (!tests.includes(token)) fail(`focused runtime test missing case: ${token}`);
}

console.log('P18.56 chart trend-line edit endpoint-hit coordination verification passed.');
