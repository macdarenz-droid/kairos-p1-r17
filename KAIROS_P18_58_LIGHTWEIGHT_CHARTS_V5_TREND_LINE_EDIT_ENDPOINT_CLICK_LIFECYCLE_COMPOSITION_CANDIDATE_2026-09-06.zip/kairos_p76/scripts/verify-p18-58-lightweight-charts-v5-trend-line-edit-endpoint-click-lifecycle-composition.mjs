import { readFileSync } from 'node:fs';

const production = readFileSync('src/features/chart/lightweightChartsV5TrendLineDraftInteractionComposition.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const tests = readFileSync('tests/lightweight-charts-v5-trend-line-edit-endpoint-click-lifecycle-composition.test.ts', 'utf8');
const click = readFileSync('src/features/chart/lightweightChartsV5DrawingClickSubscription.ts', 'utf8');
const endpointClick = readFileSync('src/features/chart/lightweightChartsV5TrendLineEditEndpointClickCoordination.ts', 'utf8');
const selection = readFileSync('src/features/chart/lightweightChartsV5DrawingSelectionInteractionCoordination.ts', 'utf8');

function fail(message) {
  console.error(`P18.58 verification failed: ${message}`);
  process.exit(1);
}

for (const token of [
  'LightweightChartsV5TrendLineEditEndpointClickLifecycleOptions',
  'getCurrentSegments: () => readonly LightweightChartsV5TrendLineScreenSegment[];',
  'readonly tolerancePx: number;',
  'editEndpointClick?: LightweightChartsV5TrendLineEditEndpointClickLifecycleOptions,',
  'if (getCurrentRendererDrawings === undefined)',
  'coordinateLightweightChartsV5TrendLineEditEndpointClick(',
  'editEndpointClick.getCurrentSegments()',
  'editEndpointClick.tolerancePx',
  'coordinateLightweightChartsV5DrawingSelectionInteraction(',
]) {
  if (!production.includes(token)) fail(`lifecycle composition missing token: ${token}`);
}

const editIndex = production.indexOf('coordinateLightweightChartsV5TrendLineEditEndpointClick(');
const selectionIndex = production.indexOf('coordinateLightweightChartsV5DrawingSelectionInteraction(');
if (editIndex < 0 || selectionIndex < 0 || editIndex > selectionIndex) {
  fail('endpoint edit evidence must be evaluated before same-click selection evidence');
}

for (const forbidden of [
  'subscribeClick(',
  'unsubscribeClick(',
  "type: 'start-editing'",
  'hitTestLightweightChartsV5TrendLineEditEndpoints(',
  'projectLightweightChartsV5TrendLineSegments(',
  'executeChartTrendLineEdit(',
  'executeChartTrendLineEditAndRefreshPresentation(',
  'replaceDrawing(',
  'refreshChartDrawingPresentationFromCollection(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'riskReward',
]) {
  if (production.includes(forbidden)) fail(`lifecycle composition leaked protected ownership: ${forbidden}`);
}

if (!production.includes("import { createLightweightChartsV5DrawingClickSubscriptionFromBinding } from './lightweightChartsV5DrawingClickBindingComposition';")) {
  fail('P18.27/P18.40 existing click binding must remain the lifecycle delegate');
}
if (!production.includes("import { coordinateLightweightChartsV5TrendLineEditEndpointClick } from './lightweightChartsV5TrendLineEditEndpointClickCoordination';")) {
  fail('P18.58 must delegate endpoint edit click semantics to P18.57');
}
if (!production.includes("import { coordinateLightweightChartsV5DrawingSelectionInteraction } from './lightweightChartsV5DrawingSelectionInteractionCoordination';")) {
  fail('P18.42 selection coordinator must remain delegated');
}
if (!index.includes('type LightweightChartsV5TrendLineEditEndpointClickLifecycleOptions,')) {
  fail('chart index options type export missing');
}
if (!click.includes('onProviderClick?.(event);')) {
  fail('P18.40 same-click raw provider evidence fan-out owner missing');
}
if (!endpointClick.includes('export function coordinateLightweightChartsV5TrendLineEditEndpointClick(')) {
  fail('P18.57 endpoint-click coordinator missing');
}
if (!selection.includes('export function coordinateLightweightChartsV5DrawingSelectionInteraction(')) {
  fail('P18.41 selection coordinator missing');
}

for (const token of [
  'routes a selected endpoint through P18.57 inside the existing single click lifecycle',
  'evaluates edit identity before selection so another drawing endpoint selects but does not edit in the same click',
  'keeps a selected line-body click out of editing while preserving selection',
  'reads the current projected endpoint segment snapshot at click time',
  'preserves one exact provider unsubscribe lifecycle after endpoint-edit composition',
]) {
  if (!tests.includes(token)) fail(`focused runtime test missing case: ${token}`);
}

console.log('P18.58 Lightweight Charts v5 trend-line edit endpoint-click lifecycle composition verification passed.');
