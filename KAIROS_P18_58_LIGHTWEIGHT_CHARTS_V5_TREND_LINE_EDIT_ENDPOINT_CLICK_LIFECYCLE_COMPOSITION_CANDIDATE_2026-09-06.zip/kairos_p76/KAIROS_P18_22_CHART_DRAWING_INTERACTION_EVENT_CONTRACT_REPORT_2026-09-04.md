# KAIROS P18.22 — Chart Drawing Interaction Event Contract

## Controlled base
Canonical P18.21 PASS, GitHub Actions run #225 / 33862549047.

## Evidence / research basis
The controlling Kairos drawing architecture requires one explicit drawing interaction state machine/reducer instead of contradictory booleans. Canonical P18.21 established only the state-shape vocabulary and explicitly deferred transition behavior. Its authoritative source has no event/action owner yet.

Current official React guidance for reducers says reducer logic should remain pure and that each action should describe one user interaction rather than scattering state setters. Current TypeScript guidance recommends discriminated unions for message/action schemes because the discriminant safely narrows each variant. P18.22 uses those principles only for the provider-neutral event contract; it introduces no React hook or vendor API dependency.

## Responsibility added
Adds only the provider-neutral event vocabulary consumed by future drawing-interaction transition logic:
- `select-tool` with `ChartDrawingKind`
- `start-drawing`
- `preview-drawing`
- `commit-drawing` with `ChartDrawingId`
- `cancel-interaction`
- `start-editing` with `ChartDrawingId`
- `start-deleting` with `ChartDrawingId`
- `reset-interaction`

The contract represents interaction intent/evidence only. It does not decide whether an event is accepted from a given state and does not mutate drawing truth.

## Ownership preserved
- P18.1 remains drawing truth owner.
- P18.11/P18.20 remain presentation lifecycle/hover coordination owners.
- P18.18 remains hover lifecycle owner.
- P18.17/P18.16/P18.15/P18.14 retain provider resolution/subscription/projection ownership.
- P18.21 remains drawing interaction-state shape owner.
- P18.22 owns only drawing interaction event/action shape.

## Explicit non-scope
No reducer transition table, transition acceptance/rejection semantics, pointer/click subscription, pointer capture, screen-to-market coordinate conversion, drag/edit execution, drawing mutation, drawing persistence, toolbar UI, undo/redo, new drawing kinds, horizontal line, rectangle/order block, freehand, risk/reward behavior, journal truth, market truth, calculations, navigation, dependency migration, or P19 work.

## Changed-file contract
Exactly six files relative to canonical P18.21:
1. `KAIROS_P18_22_CHART_DRAWING_INTERACTION_EVENT_CONTRACT_REPORT_2026-09-04.md`
2. `package.json`
3. `scripts/verify-p18-22-chart-drawing-interaction-event-contract.mjs`
4. `src/features/chart/chartDrawingInteractionEvent.ts`
5. `src/features/chart/index.ts`
6. `tests/chart-drawing-interaction-event.test.ts`

## Verification intent
Dedicated verification proves the explicit event vocabulary, discriminated-union payload ownership, chart export, preservation of P18.21 state vocabulary, and absence of provider/persistence/P19 ownership. Canonical gate must additionally prove deterministic install, production TypeScript/build, dedicated runtime tests, full unit regression, P18/P17 regression chain, historical closures, exact scope, candidate artifact, and gate evidence before promotion.
