# KAIROS P18.58 — Lightweight Charts v5 Trend-Line Edit Endpoint-Click Lifecycle Composition

Date: 2026-09-06  
Authoritative base: **P18.57 — Lightweight Charts v5 Trend-Line Edit Endpoint-Click Coordination**  
Canonical base evidence: **Kairos Controlled Roadmap Gate #268 / run 33972493069 / head 9b702a7f766b54023f1e93316e6a6f93fae12088 — SUCCESS**  
Canonical base artifacts: **KAIROS_CURRENT_CANDIDATE 9971456202 / KAIROS_GATE_EVIDENCE 9971456391**

## Source-derived missing seam

Canonical P18.57 can turn one already-observed provider click plus a current projected trend-line segment snapshot into authoritative selected endpoint edit initiation, but canonical P18.57 source does not attach that coordinator to the existing P18.30/P18.42 provider click lifecycle.

P18.26 remains the sole `subscribeClick`/`unsubscribeClick` owner. P18.40 already fans the exact raw click event through that one lifecycle. P18.42 already composes raw click selection evidence into the same P18.24-backed interaction session. The missing production seam is therefore lifecycle composition only: feed that same raw click to P18.57 without creating another provider subscription or another interaction owner.

No new Lightweight Charts API behavior is introduced or assumed; current canonical source fully establishes the required event and lifecycle surfaces, so external API research is not required for this slice.

## P18.58 responsibility

P18.58 extends the existing `createLightweightChartsV5TrendLineDraftInteractionFromBinding(...)` composition with one optional endpoint-edit click lifecycle configuration:

- `getCurrentSegments()` supplies the current P18.5 projected trend-line screen-segment snapshot at click time;
- `tolerancePx` supplies presentation hit tolerance;
- the existing raw P18.40 provider click is delegated first to P18.57 endpoint-edit coordination;
- the same raw click is then delegated to existing P18.41 selection coordination when selection composition is enabled;
- existing P18.29 anchor delivery remains unchanged and still occurs after raw provider evidence fan-out.

### Same-click ordering invariant

Endpoint-edit evidence is evaluated **before** same-click selection evidence. This preserves pre-click authoritative selection identity:

- endpoint click on the already-selected drawing may enter `editing`;
- endpoint click on another drawing cannot silently select and edit that drawing in one event;
- after the mismatched edit attempt fails closed, existing selection coordination may select that other drawing, requiring a later click to edit it;
- P18.23 remains the sole transition-acceptance owner.

## Ownership preservation

- P18.26 remains sole provider click subscribe/unsubscribe lifecycle owner.
- P18.27/P18.40 remain provider binding and raw-click fan-out owners.
- P18.5 remains forward screen-segment projection owner.
- P18.55 remains endpoint geometry owner.
- P18.56/P18.54 remain endpoint identity and edit-initiation owners.
- P18.57 remains raw click + projected segments -> endpoint edit coordination owner.
- P18.41/P18.42 remain drawing selection coordination/lifecycle composition owners.
- P18.24/P18.23 remain active interaction state and transition semantics owners.
- P18.29 remains draft anchor/state coordination owner.
- P18.58 owns only optional endpoint-edit wiring inside the already-existing single click lifecycle.

## Explicit non-scope

No second click subscription; no provider chart/series capability expansion; no screen projection; no endpoint geometry reimplementation; no direct `start-editing` dispatch; no edit execution; no committed drawing mutation; no presentation refresh; no drag lifecycle; no handle rendering/style/UI; no persistence/restore; no undo/redo; no deletion change; no new drawing kind; no P19 Risk/Reward; no journal/calculation/navigation truth; no toolchain migration.

## Focused runtime evidence

The focused P18.58 test proves:
- an endpoint click on the authoritative selected drawing enters exact editing state through P18.57 while the provider has only one click subscription;
- an endpoint click on a different drawing is evaluated against the pre-click selected identity, fails edit closed, then may select the other drawing without editing it in the same event;
- a selected line-body click does not become endpoint edit intent;
- projected endpoint segments are read at provider-click time rather than frozen at composition creation;
- destruction still delegates to the one existing unsubscribe lifecycle exactly once.

## Canonical promotion requirement

Promotion requires exact P18.57 -> P18.58 controlled scope, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.58 verifier/runtime, focused P18.58/P18.57/P18.42/P18.40/P18.26/P18.24 tests, full units, full controlled roadmap regression through P18.58, P18.58 -> P17 chart regressions, historical closures, candidate artifact, and gate evidence.
