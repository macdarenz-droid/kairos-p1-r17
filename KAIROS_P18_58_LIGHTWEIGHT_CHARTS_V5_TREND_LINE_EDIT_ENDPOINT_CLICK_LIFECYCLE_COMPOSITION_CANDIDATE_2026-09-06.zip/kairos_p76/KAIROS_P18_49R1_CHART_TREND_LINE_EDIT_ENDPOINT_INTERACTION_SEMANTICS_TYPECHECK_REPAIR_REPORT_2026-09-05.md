# KAIROS P18.49R1 — Chart Trend-Line Edit Endpoint Interaction Semantics Typecheck Repair

## Authority
Rebuilt directly from canonical P18.48, Kairos Controlled Roadmap Gate #255 / run `33959073188` / head `acab5131cb01b4191ca7b6d63435069205bd9a29`.

Failed P18.49 run #256 / run `33960306056` / job `101290932557` is evidence only and is not a base.

## Canonical failure classification
P18.49 passed archive extraction, exact 12-file scope, deterministic install, and exact Lightweight Charts 5.2.1, then failed production TypeScript compilation before build/runtime regressions.

The compiler reported exactly two fixture defects:
1. `tests/chart-drawing-interaction-reducer.test.ts` attached `endpoint` to a `commit-drawing` event, which correctly rejects that property because only `start-editing` owns edit endpoint intent.
2. historical `tests/chart-drawing-selection-presentation-projection.test.ts` created a shared `{ status: 'editing' | 'deleting', drawingId }` object. P18.49 intentionally requires an endpoint only when the discriminant is `editing`, so the historical fixture must construct the two valid states separately.

Classification: candidate-side test/type-contract repair. The canonical gate is correct. P18.49 production interaction semantics are preserved.

## Preserved P18.49 responsibility
P18.49R1 keeps the intended controlled amendment to the existing P18.21/P18.22/P18.23 owners:
- `start-editing` carries explicit `ChartTrendLineEditEndpoint`;
- accepted `editing` state stores matching drawing ID + exact endpoint;
- editing still starts only from authoritative `selected` state with matching drawing ID;
- invalid state/identity combinations remain no-ops;
- P18.24 remains sole current interaction-state/dispatch owner;
- P18.48 remains sole edit-endpoint vocabulary and pure edit-construction owner.

## Repair
- remove the invalid `endpoint` property from the `commit-drawing` no-op fixture;
- amend the historical P18.43 presentation fixture to create a valid `editing` state with endpoint and a separate valid `deleting` state without endpoint;
- keep the earlier narrow P18.48 historical verifier compatibility amendment so later interaction-state fields do not invalidate P18.48's edit-construction contract;
- add a dedicated P18.49R1 verifier that pins both TypeScript fixture repairs and all P18.49 ownership boundaries.

No production type was weakened and no provider/business/persistence owner changed.

## Explicit non-scope
No provider pointer/drag subscription; no hit testing; no anchor projection; no edit construction change; no collection replacement; no edit execution; no presentation refresh; no deletion execution change; no persistence/restore; no undo/redo; no toolbar/UI styling; no new drawing kinds; no Risk/Reward/P19; no journal/calculation/navigation truth; no dependency/toolchain migration.

## Canonical requirement
Before promotion, the canonical gate must prove exact P18.48 -> P18.49R1 scope, deterministic install, exact Lightweight Charts 5.2.1, production TypeScript/build, dedicated P18.49R1 verifier/runtime, historical P18.21/P18.22/P18.23/P18.24/P18.38/P18.43/P18.48 compatibility, focused runtime tests, full units, full roadmap through P18.49R1, P18.49R1 -> P17 regressions, historical closures, candidate artifact, and gate evidence.

## Local verification
PASS:
- dedicated P18.49R1 repair verifier;
- historical P18.48 edit-construction verifier;
- all `verify:p18:*` scripts through P18.49R1: 49/49;
- all other `verify:p*` scripts except dependency-backed `verify:p1`: 152/152;
- 201/201 non-P1-wrapper roadmap verifier contracts overall;
- P1 static/toolchain contract: 209 source files, 17 pinned package versions;
- historical P18.43 selection-presentation verifier after the narrow fixture compatibility repair.

Local dependency limitation:
- a clean `npm ci --no-audit --no-fund` attempt exceeded the local container transport window and left an incomplete install; the orphan install process was terminated and all dependency residue is removed before packaging;
- a subsequent TypeScript invocation on that incomplete install failed only because required type packages were absent, so it is not valid integration evidence and is not counted as a candidate failure;
- therefore local production TypeScript/build/Vitest/full-unit/dependency-backed P1 PASS are not claimed. Canonical GitHub Actions must establish them.
