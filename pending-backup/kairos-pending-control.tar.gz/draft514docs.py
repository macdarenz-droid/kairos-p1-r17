"""Insert Gate514 continuity entries into the work514 docs. Reads Gate513 evidence from gate513-evidence.txt, zip513.txt and head513.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate513-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip513.txt').read().split()
HEAD=open(sp+'head513.txt').read().strip()
root=sp+'work514/kairos_p76/docs/'
label="**Patch label:** P30.2 · P30 Trade record lifecycle: delete · owner phase P30 (active from the Gate512 canonical PASS) · definition: the visible, confirmed delete of one saved trade on the released history card for the Journal and Practice lists, through the P30.1 command, proven in unit tests and a real browser."
ev=f"Gate513/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P30_1_TRADE_RECORD_DELETE_COMMAND_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate512 is the immediate rollback. P30.1 is canonical."
approval=f"""## Manual Gate514 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the released history card already hosts a per-card control through optional ports on the history list, so the delete control follows that shape (a new `onTradeDeleted` port, mounted only with the database, both released mount lines keeping their literals); a trade is real journal data, so unlike the P24.2 saved-record delete the control asks for an explicit inline confirmation naming the trade and its fills and fees and reminding that an earlier backup keeps it; the Journal reuses its revision path so the daily results refresh through their released owner. P30.2 adds `src/app/JournalTradeDeleteControl.tsx` on every Journal and Practice history card; the P29.3 Practice mount pin and the P30.1 history-card pin advanced to the new literals. Real browser evidence (`scripts/test-journal-trade-delete-browser.mjs`, `.trade-delete-evidence/`) proves two real Journal trades and one practice trade, a declined confirmation changing nothing, exactly the confirmed trade and its children removed with the others byte-identical, the practice trade removed from Practice with the journal untouched, and the confirmation at both viewports in both themes. UI VISIBLE:YES. P30.3 (closure) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate513

{label}

Gate513/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P30.1 (trade record delete command) is canonical. Gate512 remains its immediate rollback. The next slice (Gate514, P30.2) mounts the delete controls with browser evidence; P30.3 (closure) follows.

"""
arch=f"""## Gate514 P30.2 trade delete controls amendment

{label}

Gate513/run{RUN}/head{HEAD} is the latest FULL canonical release: the P30.1 trade record delete command. Gate512 is the immediate rollback.

The next slice adds `src/app/JournalTradeDeleteControl.tsx` and `src/app/journalTradeDelete.css`, the `onTradeDeleted` port on `src/app/JournalHistoryList.tsx` mounted by the Journal and Practice routes, the unit and real-browser evidence and `docs/KAIROS_JOURNAL_TRADE_DELETE.md`, and advances the P30 ledger below to P30.2. Every released mount line keeps its literals; the schema and the command are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate514' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate513 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate512',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate513 P30.1 trade record delete command amendment',arch)
print('inserted')
