"""Insert Gate527 continuity entries into the work527 docs. Reads Gate526 evidence from gate526-evidence.txt, zip526.txt and head526.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate526-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip526.txt').read().split()
HEAD=open(sp+'head526.txt').read().strip()
root=sp+'work527/kairos_p76/docs/'
label="**Patch label:** P34.3 · P34 Profile data safety: backup freshness and persistent storage · owner phase P34 (closure) · definition: source-proven closure of P34 and the definition of P35 from current ownership."
ev=f"Gate526/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P34_2_PROFILE_DATA_SAFETY_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate525 is the immediate rollback. P34.2 is canonical."
approval=f"""## Manual Gate527 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. P34.3 closes P34 with no production runtime change: the P34 ledger is SYSTEM CLOSED through P34.3, the closure report and whole-phase verifier prove the last-backup record and the device card extension retained with their verifiers, the Gate526 verifier pin on the P34 ledger heading advanced to the closure literal, and P35 (Practice trade lifecycle: fills, close and activation for paper trades) is defined from research: the released update and activation commands and controls are manual-only, so a practice trade can never take a fill, close or open from a draft. P35.1 (allowed-source option on the released commands) follows without a further prompt. UI VISIBLE:NO. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate526

{label}

Gate526/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P34.2 (Profile data safety) is canonical. Gate525 remains its immediate rollback. The next slice (Gate527, P34.3) closes P34 and defines P35 (Practice trade lifecycle).

"""
arch=f"""## Gate527 P34 closure and P35 definition amendment

{label}

Gate526/run{RUN}/head{HEAD} is the latest FULL canonical release: the P34.2 Profile data safety extension. Gate525 is the immediate rollback.

The next slice closes the P34 ledger below through P34.3 and defines P35 from ownership. No production runtime owner is added; every route, command and the schema are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate527' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate526 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate525',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate526 P34.2 Profile data safety amendment',arch)
print('inserted')
