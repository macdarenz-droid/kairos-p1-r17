"""Insert Gate476 continuity entries into the work476 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST (Gate475 evidence)"""
import sys
run,job,head,cid,cdig,eid,edig=sys.argv[1:8]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work476/kairos_p76/docs/'
label="**Patch label:** P21.25 · roadmap item 5 (exact trade overlays + P18 drawing create/edit/delete + P20 save/load round trips) · owner phase P21 (chart workspace integration, active) · definition: visible trend-line tool on the Analysis chart with real draw, select and delete evidence."
ev=f"Gate475/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_ANALYSIS_DRAWING_TOOLS_RENDERER_SESSION_CANDIDATE_2026-09-17.zip;3929189bytes;SHA256 503bfc116b4302ce3ceec48b968debbaa3be8720d51507c211d218325c11c9fe; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate474 is the immediate rollback."
approval=f"""## Manual Gate476 slice — 17 September 2026

{label}

{ev}

Under the user's roadmap-first authority (UI polish stays parked until the roadmap is done), the next item-5 step mounts the Gate475 session as the visible trend-line tool in KAIROS_ANALYSIS_DRAWING_TOOLS_MOUNT.md. `useAnalysisDrawingTools` owns one session per exact selection, resolves the stroke from the active chart theme's `drawingPrimary` token with the product width `ANALYSIS_DRAWING_TREND_LINE_WIDTH = 2`, mirrors the Gate474 seam's attach/detach into React, acknowledges the P18.35 commit back to idle so the released reducer can select, and destroys the session when the selection changes. The two released canvases take their session factories from React contexts (an explicit prop still wins) so their pinned mount literals are untouched; the workspace renders the "Drawing tools" toolbar (Trend line, Cancel, Delete line, polite guidance with the exact count) before the canvases. UI VISIBLE:YES. Real Chromium evidence (`scripts/test-analysis-drawing-tools-browser.mjs`, `.drawing-tools-evidence/`) proves two pane clicks draw a line whose midpoint pixels change, a click on the line selects it through the released P18.13 hit test, Delete restores the pane, a draft cancels after its first anchor, a committed line survives the switch to the saved-trade chart and is re-presented on the replacement series, no journal write, Ink/Paper at 320/390px. Two provider facts are recorded, not worked around: Lightweight Charts drops a second click inside its double-click window, and the guidance line re-wraps between states and moves the chart, so the evidence spaces pane clicks and resolves every point from the live canvas box. No persistence, journal, market, calculation, provider or navigation owner changes; endpoint edit (P18.58/P18.59) and the Saved Analysis P20 round trip follow one gate each. Candidate publication and complete canonical PASS remain mandatory; P21 stays active.

"""
plan=f"""## Status after FULL Gate475

{label}

Gate475/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present; the unmounted Analysis drawing-tools renderer session composes the released P18 layer, draft interaction, commit, selection and deletion owners around the Gate474 seam. Gate474 remains its immediate rollback. The next slice (Gate476, P21.25) mounts that session as the visible trend-line tool on both Analysis chart paths with real draw, select and delete browser evidence; endpoint edit (P21.26) and the Saved Analysis save/load round trip (P21.27) follow one gate each, then item 6. P21 stays active.

"""
arch=f"""## Gate476 Analysis drawing tools mount amendment

{label}

Gate475/run{run}/head{head} is the latest FULL canonical release: `createAnalysisDrawingToolsRendererSession` in `src/app/analysisDrawingToolsRendererSession.ts`. Gate474 is the immediate rollback.

The next slice mounts it: `src/app/analysisDrawingToolsComposition.ts` (theme-token stroke style, session creation, the base live route-session factory and the saved-trade overlay session factory that both carry the session's Gate474 lifecycle into `createLightweightChartsV5ProductionRendererFactory`), `src/app/analysisDrawingToolsContext.ts` (two React contexts the released canvases read as their default `createSession`), `src/app/useAnalysisDrawingTools.ts` (one session per exact selection, seam state mirrored into React, commit acknowledged to idle, destroy on change), `src/app/AnalysisDrawingToolsControls.tsx` (the toolbar), the workspace hook call, toolbar and providers, a route-scoped token-only CSS block before the Gate473 block, and `ANALYSIS_DRAWING_TREND_LINE_WIDTH` in the product policy. `analysisCandleRendererSession.ts`, the overlay owners and every data owner are unchanged. UI VISIBLE:YES. No product-domain, provider, persistence, journal or calculation owner changes; P17/P18/P19/P20 boundaries and P21 active status are unchanged.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate476' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate475 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate474',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate475 Analysis drawing-tools renderer session amendment',arch)
print('inserted')
