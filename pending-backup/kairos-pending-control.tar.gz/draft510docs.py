"""Insert Gate510 continuity entries into the work510 docs. Reads Gate509 evidence from gate509-evidence.txt, zip509.txt and head509.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate509-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip509.txt').read().split()
HEAD=open(sp+'head509.txt').read().strip()
root=sp+'work510/kairos_p76/docs/'
label="**Patch label:** P29.2 · P29 Practice foundation: paper trades · owner phase P29 (active from the Gate508 canonical PASS) · definition: the explicit source scope on the one released history seam so practice trades never enter real results, applied by the repository on the released indexed path."
ev=f"Gate509/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P29_1_PRACTICE_TRADE_COMMAND_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate508 is the immediate rollback. P29.1 is canonical."
approval=f"""## Manual Gate510 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: `listJournalHistory` is the only history seam behind every released real-result consumer, the P12 verifiers pin it to the repository's indexed newest-first bounded paths and forbid application-side filtering, and a new index would bump the P5 schema and P6 backup contract. P29.2 therefore adds `JournalHistoryScope` (`real` by default, `practice` on request) to the seam and a read-only `SourceScopedTradeRepository` view that walks the same indexes and skips out-of-scope records as the cursor passes them; every consumer keeps its lines and now excludes practice trades, exact-id review stays unscoped, and the Gate508/Gate509 pins that asserted the seam carried no source literal advanced to the scope literal. The Practice placeholder is untouched until P29.3. UI VISIBLE:NO. P29.3 (Practice route) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate509

{label}

Gate509/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P29.1 (practice trade command) is canonical. Gate508 remains its immediate rollback. The next slice (Gate510, P29.2) is real-result isolation; P29.3 (Practice route) and P29.4 (closure) follow.

"""
arch=f"""## Gate510 P29.2 real-result isolation amendment

{label}

Gate509/run{RUN}/head{HEAD} is the latest FULL canonical release: the P29.1 practice trade command. Gate508 is the immediate rollback.

The next slice adds the source scope to `src/application/journal/historyQuery.ts` and the scoped view to `src/data/repositories/TradeRepositories.ts`, and advances the P29 ledger below to P29.2. Every consumer line, the schema and every route are unchanged; Practice stays a placeholder. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate510' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate509 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate508',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate509 P29.1 practice trade command amendment',arch)
print('inserted')
