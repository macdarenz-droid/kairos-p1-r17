"""Pin Gate519 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate518 zip, prev = Gate517 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P32_1_TRADE_MERGE_IMPORT_COMMAND_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P31_3_DRAFT_ACTIVATION_CLOSURE_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P31_2_DRAFT_TRADE_ACTIVATION_CONTROL_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P31.3 Draft Activation Closure','name: Kairos Controlled Roadmap Gate — P32.1 Trade Merge-Import Command')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P31.3 closure scope from Gate517','      - name: Confirm exact P32.1 trade merge-import command scope from Gate518')
start=s.index("          expected = {\n            'KAIROS_P31_3_DRAFT_ACTIVATION_CLOSURE_REPORT_2026-09-18.md',")
end=s.index("            print('P31.3 closure scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P32_1_TRADE_MERGE_IMPORT_COMMAND_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p31-3-draft-activation-closure.mjs',
            'scripts/verify-p32-1-trade-merge-import-command.mjs',
            'src/application/backup/importTrades.ts',
            'src/application/backup/index.ts',
            'tests/trade-import-command.test.ts',
          }
          if changed != expected or removed:
            print('P32.1 trade merge-import command scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P31.3 draft activation closure\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P32.1 trade merge-import command
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p32:1-trade-merge-import-command
          npm run verify:p31:3-draft-activation-closure
          npm run verify:p28:2-backup-restore-command
          npm run verify:p6:restore-preflight
          npx vitest run \\
            tests/trade-import-command.test.ts \\
            tests/backup-restore-command.test.ts \\
            tests/restore-preflight.test.ts \\
            tests/journal-history-scope.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p31:3-draft-activation-closure',""","""          for (const required of [
            'verify:p32:1-trade-merge-import-command',
            'verify:p31:3-draft-activation-closure',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P31_3_DRAFT_ACTIVATION_CLOSURE_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P32_1_TRADE_MERGE_IMPORT_COMMAND_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P31_3_DRAFT_ACTIVATION_CLOSURE_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate519')
