"""Insert Gate519 continuity entries into the work519 docs. Reads Gate518 evidence from gate518-evidence.txt, zip518.txt and head518.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate518-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip518.txt').read().split()
HEAD=open(sp+'head518.txt').read().strip()
root=sp+'work519/kairos_p76/docs/'
label="**Patch label:** P32.1 · P32 Journal import: merge trades from a backup · owner phase P32 (active from the Gate518 canonical PASS) · definition: the two-step application command that adds the trades a Kairos backup holds and this device lacks, with their own plans, executions and fees, in one atomic write, never touching an existing record."
ev=f"Gate518/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P31_3_DRAFT_ACTIVATION_CLOSURE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate517 is the immediate rollback. P31 is SYSTEM CLOSED through P31.3."
approval=f"""## Manual Gate519 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the P6.3 preflight already parses, migrates and validates a backup without touching the database, trade ids are the merge key because the backup carries every trade with its stable id and its children by trade id, real sources arrive as `import` for provenance while practice sources keep their scope, and a child id already on the device is refused rather than guessed. P32.1 adds `src/application/backup/importTrades.ts`: prepare (size guard, preflight, selection of the trades this device lacks with their children, preview with counts, nothing written) and the confirmed commit (one atomic write, ids re-checked, a trade that appeared meanwhile skipped, nothing existing replaced). The Gate518 verifier pin that asserted no import command existed advanced to the command literal; the Profile page carries no control until P32.2. UI VISIBLE:NO. P32.2 (Profile import control) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate518

{label}

Gate518/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P31 is SYSTEM CLOSED through P31.3 and P32 is defined from research. Gate517 remains its immediate rollback. The next slice (Gate519, P32.1) is the merge-import command; P32.2 (Profile import control) and P32.3 (closure) follow.

"""
arch=f"""## Gate519 P32.1 trade merge-import command amendment

{label}

Gate518/run{RUN}/head{HEAD} is the latest FULL canonical release: the P31 closure. Gate517 is the immediate rollback.

The next slice adds `src/application/backup/importTrades.ts` (exported through `src/application/backup/index.ts`) and starts the P32 ledger below at P32.1. P6, P28, the shell and every route are unchanged; the Profile page carries no import control yet. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate519' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate518 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate517',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate518 P31 closure and P32 definition amendment',arch)
print('inserted')
