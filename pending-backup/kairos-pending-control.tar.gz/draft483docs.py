"""Insert Gate483 continuity entries into the work483 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST ZIP_SIZE ZIP_SHA (Gate482 evidence + Gate482 zip)"""
import sys
run,job,head,cid,cdig,eid,edig,zsize,zsha=sys.argv[1:10]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work483/kairos_p76/docs/'
label="**Patch label:** P22.4 · P22 time-assisted trade snapshot · owner phase P22 (active) · definition: the estimated entry/exit markers drawn on the containing candles of both Analysis chart paths for the current time-assisted snapshot, labelled as estimates, carrying no price, with real browser evidence and no journal write."
ev=f"Gate482/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_ANALYSIS_TIME_ASSISTED_SNAPSHOT_PREVIEW_CANDIDATE_2026-09-17.zip;{zsize}bytes;SHA256 {zsha}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate481 is the immediate rollback."
approval=f"""## Manual Gate483 slice — 17 September 2026

{label}

{ev}

Under the user's autonomous-continuation authority, the time-assisted estimates reach the chart in KAIROS_ANALYSIS_TIME_ASSISTED_ESTIMATE_MARKERS.md: a marker binding and candlestick-series session (mirroring the released saved-trade marker binding) place "Est. entry"/"Est. exit" vendor markers on each estimate's containing candle, below or above the bar by side, with no price; one session per selection is re-presented on theme change and on every series the production renderer attaches. The Gate476 composition and hook take an optional candlestick series lifecycle (base path straight into the renderer factory; saved-trade path fanned out with the overlay's own lifecycle), and the three Gate476-pinned literals that change are updated to the new literals in that verifier. The preview publishes every result and shows the marker state. UI VISIBLE:YES. Real Chromium evidence (`scripts/test-analysis-time-assisted-markers-browser.mjs`, `.time-assisted-markers-evidence/`) proves two markers after an estimate with the entry candle's column repainted, one marker with a future exit ("exit not placed"), none with a future entry, byte-identical journal facts and Ink/Paper at 320/390px. Candle-window navigation to the trade interval and P22 closure follow one gate each. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate482

{label}

Gate482/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present: the time-assisted snapshot preview is visible on the Analysis page. Gate481 remains its immediate rollback. The next slice (Gate483, P22.4) draws the estimates as markers on both chart paths; window navigation and P22 closure follow.

"""
arch=f"""## Gate483 P22.4 time-assisted estimate markers amendment

{label}

Gate482/run{run}/head{head} is the latest FULL canonical release: `src/app/AnalysisTimeAssistedSnapshotControls.tsx` mounted by the workspace. Gate481 is the immediate rollback.

The next slice adds `src/app/analysisTimeAssistedMarkerBinding.ts`, `src/app/analysisTimeAssistedMarkerSession.ts` (with `composeCandlestickSeriesLifecycles`) and `src/app/useAnalysisTimeAssistedMarkers.ts`; the Gate476 composition and hook carry an optional candlestick series lifecycle into both chart paths; the workspace wires the marker binding to the preview. The P22.4 ledger row is below. P17 rendering, the saved-trade marker owners, the journal owners and every other P21 mount are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate483' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate482 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate481',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate482 P22.3 time-assisted snapshot preview amendment',arch)
print('inserted')
