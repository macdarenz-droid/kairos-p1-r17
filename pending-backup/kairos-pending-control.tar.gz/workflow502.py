"""Pin Gate502 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate501 zip, prev = Gate500 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P27_1_SAVED_RECORD_INDEX_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P26_4_GOALS_FOUNDATION_CLOSURE_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P26_3_GOALS_ROUTE_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P26.4 Goals Foundation Closure','name: Kairos Controlled Roadmap Gate — P27.1 Saved Record Index')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P26.4 closure scope from Gate500','      - name: Confirm exact P27.1 saved record index scope from Gate501')
start=s.index("          expected = {\n            'KAIROS_P26_4_GOALS_FOUNDATION_CLOSURE_REPORT_2026-09-18.md',")
end=s.index("            print('P26.4 closure scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P27_1_SAVED_RECORD_INDEX_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p27-1-saved-record-index.mjs',
            'src/application/library/index.ts',
            'src/application/library/savedRecordIndex.ts',
            'tests/saved-record-index.test.ts',
          }
          if changed != expected or removed:
            print('P27.1 saved record index scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P26.4 goals foundation closure\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P27.1 saved record index
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p27:1-saved-record-index
          npm run verify:p26:4-goals-foundation-closure
          npm run verify:p20:2-saved-analysis-persistence-foundation
          npm run verify:p23:4-saved-time-assisted-snapshot-application-read
          npx vitest run \\
            tests/saved-record-index.test.ts \\
            tests/saved-analysis-persistence.test.ts \\
            tests/saved-time-assisted-snapshot-load-query.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p26:4-goals-foundation-closure',""","""          for (const required of [
            'verify:p27:1-saved-record-index',
            'verify:p26:4-goals-foundation-closure',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P26_4_GOALS_FOUNDATION_CLOSURE_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P27_1_SAVED_RECORD_INDEX_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P26_4_GOALS_FOUNDATION_CLOSURE_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate502')
