"""Pin Gate515 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate514 zip, prev = Gate513 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P30_3_TRADE_RECORD_LIFECYCLE_CLOSURE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P30_2_TRADE_DELETE_CONTROLS_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P30_1_TRADE_RECORD_DELETE_COMMAND_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P30.2 Trade Delete Controls','name: Kairos Controlled Roadmap Gate — P30.3 Trade Record Lifecycle Closure')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P30.2 trade delete controls scope from Gate513','      - name: Confirm exact P30.3 closure scope from Gate514')
start=s.index("          expected = {\n            'KAIROS_P30_2_TRADE_DELETE_CONTROLS_REPORT_2026-09-18.md',")
end=s.index("            print('P30.2 trade delete controls scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P30_3_TRADE_RECORD_LIFECYCLE_CLOSURE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p30-2-trade-delete-controls.mjs',
            'scripts/verify-p30-3-trade-record-lifecycle-closure.mjs',
          }
          if changed != expected or removed:
            print('P30.3 closure scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P30.2 trade delete controls\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P30.3 trade record lifecycle closure
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p30:3-trade-record-lifecycle-closure
          npm run verify:p30:2-trade-delete-controls
          npm run verify:p30:1-trade-record-delete-command
          npx vitest run \\
            tests/journal-trade-delete-control.test.tsx \\
            tests/trade-record-delete-command.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p30:2-trade-delete-controls',""","""          for (const required of [
            'verify:p30:3-trade-record-lifecycle-closure',
            'verify:p30:2-trade-delete-controls',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P30_2_TRADE_DELETE_CONTROLS_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P30_3_TRADE_RECORD_LIFECYCLE_CLOSURE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P30_2_TRADE_DELETE_CONTROLS_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate515')
