"""Insert Gate479 continuity entries into the work479 docs (Gate478 evidence is fixed)."""
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work479/kairos_p76/docs/'
label="**Patch label:** P21.28 · roadmap item 6 (review and remaining roadmap) · owner phase P21 (chart workspace integration) · definition: source-proven closure of the P21 chart workspace integration and the definition of P22 (time-assisted trade snapshot) from current ownership."
ev="Gate478/run35247137552/job105290112073/head7d66043 is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE10509556257 (GitHub digest sha256:70a8926314ab078c8c4a44f5dfb885da78bce77fc041d75835302a9a1d79857a) and KAIROS_GATE_EVIDENCE10508952735 (GitHub digest sha256:3b50dbad6f4b9a8c87f6317d817ef14d28ec89d8b161015eaac82968c4732cbe) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_ANALYSIS_SAVED_ANALYSIS_ROUND_TRIP_CANDIDATE_2026-09-17.zip;3977825bytes;SHA256 4176c773b86879393fe269eb5bdc7919770704598df9c588beff99a11aba5926; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run35249940778, completed success). Gate477 is the immediate rollback."
approval=f"""## Manual Gate479 slice — 17 September 2026

{label}

{ev}

User instruction after item 5 landed, 17 September 2026: "continue. if u done with all slice needed enable autonomous". This is the authority for item 6: P21 review and closure proceed autonomously; it is recorded as autonomous continuation, not as a physical UI review, which the user deferred to the whole-app checkpoint ("for ui, ill inspect once the whole app is done"). The closure is a verification/docs/package boundary: `KAIROS_P21_28_CHART_WORKSPACE_INTEGRATION_CLOSURE_REPORT_2026-09-17.md` and `scripts/verify-p21-28-chart-workspace-integration-closure.mjs` prove every gap-ledger row against current source (Your Trades sizing owner; Journal cards linking to the saved trade on actual candles with the P14 not-to-scale card map retained; the chart-first workspace mount; the live-candle owners; the mounted drawing/Risk-Reward/save UI) and require every P21 verifier registration to be retained. KAIROS_ARCHITECTURE_MAP.md gains the P21 ownership ledger (SYSTEM CLOSED through P21.28) and the P22 definition; KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md gains the verified gap ledger and the closed roadmap state. P22 is defined from ownership as the time-assisted trade snapshot researched at the user's request (KAIROS_TIME_BASED_TRADE_SNAPSHOT_FEASIBILITY.md): P15/P16 history lookup, P17 rendering, P10/P14 boundaries, with the estimated-reference contract as the only new owner, and it may not begin before this closure's canonical PASS. UI VISIBLE:NO (no production runtime change). Decisions kept for the user's whole-app review: Saved Analyses store drawings only (`riskRewards` empty); Ink amendments stay parked; the vendor drops a second pane click inside its double-click window. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate478

{label}

Gate478/run35247137552/head7d66043 is FULL canonical PASS with every stage and both exact-run artifacts present; the Saved Analysis save/list/load round trip is mounted and item 5 is complete. Gate477 remains its immediate rollback. The next slice (Gate479, P21.28) is item 6: the source-proven P21 closure under the user's autonomous-continuation authority, with the physical UI inspection deferred to the whole-app checkpoint, and P22 defined from ownership as the time-assisted trade snapshot. After Gate479 passes, P22.1 (estimated-reference contract and readonly lookup boundary) is the next slice.

"""
arch=f"""## Gate479 P21 closure and P22 definition amendment

{label}

Gate478/run35247137552/head7d66043 is the latest FULL canonical release: the Saved Analysis round trip (`src/app/analysisSavedAnalysisRoundTrip.ts`, `src/app/AnalysisSavedAnalysisControls.tsx`, `loadDrawings` on the drawing-tools session). Gate477 is the immediate rollback.

The closure slice adds no production runtime owner: the P21 ownership ledger below (SYSTEM CLOSED through P21.28), the Core Truth row for P21, the P22 definition (time-assisted trade snapshot, from ownership, not begun), the root closure report and its verifier, and the package registration. P11/P14–P20 boundaries are unchanged.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate479' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate478 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate477',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate478 Analysis Saved Analysis round trip amendment',arch)
print('inserted')
