"""Insert Gate489 continuity entries into the work489 docs. Reads Gate488 evidence from gate488-evidence.txt (RUN JOB ART_CAND ART_CAND_SHA ART_EV ART_EV_SHA MAINRUN) and zip488.txt (SIZE SHA)."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate488-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip488.txt').read().split()
HEAD=open(sp+'head488.txt').read().strip()
root=sp+'work489/kairos_p76/docs/'
label="**Patch label:** P23.4 · P23 durable time-assisted snapshot provenance · owner phase P23 (active from the Gate485 canonical PASS) · definition: the application read boundary that loads one saved time-assisted snapshot by its canonical stable id and lists the saved snapshots newest first."
ev=f"Gate488/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P23_3_SAVED_TIME_ASSISTED_SNAPSHOT_APPLICATION_SAVE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate487 is the immediate rollback. P23.3 is canonical."
approval=f"""## Manual Gate489 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 decision ("1": proceed with P23 under the same gate discipline). P23.4 adds `src/application/saved-time-assisted-snapshot/loadSavedTimeAssistedSnapshot.ts`: `loadSavedTimeAssistedSnapshot` reads one record by canonical stable id with explicit not-found and storage-error results, and `listSavedTimeAssistedSnapshots` lists the store newest save first (ties by id) as a frozen, clone-safe projection with its own storage-error result. No write, update or delete, no estimate acquisition, no query index. UI VISIBLE:NO. P23.5 (preview save/list/load UI with browser evidence) may not begin before this PASS. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate488

{label}

Gate488/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P23.3 (application save command) is canonical. Gate487 remains its immediate rollback. The next slice (Gate489, P23.4) is the application read boundary (load-one and list); P23.5 (preview UI save/list/load) follows.

"""
arch=f"""## Gate489 P23.4 saved time-assisted snapshot application read amendment

{label}

Gate488/run{RUN}/head{HEAD} is the latest FULL canonical release: the P23.3 save command. Gate487 is the immediate rollback.

The next slice adds `src/application/saved-time-assisted-snapshot/loadSavedTimeAssistedSnapshot.ts` (exported from the application index) and advances the P23 ledger below to P23.4. P22, P23.1–P23.3, P20 and the journal owners are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate489' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate488 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate487',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate488 P23.3 saved time-assisted snapshot application save amendment',arch)
print('inserted')
