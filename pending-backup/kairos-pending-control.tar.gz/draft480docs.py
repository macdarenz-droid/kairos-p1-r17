"""Insert Gate480 continuity entries into the work480 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST (Gate479 evidence; Gate479 zip fixed)"""
import sys
run,job,head,cid,cdig,eid,edig=sys.argv[1:8]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work480/kairos_p76/docs/'
label="**Patch label:** P22.1 · P22 time-assisted trade snapshot (defined from ownership at P21 closure) · owner phase P22 (active from the Gate479 canonical PASS) · definition: the estimated market-reference contract and its readonly lookup boundary over the released P15/P16 candle history port."
ev=f"Gate479/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P21_28_CHART_WORKSPACE_INTEGRATION_CLOSURE_CANDIDATE_2026-09-17.zip;3986020bytes;SHA256 0705244ac35a1c202ba3ff1a2543593e7fcaef5d4430e2aef2432c4581ea6daa; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate478 is the immediate rollback. P21 is SYSTEM CLOSED through P21.28; P22 is active from this PASS."
approval=f"""## Manual Gate480 slice — 17 September 2026

{label}

{ev}

Under the user's autonomous-continuation authority, P22 begins with its foundation: `KAIROS_P22_1_ESTIMATED_MARKET_REFERENCE_FOUNDATION_REPORT_2026-09-17.md` and `src/application/market-reference/estimatedMarketReference.ts`. `estimateMarketReferenceAt` makes one readonly call to the released P15/P16 candle history port for exactly the one-minute candle containing the requested instant and returns a frozen `candle-range` estimate with provenance (exact candle, gap from the candle open, UTC-normalised instant, acquisition time) and no single price field, per the feasibility policy (no interpolation, no candle-close-at-entry assumption); unparsable and future instants fail closed without touching the port; released port failures, empty pages and non-containing candles are reported as unavailable. UI VISIBLE:NO. No UI, route, persistence, Saved Analysis extension, chart marker, aggregate-trade lookup or journal-truth change; P10/P11/P13/P14 results are untouched and an estimate never populates an execution record. The visible time-assisted preview (inputs, lookup for opening and closing instants, disclosed estimated markers on the released chart) follows in later P22 slices, one gate each. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate479

{label}

Gate479/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present: P21 is SYSTEM CLOSED through P21.28 and P22 (time-assisted trade snapshot) is defined from ownership. Gate478 remains its immediate rollback. The next slice (Gate480, P22.1) adds the estimated market-reference contract and readonly lookup boundary; the visible preview follows. This plan's P21 ledger is closed; P22 slices are recorded here as status only.

"""
arch=f"""## Gate480 P22.1 estimated market-reference foundation amendment

{label}

Gate479/run{run}/head{head} is the latest FULL canonical release: the P21 closure report and verifier, the P21 ownership ledger and the P22 definition. Gate478 is the immediate rollback.

The next slice adds `src/application/market-reference/estimatedMarketReference.ts` (exported through the market-reference index): the `EstimatedMarketReference` contract (`candle-range` with provenance, or `unavailable` with the released reasons) and `estimateMarketReferenceAt` over the released P15/P16 history port. The P22 ledger below starts at P22.1. P15/P16 request/response contracts, the journal owners and every P21 mount are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate480' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate479 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate478',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate479 P21 closure and P22 definition amendment',arch)
print('inserted')
