"""Insert Gate495 continuity entries into the work495 docs. Reads Gate494 evidence from gate494-evidence.txt, zip494.txt and head494.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate494-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip494.txt').read().split()
HEAD=open(sp+'head494.txt').read().strip()
root=sp+'work495/kairos_p76/docs/'
label="**Patch label:** P25.1 · P25 saved record labels · owner phase P25 (active from the Gate494 canonical PASS) · definition: the optional user-given label on Saved Analyses and saved time-assisted snapshots, its policy, its acceptance in persistence validation and its save-time normalisation."
ev=f"Gate494/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P24_3_SAVED_RECORD_LIFECYCLE_CLOSURE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate493 is the immediate rollback. P24 is SYSTEM CLOSED through P24.3."
approval=f"""## Manual Gate495 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule (no per-patch UI review; continue; settle decisions by research). Research settled the design: the field is `label` (the P23.1 verifier forbids `displayName`); Dexie needs no index or migration for an optional field; an absent label stays valid so the V4 backup format and every released record restore unchanged; the P23.3 pinned invalid-reason union advances to include `label-invalid`. P25.1 adds `src/app/savedRecordLabel.ts` (trim, blank = absent, at most 80 characters, stored-form acceptance), the optional `label` on both contracts, acceptance in backup validation and integrity, and save-time normalisation with explicit invalid-input results in the P20.3 and P23.3 commands. UI VISIBLE:NO. P25.2 (label input and list presentation with browser evidence) begins after this PASS without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate494

{label}

Gate494/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P24 is SYSTEM CLOSED through P24.3 and P25 is defined from ownership. Gate493 remains its immediate rollback. The next slice (Gate495, P25.1) is the label foundation; P25.2 (input and list presentation) and P25.3 (closure) follow.

"""
arch=f"""## Gate495 P25.1 saved record label foundation amendment

{label}

Gate494/run{RUN}/head{HEAD} is the latest FULL canonical release: the P24 closure. Gate493 is the immediate rollback.

The next slice adds `src/app/savedRecordLabel.ts`, the optional `label` on both saved-record contracts, its acceptance in `backupValidation.ts` and `integrity.ts`, and its normalisation in the two save commands, and starts the P25 ledger below at P25.1. Schema v5 and backup format V4 are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate495' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate494 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate493',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate494 P24 closure and P25 definition amendment',arch)
print('inserted')
