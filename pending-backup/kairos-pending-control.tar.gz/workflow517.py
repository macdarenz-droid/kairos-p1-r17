"""Pin Gate517 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate516 zip, prev = Gate515 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P31_2_DRAFT_TRADE_ACTIVATION_CONTROL_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P31_1_DRAFT_TRADE_ACTIVATION_COMMAND_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P30_3_TRADE_RECORD_LIFECYCLE_CLOSURE_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P31.1 Draft Trade Activation Command','name: Kairos Controlled Roadmap Gate — P31.2 Draft Trade Activation Control')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P31.1 draft trade activation command scope from Gate515','      - name: Confirm exact P31.2 draft trade activation control scope from Gate516')
start=s.index("          expected = {\n            'KAIROS_P31_1_DRAFT_TRADE_ACTIVATION_COMMAND_REPORT_2026-09-18.md',")
end=s.index("            print('P31.1 draft trade activation command scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P31_2_DRAFT_TRADE_ACTIVATION_CONTROL_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_JOURNAL_DRAFT_ACTIVATION.md',
            'package.json',
            'scripts/test-journal-draft-activation-browser.mjs',
            'scripts/verify-p31-1-draft-trade-activation-command.mjs',
            'scripts/verify-p31-2-draft-trade-activation-control.mjs',
            'src/app/JournalDraftTradeActivation.tsx',
            'src/app/JournalHistoryList.tsx',
            'src/app/JournalRoute.tsx',
            'src/app/journalDraftTradeActivation.css',
            'tests/journal-draft-trade-activation.test.tsx',
          }
          if changed != expected or removed:
            print('P31.2 draft trade activation control scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P31.1 draft trade activation command\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P31.2 draft trade activation control
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p31:2-draft-trade-activation-control
          npm run verify:p31:1-draft-trade-activation-command
          npm run verify:p30:2-trade-delete-controls
          npm run verify:p12:journal-history-closure
          npm run verify:p12:journal-history-status-filter-ui
          npx vitest run \\
            tests/journal-draft-trade-activation.test.tsx \\
            tests/journal-trade-delete-control.test.tsx \\
            tests/journal-open-trade-update.test.tsx \\
            tests/journal-history-route.test.tsx \\
            tests/manual-trade-journal-route.test.tsx

"""+s[end:]
rep("          node scripts/test-journal-trade-delete-browser.mjs\n","          node scripts/test-journal-trade-delete-browser.mjs\n          node scripts/test-journal-draft-activation-browser.mjs\n")
rep("""          for (const required of [
            'verify:p31:1-draft-trade-activation-command',""","""          for (const required of [
            'verify:p31:2-draft-trade-activation-control',
            'verify:p31:1-draft-trade-activation-command',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P31_1_DRAFT_TRADE_ACTIVATION_COMMAND_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P31_2_DRAFT_TRADE_ACTIVATION_CONTROL_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/docs/KAIROS_JOURNAL_DRAFT_ACTIVATION.md
            .gate-candidate/kairos_p76/.draft-activation-evidence/
            .gate-candidate/kairos_p76/KAIROS_P31_1_DRAFT_TRADE_ACTIVATION_COMMAND_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate517')
