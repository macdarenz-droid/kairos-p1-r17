"""Insert Gate520 continuity entries into the work520 docs. Reads Gate519 evidence from gate519-evidence.txt, zip519.txt and head519.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate519-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip519.txt').read().split()
HEAD=open(sp+'head519.txt').read().strip()
root=sp+'work520/kairos_p76/docs/'
label="**Patch label:** P32.2 · P32 Journal import: merge trades from a backup · owner phase P32 (active from the Gate518 canonical PASS) · definition: the visible merge import of trades from a Kairos backup on the Profile page, through the P32.1 command, proven in unit tests and a real browser."
ev=f"Gate519/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P32_1_TRADE_MERGE_IMPORT_COMMAND_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate518 is the immediate rollback. P32.1 is canonical."
approval=f"""## Manual Gate520 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the Profile page already owns the file seam and the preview → confirm → outcome shape of the restore flow, so the import card follows it with its own state and picker and adds no new seam; a merge with nothing new is a legitimate preview with the confirmation disabled. P32.2 adds the Import trades card to `src/app/ProfileRoute.tsx` between the export and restore cards; the P32.1 verifier pin that asserted no import control existed advanced to the card literal. Real browser evidence (`scripts/test-profile-trade-import-browser.mjs`, `.trade-import-evidence/`) proves two real Journal trades, a real backup download, one trade deleted through the real control, the refused non-backup, the preview of exactly the deleted trade and its return with its id and source Import while the present trade stays byte-identical, and the preview at both viewports in both themes. UI VISIBLE:YES. P32.3 (closure) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate519

{label}

Gate519/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P32.1 (trade merge-import command) is canonical. Gate518 remains its immediate rollback. The next slice (Gate520, P32.2) mounts the Profile import control with browser evidence; P32.3 (closure) follows.

"""
arch=f"""## Gate520 P32.2 Profile import control amendment

{label}

Gate519/run{RUN}/head{HEAD} is the latest FULL canonical release: the P32.1 trade merge-import command. Gate518 is the immediate rollback.

The next slice adds the Import trades card to `src/app/ProfileRoute.tsx`, the unit and real-browser evidence and `docs/KAIROS_PROFILE_TRADE_IMPORT.md`, and advances the P32 ledger below to P32.2. Every released Profile card, port and literal, the command and the schema are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate520' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate519 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate518',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate519 P32.1 trade merge-import command amendment',arch)
print('inserted')
