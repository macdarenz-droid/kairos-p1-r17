"""Pin Gate478 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate477 zip, prev = Gate476 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — Analysis Drawing Tools Endpoint Edit','name: Kairos Controlled Roadmap Gate — Analysis Saved Analysis Round Trip')
rep("      - 'KAIROS_ANALYSIS_DRAWING_TOOLS_ENDPOINT_EDIT_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_ANALYSIS_SAVED_ANALYSIS_ROUND_TRIP_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_ANALYSIS_DRAWING_TOOLS_MOUNT_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_DRAWING_TOOLS_ENDPOINT_EDIT_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_ANALYSIS_DRAWING_TOOLS_ENDPOINT_EDIT_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_SAVED_ANALYSIS_ROUND_TRIP_CANDIDATE_2026-09-17.zip')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact Analysis drawing tools endpoint edit scope from Gate476','      - name: Confirm exact Analysis Saved Analysis round trip scope from Gate477')
rep("""          expected = {
            'docs/KAIROS_ANALYSIS_DRAWING_TOOLS_ENDPOINT_EDIT.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-drawing-tools-edit-browser.mjs',
            'scripts/verify-analysis-drawing-tools-endpoint-edit.mjs',
            'scripts/verify-analysis-drawing-tools-mount.mjs',
            'src/app/AnalysisDrawingToolsControls.tsx',
            'src/app/analysisDrawingToolsComposition.ts',
            'src/app/analysisDrawingToolsRendererSession.ts',
            'src/app/analysisLiveCandleProductPolicy.ts',
            'tests/analysis-drawing-tools-mount.test.tsx',
            'tests/analysis-drawing-tools-renderer-session.test.ts',
          }
          if changed != expected or removed:
            print('Analysis drawing tools endpoint edit scope mismatch', file=sys.stderr)""","""          expected = {
            'docs/KAIROS_ANALYSIS_SAVED_ANALYSIS_ROUND_TRIP.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-drawing-tools-browser.mjs',
            'scripts/test-analysis-drawing-tools-edit-browser.mjs',
            'scripts/test-analysis-saved-analysis-browser.mjs',
            'scripts/verify-analysis-saved-analysis-round-trip.mjs',
            'src/app/AnalysisHistoryWorkspace.tsx',
            'src/app/AnalysisSavedAnalysisControls.tsx',
            'src/app/analysisDrawingToolsRendererSession.ts',
            'src/app/analysisHistory.css',
            'src/app/analysisSavedAnalysisRoundTrip.ts',
            'src/app/useAnalysisDrawingTools.ts',
            'tests/analysis-drawing-tools-renderer-session.test.ts',
            'tests/analysis-saved-analysis-round-trip.test.tsx',
          }
          if changed != expected or removed:
            print('Analysis Saved Analysis round trip scope mismatch', file=sys.stderr)""")
rep("""            tests/lightweight-charts-v5-trend-line-edit-click-execution-lifecycle-composition.test.ts

      - name: Production TypeScript compilation""","""            tests/lightweight-charts-v5-trend-line-edit-click-execution-lifecycle-composition.test.ts

      - name: Analysis Saved Analysis round trip
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:analysis-saved-analysis-round-trip
          npm run verify:analysis-drawing-tools-endpoint-edit
          npm run verify:analysis-drawing-tools-mount
          npm run verify:analysis-drawing-tools-renderer-session
          npm run verify:analysis-history-workspace
          npm run verify:p20:5-saved-analysis-system-closure
          npx vitest run \\
            tests/analysis-saved-analysis-round-trip.test.tsx \\
            tests/analysis-drawing-tools-renderer-session.test.ts \\
            tests/analysis-drawing-tools-mount.test.tsx \\
            tests/analysis-history-workspace.test.tsx \\
            tests/saved-analysis-save-command.test.ts

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:analysis-drawing-tools-endpoint-edit',""","""          for (const required of [
            'verify:analysis-saved-analysis-round-trip',
            'verify:analysis-drawing-tools-endpoint-edit',""")
rep("""          node scripts/test-analysis-drawing-tools-edit-browser.mjs

      - name: Full unit regression""","""          node scripts/test-analysis-drawing-tools-edit-browser.mjs
          node scripts/test-analysis-saved-analysis-browser.mjs

      - name: Full unit regression""")
rep("""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_DRAWING_TOOLS_ENDPOINT_EDIT.md""","""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_SAVED_ANALYSIS_ROUND_TRIP.md
            .gate-candidate/kairos_p76/.saved-analysis-evidence/
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_DRAWING_TOOLS_ENDPOINT_EDIT.md""")
open(p,'w').write(s); print('workflow pinned for Gate478')
