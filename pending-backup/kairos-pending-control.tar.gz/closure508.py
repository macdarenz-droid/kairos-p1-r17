"""Apply the Gate508 (P28.4) closure ledger/plan edits to work508 (idempotent; run before draft508docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work508/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P28 canonical ownership ledger — ACTIVE through P28\.\d+', '## P28 canonical ownership ledger — SYSTEM CLOSED through P28.4', s, count=1)
row="| P28.4 | Profile foundation system closure | verification/docs/package boundary only; no production runtime owner added | Proves P28.1–P28.3 as the complete source-proven P28 boundary and defines P29 from ownership |\n"
anchor="the pre-restore copy on failure); no activation write, no verifier, no estimate |\n"
if row not in s:
    assert s.count(anchor)==1; s=s.replace(anchor, anchor+row, 1)
section="""## P28 Profile Foundation System Closure — P28.4

P28.4 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P28.1 backup export command, the P28.2 two-step restore command and the P28.3 Profile route are mounted and retained with their verifiers; the closure report is `KAIROS_P28_4_PROFILE_FOUNDATION_CLOSURE_REPORT_2026-09-18.md` and its verifier `scripts/verify-p28-4-profile-foundation-closure.mjs`. Profile never writes except through the explicitly confirmed P6 verified replacement, never verifies or alters the activation receipt, and leaves every released P6 owner byte-identical.

## P29 — Practice foundation: paper trades (defined from ownership, not begun)

Research against current source: `src/domain/trades/tradeTypes.ts` already defines `TradeSource = 'manual' | 'paper' | 'replay' | 'import' | 'broker-import'` and the P6 backup validation accepts every value, yet the only writer (`src/application/trades/saveManualTrade.ts`) records `source: 'manual'`, `updateOpenManualTrade` refuses any other source, and no reader filters by source: `listJournalHistory` in `src/application/journal/historyQuery.ts` is the one history seam behind the Journal history, Home Your Trades, the P13 daily results, the P26 Goals progress, the trade visualizer and the Analysis saved-trade selection, and it lists every trade whatever its source. `src/app/routes.tsx` still renders Practice (under More) as `PlaceholderRoute`. P29 makes Practice the paper-trading page in dependency order: P29.1 a practice trade command over the released P10 manual-trade draft validation and atomic write shape, recording `source: 'paper'` and never touching a manual trade (no new store, index or field); P29.2 real-result isolation, one seam: `listJournalHistory` gains an explicit source scope that defaults to real sources so paper trades never enter Journal history, Home Your Trades, daily results, Goals progress or Analysis saved-trade selection, proven per consumer with the released lines unchanged; P29.3 the Practice route replacing the placeholder with the practice trade form and the practice history (scope practice), plainly labelled as practice, with unit and real-browser evidence; and P29.4 the closure. Proven from ownership: P10 owns the trade draft and write, P12 the history seam, P5 the database, the shell navigation; the only new owners are the command, the scope and the route. P29 may not begin before that PASS (the Gate508 canonical PASS of P28.4).

"""
if '## P28 Profile Foundation System Closure — P28.4' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert s.count(anchor2)==1; s=s.replace(anchor2, section+anchor2, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Updated at Gate505: P28 ACTIVE (Profile foundation: your data) from the Gate504 canonical PASS."
add=" Updated at Gate508: P17–P28 closed; P29 defined (Practice foundation: paper trades), not begun; P30–P40 later."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
