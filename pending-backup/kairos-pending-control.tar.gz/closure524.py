"""Apply the Gate524 (P33.3) closure ledger/plan edits to work524 (idempotent; run before draft524docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work524/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P33 canonical ownership ledger — ACTIVE through P33\.\d+', '## P33 canonical ownership ledger — SYSTEM CLOSED through P33.3', s, count=1)
row="| P33.3 | Library import system closure | verification/docs/package boundary only; no production runtime owner added | Proves P33.1–P33.2 as the complete source-proven P33 boundary and defines P34 from ownership |\n"
anchor="every released Profile card and literal otherwise unchanged; no replacement of existing records |\n"
if row not in s:
    assert s.count(anchor)==1; s=s.replace(anchor, anchor+row, 1)
section="""## P33 Library Import System Closure — P33.3

P33.3 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P33.1 saved-record merge-import command and the P33.2 Profile import card extension are mounted and retained with their verifiers; the closure report is `KAIROS_P33_3_LIBRARY_IMPORT_CLOSURE_REPORT_2026-09-18.md` and its verifier `scripts/verify-p33-3-library-import-closure.mjs`. One chosen backup now adds the trades and saved records this device lacks, byte-identical, never replacing an existing record; with P28 (export, restore), P32 and P33 the device's data can be taken out, brought back whole, or merged.

## P34 — Profile data safety: backup freshness and persistent storage (defined from ownership, not begun)

Research against current source: `src/pwa/storageDurability.ts` already inspects whether the browser granted persistent storage and can request it (`requestPersistentStorage`), and `src/main.tsx` inspects it at startup, yet no route shows the state or offers the request, so a user never learns that the browser may evict the journal under storage pressure; and nothing records when a backup was last taken, so the Profile device card cannot say whether the data is backed up at all. Device-scoped metadata (`device.` prefix, excluded from backups by the released P5 scope rule) is the right home for both facts. P34 gives Profile its data-safety facts in dependency order: P34.1 a last-backup record over one device-scoped metadata key (written by an application command after a backup download is handed to the browser, read back as a moment or never; never inside a backup, never touched by restore or import); P34.2 the Profile device card extended with the last-backup moment, the storage-durability state in plain words and a "Keep my data on this device" request through the released owner, with unit and real-browser evidence; P34.3 the closure. Proven from ownership: the storage-durability owner keeps inspection and request, P5 the metadata store and the device scope, P28.1 the export, P28.3 the page; the only new owners are the record command and the card extension. P34 may not begin before that PASS (the Gate524 canonical PASS of P33.3).

"""
if '## P33 Library Import System Closure — P33.3' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert s.count(anchor2)==1; s=s.replace(anchor2, section+anchor2, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Updated at Gate522: P33 ACTIVE (Library import: merge saved records from a backup) from the Gate521 canonical PASS."
add=" Updated at Gate524: P17–P33 closed; P34 defined (Profile data safety: backup freshness and persistent storage), not begun; P35–P40 later."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
