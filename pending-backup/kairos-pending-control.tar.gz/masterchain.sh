#!/bin/bash
set -u
SP=/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad
REPO=/home/user/kairos-p1-r17
OWNER=macdarenz-droid
NAME=kairos-p1-r17
WORKFLOW_ID=347091198
BRANCH=claude/kairos-trading-journal-hftwax
LOG="$SP/masterchain.log"
echo "=== resuming $(date -u +%FT%TZ) ===" >> "$LOG"
log(){ echo "$(date -u +%T) $*" | tee -a "$LOG"; }
fail(){ log "STOPPED: $*"; echo MASTERCHAIN_FAILED >> "$LOG"; exit 1; }

api(){ curl -sS --max-time 30 -H "Authorization: token $GH_TOKEN" -H "Accept: application/vnd.github+json" -H "Content-Type: application/json" "$@"; }

wait_run(){
  local id=$1 s="" tries=0
  while true; do
    s=$(api "https://api.github.com/repos/$OWNER/$NAME/actions/runs/$id" | python3 -c "import sys,json; r=json.load(sys.stdin); print(r['status'])" 2>/dev/null)
    [ "$s" = "completed" ] && break
    tries=$((tries+1))
    if [ $tries -gt 300 ]; then echo "timeout"; return; fi
    sleep 25
  done
  api "https://api.github.com/repos/$OWNER/$NAME/actions/runs/$id" | python3 -c "import sys,json; r=json.load(sys.stdin); print(r['conclusion'])"
}

get_job_and_artifacts(){
  local id=$1
  JOB=$(api "https://api.github.com/repos/$OWNER/$NAME/actions/runs/$id/jobs" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['jobs'][0]['id'])")
  read -r AC ACS AE AES <<EOF
$(api "https://api.github.com/repos/$OWNER/$NAME/actions/runs/$id/artifacts" | python3 -c "
import json,sys
d=json.load(sys.stdin)
by={a['name']:a for a in d['artifacts']}
c=by['KAIROS_CURRENT_CANDIDATE']; e=by['KAIROS_GATE_EVIDENCE']
print(c['id'], c['digest'], e['id'], e['digest'])
")
EOF
}

find_run(){
  # $1 branch, $2 event, $3 short-sha
  local branch=$1 event=$2 sha=$3 rid=""
  for i in $(seq 1 24); do
    rid=$(api "https://api.github.com/repos/$OWNER/$NAME/actions/runs?branch=$branch&event=$event&per_page=5" | python3 -c "
import json,sys
d=json.load(sys.stdin)
for r in d['workflow_runs']:
    if r['head_sha'].startswith('$sha'):
        print(r['id']); break
")
    [ -n "$rid" ] && { echo "$rid"; return; }
    sleep 10
  done
  echo ""
}

sync_backup(){
  ( cd /tmp && rm -rf backup-sync && git clone -q --depth 1 --branch claude/kairos-pending-work-backup https://github.com/macdarenz-droid/kairos-p1-r17 backup-sync 2>>"$LOG" \
    && cd backup-sync \
    && tar -czf pending-backup/kairos-pending-control.tar.gz -C "$SP" \
         gatechain.sh gatepoll.sh pkgnext.sh reapply-ledger.py masterchain.sh \
         gatechain-plan.tsv gatechain-plan-remaining2.tsv masterchain.log \
         $(cd "$SP" && ls closure*.py draft*docs.py workflow*.py gate*-evidence.txt head*.txt zip*.txt 2>/dev/null) \
    && git add pending-backup/kairos-pending-control.tar.gz \
    && git commit -q -m "Progress sync: control files through Gate$1" --allow-empty \
    && git push -q origin claude/kairos-pending-work-backup ) >>"$LOG" 2>&1
}

PREV_ZIP="KAIROS_P26_4_GOALS_FOUNDATION_CLOSURE_CANDIDATE_2026-09-18.zip"

while IFS=$'\t' read -r N MODE ZIP TITLE; do
  log "=== Gate$N: mode=$MODE zip=$ZIP ==="
  cd "$SP" || fail "cannot cd to scratchpad"
  bash gatechain.sh "$N" "$PREV_ZIP" "$ZIP" "$MODE" "$TITLE" >> "$LOG" 2>&1
  rc=$?
  [ $rc -ne 0 ] && fail "gatechain.sh $N failed (rc=$rc) - see $LOG for the WORK VS PKG diff or other error"
  HEAD=$(cat "$SP/head$N.txt")

  cd "$REPO" || fail "cannot cd to repo"
  LOCALSHA=$(git rev-parse HEAD)
  REMOTESHA=$(git ls-remote origin "refs/heads/$BRANCH" | cut -f1)
  [ "$LOCALSHA" != "$REMOTESHA" ] && fail "Gate$N: local branch head ($LOCALSHA) does not match remote ($REMOTESHA) after gatechain.sh push"
  log "Gate$N head=$HEAD confirmed pushed to $BRANCH. Dispatching CI..."

  api -X POST "https://api.github.com/repos/$OWNER/$NAME/actions/workflows/$WORKFLOW_ID/dispatches" -d "{\"ref\":\"$BRANCH\"}" > /dev/null
  sleep 8
  RUNID=$(find_run "$BRANCH" "workflow_dispatch" "$HEAD")
  [ -z "$RUNID" ] && fail "Gate$N: could not find dispatched branch run for head $HEAD"
  log "Gate$N branch run: $RUNID (https://github.com/$OWNER/$NAME/actions/runs/$RUNID)"
  CONCL=$(wait_run "$RUNID")
  [ "$CONCL" != "success" ] && fail "Gate$N branch run $RUNID concluded '$CONCL'"
  log "Gate$N branch run PASSED"

  get_job_and_artifacts "$RUNID"
  echo "$RUNID $JOB $AC $ACS $AE $AES MAINRUN" > "$SP/gate$N-evidence.txt"

  git fetch origin main --quiet
  git checkout main --quiet
  git merge --ff-only "$BRANCH" || fail "Gate$N: FF merge to main failed"
  pushed=0
  for i in 1 2 3 4 5; do git push origin main && { pushed=1; break; }; sleep $((2**i)); done
  [ $pushed -eq 0 ] && fail "Gate$N: push to main failed after retries"
  git checkout "$BRANCH" --quiet
  log "Gate$N: main fast-forwarded to $HEAD and pushed"

  sleep 5
  MAINRUNID=$(find_run "main" "push" "$HEAD")
  [ -z "$MAINRUNID" ] && fail "Gate$N: could not find main push run for head $HEAD"
  log "Gate$N main run: $MAINRUNID (https://github.com/$OWNER/$NAME/actions/runs/$MAINRUNID)"
  MCONCL=$(wait_run "$MAINRUNID")
  [ "$MCONCL" != "success" ] && fail "Gate$N main run $MAINRUNID concluded '$MCONCL'"
  sed -i "s/ MAINRUN\$/ $MAINRUNID/" "$SP/gate$N-evidence.txt"
  log "Gate$N: FULLY LANDED on main (main run $MAINRUNID passed)"
  sync_backup "$N"

  PREV_ZIP="$ZIP"
done < "$SP/gatechain-plan-remaining2.tsv"

log "ALL GATES 499-529 SHIPPED AND LANDED ON MAIN"
echo MASTERCHAIN_DONE >> "$LOG"
