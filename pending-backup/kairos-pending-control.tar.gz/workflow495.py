"""Pin Gate495 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate494 zip, prev = Gate493 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P25_1_SAVED_RECORD_LABEL_FOUNDATION_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P24_3_SAVED_RECORD_LIFECYCLE_CLOSURE_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P24_2_SAVED_RECORD_DELETE_CONTROLS_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P24.3 Saved Record Lifecycle Closure','name: Kairos Controlled Roadmap Gate — P25.1 Saved Record Label Foundation')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P24.3 closure scope from Gate493','      - name: Confirm exact P25.1 saved record label foundation scope from Gate494')
start=s.index("          expected = {\n            'KAIROS_P24_3_SAVED_RECORD_LIFECYCLE_CLOSURE_REPORT_2026-09-18.md',")
end=s.index("            print('P24.3 closure scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P25_1_SAVED_RECORD_LABEL_FOUNDATION_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p23-3-saved-time-assisted-snapshot-application-save.mjs',
            'scripts/verify-p25-1-saved-record-label-foundation.mjs',
            'src/app/savedAnalysisContract.ts',
            'src/app/savedRecordLabel.ts',
            'src/app/savedTimeAssistedSnapshotContract.ts',
            'src/application/saved-analysis/saveSavedAnalysis.ts',
            'src/application/saved-time-assisted-snapshot/saveSavedTimeAssistedSnapshot.ts',
            'src/data/backup/backupValidation.ts',
            'src/data/database/integrity.ts',
            'tests/saved-record-label-foundation.test.ts',
          }
          if changed != expected or removed:
            print('P25.1 saved record label foundation scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P24.3 saved record lifecycle closure\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P25.1 saved record label foundation
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p25:1-saved-record-label-foundation
          npm run verify:p24:3-saved-record-lifecycle-closure
          npm run verify:p20:1-saved-analysis-contract-foundation
          npm run verify:p23:1-saved-time-assisted-snapshot-contract-foundation
          npm run verify:p20:3-saved-analysis-application-save
          npm run verify:p23:3-saved-time-assisted-snapshot-application-save
          npm run verify:p23:2-saved-time-assisted-snapshot-persistence-foundation
          npm run verify:p6:backup-envelope
          npx vitest run \\
            tests/saved-record-label-foundation.test.ts \\
            tests/saved-analysis-save-command.test.ts \\
            tests/saved-time-assisted-snapshot-save-command.test.ts \\
            tests/saved-time-assisted-snapshot-contract.test.ts \\
            tests/saved-analysis-persistence.test.ts \\
            tests/saved-time-assisted-snapshot-persistence.test.ts \\
            tests/backup-envelope.test.ts \\
            tests/restore-verification.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p24:3-saved-record-lifecycle-closure',""","""          for (const required of [
            'verify:p25:1-saved-record-label-foundation',
            'verify:p24:3-saved-record-lifecycle-closure',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P24_3_SAVED_RECORD_LIFECYCLE_CLOSURE_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P25_1_SAVED_RECORD_LABEL_FOUNDATION_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P24_3_SAVED_RECORD_LIFECYCLE_CLOSURE_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate495')
