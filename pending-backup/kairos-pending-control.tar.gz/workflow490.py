"""Pin Gate490 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate489 zip, prev = Gate488 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P23_5_SAVED_TIME_ASSISTED_SNAPSHOT_PREVIEW_ROUND_TRIP_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P23_4_SAVED_TIME_ASSISTED_SNAPSHOT_APPLICATION_READ_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P23_3_SAVED_TIME_ASSISTED_SNAPSHOT_APPLICATION_SAVE_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P23.4 Saved Time-Assisted Snapshot Application Read','name: Kairos Controlled Roadmap Gate — P23.5 Saved Time-Assisted Snapshot Preview Round Trip')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P23.4 saved time-assisted snapshot application read scope from Gate488','      - name: Confirm exact P23.5 saved time-assisted snapshot preview round trip scope from Gate489')
start=s.index("          expected = {\n            'KAIROS_P23_4_SAVED_TIME_ASSISTED_SNAPSHOT_APPLICATION_READ_REPORT_2026-09-18.md',")
end=s.index("            print('P23.4 saved time-assisted snapshot application read scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P23_5_SAVED_TIME_ASSISTED_SNAPSHOT_PREVIEW_ROUND_TRIP_REPORT_2026-09-18.md',
            'docs/KAIROS_ANALYSIS_SAVED_TIME_ASSISTED_SNAPSHOT_ROUND_TRIP.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-time-assisted-snapshot-saved-browser.mjs',
            'scripts/verify-analysis-time-assisted-snapshot-preview.mjs',
            'scripts/verify-p23-5-saved-time-assisted-snapshot-preview-round-trip.mjs',
            'src/app/AnalysisTimeAssistedSnapshotControls.tsx',
            'src/app/analysisHistory.css',
            'src/app/analysisSavedTimeAssistedSnapshotRoundTrip.ts',
            'tests/analysis-time-assisted-snapshot-saved-round-trip.test.tsx',
          }
          if changed != expected or removed:
            print('P23.5 saved time-assisted snapshot preview round trip scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P23.4 saved time-assisted snapshot application read\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P23.5 saved time-assisted snapshot preview round trip
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p23:5-saved-time-assisted-snapshot-preview-round-trip
          npm run verify:p23:4-saved-time-assisted-snapshot-application-read
          npm run verify:p23:3-saved-time-assisted-snapshot-application-save
          npm run verify:analysis-time-assisted-snapshot-preview
          npm run verify:analysis-time-assisted-estimate-markers
          npm run verify:analysis-time-assisted-window-navigation
          npm run verify:analysis-saved-analysis-round-trip
          npx vitest run \\
            tests/analysis-time-assisted-snapshot-saved-round-trip.test.tsx \\
            tests/analysis-time-assisted-snapshot-preview.test.tsx \\
            tests/analysis-time-assisted-markers-mount.test.tsx \\
            tests/analysis-time-assisted-window-mount.test.tsx \\
            tests/analysis-history-workspace.test.tsx \\
            tests/saved-time-assisted-snapshot-load-query.test.ts \\
            tests/saved-time-assisted-snapshot-save-command.test.ts

"""+s[end:]
rep("          node scripts/test-analysis-time-assisted-window-browser.mjs\n","          node scripts/test-analysis-time-assisted-window-browser.mjs\n          node scripts/test-analysis-time-assisted-snapshot-saved-browser.mjs\n")
rep("""          for (const required of [
            'verify:p23:4-saved-time-assisted-snapshot-application-read',""","""          for (const required of [
            'verify:p23:5-saved-time-assisted-snapshot-preview-round-trip',
            'verify:p23:4-saved-time-assisted-snapshot-application-read',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P23_4_SAVED_TIME_ASSISTED_SNAPSHOT_APPLICATION_READ_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P23_5_SAVED_TIME_ASSISTED_SNAPSHOT_PREVIEW_ROUND_TRIP_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_SAVED_TIME_ASSISTED_SNAPSHOT_ROUND_TRIP.md
            .gate-candidate/kairos_p76/.time-assisted-saved-evidence/
            .gate-candidate/kairos_p76/KAIROS_P23_4_SAVED_TIME_ASSISTED_SNAPSHOT_APPLICATION_READ_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate490')
