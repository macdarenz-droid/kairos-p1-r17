"""Apply the Gate531 (P36.1) ledger/plan edits to work531 (idempotent; run before draft531docs.py)."""
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work531/kairos_p76/docs/'
HOME="## Home Your Trades V1 candidate from Gate395"
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
head="## P36 — Discipline foundation: checklists, mistake tracking and discipline score (vision P22, discipline half; defined from the vision, not begun)\n\n"
note="_Status at Gate531: this definition was written at the P35 closure from the vision; P36 is now ACTIVE from the Gate530 canonical PASS (ledger below)._\n\n"
assert s.count(head)==1
if note not in s: s=s.replace(head, head+note, 1)
section="""## P36 canonical ownership ledger — ACTIVE through P36.1

| Patch | Canonical responsibility | Production owner seam | Boundary |
|---|---|---|---|
| P36.1 | Trade discipline record foundation | `src/domain/discipline/` (`TradeDisciplineRecord`, vocabularies, `isTradeDisciplineRecordShape`, `createTradeDisciplineId`); `src/data/database/schema.ts` (v6, `KAIROS_V6_STORES`), `src/data/database/migrations.ts` (`KAIROS_V6_MIGRATION`), `src/data/database/KairosDatabase.ts`, `src/data/database/integrity.ts`, `src/data/repositories/TradeDisciplineRepository.ts`, `src/data/backup/*` (format V5 ↔ schema 6) | Owns the one-per-trade discipline record (pre-trade checklist and post-trade review answers from fixed vocabularies, unique mistake tags, a bounded note, the answer moments; never price, quantity or result), its append-only v6 store `tradeDiscipline` (`&id,tradeId,updatedAt`), repository get/getByTradeId/list/put/delete/replaceAll, the closed integrity checks (shape, existing trade, one per trade) and the V5 backup envelope/snapshot/migration/validation/preflight/replacement/verification extension; V1–V4 backups stay accepted and migrate with an empty discipline store; no command, no UI, no score; the P30.1 delete is unchanged until P36.2 |

"""
if '## P36 canonical ownership ledger' not in s:
    assert s.count(HOME)==1; s=s.replace(HOME, section+HOME, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="P36 defined (Discipline foundation: checklists, mistake tracking and discipline score — vision P22, discipline half), not begun; P37 onward per the alignment forward sequence."
add=" Updated at Gate531: P36 ACTIVE (Discipline foundation: checklists, mistake tracking and discipline score — vision P22, discipline half) from the Gate530 canonical PASS."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('ledger edits applied')
