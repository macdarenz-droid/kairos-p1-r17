"""Pin Gate473 in the repo workflow. Usage: SIZE SHA"""
import sys
size,sha=sys.argv[1],sys.argv[2]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — Risk/Reward Ratio Projection','name: Kairos Controlled Roadmap Gate — Saved-Trade Position Box')
rep("      - 'KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RATIO_PROJECTION_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_ANALYSIS_SAVED_TRADE_POSITION_BOX_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_ANALYSIS_INK_PRESENTATION_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RATIO_PROJECTION_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RATIO_PROJECTION_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_SAVED_TRADE_POSITION_BOX_CANDIDATE_2026-09-17.zip')
rep("            ('BASE_ZIP', 3892168, '7202cbd0c0a8c4d50ef0a781c7386577bf54f44593ffd2034f59f1a06d4775b3'),\n            ('CANDIDATE_ZIP', 3898877, 'cc188ee190977d63778c5cbe77ab3bd7b47e33359fc62fae73c44d3e42dca46d'),",f"            ('BASE_ZIP', 3898877, 'cc188ee190977d63778c5cbe77ab3bd7b47e33359fc62fae73c44d3e42dca46d'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact Risk/Reward ratio projection scope from Gate471','      - name: Confirm exact saved-trade position box scope from Gate472')
rep("""          expected = {
            'docs/KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RATIO_PROJECTION.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-analysis-saved-trade-risk-reward-ratio-projection.mjs',
            'src/app/analysisSavedTradeRiskRewardRatioProjection.ts',
            'tests/analysis-saved-trade-risk-reward-ratio-projection.test.ts',
          }
          if changed != expected or removed:
            print('Risk/Reward ratio projection scope mismatch', file=sys.stderr)""","""          expected = {
            'docs/KAIROS_ANALYSIS_SAVED_TRADE_POSITION_BOX.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-position-box-browser.mjs',
            'scripts/verify-analysis-saved-trade-position-box.mjs',
            'src/app/AnalysisLiveCandleCanvas.tsx',
            'src/app/AnalysisSavedTradeOverlayLiveCandleCanvas.tsx',
            'src/app/AnalysisSavedTradeRiskRewardEvidencePresentation.tsx',
            'src/app/analysisHistory.css',
            'src/app/analysisSavedTradePositionBoxFormatting.ts',
            'tests/analysis-saved-trade-position-box.test.tsx',
          }
          if changed != expected or removed:
            print('Saved-trade position box scope mismatch', file=sys.stderr)""")
rep("""            tests/analysis-saved-trade-overlay-live-candle-composition.test.tsx

      - name: Production TypeScript compilation""","""            tests/analysis-saved-trade-overlay-live-candle-composition.test.tsx

      - name: Saved-trade position box
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:analysis-saved-trade-position-box
          npm run verify:analysis-saved-trade-risk-reward-ratio-projection
          npm run verify:analysis-live-candle-canvas-presentation
          npm run verify:analysis-live-candle-workspace-mount
          npm run verify:analysis-saved-trade-live-candle-composition
          npm run verify:analysis-saved-trade-overlay-live-candle-composition
          npm run verify:analysis-saved-trade-overlay-runtime-input-composition
          npm run verify:analysis-saved-trade-overlay-workspace-mount
          npm run verify:analysis-saved-trade-risk-reward-live-candle-composition
          npm run verify:analysis-history-workspace
          npm run verify:analysis-ink-presentation
          npm run verify:p2:design-system
          npm run verify:p2:accessibility
          npx vitest run \\
            tests/analysis-saved-trade-position-box.test.tsx \\
            tests/analysis-saved-trade-overlay-live-candle-composition.test.tsx \\
            tests/analysis-live-candle-canvas-presentation.test.tsx \\
            tests/analysis-saved-trade-live-candle-composition.test.tsx \\
            tests/analysis-history-workspace.test.tsx

      - name: Production TypeScript compilation""")
rep("""          node scripts/test-home-dashboard-swipe-browser.mjs

      - name: Full unit regression""","""          node scripts/test-home-dashboard-swipe-browser.mjs
          node scripts/test-analysis-position-box-browser.mjs

      - name: Full unit regression""")
rep("""          for (const required of [
            'verify:analysis-saved-trade-risk-reward-ratio-projection',""","""          for (const required of [
            'verify:analysis-saved-trade-position-box',
            'verify:analysis-saved-trade-risk-reward-ratio-projection',""")
rep("""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RATIO_PROJECTION.md""","""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_SAVED_TRADE_POSITION_BOX.md
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RATIO_PROJECTION.md""")
rep("""            .gate-candidate/kairos_p76/.home-swipe-evidence/""","""            .gate-candidate/kairos_p76/.home-swipe-evidence/
            .gate-candidate/kairos_p76/.position-box-evidence/""")
open(p,'w').write(s); print('workflow pinned for Gate473')
