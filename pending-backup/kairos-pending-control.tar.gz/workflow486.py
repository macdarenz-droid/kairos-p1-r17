"""Pin Gate486 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate485 zip, prev = Gate484 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — P22.6 Time-Assisted Trade Snapshot Closure','name: Kairos Controlled Roadmap Gate — P23.1 Saved Time-Assisted Snapshot Contract Foundation')
rep("      - 'KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_P23_1_SAVED_TIME_ASSISTED_SNAPSHOT_CONTRACT_FOUNDATION_CANDIDATE_2026-09-18.zip'\n")
rep('  BASE_ZIP: KAIROS_ANALYSIS_TIME_ASSISTED_WINDOW_NAVIGATION_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_P23_1_SAVED_TIME_ASSISTED_SNAPSHOT_CONTRACT_FOUNDATION_CANDIDATE_2026-09-18.zip')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P22.6 closure scope from Gate484','      - name: Confirm exact P23.1 saved time-assisted snapshot contract scope from Gate485')
rep("""          expected = {
            'KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_REPORT_2026-09-17.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-analysis-time-assisted-estimate-markers.mjs',
            'scripts/verify-analysis-time-assisted-snapshot-preview.mjs',
            'scripts/verify-analysis-time-assisted-window-navigation.mjs',
            'scripts/verify-p22-1-estimated-market-reference-foundation.mjs',
            'scripts/verify-p22-2-time-assisted-trade-snapshot-composition.mjs',
            'scripts/verify-p22-6-time-assisted-trade-snapshot-closure.mjs',
          }
          if changed != expected or removed:
            print('P22.6 closure scope mismatch', file=sys.stderr)""","""          expected = {
            'KAIROS_P23_1_SAVED_TIME_ASSISTED_SNAPSHOT_CONTRACT_FOUNDATION_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p23-1-saved-time-assisted-snapshot-contract-foundation.mjs',
            'src/app/savedTimeAssistedSnapshotContract.ts',
            'src/app/savedTimeAssistedSnapshotIdentity.ts',
            'tests/saved-time-assisted-snapshot-contract.test.ts',
          }
          if changed != expected or removed:
            print('P23.1 saved time-assisted snapshot contract scope mismatch', file=sys.stderr)""")
rep("""          npm run verify:p21:28-chart-workspace-integration-closure

      - name: Production TypeScript compilation""","""          npm run verify:p21:28-chart-workspace-integration-closure

      - name: P23.1 saved time-assisted snapshot contract foundation
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p23:1-saved-time-assisted-snapshot-contract-foundation
          npm run verify:p22:6-time-assisted-trade-snapshot-closure
          npm run verify:p20:1-saved-analysis-contract-foundation
          npx vitest run \\
            tests/saved-time-assisted-snapshot-contract.test.ts \\
            tests/time-assisted-trade-snapshot.test.ts

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:p22:6-time-assisted-trade-snapshot-closure',""","""          for (const required of [
            'verify:p23:1-saved-time-assisted-snapshot-contract-foundation',
            'verify:p22:6-time-assisted-trade-snapshot-closure',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_REPORT_2026-09-17.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P23_1_SAVED_TIME_ASSISTED_SNAPSHOT_CONTRACT_FOUNDATION_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_REPORT_2026-09-17.md""")
open(p,'w').write(s); print('workflow pinned for Gate486')
