"""Apply the Gate491 (P23.6) closure ledger/plan edits to work491 (idempotent; run before draft491docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work491/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P23 canonical ownership ledger — ACTIVE through P23\.\d+', '## P23 canonical ownership ledger — SYSTEM CLOSED through P23.6', s, count=1)
row="| P23.6 | Durable time-assisted snapshot provenance system closure | verification/docs/package boundary only; no production runtime owner added | Proves P23.1–P23.5 as the complete source-proven P23 boundary and defines P24 from ownership |\n"
anchor="no persistence, estimate, chart or journal ownership |\n"
if row not in s:
    assert s.count(anchor)==1; s=s.replace(anchor, anchor+row, 1)
section="""## P23 Durable Time-Assisted Snapshot Provenance System Closure — P23.6

P23.6 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P23.1 contract, the P23.2 persistence and backup/restore extension (schema v5, backup format V4), the P23.3 save command, the P23.4 read boundary and the P23.5 preview round trip are mounted and retained with their verifiers; the closure report is `KAIROS_P23_6_DURABLE_TIME_ASSISTED_SNAPSHOT_PROVENANCE_CLOSURE_REPORT_2026-09-18.md` and its verifier `scripts/verify-p23-6-durable-time-assisted-snapshot-provenance-closure.mjs`. Saved snapshots are disclosed estimates with provenance, never journal truth, and never feed P11 results.

## P24 — saved record lifecycle (defined from ownership, not begun)

P24 gives the two saved-record stores their missing lifecycle owner: deleting a Saved Analysis (P20) or a saved time-assisted snapshot (P23) that the user no longer wants, through the released repositories (`delete` exists on both, unused by any application or UI owner), with explicit not-found and storage-error results, no cascade into the journal, backup/restore untouched, and Analysis-page controls with unit and real-browser evidence. Proven from ownership: P20.2/P23.2 own persistence, P20.3/P20.4/P23.3/P23.4 own save/load, P21.27/P23.5 own the page round trips; the only new owners are the delete commands and their controls. P24 may not begin before that PASS (the Gate491 canonical PASS of P23.6).

"""
if '## P23 Durable Time-Assisted Snapshot Provenance System Closure — P23.6' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert s.count(anchor2)==1; s=s.replace(anchor2, section+anchor2, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Updated at Gate485: P17–P22 closed; P23 defined (durable time-assisted snapshot provenance), not begun; P24–P40 later."
add=" Updated at Gate491: P17–P23 closed; P24 defined (saved record lifecycle), not begun; P25–P40 later."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
