"""Insert Gate523 continuity entries into the work523 docs. Reads Gate522 evidence from gate522-evidence.txt, zip522.txt and head522.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate522-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip522.txt').read().split()
HEAD=open(sp+'head522.txt').read().strip()
root=sp+'work523/kairos_p76/docs/'
label="**Patch label:** P33.2 · P33 Library import: merge saved records from a backup · owner phase P33 (active from the Gate521 canonical PASS) · definition: the Profile import card extended so one chosen backup previews and adds its missing trades and saved records together, through the P32.1 and P33.1 commands, proven in unit tests and a real browser."
ev=f"Gate522/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P33_1_SAVED_RECORD_MERGE_IMPORT_COMMAND_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate521 is the immediate rollback. P33.1 is canonical."
approval=f"""## Manual Gate523 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: one backup file carries trades and saved records together, so the released Import trades card keeps one picker, one preview and one confirmation and names the two counts separately; the trade merge can refuse while the saved-record merge cannot, so trades are committed first and a later saved-record write failure is disclosed rather than rolled back across two owners. P33.2 extends the card in `src/app/ProfileRoute.tsx` (Add these records, both counts in the preview and outcome); the P32.2 verifier literals and the P33.1 pin advanced. Real browser evidence (`scripts/test-profile-record-import-browser.mjs`, `.record-import-evidence/`) proves two Saved Analyses through the released save command, a real backup download, one deleted through the released delete command, the preview of exactly the lost analysis and its return byte-identical with its label, the Library showing it, and nothing offered from the device's own backup, at both viewports in both themes; the P32.2 browser script still passes. UI VISIBLE:YES. P33.3 (closure) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate522

{label}

Gate522/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P33.1 (saved-record merge-import command) is canonical. Gate521 remains its immediate rollback. The next slice (Gate523, P33.2) extends the Profile import card with browser evidence; P33.3 (closure) follows.

"""
arch=f"""## Gate523 P33.2 Profile import card extension amendment

{label}

Gate522/run{RUN}/head{HEAD} is the latest FULL canonical release: the P33.1 saved-record merge-import command. Gate521 is the immediate rollback.

The next slice extends the Import trades card in `src/app/ProfileRoute.tsx`, adds the unit and real-browser evidence and `docs/KAIROS_PROFILE_RECORD_IMPORT.md`, and advances the P33 ledger below to P33.2. Every other Profile card, the commands and the schema are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate523' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate522 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate521',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate522 P33.1 saved-record merge-import command amendment',arch)
print('inserted')
