"""Insert Gate515 continuity entries into the work515 docs. Reads Gate514 evidence from gate514-evidence.txt, zip514.txt and head514.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate514-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip514.txt').read().split()
HEAD=open(sp+'head514.txt').read().strip()
root=sp+'work515/kairos_p76/docs/'
label="**Patch label:** P30.3 · P30 Trade record lifecycle: delete · owner phase P30 (closure) · definition: source-proven closure of P30 and the definition of P31 from current ownership."
ev=f"Gate514/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P30_2_TRADE_DELETE_CONTROLS_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate513 is the immediate rollback. P30.2 is canonical."
approval=f"""## Manual Gate515 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. P30.3 closes P30 with no production runtime change: the P30 ledger is SYSTEM CLOSED through P30.3, the closure report and whole-phase verifier prove the delete command and the confirmed delete controls retained with their verifiers, the Gate514 verifier pin on the P30 ledger heading advanced to the closure literal, and P31 (Trade record lifecycle: draft activation) is defined from research: a draft carries no times, the open-trade update refuses any trade that is not open and manual, and no command or control turns a saved draft into an open trade. P31.1 (draft activation command) follows without a further prompt. UI VISIBLE:NO. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate514

{label}

Gate514/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P30.2 (trade delete controls) is canonical. Gate513 remains its immediate rollback. The next slice (Gate515, P30.3) closes P30 and defines P31 (Trade record lifecycle: draft activation).

"""
arch=f"""## Gate515 P30 closure and P31 definition amendment

{label}

Gate514/run{RUN}/head{HEAD} is the latest FULL canonical release: the P30.2 trade delete controls. Gate513 is the immediate rollback.

The next slice closes the P30 ledger below through P30.3 and defines P31 from ownership. No production runtime owner is added; every route, command and the schema are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate515' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate514 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate513',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate514 P30.2 trade delete controls amendment',arch)
print('inserted')
