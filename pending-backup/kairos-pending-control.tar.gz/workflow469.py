"""Pin Gate469 in the repo workflow. Usage: python3 workflow469.py SIZE SHA"""
import sys
size,sha=sys.argv[1],sys.argv[2]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — Ink Bubble Presentation','name: Kairos Controlled Roadmap Gate — Home Swipe Pager')
rep("      - 'KAIROS_INK_BUBBLE_PRESENTATION_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_HOME_DASHBOARD_SWIPE_PAGER_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_APP_SHELL_INK_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_INK_BUBBLE_PRESENTATION_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_INK_BUBBLE_PRESENTATION_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_HOME_DASHBOARD_SWIPE_PAGER_CANDIDATE_2026-09-17.zip')
rep("            ('BASE_ZIP', 3859514, 'f7d94f75df181d870601d7c90adf855b71819faa4fdacaa8409e40dd094048e5'),\n            ('CANDIDATE_ZIP', 3865083, '2136fd19582a7294d0b74370d29370b5688d87c9974f6a81551251b5b1264ddf'),",f"            ('BASE_ZIP', 3865083, '2136fd19582a7294d0b74370d29370b5688d87c9974f6a81551251b5b1264ddf'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact Ink bubble presentation scope from Gate467','      - name: Confirm exact Home swipe pager scope from Gate468')
rep("""          expected = {
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_INK_BUBBLE_PRESENTATION.md',
            'package.json',
            'scripts/verify-ink-bubble-presentation.mjs',
            'src/app/homeDashboardGlassBubbleMap.css',
            'src/design-system/themes/themeEngine.ts',
            'tests/ink-bubble-presentation.test.ts',
          }
          if changed != expected or removed:
            print('Ink bubble presentation scope mismatch', file=sys.stderr)""","""          expected = {
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_HOME_DASHBOARD_SWIPE_PAGER.md',
            'package.json',
            'scripts/test-home-dashboard-swipe-browser.mjs',
            'scripts/verify-home-dashboard-swipe-pager.mjs',
            'src/app/HomeDashboardSwipePager.tsx',
            'src/app/HomeRoute.tsx',
            'src/app/homeDashboardSwipeGesture.ts',
            'src/app/homeDashboardSwipePager.css',
            'src/app/homeDashboardYourTrades.css',
            'tests/home-dashboard-swipe-gesture.test.ts',
            'tests/home-dashboard-swipe-pager.test.tsx',
          }
          if changed != expected or removed:
            print('Home swipe pager scope mismatch', file=sys.stderr)""")
rep("""            tests/home-dashboard-your-trades.test.tsx

      - name: Production TypeScript compilation""","""            tests/home-dashboard-your-trades.test.tsx

      - name: Home dashboard swipe pager
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:home-dashboard-swipe-pager
          node scripts/verify-home-dashboard-your-trades.mjs
          npm run verify:p21:1-home-dashboard-route-ownership-foundation
          npm run verify:home-dashboard-live-crypto-bubble-home-route-text-runtime-integration-foundation
          npm run verify:home-dashboard-glass-bubble-presentation-amendment
          node scripts/verify-home-dashboard-bubble-drag.mjs
          npm run verify:p2:design-system
          npm run verify:p2:accessibility
          npx vitest run \\
            tests/home-dashboard-swipe-gesture.test.ts \\
            tests/home-dashboard-swipe-pager.test.tsx \\
            tests/home-dashboard-view-switch.test.tsx \\
            tests/home-dashboard-your-trades.test.tsx \\
            tests/home-dashboard-live-crypto-bubble-home-route-text-runtime-integration-foundation.test.tsx \\
            tests/router.test.tsx

      - name: Production TypeScript compilation""")
rep("""          node scripts/test-analysis-history-browser.mjs

      - name: Full unit regression""","""          node scripts/test-analysis-history-browser.mjs
          node scripts/test-home-dashboard-swipe-browser.mjs

      - name: Full unit regression""")
rep("""          for (const required of [
            'verify:ink-bubble-presentation',""","""          for (const required of [
            'verify:home-dashboard-swipe-pager',
            'verify:ink-bubble-presentation',""")
rep("""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_INK_BUBBLE_PRESENTATION.md""","""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_HOME_DASHBOARD_SWIPE_PAGER.md
            .gate-candidate/kairos_p76/docs/KAIROS_INK_BUBBLE_PRESENTATION.md""")
rep("""            .gate-candidate/kairos_p76/.bubble-drag-evidence/""","""            .gate-candidate/kairos_p76/.bubble-drag-evidence/
            .gate-candidate/kairos_p76/.home-swipe-evidence/""")
open(p,'w').write(s); print('workflow pinned for Gate469')
