"""Insert Gate482 continuity entries into the work482 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST ZIP_SIZE ZIP_SHA (Gate481 evidence + Gate481 zip)"""
import sys
run,job,head,cid,cdig,eid,edig,zsize,zsha=sys.argv[1:10]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work482/kairos_p76/docs/'
label="**Patch label:** P22.3 · P22 time-assisted trade snapshot · owner phase P22 (active) · definition: the visible, readonly preview on the Analysis page that takes side and opening/closing instants for the selected market and shows the P22.2 estimates as disclosed market-candle ranges, with real browser evidence and no journal write."
ev=f"Gate481/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P22_2_TIME_ASSISTED_TRADE_SNAPSHOT_COMPOSITION_CANDIDATE_2026-09-17.zip;{zsize}bytes;SHA256 {zsha}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate480 is the immediate rollback."
approval=f"""## Manual Gate482 slice — 17 September 2026

{label}

{ev}

Under the user's autonomous-continuation authority, P22 becomes visible in KAIROS_ANALYSIS_TIME_ASSISTED_SNAPSHOT_PREVIEW.md: the "Time-assisted snapshot" section on the Analysis page (side, opened at, optional closed at in the device time zone, Estimate) calls the released P22.2 composition over the released history port and shows each instant's 1-minute candle at its UTC open, the gap after the open and the low–high range with the words "Not your fill."; invalid requests and unavailable instants are explained in plain words; nothing is saved and no chart marker is drawn. The workspace mounts the section once with only the selected instrument and still owns no history port. UI VISIBLE:YES. Real Chromium evidence (`scripts/test-analysis-time-assisted-snapshot-browser.mjs`, `.time-assisted-evidence/`) records exactly one `klines` request per instant with `interval=1m`, `limit=1` and the containing minute's window, displayed ranges equal to the mocked candle, a future instant disclosed without a request, an open trade with only the entry, byte-identical journal facts and Ink/Paper at 320/390px. Two browser facts recorded: Chromium drops `:00` seconds from a `datetime-local` value, and each control is scrolled clear of the fixed bottom navigation. The P22.2 verifier's ledger-header pin is generalised to the active-P22 prefix like P22.1's. Estimated markers on the released chart and candle-window navigation follow one gate each. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate481

{label}

Gate481/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present: P22.2 (time-assisted snapshot composition) is canonical. Gate480 remains its immediate rollback. The next slice (Gate482, P22.3) mounts the visible preview on the Analysis page; estimated markers on the chart and window navigation follow.

"""
arch=f"""## Gate482 P22.3 time-assisted snapshot preview amendment

{label}

Gate481/run{run}/head{head} is the latest FULL canonical release: `src/application/market-reference/timeAssistedTradeSnapshot.ts`. Gate480 is the immediate rollback.

The next slice adds `src/app/AnalysisTimeAssistedSnapshotControls.tsx` (mounted once by the workspace with the selected instrument; the released history port by default), a route-scoped token-only CSS block before the Gate478 block, and the P22.3 ledger row below. P22.1/P22.2, P15/P16, the journal owners and every P21 mount are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate482' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate481 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate480',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate481 P22.2 time-assisted trade snapshot composition amendment',arch)
print('inserted')
