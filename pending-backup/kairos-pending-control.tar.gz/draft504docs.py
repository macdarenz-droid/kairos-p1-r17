"""Insert Gate504 continuity entries into the work504 docs. Reads Gate503 evidence from gate503-evidence.txt, zip503.txt and head503.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate503-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip503.txt').read().split()
HEAD=open(sp+'head503.txt').read().strip()
root=sp+'work504/kairos_p76/docs/'
label="**Patch label:** P27.3 · P27 Library foundation · owner phase P27 (closure) · definition: source-proven closure of P27 and the definition of P28 (Profile foundation: your data) from current ownership."
ev=f"Gate503/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P27_2_LIBRARY_ROUTE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate502 is the immediate rollback. P27.2 is canonical: the Library tab is live."
approval=f"""## Manual Gate504 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. P27.3 adds no production runtime behaviour and no new production owner: it proves P27.1–P27.2 against current source, marks the P27 ledger SYSTEM CLOSED through P27.3 and defines P28 from research: the released P6 backup/restore system has no route calling it, Profile still renders the placeholder and the activation receipt is shown nowhere; P28 is the Profile foundation (backup export command, restore command over the released preflight/preview/verified replacement, the Profile route with export, restore and read-only activation state, closure), one gate per owner with unit and real-browser evidence. UI VISIBLE:NO. P28 begins after this PASS without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate503

{label}

Gate503/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P27.2 (Library route and handoff) is canonical. Gate502 remains its immediate rollback. The next slice (Gate504, P27.3) is the P27 closure and the definition of P28 (Profile foundation: your data) from ownership.

"""
arch=f"""## Gate504 P27 closure and P28 definition amendment

{label}

Gate503/run{RUN}/head{HEAD} is the latest FULL canonical release: the P27.2 Library route. Gate502 is the immediate rollback.

The next slice adds `scripts/verify-p27-3-library-foundation-closure.mjs`, closes the P27 ledger below at P27.3 and adds the P27 closure section and the research-backed P28 definition. No production file changes. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate504' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate503 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate502',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate503 P27.2 Library route amendment',arch)
print('inserted')
