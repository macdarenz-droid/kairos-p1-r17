"""Re-apply the Gate485 closure ledger/plan edits to work485 after syncing docs from work484 (run before draft485docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work485/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P22 canonical ownership ledger — ACTIVE through P22\.\d+', '## P22 canonical ownership ledger — SYSTEM CLOSED through P22.6', s, count=1)
row="| P22.6 | Time-assisted trade snapshot system closure | verification/docs/package boundary only; no production runtime owner added | Proves P22.1–P22.5 as the complete source-proven P22 boundary and defines P23 from ownership |\n"
anchor="reports the applied range; changes no data |\n"
if row not in s:
    assert anchor in s; s=s.replace(anchor, anchor+row, 1)
section="""## P22 Time-Assisted Trade Snapshot System Closure — P22.6

P22.6 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P22.1 estimate contract, the P22.2 composition, the P22.3 preview, the P22.4 estimate markers and the P22.5 window navigation are mounted and retained with their verifiers; the closure report is `KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_REPORT_2026-09-17.md` and its verifier `scripts/verify-p22-6-time-assisted-trade-snapshot-closure.mjs`. Estimates never feed P11 results; nothing is persisted.

## P23 — durable time-assisted snapshot provenance (defined from ownership, not begun)

P23 saves a time-assisted snapshot through the released P20 contracts with full estimate provenance (provider/venue/symbol, requested instants and input time zone, matched candle times, method/resolution, exact candle OHLC, gaps, acquisition time), backup/restore compatible through P5/P6, with manual records authoritative and estimates outside actual performance. Proven from ownership: P20.2 persistence and backup/restore, P20.3/P20.4 save/load orchestration, P22.1/P22.2 estimate contracts; the only new owner is the snapshot record contract and its migration. P23 may not begin before that PASS (the Gate485 canonical PASS of P22.6).

"""
if '## P22 Time-Assisted Trade Snapshot System Closure — P22.6' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert anchor2 in s; s=s.replace(anchor2, section+anchor2, 1)
note="_Status at Gate485: this definition was written at the P21 closure; P22 is now SYSTEM CLOSED through P22.6 (ledger and closure section above)._\n\n"
head="## P22 — time-assisted trade snapshot (defined from ownership, not begun)\n\n"
if note not in s:
    assert head in s; s=s.replace(head, head+note, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Roadmap state: P17/P18/P19/P20/P21 closed; P22 defined (time-assisted trade snapshot), not begun; P23–P40 later."
add=" Updated at Gate485: P17–P22 closed; P23 defined (durable time-assisted snapshot provenance), not begun; P24–P40 later."
if add.strip() not in s:
    assert old in s; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
