"""Insert Gate522 continuity entries into the work522 docs. Reads Gate521 evidence from gate521-evidence.txt, zip521.txt and head521.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate521-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip521.txt').read().split()
HEAD=open(sp+'head521.txt').read().strip()
root=sp+'work522/kairos_p76/docs/'
label="**Patch label:** P33.1 · P33 Library import: merge saved records from a backup · owner phase P33 (active from the Gate521 canonical PASS) · definition: the two-step application command that adds the Saved Analyses and saved snapshots a Kairos backup holds and this device lacks, byte-identical, in one atomic write, never touching an existing record."
ev=f"Gate521/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P32_3_JOURNAL_IMPORT_CLOSURE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate520 is the immediate rollback. P32 is SYSTEM CLOSED through P32.3."
approval=f"""## Manual Gate522 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: P32.1 already fixed the merge-import shape, the two saved-record stores have no provenance field, no children and no cross-references, and a label is the user's own words, so P33.1 applies the same shape to the P20.2 and P23.2 stores with every selected record written byte-identical and a record that appears meanwhile simply skipped. P33.1 adds `src/application/backup/importSavedRecords.ts`; the Gate521 verifier pin that asserted no saved-record merge existed advanced to the command literal; the Profile card imports trades only until P33.2. UI VISIBLE:NO. P33.2 (Profile import card extension) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate521

{label}

Gate521/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P32 is SYSTEM CLOSED through P32.3 and P33 is defined from research. Gate520 remains its immediate rollback. The next slice (Gate522, P33.1) is the saved-record merge-import command; P33.2 (Profile import card extension) and P33.3 (closure) follow.

"""
arch=f"""## Gate522 P33.1 saved-record merge-import command amendment

{label}

Gate521/run{RUN}/head{HEAD} is the latest FULL canonical release: the P32 closure. Gate520 is the immediate rollback.

The next slice adds `src/application/backup/importSavedRecords.ts` (exported through `src/application/backup/index.ts`) and starts the P33 ledger below at P33.1. P6, P20.2, P23.2, P28, the shell and every route are unchanged; the Profile card imports trades only. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate522' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate521 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate520',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate521 P32 closure and P33 definition amendment',arch)
print('inserted')
