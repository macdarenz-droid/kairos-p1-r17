"""Pin Gate491 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate490 zip, prev = Gate489 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P23_6_DURABLE_TIME_ASSISTED_SNAPSHOT_PROVENANCE_CLOSURE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P23_5_SAVED_TIME_ASSISTED_SNAPSHOT_PREVIEW_ROUND_TRIP_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P23_4_SAVED_TIME_ASSISTED_SNAPSHOT_APPLICATION_READ_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P23.5 Saved Time-Assisted Snapshot Preview Round Trip','name: Kairos Controlled Roadmap Gate — P23.6 Durable Time-Assisted Snapshot Provenance Closure')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P23.5 saved time-assisted snapshot preview round trip scope from Gate489','      - name: Confirm exact P23.6 closure scope from Gate490')
start=s.index("          expected = {\n            'KAIROS_P23_5_SAVED_TIME_ASSISTED_SNAPSHOT_PREVIEW_ROUND_TRIP_REPORT_2026-09-18.md',")
end=s.index("            print('P23.5 saved time-assisted snapshot preview round trip scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P23_6_DURABLE_TIME_ASSISTED_SNAPSHOT_PROVENANCE_CLOSURE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p23-6-durable-time-assisted-snapshot-provenance-closure.mjs',
          }
          if changed != expected or removed:
            print('P23.6 closure scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P23.5 saved time-assisted snapshot preview round trip\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P23.6 durable time-assisted snapshot provenance closure
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p23:6-durable-time-assisted-snapshot-provenance-closure
          npm run verify:p23:5-saved-time-assisted-snapshot-preview-round-trip
          npm run verify:p23:4-saved-time-assisted-snapshot-application-read
          npm run verify:p23:3-saved-time-assisted-snapshot-application-save
          npm run verify:p23:2-saved-time-assisted-snapshot-persistence-foundation
          npm run verify:p23:1-saved-time-assisted-snapshot-contract-foundation
          npm run verify:p22:6-time-assisted-trade-snapshot-closure
          npx vitest run \\
            tests/saved-time-assisted-snapshot-contract.test.ts \\
            tests/saved-time-assisted-snapshot-persistence.test.ts \\
            tests/saved-time-assisted-snapshot-save-command.test.ts \\
            tests/saved-time-assisted-snapshot-load-query.test.ts \\
            tests/analysis-time-assisted-snapshot-saved-round-trip.test.tsx

"""+s[end:]
rep("""          for (const required of [
            'verify:p23:5-saved-time-assisted-snapshot-preview-round-trip',""","""          for (const required of [
            'verify:p23:6-durable-time-assisted-snapshot-provenance-closure',
            'verify:p23:5-saved-time-assisted-snapshot-preview-round-trip',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P23_5_SAVED_TIME_ASSISTED_SNAPSHOT_PREVIEW_ROUND_TRIP_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P23_6_DURABLE_TIME_ASSISTED_SNAPSHOT_PROVENANCE_CLOSURE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P23_5_SAVED_TIME_ASSISTED_SNAPSHOT_PREVIEW_ROUND_TRIP_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate491')
