"""Insert Gate525 continuity entries into the work525 docs. Reads Gate524 evidence from gate524-evidence.txt, zip524.txt and head524.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate524-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip524.txt').read().split()
HEAD=open(sp+'head524.txt').read().strip()
root=sp+'work525/kairos_p76/docs/'
label="**Patch label:** P34.1 · P34 Profile data safety: backup freshness and persistent storage · owner phase P34 (active from the Gate524 canonical PASS) · definition: the device-scoped record of the last backup handed to the browser, written after the hand-off and read back as a moment or never, never inside a backup."
ev=f"Gate524/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P33_3_LIBRARY_IMPORT_CLOSURE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate523 is the immediate rollback. P33 is SYSTEM CLOSED through P33.3."
approval=f"""## Manual Gate525 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the released P5 metadata scope excludes every `device.` key from backups and the P6 restore retains them, so a `device.backup.last-export.v1` record is naturally per device; the record repeats the file's own facts so the P28.1 export stays pure; a missing or malformed record reads as never, the rule the goals preference already follows. P34.1 adds `src/application/backup/lastBackup.ts`; the Gate524 verifier pin that asserted no record existed advanced to the command literal; the Profile page shows nothing of it until P34.2. UI VISIBLE:NO. P34.2 (Profile device card extension) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate524

{label}

Gate524/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P33 is SYSTEM CLOSED through P33.3 and P34 is defined from research. Gate523 remains its immediate rollback. The next slice (Gate525, P34.1) is the last-backup record; P34.2 (Profile device card extension) and P34.3 (closure) follow.

"""
arch=f"""## Gate525 P34.1 last-backup record amendment

{label}

Gate524/run{RUN}/head{HEAD} is the latest FULL canonical release: the P33 closure. Gate523 is the immediate rollback.

The next slice adds `src/application/backup/lastBackup.ts` (exported through `src/application/backup/index.ts`) and starts the P34 ledger below at P34.1. P5, P6, P28, the shell and every route are unchanged; the Profile page shows nothing of it yet. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate525' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate524 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate523',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate524 P33 closure and P34 definition amendment',arch)
print('inserted')
