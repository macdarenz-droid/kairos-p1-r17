"""Pin Gate507 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate506 zip, prev = Gate505 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P28_3_PROFILE_ROUTE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P28_2_BACKUP_RESTORE_COMMAND_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P28_1_BACKUP_EXPORT_COMMAND_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P28.2 Backup Restore Command','name: Kairos Controlled Roadmap Gate — P28.3 Profile Route')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P28.2 backup restore command scope from Gate505','      - name: Confirm exact P28.3 profile route scope from Gate506')
start=s.index("          expected = {\n            'KAIROS_P28_2_BACKUP_RESTORE_COMMAND_REPORT_2026-09-18.md',")
end=s.index("            print('P28.2 backup restore command scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P28_3_PROFILE_ROUTE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_PROFILE_ROUTE.md',
            'package.json',
            'scripts/test-profile-route-browser.mjs',
            'scripts/verify-p26-3-goals-route.mjs',
            'scripts/verify-p27-2-library-route.mjs',
            'scripts/verify-p27-3-library-foundation-closure.mjs',
            'scripts/verify-p28-1-backup-export-command.mjs',
            'scripts/verify-p28-2-backup-restore-command.mjs',
            'scripts/verify-p28-3-profile-route.mjs',
            'src/app/ProfileRoute.tsx',
            'src/app/profileRoute.css',
            'src/app/routes.tsx',
            'tests/profile-route.test.tsx',
          }
          if changed != expected or removed:
            print('P28.3 profile route scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P28.2 backup restore command\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P28.3 profile route
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p28:3-profile-route
          npm run verify:p28:2-backup-restore-command
          npm run verify:p28:1-backup-export-command
          npm run verify:p27:3-library-foundation-closure
          npm run verify:p27:2-library-route
          npm run verify:p26:3-goals-route
          npx vitest run \\
            tests/profile-route.test.tsx \\
            tests/backup-restore-command.test.ts \\
            tests/backup-export-command.test.ts \\
            tests/activation-persistence.test.ts \\
            tests/app-shell-ink.test.tsx

"""+s[end:]
rep("          node scripts/test-library-route-browser.mjs\n","          node scripts/test-library-route-browser.mjs\n          node scripts/test-profile-route-browser.mjs\n")
rep("""          for (const required of [
            'verify:p28:2-backup-restore-command',""","""          for (const required of [
            'verify:p28:3-profile-route',
            'verify:p28:2-backup-restore-command',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P28_2_BACKUP_RESTORE_COMMAND_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P28_3_PROFILE_ROUTE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/docs/KAIROS_PROFILE_ROUTE.md
            .gate-candidate/kairos_p76/.profile-route-evidence/
            .gate-candidate/kairos_p76/KAIROS_P28_2_BACKUP_RESTORE_COMMAND_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate507')
