"""Pin Gate496 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate495 zip, prev = Gate494 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P25_2_SAVED_RECORD_LABEL_PRESENTATION_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P25_1_SAVED_RECORD_LABEL_FOUNDATION_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P24_3_SAVED_RECORD_LIFECYCLE_CLOSURE_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P25.1 Saved Record Label Foundation','name: Kairos Controlled Roadmap Gate — P25.2 Saved Record Label Presentation')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P25.1 saved record label foundation scope from Gate494','      - name: Confirm exact P25.2 saved record label presentation scope from Gate495')
start=s.index("          expected = {\n            'KAIROS_P25_1_SAVED_RECORD_LABEL_FOUNDATION_REPORT_2026-09-18.md',")
end=s.index("            print('P25.1 saved record label foundation scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P25_2_SAVED_RECORD_LABEL_PRESENTATION_REPORT_2026-09-18.md',
            'docs/KAIROS_ANALYSIS_SAVED_RECORD_LABELS.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-saved-record-label-browser.mjs',
            'scripts/verify-analysis-saved-analysis-round-trip.mjs',
            'scripts/verify-p23-5-saved-time-assisted-snapshot-preview-round-trip.mjs',
            'scripts/verify-p25-2-saved-record-label-presentation.mjs',
            'src/app/AnalysisSavedAnalysisControls.tsx',
            'src/app/AnalysisTimeAssistedSnapshotControls.tsx',
            'src/app/analysisHistory.css',
            'src/app/analysisSavedAnalysisRoundTrip.ts',
            'src/app/analysisSavedTimeAssistedSnapshotRoundTrip.ts',
            'tests/analysis-saved-record-label.test.tsx',
          }
          if changed != expected or removed:
            print('P25.2 saved record label presentation scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P25.1 saved record label foundation\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P25.2 saved record label presentation
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p25:2-saved-record-label-presentation
          npm run verify:p25:1-saved-record-label-foundation
          npm run verify:analysis-saved-analysis-round-trip
          npm run verify:p23:5-saved-time-assisted-snapshot-preview-round-trip
          npm run verify:p24:2-saved-record-delete-controls
          npx vitest run \\
            tests/analysis-saved-record-label.test.tsx \\
            tests/analysis-saved-analysis-round-trip.test.tsx \\
            tests/analysis-time-assisted-snapshot-saved-round-trip.test.tsx \\
            tests/analysis-saved-record-delete.test.tsx \\
            tests/analysis-history-workspace.test.tsx \\
            tests/saved-record-label-foundation.test.ts

"""+s[end:]
rep("          node scripts/test-analysis-saved-record-delete-browser.mjs\n","          node scripts/test-analysis-saved-record-delete-browser.mjs\n          node scripts/test-analysis-saved-record-label-browser.mjs\n")
rep("""          for (const required of [
            'verify:p25:1-saved-record-label-foundation',""","""          for (const required of [
            'verify:p25:2-saved-record-label-presentation',
            'verify:p25:1-saved-record-label-foundation',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P25_1_SAVED_RECORD_LABEL_FOUNDATION_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P25_2_SAVED_RECORD_LABEL_PRESENTATION_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_SAVED_RECORD_LABELS.md
            .gate-candidate/kairos_p76/.saved-record-label-evidence/
            .gate-candidate/kairos_p76/KAIROS_P25_1_SAVED_RECORD_LABEL_FOUNDATION_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate496')
