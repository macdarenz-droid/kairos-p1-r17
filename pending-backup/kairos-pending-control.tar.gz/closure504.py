"""Apply the Gate504 (P27.3) closure ledger/plan edits to work504 (idempotent; run before draft504docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work504/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P27 canonical ownership ledger — ACTIVE through P27\.\d+', '## P27 canonical ownership ledger — SYSTEM CLOSED through P27.3', s, count=1)
row="| P27.3 | Library foundation system closure | verification/docs/package boundary only; no production runtime owner added | Proves P27.1–P27.2 as the complete source-proven P27 boundary and defines P28 from ownership |\n"
anchor="every released mount line stays byte-identical; no write, no re-estimation |\n"
if row not in s:
    assert s.count(anchor)==1; s=s.replace(anchor, anchor+row, 1)
section="""## P27 Library Foundation System Closure — P27.3

P27.3 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P27.1 saved-record index and the P27.2 Library route with its Library → Analysis handoff are mounted and retained with their verifiers; the closure report is `KAIROS_P27_3_LIBRARY_FOUNDATION_CLOSURE_REPORT_2026-09-18.md` and its verifier `scripts/verify-p27-3-library-foundation-closure.mjs`. The Library never writes, never re-estimates and leaves every released mount line byte-identical.

## P28 — Profile foundation: your data (defined from ownership, not begun)

Research against current source: the P6 backup system (schema-versioned full backups, format V4, restore preflight, atomic replacement and verified reload) is complete and covered by its own tests and verifiers, yet no route in `src/app` calls `createKairosDatabaseSnapshot`, `prepareKairosRestore` or `restoreAndVerifyKairosDatabase`: a user has no way to export or restore their own journal. `src/app/routes.tsx` still renders Profile (under More) as `PlaceholderRoute`, and `src/services/activation` owns a device activation receipt no page shows. P28 makes Profile the device's own page in dependency order: P28.1 a backup export command (the released P6 snapshot serialised to a named `.json` file, download handed to the browser, nothing written), P28.2 a restore command over the released preflight → preview → confirm → verified replacement path with explicit outcomes, P28.3 the Profile route mounting export, restore and the read-only activation state, each with unit and real-browser evidence, and P28.4 the closure. Proven from ownership: P6 owns the backup lifecycle, P5 the database, the activation service its receipt, the shell navigation; the only new owners are the two commands and the route. Practice stays a placeholder until its own phase. P28 may not begin before that PASS (the Gate504 canonical PASS of P27.3).

"""
if '## P27 Library Foundation System Closure — P27.3' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert s.count(anchor2)==1; s=s.replace(anchor2, section+anchor2, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Updated at Gate502: P27 ACTIVE (Library foundation) from the Gate501 canonical PASS."
add=" Updated at Gate504: P17–P27 closed; P28 defined (Profile foundation: your data), not begun; P29–P40 later."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
