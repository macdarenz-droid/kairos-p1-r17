"""Pin Gate480 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate479 zip, prev = Gate478 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — P21 Chart Workspace Integration Closure','name: Kairos Controlled Roadmap Gate — P22.1 Estimated Market Reference Foundation')
rep("      - 'KAIROS_P21_28_CHART_WORKSPACE_INTEGRATION_CLOSURE_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_P22_1_ESTIMATED_MARKET_REFERENCE_FOUNDATION_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_ANALYSIS_SAVED_ANALYSIS_ROUND_TRIP_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_P21_28_CHART_WORKSPACE_INTEGRATION_CLOSURE_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_P21_28_CHART_WORKSPACE_INTEGRATION_CLOSURE_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_P22_1_ESTIMATED_MARKET_REFERENCE_FOUNDATION_CANDIDATE_2026-09-17.zip')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P21 closure scope from Gate478','      - name: Confirm exact P22.1 estimated market reference foundation scope from Gate479')
rep("""          expected = {
            'KAIROS_P21_28_CHART_WORKSPACE_INTEGRATION_CLOSURE_REPORT_2026-09-17.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p21-28-chart-workspace-integration-closure.mjs',
          }
          if changed != expected or removed:
            print('P21 closure scope mismatch', file=sys.stderr)""","""          expected = {
            'KAIROS_P22_1_ESTIMATED_MARKET_REFERENCE_FOUNDATION_REPORT_2026-09-17.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p22-1-estimated-market-reference-foundation.mjs',
            'src/application/market-reference/estimatedMarketReference.ts',
            'src/application/market-reference/index.ts',
            'tests/estimated-market-reference-foundation.test.ts',
          }
          if changed != expected or removed:
            print('P22.1 estimated market reference foundation scope mismatch', file=sys.stderr)""")
rep("""          npm run verify:analysis-saved-trade-position-box

      - name: Production TypeScript compilation""","""          npm run verify:analysis-saved-trade-position-box

      - name: P22.1 estimated market reference foundation
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p22:1-estimated-market-reference-foundation
          npm run verify:p21:28-chart-workspace-integration-closure
          npm run verify:binance-spot-candle-history
          npx vitest run \\
            tests/estimated-market-reference-foundation.test.ts \\
            tests/binance-spot-candle-history.test.ts

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:p21:28-chart-workspace-integration-closure',""","""          for (const required of [
            'verify:p22:1-estimated-market-reference-foundation',
            'verify:p21:28-chart-workspace-integration-closure',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P21_28_CHART_WORKSPACE_INTEGRATION_CLOSURE_REPORT_2026-09-17.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P22_1_ESTIMATED_MARKET_REFERENCE_FOUNDATION_REPORT_2026-09-17.md
            .gate-candidate/kairos_p76/KAIROS_P21_28_CHART_WORKSPACE_INTEGRATION_CLOSURE_REPORT_2026-09-17.md""")
open(p,'w').write(s); print('workflow pinned for Gate480')
