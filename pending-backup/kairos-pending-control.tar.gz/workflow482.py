"""Pin Gate482 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate481 zip, prev = Gate480 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — P22.2 Time-Assisted Trade Snapshot Composition','name: Kairos Controlled Roadmap Gate — P22.3 Time-Assisted Snapshot Preview')
rep("      - 'KAIROS_P22_2_TIME_ASSISTED_TRADE_SNAPSHOT_COMPOSITION_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_ANALYSIS_TIME_ASSISTED_SNAPSHOT_PREVIEW_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_P22_1_ESTIMATED_MARKET_REFERENCE_FOUNDATION_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_P22_2_TIME_ASSISTED_TRADE_SNAPSHOT_COMPOSITION_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_P22_2_TIME_ASSISTED_TRADE_SNAPSHOT_COMPOSITION_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_TIME_ASSISTED_SNAPSHOT_PREVIEW_CANDIDATE_2026-09-17.zip')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P22.2 time-assisted trade snapshot composition scope from Gate480','      - name: Confirm exact P22.3 time-assisted snapshot preview scope from Gate481')
rep("""          expected = {
            'KAIROS_P22_2_TIME_ASSISTED_TRADE_SNAPSHOT_COMPOSITION_REPORT_2026-09-17.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p22-1-estimated-market-reference-foundation.mjs',
            'scripts/verify-p22-2-time-assisted-trade-snapshot-composition.mjs',
            'src/application/market-reference/index.ts',
            'src/application/market-reference/timeAssistedTradeSnapshot.ts',
            'tests/time-assisted-trade-snapshot.test.ts',
          }
          if changed != expected or removed:
            print('P22.2 time-assisted trade snapshot composition scope mismatch', file=sys.stderr)""","""          expected = {
            'docs/KAIROS_ANALYSIS_TIME_ASSISTED_SNAPSHOT_PREVIEW.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-time-assisted-snapshot-browser.mjs',
            'scripts/verify-analysis-time-assisted-snapshot-preview.mjs',
            'scripts/verify-p22-2-time-assisted-trade-snapshot-composition.mjs',
            'src/app/AnalysisHistoryWorkspace.tsx',
            'src/app/AnalysisTimeAssistedSnapshotControls.tsx',
            'src/app/analysisHistory.css',
            'tests/analysis-time-assisted-snapshot-preview.test.tsx',
          }
          if changed != expected or removed:
            print('P22.3 time-assisted snapshot preview scope mismatch', file=sys.stderr)""")
rep("""            tests/estimated-market-reference-foundation.test.ts

      - name: Production TypeScript compilation""","""            tests/estimated-market-reference-foundation.test.ts

      - name: P22.3 time-assisted snapshot preview
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:analysis-time-assisted-snapshot-preview
          npm run verify:p22:2-time-assisted-trade-snapshot-composition
          npm run verify:analysis-history-workspace
          npm run verify:analysis-saved-analysis-round-trip
          npm run verify:p2:design-system
          npx vitest run \\
            tests/analysis-time-assisted-snapshot-preview.test.tsx \\
            tests/time-assisted-trade-snapshot.test.ts \\
            tests/analysis-history-workspace.test.tsx

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:p22:2-time-assisted-trade-snapshot-composition',""","""          for (const required of [
            'verify:analysis-time-assisted-snapshot-preview',
            'verify:p22:2-time-assisted-trade-snapshot-composition',""")
rep("""          node scripts/test-analysis-saved-analysis-browser.mjs

      - name: Full unit regression""","""          node scripts/test-analysis-saved-analysis-browser.mjs
          node scripts/test-analysis-time-assisted-snapshot-browser.mjs

      - name: Full unit regression""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P22_2_TIME_ASSISTED_TRADE_SNAPSHOT_COMPOSITION_REPORT_2026-09-17.md""","""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_TIME_ASSISTED_SNAPSHOT_PREVIEW.md
            .gate-candidate/kairos_p76/.time-assisted-evidence/
            .gate-candidate/kairos_p76/KAIROS_P22_2_TIME_ASSISTED_TRADE_SNAPSHOT_COMPOSITION_REPORT_2026-09-17.md""")
open(p,'w').write(s); print('workflow pinned for Gate482')
