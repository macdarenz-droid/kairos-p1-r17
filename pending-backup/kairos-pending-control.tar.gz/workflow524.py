"""Pin Gate524 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate523 zip, prev = Gate522 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P33_3_LIBRARY_IMPORT_CLOSURE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P33_2_PROFILE_IMPORT_CARD_EXTENSION_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P33_1_SAVED_RECORD_MERGE_IMPORT_COMMAND_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P33.2 Profile Import Card Extension','name: Kairos Controlled Roadmap Gate — P33.3 Library Import Closure')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P33.2 profile import card extension scope from Gate522','      - name: Confirm exact P33.3 closure scope from Gate523')
start=s.index("          expected = {\n            'KAIROS_P33_2_PROFILE_IMPORT_CARD_EXTENSION_REPORT_2026-09-18.md',")
end=s.index("            print('P33.2 profile import card extension scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P33_3_LIBRARY_IMPORT_CLOSURE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p33-2-profile-import-card-extension.mjs',
            'scripts/verify-p33-3-library-import-closure.mjs',
          }
          if changed != expected or removed:
            print('P33.3 closure scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P33.2 profile import card extension\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P33.3 library import closure
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p33:3-library-import-closure
          npm run verify:p33:2-profile-import-card-extension
          npm run verify:p33:1-saved-record-merge-import-command
          npx vitest run \\
            tests/profile-trade-import.test.tsx \\
            tests/saved-record-import-command.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p33:2-profile-import-card-extension',""","""          for (const required of [
            'verify:p33:3-library-import-closure',
            'verify:p33:2-profile-import-card-extension',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P33_2_PROFILE_IMPORT_CARD_EXTENSION_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P33_3_LIBRARY_IMPORT_CLOSURE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P33_2_PROFILE_IMPORT_CARD_EXTENSION_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate524')
