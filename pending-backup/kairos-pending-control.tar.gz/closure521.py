"""Apply the Gate521 (P32.3) closure ledger/plan edits to work521 (idempotent; run before draft521docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work521/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P32 canonical ownership ledger — ACTIVE through P32\.\d+', '## P32 canonical ownership ledger — SYSTEM CLOSED through P32.3', s, count=1)
row="| P32.3 | Journal import system closure | verification/docs/package boundary only; no production runtime owner added | Proves P32.1–P32.2 as the complete source-proven P32 boundary and defines P33 from ownership |\n"
anchor="every released Profile card and literal unchanged; no replacement of existing records |\n"
if row not in s:
    assert s.count(anchor)==1; s=s.replace(anchor, anchor+row, 1)
section="""## P32 Journal Import System Closure — P32.3

P32.3 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P32.1 merge-import command and the P32.2 Profile import card are mounted and retained with their verifiers; the closure report is `KAIROS_P32_3_JOURNAL_IMPORT_CLOSURE_REPORT_2026-09-18.md` and its verifier `scripts/verify-p32-3-journal-import-closure.mjs`. An import adds only the trades this device lacks, with their own children, re-stamped `import` for real sources, never replacing an existing record; every released Profile card and literal is unchanged.

## P33 — Library import: merge saved records from a backup (defined from ownership, not begun)

Research against current source: the P6 backup format carries every Saved Analysis (V3) and saved time-assisted snapshot (V4) with its stable id, the P20.2 and P23.2 repositories expose `get`, `listAll` and `put` for both stores, and P32 merges trades only: a Saved Analysis or snapshot made on another device, or lost to a P24 delete, can still be brought back only by the P28 restore, which replaces everything. P33 completes the merge import for the Library in dependency order: P33.1 a merge-import command that reads a backup through the released P6 parse and preflight and selects the Saved Analyses and saved snapshots whose ids are not on this device, keeping every record byte-identical including its P25 label, and writes them in one atomic write with explicit counts (added, already present) and refusals, never touching an existing record, a trade or a preference; P33.2 the Profile import card extended so one chosen backup previews and adds its missing trades and saved records together, with the counts named separately, proven in unit tests and a real browser; P33.3 the closure. Proven from ownership: P6 owns parsing, validation and the format, P20.2/P23.2 the saved-record stores, P9 the atomic write, P32.1 the trade merge, P28/P32.2 the Profile card; the only new owners are the saved-record command and the extended card. P33 may not begin before that PASS (the Gate521 canonical PASS of P32.3).

"""
if '## P32 Journal Import System Closure — P32.3' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert s.count(anchor2)==1; s=s.replace(anchor2, section+anchor2, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Updated at Gate519: P32 ACTIVE (Journal import: merge trades from a backup) from the Gate518 canonical PASS."
add=" Updated at Gate521: P17–P32 closed; P33 defined (Library import: merge saved records from a backup), not begun; P34–P40 later."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
