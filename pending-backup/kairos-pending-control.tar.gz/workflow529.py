"""Pin Gate529 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate528 zip, prev = Gate527 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P35_2_PRACTICE_ROUTE_LIFECYCLE_CONTROLS_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P35_1_PRACTICE_TRADE_LIFECYCLE_SOURCE_OPTION_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P34_3_PROFILE_DATA_SAFETY_CLOSURE_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P35.1 Practice Trade Lifecycle Source Option','name: Kairos Controlled Roadmap Gate — P35.2 Practice Route Lifecycle Controls')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P35.1 practice trade lifecycle source option scope from Gate527','      - name: Confirm exact P35.2 practice route lifecycle controls scope from Gate528')
start=s.index("          expected = {\n            'KAIROS_P35_1_PRACTICE_TRADE_LIFECYCLE_SOURCE_OPTION_REPORT_2026-09-18.md',")
end=s.index("            print('P35.1 practice trade lifecycle source option scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P35_2_PRACTICE_ROUTE_LIFECYCLE_CONTROLS_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_PRACTICE_TRADE_LIFECYCLE.md',
            'package.json',
            'scripts/verify-p30-2-trade-delete-controls.mjs',
            'scripts/verify-p31-1-draft-trade-activation-command.mjs',
            'scripts/verify-p31-2-draft-trade-activation-control.mjs',
            'scripts/verify-p31-3-draft-activation-closure.mjs',
            'scripts/verify-p34-3-profile-data-safety-closure.mjs',
            'scripts/verify-p35-2-practice-route-lifecycle-controls.mjs',
            'src/app/JournalDraftTradeActivation.tsx',
            'src/app/JournalHistoryList.tsx',
            'src/app/JournalOpenTradeUpdate.tsx',
            'src/app/PracticeRoute.tsx',
            'tests/journal-draft-trade-activation.test.tsx',
          }
          if changed != expected or removed:
            print('P35.2 practice route lifecycle controls scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P35.1 practice trade lifecycle source option\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P35.2 practice route lifecycle controls
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p35:2-practice-route-lifecycle-controls
          npm run verify:p35:1-practice-trade-lifecycle-source-option
          npm run verify:p31:2-draft-trade-activation-control
          npm run verify:p31:1-draft-trade-activation-command
          npm run verify:p30:2-trade-delete-controls
          npm run verify:p30:1-trade-record-delete-command
          npm run verify:p31:3-draft-activation-closure
          npm run verify:p30:3-trade-record-lifecycle-closure
          npm run verify:p34:3-profile-data-safety-closure
          npm run verify:p29:3-practice-route
          npx vitest run \\
            tests/journal-draft-trade-activation.test.tsx \\
            tests/journal-open-trade-update.test.tsx \\
            tests/draft-trade-activation-command.test.ts \\
            tests/practice-route.test.tsx \\
            tests/journal-trade-delete-control.test.tsx \\
            tests/manual-trade-journal-route.test.tsx \\
            tests/practice-trade-lifecycle-source-option.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p35:1-practice-trade-lifecycle-source-option',""","""          for (const required of [
            'verify:p35:2-practice-route-lifecycle-controls',
            'verify:p35:1-practice-trade-lifecycle-source-option',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P35_1_PRACTICE_TRADE_LIFECYCLE_SOURCE_OPTION_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P35_2_PRACTICE_ROUTE_LIFECYCLE_CONTROLS_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/docs/KAIROS_PRACTICE_TRADE_LIFECYCLE.md
            .gate-candidate/kairos_p76/KAIROS_P35_1_PRACTICE_TRADE_LIFECYCLE_SOURCE_OPTION_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate529')
