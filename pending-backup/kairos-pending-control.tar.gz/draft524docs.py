"""Insert Gate524 continuity entries into the work524 docs. Reads Gate523 evidence from gate523-evidence.txt, zip523.txt and head523.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate523-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip523.txt').read().split()
HEAD=open(sp+'head523.txt').read().strip()
root=sp+'work524/kairos_p76/docs/'
label="**Patch label:** P33.3 · P33 Library import: merge saved records from a backup · owner phase P33 (closure) · definition: source-proven closure of P33 and the definition of P34 from current ownership."
ev=f"Gate523/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P33_2_PROFILE_IMPORT_CARD_EXTENSION_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate522 is the immediate rollback. P33.2 is canonical."
approval=f"""## Manual Gate524 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. P33.3 closes P33 with no production runtime change: the P33 ledger is SYSTEM CLOSED through P33.3, the closure report and whole-phase verifier prove the saved-record merge command and the card extension retained with their verifiers, the Gate523 verifier pin on the P33 ledger heading advanced to the closure literal, and P34 (Profile data safety: backup freshness and persistent storage) is defined from research: the storage-durability owner inspects and can request persistent storage yet no route shows or offers it, and nothing records when a backup was last taken. P34.1 (last-backup record) follows without a further prompt. UI VISIBLE:NO. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate523

{label}

Gate523/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P33.2 (Profile import card extension) is canonical. Gate522 remains its immediate rollback. The next slice (Gate524, P33.3) closes P33 and defines P34 (Profile data safety: backup freshness and persistent storage).

"""
arch=f"""## Gate524 P33 closure and P34 definition amendment

{label}

Gate523/run{RUN}/head{HEAD} is the latest FULL canonical release: the P33.2 Profile import card extension. Gate522 is the immediate rollback.

The next slice closes the P33 ledger below through P33.3 and defines P34 from ownership. No production runtime owner is added; every route, command and the schema are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate524' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate523 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate522',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate523 P33.2 Profile import card extension amendment',arch)
print('inserted')
