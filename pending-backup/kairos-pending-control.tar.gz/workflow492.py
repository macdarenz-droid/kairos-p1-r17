"""Pin Gate492 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate491 zip, prev = Gate490 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P24_1_SAVED_RECORD_DELETE_COMMANDS_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P23_6_DURABLE_TIME_ASSISTED_SNAPSHOT_PROVENANCE_CLOSURE_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P23_5_SAVED_TIME_ASSISTED_SNAPSHOT_PREVIEW_ROUND_TRIP_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P23.6 Durable Time-Assisted Snapshot Provenance Closure','name: Kairos Controlled Roadmap Gate — P24.1 Saved Record Delete Commands')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P23.6 closure scope from Gate490','      - name: Confirm exact P24.1 saved record delete commands scope from Gate491')
start=s.index("          expected = {\n            'KAIROS_P23_6_DURABLE_TIME_ASSISTED_SNAPSHOT_PROVENANCE_CLOSURE_REPORT_2026-09-18.md',")
end=s.index("            print('P23.6 closure scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P24_1_SAVED_RECORD_DELETE_COMMANDS_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p24-1-saved-record-delete-commands.mjs',
            'src/application/saved-analysis/deleteSavedAnalysis.ts',
            'src/application/saved-analysis/index.ts',
            'src/application/saved-time-assisted-snapshot/deleteSavedTimeAssistedSnapshot.ts',
            'src/application/saved-time-assisted-snapshot/index.ts',
            'tests/saved-record-delete-commands.test.ts',
          }
          if changed != expected or removed:
            print('P24.1 saved record delete commands scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P23.6 durable time-assisted snapshot provenance closure\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P24.1 saved record delete commands
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p24:1-saved-record-delete-commands
          npm run verify:p23:6-durable-time-assisted-snapshot-provenance-closure
          npm run verify:p20:3-saved-analysis-application-save
          npm run verify:p20:4-saved-analysis-application-load
          npm run verify:p23:3-saved-time-assisted-snapshot-application-save
          npm run verify:p23:4-saved-time-assisted-snapshot-application-read
          npx vitest run \\
            tests/saved-record-delete-commands.test.ts \\
            tests/saved-analysis-save-command.test.ts \\
            tests/saved-analysis-load-query.test.ts \\
            tests/saved-time-assisted-snapshot-save-command.test.ts \\
            tests/saved-time-assisted-snapshot-load-query.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p23:6-durable-time-assisted-snapshot-provenance-closure',""","""          for (const required of [
            'verify:p24:1-saved-record-delete-commands',
            'verify:p23:6-durable-time-assisted-snapshot-provenance-closure',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P23_6_DURABLE_TIME_ASSISTED_SNAPSHOT_PROVENANCE_CLOSURE_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P24_1_SAVED_RECORD_DELETE_COMMANDS_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P23_6_DURABLE_TIME_ASSISTED_SNAPSHOT_PROVENANCE_CLOSURE_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate492')
