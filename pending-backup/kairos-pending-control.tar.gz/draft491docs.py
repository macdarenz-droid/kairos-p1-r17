"""Insert Gate491 continuity entries into the work491 docs. Reads Gate490 evidence from gate490-evidence.txt (RUN JOB ART_CAND ART_CAND_SHA ART_EV ART_EV_SHA MAINRUN), zip490.txt (SIZE SHA) and head490.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate490-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip490.txt').read().split()
HEAD=open(sp+'head490.txt').read().strip()
root=sp+'work491/kairos_p76/docs/'
label="**Patch label:** P23.6 · P23 durable time-assisted snapshot provenance · owner phase P23 (closure) · definition: source-proven closure of P23 and the definition of P24 (saved record lifecycle) from current ownership."
ev=f"Gate490/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P23_5_SAVED_TIME_ASSISTED_SNAPSHOT_PREVIEW_ROUND_TRIP_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate489 is the immediate rollback. P23.5 is canonical: saved snapshots are visible on the Analysis page."
approval=f"""## Manual Gate491 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 decision ("1": proceed with P23 under the same gate discipline). P23.6 adds no production runtime behaviour and no new production owner: it proves P23.1–P23.5 against current source (contract, schema v5 / backup V4 persistence, save command, read boundary, preview round trip with browser evidence), marks the P23 ledger SYSTEM CLOSED through P23.6 and defines P24 from ownership: the saved record lifecycle (delete commands and Analysis-page controls for Saved Analyses and saved snapshots; the repositories already expose `delete` and no owner uses it). UI VISIBLE:NO. P24 may not begin before this PASS; the user's whole-app UI review and the parked Ink amendments remain deferred to the user's checkpoint. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate490

{label}

Gate490/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P23.5 (preview save/list/load round trip) is canonical. Gate489 remains its immediate rollback. The next slice (Gate491, P23.6) is the P23 closure and the definition of P24 (saved record lifecycle) from ownership.

"""
arch=f"""## Gate491 P23 closure and P24 definition amendment

{label}

Gate490/run{RUN}/head{HEAD} is the latest FULL canonical release: the P23.5 preview round trip. Gate489 is the immediate rollback.

The next slice adds `scripts/verify-p23-6-durable-time-assisted-snapshot-provenance-closure.mjs`, closes the P23 ledger below at P23.6 and adds the P23 closure section and the P24 definition. No production file changes. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate491' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate490 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate489',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate490 P23.5 saved time-assisted snapshot preview round trip amendment',arch)
print('inserted')
