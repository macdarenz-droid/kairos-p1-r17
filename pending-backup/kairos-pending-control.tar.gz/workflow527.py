"""Pin Gate527 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate526 zip, prev = Gate525 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P34_3_PROFILE_DATA_SAFETY_CLOSURE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P34_2_PROFILE_DATA_SAFETY_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P34_1_LAST_BACKUP_RECORD_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P34.2 Profile Data Safety','name: Kairos Controlled Roadmap Gate — P34.3 Profile Data Safety Closure')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P34.2 profile data safety scope from Gate525','      - name: Confirm exact P34.3 closure scope from Gate526')
start=s.index("          expected = {\n            'KAIROS_P34_2_PROFILE_DATA_SAFETY_REPORT_2026-09-18.md',")
end=s.index("            print('P34.2 profile data safety scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P34_3_PROFILE_DATA_SAFETY_CLOSURE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p34-2-profile-data-safety.mjs',
            'scripts/verify-p34-3-profile-data-safety-closure.mjs',
          }
          if changed != expected or removed:
            print('P34.3 closure scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P34.2 profile data safety\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P34.3 profile data safety closure
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p34:3-profile-data-safety-closure
          npm run verify:p34:2-profile-data-safety
          npm run verify:p34:1-last-backup-record
          npx vitest run \\
            tests/profile-data-safety.test.tsx \\
            tests/last-backup-record.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p34:2-profile-data-safety',""","""          for (const required of [
            'verify:p34:3-profile-data-safety-closure',
            'verify:p34:2-profile-data-safety',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P34_2_PROFILE_DATA_SAFETY_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P34_3_PROFILE_DATA_SAFETY_CLOSURE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P34_2_PROFILE_DATA_SAFETY_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate527')
