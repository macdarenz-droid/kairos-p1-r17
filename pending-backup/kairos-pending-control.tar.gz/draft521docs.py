"""Insert Gate521 continuity entries into the work521 docs. Reads Gate520 evidence from gate520-evidence.txt, zip520.txt and head520.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate520-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip520.txt').read().split()
HEAD=open(sp+'head520.txt').read().strip()
root=sp+'work521/kairos_p76/docs/'
label="**Patch label:** P32.3 · P32 Journal import: merge trades from a backup · owner phase P32 (closure) · definition: source-proven closure of P32 and the definition of P33 from current ownership."
ev=f"Gate520/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P32_2_PROFILE_IMPORT_CONTROL_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate519 is the immediate rollback. P32.2 is canonical."
approval=f"""## Manual Gate521 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. P32.3 closes P32 with no production runtime change: the P32 ledger is SYSTEM CLOSED through P32.3, the closure report and whole-phase verifier prove the merge-import command and the Profile import card retained with their verifiers, the Gate520 verifier pin on the P32 ledger heading advanced to the closure literal, and P33 (Library import: merge saved records from a backup) is defined from research: the backup carries every Saved Analysis and saved snapshot with its id, their repositories expose identity reads and writes, and P32 merges trades only. P33.1 (saved-record merge-import command) follows without a further prompt. UI VISIBLE:NO. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate520

{label}

Gate520/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P32.2 (Profile import control) is canonical. Gate519 remains its immediate rollback. The next slice (Gate521, P32.3) closes P32 and defines P33 (Library import: merge saved records from a backup).

"""
arch=f"""## Gate521 P32 closure and P33 definition amendment

{label}

Gate520/run{RUN}/head{HEAD} is the latest FULL canonical release: the P32.2 Profile import control. Gate519 is the immediate rollback.

The next slice closes the P32 ledger below through P32.3 and defines P33 from ownership. No production runtime owner is added; every route, command and the schema are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate521' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate520 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate519',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate520 P32.2 Profile import control amendment',arch)
print('inserted')
