"""Pin Gate516 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate515 zip, prev = Gate514 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P31_1_DRAFT_TRADE_ACTIVATION_COMMAND_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P30_3_TRADE_RECORD_LIFECYCLE_CLOSURE_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P30_2_TRADE_DELETE_CONTROLS_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P30.3 Trade Record Lifecycle Closure','name: Kairos Controlled Roadmap Gate — P31.1 Draft Trade Activation Command')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P30.3 closure scope from Gate514','      - name: Confirm exact P31.1 draft trade activation command scope from Gate515')
start=s.index("          expected = {\n            'KAIROS_P30_3_TRADE_RECORD_LIFECYCLE_CLOSURE_REPORT_2026-09-18.md',")
end=s.index("            print('P30.3 closure scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P31_1_DRAFT_TRADE_ACTIVATION_COMMAND_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p30-3-trade-record-lifecycle-closure.mjs',
            'scripts/verify-p31-1-draft-trade-activation-command.mjs',
            'src/application/trades/index.ts',
            'src/application/trades/openDraftTrade.ts',
            'tests/draft-trade-activation-command.test.ts',
          }
          if changed != expected or removed:
            print('P31.1 draft trade activation command scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P30.3 trade record lifecycle closure\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P31.1 draft trade activation command
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p31:1-draft-trade-activation-command
          npm run verify:p30:3-trade-record-lifecycle-closure
          npm run verify:p10:manual-trade-save-command
          npx vitest run \\
            tests/draft-trade-activation-command.test.ts \\
            tests/journal-open-trade-update.test.tsx \\
            tests/manual-trade-save-command.test.ts \\
            tests/trade-record-delete-command.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p30:3-trade-record-lifecycle-closure',""","""          for (const required of [
            'verify:p31:1-draft-trade-activation-command',
            'verify:p30:3-trade-record-lifecycle-closure',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P30_3_TRADE_RECORD_LIFECYCLE_CLOSURE_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P31_1_DRAFT_TRADE_ACTIVATION_COMMAND_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P30_3_TRADE_RECORD_LIFECYCLE_CLOSURE_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate516')
