"""Apply the Gate497 (P25.3) closure ledger/plan edits to work497 (idempotent; run before draft497docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work497/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P25 canonical ownership ledger — ACTIVE through P25\.\d+', '## P25 canonical ownership ledger — SYSTEM CLOSED through P25.3', s, count=1)
row="| P25.3 | Saved record labels system closure | verification/docs/package boundary only; no production runtime owner added | Proves P25.1–P25.2 as the complete source-proven P25 boundary and defines P26 from ownership |\n"
anchor="no rename of existing records, no persistence ownership |\n"
if row not in s:
    assert s.count(anchor)==1; s=s.replace(anchor, anchor+row, 1)
section="""## P25 Saved Record Labels System Closure — P25.3

P25.3 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P25.1 label policy and acceptance and the P25.2 label inputs and list presentation are mounted and retained with their verifiers; the closure report is `KAIROS_P25_3_SAVED_RECORD_LABELS_CLOSURE_REPORT_2026-09-18.md` and its verifier `scripts/verify-p25-3-saved-record-labels-closure.mjs`. Labels never change schema, backup format or journal truth.

## P26 — Goals foundation (defined from ownership, not begun)

Research against current source: `src/app/navigation.ts` lists Goals under the More tab and `src/app/routes.tsx` renders it as `PlaceholderRoute` ("This area is ready for a future Kairos patch"), as it does Library, Practice and Profile; the roadmap recorded Goals & Discipline as the phase following P21 before P22 was re-pointed to the time-assisted snapshot. P26 replaces the Goals placeholder with a real owner in dependency order: a goal contract (a small set of user-set targets such as a monthly realized-result target and a maximum trades per day) persisted as P5 metadata records under a reserved key namespace (no schema change, no backup format bump, excluded from nothing the released backup already covers), a read-only progress projection over the released P11 journal results and P12 history (no new arithmetic truth, currency-aware only where P13 already is), and the Goals route UI with unit and real-browser evidence. Proven from ownership: P5 owns metadata persistence, P11/P12/P13 own results and history, the shell owns navigation; the only new owners are the goal contract, its metadata mapping, the projection and the route. Library, Practice and Profile stay placeholders until their own phases. P26 may not begin before that PASS (the Gate497 canonical PASS of P25.3).

"""
if '## P25 Saved Record Labels System Closure — P25.3' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert s.count(anchor2)==1; s=s.replace(anchor2, section+anchor2, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Updated at Gate495: P25 ACTIVE (saved record labels) from the Gate494 canonical PASS."
add=" Updated at Gate497: P17–P25 closed; P26 defined (Goals foundation), not begun; P27–P40 later."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
