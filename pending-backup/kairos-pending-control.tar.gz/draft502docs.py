"""Insert Gate502 continuity entries into the work502 docs. Reads Gate501 evidence from gate501-evidence.txt, zip501.txt and head501.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate501-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip501.txt').read().split()
HEAD=open(sp+'head501.txt').read().strip()
root=sp+'work502/kairos_p76/docs/'
label="**Patch label:** P27.1 · P27 Library foundation · owner phase P27 (active from the Gate501 canonical PASS) · definition: the read-only cross-market index over the released Saved Analysis and saved snapshot listings, with ordering, distinct markets and a kind/market filter."
ev=f"Gate501/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P26_4_GOALS_FOUNDATION_CLOSURE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate500 is the immediate rollback. P26 is SYSTEM CLOSED through P26.4."
approval=f"""## Manual Gate502 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: both saved-record repositories already list everything, so the index needs no new store, index or field; the P20.1 contract carries no save moment, so Saved Analyses order by label then id after the snapshots and state no save moment. P27.1 adds `src/application/library/savedRecordIndex.ts` (build, order, filter by kind and exact market, distinct markets, counts, database read through the released repositories). The Library route stays a placeholder until P27.2. UI VISIBLE:NO. P27.2 (the Library route with the Open-in-Analysis handoff) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate501

{label}

Gate501/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P26 is SYSTEM CLOSED through P26.4 and P27 is defined from research. Gate500 remains its immediate rollback. The next slice (Gate502, P27.1) is the saved-record index; P27.2 (Library route) and P27.3 (closure) follow.

"""
arch=f"""## Gate502 P27.1 saved record index amendment

{label}

Gate501/run{RUN}/head{HEAD} is the latest FULL canonical release: the P26 closure. Gate500 is the immediate rollback.

The next slice adds `src/application/library/savedRecordIndex.ts` (exported through `src/application/library/index.ts`) and starts the P27 ledger below at P27.1. P20, P23, P25 and the shell are unchanged; the Library route stays a placeholder. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate502' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate501 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate500',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate501 P26 closure and P27 definition amendment',arch)
print('inserted')
