"""Pin Gate493 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate492 zip, prev = Gate491 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P24_2_SAVED_RECORD_DELETE_CONTROLS_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P24_1_SAVED_RECORD_DELETE_COMMANDS_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P23_6_DURABLE_TIME_ASSISTED_SNAPSHOT_PROVENANCE_CLOSURE_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P24.1 Saved Record Delete Commands','name: Kairos Controlled Roadmap Gate — P24.2 Saved Record Delete Controls')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P24.1 saved record delete commands scope from Gate491','      - name: Confirm exact P24.2 saved record delete controls scope from Gate492')
start=s.index("          expected = {\n            'KAIROS_P24_1_SAVED_RECORD_DELETE_COMMANDS_REPORT_2026-09-18.md',")
end=s.index("            print('P24.1 saved record delete commands scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P24_2_SAVED_RECORD_DELETE_CONTROLS_REPORT_2026-09-18.md',
            'docs/KAIROS_ANALYSIS_SAVED_RECORD_DELETE.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-saved-record-delete-browser.mjs',
            'scripts/verify-p24-2-saved-record-delete-controls.mjs',
            'src/app/AnalysisSavedAnalysisControls.tsx',
            'src/app/AnalysisTimeAssistedSnapshotControls.tsx',
            'src/app/analysisSavedAnalysisRoundTrip.ts',
            'src/app/analysisSavedTimeAssistedSnapshotRoundTrip.ts',
            'tests/analysis-saved-analysis-round-trip.test.tsx',
            'tests/analysis-saved-record-delete.test.tsx',
            'tests/analysis-time-assisted-snapshot-saved-round-trip.test.tsx',
          }
          if changed != expected or removed:
            print('P24.2 saved record delete controls scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P24.1 saved record delete commands\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P24.2 saved record delete controls
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p24:2-saved-record-delete-controls
          npm run verify:p24:1-saved-record-delete-commands
          npm run verify:analysis-saved-analysis-round-trip
          npm run verify:p23:5-saved-time-assisted-snapshot-preview-round-trip
          npm run verify:analysis-time-assisted-snapshot-preview
          npx vitest run \\
            tests/analysis-saved-record-delete.test.tsx \\
            tests/analysis-saved-analysis-round-trip.test.tsx \\
            tests/analysis-time-assisted-snapshot-saved-round-trip.test.tsx \\
            tests/analysis-time-assisted-snapshot-preview.test.tsx \\
            tests/analysis-history-workspace.test.tsx \\
            tests/saved-record-delete-commands.test.ts

"""+s[end:]
rep("          node scripts/test-analysis-time-assisted-snapshot-saved-browser.mjs\n","          node scripts/test-analysis-time-assisted-snapshot-saved-browser.mjs\n          node scripts/test-analysis-saved-record-delete-browser.mjs\n")
rep("""          for (const required of [
            'verify:p24:1-saved-record-delete-commands',""","""          for (const required of [
            'verify:p24:2-saved-record-delete-controls',
            'verify:p24:1-saved-record-delete-commands',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P24_1_SAVED_RECORD_DELETE_COMMANDS_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P24_2_SAVED_RECORD_DELETE_CONTROLS_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_SAVED_RECORD_DELETE.md
            .gate-candidate/kairos_p76/.saved-record-delete-evidence/
            .gate-candidate/kairos_p76/KAIROS_P24_1_SAVED_RECORD_DELETE_COMMANDS_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate493')
