"""Insert Gate496 continuity entries into the work496 docs. Reads Gate495 evidence from gate495-evidence.txt, zip495.txt and head495.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate495-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip495.txt').read().split()
HEAD=open(sp+'head495.txt').read().strip()
root=sp+'work496/kairos_p76/docs/'
label="**Patch label:** P25.2 · P25 saved record labels · owner phase P25 (active from the Gate494 canonical PASS) · definition: the label input beside Save analysis and Save snapshot, the label-first presentation of both saved-record lists, and their unit and real-browser evidence."
ev=f"Gate495/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P25_1_SAVED_RECORD_LABEL_FOUNDATION_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate494 is the immediate rollback. P25.1 is canonical."
approval=f"""## Manual Gate496 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. P25.2 threads the label through both round-trip ports (the Gate478/Gate490 pinned literals advance to the amended lines, never relaxed), adds the **Analysis label** and **Snapshot label** inputs before the Save buttons (capped at 80 characters, cleared after a successful save, blank saves an unlabelled record, over-long refused in plain words without a write) and leads both lists' option text with the label when present. Real browser evidence (`scripts/test-analysis-saved-record-label-browser.mjs`, `.saved-record-label-evidence/`) proves the trimmed stored label, the cleared input, label-first listing beside an unlabelled record, refusal over 80 characters, survival through load, reload and a backup V4 round trip, an untouched journal and both viewports in both themes. UI VISIBLE:YES. P25.3 (closure) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate495

{label}

Gate495/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P25.1 (label foundation) is canonical. Gate494 remains its immediate rollback. The next slice (Gate496, P25.2) mounts the label inputs and list presentation with browser evidence; P25.3 (closure) follows.

"""
arch=f"""## Gate496 P25.2 saved record label presentation amendment

{label}

Gate495/run{RUN}/head{HEAD} is the latest FULL canonical release: the P25.1 label foundation. Gate494 is the immediate rollback.

The next slice threads `label` through both round-trip ports and summaries, adds the label inputs and label-first option text inside the released Saved analysis and Saved snapshot groups (route-scoped CSS inside the released blocks), adds the unit and real-browser evidence and `docs/KAIROS_ANALYSIS_SAVED_RECORD_LABELS.md`, and advances the P25 ledger below to P25.2. The workspace mounts, P20, P23, P24 and the journal owners are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate496' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate495 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate494',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate495 P25.1 saved record label foundation amendment',arch)
print('inserted')
