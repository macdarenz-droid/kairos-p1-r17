"""Insert Gate488 continuity entries into the work488 docs. Reads Gate487 evidence from gate487-evidence.txt (RUN JOB ART_CAND ART_CAND_SHA ART_EV ART_EV_SHA MAINRUN)."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate487-evidence.txt').read().split()
root=sp+'work488/kairos_p76/docs/'
label="**Patch label:** P23.3 · P23 durable time-assisted snapshot provenance · owner phase P23 (active from the Gate485 canonical PASS) · definition: the application save command that turns a composed P22.2 time-assisted snapshot into one persisted P23.1 record."
ev=f"Gate487/run{RUN}/job{JOB}/heada46d886 is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P23_2_SAVED_TIME_ASSISTED_SNAPSHOT_PERSISTENCE_FOUNDATION_CANDIDATE_2026-09-18.zip;4072784bytes;SHA256 b8e9aa3c4524d55a1c45ece89133fd656c33bf4fc022948ccadfe5ef0ce01e70; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate486 is the immediate rollback. P23.2 is canonical: schema v5, backup format V4."
approval=f"""## Manual Gate488 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 decision ("1": proceed with P23 under the same gate discipline). P23.3 adds `src/application/saved-time-assisted-snapshot/saveSavedTimeAssistedSnapshot.ts`: it accepts only a composed P22.2 snapshot plus the device time zone, takes the entered instants from the estimates' own `requestedAt`, normalises them to UTC, records the save moment, allocates the P23.1 identity and performs one atomic repository write over the P23.2 store, with explicit invalid-input (`snapshot-not-composed`, `time-zone-invalid`, `opened-at-invalid`, `closed-at-invalid`) and storage-error results and no caller mutation. UI VISIBLE:NO. No UI, no list/load/delete, no estimate acquisition; P23.4 (load-one) may not begin before this PASS. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate487

{label}

Gate487/run{RUN}/heada46d886 is FULL canonical PASS with every stage and both exact-run artifacts present: P23.2 (schema v5 store, V5 migration, repository, integrity, backup format V4, restore coverage) is canonical. Gate486 remains its immediate rollback. The next slice (Gate488, P23.3) is the application save command; P23.4 (load-one) follows.

"""
arch=f"""## Gate488 P23.3 saved time-assisted snapshot application save amendment

{label}

Gate487/run{RUN}/heada46d886 is the latest FULL canonical release: the P23.2 persistence foundation. Gate486 is the immediate rollback.

The next slice adds `src/application/saved-time-assisted-snapshot/saveSavedTimeAssistedSnapshot.ts` (and its index) and advances the P23 ledger below to P23.3. P22, P23.1, P23.2, P20 and the journal owners are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate488' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate487 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate486',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate487 P23.2 saved time-assisted snapshot persistence amendment',arch)
print('inserted')
