"""Insert Gate508 continuity entries into the work508 docs. Reads Gate507 evidence from gate507-evidence.txt, zip507.txt and head507.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate507-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip507.txt').read().split()
HEAD=open(sp+'head507.txt').read().strip()
root=sp+'work508/kairos_p76/docs/'
label="**Patch label:** P28.4 · P28 Profile foundation: your data · owner phase P28 (closure) · definition: source-proven closure of P28 and the definition of P29 from current ownership."
ev=f"Gate507/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P28_3_PROFILE_ROUTE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate506 is the immediate rollback. P28.3 is canonical."
approval=f"""## Manual Gate508 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. P28.4 closes P28 with no production runtime change: the P28 ledger is SYSTEM CLOSED through P28.4, the closure report and whole-phase verifier prove the export command, the restore command and the Profile route retained with their verifiers, and P29 (Practice foundation: paper trades) is defined from research: the trade contract already admits `source: 'paper'`, only `manual` is written, and `listJournalHistory` is the one history seam behind every released consumer and does not filter by source. The Gate506/Gate507 verifier pins on the P28 ledger heading advanced to the closure literal. P29.1 (practice trade command) follows without a further prompt. UI VISIBLE:NO. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate507

{label}

Gate507/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P28.3 (Profile route) is canonical. Gate506 remains its immediate rollback. The next slice (Gate508, P28.4) closes P28 and defines P29 (Practice foundation: paper trades).

"""
arch=f"""## Gate508 P28 closure and P29 definition amendment

{label}

Gate507/run{RUN}/head{HEAD} is the latest FULL canonical release: the P28.3 Profile route. Gate506 is the immediate rollback.

The next slice closes the P28 ledger below through P28.4 and defines P29 from ownership. No production runtime owner is added; every route, P6 and the activation service are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate508' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate507 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate506',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate507 P28.3 Profile route amendment',arch)
print('inserted')
