"""Insert Gate506 continuity entries into the work506 docs. Reads Gate505 evidence from gate505-evidence.txt, zip505.txt and head505.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate505-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip505.txt').read().split()
HEAD=open(sp+'head505.txt').read().strip()
root=sp+'work506/kairos_p76/docs/'
label="**Patch label:** P28.2 · P28 Profile foundation: your data · owner phase P28 (active from the Gate504 canonical PASS) · definition: the two-step application command that restores a backup file over the released P6 preflight → preview → confirm → verified replacement path with explicit outcomes and the pre-restore copy on every failure."
ev=f"Gate505/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P28_1_BACKUP_EXPORT_COMMAND_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate504 is the immediate rollback. P28.1 is canonical."
approval=f"""## Manual Gate506 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the P6.3 preflight and recovery snapshot and the P6.4/P6.5 verified replacement already own every restore invariant and no route calls them, so P28.2 composes them into two explicit steps in `src/application/backup/restoreBackup.ts`: prepare (64 MiB text guard before parsing, typed validation and preflight refusals, the pre-restore recovery snapshot exposed as a downloadable P28.1 file, nothing written) and the explicitly confirmed commit (atomic replacement, reopen and re-query verification), every post-commit failure carrying the recovery file. Device-scoped metadata survives a restore as P6 defines. The Profile route stays a placeholder until P28.3. UI VISIBLE:NO. P28.3 (Profile route) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate505

{label}

Gate505/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P28.1 (backup export command) is canonical. Gate504 remains its immediate rollback. The next slice (Gate506, P28.2) is the restore command; P28.3 (Profile route) and P28.4 (closure) follow.

"""
arch=f"""## Gate506 P28.2 backup restore command amendment

{label}

Gate505/run{RUN}/head{HEAD} is the latest FULL canonical release: the P28.1 backup export command. Gate504 is the immediate rollback.

The next slice adds `src/application/backup/restoreBackup.ts` (exported through `src/application/backup/index.ts`) and advances the P28 ledger below to P28.2. P6, P5, the shell and every route are unchanged; Profile stays a placeholder. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate506' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate505 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate504',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate505 P28.1 backup export command amendment',arch)
print('inserted')
