"""Insert Gate512 continuity entries into the work512 docs. Reads Gate511 evidence from gate511-evidence.txt, zip511.txt and head511.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate511-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip511.txt').read().split()
HEAD=open(sp+'head511.txt').read().strip()
root=sp+'work512/kairos_p76/docs/'
label="**Patch label:** P29.4 · P29 Practice foundation: paper trades · owner phase P29 (closure) · definition: source-proven closure of P29 and the definition of P30 from current ownership."
ev=f"Gate511/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P29_3_PRACTICE_ROUTE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate510 is the immediate rollback. P29.3 is canonical."
approval=f"""## Manual Gate512 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. P29.4 closes P29 with no production runtime change: the P29 ledger is SYSTEM CLOSED through P29.4, the closure report and whole-phase verifier prove the practice trade command, the history source scope and the Practice route retained with their verifiers, the Gate510/Gate511 verifier pins on the P29 ledger heading advanced to the closure literal, and P30 (Trade record lifecycle: delete) is defined from research: no application command and no route can remove a trade record, the repository delete serves only the P6 restore path, and P24 already proved the delete pattern for saved records. P30.1 (trade delete command) follows without a further prompt. UI VISIBLE:NO. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate511

{label}

Gate511/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P29.3 (Practice route) is canonical. Gate510 remains its immediate rollback. The next slice (Gate512, P29.4) closes P29 and defines P30 (Trade record lifecycle: delete).

"""
arch=f"""## Gate512 P29 closure and P30 definition amendment

{label}

Gate511/run{RUN}/head{HEAD} is the latest FULL canonical release: the P29.3 Practice route. Gate510 is the immediate rollback.

The next slice closes the P29 ledger below through P29.4 and defines P30 from ownership. No production runtime owner is added; every route, the history seam and the schema are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate512' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate511 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate510',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate511 P29.3 Practice route amendment',arch)
print('inserted')
