"""Apply the Gate512 (P29.4) closure ledger/plan edits to work512 (idempotent; run before draft512docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work512/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P29 canonical ownership ledger — ACTIVE through P29\.\d+', '## P29 canonical ownership ledger — SYSTEM CLOSED through P29.4', s, count=1)
row="| P29.4 | Practice foundation system closure | verification/docs/package boundary only; no production runtime owner added | Proves P29.1–P29.3 as the complete source-proven P29 boundary and defines P30 from ownership |\n"
anchor="no open-trade update or delete of practice trades, no real result touched |\n"
if row not in s:
    assert s.count(anchor)==1; s=s.replace(anchor, anchor+row, 1)
section="""## P29 Practice Foundation System Closure — P29.4

P29.4 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P29.1 practice trade command, the P29.2 history source scope with its scoped repository view and the P29.3 Practice route are mounted and retained with their verifiers; the closure report is `KAIROS_P29_4_PRACTICE_FOUNDATION_CLOSURE_REPORT_2026-09-18.md` and its verifier `scripts/verify-p29-4-practice-foundation-closure.mjs`. Practice trades are recorded through the released P10 validation, listed only through the `practice` scope, and never enter the Journal history, Home Your Trades, daily results, Goals progress or trade review selection; every released consumer line, the Journal route and the schema are unchanged.

## P30 — Trade record lifecycle: delete (defined from ownership, not begun)

Research against current source: no application command and no route can remove a trade record. `src/application/trades` owns the manual save (P10.1) and the open-trade update (append fills, close; manual trades only), P29.1 owns the practice save, and `TradeRepository.delete` exists only for the P6 restore path; a draft, cancelled, mistaken or practice trade stays on the device forever. P24 already proved the pattern for saved records: an atomic delete command with explicit outcomes, then confirmed controls in the released lists, then closure. P30 gives trade records the same lifecycle in dependency order: P30.1 a delete command that removes one trade and its plans, executions and fees in one atomic write with explicit not-found and storage-error outcomes, never touching another trade, a saved record or a backup; P30.2 the delete control on the released history card (Journal and Practice through the shared list) with an explicit confirmation, plain-word outcomes, list refresh and the daily results and Home refreshed through their released owners, proven in unit tests and a real browser; and P30.3 the closure. Proven from ownership: P10/P29.1 own the writes, P12 the history list and hydration, P13/P26/Home their read-only projections, P5 the database; the only new owners are the command and the control. P30 may not begin before that PASS (the Gate512 canonical PASS of P29.4).

"""
if '## P29 Practice Foundation System Closure — P29.4' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert s.count(anchor2)==1; s=s.replace(anchor2, section+anchor2, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Updated at Gate509: P29 ACTIVE (Practice foundation: paper trades) from the Gate508 canonical PASS."
add=" Updated at Gate512: P17–P29 closed; P30 defined (Trade record lifecycle: delete), not begun; P31–P40 later."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
