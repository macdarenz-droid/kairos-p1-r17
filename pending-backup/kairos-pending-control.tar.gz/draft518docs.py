"""Insert Gate518 continuity entries into the work518 docs. Reads Gate517 evidence from gate517-evidence.txt, zip517.txt and head517.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate517-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip517.txt').read().split()
HEAD=open(sp+'head517.txt').read().strip()
root=sp+'work518/kairos_p76/docs/'
label="**Patch label:** P31.3 · P31 Trade record lifecycle: draft activation · owner phase P31 (closure) · definition: source-proven closure of P31 and the definition of P32 from current ownership."
ev=f"Gate517/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P31_2_DRAFT_TRADE_ACTIVATION_CONTROL_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate516 is the immediate rollback. P31.2 is canonical."
approval=f"""## Manual Gate518 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. P31.3 closes P31 with no production runtime change: the P31 ledger is SYSTEM CLOSED through P31.3, the closure report and whole-phase verifier prove the activation command and control retained with their verifiers, the Gate517 verifier pin on the P31 ledger heading advanced to the closure literal, and P32 (Journal import: merge trades from a backup) is defined from research: the import source exists in the contract, the P6 backup format carries every trade with its id and children, the P6 parse and preflight validate any Kairos backup, and the only way to bring records from another device is the P28 restore, which replaces everything. P32.1 (merge-import command) follows without a further prompt. UI VISIBLE:NO. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate517

{label}

Gate517/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P31.2 (draft trade activation control) is canonical. Gate516 remains its immediate rollback. The next slice (Gate518, P31.3) closes P31 and defines P32 (Journal import: merge trades from a backup).

"""
arch=f"""## Gate518 P31 closure and P32 definition amendment

{label}

Gate517/run{RUN}/head{HEAD} is the latest FULL canonical release: the P31.2 draft trade activation control. Gate516 is the immediate rollback.

The next slice closes the P31 ledger below through P31.3 and defines P32 from ownership. No production runtime owner is added; every route, command and the schema are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate518' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate517 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate516',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate517 P31.2 draft trade activation control amendment',arch)
print('inserted')
