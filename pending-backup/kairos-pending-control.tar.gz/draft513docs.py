"""Insert Gate513 continuity entries into the work513 docs. Reads Gate512 evidence from gate512-evidence.txt, zip512.txt and head512.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate512-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip512.txt').read().split()
HEAD=open(sp+'head512.txt').read().strip()
root=sp+'work513/kairos_p76/docs/'
label="**Patch label:** P30.1 · P30 Trade record lifecycle: delete · owner phase P30 (active from the Gate512 canonical PASS) · definition: the application command that removes one trade record with its plans, executions and fees in one atomic write, with explicit outcomes and nothing else touched."
ev=f"Gate512/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P29_4_PRACTICE_FOUNDATION_CLOSURE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate511 is the immediate rollback. P29 is SYSTEM CLOSED through P29.4."
approval=f"""## Manual Gate513 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the P5 repositories already expose get, list-by-trade and delete for every trade store and the P9 atomic write covers several stores in one transaction, and P24.1 already fixed the delete-command contract for saved records. P30.1 adds `src/application/trades/deleteTradeRecord.ts`: one trade and its own plans, executions and fees removed in one atomic write by canonical id whatever the source, explicit not-found and storage-error outcomes, removed counts disclosed, no other trade, saved record or backup touched. The Gate512 verifier pin that asserted no delete command existed advanced to the command literal; the history card carries no control until P30.2. UI VISIBLE:NO. P30.2 (delete controls) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate512

{label}

Gate512/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P29 is SYSTEM CLOSED through P29.4 and P30 is defined from research. Gate511 remains its immediate rollback. The next slice (Gate513, P30.1) is the trade record delete command; P30.2 (delete controls) and P30.3 (closure) follow.

"""
arch=f"""## Gate513 P30.1 trade record delete command amendment

{label}

Gate512/run{RUN}/head{HEAD} is the latest FULL canonical release: the P29 closure. Gate511 is the immediate rollback.

The next slice adds `src/application/trades/deleteTradeRecord.ts` (exported through `src/application/trades/index.ts`) and starts the P30 ledger below at P30.1. P10, P12, the shell and every route are unchanged; the history card carries no delete control yet. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate513' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate512 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate511',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate512 P29 closure and P30 definition amendment',arch)
print('inserted')
