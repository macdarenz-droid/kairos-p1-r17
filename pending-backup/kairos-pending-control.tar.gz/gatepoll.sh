#!/bin/bash
# Usage: gatepoll.sh N — creates pollN.sh from poll486.sh for head N, starts it, and prints the run id once found.
N=$1; SP=/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad; cd $SP
H=$(cat head$N.txt)
sed "s/run486.log/run$N.log/g; s/fbb9e0e/$H/g" poll486.sh > poll$N.sh && chmod +x poll$N.sh
nohup ./poll$N.sh >/dev/null 2>&1 &
for i in $(seq 1 30); do [ -s run$N.log ] && grep -q "^RUN" run$N.log && break; sleep 5; done
head -1 run$N.log
