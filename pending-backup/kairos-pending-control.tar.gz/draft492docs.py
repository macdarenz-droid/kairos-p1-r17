"""Insert Gate492 continuity entries into the work492 docs. Reads Gate491 evidence from gate491-evidence.txt, zip491.txt and head491.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate491-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip491.txt').read().split()
HEAD=open(sp+'head491.txt').read().strip()
root=sp+'work492/kairos_p76/docs/'
label="**Patch label:** P24.1 · P24 saved record lifecycle · owner phase P24 (active from the Gate491 canonical PASS) · definition: the application delete commands for one Saved Analysis and one saved time-assisted snapshot by canonical stable id."
ev=f"Gate491/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P23_6_DURABLE_TIME_ASSISTED_SNAPSHOT_PROVENANCE_CLOSURE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate490 is the immediate rollback. P23 is SYSTEM CLOSED through P23.6."
approval=f"""## Manual Gate492 slice — 18 September 2026

{label}

{ev}

User decision, 18 September 2026: after the P23 closure report offered P24 (saved record lifecycle) or the parked UI review, the user replied "continue"; under the standing autonomous-continuation instruction and the P22→P23 precedent this is recorded as proceeding with P24 under the same gate discipline, not as a UI review (the user's physical UI inspection and the parked Ink amendments stay deferred to the user's checkpoint). P24.1 adds `deleteSavedAnalysis` and `deleteSavedTimeAssistedSnapshot`: one atomic write each over its own store, read and delete in the same transaction, explicit not-found and storage-error results, no cascade into the journal, the other store or backup/restore. UI VISIBLE:NO. P24.2 (Delete analysis / Delete snapshot controls on the Analysis page with browser evidence) may not begin before this PASS. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate491

{label}

Gate491/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P23 is SYSTEM CLOSED through P23.6 and P24 is defined from ownership. Gate490 remains its immediate rollback. The user chose to continue; the next slice (Gate492, P24.1) is the delete commands; P24.2 (page controls) and P24.3 (closure) follow.

"""
arch=f"""## Gate492 P24.1 saved record delete commands amendment

{label}

Gate491/run{RUN}/head{HEAD} is the latest FULL canonical release: the P23 closure. Gate490 is the immediate rollback.

The next slice adds `src/application/saved-analysis/deleteSavedAnalysis.ts` and `src/application/saved-time-assisted-snapshot/deleteSavedTimeAssistedSnapshot.ts` (both exported from their application index) and starts the P24 ledger below at P24.1. P20, P23 and the journal owners are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate492' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate491 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate490',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate491 P23 closure and P24 definition amendment',arch)
print('inserted')
