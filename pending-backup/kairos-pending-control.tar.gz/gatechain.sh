#!/bin/bash
# Usage: gatechain.sh N PREV_ZIP NEW_ZIP MODE COMMIT_TITLE
#   MODE: reapply | closure   (closure runs closureN.py instead of reapply-ledger.py N)
# Syncs docs from work(N-1), applies N's ledger edits, drafts docs, packages, pins the workflow, commits and pushes. Prints head N.
set -e
N=$1; PREV_ZIP=$2; NEW_ZIP=$3; MODE=$4; TITLE=$5
SP=/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad
cd $SP
P=$((N-1)); PP=$((N-2))
for d in KAIROS_ARCHITECTURE_MAP.md KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md KAIROS_CONTINUATION_APPROVAL_CONTROL.md; do cp work$P/kairos_p76/docs/$d work$N/kairos_p76/docs/$d; done
if [ "$MODE" = "closure" ]; then python3 closure$N.py; else python3 reapply-ledger.py $N; fi
python3 draft${N}docs.py
rm -rf work$N/kairos_p76/.*-evidence work$N/kairos_p76/dist
./pkgnext.sh $N "$PREV_ZIP" "$NEW_ZIP" > pkg$N.log 2>&1
grep -A30 "work vs pkg" pkg$N.log | sed -n '2,40p' | grep -v "^[0-9]* [0-9a-f]\{64\}$\|zip copied" | grep -q . && { echo "WORK VS PKG NOT EMPTY"; cat pkg$N.log; exit 1; }
read SIZE SHA < zip$N.txt; read BSIZE BSHA < zip$P.txt; read PSIZE PSHA < zip$PP.txt
python3 workflow$N.py $SIZE $SHA $BSIZE $BSHA $PSIZE $PSHA
cd /home/user/kairos-p1-r17
git add -A
git commit -q -F - <<MSG
$TITLE

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_018pyp9iExFcgx5wuugMnKK5
MSG
git rev-parse --short HEAD > $SP/head$N.txt
for i in 1 2 3 4 5; do git branch -f claude/kairos-trading-journal-hftwax HEAD >/dev/null 2>&1; git push -u origin claude/kairos-trading-journal-hftwax >/dev/null 2>&1 && break; sleep $((2**i)); done
echo "HEAD $(cat $SP/head$N.txt) ZIP $SIZE $SHA"
