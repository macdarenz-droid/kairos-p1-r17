"""Insert Gate533 continuity entries into the work533 docs. Reads Gate532 evidence from gate532-evidence.txt, zip532.txt and head532.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate532-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip532.txt').read().split()
HEAD=open(sp+'head532.txt').read().strip()
root=sp+'work533/kairos_p76/docs/'
label="**Patch label:** P36.3 · P36 Discipline foundation: checklists, mistake tracking and discipline score (vision P22, discipline half) · owner phase P36 (active from the Gate530 canonical PASS) · definition: the pre-trade checklist on a draft or open trade and the post-trade review with mistake tags on a closed trade, on the released Journal and Practice history cards, through the P36.2 commands, proven in unit tests and a real browser."
ev=f"Gate532/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P36_2_TRADE_DISCIPLINE_COMMANDS_CANDIDATE_2026-09-20.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate531 is the immediate rollback. P36.2 is canonical."
approval=f"""## Manual Gate533 slice — 20 September 2026

{label}

{ev}

P36.3 adds `src/app/JournalTradeDiscipline.tsx` and its stylesheet (the pre-trade checklist on a draft or open trade, the review with mistake tags on a closed trade, a note, in the trader's own words, saved only through the P36.2 command) and the `onDisciplineSaved` port on `JournalHistoryList`, passed by the Journal route and on the Practice mount line scoped to `['paper']`. Unit and real-browser evidence (`tests/journal-trade-discipline-control.test.tsx`, `scripts/test-journal-trade-discipline-browser.mjs`). The P29.3 exact Practice mount-line pin advanced (`pin advanced at Gate533`); the P35.3, P36.1 and P36.2 "no P36.3 owner yet" checks advanced to the present control; nothing relaxed. The trades, results and projections are untouched; no score. UI VISIBLE:YES (history cards on Journal and Practice). Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate531

{label}

Gate532/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P36.2 (trade discipline commands) is canonical. Gate531 remains its immediate rollback. The next slice (Gate533, P36.3) mounts the discipline checklist and review controls on the Journal and Practice history cards.

"""
arch=f"""## Gate533 P36.3 trade discipline controls amendment

{label}

Gate532/run{RUN}/head{HEAD} is the latest FULL canonical release: the P36.2 trade discipline commands. Gate531 is the immediate rollback.

The next slice adds `src/app/JournalTradeDiscipline.tsx` and `src/app/journalTradeDiscipline.css`, the `onDisciplineSaved` port on `src/app/JournalHistoryList.tsx` passed by `src/app/JournalRoute.tsx` and `src/app/PracticeRoute.tsx`, and advances the P36 ledger below to P36.3. P36.2 keeps the commands, P12 the list, P30.2 and P31.2 their controls; the trades and every projection are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate533' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate532 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate531',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate532 P36.2 trade discipline commands amendment',arch)
print('inserted')
