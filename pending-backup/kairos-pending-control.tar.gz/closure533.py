"""Apply the Gate533 (P36.3) ledger edits to work533 (idempotent; run before draft533docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work533/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P36 canonical ownership ledger — ACTIVE through P36\.\d+', '## P36 canonical ownership ledger — ACTIVE through P36.3', s, count=1)
row="| P36.3 | Trade discipline controls | `src/app/JournalTradeDiscipline.tsx`, `src/app/journalTradeDiscipline.css`; the `onDisciplineSaved` port on `src/app/JournalHistoryList.tsx` mounted by `src/app/JournalRoute.tsx` and `src/app/PracticeRoute.tsx` | Owns the visible discipline surface on every eligible history card (manual on the Journal, paper on Practice, never cancelled): the one-line summary of the saved answers, the Pre-trade checklist / Edit checklist panel on a draft or open trade and the Review this trade / Edit review panel with mistake tags on a closed trade, in the trader's own words over the P36.1 vocabulary, a note, plain-word refusals with the answers kept, saving only through the P36.2 command with the list notice; the trades, results and projections untouched; every other released mount line keeps its literals; no score |\n"
if row not in s:
    anchor="| P36.2 | Trade discipline commands |"; i=s.index(anchor); j=s.index('\n',i)+1; s=s[:j]+row+s[j:]
open(p,'w').write(s); print('ledger edits applied')
