"""Apply the Gate534 (P36.4) ledger edits to work534 (idempotent; run before draft534docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work534/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P36 canonical ownership ledger — ACTIVE through P36\.\d+', '## P36 canonical ownership ledger — ACTIVE through P36.4', s, count=1)
row="| P36.4 | Discipline score | `src/application/discipline/disciplineScore.ts`, `src/application/discipline/loadDisciplineScore.ts` (exported through `src/application/discipline/index.ts`); `src/app/HomeDashboardDiscipline.tsx`, `src/app/homeDashboardDiscipline.css`; the one delegation line in `src/app/HomeRoute.tsx` | Owns the only discipline score: over the closed trades of the current calendar month (P13.6 day-key of each close in the explicit P13.10R1 time zone, bounded real-scope P12 history), the checklist-answered, reviewed and mistake-free counts, the weighted whole-number score (40 preparation, 20 honesty, 40 execution) and the ranked mistake tags; the loader with its unconfigured-time-zone outcome; and the Home card showing the score at a glance with every state in plain words; no other part of the app computes it; no write, no price, no result, no change to goals or projections |\n"
if row not in s:
    anchor="| P36.3 | Trade discipline controls |"; i=s.index(anchor); j=s.index('\n',i)+1; s=s[:j]+row+s[j:]
open(p,'w').write(s); print('ledger edits applied')
