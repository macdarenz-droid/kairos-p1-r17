"""Apply the Gate494 (P24.3) closure ledger/plan edits to work494 (idempotent; run before draft494docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work494/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P24 canonical ownership ledger — ACTIVE through P24\.\d+', '## P24 canonical ownership ledger — SYSTEM CLOSED through P24.3', s, count=1)
row="| P24.3 | Saved record lifecycle system closure | verification/docs/package boundary only; no production runtime owner added | Proves P24.1–P24.2 as the complete source-proven P24 boundary and defines P25 from ownership |\n"
anchor="no confirmation dialog, no undo, no persistence ownership |\n"
if row not in s:
    assert s.count(anchor)==1; s=s.replace(anchor, anchor+row, 1)
section="""## P24 Saved Record Lifecycle System Closure — P24.3

P24.3 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P24.1 delete commands and the P24.2 Delete analysis / Delete snapshot controls are mounted and retained with their verifiers; the closure report is `KAIROS_P24_3_SAVED_RECORD_LIFECYCLE_CLOSURE_REPORT_2026-09-18.md` and its verifier `scripts/verify-p24-3-saved-record-lifecycle-closure.mjs`. Deleting a saved record never touches the journal, the other store or backup/restore.

## P25 — saved record labels (defined from ownership, not begun)

Both saved-record lists identify a record only by the first eight characters of its id plus derived facts (line count; side and opening instant). P25 gives Saved Analyses (P20) and saved time-assisted snapshots (P23) an optional user-given label: a controlled amendment of the P20.1 and P23.1 contracts (an optional `label` string, no schema index), accepted by the P20.2/P23.2 record validators and backup format without a format bump (an absent label stays valid, so released backups still restore), set at save time from an input beside Save analysis / Save snapshot, shown in the lists and status lines, with unit and real-browser evidence. Proven from ownership: P20.1/P23.1 own the contracts, P20.2/P23.2 own persistence and validation, P21.27/P23.5/P24.2 own the page groups; no new store, migration or provider. P25 may not begin before that PASS (the Gate494 canonical PASS of P24.3).

"""
if '## P24 Saved Record Lifecycle System Closure — P24.3' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert s.count(anchor2)==1; s=s.replace(anchor2, section+anchor2, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Updated at Gate492: P24 ACTIVE (saved record lifecycle) from the Gate491 canonical PASS."
add=" Updated at Gate494: P17–P24 closed; P25 defined (saved record labels), not begun; P26–P40 later."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
