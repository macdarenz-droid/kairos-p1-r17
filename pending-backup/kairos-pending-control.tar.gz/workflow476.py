"""Pin Gate476 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA"""
import sys
size,sha,bsize,bsha=sys.argv[1:5]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — Analysis Drawing-Tools Session','name: Kairos Controlled Roadmap Gate — Analysis Drawing Tools Mount')
rep("      - 'KAIROS_ANALYSIS_DRAWING_TOOLS_RENDERER_SESSION_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_ANALYSIS_DRAWING_TOOLS_MOUNT_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_LIGHTWEIGHT_CHARTS_V5_PRODUCTION_DRAWING_BINDING_SEAM_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_DRAWING_TOOLS_RENDERER_SESSION_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_ANALYSIS_DRAWING_TOOLS_RENDERER_SESSION_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_DRAWING_TOOLS_MOUNT_CANDIDATE_2026-09-17.zip')
rep(f"            ('BASE_ZIP', 3920429, '2f9dc76439f3a6e48860017f03093d2b849af248035f76149c51052236609365'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact Analysis drawing-tools session scope from Gate474','      - name: Confirm exact Analysis drawing tools mount scope from Gate475')
rep("""          expected = {
            'docs/KAIROS_ANALYSIS_DRAWING_TOOLS_RENDERER_SESSION.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-analysis-drawing-tools-renderer-session.mjs',
            'src/app/analysisDrawingToolsRendererSession.ts',
            'tests/analysis-drawing-tools-renderer-session.test.ts',
          }
          if changed != expected or removed:
            print('Analysis drawing-tools session scope mismatch', file=sys.stderr)""","""          expected = {
            'docs/KAIROS_ANALYSIS_DRAWING_TOOLS_MOUNT.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-drawing-tools-browser.mjs',
            'scripts/verify-analysis-drawing-tools-mount.mjs',
            'src/app/AnalysisDrawingToolsControls.tsx',
            'src/app/AnalysisHistoryWorkspace.tsx',
            'src/app/AnalysisLiveCandleCanvas.tsx',
            'src/app/AnalysisSavedTradeOverlayLiveCandleCanvas.tsx',
            'src/app/analysisDrawingToolsComposition.ts',
            'src/app/analysisDrawingToolsContext.ts',
            'src/app/analysisHistory.css',
            'src/app/analysisLiveCandleProductPolicy.ts',
            'src/app/useAnalysisDrawingTools.ts',
            'tests/analysis-drawing-tools-mount.test.tsx',
          }
          if changed != expected or removed:
            print('Analysis drawing tools mount scope mismatch', file=sys.stderr)""")
rep("""            tests/chart-drawing-deletion-presentation-coordination.test.ts

      - name: Production TypeScript compilation""","""            tests/chart-drawing-deletion-presentation-coordination.test.ts

      - name: Analysis drawing tools mount
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:analysis-drawing-tools-mount
          npm run verify:analysis-drawing-tools-renderer-session
          npm run verify:analysis-saved-trade-overlay-workspace-mount
          npm run verify:analysis-saved-trade-position-box
          npm run verify:analysis-history-workspace
          npm run verify:p2:design-system
          npx vitest run \\
            tests/analysis-drawing-tools-mount.test.tsx \\
            tests/analysis-drawing-tools-renderer-session.test.ts \\
            tests/analysis-history-workspace.test.tsx \\
            tests/analysis-saved-trade-position-box.test.tsx

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:analysis-drawing-tools-renderer-session',""","""          for (const required of [
            'verify:analysis-drawing-tools-mount',
            'verify:analysis-drawing-tools-renderer-session',""")
rep("""          node scripts/test-analysis-position-box-browser.mjs

      - name: Full unit regression""","""          node scripts/test-analysis-position-box-browser.mjs
          node scripts/test-analysis-drawing-tools-browser.mjs

      - name: Full unit regression""")
rep("""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_DRAWING_TOOLS_RENDERER_SESSION.md""","""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_DRAWING_TOOLS_MOUNT.md
            .gate-candidate/kairos_p76/.drawing-tools-evidence/
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_DRAWING_TOOLS_RENDERER_SESSION.md""")
open(p,'w').write(s); print('workflow pinned for Gate476')
