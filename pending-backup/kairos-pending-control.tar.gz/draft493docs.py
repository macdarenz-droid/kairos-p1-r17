"""Insert Gate493 continuity entries into the work493 docs. Reads Gate492 evidence from gate492-evidence.txt, zip492.txt and head492.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate492-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip492.txt').read().split()
HEAD=open(sp+'head492.txt').read().strip()
root=sp+'work493/kairos_p76/docs/'
label="**Patch label:** P24.2 · P24 saved record lifecycle · owner phase P24 (active from the Gate491 canonical PASS) · definition: the visible delete of the selected Saved Analysis and the selected saved time-assisted snapshot on the Analysis page, through the released P24.1 commands, with real browser evidence."
ev=f"Gate492/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P24_1_SAVED_RECORD_DELETE_COMMANDS_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate491 is the immediate rollback. P24.1 is canonical."
approval=f"""## Manual Gate493 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's "continue" of 18 September 2026 (recorded at Gate492 as proceeding with P24 under the same gate discipline). P24.2 adds `remove` to the Saved Analysis and saved snapshot round-trip ports (calling the P24.1 commands; the released import lines stay verbatim) and mounts **Delete analysis** in the Gate478 Saved analysis group and **Delete snapshot** in the Gate490 Saved snapshot group: exactly the selected record is removed, the list refreshes, the chart, the shown estimate, the other store and the journal are untouched; no confirmation dialog and no undo (earlier backups keep the record). Real browser evidence (`scripts/test-analysis-saved-record-delete-browser.mjs`, `.saved-record-delete-evidence/`) seeds records through the released save commands, deletes per market, proves an untouched journal, survives a reload and empties both groups. UI VISIBLE:YES (autonomous continuation; the user's physical UI inspection remains deferred to the whole-app checkpoint). P24.3 (closure) may not begin before this PASS. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate492

{label}

Gate492/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P24.1 (delete commands) is canonical. Gate491 remains its immediate rollback. The next slice (Gate493, P24.2) mounts Delete analysis and Delete snapshot with browser evidence; P24.3 (closure) follows.

"""
arch=f"""## Gate493 P24.2 saved record delete controls amendment

{label}

Gate492/run{RUN}/head{HEAD} is the latest FULL canonical release: the P24.1 delete commands. Gate491 is the immediate rollback.

The next slice adds `remove` to both round-trip ports, the Delete analysis and Delete snapshot buttons inside the released groups, the unit and real-browser evidence and `docs/KAIROS_ANALYSIS_SAVED_RECORD_DELETE.md`, and advances the P24 ledger below to P24.2. The workspace mounts, P20, P23 and the journal owners are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate493' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate492 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate491',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate492 P24.1 saved record delete commands amendment',arch)
print('inserted')
