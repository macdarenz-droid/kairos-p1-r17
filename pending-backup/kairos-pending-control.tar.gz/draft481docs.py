"""Insert Gate481 continuity entries into the work481 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST ZIP_SIZE ZIP_SHA (Gate480 evidence + Gate480 zip)"""
import sys
run,job,head,cid,cdig,eid,edig,zsize,zsha=sys.argv[1:10]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work481/kairos_p76/docs/'
label="**Patch label:** P22.2 · P22 time-assisted trade snapshot · owner phase P22 (active) · definition: the readonly application composition that turns instrument, side and opening/closing instants into the two P22.1 estimates plus the exact duration, with no price, result or journal identity."
ev=f"Gate480/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P22_1_ESTIMATED_MARKET_REFERENCE_FOUNDATION_CANDIDATE_2026-09-17.zip;{zsize}bytes;SHA256 {zsha}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate479 is the immediate rollback."
approval=f"""## Manual Gate481 slice — 17 September 2026

{label}

{ev}

Under the user's autonomous-continuation authority, P22 continues with `KAIROS_P22_2_TIME_ASSISTED_TRADE_SNAPSHOT_COMPOSITION_REPORT_2026-09-17.md` and `src/application/market-reference/timeAssistedTradeSnapshot.ts`: `composeTimeAssistedTradeSnapshot` validates the request shape (side, opening instant, optional closing instant, ordering) before any port call, then resolves the opening and closing estimates through the released P22.1 boundary, each reporting its own availability, and carries side and the exact duration. The snapshot has no price, P&L, hypothetical result or execution identity; the feasibility policy allows a hypothetical result only with separately supplied assumptions, which this slice does not add. The P22.1 verifier's ledger-header pin is generalised to the active-P22 prefix so later P22 rows do not require touching it; every other P22.1 pin is unchanged. UI VISIBLE:NO. No UI, route, marker, interval/window policy, persistence or journal-truth change. The visible preview (inputs and disclosed estimated markers on the released chart) follows in later P22 slices. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate480

{label}

Gate480/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present: P22.1 (estimated market-reference contract and readonly lookup) is canonical. Gate479 remains its immediate rollback. The next slice (Gate481, P22.2) composes the opening/closing estimates and duration for a time-assisted trade; the visible preview follows.

"""
arch=f"""## Gate481 P22.2 time-assisted trade snapshot composition amendment

{label}

Gate480/run{run}/head{head} is the latest FULL canonical release: `src/application/market-reference/estimatedMarketReference.ts`. Gate479 is the immediate rollback.

The next slice adds `src/application/market-reference/timeAssistedTradeSnapshot.ts` (exported through the market-reference index) and the P22.2 ledger row below. P22.1, P15/P16, the journal owners and every P21 mount are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate481' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate480 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate479',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate480 P22.1 estimated market-reference foundation amendment',arch)
print('inserted')
