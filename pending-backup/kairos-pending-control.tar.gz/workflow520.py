"""Pin Gate520 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate519 zip, prev = Gate518 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P32_2_PROFILE_IMPORT_CONTROL_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P32_1_TRADE_MERGE_IMPORT_COMMAND_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P31_3_DRAFT_ACTIVATION_CLOSURE_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P32.1 Trade Merge-Import Command','name: Kairos Controlled Roadmap Gate — P32.2 Profile Import Control')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P32.1 trade merge-import command scope from Gate518','      - name: Confirm exact P32.2 profile import control scope from Gate519')
start=s.index("          expected = {\n            'KAIROS_P32_1_TRADE_MERGE_IMPORT_COMMAND_REPORT_2026-09-18.md',")
end=s.index("            print('P32.1 trade merge-import command scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P32_2_PROFILE_IMPORT_CONTROL_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_PROFILE_TRADE_IMPORT.md',
            'package.json',
            'scripts/test-profile-route-browser.mjs',
            'scripts/test-profile-trade-import-browser.mjs',
            'scripts/verify-p32-1-trade-merge-import-command.mjs',
            'scripts/verify-p32-2-profile-import-control.mjs',
            'src/app/ProfileRoute.tsx',
            'tests/profile-trade-import.test.tsx',
          }
          if changed != expected or removed:
            print('P32.2 profile import control scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P32.1 trade merge-import command\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P32.2 profile import control
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p32:2-profile-import-control
          npm run verify:p32:1-trade-merge-import-command
          npm run verify:p28:3-profile-route
          npm run verify:p28:2-backup-restore-command
          npx vitest run \\
            tests/profile-trade-import.test.tsx \\
            tests/profile-route.test.tsx \\
            tests/trade-import-command.test.ts \\
            tests/backup-restore-command.test.ts

"""+s[end:]
rep("          node scripts/test-journal-draft-activation-browser.mjs\n","          node scripts/test-journal-draft-activation-browser.mjs\n          node scripts/test-profile-trade-import-browser.mjs\n")
rep("""          for (const required of [
            'verify:p32:1-trade-merge-import-command',""","""          for (const required of [
            'verify:p32:2-profile-import-control',
            'verify:p32:1-trade-merge-import-command',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P32_1_TRADE_MERGE_IMPORT_COMMAND_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P32_2_PROFILE_IMPORT_CONTROL_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/docs/KAIROS_PROFILE_TRADE_IMPORT.md
            .gate-candidate/kairos_p76/.trade-import-evidence/
            .gate-candidate/kairos_p76/KAIROS_P32_1_TRADE_MERGE_IMPORT_COMMAND_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate520')
