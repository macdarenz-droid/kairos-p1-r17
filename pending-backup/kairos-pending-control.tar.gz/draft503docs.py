"""Insert Gate503 continuity entries into the work503 docs. Reads Gate502 evidence from gate502-evidence.txt, zip502.txt and head502.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate502-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip502.txt').read().split()
HEAD=open(sp+'head502.txt').read().strip()
root=sp+'work503/kairos_p76/docs/'
label="**Patch label:** P27.2 · P27 Library foundation · owner phase P27 (active from the Gate501 canonical PASS) · definition: the Library tab replacing its placeholder with the cross-market saved-record list over the P27.1 index, and the Library → Analysis handoff that opens a record through the released load paths, proven in unit tests and a real browser."
ev=f"Gate502/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P27_1_SAVED_RECORD_INDEX_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate501 is the immediate rollback. P27.1 is canonical."
approval=f"""## Manual Gate503 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the Analysis route already carries its saved-trade selection in the URL and every workspace and control mount line is pinned by released verifiers, so the handoff is provided through a React context created above the pinned mount (`src/app/analysisHandoff.ts`) and consumed inside the workspace and both saved-record controls, leaving every released mount line byte-identical. P27.2 replaces the `/library` placeholder with `src/app/LibraryRoute.tsx`: the P27.1 index as a list with Kind and Market filters and one **Open in Analysis** link per record (`market=<venue>:<instrument>&open=<kind>:<id>`); the Analysis route parses the handoff once, the workspace selects the market (5m when no timeframe is chosen) and the Saved analysis or Saved snapshot control opens the record exactly once through its released load path. The Gate490/Gate500/Gate501/Gate502 verifier pins on the Library placeholder and on the moved load lines advanced to the new literals; Practice and Profile stay placeholders. Real browser evidence (`scripts/test-library-route-browser.mjs`, `.library-route-evidence/`) proves the cross-market list and filters, the one-time open of each kind, market selection on Analysis, no re-estimation and an untouched journal, at both viewports in both themes. UI VISIBLE:YES. P27.3 (closure) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate502

{label}

Gate502/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P27.1 (saved-record index) is canonical. Gate501 remains its immediate rollback. The next slice (Gate503, P27.2) mounts the Library route with the Open-in-Analysis handoff and browser evidence; P27.3 (closure) follows.

"""
arch=f"""## Gate503 P27.2 Library route amendment

{label}

Gate502/run{RUN}/head{HEAD} is the latest FULL canonical release: the P27.1 saved-record index. Gate501 is the immediate rollback.

The next slice adds `src/app/LibraryRoute.tsx`, `src/app/libraryRoute.css` and `src/app/analysisHandoff.ts`, wires `/library` to the route in `src/app/routes.tsx`, provides the handoff context above the pinned workspace mount in `src/app/AnalysisRoute.tsx` and consumes it in the workspace and both saved-record controls, adds the unit and real-browser evidence and `docs/KAIROS_LIBRARY_ROUTE.md`, and advances the P27 ledger below to P27.2. Every released mount line, P20/P23/P24/P25 and the remaining placeholders are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate503' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate502 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate501',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate502 P27.1 saved record index amendment',arch)
print('inserted')
