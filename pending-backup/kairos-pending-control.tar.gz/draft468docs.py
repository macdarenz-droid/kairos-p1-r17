"""Insert Gate468 continuity entries into the work468 docs. Usage: python3 draft468docs.py RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST"""
import sys
run,job,head,cid,cdig,eid,edig=sys.argv[1:8]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work468/kairos_p76/docs/'
ev=f"Gate467/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_APP_SHELL_INK_CANDIDATE_2026-09-17.zip;3859514bytes;SHA256 f7d94f75df181d870601d7c90adf855b71819faa4fdacaa8409e40dd094048e5; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate466 R1 is the immediate rollback."
approval=f"""## Manual Gate468 slice — 17 September 2026

{ev}

Under the user's autonomous continuation authority and the approved Ink direction, the next smallest dependency-safe slice is the Ink bubble presentation in KAIROS_INK_BUBBLE_PRESENTATION.md: eight bubble presentation roles join every registered theme, and under Ink and Paper the approved artwork canvas renders as a faint monochrome texture over a glass gradient with a hairline border, soft shadow and a profit/loss movement ring, mono tickers, and BTC/ETH identity in the amber and ice tokens; the three earlier themes express their current look through the same roles. The artwork canvas, its exact approved identity, RGBA transparency, refresh retention, physics, drag, freshness, accessibility and data owners are unchanged, so the released glass presentation, drag and bubble verifiers still pass. UI VISIBLE:YES. It adds no market acquisition, projection, persistence, journal or calculation owner and no execution, venue, FX or P&L inference. Candidate publication and complete canonical PASS remain mandatory; P21 stays active.

"""
plan=f"""## Status after FULL Gate467

Gate467/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present; the shell now paints the Ink gradient, translucent hairline bars, mono version with pulse, router-driven breathing loader, line icons and a spring ink indicator. Gate466 R1 remains its immediate rollback. The next slice is the Ink bubble presentation (Gate468); the home dashboard swipe pager with segmented control, journal rows/streak/sheet, analysis chips/status/position box with a live R readout through the released Risk/Reward owners, and the motion/loading contract follow one gate each. P21 stays active.

"""
arch=f"""## Gate468 Ink bubble presentation amendment

Gate467/run{run}/head{head} is the latest FULL canonical release: `AppShellRoute` is the only data-router reader, `AppShell` is router-agnostic, and `navigationShell.css` owns the Ink shell through tokens. Gate466 R1 is the immediate rollback.

The next bounded slice amends only bubble presentation. `themeEngine.ts` adds eight `--kairos-bubble-*` roles to every registered theme; `homeDashboardGlassBubbleMap.css` reads them for the glass surface, hairline border, shadow, movement ring, artwork filter/opacity and fallback-initial opacity, and sets tickers in the mono face. `HomeDashboardGlassBubbleMap.tsx`, the material, layout, motion, drag and freshness owners, the Your Trades view and every data owner are unchanged; the approved artwork canvas keeps its exact identity and RGBA transparency. UI VISIBLE:YES. No product-domain, provider, persistence, journal or calculation owner changes; P14/P17/P18/P19/P20 boundaries and P21 active status are unchanged.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate468' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate467 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate466 R1',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate467 app shell Ink presentation amendment',arch)
print('inserted')
