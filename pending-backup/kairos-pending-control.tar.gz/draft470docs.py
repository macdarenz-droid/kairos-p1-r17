import sys
run,job,head,cid,cdig,eid,edig=sys.argv[1:8]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work470/kairos_p76/docs/'
ev=f"Gate469/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser (including the new real-touch swipe evidence), TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_HOME_DASHBOARD_SWIPE_PAGER_CANDIDATE_2026-09-17.zip;3881540bytes;SHA256 5d91d56d56c4a6adb7ae72d8a5e33c98508ecfbabdc4620ede8c7c278892e52d; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate468 is the immediate rollback."
approval=f"""## Manual Gate470 slice — 17 September 2026

{ev}

Under the user's autonomous continuation authority and the approved Ink direction, the next smallest dependency-safe slice is the Journal Ink presentation in KAIROS_JOURNAL_INK_PRESENTATION.md: one route-scoped amendment block is prepended to `journalRoute.css` so the trade form, streak, result days, cumulative progress, daily results and trade history frame with hairlines over the surface gradient, every recorded value is set in the mono face with tabular numerals, inputs take the field gradient, the primary action inks with the accent pair and the on-accent text token, and the streak carries an outcome-tinted edge. Every released Journal rule stays byte-identical below the amendment, including the blocks that P13.14, P13.16, P14.6, P14.7 and P14.8 slice by first occurrence, and the history card keeps a solid colour beneath its gradient so the released browser contrast measurement is unchanged. No markup, data, calculation or fixture changes. UI VISIBLE:YES. It adds no journal, persistence, calculation, provider or navigation owner and no execution, venue, FX or P&L inference. Candidate publication and complete canonical PASS remain mandatory; P21 stays active.

"""
plan=f"""## Status after FULL Gate469

Gate469/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present; Home now pages between Live Market and Your Trades by touch swipe under a segmented control, with a single mounted pane and every released Home owner unchanged. Gate468 remains its immediate rollback. The next slice is the Journal Ink presentation (Gate470); analysis chips/status/position box with a live R readout through the released Risk/Reward owners and the motion/loading contract follow one gate each. P21 stays active.

"""
arch=f"""## Gate470 Journal Ink presentation amendment

Gate469/run{run}/head{head} is the latest FULL canonical release: `homeDashboardSwipeGesture.ts` and `HomeDashboardSwipePager.tsx` own Home swipe paging around the unchanged `HomeRoute` selection. Gate468 is the immediate rollback.

The next bounded slice amends only `src/app/journalRoute.css`, by prepending one route-scoped Ink block (hairline framing over gradient surfaces with a solid card colour retained, mono tabular numerals, field gradient, accent-pair primary action, outcome-tinted streak edge, reduced-motion opt-out). `JournalRoute.tsx`, `JournalHistoryList.tsx`, `VisualPnlStreak.tsx`, `VisualPnlPerformanceSummary.tsx`, `JournalDailyResults.tsx`, the trade map and every data, query, calculation and persistence owner are unchanged, and every released Journal verifier still passes on the untouched rules. UI VISIBLE:YES. No product-domain, provider, persistence, journal or calculation owner changes; P14/P17/P18/P19/P20 boundaries and P21 active status are unchanged.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate470' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate469 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate468',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate469 Home dashboard swipe pager amendment',arch)
print('inserted')
