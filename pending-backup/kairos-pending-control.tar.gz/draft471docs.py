"""Insert Gate471 continuity entries into the work471 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST"""
import sys
run,job,head,cid,cdig,eid,edig=sys.argv[1:8]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work471/kairos_p76/docs/'
ev=f"Gate470 R1/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_JOURNAL_INK_PRESENTATION_CANDIDATE_2026-09-17-R1.zip;3886892bytes;SHA256 852aeeaa4d6bf7eafc38de252a52e4d07535212b4e3414adc78dbc88c7632c4b; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate470 (run35193080865) remains failed timing-dependent-test evidence only; Gate469 is the immediate rollback."
approval=f"""## Manual Gate471 slice — 17 September 2026

{ev}

Under the user's autonomous continuation authority and the approved Ink direction, the next smallest dependency-safe slice is the Analysis Ink presentation in KAIROS_ANALYSIS_INK_PRESENTATION.md: one route-scoped amendment block is appended to `analysisHistory.css` and one to `tradeReview.css` so the market chart card and review cards frame with hairlines over the surface gradient, the live-candle status becomes a pill with a state dot drawn from the released status kinds (profit with a slow pulse for `live`, accent while loading, connecting, reconnecting or recovering, loss for unavailable or error, muted when paused or empty), the view tools become a segmented hairline pill, controls take the field gradient, and candle values, review facts and results are set in the mono face with tabular numerals. Every released rule stays byte-identical above the amendments, including the table-scroll block the workspace verifier slices by first occurrence; the status text, roles and `data-live-candle-status` evidence are unchanged. No markup, session, history, renderer or fixture changes. UI VISIBLE:YES. The TradingView-style position box with a live R readout through the released Risk/Reward owners remains a separate later slice. It adds no analysis, history, provider, persistence, calculation or navigation owner and no execution, venue, FX or P&L inference. Candidate publication and complete canonical PASS remain mandatory; P21 stays active.

"""
plan=f"""## Status after FULL Gate470 R1

Gate470 R1/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present; the Journal now renders on Ink and Paper through one route-scoped CSS amendment, and the Gate469 swipe-pager test's short-drag case is deterministic. Gate469 remains its immediate rollback. The next slice is the Analysis Ink presentation (Gate471); the position box with a live R readout through the released Risk/Reward owners and the motion/loading contract follow one gate each. P21 stays active.

"""
arch=f"""## Gate471 Analysis Ink presentation amendment

Gate470 R1/run{run}/head{head} is the latest FULL canonical release: `journalRoute.css` carries the prepended Journal Ink amendment and every released Journal rule below it is byte-identical. Gate469 is the immediate rollback.

The next bounded slice amends only `src/app/analysisHistory.css` and `src/app/tradeReview.css` by appending one route-scoped Ink block each (hairline framing over gradient surfaces, a live-status pill whose state dot follows the released `AnalysisLiveCandleStatusKind` values, a segmented tools pill, field-gradient controls, mono tabular numerals, reduced-motion opt-out). `AnalysisRoute.tsx`, `AnalysisHistoryWorkspace.tsx`, `AnalysisLiveCandleCanvas.tsx`, the status presentation, route session, renderer session, saved-trade overlay owners and every data owner are unchanged. UI VISIBLE:YES. No product-domain, provider, persistence, journal or calculation owner changes; P14/P17/P18/P19/P20 boundaries and P21 active status are unchanged.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate471' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Active Gate470 R1 repair',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate469',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate470 Journal Ink presentation amendment',arch)
print('inserted')
