"""Pin Gate521 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate520 zip, prev = Gate519 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P32_3_JOURNAL_IMPORT_CLOSURE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P32_2_PROFILE_IMPORT_CONTROL_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P32_1_TRADE_MERGE_IMPORT_COMMAND_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P32.2 Profile Import Control','name: Kairos Controlled Roadmap Gate — P32.3 Journal Import Closure')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P32.2 profile import control scope from Gate519','      - name: Confirm exact P32.3 closure scope from Gate520')
start=s.index("          expected = {\n            'KAIROS_P32_2_PROFILE_IMPORT_CONTROL_REPORT_2026-09-18.md',")
end=s.index("            print('P32.2 profile import control scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P32_3_JOURNAL_IMPORT_CLOSURE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p32-2-profile-import-control.mjs',
            'scripts/verify-p32-3-journal-import-closure.mjs',
          }
          if changed != expected or removed:
            print('P32.3 closure scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P32.2 profile import control\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P32.3 journal import closure
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p32:3-journal-import-closure
          npm run verify:p32:2-profile-import-control
          npm run verify:p32:1-trade-merge-import-command
          npx vitest run \\
            tests/profile-trade-import.test.tsx \\
            tests/trade-import-command.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p32:2-profile-import-control',""","""          for (const required of [
            'verify:p32:3-journal-import-closure',
            'verify:p32:2-profile-import-control',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P32_2_PROFILE_IMPORT_CONTROL_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P32_3_JOURNAL_IMPORT_CLOSURE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P32_2_PROFILE_IMPORT_CONTROL_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate521')
