"""Insert Gate485 continuity entries into the work485 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST ZIP_SIZE ZIP_SHA (Gate484 evidence + Gate484 zip)"""
import sys
run,job,head,cid,cdig,eid,edig,zsize,zsha=sys.argv[1:10]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work485/kairos_p76/docs/'
label="**Patch label:** P22.6 · P22 time-assisted trade snapshot · owner phase P22 (closure) · definition: source-proven closure of the P22 time-assisted trade snapshot and the definition of P23 (durable time-assisted snapshot provenance) from current ownership."
ev=f"Gate484/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_ANALYSIS_TIME_ASSISTED_WINDOW_NAVIGATION_CANDIDATE_2026-09-17.zip;{zsize}bytes;SHA256 {zsha}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate483 is the immediate rollback."
approval=f"""## Manual Gate485 slice — 17 September 2026

{label}

{ev}

Under the user's autonomous-continuation authority, P22 closes as a verification/docs/package boundary: `KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_REPORT_2026-09-17.md` and `scripts/verify-p22-6-time-assisted-trade-snapshot-closure.mjs` prove the P22.1 estimate contract, the P22.2 composition, the P22.3 preview, the P22.4 estimate markers and the P22.5 window navigation are mounted and retained with their verifiers; the P22 ledger is SYSTEM CLOSED through P22.6. P23 is defined from ownership as durable time-assisted snapshot provenance through the released P20 contracts (P20.2 persistence and backup/restore, P20.3/P20.4 save/load, P22.1/P22.2 estimate contracts; the only new owner is the snapshot record contract and its migration) and may not begin before this closure's canonical PASS. UI VISIBLE:NO. Estimates never feed P11 results; nothing is persisted; Ink amendments stay parked for the user's whole-app review. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate484

{label}

Gate484/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present: Show on chart navigates the live chart to the trade interval. Gate483 remains its immediate rollback. The next slice (Gate485, P22.6) closes P22 from source and defines P23 (durable time-assisted snapshot provenance); P23.1 follows after that PASS.

"""
arch=f"""## Gate485 P22 closure and P23 definition amendment

{label}

Gate484/run{run}/head{head} is the latest FULL canonical release: the time-assisted window navigation. Gate483 is the immediate rollback.

The closure slice adds no production runtime owner: the P22 ledger below becomes SYSTEM CLOSED through P22.6, the closure section and the P23 definition are added, the root closure report and its verifier are registered. P11/P14–P21 boundaries are unchanged.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate485' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate484 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate483',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate484 P22.5 time-assisted window navigation amendment',arch)
print('inserted')
