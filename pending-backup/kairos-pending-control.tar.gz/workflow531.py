"""Pin Gate531 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate530 zip, prev = Gate529 zip). Expected scope read from scope531.txt."""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
scope=sorted(l.strip() for l in open(sp+'scope531.txt') if l.strip())
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P36_1_TRADE_DISCIPLINE_RECORD_FOUNDATION_CANDIDATE_2026-09-20.zip'
BASE='KAIROS_P35_3_PRACTICE_TRADE_LIFECYCLE_CLOSURE_CANDIDATE_2026-09-20.zip'
PREV='KAIROS_P35_2_PRACTICE_ROUTE_LIFECYCLE_CONTROLS_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P35.3 Practice Trade Lifecycle Closure','name: Kairos Controlled Roadmap Gate — P36.1 Trade Discipline Record Foundation')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P35.3 closure scope from Gate529','      - name: Confirm exact P36.1 trade discipline record foundation scope from Gate530')
start=s.index("          expected = {\n            'KAIROS_P35_3_PRACTICE_TRADE_LIFECYCLE_CLOSURE_REPORT_2026-09-20.md',")
end=s.index("            print('P35.3 closure scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
body=''.join(f"            '{f}',\n" for f in scope)
s=s[:start]+"          expected = {\n"+body+"""          }
          if changed != expected or removed:
            print('P36.1 trade discipline record foundation scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P35.3 practice trade lifecycle closure\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P36.1 trade discipline record foundation
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p36:1-trade-discipline-record-foundation
          npm run verify:p35:3-practice-trade-lifecycle-closure
          npm run verify:p23:2-saved-time-assisted-snapshot-persistence-foundation
          npm run verify:p9:trade-persistence
          npm run verify:p6:backup-envelope
          npm run verify:p6:restore-verification
          npx vitest run \\
            tests/trade-discipline-persistence.test.ts \\
            tests/database-migrations.test.ts \\
            tests/backup-envelope.test.ts \\
            tests/restore-preflight.test.ts \\
            tests/saved-time-assisted-snapshot-persistence.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p35:3-practice-trade-lifecycle-closure',""","""          for (const required of [
            'verify:p36:1-trade-discipline-record-foundation',
            'verify:p35:3-practice-trade-lifecycle-closure',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P35_3_PRACTICE_TRADE_LIFECYCLE_CLOSURE_REPORT_2026-09-20.md
            .gate-candidate/kairos_p76/docs/KAIROS_VISION_ROADMAP_ALIGNMENT.md
""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P36_1_TRADE_DISCIPLINE_RECORD_FOUNDATION_REPORT_2026-09-20.md
            .gate-candidate/kairos_p76/KAIROS_P35_3_PRACTICE_TRADE_LIFECYCLE_CLOSURE_REPORT_2026-09-20.md
""")
open(p,'w').write(s); print('workflow pinned for Gate531')
