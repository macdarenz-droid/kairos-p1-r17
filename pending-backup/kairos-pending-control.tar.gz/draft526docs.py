"""Insert Gate526 continuity entries into the work526 docs. Reads Gate525 evidence from gate525-evidence.txt, zip525.txt and head525.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate525-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip525.txt').read().split()
HEAD=open(sp+'head525.txt').read().strip()
root=sp+'work526/kairos_p76/docs/'
label="**Patch label:** P34.2 · P34 Profile data safety: backup freshness and persistent storage · owner phase P34 (active from the Gate524 canonical PASS) · definition: the Profile device card extended with the last-backup moment, the storage-durability state and the persistent-storage request, proven in unit tests and a real browser."
ev=f"Gate525/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P34_1_LAST_BACKUP_RECORD_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate524 is the immediate rollback. P34.1 is canonical."
approval=f"""## Manual Gate526 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the released storage-durability owner already publishes a subscribable status and owns the request, so the card subscribes and asks through ports whose stable default is that owner; the browser's answer is reported as given and never claimed beyond it; the last backup is recorded only after the hand-off succeeded through the P34.1 command over the metadata repository the activation receipt already uses. P34.2 extends the This device card in `src/app/ProfileRoute.tsx`; the P28.3 receipts literal and the P34.1 pin advanced. Real browser evidence (`scripts/test-profile-data-safety-browser.mjs`, `.data-safety-evidence/`) proves the card reporting exactly what the real browser reports, a real backup download recorded and kept across a reload and out of the next backup, the request made to the real browser with its answer reported honestly, and both viewports in both themes. UI VISIBLE:YES. P34.3 (closure) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate525

{label}

Gate525/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P34.1 (last-backup record) is canonical. Gate524 remains its immediate rollback. The next slice (Gate526, P34.2) extends the Profile device card with browser evidence; P34.3 (closure) follows.

"""
arch=f"""## Gate526 P34.2 Profile data safety amendment

{label}

Gate525/run{RUN}/head{HEAD} is the latest FULL canonical release: the P34.1 last-backup record. Gate524 is the immediate rollback.

The next slice extends the This device card in `src/app/ProfileRoute.tsx` with the `durability` ports, adds the unit and real-browser evidence and `docs/KAIROS_PROFILE_DATA_SAFETY.md`, and advances the P34 ledger below to P34.2. The storage-durability owner, every other Profile card, the commands and the schema are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate526' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate525 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate524',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate525 P34.1 last-backup record amendment',arch)
print('inserted')
