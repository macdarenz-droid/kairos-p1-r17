"""Insert Gate497 continuity entries into the work497 docs. Reads Gate496 evidence from gate496-evidence.txt, zip496.txt and head496.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate496-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip496.txt').read().split()
HEAD=open(sp+'head496.txt').read().strip()
root=sp+'work497/kairos_p76/docs/'
label="**Patch label:** P25.3 · P25 saved record labels · owner phase P25 (closure) · definition: source-proven closure of P25 and the definition of P26 (Goals foundation) from current ownership."
ev=f"Gate496/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P25_2_SAVED_RECORD_LABEL_PRESENTATION_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate495 is the immediate rollback. P25.2 is canonical: labels are visible on the Analysis page."
approval=f"""## Manual Gate497 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. P25.3 adds no production runtime behaviour and no new production owner: it proves P25.1–P25.2 against current source, marks the P25 ledger SYSTEM CLOSED through P25.3 and defines P26 from research: the `/goals` More-tab entry still renders the placeholder ("This area is ready for a future Kairos patch") and the continuity record names Goals & Discipline as the phase after P21 before P22 was re-pointed; P26 is the Goals foundation (goal contract persisted as P5 metadata under a reserved key namespace, a read-only progress projection over released P11/P12 truth, and the Goals route), one gate per owner with unit and real-browser evidence. UI VISIBLE:NO. P26 begins after this PASS without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate496

{label}

Gate496/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P25.2 (label inputs and list presentation) is canonical. Gate495 remains its immediate rollback. The next slice (Gate497, P25.3) is the P25 closure and the definition of P26 (Goals foundation) from ownership.

"""
arch=f"""## Gate497 P25 closure and P26 definition amendment

{label}

Gate496/run{RUN}/head{HEAD} is the latest FULL canonical release: the P25.2 label presentation. Gate495 is the immediate rollback.

The next slice adds `scripts/verify-p25-3-saved-record-labels-closure.mjs`, closes the P25 ledger below at P25.3 and adds the P25 closure section and the research-backed P26 definition. No production file changes. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate497' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate496 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate495',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate496 P25.2 saved record label presentation amendment',arch)
print('inserted')
