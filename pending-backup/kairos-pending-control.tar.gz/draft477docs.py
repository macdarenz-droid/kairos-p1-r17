"""Insert Gate477 continuity entries into the work477 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST ZIP_SIZE ZIP_SHA (Gate476 evidence + Gate476 zip)"""
import sys
run,job,head,cid,cdig,eid,edig,zsize,zsha=sys.argv[1:10]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work477/kairos_p76/docs/'
label="**Patch label:** P21.26 · roadmap item 5 (exact trade overlays + P18 drawing create/edit/delete + P20 save/load round trips) · owner phase P21 (chart workspace integration, active) · definition: move a selected trend-line endpoint on the Analysis chart through the released P18.58/P18.59 edit lifecycle, with real browser evidence."
ev=f"Gate476/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_ANALYSIS_DRAWING_TOOLS_MOUNT_CANDIDATE_2026-09-17.zip;{zsize}bytes;SHA256 {zsha}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate475 is the immediate rollback."
approval=f"""## Manual Gate477 slice — 17 September 2026

{label}

{ev}

Under the user's roadmap-first authority, the next item-5 step is endpoint edit in KAIROS_ANALYSIS_DRAWING_TOOLS_ENDPOINT_EDIT.md. The Gate475 session takes an optional `endpointEditTolerancePx`; when set, the same single released click lifecycle receives the P18.58 endpoint-click options (segments from the released P18.5 projection of the committed drawings on the exact bound chart and series, computed per click) and the P18.59 execution options (the session collection and its drawing-only refresh). The Gate476 composition passes the product tolerance `ANALYSIS_DRAWING_ENDPOINT_EDIT_TOLERANCE_PX = 8`. A click within tolerance of a selected line's endpoint enters editing; the next chart click moves that endpoint through P18.50/P18.51R3 and the interaction resets to idle; Cancel keeps the line; a far click is not a grab. The toolbar keeps Cancel enabled while editing and says what the next click does; the two Gate476-pinned literals this slice deliberately changes (the Cancel condition and the session creation call) are updated in that verifier to the new literals, not relaxed. UI VISIBLE:YES. Real Chromium evidence (`scripts/test-analysis-drawing-tools-edit-browser.mjs`, `.drawing-tools-edit-evidence/`) proves a real pane click grabs the end endpoint and the next click moves it (old midpoint no longer painted, new midpoint painted), Cancel keeps the moved line, no journal write, Ink/Paper at 320/390px. No persistence, journal, market, calculation, provider or navigation owner changes; the Saved Analysis P20 round trip (P21.27) follows. Candidate publication and complete canonical PASS remain mandatory; P21 stays active.

"""
plan=f"""## Status after FULL Gate476

{label}

Gate476/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present; the trend-line tool is visible on both Analysis chart paths with real draw, select and delete evidence. Gate475 remains its immediate rollback. The next slice (Gate477, P21.26) moves a selected endpoint through the released P18.58/P18.59 lifecycle with real browser evidence; the Saved Analysis save/load round trip (P21.27) follows, then item 6. P21 stays active.

"""
arch=f"""## Gate477 Analysis drawing tools endpoint edit amendment

{label}

Gate476/run{run}/head{head} is the latest FULL canonical release: the mounted trend-line tool (`analysisDrawingToolsComposition.ts`, `analysisDrawingToolsContext.ts`, `useAnalysisDrawingTools.ts`, `AnalysisDrawingToolsControls.tsx`). Gate475 is the immediate rollback.

The next slice extends the session with an optional endpoint-edit tolerance that wires the released P18.58 endpoint click (segments from the released P18.5 projection on the exact bound chart and series) and the released P18.59 execution into the same single click lifecycle; the composition passes `ANALYSIS_DRAWING_ENDPOINT_EDIT_TOLERANCE_PX` from the product policy; the toolbar keeps Cancel available while editing. `analysisCandleRendererSession.ts`, the canvases, the workspace, the overlay owners and every data owner are unchanged. UI VISIBLE:YES. No product-domain, provider, persistence, journal or calculation owner changes; P17/P18/P19/P20 boundaries and P21 active status are unchanged.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate477' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate476 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate475',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate476 Analysis drawing tools mount amendment',arch)
print('inserted')
