"""Apply the Gate501 (P26.4) closure ledger/plan edits to work501 (idempotent; run before draft501docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work501/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P26 canonical ownership ledger — ACTIVE through P26\.\d+', '## P26 canonical ownership ledger — SYSTEM CLOSED through P26.4', s, count=1)
row="| P26.4 | Goals foundation system closure | verification/docs/package boundary only; no production runtime owner added | Proves P26.1–P26.3 as the complete source-proven P26 boundary and defines P27 from ownership |\n"
anchor="no journal write, no device time zone, no estimate |\n"
if row not in s:
    assert s.count(anchor)==1; s=s.replace(anchor, anchor+row, 1)
section="""## P26 Goals Foundation System Closure — P26.4

P26.4 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P26.1 goals preference, the P26.2 progress projection and the P26.3 Goals route are mounted and retained with their verifiers; the closure report is `KAIROS_P26_4_GOALS_FOUNDATION_CLOSURE_REPORT_2026-09-18.md` and its verifier `scripts/verify-p26-4-goals-foundation-closure.mjs`. Goals never write to the journal, never infer a time zone and never estimate.

## P27 — Library foundation (defined from ownership, not begun)

Research against current source: `src/app/navigation.ts` places Library in the primary tab bar and `src/app/routes.tsx` still renders it as `PlaceholderRoute`; no continuity record defines its content. What the app already owns and cannot yet show in one place are its saved records: Saved Analyses (P20, page round trip P21.27) and saved time-assisted snapshots (P23, page round trip P23.5), both labelled (P25) and deletable (P24), but each reachable only inside Analysis for the currently selected market. P27 makes Library the saved-record library: a read-only cross-market index query over the released P20.2 listing and the P23.4 listing (kind, label, market, saved moment, newest first, no new store or index), the Library route replacing the placeholder with that list, a kind/market filter and an "Open in Analysis" action that selects the record's market and hands the record to the released load paths, each as its own gate with unit and real-browser evidence. Proven from ownership: P20/P23 own the records, P21.27/P23.5 own loading into Analysis, the shell owns navigation; the only new owners are the index query, the route and the handoff. Practice and Profile stay placeholders until their own phases. P27 may not begin before that PASS (the Gate501 canonical PASS of P26.4).

"""
if '## P26 Goals Foundation System Closure — P26.4' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert s.count(anchor2)==1; s=s.replace(anchor2, section+anchor2, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Updated at Gate498: P26 ACTIVE (Goals foundation) from the Gate497 canonical PASS."
add=" Updated at Gate501: P17–P26 closed; P27 defined (Library foundation), not begun; P28–P40 later."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
