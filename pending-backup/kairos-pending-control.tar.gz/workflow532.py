"""Pin Gate532 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate531 zip, prev = Gate530 zip). Expected scope read from scope532.txt."""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
scope=sorted(l.strip() for l in open(sp+'scope532.txt') if l.strip())
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P36_2_TRADE_DISCIPLINE_COMMANDS_CANDIDATE_2026-09-20.zip'
BASE='KAIROS_P36_1_TRADE_DISCIPLINE_RECORD_FOUNDATION_CANDIDATE_2026-09-20.zip'
PREV='KAIROS_P35_3_PRACTICE_TRADE_LIFECYCLE_CLOSURE_CANDIDATE_2026-09-20.zip'
rep('name: Kairos Controlled Roadmap Gate — P36.1 Trade Discipline Record Foundation','name: Kairos Controlled Roadmap Gate — P36.2 Trade Discipline Commands')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P36.1 trade discipline record foundation scope from Gate530','      - name: Confirm exact P36.2 trade discipline commands scope from Gate531')
start=s.index("          expected = {\n            'KAIROS_P36_1_TRADE_DISCIPLINE_RECORD_FOUNDATION_REPORT_2026-09-20.md',")
end=s.index("            print('P36.1 trade discipline record foundation scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
body=''.join(f"            '{f}',\n" for f in scope)
s=s[:start]+"          expected = {\n"+body+"""          }
          if changed != expected or removed:
            print('P36.2 trade discipline commands scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P36.1 trade discipline record foundation\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P36.2 trade discipline commands
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p36:2-trade-discipline-commands
          npm run verify:p36:1-trade-discipline-record-foundation
          npm run verify:p30:1-trade-record-delete-command
          npm run verify:p30:2-trade-delete-controls
          npm run verify:p35:3-practice-trade-lifecycle-closure
          npx vitest run \\
            tests/trade-discipline-commands.test.ts \\
            tests/trade-discipline-persistence.test.ts \\
            tests/trade-record-delete-command.test.ts \\
            tests/journal-trade-delete-control.test.tsx

"""+s[end:]
rep("""          for (const required of [
            'verify:p36:1-trade-discipline-record-foundation',""","""          for (const required of [
            'verify:p36:2-trade-discipline-commands',
            'verify:p36:1-trade-discipline-record-foundation',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P36_1_TRADE_DISCIPLINE_RECORD_FOUNDATION_REPORT_2026-09-20.md
            .gate-candidate/kairos_p76/KAIROS_P35_3_PRACTICE_TRADE_LIFECYCLE_CLOSURE_REPORT_2026-09-20.md
""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P36_2_TRADE_DISCIPLINE_COMMANDS_REPORT_2026-09-20.md
            .gate-candidate/kairos_p76/KAIROS_P36_1_TRADE_DISCIPLINE_RECORD_FOUNDATION_REPORT_2026-09-20.md
""")
open(p,'w').write(s); print('workflow pinned for Gate532')
