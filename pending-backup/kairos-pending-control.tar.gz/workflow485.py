"""Pin Gate485 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate484 zip, prev = Gate483 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — P22.5 Time-Assisted Window Navigation','name: Kairos Controlled Roadmap Gate — P22.6 Time-Assisted Trade Snapshot Closure')
rep("      - 'KAIROS_ANALYSIS_TIME_ASSISTED_WINDOW_NAVIGATION_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_ANALYSIS_TIME_ASSISTED_ESTIMATE_MARKERS_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_TIME_ASSISTED_WINDOW_NAVIGATION_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_ANALYSIS_TIME_ASSISTED_WINDOW_NAVIGATION_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_CANDIDATE_2026-09-17.zip')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P22.5 time-assisted window navigation scope from Gate483','      - name: Confirm exact P22.6 closure scope from Gate484')
rep("""          expected = {
            'docs/KAIROS_ANALYSIS_TIME_ASSISTED_WINDOW_NAVIGATION.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-time-assisted-window-browser.mjs',
            'scripts/verify-analysis-drawing-tools-mount.mjs',
            'scripts/verify-analysis-time-assisted-estimate-markers.mjs',
            'scripts/verify-analysis-time-assisted-snapshot-preview.mjs',
            'scripts/verify-analysis-time-assisted-window-navigation.mjs',
            'src/app/AnalysisHistoryWorkspace.tsx',
            'src/app/AnalysisTimeAssistedSnapshotControls.tsx',
            'src/app/analysisHistory.css',
            'src/app/analysisTimeAssistedWindowSession.ts',
            'src/app/useAnalysisDrawingTools.ts',
            'src/app/useAnalysisTimeAssistedWindow.ts',
            'tests/analysis-time-assisted-window-mount.test.tsx',
            'tests/analysis-time-assisted-window-session.test.ts',
          }
          if changed != expected or removed:
            print('P22.5 time-assisted window navigation scope mismatch', file=sys.stderr)""","""          expected = {
            'KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_REPORT_2026-09-17.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-analysis-time-assisted-estimate-markers.mjs',
            'scripts/verify-analysis-time-assisted-snapshot-preview.mjs',
            'scripts/verify-analysis-time-assisted-window-navigation.mjs',
            'scripts/verify-p22-1-estimated-market-reference-foundation.mjs',
            'scripts/verify-p22-2-time-assisted-trade-snapshot-composition.mjs',
            'scripts/verify-p22-6-time-assisted-trade-snapshot-closure.mjs',
          }
          if changed != expected or removed:
            print('P22.6 closure scope mismatch', file=sys.stderr)""")
rep("""            tests/analysis-time-assisted-markers-mount.test.tsx

      - name: Production TypeScript compilation""","""            tests/analysis-time-assisted-markers-mount.test.tsx

      - name: P22.6 time-assisted trade snapshot system closure
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p22:6-time-assisted-trade-snapshot-closure
          npm run verify:p22:1-estimated-market-reference-foundation
          npm run verify:p22:2-time-assisted-trade-snapshot-composition
          npm run verify:analysis-time-assisted-snapshot-preview
          npm run verify:analysis-time-assisted-estimate-markers
          npm run verify:analysis-time-assisted-window-navigation
          npm run verify:p21:28-chart-workspace-integration-closure

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:analysis-time-assisted-window-navigation',""","""          for (const required of [
            'verify:p22:6-time-assisted-trade-snapshot-closure',
            'verify:analysis-time-assisted-window-navigation',""")
rep("""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_TIME_ASSISTED_WINDOW_NAVIGATION.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_REPORT_2026-09-17.md
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_TIME_ASSISTED_WINDOW_NAVIGATION.md""")
open(p,'w').write(s); print('workflow pinned for Gate485')
