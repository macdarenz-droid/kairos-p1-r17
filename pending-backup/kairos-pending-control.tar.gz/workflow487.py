"""Pin Gate487 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate486 zip, prev = Gate485 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P23_2_SAVED_TIME_ASSISTED_SNAPSHOT_PERSISTENCE_FOUNDATION_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P23_1_SAVED_TIME_ASSISTED_SNAPSHOT_CONTRACT_FOUNDATION_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_CANDIDATE_2026-09-17.zip'
rep('name: Kairos Controlled Roadmap Gate — P23.1 Saved Time-Assisted Snapshot Contract Foundation','name: Kairos Controlled Roadmap Gate — P23.2 Saved Time-Assisted Snapshot Persistence Foundation')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P23.1 saved time-assisted snapshot contract scope from Gate485','      - name: Confirm exact P23.2 saved time-assisted snapshot persistence scope from Gate486')
rep("""          expected = {
            'KAIROS_P23_1_SAVED_TIME_ASSISTED_SNAPSHOT_CONTRACT_FOUNDATION_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p23-1-saved-time-assisted-snapshot-contract-foundation.mjs',
            'src/app/savedTimeAssistedSnapshotContract.ts',
            'src/app/savedTimeAssistedSnapshotIdentity.ts',
            'tests/saved-time-assisted-snapshot-contract.test.ts',
          }
          if changed != expected or removed:
            print('P23.1 saved time-assisted snapshot contract scope mismatch', file=sys.stderr)""","""          expected = {
            'KAIROS_P23_2_SAVED_TIME_ASSISTED_SNAPSHOT_PERSISTENCE_FOUNDATION_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p12-journal-history-status-index-backup-regression-repair.mjs',
            'scripts/verify-p12-journal-history-status-index-verifier-compatibility-repair.mjs',
            'scripts/verify-p12-journal-history-status-index.mjs',
            'scripts/verify-p20-2-saved-analysis-persistence-foundation.mjs',
            'scripts/verify-p23-1-saved-time-assisted-snapshot-contract-foundation.mjs',
            'scripts/verify-p23-2-saved-time-assisted-snapshot-persistence-foundation.mjs',
            'scripts/verify-p6-backup-envelope.mjs',
            'scripts/verify-p9-trade-persistence.mjs',
            'src/data/backup/backupEnvelope.ts',
            'src/data/backup/backupFormat.ts',
            'src/data/backup/backupSerialization.ts',
            'src/data/backup/backupSnapshot.ts',
            'src/data/backup/backupValidation.ts',
            'src/data/backup/restorePreflight.ts',
            'src/data/backup/restoreReplacement.ts',
            'src/data/backup/restoreVerification.ts',
            'src/data/database/KairosDatabase.ts',
            'src/data/database/index.ts',
            'src/data/database/integrity.ts',
            'src/data/database/migrations.ts',
            'src/data/database/schema.ts',
            'src/data/repositories/SavedTimeAssistedSnapshotRepository.ts',
            'src/data/repositories/index.ts',
            'tests/activation-persistence.test.ts',
            'tests/backup-envelope.test.ts',
            'tests/backup-snapshot.test.ts',
            'tests/database-kernel.test.ts',
            'tests/database-migrations.test.ts',
            'tests/database-transactions.test.ts',
            'tests/metadata-repository.test.ts',
            'tests/restore-preflight.test.ts',
            'tests/restore-replacement.test.ts',
            'tests/restore-verification.test.ts',
            'tests/saved-analysis-persistence.test.ts',
            'tests/saved-time-assisted-snapshot-persistence.test.ts',
            'tests/trade-persistence.test.ts',
          }
          if changed != expected or removed:
            print('P23.2 saved time-assisted snapshot persistence scope mismatch', file=sys.stderr)""")
rep("""      - name: P23.1 saved time-assisted snapshot contract foundation
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p23:1-saved-time-assisted-snapshot-contract-foundation
          npm run verify:p22:6-time-assisted-trade-snapshot-closure
          npm run verify:p20:1-saved-analysis-contract-foundation
          npx vitest run \\
            tests/saved-time-assisted-snapshot-contract.test.ts \\
            tests/time-assisted-trade-snapshot.test.ts
""","""      - name: P23.2 saved time-assisted snapshot persistence foundation
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p23:2-saved-time-assisted-snapshot-persistence-foundation
          npm run verify:p23:1-saved-time-assisted-snapshot-contract-foundation
          npm run verify:p20:2-saved-analysis-persistence-foundation
          npm run verify:p9:trade-persistence
          npm run verify:p6:backup-envelope
          npm run verify:p12:journal-history-status-index
          npx vitest run \\
            tests/saved-time-assisted-snapshot-persistence.test.ts \\
            tests/saved-time-assisted-snapshot-contract.test.ts \\
            tests/saved-analysis-persistence.test.ts \\
            tests/backup-envelope.test.ts \\
            tests/backup-snapshot.test.ts \\
            tests/database-kernel.test.ts \\
            tests/database-migrations.test.ts \\
            tests/database-transactions.test.ts \\
            tests/metadata-repository.test.ts \\
            tests/restore-preflight.test.ts \\
            tests/restore-replacement.test.ts \\
            tests/restore-verification.test.ts \\
            tests/activation-persistence.test.ts \\
            tests/trade-persistence.test.ts
""")
rep("""          for (const required of [
            'verify:p23:1-saved-time-assisted-snapshot-contract-foundation',""","""          for (const required of [
            'verify:p23:2-saved-time-assisted-snapshot-persistence-foundation',
            'verify:p23:1-saved-time-assisted-snapshot-contract-foundation',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P23_1_SAVED_TIME_ASSISTED_SNAPSHOT_CONTRACT_FOUNDATION_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P23_2_SAVED_TIME_ASSISTED_SNAPSHOT_PERSISTENCE_FOUNDATION_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P23_1_SAVED_TIME_ASSISTED_SNAPSHOT_CONTRACT_FOUNDATION_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate487')
