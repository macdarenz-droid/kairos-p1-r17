"""Pin Gate472 in the repo workflow. Usage: SIZE SHA"""
import sys
size,sha=sys.argv[1],sys.argv[2]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — Analysis Ink Presentation','name: Kairos Controlled Roadmap Gate — Risk/Reward Ratio Projection')
rep("      - 'KAIROS_ANALYSIS_INK_PRESENTATION_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RATIO_PROJECTION_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_JOURNAL_INK_PRESENTATION_CANDIDATE_2026-09-17-R1.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_INK_PRESENTATION_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_ANALYSIS_INK_PRESENTATION_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RATIO_PROJECTION_CANDIDATE_2026-09-17.zip')
rep("            ('BASE_ZIP', 3886892, '852aeeaa4d6bf7eafc38de252a52e4d07535212b4e3414adc78dbc88c7632c4b'),\n            ('CANDIDATE_ZIP', 3892168, '7202cbd0c0a8c4d50ef0a781c7386577bf54f44593ffd2034f59f1a06d4775b3'),",f"            ('BASE_ZIP', 3892168, '7202cbd0c0a8c4d50ef0a781c7386577bf54f44593ffd2034f59f1a06d4775b3'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact Analysis Ink presentation scope from Gate470 R1','      - name: Confirm exact Risk/Reward ratio projection scope from Gate471')
rep("""          expected = {
            'docs/KAIROS_ANALYSIS_INK_PRESENTATION.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-analysis-ink-presentation.mjs',
            'src/app/analysisHistory.css',
            'src/app/tradeReview.css',
          }
          if changed != expected or removed:
            print('Analysis Ink presentation scope mismatch', file=sys.stderr)""","""          expected = {
            'docs/KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RATIO_PROJECTION.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-analysis-saved-trade-risk-reward-ratio-projection.mjs',
            'src/app/analysisSavedTradeRiskRewardRatioProjection.ts',
            'tests/analysis-saved-trade-risk-reward-ratio-projection.test.ts',
          }
          if changed != expected or removed:
            print('Risk/Reward ratio projection scope mismatch', file=sys.stderr)""")
rep("""            tests/trade-review.test.tsx

      - name: Production TypeScript compilation""","""            tests/trade-review.test.tsx

      - name: Saved-trade Risk/Reward ratio projection
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:analysis-saved-trade-risk-reward-ratio-projection
          npm run verify:analysis-saved-trade-risk-reward-snapshot-extent-projection
          npm run verify:analysis-saved-trade-risk-reward-theme-style-source
          npm run verify:analysis-saved-trade-overlay-runtime-input-composition
          npx vitest run \\
            tests/analysis-saved-trade-risk-reward-ratio-projection.test.ts \\
            tests/analysis-saved-trade-risk-reward-reference-projection.test.ts \\
            tests/analysis-saved-trade-risk-reward-snapshot-extent-projection.test.ts \\
            tests/analysis-saved-trade-overlay-live-candle-composition.test.tsx

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:analysis-ink-presentation',""","""          for (const required of [
            'verify:analysis-saved-trade-risk-reward-ratio-projection',
            'verify:analysis-ink-presentation',""")
rep("""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_INK_PRESENTATION.md""","""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RATIO_PROJECTION.md
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_INK_PRESENTATION.md""")
open(p,'w').write(s); print('workflow pinned for Gate472')
