"""Pin Gate530 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate529 zip, prev = Gate528 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P35_3_PRACTICE_TRADE_LIFECYCLE_CLOSURE_CANDIDATE_2026-09-20.zip'
BASE='KAIROS_P35_2_PRACTICE_ROUTE_LIFECYCLE_CONTROLS_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P35_1_PRACTICE_TRADE_LIFECYCLE_SOURCE_OPTION_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P35.2 Practice Route Lifecycle Controls','name: Kairos Controlled Roadmap Gate — P35.3 Practice Trade Lifecycle Closure')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P35.2 practice route lifecycle controls scope from Gate528','      - name: Confirm exact P35.3 closure scope from Gate529')
start=s.index("          expected = {\n            'KAIROS_P35_2_PRACTICE_ROUTE_LIFECYCLE_CONTROLS_REPORT_2026-09-18.md',")
end=s.index("            print('P35.2 practice route lifecycle controls scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P35_3_PRACTICE_TRADE_LIFECYCLE_CLOSURE_REPORT_2026-09-20.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_VISION_ROADMAP_ALIGNMENT.md',
            'package.json',
            'scripts/verify-p35-2-practice-route-lifecycle-controls.mjs',
            'scripts/verify-p35-3-practice-trade-lifecycle-closure.mjs',
          }
          if changed != expected or removed:
            print('P35.3 closure scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P35.2 practice route lifecycle controls\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P35.3 practice trade lifecycle closure
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p35:3-practice-trade-lifecycle-closure
          npm run verify:p35:2-practice-route-lifecycle-controls
          npm run verify:p35:1-practice-trade-lifecycle-source-option
          npx vitest run \\
            tests/practice-trade-lifecycle-source-option.test.ts \\
            tests/journal-draft-trade-activation.test.tsx

"""+s[end:]
rep("""          for (const required of [
            'verify:p35:2-practice-route-lifecycle-controls',""","""          for (const required of [
            'verify:p35:3-practice-trade-lifecycle-closure',
            'verify:p35:2-practice-route-lifecycle-controls',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P35_2_PRACTICE_ROUTE_LIFECYCLE_CONTROLS_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P35_3_PRACTICE_TRADE_LIFECYCLE_CLOSURE_REPORT_2026-09-20.md
            .gate-candidate/kairos_p76/docs/KAIROS_VISION_ROADMAP_ALIGNMENT.md
            .gate-candidate/kairos_p76/KAIROS_P35_2_PRACTICE_ROUTE_LIFECYCLE_CONTROLS_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate530')
