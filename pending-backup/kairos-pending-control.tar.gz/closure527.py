"""Apply the Gate527 (P34.3) closure ledger/plan edits to work527 (idempotent; run before draft527docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work527/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P34 canonical ownership ledger — ACTIVE through P34\.\d+', '## P34 canonical ownership ledger — SYSTEM CLOSED through P34.3', s, count=1)
row="| P34.3 | Profile data safety system closure | verification/docs/package boundary only; no production runtime owner added | Proves P34.1–P34.2 as the complete source-proven P34 boundary and defines P35 from ownership |\n"
anchor="every released Profile card, port and literal otherwise unchanged; no reminder policy, no eviction handling |\n"
if row not in s:
    assert s.count(anchor)==1; s=s.replace(anchor, anchor+row, 1)
section="""## P34 Profile Data Safety System Closure — P34.3

P34.3 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P34.1 last-backup record and the P34.2 device card extension are mounted and retained with their verifiers; the closure report is `KAIROS_P34_3_PROFILE_DATA_SAFETY_CLOSURE_REPORT_2026-09-18.md` and its verifier `scripts/verify-p34-3-profile-data-safety-closure.mjs`. The Profile page now tells the user when the device was last backed up and whether the browser has promised to keep the data, and lets them ask; nothing is promised beyond what the browser answers.

## P35 — Practice trade lifecycle: fills, close and activation for paper trades (defined from ownership, not begun)

Research against current source: `updateOpenManualTrade` (P10.4) and `openDraftTrade` (P31.1) refuse any trade whose source is not `manual`, and `JournalOpenTradeUpdate` and `JournalDraftTradeActivation` render nothing for a non-manual trade, so a practice trade (P29, `source: 'paper'`) can be recorded and deleted but never receive a fill, be closed or be opened from a draft: the practice history can never show a result, which is the point of rehearsing. The guarded-write pattern, the released fields and the confirmed refresh path already exist and are pinned; only the source gate is manual-only. P35 gives paper trades the same lifecycle in dependency order: P35.1 an explicit allowed-source option on the two released commands (default `manual`, so every released caller and literal keeps its behaviour) with the practice source accepted only when the caller names it, proven against manual, paper and mixed stores; P35.2 the Practice route mounting the released update and activation controls with the practice source named, with unit and real-browser evidence that a paper trade takes a fill, closes with a result in the practice history and a draft opens, while the Journal stays manual-only and no real result changes; P35.3 the closure. Proven from ownership: P10.4 and P31.1 own the commands and their guards, P10/P31.2 the controls, P29 the practice write and scope, P12 the list; the only new owners are the option and the Practice mounts. P35 may not begin before that PASS (the Gate527 canonical PASS of P34.3).

"""
if '## P34 Profile Data Safety System Closure — P34.3' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert s.count(anchor2)==1; s=s.replace(anchor2, section+anchor2, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Updated at Gate525: P34 ACTIVE (Profile data safety: backup freshness and persistent storage) from the Gate524 canonical PASS."
add=" Updated at Gate527: P17–P34 closed; P35 defined (Practice trade lifecycle: fills, close and activation for paper trades), not begun; P36–P40 later."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
