"""Pin Gate483 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate482 zip, prev = Gate481 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — P22.3 Time-Assisted Snapshot Preview','name: Kairos Controlled Roadmap Gate — P22.4 Time-Assisted Estimate Markers')
rep("      - 'KAIROS_ANALYSIS_TIME_ASSISTED_SNAPSHOT_PREVIEW_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_ANALYSIS_TIME_ASSISTED_ESTIMATE_MARKERS_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_P22_2_TIME_ASSISTED_TRADE_SNAPSHOT_COMPOSITION_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_TIME_ASSISTED_SNAPSHOT_PREVIEW_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_ANALYSIS_TIME_ASSISTED_SNAPSHOT_PREVIEW_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_TIME_ASSISTED_ESTIMATE_MARKERS_CANDIDATE_2026-09-17.zip')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P22.3 time-assisted snapshot preview scope from Gate481','      - name: Confirm exact P22.4 time-assisted estimate markers scope from Gate482')
rep("""          expected = {
            'docs/KAIROS_ANALYSIS_TIME_ASSISTED_SNAPSHOT_PREVIEW.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-time-assisted-snapshot-browser.mjs',
            'scripts/verify-analysis-time-assisted-snapshot-preview.mjs',
            'scripts/verify-p22-2-time-assisted-trade-snapshot-composition.mjs',
            'src/app/AnalysisHistoryWorkspace.tsx',
            'src/app/AnalysisTimeAssistedSnapshotControls.tsx',
            'src/app/analysisHistory.css',
            'tests/analysis-time-assisted-snapshot-preview.test.tsx',
          }
          if changed != expected or removed:
            print('P22.3 time-assisted snapshot preview scope mismatch', file=sys.stderr)""","""          expected = {
            'docs/KAIROS_ANALYSIS_TIME_ASSISTED_ESTIMATE_MARKERS.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-time-assisted-markers-browser.mjs',
            'scripts/verify-analysis-drawing-tools-mount.mjs',
            'scripts/verify-analysis-time-assisted-estimate-markers.mjs',
            'scripts/verify-analysis-time-assisted-snapshot-preview.mjs',
            'src/app/AnalysisHistoryWorkspace.tsx',
            'src/app/AnalysisTimeAssistedSnapshotControls.tsx',
            'src/app/analysisDrawingToolsComposition.ts',
            'src/app/analysisTimeAssistedMarkerBinding.ts',
            'src/app/analysisTimeAssistedMarkerSession.ts',
            'src/app/useAnalysisDrawingTools.ts',
            'src/app/useAnalysisTimeAssistedMarkers.ts',
            'tests/analysis-time-assisted-marker-session.test.ts',
            'tests/analysis-time-assisted-markers-mount.test.tsx',
          }
          if changed != expected or removed:
            print('P22.4 time-assisted estimate markers scope mismatch', file=sys.stderr)""")
rep("""            tests/analysis-history-workspace.test.tsx

      - name: Production TypeScript compilation""","""            tests/analysis-history-workspace.test.tsx

      - name: P22.4 time-assisted estimate markers
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:analysis-time-assisted-estimate-markers
          npm run verify:analysis-time-assisted-snapshot-preview
          npm run verify:analysis-drawing-tools-mount
          npm run verify:analysis-saved-trade-overlay-workspace-mount
          npm run verify:analysis-saved-trade-renderer-marker-session
          npx vitest run \\
            tests/analysis-time-assisted-marker-session.test.ts \\
            tests/analysis-time-assisted-markers-mount.test.tsx \\
            tests/analysis-drawing-tools-mount.test.tsx \\
            tests/analysis-time-assisted-snapshot-preview.test.tsx

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:analysis-time-assisted-snapshot-preview',""","""          for (const required of [
            'verify:analysis-time-assisted-estimate-markers',
            'verify:analysis-time-assisted-snapshot-preview',""")
rep("""          node scripts/test-analysis-time-assisted-snapshot-browser.mjs

      - name: Full unit regression""","""          node scripts/test-analysis-time-assisted-snapshot-browser.mjs
          node scripts/test-analysis-time-assisted-markers-browser.mjs

      - name: Full unit regression""")
rep("""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_TIME_ASSISTED_SNAPSHOT_PREVIEW.md""","""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_TIME_ASSISTED_ESTIMATE_MARKERS.md
            .gate-candidate/kairos_p76/.time-assisted-markers-evidence/
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_TIME_ASSISTED_SNAPSHOT_PREVIEW.md""")
open(p,'w').write(s); print('workflow pinned for Gate483')
