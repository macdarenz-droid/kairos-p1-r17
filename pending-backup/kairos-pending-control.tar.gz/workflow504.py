"""Pin Gate504 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate503 zip, prev = Gate502 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P27_3_LIBRARY_FOUNDATION_CLOSURE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P27_2_LIBRARY_ROUTE_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P27_1_SAVED_RECORD_INDEX_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P27.2 Library Route','name: Kairos Controlled Roadmap Gate — P27.3 Library Foundation Closure')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P27.2 library route scope from Gate502','      - name: Confirm exact P27.3 closure scope from Gate503')
start=s.index("          expected = {\n            'KAIROS_P27_2_LIBRARY_ROUTE_REPORT_2026-09-18.md',")
end=s.index("            print('P27.2 library route scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P27_3_LIBRARY_FOUNDATION_CLOSURE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p27-3-library-foundation-closure.mjs',
          }
          if changed != expected or removed:
            print('P27.3 closure scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P27.2 library route\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P27.3 library foundation closure
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p27:3-library-foundation-closure
          npm run verify:p27:2-library-route
          npm run verify:p27:1-saved-record-index
          npx vitest run \\
            tests/library-route.test.tsx \\
            tests/saved-record-index.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p27:2-library-route',""","""          for (const required of [
            'verify:p27:3-library-foundation-closure',
            'verify:p27:2-library-route',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P27_2_LIBRARY_ROUTE_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P27_3_LIBRARY_FOUNDATION_CLOSURE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P27_2_LIBRARY_ROUTE_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate504')
