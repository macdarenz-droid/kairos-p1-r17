"""Insert Gate486 continuity entries into the work486 docs (Gate485 evidence is fixed)."""
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work486/kairos_p76/docs/'
label="**Patch label:** P23.1 · P23 durable time-assisted snapshot provenance · owner phase P23 (active from the Gate485 canonical PASS) · definition: the provider-neutral saved time-assisted snapshot logical contract and its independent stable identity allocator."
ev="Gate485/run35299116855/job105457696525/head9ff8c32 is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE10529322851 (GitHub digest sha256:1bb11e015c1d802a13efc2f8054441fc5ee7c20a00c5d8a1ee61debe10c053c3) and KAIROS_GATE_EVIDENCE10529652429 (GitHub digest sha256:ead8e80661bf8a906cf035ba02b22cd071f20dc463c51cbf72b132ed5c79cd1d) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P22_6_TIME_ASSISTED_TRADE_SNAPSHOT_CLOSURE_CANDIDATE_2026-09-17.zip;4055087bytes;SHA256 d1f17c37a3f559810193437e1e86c2fc5c58c31d42f5d90a7e4820e40cf8a044; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run35300929264, completed success). Gate484 is the immediate rollback. P22 is SYSTEM CLOSED through P22.6."
approval=f"""## Manual Gate486 slice — 18 September 2026

{label}

{ev}

User decision, 18 September 2026: after the P22 closure report offered P23 (durable time-assisted snapshot provenance, requiring a schema bump and a new backup format version as controlled extensions of the closed P5/P6/P20 owners) or the parked UI review, the user chose "1": proceed with P23 under the same gate discipline. P23.1 adds only the contract: `src/app/savedTimeAssistedSnapshotContract.ts` composes the P17 market reference, the P22.2 side and instants (as entered, with UTC normalisation and the device time zone) and the P22.1 estimates with their provenance, plus duration and save moment; `src/app/savedTimeAssistedSnapshotIdentity.ts` allocates independent UUID identities. No price, result, execution identity or trade relation; an unavailable estimate stays representable. UI VISIBLE:NO. No schema, migration, repository, backup/restore, UI or provider work; P23.2 evolves persistence and backup/restore coherently and may not begin before this PASS. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate485

{label}

Gate485/run35299116855/head9ff8c32 is FULL canonical PASS with every stage and both exact-run artifacts present: P22 is SYSTEM CLOSED through P22.6 and P23 is defined from ownership. Gate484 remains its immediate rollback. The user chose to proceed with P23. The next slice (Gate486, P23.1) is the saved time-assisted snapshot contract and identity; P23.2 (persistence, schema, backup/restore) follows.

"""
arch=f"""## Gate486 P23.1 saved time-assisted snapshot contract amendment

{label}

Gate485/run35299116855/head9ff8c32 is the latest FULL canonical release: the P22 closure. Gate484 is the immediate rollback.

The next slice adds `src/app/savedTimeAssistedSnapshotContract.ts` and `src/app/savedTimeAssistedSnapshotIdentity.ts` and starts the P23 ledger below at P23.1. P22, P20, P17 and the journal owners are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate486' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate485 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate484',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate485 P22 closure and P23 definition amendment',arch)
print('inserted')
