#!/bin/bash
# Usage: pkgnext.sh N BASE_ZIP_NAME NEW_ZIP_NAME  — packages workN from pkg(N-1) base, copying files and directories, writes zipN.txt and changedN.txt, copies the ZIP into the repo.
set -e
N=$1; BASEZIP=$2; NEWZIP=$3; P=$((N-1))
cd /tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad
rm -rf pkg$N && mkdir pkg$N && (cd pkg$N && unzip -q /home/user/kairos-p1-r17/$BASEZIP)
diff -rq work$P/kairos_p76 work$N/kairos_p76 -x node_modules -x dist -x '.*' | sed -E 's#^Files work'$P'/kairos_p76/(.*) and .*#\1#; s#^Only in work'$N'/kairos_p76/?([^:]*): (.*)#\1/\2#; s#^/##' | sort | while read f; do
  if [ -d work$N/kairos_p76/$f ]; then mkdir -p pkg$N/kairos_p76/$f; cp -r work$N/kairos_p76/$f/. pkg$N/kairos_p76/$f/; else mkdir -p pkg$N/kairos_p76/$(dirname $f); cp work$N/kairos_p76/$f pkg$N/kairos_p76/$f; fi
done
echo "== changed vs base =="; diff -rq pkg$P pkg$N | sed -E 's#^Files pkg'$P'/kairos_p76/(.*) and .*#\1#; s#^Only in pkg'$N'/kairos_p76/?([^:]*): (.*)#\1/\2#; s#^/##' | sort | tee changed$N.txt
echo "== work vs pkg (must be empty) =="; diff -rq work$N pkg$N -x node_modules -x dist -x '.*' || true
(cd pkg$N && rm -f ../$NEWZIP && zip -q -r -X ../$NEWZIP kairos_p76)
S=$(stat -c %s $NEWZIP); H=$(sha256sum $NEWZIP | cut -d' ' -f1); echo "$S $H" | tee zip$N.txt
cp $NEWZIP /home/user/kairos-p1-r17/$NEWZIP; echo "zip copied to repo"
