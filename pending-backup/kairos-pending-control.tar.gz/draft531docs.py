"""Insert Gate531 continuity entries into the work531 docs. Reads Gate530 evidence from gate530-evidence.txt, zip530.txt and head530.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate530-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip530.txt').read().split()
HEAD=open(sp+'head530.txt').read().strip()
root=sp+'work531/kairos_p76/docs/'
label="**Patch label:** P36.1 · P36 Discipline foundation: checklists, mistake tracking and discipline score (vision P22, discipline half) · owner phase P36 (active from the Gate530 canonical PASS) · definition: the trade discipline record contract, its schema V6 store, repository, integrity checks and backup format V5 acceptance through the released P6 path."
ev=f"Gate530/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P35_3_PRACTICE_TRADE_LIFECYCLE_CLOSURE_CANDIDATE_2026-09-20.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate529 is the immediate rollback. P35.3 is canonical; P35 is SYSTEM CLOSED; the vision roadmap alignment is canonical."
approval=f"""## Manual Gate531 slice — 20 September 2026

{label}

{ev}

P36 is ACTIVE from this PASS under the user's 20 September 2026 direction (realign, update the roadmap, start progress) and the 18 September 2026 autonomy rule. P36.1 adds `src/domain/discipline/` (the `TradeDisciplineRecord` contract with fixed checklist, review and mistake vocabularies), schema V6 (`KAIROS_V6_STORES = {{ tradeDiscipline: '&id,tradeId,updatedAt' }}`, `KAIROS_V6_MIGRATION`), `TradeDisciplineRepository`, three closed integrity checks and the backup format V5 extension across `src/data/backup/*` (V1–V4 backups stay accepted and migrate with an empty discipline store). Every released verifier and test pinning schema 5 / format V4 advanced to schema 6 / format V5 (marked `pin advanced at Gate531`); the P35.3 closure verifier's P36-absence check advanced to the present P36.1 owner; nothing relaxed. No command, no UI, no score; `deleteTradeRecord` is unchanged until P36.2. UI VISIBLE:NO. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate530

{label}

Gate530/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P35.3 (practice trade lifecycle closure and vision realignment) is canonical, P35 is SYSTEM CLOSED and `docs/KAIROS_VISION_ROADMAP_ALIGNMENT.md` is the canonical roadmap. Gate529 remains its immediate rollback. The next slice (Gate531, P36.1) begins the Discipline foundation with the trade discipline record, its store and its backup acceptance.

"""
arch=f"""## Gate531 P36.1 trade discipline record foundation amendment

{label}

Gate530/run{RUN}/head{HEAD} is the latest FULL canonical release: the P35.3 closure and vision realignment. Gate529 is the immediate rollback.

The next slice adds `src/domain/discipline/`, appends schema v6 (`KAIROS_V6_STORES`, `KAIROS_V6_MIGRATION`), `src/data/repositories/TradeDisciplineRepository.ts`, the integrity checks and the backup format V5 extension across `src/data/backup/*`, and starts the P36 ledger below at P36.1. P5, P6, P20.2 and P23.2 released history (schema v1–v5, backup V1–V4) remains declared and accepted; every route, command and control is unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate531' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate530 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate529',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate530 P35 closure, vision realignment and P36 definition amendment',arch)
print('inserted')
