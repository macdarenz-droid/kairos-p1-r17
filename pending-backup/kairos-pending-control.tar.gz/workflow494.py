"""Pin Gate494 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate493 zip, prev = Gate492 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P24_3_SAVED_RECORD_LIFECYCLE_CLOSURE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P24_2_SAVED_RECORD_DELETE_CONTROLS_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P24_1_SAVED_RECORD_DELETE_COMMANDS_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P24.2 Saved Record Delete Controls','name: Kairos Controlled Roadmap Gate — P24.3 Saved Record Lifecycle Closure')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P24.2 saved record delete controls scope from Gate492','      - name: Confirm exact P24.3 closure scope from Gate493')
start=s.index("          expected = {\n            'KAIROS_P24_2_SAVED_RECORD_DELETE_CONTROLS_REPORT_2026-09-18.md',")
end=s.index("            print('P24.2 saved record delete controls scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P24_3_SAVED_RECORD_LIFECYCLE_CLOSURE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p24-3-saved-record-lifecycle-closure.mjs',
          }
          if changed != expected or removed:
            print('P24.3 closure scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P24.2 saved record delete controls\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P24.3 saved record lifecycle closure
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p24:3-saved-record-lifecycle-closure
          npm run verify:p24:2-saved-record-delete-controls
          npm run verify:p24:1-saved-record-delete-commands
          npm run verify:p23:6-durable-time-assisted-snapshot-provenance-closure
          npx vitest run \\
            tests/saved-record-delete-commands.test.ts \\
            tests/analysis-saved-record-delete.test.tsx

"""+s[end:]
rep("""          for (const required of [
            'verify:p24:2-saved-record-delete-controls',""","""          for (const required of [
            'verify:p24:3-saved-record-lifecycle-closure',
            'verify:p24:2-saved-record-delete-controls',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P24_2_SAVED_RECORD_DELETE_CONTROLS_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P24_3_SAVED_RECORD_LIFECYCLE_CLOSURE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P24_2_SAVED_RECORD_DELETE_CONTROLS_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate494')
