"""Apply the Gate518 (P31.3) closure ledger/plan edits to work518 (idempotent; run before draft518docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work518/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P31 canonical ownership ledger — ACTIVE through P31\.\d+', '## P31 canonical ownership ledger — SYSTEM CLOSED through P31.3', s, count=1)
row="| P31.3 | Draft activation system closure | verification/docs/package boundary only; no production runtime owner added | Proves P31.1–P31.2 as the complete source-proven P31 boundary and defines P32 from ownership |\n"
anchor="shown only on manual draft cards, never on the Practice page; every released mount line keeps its literals |\n"
if row not in s:
    assert s.count(anchor)==1; s=s.replace(anchor, anchor+row, 1)
section="""## P31 Draft Activation System Closure — P31.3

P31.3 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P31.1 draft activation command and the P31.2 activation control on the Journal draft card are mounted and retained with their verifiers; the closure report is `KAIROS_P31_3_DRAFT_ACTIVATION_CLOSURE_REPORT_2026-09-18.md` and its verifier `scripts/verify-p31-3-draft-activation-closure.mjs`. With P10 (save, update, close), P30 (delete) and P31 (draft → open) a manual trade record now has its whole lifecycle on the device; practice trades keep theirs (P29); every released mount line keeps its literals.

## P32 — Journal import: merge trades from a backup (defined from ownership, not begun)

Research against current source: `TradeSource` already admits `'import'` and `'broker-import'` and the diagnostics service already lists an `import` category, yet nothing writes an imported trade; the P6 backup format carries every trade with its stable id, plans, executions and fees, `parseKairosBackup` and the P6.3 preflight already validate and migrate any Kairos backup file, and the only way to bring records from another device is the P28 restore, which replaces everything. A user with two devices, or a backup from before a delete, has no way to add the trades they are missing. P32 gives the journal a merge import in dependency order: P32.1 a merge-import command that reads a backup through the released P6 parse and preflight, selects the trades whose ids are not on this device together with their own plans, executions and fees, re-stamps real sources as `import` and keeps practice sources, and writes them in one atomic write with explicit counts (added, already present) and refusal outcomes, never touching an existing record, a saved record or a preference; P32.2 the Profile "Import trades" control over the released file reading (file → preview of new and already-present trades → confirm → outcome) proven in unit tests and a real browser; P32.3 the closure. Proven from ownership: P6 owns parsing, validation and the backup format, P5 the stores, P9 the atomic write, P28 the Profile page and the file seam, P12 the history; the only new owners are the command and the control. P32 may not begin before that PASS (the Gate518 canonical PASS of P31.3).

"""
if '## P31 Draft Activation System Closure — P31.3' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert s.count(anchor2)==1; s=s.replace(anchor2, section+anchor2, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Updated at Gate516: P31 ACTIVE (Trade record lifecycle: draft activation) from the Gate515 canonical PASS."
add=" Updated at Gate518: P17–P31 closed; P32 defined (Journal import: merge trades from a backup), not begun; P33–P40 later."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
