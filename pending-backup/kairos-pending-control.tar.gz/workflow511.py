"""Pin Gate511 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate510 zip, prev = Gate509 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P29_3_PRACTICE_ROUTE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P29_2_REAL_RESULT_ISOLATION_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P29_1_PRACTICE_TRADE_COMMAND_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P29.2 Real-Result Isolation','name: Kairos Controlled Roadmap Gate — P29.3 Practice Route')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P29.2 real-result isolation scope from Gate509','      - name: Confirm exact P29.3 practice route scope from Gate510')
start=s.index("          expected = {\n            'KAIROS_P29_2_REAL_RESULT_ISOLATION_REPORT_2026-09-18.md',")
end=s.index("            print('P29.2 real-result isolation scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P29_3_PRACTICE_ROUTE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_PRACTICE_ROUTE.md',
            'package.json',
            'scripts/test-practice-route-browser.mjs',
            'scripts/verify-p26-3-goals-route.mjs',
            'scripts/verify-p27-2-library-route.mjs',
            'scripts/verify-p28-3-profile-route.mjs',
            'scripts/verify-p28-4-profile-foundation-closure.mjs',
            'scripts/verify-p29-1-practice-trade-command.mjs',
            'scripts/verify-p29-2-real-result-isolation.mjs',
            'scripts/verify-p29-3-practice-route.mjs',
            'src/app/PracticeRoute.tsx',
            'src/app/practiceRoute.css',
            'src/app/routes.tsx',
            'tests/practice-route.test.tsx',
          }
          if changed != expected or removed:
            print('P29.3 practice route scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P29.2 real-result isolation\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P29.3 practice route
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p29:3-practice-route
          npm run verify:p29:2-real-result-isolation
          npm run verify:p29:1-practice-trade-command
          npm run verify:p28:4-profile-foundation-closure
          npm run verify:p28:3-profile-route
          npm run verify:p27:2-library-route
          npm run verify:p26:3-goals-route
          npm run verify:p10:manual-trade-journal-route
          npx vitest run \\
            tests/practice-route.test.tsx \\
            tests/journal-history-scope.test.ts \\
            tests/practice-trade-save-command.test.ts \\
            tests/manual-trade-journal-route.test.tsx \\
            tests/app-shell-ink.test.tsx

"""+s[end:]
rep("          node scripts/test-profile-route-browser.mjs\n","          node scripts/test-profile-route-browser.mjs\n          node scripts/test-practice-route-browser.mjs\n")
rep("""          for (const required of [
            'verify:p29:2-real-result-isolation',""","""          for (const required of [
            'verify:p29:3-practice-route',
            'verify:p29:2-real-result-isolation',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P29_2_REAL_RESULT_ISOLATION_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P29_3_PRACTICE_ROUTE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/docs/KAIROS_PRACTICE_ROUTE.md
            .gate-candidate/kairos_p76/.practice-route-evidence/
            .gate-candidate/kairos_p76/KAIROS_P29_2_REAL_RESULT_ISOLATION_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate511')
