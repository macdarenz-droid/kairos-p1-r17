"""Insert Gate475 continuity entries into the work475 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST (Gate474 evidence)"""
import sys
run,job,head,cid,cdig,eid,edig=sys.argv[1:8]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work475/kairos_p76/docs/'
ev=f"Gate474/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_LIGHTWEIGHT_CHARTS_V5_PRODUCTION_DRAWING_BINDING_SEAM_CANDIDATE_2026-09-17.zip;3920429bytes;SHA256 2f9dc76439f3a6e48860017f03093d2b849af248035f76149c51052236609365; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate473 is the immediate rollback."
approval=f"""## Manual Gate475 slice — 17 September 2026

{ev}

Under the user's roadmap-first authority, the next smallest dependency-safe item-5 prerequisite is the unmounted Analysis drawing-tools renderer session in KAIROS_ANALYSIS_DRAWING_TOOLS_RENDERER_SESSION.md. It composes only released P18 owners around the Gate474 seam: on attach it creates the P18.10 trend-line layer on the exact candlestick handle and the P18.30/P18.42 draft interaction from the binding with the committed drawings supplied for click selection; `selectTrendLineTool()` enters drawing from idle; the second provider click commits through P18.35 and refreshes through P18.46/P18.47 inside the released click lifecycle; a provider hit with the P18.13 identity selects through P18.41/P18.42 and `deleteSelected()` removes exactly that drawing through the released deletion coordinators; the committed collection outlives chart rebuilds and is re-presented on the replacement series. UI VISIBLE:NO. It is not imported by any route, workspace or session. It adds no persistence, journal, market, calculation, theme-lookup, provider or navigation owner and no P19 behaviour; endpoint edit (P18.58/P18.59) follows once the tool is visible because it needs the projected screen-segment snapshot and tolerance policy. Candidate publication and complete canonical PASS remain mandatory; P21 stays active.

"""
plan=f"""## Status after FULL Gate474

Gate474/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present; the production renderer now exposes the P18.9/P18.16 binding and the candlestick handle through one optional lifecycle and forwards the vendor click and crosshair subscriptions. Gate473 remains its immediate rollback. The next slice is the unmounted Analysis drawing-tools renderer session (Gate475); the visible trend-line tool with draw, select and delete evidence, endpoint edit, and the Saved Analysis round trip follow one gate each, then item 6. P21 stays active.

"""
arch=f"""## Gate475 Analysis drawing-tools renderer session amendment

Gate474/run{run}/head{head} is the latest FULL canonical release: `createLightweightChartsV5ProductionRendererFactory` accepts an optional drawing-binding lifecycle and forwards the four vendor chart event subscriptions. Gate473 is the immediate rollback.

The next bounded non-UI slice adds `createAnalysisDrawingToolsRendererSession` in `src/app/analysisDrawingToolsRendererSession.ts`: one committed P18.33 collection per session, the P18.10 layer and P18.30/P18.42 draft interaction created per attached candlestick handle, commit through P18.35 on the preview state, refresh through P18.46/P18.47, selection through P18.41/P18.42 and deletion through the released P18 deletion coordinators. `analysisCandleRendererSession.ts`, the Analysis workspace, the overlay owners and every data owner are unchanged. UI VISIBLE:NO. No product-domain, provider, persistence, journal or calculation owner changes; P17/P18/P19/P20 boundaries and P21 active status are unchanged.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate475' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate474 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate473',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate474 production drawing-binding seam amendment',arch)
print('inserted')
