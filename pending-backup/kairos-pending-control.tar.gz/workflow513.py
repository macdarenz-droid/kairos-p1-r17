"""Pin Gate513 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate512 zip, prev = Gate511 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P30_1_TRADE_RECORD_DELETE_COMMAND_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P29_4_PRACTICE_FOUNDATION_CLOSURE_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P29_3_PRACTICE_ROUTE_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P29.4 Practice Foundation Closure','name: Kairos Controlled Roadmap Gate — P30.1 Trade Record Delete Command')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P29.4 closure scope from Gate511','      - name: Confirm exact P30.1 trade record delete command scope from Gate512')
start=s.index("          expected = {\n            'KAIROS_P29_4_PRACTICE_FOUNDATION_CLOSURE_REPORT_2026-09-18.md',")
end=s.index("            print('P29.4 closure scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P30_1_TRADE_RECORD_DELETE_COMMAND_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p29-4-practice-foundation-closure.mjs',
            'scripts/verify-p30-1-trade-record-delete-command.mjs',
            'src/application/trades/deleteTradeRecord.ts',
            'src/application/trades/index.ts',
            'tests/trade-record-delete-command.test.ts',
          }
          if changed != expected or removed:
            print('P30.1 trade record delete command scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P29.4 practice foundation closure\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P30.1 trade record delete command
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p30:1-trade-record-delete-command
          npm run verify:p29:4-practice-foundation-closure
          npm run verify:p24:1-saved-record-delete-commands
          npm run verify:p10:manual-trade-save-command
          npx vitest run \\
            tests/trade-record-delete-command.test.ts \\
            tests/saved-record-delete-commands.test.ts \\
            tests/manual-trade-save-command.test.ts \\
            tests/practice-trade-save-command.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p29:4-practice-foundation-closure',""","""          for (const required of [
            'verify:p30:1-trade-record-delete-command',
            'verify:p29:4-practice-foundation-closure',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P29_4_PRACTICE_FOUNDATION_CLOSURE_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P30_1_TRADE_RECORD_DELETE_COMMAND_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P29_4_PRACTICE_FOUNDATION_CLOSURE_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate513')
