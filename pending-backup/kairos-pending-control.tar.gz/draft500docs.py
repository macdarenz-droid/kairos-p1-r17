"""Insert Gate500 continuity entries into the work500 docs. Reads Gate499 evidence from gate499-evidence.txt, zip499.txt and head499.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate499-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip499.txt').read().split()
HEAD=open(sp+'head499.txt').read().strip()
root=sp+'work500/kairos_p76/docs/'
label="**Patch label:** P26.3 · P26 Goals foundation · owner phase P26 (active from the Gate497 canonical PASS) · definition: the Goals page replacing the More-tab placeholder, with the targets form over P26.1 and the progress cards over P26.2, proven in unit tests and a real browser."
ev=f"Gate499/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P26_2_GOALS_PROGRESS_PROJECTION_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate498 is the immediate rollback. P26.2 is canonical."
approval=f"""## Manual Gate500 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. P26.3 replaces the `/goals` placeholder with `src/app/GoalsRoute.tsx`: three progress cards from the P26.2 projection with explicit unset, unavailable, progress, reached, at-limit and over-limit states, a targets form over the P26.1 preference with plain-word validation outcomes and a refresh after each save, and a link to the P13.12 Settings time zone while it is unconfigured (targets still save). The Gate498/Gate499 verifier pins on the placeholder advanced to the route line; Library, Practice and Profile stay placeholders; the CSS mirrors the Settings route contract. Real browser evidence (`scripts/test-goals-route-browser.mjs`, `.goals-route-evidence/`) proves More → Goals, one persisted metadata record, the Settings link, progress from a trade saved through the real Journal, the refused invalid target and both viewports in both themes. UI VISIBLE:YES. P26.4 (closure) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate499

{label}

Gate499/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P26.2 (progress projection) is canonical. Gate498 remains its immediate rollback. The next slice (Gate500, P26.3) mounts the Goals route with browser evidence; P26.4 (closure) follows.

"""
arch=f"""## Gate500 P26.3 Goals route amendment

{label}

Gate499/run{RUN}/head{HEAD} is the latest FULL canonical release: the P26.2 progress projection. Gate498 is the immediate rollback.

The next slice adds `src/app/GoalsRoute.tsx` and `src/app/goalsRoute.css`, wires `/goals` to the route in `src/app/routes.tsx`, adds the unit and real-browser evidence and `docs/KAIROS_GOALS_ROUTE.md`, and advances the P26 ledger below to P26.3. Navigation, P13 and the remaining placeholders are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate500' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate499 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate498',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate499 P26.2 goals progress projection amendment',arch)
print('inserted')
