"""Pin Gate474 (drawing-binding seam) in the repo workflow. Usage: SIZE SHA"""
import sys
size,sha=sys.argv[1],sys.argv[2]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — Saved-Trade Position Box','name: Kairos Controlled Roadmap Gate — Production Drawing-Binding Seam')
rep("      - 'KAIROS_ANALYSIS_SAVED_TRADE_POSITION_BOX_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_LIGHTWEIGHT_CHARTS_V5_PRODUCTION_DRAWING_BINDING_SEAM_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RATIO_PROJECTION_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_SAVED_TRADE_POSITION_BOX_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_ANALYSIS_SAVED_TRADE_POSITION_BOX_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_LIGHTWEIGHT_CHARTS_V5_PRODUCTION_DRAWING_BINDING_SEAM_CANDIDATE_2026-09-17.zip')
rep("            ('BASE_ZIP', 3898877, 'cc188ee190977d63778c5cbe77ab3bd7b47e33359fc62fae73c44d3e42dca46d'),\n            ('CANDIDATE_ZIP', 3913657, '2da5ddccf149ddee5fbe2482ff4e74ab2cf6c68eab528b091a5c722b4b65bfe0'),",f"            ('BASE_ZIP', 3913657, '2da5ddccf149ddee5fbe2482ff4e74ab2cf6c68eab528b091a5c722b4b65bfe0'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact saved-trade position box scope from Gate472','      - name: Confirm exact production drawing-binding seam scope from Gate473')
rep("""          expected = {
            'docs/KAIROS_ANALYSIS_SAVED_TRADE_POSITION_BOX.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-position-box-browser.mjs',
            'scripts/verify-analysis-saved-trade-position-box.mjs',
            'src/app/AnalysisLiveCandleCanvas.tsx',
            'src/app/AnalysisSavedTradeOverlayLiveCandleCanvas.tsx',
            'src/app/AnalysisSavedTradeRiskRewardEvidencePresentation.tsx',
            'src/app/analysisHistory.css',
            'src/app/analysisSavedTradePositionBoxFormatting.ts',
            'tests/analysis-saved-trade-position-box.test.tsx',
          }
          if changed != expected or removed:
            print('Saved-trade position box scope mismatch', file=sys.stderr)""","""          expected = {
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_LIGHTWEIGHT_CHARTS_V5_PRODUCTION_DRAWING_BINDING_SEAM.md',
            'package.json',
            'scripts/verify-lightweight-charts-v5-production-drawing-binding-seam.mjs',
            'src/features/chart/lightweightChartsV5ProductionRenderer.ts',
            'tests/lightweight-charts-v5-production-drawing-binding-seam.test.ts',
          }
          if changed != expected or removed:
            print('Production drawing-binding seam scope mismatch', file=sys.stderr)""")
rep("""            tests/analysis-history-workspace.test.tsx

      - name: Production TypeScript compilation""","""            tests/analysis-history-workspace.test.tsx

      - name: Production drawing-binding seam
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:lightweight-charts-v5-production-drawing-binding-seam
          npm run verify:p17:10-lightweight-charts-v5-production-renderer
          npm run verify:p17:11-responsive-chart-sizing
          npm run verify:p17:16-chart-engine-system-closure
          npm run verify:live-candle-production-renderer-binding
          npm run verify:analysis-saved-trade-renderer-marker-session
          npm run verify:analysis-history-workspace
          npx vitest run \\
            tests/lightweight-charts-v5-production-drawing-binding-seam.test.ts \\
            tests/lightweight-charts-v5-production-renderer.test.ts \\
            tests/projected-incremental-candle-renderer.test.ts \\
            tests/analysis-saved-trade-position-box.test.tsx

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:analysis-saved-trade-position-box',""","""          for (const required of [
            'verify:lightweight-charts-v5-production-drawing-binding-seam',
            'verify:analysis-saved-trade-position-box',""")
rep("""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_SAVED_TRADE_POSITION_BOX.md""","""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_LIGHTWEIGHT_CHARTS_V5_PRODUCTION_DRAWING_BINDING_SEAM.md
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_SAVED_TRADE_POSITION_BOX.md""")
open(p,'w').write(s); print('workflow pinned for Gate474')
