"""Insert Gate505 continuity entries into the work505 docs. Reads Gate504 evidence from gate504-evidence.txt, zip504.txt and head504.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate504-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip504.txt').read().split()
HEAD=open(sp+'head504.txt').read().strip()
root=sp+'work505/kairos_p76/docs/'
label="**Patch label:** P28.1 · P28 Profile foundation: your data · owner phase P28 (active from the Gate504 canonical PASS) · definition: the application command that turns the released P6 snapshot into one named `.json` backup file and the seam that hands that file to the browser as a download, nothing written."
ev=f"Gate504/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P27_3_LIBRARY_FOUNDATION_CLOSURE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate503 is the immediate rollback. P27 is SYSTEM CLOSED through P27.3."
approval=f"""## Manual Gate505 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the P6.2 snapshot and P6 serialisation already produce the integrity-checked, device-metadata-free V4 envelope and no route calls them, so P28.1 composes the two released functions into `src/application/backup/exportBackup.ts` and adds no snapshot logic. The command takes the caller's explicit export moment (no clock of its own), names the file `kairos-backup-<UTC moment to the second>.json`, discloses byte length and record counts, and returns explicit invalid-input, integrity-error (failed check ids) and storage-error outcomes; the download hand-off is a three-port seam with one browser implementation that always releases the object URL. The Profile route stays a placeholder until P28.3. UI VISIBLE:NO. P28.2 (restore command) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate504

{label}

Gate504/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P27 is SYSTEM CLOSED through P27.3 and P28 is defined from research. Gate503 remains its immediate rollback. The next slice (Gate505, P28.1) is the backup export command; P28.2 (restore command), P28.3 (Profile route) and P28.4 (closure) follow.

"""
arch=f"""## Gate505 P28.1 backup export command amendment

{label}

Gate504/run{RUN}/head{HEAD} is the latest FULL canonical release: the P27 closure. Gate503 is the immediate rollback.

The next slice adds `src/application/backup/exportBackup.ts` (exported through `src/application/backup/index.ts`) and starts the P28 ledger below at P28.1. P6, P5, the shell and every route are unchanged; Profile stays a placeholder. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate505' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate504 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate503',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate504 P27 closure and P28 definition amendment',arch)
print('inserted')
