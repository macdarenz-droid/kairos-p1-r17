"""Insert Gate487 continuity entries into the work487 docs. Reads Gate486 evidence from gate486-evidence.txt (RUN JOB ART_CAND ART_CAND_SHA ART_EV ART_EV_SHA MAINRUN)."""
import os
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate486-evidence.txt').read().split()
root=sp+'work487/kairos_p76/docs/'
label="**Patch label:** P23.2 · P23 durable time-assisted snapshot provenance · owner phase P23 (active from the Gate485 canonical PASS) · definition: the raw persistence, integrity and full backup/restore extension for the P23.1 saved time-assisted snapshot contract."
ev=f"Gate486/run{RUN}/job{JOB}/headfbb9e0e is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P23_1_SAVED_TIME_ASSISTED_SNAPSHOT_CONTRACT_FOUNDATION_CANDIDATE_2026-09-18.zip;4061879bytes;SHA256 3e49a7af9fd26353ddb76135a9e12789e029a31bad3234280eb7febc009978e9; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate485 is the immediate rollback. P23.1 is canonical."
approval=f"""## Manual Gate487 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 decision ("1": proceed with P23 under the same gate discipline). P23.2 evolves the closed P5/P6/P20 persistence owners coherently: database schema version 5 appends `savedTimeAssistedSnapshots: '&id'` through the append-only `KAIROS_V5_MIGRATION`; `SavedTimeAssistedSnapshotRepository` persists the P23.1 contract verbatim; integrity adds the primary-key and record-shape checks; backup format V4 describes schema 5 and carries the store, while `KAIROS_SAVED_ANALYSIS_BACKUP_FORMAT_VERSION = 3` names the released V3 contract and V1/V2/V3 backups migrate with an empty snapshot store; restore preflight, replacement and verification cover the store. Every P5/P6/P9/P12/P20 test and verifier advances its current-version pin to schema 5 / format V4 and keeps every released-history pin. UI VISIBLE:NO. No application save/load orchestration, UI, provider or pixel work; P23.3 (save orchestration) may not begin before this PASS. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate486

{label}

Gate486/run{RUN}/headfbb9e0e is FULL canonical PASS with every stage and both exact-run artifacts present: P23.1 (saved time-assisted snapshot contract and identity) is canonical. Gate485 remains its immediate rollback. The next slice (Gate487, P23.2) is the persistence foundation: schema v5, V5 migration, repository, integrity, backup format V4 and restore coverage; P23.3 (application save orchestration) follows.

"""
arch=f"""## Gate487 P23.2 saved time-assisted snapshot persistence amendment

{label}

Gate486/run{RUN}/headfbb9e0e is the latest FULL canonical release: the P23.1 contract. Gate485 is the immediate rollback.

The next slice appends schema v5 (`KAIROS_V5_STORES`, `KAIROS_V5_MIGRATION`), `src/data/repositories/SavedTimeAssistedSnapshotRepository.ts`, the integrity checks and the backup format V4 extension across `src/data/backup/*`, and advances the P23 ledger below to P23.2. P5, P6 and P20 released history (schema v1–v4, backup V1–V3) remains declared and accepted. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate487' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate486 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate485',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate486 P23.1 saved time-assisted snapshot contract amendment',arch)
print('inserted')
