"""Pin Gate510 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate509 zip, prev = Gate508 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P29_2_REAL_RESULT_ISOLATION_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P29_1_PRACTICE_TRADE_COMMAND_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P28_4_PROFILE_FOUNDATION_CLOSURE_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P29.1 Practice Trade Command','name: Kairos Controlled Roadmap Gate — P29.2 Real-Result Isolation')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P29.1 practice trade command scope from Gate508','      - name: Confirm exact P29.2 real-result isolation scope from Gate509')
start=s.index("          expected = {\n            'KAIROS_P29_1_PRACTICE_TRADE_COMMAND_REPORT_2026-09-18.md',")
end=s.index("            print('P29.1 practice trade command scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P29_2_REAL_RESULT_ISOLATION_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p28-4-profile-foundation-closure.mjs',
            'scripts/verify-p29-1-practice-trade-command.mjs',
            'scripts/verify-p29-2-real-result-isolation.mjs',
            'src/application/journal/historyQuery.ts',
            'src/application/journal/index.ts',
            'src/data/repositories/TradeRepositories.ts',
            'tests/journal-history-scope.test.ts',
          }
          if changed != expected or removed:
            print('P29.2 real-result isolation scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P29.1 practice trade command\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P29.2 real-result isolation
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p29:2-real-result-isolation
          npm run verify:p29:1-practice-trade-command
          npm run verify:p12:journal-history-closure
          npm run verify:p12:journal-history-status-index
          npm run verify:p12:journal-history-heavy-performance
          npx vitest run \\
            tests/journal-history-scope.test.ts \\
            tests/practice-trade-save-command.test.ts \\
            tests/journal-history-query.test.ts \\
            tests/journal-history-performance.test.tsx \\
            tests/journal-visual-pnl-daily-summary-query.test.ts \\
            tests/home-dashboard-your-trades.test.tsx \\
            tests/goals-progress.test.ts \\
            tests/trade-review.test.tsx

"""+s[end:]
rep("""          for (const required of [
            'verify:p29:1-practice-trade-command',""","""          for (const required of [
            'verify:p29:2-real-result-isolation',
            'verify:p29:1-practice-trade-command',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P29_1_PRACTICE_TRADE_COMMAND_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P29_2_REAL_RESULT_ISOLATION_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P29_1_PRACTICE_TRADE_COMMAND_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate510')
