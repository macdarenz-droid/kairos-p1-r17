"""Pin Gate525 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate524 zip, prev = Gate523 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P34_1_LAST_BACKUP_RECORD_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P33_3_LIBRARY_IMPORT_CLOSURE_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P33_2_PROFILE_IMPORT_CARD_EXTENSION_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P33.3 Library Import Closure','name: Kairos Controlled Roadmap Gate — P34.1 Last-Backup Record')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P33.3 closure scope from Gate523','      - name: Confirm exact P34.1 last-backup record scope from Gate524')
start=s.index("          expected = {\n            'KAIROS_P33_3_LIBRARY_IMPORT_CLOSURE_REPORT_2026-09-18.md',")
end=s.index("            print('P33.3 closure scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P34_1_LAST_BACKUP_RECORD_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p33-3-library-import-closure.mjs',
            'scripts/verify-p34-1-last-backup-record.mjs',
            'src/application/backup/index.ts',
            'src/application/backup/lastBackup.ts',
            'tests/last-backup-record.test.ts',
          }
          if changed != expected or removed:
            print('P34.1 last-backup record scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P33.3 library import closure\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P34.1 last-backup record
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p34:1-last-backup-record
          npm run verify:p33:3-library-import-closure
          npm run verify:p28:1-backup-export-command
          npx vitest run \\
            tests/last-backup-record.test.ts \\
            tests/backup-export-command.test.ts \\
            tests/backup-snapshot.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p33:3-library-import-closure',""","""          for (const required of [
            'verify:p34:1-last-backup-record',
            'verify:p33:3-library-import-closure',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P33_3_LIBRARY_IMPORT_CLOSURE_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P34_1_LAST_BACKUP_RECORD_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P33_3_LIBRARY_IMPORT_CLOSURE_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate525')
