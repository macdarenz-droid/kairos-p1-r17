"""Insert Gate473 continuity entries into the work473 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST"""
import sys
run,job,head,cid,cdig,eid,edig=sys.argv[1:8]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work473/kairos_p76/docs/'
ev=f"Gate472/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RATIO_PROJECTION_CANDIDATE_2026-09-17.zip;3898877bytes;SHA256 cc188ee190977d63778c5cbe77ab3bd7b47e33359fc62fae73c44d3e42dca46d; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (main also carries the documentation-only Cloudflare Pages deployment note c16641acb171b9654a895fc701c3994bb81846a5, which touches no candidate or workflow). Gate471 is the immediate rollback."
approval=f"""## Manual Gate473 slice — 17 September 2026

{ev}

Under the user's autonomous continuation authority and the approved Ink direction, the next smallest dependency-safe item-5 slice is the saved-trade position box in KAIROS_ANALYSIS_SAVED_TRADE_POSITION_BOX.md: an accessible presentation beside the chart shows side and symbol, reward and risk distances with percent of entry, the planned ratio, exact target/entry/stop levels and the side-signed live R, reading only the released Risk/Reward presentation result, the Gate472 ratio projection, the released percentage owner and the released presentation-only rounding formatters. `AnalysisLiveCandleCanvas` gains one optional `onLatestCandle` seam that reports only the candle the released live projection last rendered; the overlay canvas retains it per exact selection, lets the authoritative page's last close stand in before any live render, and mounts one position box above the marker evidence. The chart's released Risk/Reward zones and levels, every history, provider, renderer, session, route and workspace owner and every released contract string are unchanged; nothing is written to the journal. UI VISIBLE:YES: choosing a saved trade with a full plan on its symbol shows the position box with a live R that updates as the released projection renders candles. Drag-to-plan edges remain a later slice. It adds no new arithmetic, persistence, provider or navigation owner and no execution, venue, FX or P&L inference. Candidate publication and complete canonical PASS remain mandatory; P21 stays active.

"""
plan=f"""## Status after FULL Gate472

Gate472/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present; the exact planned ratio and side-signed live R now have a released owner through the P11 calculators. Gate471 remains its immediate rollback. The next slice is the saved-trade position box beside the chart (Gate473); the journal rows and filter chips, the journal log-trade sheet, Your Trades result amounts in bubbles and the motion/loading contract follow one gate each. P21 stays active.

"""
arch=f"""## Gate473 saved-trade position box amendment

Gate472/run{run}/head{head} is the latest FULL canonical release: `projectAnalysisSavedTradeRiskRewardRatio` owns the exact planned ratio and live R through the released decimal kernel, risk-distance and R-multiple calculators. Gate471 is the immediate rollback.

The next bounded slice adds `AnalysisSavedTradeRiskRewardEvidencePresentation` (the position box) and `analysisSavedTradePositionBoxFormatting.ts` (presentation-only rounding with the exact values still exposed as data attributes), one optional `onLatestCandle` seam on `AnalysisLiveCandleCanvas`, per-selection latest-candle retention plus one position box mount in `AnalysisSavedTradeOverlayLiveCandleCanvas`, and route-scoped position box styles in `analysisHistory.css`. The status presentation, route session, renderer session, marker evidence, saved-trade overlay owners and every data owner are unchanged. UI VISIBLE:YES. No product-domain, provider, persistence, journal or calculation owner changes; P11/P14/P17/P18/P19/P20 boundaries and P21 active status are unchanged.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate473' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate472 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate471',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate472 saved-trade Risk/Reward ratio projection amendment',arch)
print('inserted')
