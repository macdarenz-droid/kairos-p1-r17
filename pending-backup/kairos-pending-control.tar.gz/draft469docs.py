"""Insert Gate469 continuity entries into the work469 docs. Usage: python3 draft469docs.py RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST"""
import sys
run,job,head,cid,cdig,eid,edig=sys.argv[1:8]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work469/kairos_p76/docs/'
ev=f"Gate468/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_INK_BUBBLE_PRESENTATION_CANDIDATE_2026-09-17.zip;3865083bytes;SHA256 2136fd19582a7294d0b74370d29370b5688d87c9974f6a81551251b5b1264ddf; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate467 is the immediate rollback."
approval=f"""## Manual Gate469 slice — 17 September 2026

{ev}

Under the user's autonomous continuation authority and the approved Ink direction, the next smallest dependency-safe slice is the Home dashboard swipe pager in KAIROS_HOME_DASHBOARD_SWIPE_PAGER.md: a pure swipe recognizer decides `next`, `previous` or nothing from slop, axis ratio, distance and flick velocity; a touch-only pager wraps the existing single-pane selection so a horizontal swipe pages between Live Market and Your Trades while the pane follows the finger and enters from the swipe direction; the two existing view buttons become a segmented control with a sliding ink pill. `HomeRoute` keeps `useState<'market'|'trades'>('market')`, the ternary and every released ownership string, so the market runtime still unmounts while Your Trades is shown and every P21, Your Trades, glass presentation and drag verifier still passes. `touch-action: pan-y`, a held bubble, a cancelled touchmove, a second finger and an uncancellable native pan all yield paging to the released owners or the browser. UI VISIBLE:YES. It adds no market acquisition, projection, persistence, journal or calculation owner and no execution, venue, FX or P&L inference. Candidate publication and complete canonical PASS remain mandatory; P21 stays active.

"""
plan=f"""## Status after FULL Gate468

Gate468/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present; both bubble maps now render on the Ink and Paper glass with BTC/ETH identity through eight theme-owned bubble roles. Gate467 remains its immediate rollback. The next slice is the Home dashboard swipe pager with segmented control (Gate469); journal rows/streak/sheet, analysis chips/status/position box with a live R readout through the released Risk/Reward owners, and the motion/loading contract follow one gate each. P21 stays active.

"""
arch=f"""## Gate469 Home dashboard swipe pager amendment

Gate468/run{run}/head{head} is the latest FULL canonical release: every registered theme carries the eight `--kairos-bubble-*` roles and `homeDashboardGlassBubbleMap.css` renders both bubble maps through them. Gate467 is the immediate rollback.

The next bounded slice adds two Home presentation owners and wraps the existing selection. `src/app/homeDashboardSwipeGesture.ts` is the pure recognizer (no DOM, timers or data); `src/app/HomeDashboardSwipePager.tsx` binds touch events to one frame, mounts one pane keyed by the view, follows the finger through a rubber-banded custom property and asks the route for the next view; `homeDashboardSwipePager.css` and the segmented-control rules in `homeDashboardYourTrades.css` use tokens only. `HomeRoute.tsx` wraps its unchanged ternary in the pager and marks the switch with the current view; `HomeDashboardYourTrades`, the glass map, drag, motion, freshness, market runtime and every data owner are unchanged. UI VISIBLE:YES. No product-domain, provider, persistence, journal or calculation owner changes; P14/P17/P18/P19/P20 boundaries and P21 active status are unchanged.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate469' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate468 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate467',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate468 Ink bubble presentation amendment',arch)
print('inserted')
