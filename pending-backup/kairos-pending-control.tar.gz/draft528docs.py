"""Insert Gate528 continuity entries into the work528 docs. Reads Gate527 evidence from gate527-evidence.txt, zip527.txt and head527.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate527-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip527.txt').read().split()
HEAD=open(sp+'head527.txt').read().strip()
root=sp+'work528/kairos_p76/docs/'
label="**Patch label:** P35.1 · P35 Practice trade lifecycle: fills, close and activation for paper trades · owner phase P35 (active from the Gate527 canonical PASS) · definition: one explicit `allowedSources` option, defaulted to `['manual']`, on the released P10.4 open-trade update and P31.1 draft activation commands, so a caller must name `'paper'` explicitly to touch a practice trade."
ev=f"Gate527/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P34_3_PROFILE_DATA_SAFETY_CLOSURE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate526 is the immediate rollback. P34 is SYSTEM CLOSED through P34.3."
approval=f"""## Manual Gate528 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the two released guarded-write commands already own the whole shape (outer refusal, re-read inside the transaction, revision comparison, id-collision rejection); the only thing hard-coded to `'manual'` is the source check itself. P35.1 replaces that literal with an explicit `allowedSources` option defaulted to `['manual']`, so every released call site keeps its exact behaviour; the released `tests/journal-open-trade-update.test.tsx` and `tests/draft-trade-activation-command.test.ts` pass unchanged, proving it. The Gate527 verifier pin that asserted the hard-coded `'manual'` guard literal advanced to the new default-option literal. No route or control uses the option yet. UI VISIBLE:NO. P35.2 (Practice route lifecycle controls) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate527

{label}

Gate527/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P34 is SYSTEM CLOSED through P34.3 and P35 is defined from research. Gate526 remains its immediate rollback. The next slice (Gate528, P35.1) is the allowed-source option; P35.2 (Practice route lifecycle controls) and P35.3 (closure) follow.

"""
arch=f"""## Gate528 P35.1 allowed-source option amendment

{label}

Gate527/run{RUN}/head{HEAD} is the latest FULL canonical release: the P34 closure. Gate526 is the immediate rollback.

The next slice adds `allowedSources` to `src/application/trades/updateOpenManualTrade.ts` and `src/application/trades/openDraftTrade.ts` and starts the P35 ledger below at P35.1. Every released call site, control and route is unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate528' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate527 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate526',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate527 P34 closure and P35 definition amendment',arch)
print('inserted')
