"""Pin Gate514 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate513 zip, prev = Gate512 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P30_2_TRADE_DELETE_CONTROLS_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P30_1_TRADE_RECORD_DELETE_COMMAND_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P29_4_PRACTICE_FOUNDATION_CLOSURE_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P30.1 Trade Record Delete Command','name: Kairos Controlled Roadmap Gate — P30.2 Trade Delete Controls')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P30.1 trade record delete command scope from Gate512','      - name: Confirm exact P30.2 trade delete controls scope from Gate513')
start=s.index("          expected = {\n            'KAIROS_P30_1_TRADE_RECORD_DELETE_COMMAND_REPORT_2026-09-18.md',")
end=s.index("            print('P30.1 trade record delete command scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P30_2_TRADE_DELETE_CONTROLS_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_JOURNAL_TRADE_DELETE.md',
            'package.json',
            'scripts/test-journal-trade-delete-browser.mjs',
            'scripts/verify-p29-3-practice-route.mjs',
            'scripts/verify-p30-1-trade-record-delete-command.mjs',
            'scripts/verify-p30-2-trade-delete-controls.mjs',
            'src/app/JournalHistoryList.tsx',
            'src/app/JournalRoute.tsx',
            'src/app/JournalTradeDeleteControl.tsx',
            'src/app/PracticeRoute.tsx',
            'src/app/journalTradeDelete.css',
            'tests/journal-trade-delete-control.test.tsx',
          }
          if changed != expected or removed:
            print('P30.2 trade delete controls scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P30.1 trade record delete command\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P30.2 trade delete controls
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p30:2-trade-delete-controls
          npm run verify:p30:1-trade-record-delete-command
          npm run verify:p29:3-practice-route
          npm run verify:p12:journal-history-closure
          npm run verify:p12:journal-history-status-filter-ui
          npx vitest run \\
            tests/journal-trade-delete-control.test.tsx \\
            tests/trade-record-delete-command.test.ts \\
            tests/practice-route.test.tsx \\
            tests/journal-history-route.test.tsx \\
            tests/manual-trade-journal-route.test.tsx \\
            tests/journal-open-trade-update.test.tsx

"""+s[end:]
rep("          node scripts/test-practice-route-browser.mjs\n","          node scripts/test-practice-route-browser.mjs\n          node scripts/test-journal-trade-delete-browser.mjs\n")
rep("""          for (const required of [
            'verify:p30:1-trade-record-delete-command',""","""          for (const required of [
            'verify:p30:2-trade-delete-controls',
            'verify:p30:1-trade-record-delete-command',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P30_1_TRADE_RECORD_DELETE_COMMAND_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P30_2_TRADE_DELETE_CONTROLS_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/docs/KAIROS_JOURNAL_TRADE_DELETE.md
            .gate-candidate/kairos_p76/.trade-delete-evidence/
            .gate-candidate/kairos_p76/KAIROS_P30_1_TRADE_RECORD_DELETE_COMMAND_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate514')
