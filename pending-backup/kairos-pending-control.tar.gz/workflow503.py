"""Pin Gate503 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate502 zip, prev = Gate501 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P27_2_LIBRARY_ROUTE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P27_1_SAVED_RECORD_INDEX_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P26_4_GOALS_FOUNDATION_CLOSURE_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P27.1 Saved Record Index','name: Kairos Controlled Roadmap Gate — P27.2 Library Route')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P27.1 saved record index scope from Gate501','      - name: Confirm exact P27.2 library route scope from Gate502')
start=s.index("          expected = {\n            'KAIROS_P27_1_SAVED_RECORD_INDEX_REPORT_2026-09-18.md',")
end=s.index("            print('P27.1 saved record index scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P27_2_LIBRARY_ROUTE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_LIBRARY_ROUTE.md',
            'package.json',
            'scripts/test-library-route-browser.mjs',
            'scripts/verify-p23-5-saved-time-assisted-snapshot-preview-round-trip.mjs',
            'scripts/verify-p26-3-goals-route.mjs',
            'scripts/verify-p26-4-goals-foundation-closure.mjs',
            'scripts/verify-p27-1-saved-record-index.mjs',
            'scripts/verify-p27-2-library-route.mjs',
            'src/app/AnalysisHistoryWorkspace.tsx',
            'src/app/AnalysisRoute.tsx',
            'src/app/AnalysisSavedAnalysisControls.tsx',
            'src/app/AnalysisTimeAssistedSnapshotControls.tsx',
            'src/app/LibraryRoute.tsx',
            'src/app/analysisHandoff.ts',
            'src/app/libraryRoute.css',
            'src/app/routes.tsx',
            'tests/library-route.test.tsx',
          }
          if changed != expected or removed:
            print('P27.2 library route scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P27.1 saved record index\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P27.2 library route
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p27:2-library-route
          npm run verify:p27:1-saved-record-index
          npm run verify:p26:4-goals-foundation-closure
          npm run verify:p26:3-goals-route
          npm run verify:p23:5-saved-time-assisted-snapshot-preview-round-trip
          npm run verify:p24:2-saved-record-delete-controls
          npx vitest run \\
            tests/library-route.test.tsx \\
            tests/saved-record-index.test.ts \\
            tests/analysis-saved-record-label.test.tsx \\
            tests/analysis-saved-record-delete.test.tsx \\
            tests/analysis-time-assisted-snapshot-preview.test.tsx \\
            tests/analysis-saved-analysis-round-trip.test.tsx \\
            tests/app-shell-ink.test.tsx

"""+s[end:]
rep("          node scripts/test-goals-route-browser.mjs\n","          node scripts/test-goals-route-browser.mjs\n          node scripts/test-library-route-browser.mjs\n")
rep("""          for (const required of [
            'verify:p27:1-saved-record-index',""","""          for (const required of [
            'verify:p27:2-library-route',
            'verify:p27:1-saved-record-index',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P27_1_SAVED_RECORD_INDEX_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P27_2_LIBRARY_ROUTE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/docs/KAIROS_LIBRARY_ROUTE.md
            .gate-candidate/kairos_p76/.library-route-evidence/
            .gate-candidate/kairos_p76/KAIROS_P27_1_SAVED_RECORD_INDEX_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate503')
