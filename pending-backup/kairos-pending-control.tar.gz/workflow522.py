"""Pin Gate522 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate521 zip, prev = Gate520 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P33_1_SAVED_RECORD_MERGE_IMPORT_COMMAND_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P32_3_JOURNAL_IMPORT_CLOSURE_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P32_2_PROFILE_IMPORT_CONTROL_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P32.3 Journal Import Closure','name: Kairos Controlled Roadmap Gate — P33.1 Saved-Record Merge-Import Command')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P32.3 closure scope from Gate520','      - name: Confirm exact P33.1 saved-record merge-import command scope from Gate521')
start=s.index("          expected = {\n            'KAIROS_P32_3_JOURNAL_IMPORT_CLOSURE_REPORT_2026-09-18.md',")
end=s.index("            print('P32.3 closure scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P33_1_SAVED_RECORD_MERGE_IMPORT_COMMAND_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p32-3-journal-import-closure.mjs',
            'scripts/verify-p33-1-saved-record-merge-import-command.mjs',
            'src/application/backup/importSavedRecords.ts',
            'src/application/backup/index.ts',
            'tests/saved-record-import-command.test.ts',
          }
          if changed != expected or removed:
            print('P33.1 saved-record merge-import command scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P32.3 journal import closure\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P33.1 saved-record merge-import command
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p33:1-saved-record-merge-import-command
          npm run verify:p32:3-journal-import-closure
          npm run verify:p32:1-trade-merge-import-command
          npx vitest run \\
            tests/saved-record-import-command.test.ts \\
            tests/trade-import-command.test.ts \\
            tests/saved-record-index.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p32:3-journal-import-closure',""","""          for (const required of [
            'verify:p33:1-saved-record-merge-import-command',
            'verify:p32:3-journal-import-closure',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P32_3_JOURNAL_IMPORT_CLOSURE_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P33_1_SAVED_RECORD_MERGE_IMPORT_COMMAND_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P32_3_JOURNAL_IMPORT_CLOSURE_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate522')
