"""Insert Gate494 continuity entries into the work494 docs. Reads Gate493 evidence from gate493-evidence.txt, zip493.txt and head493.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate493-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip493.txt').read().split()
HEAD=open(sp+'head493.txt').read().strip()
root=sp+'work494/kairos_p76/docs/'
label="**Patch label:** P24.3 · P24 saved record lifecycle · owner phase P24 (closure) · definition: source-proven closure of P24 and the definition of P25 (saved record labels) from current ownership."
ev=f"Gate493/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P24_2_SAVED_RECORD_DELETE_CONTROLS_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate492 is the immediate rollback. P24.2 is canonical: Delete analysis and Delete snapshot are visible on the Analysis page."
approval=f"""## Manual Gate494 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's "continue" of 18 September 2026. P24.3 adds no production runtime behaviour and no new production owner: it proves P24.1–P24.2 against current source, marks the P24 ledger SYSTEM CLOSED through P24.3 and defines P25 from ownership: saved record labels (an optional user-given label on Saved Analyses and saved snapshots, contract amendment without schema index or backup format bump, set beside Save analysis / Save snapshot and shown in the lists). UI VISIBLE:NO. User rule, 18 September 2026 (verbatim intent): no per-patch UI review is needed; continue to the next patch autonomously; any decision that research can settle is settled by research, proven against the project, and applied; pause and ask only when the user's own output is genuinely required. Under this rule P25 begins after this PASS without a further prompt, and the parked Ink amendments are handled the same way when their turn comes. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate493

{label}

Gate493/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P24.2 (Delete analysis / Delete snapshot) is canonical. Gate492 remains its immediate rollback. The next slice (Gate494, P24.3) is the P24 closure and the definition of P25 (saved record labels) from ownership.

"""
arch=f"""## Gate494 P24 closure and P25 definition amendment

{label}

Gate493/run{RUN}/head{HEAD} is the latest FULL canonical release: the P24.2 delete controls. Gate492 is the immediate rollback.

The next slice adds `scripts/verify-p24-3-saved-record-lifecycle-closure.mjs`, closes the P24 ledger below at P24.3 and adds the P24 closure section and the P25 definition. No production file changes. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate494' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate493 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate492',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate493 P24.2 saved record delete controls amendment',arch)
print('inserted')
