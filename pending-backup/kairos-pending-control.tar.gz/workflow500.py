"""Pin Gate500 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate499 zip, prev = Gate498 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P26_3_GOALS_ROUTE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P26_2_GOALS_PROGRESS_PROJECTION_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P26_1_GOALS_PREFERENCE_FOUNDATION_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P26.2 Goals Progress Projection','name: Kairos Controlled Roadmap Gate — P26.3 Goals Route')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P26.2 goals progress projection scope from Gate498','      - name: Confirm exact P26.3 goals route scope from Gate499')
start=s.index("          expected = {\n            'KAIROS_P26_2_GOALS_PROGRESS_PROJECTION_REPORT_2026-09-18.md',")
end=s.index("            print('P26.2 goals progress projection scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P26_3_GOALS_ROUTE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_GOALS_ROUTE.md',
            'package.json',
            'scripts/test-goals-route-browser.mjs',
            'scripts/verify-p25-3-saved-record-labels-closure.mjs',
            'scripts/verify-p26-1-goals-preference-foundation.mjs',
            'scripts/verify-p26-2-goals-progress-projection.mjs',
            'scripts/verify-p26-3-goals-route.mjs',
            'src/app/GoalsRoute.tsx',
            'src/app/goalsRoute.css',
            'src/app/routes.tsx',
            'tests/goals-route.test.tsx',
          }
          if changed != expected or removed:
            print('P26.3 goals route scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P26.2 goals progress projection\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P26.3 goals route
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p26:3-goals-route
          npm run verify:p26:2-goals-progress-projection
          npm run verify:p26:1-goals-preference-foundation
          npm run verify:p13:12-explicit-time-zone-settings
          npx vitest run \\
            tests/goals-route.test.tsx \\
            tests/goals-progress.test.ts \\
            tests/goals-preference.test.ts \\
            tests/settings-visual-pnl-time-zone.test.tsx \\
            tests/app-shell-ink.test.tsx

"""+s[end:]
rep("          node scripts/test-analysis-saved-record-label-browser.mjs\n","          node scripts/test-analysis-saved-record-label-browser.mjs\n          node scripts/test-goals-route-browser.mjs\n")
rep("""          for (const required of [
            'verify:p26:2-goals-progress-projection',""","""          for (const required of [
            'verify:p26:3-goals-route',
            'verify:p26:2-goals-progress-projection',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P26_2_GOALS_PROGRESS_PROJECTION_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P26_3_GOALS_ROUTE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/docs/KAIROS_GOALS_ROUTE.md
            .gate-candidate/kairos_p76/.goals-route-evidence/
            .gate-candidate/kairos_p76/KAIROS_P26_2_GOALS_PROGRESS_PROJECTION_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate500')
