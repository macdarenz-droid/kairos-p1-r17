"""Pin Gate505 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate504 zip, prev = Gate503 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P28_1_BACKUP_EXPORT_COMMAND_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P27_3_LIBRARY_FOUNDATION_CLOSURE_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P27_2_LIBRARY_ROUTE_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P27.3 Library Foundation Closure','name: Kairos Controlled Roadmap Gate — P28.1 Backup Export Command')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P27.3 closure scope from Gate503','      - name: Confirm exact P28.1 backup export command scope from Gate504')
start=s.index("          expected = {\n            'KAIROS_P27_3_LIBRARY_FOUNDATION_CLOSURE_REPORT_2026-09-18.md',")
end=s.index("            print('P27.3 closure scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P28_1_BACKUP_EXPORT_COMMAND_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p28-1-backup-export-command.mjs',
            'src/application/backup/exportBackup.ts',
            'src/application/backup/index.ts',
            'tests/backup-export-command.test.ts',
          }
          if changed != expected or removed:
            print('P28.1 backup export command scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P27.3 library foundation closure\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P28.1 backup export command
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p28:1-backup-export-command
          npm run verify:p27:3-library-foundation-closure
          npm run verify:p6:backup-snapshot
          npm run verify:p6:backup-envelope
          npx vitest run \\
            tests/backup-export-command.test.ts \\
            tests/backup-snapshot.test.ts \\
            tests/backup-envelope.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p27:3-library-foundation-closure',""","""          for (const required of [
            'verify:p28:1-backup-export-command',
            'verify:p27:3-library-foundation-closure',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P27_3_LIBRARY_FOUNDATION_CLOSURE_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P28_1_BACKUP_EXPORT_COMMAND_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P27_3_LIBRARY_FOUNDATION_CLOSURE_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate505')
