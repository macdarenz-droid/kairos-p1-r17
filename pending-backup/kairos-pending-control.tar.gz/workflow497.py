"""Pin Gate497 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate496 zip, prev = Gate495 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P25_3_SAVED_RECORD_LABELS_CLOSURE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P25_2_SAVED_RECORD_LABEL_PRESENTATION_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P25_1_SAVED_RECORD_LABEL_FOUNDATION_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P25.2 Saved Record Label Presentation','name: Kairos Controlled Roadmap Gate — P25.3 Saved Record Labels Closure')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P25.2 saved record label presentation scope from Gate495','      - name: Confirm exact P25.3 closure scope from Gate496')
start=s.index("          expected = {\n            'KAIROS_P25_2_SAVED_RECORD_LABEL_PRESENTATION_REPORT_2026-09-18.md',")
end=s.index("            print('P25.2 saved record label presentation scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P25_3_SAVED_RECORD_LABELS_CLOSURE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p25-3-saved-record-labels-closure.mjs',
          }
          if changed != expected or removed:
            print('P25.3 closure scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P25.2 saved record label presentation\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P25.3 saved record labels closure
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p25:3-saved-record-labels-closure
          npm run verify:p25:2-saved-record-label-presentation
          npm run verify:p25:1-saved-record-label-foundation
          npm run verify:p24:3-saved-record-lifecycle-closure
          npx vitest run \\
            tests/saved-record-label-foundation.test.ts \\
            tests/analysis-saved-record-label.test.tsx

"""+s[end:]
rep("""          for (const required of [
            'verify:p25:2-saved-record-label-presentation',""","""          for (const required of [
            'verify:p25:3-saved-record-labels-closure',
            'verify:p25:2-saved-record-label-presentation',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P25_2_SAVED_RECORD_LABEL_PRESENTATION_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P25_3_SAVED_RECORD_LABELS_CLOSURE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P25_2_SAVED_RECORD_LABEL_PRESENTATION_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate497')
