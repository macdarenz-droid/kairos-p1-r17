"""Pin Gate477 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA"""
import sys
size,sha,bsize,bsha=sys.argv[1:5]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — Analysis Drawing Tools Mount','name: Kairos Controlled Roadmap Gate — Analysis Drawing Tools Endpoint Edit')
rep("      - 'KAIROS_ANALYSIS_DRAWING_TOOLS_MOUNT_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_ANALYSIS_DRAWING_TOOLS_ENDPOINT_EDIT_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_ANALYSIS_DRAWING_TOOLS_RENDERER_SESSION_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_DRAWING_TOOLS_MOUNT_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_ANALYSIS_DRAWING_TOOLS_MOUNT_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_DRAWING_TOOLS_ENDPOINT_EDIT_CANDIDATE_2026-09-17.zip')
rep(f"            ('BASE_ZIP', 3929189, '503bfc116b4302ce3ceec48b968debbaa3be8720d51507c211d218325c11c9fe'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact Analysis drawing tools mount scope from Gate475','      - name: Confirm exact Analysis drawing tools endpoint edit scope from Gate476')
rep("""          expected = {
            'docs/KAIROS_ANALYSIS_DRAWING_TOOLS_MOUNT.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-drawing-tools-browser.mjs',
            'scripts/verify-analysis-drawing-tools-mount.mjs',
            'src/app/AnalysisDrawingToolsControls.tsx',
            'src/app/AnalysisHistoryWorkspace.tsx',
            'src/app/AnalysisLiveCandleCanvas.tsx',
            'src/app/AnalysisSavedTradeOverlayLiveCandleCanvas.tsx',
            'src/app/analysisDrawingToolsComposition.ts',
            'src/app/analysisDrawingToolsContext.ts',
            'src/app/analysisHistory.css',
            'src/app/analysisLiveCandleProductPolicy.ts',
            'src/app/useAnalysisDrawingTools.ts',
            'tests/analysis-drawing-tools-mount.test.tsx',
          }
          if changed != expected or removed:
            print('Analysis drawing tools mount scope mismatch', file=sys.stderr)""","""          expected = {
            'docs/KAIROS_ANALYSIS_DRAWING_TOOLS_ENDPOINT_EDIT.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-drawing-tools-edit-browser.mjs',
            'scripts/verify-analysis-drawing-tools-endpoint-edit.mjs',
            'scripts/verify-analysis-drawing-tools-mount.mjs',
            'src/app/AnalysisDrawingToolsControls.tsx',
            'src/app/analysisDrawingToolsComposition.ts',
            'src/app/analysisDrawingToolsRendererSession.ts',
            'src/app/analysisLiveCandleProductPolicy.ts',
            'tests/analysis-drawing-tools-mount.test.tsx',
            'tests/analysis-drawing-tools-renderer-session.test.ts',
          }
          if changed != expected or removed:
            print('Analysis drawing tools endpoint edit scope mismatch', file=sys.stderr)""")
rep("""            tests/analysis-saved-trade-position-box.test.tsx

      - name: Production TypeScript compilation""","""            tests/analysis-saved-trade-position-box.test.tsx

      - name: Analysis drawing tools endpoint edit
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:analysis-drawing-tools-endpoint-edit
          npm run verify:analysis-drawing-tools-mount
          npm run verify:analysis-drawing-tools-renderer-session
          npm run verify:p18:60-drawing-tools-system-closure
          npx vitest run \\
            tests/analysis-drawing-tools-renderer-session.test.ts \\
            tests/analysis-drawing-tools-mount.test.tsx \\
            tests/lightweight-charts-v5-trend-line-edit-click-execution-lifecycle-composition.test.ts

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:analysis-drawing-tools-mount',""","""          for (const required of [
            'verify:analysis-drawing-tools-endpoint-edit',
            'verify:analysis-drawing-tools-mount',""")
rep("""          node scripts/test-analysis-drawing-tools-browser.mjs

      - name: Full unit regression""","""          node scripts/test-analysis-drawing-tools-browser.mjs
          node scripts/test-analysis-drawing-tools-edit-browser.mjs

      - name: Full unit regression""")
rep("""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_DRAWING_TOOLS_MOUNT.md""","""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_DRAWING_TOOLS_ENDPOINT_EDIT.md
            .gate-candidate/kairos_p76/.drawing-tools-edit-evidence/
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_DRAWING_TOOLS_MOUNT.md""")
open(p,'w').write(s); print('workflow pinned for Gate477')
