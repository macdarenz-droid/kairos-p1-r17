"""Pin Gate471 in the repo workflow. Usage: SIZE SHA"""
import sys
size,sha=sys.argv[1],sys.argv[2]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — Journal Ink Presentation','name: Kairos Controlled Roadmap Gate — Analysis Ink Presentation')
rep("      - 'KAIROS_JOURNAL_INK_PRESENTATION_CANDIDATE_2026-09-17-R1.zip'\n","      - 'KAIROS_ANALYSIS_INK_PRESENTATION_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_HOME_DASHBOARD_SWIPE_PAGER_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_JOURNAL_INK_PRESENTATION_CANDIDATE_2026-09-17-R1.zip','  BASE_ZIP: KAIROS_JOURNAL_INK_PRESENTATION_CANDIDATE_2026-09-17-R1.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_INK_PRESENTATION_CANDIDATE_2026-09-17.zip')
rep("            ('BASE_ZIP', 3881540, '5d91d56d56c4a6adb7ae72d8a5e33c98508ecfbabdc4620ede8c7c278892e52d'),\n            ('CANDIDATE_ZIP', 3886892, '852aeeaa4d6bf7eafc38de252a52e4d07535212b4e3414adc78dbc88c7632c4b'),",f"            ('BASE_ZIP', 3886892, '852aeeaa4d6bf7eafc38de252a52e4d07535212b4e3414adc78dbc88c7632c4b'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact Journal Ink presentation R1 scope from Gate469','      - name: Confirm exact Analysis Ink presentation scope from Gate470 R1')
rep("""          expected = {
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_JOURNAL_INK_PRESENTATION.md',
            'package.json',
            'scripts/verify-journal-ink-presentation.mjs',
            'src/app/journalRoute.css',
            'tests/home-dashboard-swipe-pager.test.tsx',
          }
          if changed != expected or removed:
            print('Journal Ink presentation scope mismatch', file=sys.stderr)""","""          expected = {
            'docs/KAIROS_ANALYSIS_INK_PRESENTATION.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-analysis-ink-presentation.mjs',
            'src/app/analysisHistory.css',
            'src/app/tradeReview.css',
          }
          if changed != expected or removed:
            print('Analysis Ink presentation scope mismatch', file=sys.stderr)""")
rep("""            tests/home-dashboard-swipe-pager.test.tsx

      - name: Production TypeScript compilation""","""            tests/home-dashboard-swipe-pager.test.tsx

      - name: Analysis Ink presentation
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:analysis-ink-presentation
          npm run verify:analysis-history-workspace
          node scripts/verify-trade-review.mjs
          npm run verify:analysis-live-candle-status-presentation
          npm run verify:analysis-saved-trade-overlay-workspace-mount
          npm run verify:p2:design-system
          npm run verify:p2:accessibility
          npx vitest run \\
            tests/analysis-history-workspace.test.tsx \\
            tests/analysis-live-candle-status-presentation.test.ts \\
            tests/trade-review.test.tsx

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:journal-ink-presentation',""","""          for (const required of [
            'verify:analysis-ink-presentation',
            'verify:journal-ink-presentation',""")
rep("""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_JOURNAL_INK_PRESENTATION.md""","""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_INK_PRESENTATION.md
            .gate-candidate/kairos_p76/docs/KAIROS_JOURNAL_INK_PRESENTATION.md""")
open(p,'w').write(s); print('workflow pinned for Gate471')
