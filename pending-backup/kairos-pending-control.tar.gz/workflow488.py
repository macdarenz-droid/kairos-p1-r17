"""Pin Gate488 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate487 zip, prev = Gate486 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P23_3_SAVED_TIME_ASSISTED_SNAPSHOT_APPLICATION_SAVE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P23_2_SAVED_TIME_ASSISTED_SNAPSHOT_PERSISTENCE_FOUNDATION_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P23_1_SAVED_TIME_ASSISTED_SNAPSHOT_CONTRACT_FOUNDATION_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P23.2 Saved Time-Assisted Snapshot Persistence Foundation','name: Kairos Controlled Roadmap Gate — P23.3 Saved Time-Assisted Snapshot Application Save')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P23.2 saved time-assisted snapshot persistence scope from Gate486','      - name: Confirm exact P23.3 saved time-assisted snapshot application save scope from Gate487')
start=s.index("          expected = {\n            'KAIROS_P23_2_SAVED_TIME_ASSISTED_SNAPSHOT_PERSISTENCE_FOUNDATION_REPORT_2026-09-18.md',")
end=s.index("            print('P23.2 saved time-assisted snapshot persistence scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P23_3_SAVED_TIME_ASSISTED_SNAPSHOT_APPLICATION_SAVE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p23-3-saved-time-assisted-snapshot-application-save.mjs',
            'src/application/saved-time-assisted-snapshot/index.ts',
            'src/application/saved-time-assisted-snapshot/saveSavedTimeAssistedSnapshot.ts',
            'tests/saved-time-assisted-snapshot-save-command.test.ts',
          }
          if changed != expected or removed:
            print('P23.3 saved time-assisted snapshot application save scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P23.2 saved time-assisted snapshot persistence foundation\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P23.3 saved time-assisted snapshot application save
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p23:3-saved-time-assisted-snapshot-application-save
          npm run verify:p23:2-saved-time-assisted-snapshot-persistence-foundation
          npm run verify:p23:1-saved-time-assisted-snapshot-contract-foundation
          npm run verify:p20:3-saved-analysis-application-save
          npm run verify:p22:2-time-assisted-trade-snapshot-composition
          npx vitest run \\
            tests/saved-time-assisted-snapshot-save-command.test.ts \\
            tests/saved-time-assisted-snapshot-persistence.test.ts \\
            tests/saved-time-assisted-snapshot-contract.test.ts \\
            tests/saved-analysis-save-command.test.ts \\
            tests/time-assisted-trade-snapshot.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p23:2-saved-time-assisted-snapshot-persistence-foundation',""","""          for (const required of [
            'verify:p23:3-saved-time-assisted-snapshot-application-save',
            'verify:p23:2-saved-time-assisted-snapshot-persistence-foundation',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P23_2_SAVED_TIME_ASSISTED_SNAPSHOT_PERSISTENCE_FOUNDATION_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P23_3_SAVED_TIME_ASSISTED_SNAPSHOT_APPLICATION_SAVE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P23_2_SAVED_TIME_ASSISTED_SNAPSHOT_PERSISTENCE_FOUNDATION_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate488')
