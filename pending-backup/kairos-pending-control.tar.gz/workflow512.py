"""Pin Gate512 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate511 zip, prev = Gate510 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P29_4_PRACTICE_FOUNDATION_CLOSURE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P29_3_PRACTICE_ROUTE_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P29_2_REAL_RESULT_ISOLATION_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P29.3 Practice Route','name: Kairos Controlled Roadmap Gate — P29.4 Practice Foundation Closure')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P29.3 practice route scope from Gate510','      - name: Confirm exact P29.4 closure scope from Gate511')
start=s.index("          expected = {\n            'KAIROS_P29_3_PRACTICE_ROUTE_REPORT_2026-09-18.md',")
end=s.index("            print('P29.3 practice route scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P29_4_PRACTICE_FOUNDATION_CLOSURE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p29-2-real-result-isolation.mjs',
            'scripts/verify-p29-3-practice-route.mjs',
            'scripts/verify-p29-4-practice-foundation-closure.mjs',
          }
          if changed != expected or removed:
            print('P29.4 closure scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P29.3 practice route\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P29.4 practice foundation closure
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p29:4-practice-foundation-closure
          npm run verify:p29:3-practice-route
          npm run verify:p29:2-real-result-isolation
          npm run verify:p29:1-practice-trade-command
          npx vitest run \\
            tests/practice-route.test.tsx \\
            tests/journal-history-scope.test.ts \\
            tests/practice-trade-save-command.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p29:3-practice-route',""","""          for (const required of [
            'verify:p29:4-practice-foundation-closure',
            'verify:p29:3-practice-route',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P29_3_PRACTICE_ROUTE_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P29_4_PRACTICE_FOUNDATION_CLOSURE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P29_3_PRACTICE_ROUTE_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate512')
