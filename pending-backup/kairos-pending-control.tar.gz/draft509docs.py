"""Insert Gate509 continuity entries into the work509 docs. Reads Gate508 evidence from gate508-evidence.txt, zip508.txt and head508.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate508-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip508.txt').read().split()
HEAD=open(sp+'head508.txt').read().strip()
root=sp+'work509/kairos_p76/docs/'
label="**Patch label:** P29.1 · P29 Practice foundation: paper trades · owner phase P29 (active from the Gate508 canonical PASS) · definition: the application command that records one practice (paper) trade through the released P10 validation and atomic write shape, never touching a manual trade."
ev=f"Gate508/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P28_4_PROFILE_FOUNDATION_CLOSURE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate507 is the immediate rollback. P28 is SYSTEM CLOSED through P28.4."
approval=f"""## Manual Gate509 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: `TradeSource` already admits `'paper'` and the backup validation and integrity checks accept it, `prepareManualTrade` (P10.1) already owns the whole normalisation and validation, and `updateOpenManualTrade` refuses any non-manual trade. P29.1 adds `src/application/practice/savePracticeTrade.ts`: the released preparation, the trade re-stamped `source: 'paper'` and re-validated, the same atomic aggregate write, explicit validation-error and storage-error outcomes; no released line changes and no schema, index or field is added. The history seam and the Practice placeholder are untouched until P29.2 and P29.3. UI VISIBLE:NO. P29.2 (real-result isolation) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate508

{label}

Gate508/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P28 is SYSTEM CLOSED through P28.4 and P29 is defined from research. Gate507 remains its immediate rollback. The next slice (Gate509, P29.1) is the practice trade command; P29.2 (real-result isolation), P29.3 (Practice route) and P29.4 (closure) follow.

"""
arch=f"""## Gate509 P29.1 practice trade command amendment

{label}

Gate508/run{RUN}/head{HEAD} is the latest FULL canonical release: the P28 closure. Gate507 is the immediate rollback.

The next slice adds `src/application/practice/savePracticeTrade.ts` (exported through `src/application/practice/index.ts`) and starts the P29 ledger below at P29.1. P10, P12, the shell and every route are unchanged; Practice stays a placeholder. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate509' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate508 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate507',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate508 P28 closure and P29 definition amendment',arch)
print('inserted')
