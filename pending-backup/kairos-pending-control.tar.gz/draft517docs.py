"""Insert Gate517 continuity entries into the work517 docs. Reads Gate516 evidence from gate516-evidence.txt, zip516.txt and head516.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate516-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip516.txt').read().split()
HEAD=open(sp+'head516.txt').read().strip()
root=sp+'work517/kairos_p76/docs/'
label="**Patch label:** P31.2 · P31 Trade record lifecycle: draft activation · owner phase P31 (active from the Gate515 canonical PASS) · definition: the visible activation of a saved manual draft on its Journal history card through the P31.1 command, proven in unit tests and a real browser."
ev=f"Gate516/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P31_1_DRAFT_TRADE_ACTIVATION_COMMAND_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate515 is the immediate rollback. P31.1 is canonical."
approval=f"""## Manual Gate517 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the released open-trade update control already shows the per-card panel shape and the list already exposes optional ports mounted only with the database, so the activation control follows both with one new `onTradeOpened` port and one attribute on the Journal mount; the P10 execution-details preparation already normalises the opened moment and the fill rows, so the control collects facts only; practice drafts stay recorded only. P31.2 adds `src/app/JournalDraftTradeActivation.tsx` on every manual draft card of the Journal history; the P31.1 history-card pin advanced to the new literal. Real browser evidence (`scripts/test-journal-draft-activation-browser.mjs`, `.draft-activation-evidence/`) proves a planned draft saved through the real Journal UI, the refused opening without a moment, the opening with currency and one entry fill recorded as open with the same id and the plan byte-identical, the card no longer offering activation, and the panel at both viewports in both themes. UI VISIBLE:YES. P31.3 (closure) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate516

{label}

Gate516/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P31.1 (draft trade activation command) is canonical. Gate515 remains its immediate rollback. The next slice (Gate517, P31.2) mounts the activation control with browser evidence; P31.3 (closure) follows.

"""
arch=f"""## Gate517 P31.2 draft trade activation control amendment

{label}

Gate516/run{RUN}/head{HEAD} is the latest FULL canonical release: the P31.1 draft trade activation command. Gate515 is the immediate rollback.

The next slice adds `src/app/JournalDraftTradeActivation.tsx` and `src/app/journalDraftTradeActivation.css`, the `onTradeOpened` port on `src/app/JournalHistoryList.tsx` mounted by the Journal route, the unit and real-browser evidence and `docs/KAIROS_JOURNAL_DRAFT_ACTIVATION.md`, and advances the P31 ledger below to P31.2. Every released mount line keeps its literals; the Practice route and the schema are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate517' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate516 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate515',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate516 P31.1 draft trade activation command amendment',arch)
print('inserted')
