"""Insert Gate472 continuity entries into the work472 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST"""
import sys
run,job,head,cid,cdig,eid,edig=sys.argv[1:8]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work472/kairos_p76/docs/'
ev=f"Gate471/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_ANALYSIS_INK_PRESENTATION_CANDIDATE_2026-09-17.zip;3892168bytes;SHA256 7202cbd0c0a8c4d50ef0a781c7386577bf54f44593ffd2034f59f1a06d4775b3; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate470 R1 is the immediate rollback."
approval=f"""## Manual Gate472 slice — 17 September 2026

{ev}

Under the user's autonomous continuation authority, the next smallest dependency-safe item-5 prerequisite is the non-UI saved-trade Risk/Reward ratio projection in KAIROS_ANALYSIS_SAVED_TRADE_RISK_REWARD_RATIO_PROJECTION.md. Source inspection shows no released owner exposes a planned ratio or an open R: the P19 contract carries only side plus exact entry, stop and target, while P11 already owns the exact decimal kernel, risk-distance and R-multiple calculators. The projection reads the released `RiskRewardAnalysis` and a caller-authoritative last close (or null), derives risk distance, reward distance, the planned ratio and the side-signed live R exclusively through those released calculators, and fails closed on inverted or flat levels, zero risk distance or invalid decimals while a missing last close keeps the planned ratio. UI VISIBLE:NO. It adds no route/workspace mount, React lifecycle, style resolution, history, provider, persistence, journal, formatting or new arithmetic owner and no execution, venue, FX or P&L inference. The TradingView-style position box that shows this ratio and live R beside the chart under the approved Ink direction is the next separate slice. Candidate publication and complete canonical PASS remain mandatory; P21 stays active.

"""
plan=f"""## Status after FULL Gate471

Gate471/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present; the Analysis workspace and review cards now render on Ink and Paper through two appended route-scoped CSS amendments. Gate470 R1 remains its immediate rollback. The position box needs an exact ratio and open-R owner first, so the next slice is the non-UI saved-trade Risk/Reward ratio projection (Gate472) through the released P11 calculators; the position box presentation and the motion/loading contract follow one gate each. P21 stays active.

"""
arch=f"""## Gate472 saved-trade Risk/Reward ratio projection amendment

Gate471/run{run}/head{head} is the latest FULL canonical release: `analysisHistory.css` and `tradeReview.css` carry the appended Analysis Ink amendments and every released rule above them is byte-identical. Gate470 R1 is the immediate rollback.

The next bounded non-UI boundary adds `projectAnalysisSavedTradeRiskRewardRatio` in `src/app/analysisSavedTradeRiskRewardRatioProjection.ts`. It accepts the released `RiskRewardAnalysis` and a caller-authoritative last close, delegates every operation to the released decimal kernel, `calculateRiskPriceDistance` and `calculateRMultiple`, and returns exact decimal strings for risk distance, reward distance, the planned ratio and the side-signed live R, or fails closed. UI VISIBLE:NO. It is not imported by any route, workspace or session. No product-domain, provider, persistence, journal or calculation owner changes; P11/P14/P17/P18/P19/P20 boundaries and P21 active status are unchanged.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate472' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate471 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate470 R1',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate471 Analysis Ink presentation amendment',arch)
print('inserted')
