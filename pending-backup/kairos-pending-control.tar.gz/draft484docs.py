"""Insert Gate484 continuity entries into the work484 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST ZIP_SIZE ZIP_SHA (Gate483 evidence + Gate483 zip)"""
import sys
run,job,head,cid,cdig,eid,edig,zsize,zsha=sys.argv[1:10]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work484/kairos_p76/docs/'
label="**Patch label:** P22.5 · P22 time-assisted trade snapshot · owner phase P22 (active) · definition: \"Show on chart\" scrolls the live Analysis chart to the padded trade interval of the current time-assisted snapshot through the Gate474 seam, reporting the range the vendor actually shows, with real browser evidence and no data change."
ev=f"Gate483/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_ANALYSIS_TIME_ASSISTED_ESTIMATE_MARKERS_CANDIDATE_2026-09-17.zip;{zsize}bytes;SHA256 {zsha}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate482 is the immediate rollback."
approval=f"""## Manual Gate484 slice — 17 September 2026

{label}

{ev}

Under the user's autonomous-continuation authority, the time-assisted snapshot gains navigation in KAIROS_ANALYSIS_TIME_ASSISTED_WINDOW_NAVIGATION.md: a window session shares the Gate474 seam with the drawing tools (the Gate476 hook fans an extra drawing-binding lifecycle out with its own), pads the trade interval (15 % of the span, at least 5 minutes) and asks the vendor time scale for that visible range behind a runtime guard; because the vendor applies the target on its next frame, the applied range is re-read then and shown in the preview ("The chart now shows … to … UTC."). The three pinned literals this changes (Gate476 and Gate483 hook-call literals, Gate482 preview mount literal) are updated to the new literals. UI VISIBLE:YES. Real Chromium evidence (`scripts/test-analysis-time-assisted-window-browser.mjs`, `.time-assisted-window-evidence/`) proves the vendor-reported visible range covers the whole trade interval after Show on chart, the pane repaints, both estimate markers stay, journal facts are byte-identical, Ink/Paper at 320/390px. P22 closure follows. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate483

{label}

Gate483/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present: estimate markers are drawn on both chart paths. Gate482 remains its immediate rollback. The next slice (Gate484, P22.5) scrolls the chart to the trade interval; P22 closure follows.

"""
arch=f"""## Gate484 P22.5 time-assisted window navigation amendment

{label}

Gate483/run{run}/head{head} is the latest FULL canonical release: the time-assisted estimate markers. Gate482 is the immediate rollback.

The next slice adds `src/app/analysisTimeAssistedWindowSession.ts` (with `composeDrawingBindingLifecycles`) and `src/app/useAnalysisTimeAssistedWindow.ts`; the Gate476 hook fans an extra drawing-binding lifecycle out with its own; the workspace and preview wire "Show on chart". The P22.5 ledger row is below. P17 rendering, the vendor time scale, the journal owners and every other mount are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate484' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate483 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate482',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate483 P22.4 time-assisted estimate markers amendment',arch)
print('inserted')
