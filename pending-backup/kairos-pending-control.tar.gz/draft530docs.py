"""Insert Gate530 continuity entries into the work530 docs. Reads Gate529 evidence from gate529-evidence.txt, zip529.txt and head529.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate529-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip529.txt').read().split()
HEAD=open(sp+'head529.txt').read().strip()
root=sp+'work530/kairos_p76/docs/'
label="**Patch label:** P35.3 · P35 Practice trade lifecycle: fills, close and activation for paper trades · owner phase P35 (closure) · definition: source-proven closure of P35, realignment of the roadmap to the user's September 2026 vision, and the definition of P36 from that vision."
ev=f"Gate529/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P35_2_PRACTICE_ROUTE_LIFECYCLE_CONTROLS_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate528 is the immediate rollback. P35.2 is canonical."
approval=f"""## Manual Gate530 slice — 20 September 2026

{label}

{ev}

User direction of 20 September 2026: the user supplied the *Kairos — Vision & Roadmap, September 2026* document (40 phases), identified that built P22–P35 had drifted from it (their numbers reused for smaller, ownership-defined features), and directed: realign, update the roadmap, and start progress. P35.3 closes P35 with no production runtime change (the P35 ledger is SYSTEM CLOSED through P35.3; the closure report and whole-phase verifier prove the option and the Practice mounts retained; the Gate529 verifier pin on the P35 ledger heading advanced to the closure literal) and introduces `docs/KAIROS_VISION_ROADMAP_ALIGNMENT.md` as the canonical roadmap: built numbers never change (retained verifiers pin them), every phase from P36 onward is a named vision feature, and closures define the next phase from its dependency-ordered forward sequence. P36 (Discipline foundation: checklists, mistake tracking and discipline score — vision P22, discipline half) is defined from research: no discipline owner exists in source, schema V5 is append-only with paired backup format bumps, the atomic trade delete covers exactly plans, executions and fees, and the Home dashboard is the vision's home for the score. P36.1 (discipline record foundation) follows without a further prompt; the 18 September 2026 autonomy rule otherwise stands. UI VISIBLE:NO. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate529

{label}

Gate529/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P35.2 (Practice route lifecycle controls) is canonical. Gate528 remains its immediate rollback. The next slice (Gate530, P35.3) closes P35, realigns the roadmap to the September 2026 vision and defines P36 (Discipline foundation).

"""
arch=f"""## Gate530 P35 closure, vision realignment and P36 definition amendment

{label}

Gate529/run{RUN}/head{HEAD} is the latest FULL canonical release: the P35.2 Practice route lifecycle controls. Gate528 is the immediate rollback.

The next slice closes the P35 ledger below through P35.3, adds `docs/KAIROS_VISION_ROADMAP_ALIGNMENT.md` (canonical: built numbers unchanged, P36 onward are named vision features in dependency order) and defines P36 from the vision. No production runtime owner is added; every route, command and the schema are unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate530' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate529 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate528',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate529 P35.2 Practice route lifecycle controls amendment',arch)
print('inserted')
