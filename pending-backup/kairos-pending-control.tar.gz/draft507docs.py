"""Insert Gate507 continuity entries into the work507 docs. Reads Gate506 evidence from gate506-evidence.txt, zip506.txt and head506.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate506-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip506.txt').read().split()
HEAD=open(sp+'head506.txt').read().strip()
root=sp+'work507/kairos_p76/docs/'
label="**Patch label:** P28.3 · P28 Profile foundation: your data · owner phase P28 (active from the Gate504 canonical PASS) · definition: the Profile page replacing the More-tab placeholder, mounting the P28.1 backup export, the P28.2 restore flow and the read-only device activation state, proven in unit tests and a real browser."
ev=f"Gate506/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P28_2_BACKUP_RESTORE_COMMAND_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate505 is the immediate rollback. P28.2 is canonical."
approval=f"""## Manual Gate507 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the activation receipt repository already distinguishes missing, corrupt and stored, so the device card reads through it and shows only the activation id and moments (never the payload or signature, never verifying); a browser download and a file read are props with browser defaults; and because restore is destructive the route never writes on file choice — the P28.2 prepare step yields the preview and the recovery file, and only the explicit "Replace my data" reaches the commit. P28.3 replaces the `/profile` placeholder with `src/app/ProfileRoute.tsx`: the device card, the Download backup action over P28.1, and the restore card (picker, plain-word refusals, preview, Download current data first, Replace my data, Cancel, verified outcome, pre-restore copy on failure). The Gate500/Gate503/Gate504/Gate505/Gate506 verifier pins on the Profile placeholder advanced to the route line; Practice stays a placeholder. Real browser evidence (`scripts/test-profile-route-browser.mjs`, `.profile-route-evidence/`) proves More → Profile, a real download of one named V4 file carrying a trade saved through the real Journal with the store unchanged, a refused non-backup, the preview with the current data offered first, the confirmed verified replacement visible on the Goals page, and both viewports in both themes. UI VISIBLE:YES. P28.4 (closure) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate506

{label}

Gate506/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P28.2 (backup restore command) is canonical. Gate505 remains its immediate rollback. The next slice (Gate507, P28.3) mounts the Profile route with browser evidence; P28.4 (closure) follows.

"""
arch=f"""## Gate507 P28.3 Profile route amendment

{label}

Gate506/run{RUN}/head{HEAD} is the latest FULL canonical release: the P28.2 backup restore command. Gate505 is the immediate rollback.

The next slice adds `src/app/ProfileRoute.tsx` and `src/app/profileRoute.css`, wires `/profile` to the route in `src/app/routes.tsx`, adds the unit and real-browser evidence and `docs/KAIROS_PROFILE_ROUTE.md`, and advances the P28 ledger below to P28.3. Navigation, P6, the activation service and the Practice placeholder are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate507' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate506 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate505',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate506 P28.2 backup restore command amendment',arch)
print('inserted')
