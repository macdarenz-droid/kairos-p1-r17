"""Insert Gate498 continuity entries into the work498 docs. Reads Gate497 evidence from gate497-evidence.txt, zip497.txt and head497.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate497-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip497.txt').read().split()
HEAD=open(sp+'head497.txt').read().strip()
root=sp+'work498/kairos_p76/docs/'
label="**Patch label:** P26.1 · P26 Goals foundation · owner phase P26 (active from the Gate497 canonical PASS) · definition: the goals contract, its typed-input validation, and its persistence as one P5 metadata record."
ev=f"Gate497/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P25_3_SAVED_RECORD_LABELS_CLOSURE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate496 is the immediate rollback. P25 is SYSTEM CLOSED through P25.3."
approval=f"""## Manual Gate498 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: user preferences already persist as versioned P5 metadata records (the P13.10R1 time-zone preference is the model), so `preferences.goals.v1` needs no schema change, migration or backup format bump and travels in every backup; the contract holds only targets the released P11/P12/P13 owners can project without new arithmetic truth (trades per month, max trades per day, a monthly result target in one currency). P26.1 adds `src/application/goals/goalsPreference.ts` with typed-input validation and explicit reasons, read (missing or malformed evidence reads as no goals set), write (JSON, version 1) and clear. The Goals route stays a placeholder until P26.3. UI VISIBLE:NO. P26.2 (progress projection) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate497

{label}

Gate497/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P25 is SYSTEM CLOSED through P25.3 and P26 is defined from research. Gate496 remains its immediate rollback. The next slice (Gate498, P26.1) is the goals preference foundation; P26.2 (progress projection), P26.3 (route) and P26.4 (closure) follow.

"""
arch=f"""## Gate498 P26.1 goals preference foundation amendment

{label}

Gate497/run{RUN}/head{HEAD} is the latest FULL canonical release: the P25 closure. Gate496 is the immediate rollback.

The next slice adds `src/application/goals/goalsPreference.ts` (exported through `src/application/goals/index.ts`) and starts the P26 ledger below at P26.1. P5 metadata persistence, P11/P12/P13 and the shell are unchanged; the Goals route stays a placeholder. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate498' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate497 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate496',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate497 P25 closure and P26 definition amendment',arch)
print('inserted')
