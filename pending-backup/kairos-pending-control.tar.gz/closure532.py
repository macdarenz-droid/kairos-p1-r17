"""Apply the Gate532 (P36.2) ledger edits to work532 (idempotent; run before draft532docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work532/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P36 canonical ownership ledger — ACTIVE through P36\.\d+', '## P36 canonical ownership ledger — ACTIVE through P36.2', s, count=1)
row="| P36.2 | Trade discipline commands | `src/application/discipline/saveTradeDiscipline.ts`, `src/application/discipline/loadTradeDiscipline.ts` (exported through `src/application/discipline/index.ts`); the `tradeDiscipline` line in `src/application/trades/deleteTradeRecord.ts`; `listByTradeId` on `TradeDisciplineRepository` | Owns the guarded save of the one record per trade (refusals by name before any write: nothing to save, checklist, review, mistakes, note; one atomic write over trades and tradeDiscipline re-reading the trade and the existing record, halves replaced by name with their moments stamped, shape-checked before put, created/updated reported; explicit not-found and storage-error), the clone-safe read (null when unanswered), and the P30.1 delete extended so the record leaves with its trade in the same atomic write (`removed.discipline`); no UI, no score, no write to the trade |\n"
if row not in s:
    anchor="| P36.1 | Trade discipline record foundation |"; i=s.index(anchor); j=s.index('\n',i)+1; s=s[:j]+row+s[j:]
open(p,'w').write(s); print('ledger edits applied')
