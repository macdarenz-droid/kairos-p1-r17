"""Insert Gate478 continuity entries into the work478 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST ZIP_SIZE ZIP_SHA (Gate477 evidence + Gate477 zip)"""
import sys
run,job,head,cid,cdig,eid,edig,zsize,zsha=sys.argv[1:10]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work478/kairos_p76/docs/'
label="**Patch label:** P21.27 · roadmap item 5 (exact trade overlays + P18 drawing create/edit/delete + P20 save/load round trips) · owner phase P21 (chart workspace integration, active) · definition: save the drawn lines of the exact Analysis market as one Saved Analysis and load one back onto the chart through the released P20 owners, with real browser evidence and no journal mutation."
ev=f"Gate477/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_ANALYSIS_DRAWING_TOOLS_ENDPOINT_EDIT_CANDIDATE_2026-09-17.zip;{zsize}bytes;SHA256 {zsha}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate476 is the immediate rollback."
approval=f"""## Manual Gate478 slice — 17 September 2026

{label}

{ev}

Under the user's roadmap-first authority, the last item-5 step is the Saved Analysis round trip in KAIROS_ANALYSIS_SAVED_ANALYSIS_ROUND_TRIP.md. `analysisSavedAnalysisRoundTrip.ts` composes the released P20.3 save (one atomic write, fresh id), the released P20.2 repository listing filtered to the exact market and the released P20.4 load-one-by-id; drawings are the only content and `riskRewards` stays empty because saved-trade overlays remain derived from the journal (no duplication of journal truth; recorded as a decision for the user's item-6 review). The Gate475 session gains `loadDrawings` composed from the released P18.33 collection mutations (stable ids kept, interaction reset, re-presented on the bound series); the Gate476 hook passes it through; the "Saved analysis" controls (Save analysis, Saved analyses select, Load analysis, polite exact message) mount once after the drawing tools with injectable ports and the released default. UI VISIBLE:YES. Real Chromium evidence (`scripts/test-analysis-saved-analysis-browser.mjs`, `.saved-analysis-evidence/`, real IndexedDB) proves one exact record per save, load back to the same pane pixels after deletion with nothing written, survival across a full reload and a re-selection, per-market listing, re-presentation on the saved-trade chart, byte-identical journal trades/plans/executions/fees, Ink/Paper at 320/390px. With this slice roadmap item 5 is complete; item 6 (P21 review/closure with the user's review, then P22 defined from ownership) follows. Candidate publication and complete canonical PASS remain mandatory; P21 stays active.

"""
plan=f"""## Status after FULL Gate477

{label}

Gate477/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present; a selected trend-line endpoint moves through the released P18.58/P18.59 lifecycle with real browser evidence. Gate476 remains its immediate rollback. The next slice (Gate478, P21.27) closes item 5 with the Saved Analysis save/load round trip over the released P20 owners; item 6 (P21 review/closure with the user's review, then P22 from ownership) follows. P21 stays active.

"""
arch=f"""## Gate478 Analysis Saved Analysis round trip amendment

{label}

Gate477/run{run}/head{head} is the latest FULL canonical release: endpoint edit in the Analysis drawing-tools session and toolbar. Gate476 is the immediate rollback.

The next slice adds `src/app/analysisSavedAnalysisRoundTrip.ts` (market reference from the exact selection; save/list/load ports over P20.3, the P20.2 repository listing and P20.4; drawings only, `riskRewards` empty by decision), `loadDrawings` on the Gate475 session (released P18.33 mutations, interaction reset, re-present), the hook passthrough, `src/app/AnalysisSavedAnalysisControls.tsx`, the workspace's injectable `savedAnalysis` ports and one controls mount, and a route-scoped token-only CSS block before the Gate476 block. `analysisCandleRendererSession.ts`, the canvases, the overlay owners, the P20 owners and every data owner are unchanged. UI VISIBLE:YES. No product-domain, provider, persistence, journal or calculation owner changes; P17/P18/P19/P20 boundaries and P21 active status are unchanged; roadmap item 5 is complete.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate478' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate477 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate476',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate477 Analysis drawing tools endpoint edit amendment',arch)
print('inserted')
