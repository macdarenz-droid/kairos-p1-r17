"""Insert Gate499 continuity entries into the work499 docs. Reads Gate498 evidence from gate498-evidence.txt, zip498.txt and head498.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate498-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip498.txt').read().split()
HEAD=open(sp+'head498.txt').read().strip()
root=sp+'work499/kairos_p76/docs/'
label="**Patch label:** P26.2 · P26 Goals foundation · owner phase P26 (active from the Gate497 canonical PASS) · definition: the read-only projection of the stored goals against the released journal truth, and its bounded composition query."
ev=f"Gate498/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P26_1_GOALS_PREFERENCE_FOUNDATION_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate497 is the immediate rollback. P26.1 is canonical."
approval=f"""## Manual Gate499 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: calendar days come only from the P13.6 day-key contract in the explicit P13.10R1 time zone; money is summed only by the decimal kernel over the P13.7 daily summaries with incomparable days disclosed; counts run over the bounded P12 history and disclose the bound. P26.2 adds `projectGoalsProgress` (closed trades this month, trades opened today with the remaining allowance, the monthly result with current, remaining and reached, or explicit unavailable reasons) and `loadGoalsProgress` (goals and time-zone preferences, bounded history, projection). The Goals route stays a placeholder until P26.3. UI VISIBLE:NO. P26.3 (the Goals route) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate498

{label}

Gate498/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P26.1 (goals preference) is canonical. Gate497 remains its immediate rollback. The next slice (Gate499, P26.2) is the progress projection; P26.3 (route) and P26.4 (closure) follow.

"""
arch=f"""## Gate499 P26.2 goals progress projection amendment

{label}

Gate498/run{RUN}/head{HEAD} is the latest FULL canonical release: the P26.1 goals preference. Gate497 is the immediate rollback.

The next slice adds `src/application/goals/goalsProgress.ts` and `src/application/goals/loadGoalsProgress.ts` (exported through the goals index) and advances the P26 ledger below to P26.2. P12, P13, the decimal kernel and the shell are unchanged; the Goals route stays a placeholder. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate499' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate498 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate497',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate498 P26.1 goals preference foundation amendment',arch)
print('inserted')
