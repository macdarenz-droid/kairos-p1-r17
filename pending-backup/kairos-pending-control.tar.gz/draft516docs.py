"""Insert Gate516 continuity entries into the work516 docs. Reads Gate515 evidence from gate515-evidence.txt, zip515.txt and head515.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate515-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip515.txt').read().split()
HEAD=open(sp+'head515.txt').read().strip()
root=sp+'work516/kairos_p76/docs/'
label="**Patch label:** P31.1 · P31 Trade record lifecycle: draft activation · owner phase P31 (active from the Gate515 canonical PASS) · definition: the application command that moves one saved manual draft to open with its opened moment and optional first fills, fees and price currency in one atomic write, keeping its id and plan."
ev=f"Gate515/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P30_3_TRADE_RECORD_LIFECYCLE_CLOSURE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate514 is the immediate rollback. P30 is SYSTEM CLOSED through P30.3."
approval=f"""## Manual Gate516 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the P10.1 preparation already validates an open trade with its opened moment, fills, fees and currency, and the P10.4 open-trade update already fixed the guarded-write pattern (re-read in the transaction, header-plus-children revision, id-collision rejection, append only). P31.1 adds `src/application/trades/openDraftTrade.ts`: one saved manual draft moved to open with the same preparation and guards, id and plan kept, explicit conflict, validation and storage outcomes; practice drafts and open trades are refused. The Gate515 verifier pin that asserted no activation command existed advanced to the command literal; the history card carries no control until P31.2. UI VISIBLE:NO. P31.2 (activation control) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate515

{label}

Gate515/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P30 is SYSTEM CLOSED through P30.3 and P31 is defined from research. Gate514 remains its immediate rollback. The next slice (Gate516, P31.1) is the draft activation command; P31.2 (activation control) and P31.3 (closure) follow.

"""
arch=f"""## Gate516 P31.1 draft trade activation command amendment

{label}

Gate515/run{RUN}/head{HEAD} is the latest FULL canonical release: the P30 closure. Gate514 is the immediate rollback.

The next slice adds `src/application/trades/openDraftTrade.ts` (exported through `src/application/trades/index.ts`) and starts the P31 ledger below at P31.1. P10, P12, the shell and every route are unchanged; the history card carries no activation control yet. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate516' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate515 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate514',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate515 P30 closure and P31 definition amendment',arch)
print('inserted')
