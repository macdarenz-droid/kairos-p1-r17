"""Apply the Gate515 (P30.3) closure ledger/plan edits to work515 (idempotent; run before draft515docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work515/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P30 canonical ownership ledger — ACTIVE through P30\.\d+', '## P30 canonical ownership ledger — SYSTEM CLOSED through P30.3', s, count=1)
row="| P30.3 | Trade record lifecycle system closure | verification/docs/package boundary only; no production runtime owner added | Proves P30.1–P30.2 as the complete source-proven P30 boundary and defines P31 from ownership |\n"
anchor="every released mount line keeps its literals; no bulk delete, no undo, no delete of saved records |\n"
if row not in s:
    assert s.count(anchor)==1; s=s.replace(anchor, anchor+row, 1)
section="""## P30 Trade Record Lifecycle System Closure — P30.3

P30.3 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P30.1 trade record delete command and the P30.2 confirmed delete controls on the Journal and Practice history cards are mounted and retained with their verifiers; the closure report is `KAIROS_P30_3_TRADE_RECORD_LIFECYCLE_CLOSURE_REPORT_2026-09-18.md` and its verifier `scripts/verify-p30-3-trade-record-lifecycle-closure.mjs`. A delete removes exactly one confirmed trade with its own plans, executions and fees, never a saved record or a backup; every released mount line keeps its literals.

## P31 — Trade record lifecycle: draft activation (defined from ownership, not begun)

Research against current source: `src/domain/trades/tradeValidation.ts` defines a draft trade as one with no opened or closed time, `src/application/trades/updateOpenManualTrade.ts` refuses any trade that is not open and manual (`trade-not-open-manual`), and no command or control turns a saved draft into an open trade: a user who logged a plan as a draft must delete it (P30) and re-enter it to record the first fill. P31 gives draft trades their forward step in dependency order: P31.1 an activation command over the released P10 preparation and the P10.4 conflict-revision pattern that moves one saved manual draft to open with its opened moment and optional first fills, fees and price currency in one atomic write, keeping the trade id and plan, with explicit conflict, validation and storage outcomes; P31.2 the control on the draft history card (Open this trade → the released execution, fee and currency fields → Save) with plain-word outcomes and the released refresh path, proven in unit tests and a real browser; P31.3 the closure. Proven from ownership: P10 owns the draft contract, preparation and the open-trade update; P12 the history card; P5 the database; the only new owners are the command and the control. Practice drafts stay recorded only (P29 non-scope). P31 may not begin before that PASS (the Gate515 canonical PASS of P30.3).

"""
if '## P30 Trade Record Lifecycle System Closure — P30.3' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert s.count(anchor2)==1; s=s.replace(anchor2, section+anchor2, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Updated at Gate513: P30 ACTIVE (Trade record lifecycle: delete) from the Gate512 canonical PASS."
add=" Updated at Gate515: P17–P30 closed; P31 defined (Trade record lifecycle: draft activation), not begun; P32–P40 later."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
