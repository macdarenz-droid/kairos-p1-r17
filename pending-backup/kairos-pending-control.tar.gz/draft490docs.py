"""Insert Gate490 continuity entries into the work490 docs. Reads Gate489 evidence from gate489-evidence.txt (RUN JOB ART_CAND ART_CAND_SHA ART_EV ART_EV_SHA MAINRUN), zip489.txt (SIZE SHA) and head489.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate489-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip489.txt').read().split()
HEAD=open(sp+'head489.txt').read().strip()
root=sp+'work490/kairos_p76/docs/'
label="**Patch label:** P23.5 · P23 durable time-assisted snapshot provenance · owner phase P23 (active from the Gate485 canonical PASS) · definition: the visible save/list/load of a shown time-assisted estimate on the Analysis page, through the released P23.3 save and P23.4 read commands, with real browser evidence."
ev=f"Gate489/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P23_4_SAVED_TIME_ASSISTED_SNAPSHOT_APPLICATION_READ_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate488 is the immediate rollback. P23.4 is canonical."
approval=f"""## Manual Gate490 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 decision ("1": proceed with P23 under the same gate discipline). P23.5 makes P23 visible: `src/app/analysisSavedTimeAssistedSnapshotRoundTrip.ts` composes the released P23.3 save and P23.4 list/load for the exact selected market, and the Gate482 preview gains a "Saved snapshot" group (Save snapshot, Saved snapshots list, Load snapshot). Saving records the entered instants, their UTC normalisation, the device time zone, the estimates with their provenance and the save moment; loading restores the inputs, shows the saved estimates, publishes them to the released chart markers and states "estimates as acquired then, not re-estimated". The section copy now reads "nothing is saved until you save a snapshot"; the Gate482 verifier's pin advanced to that literal (never relaxed). The workspace mount is unchanged. Real browser evidence (`scripts/test-analysis-time-assisted-snapshot-saved-browser.mjs`, `.time-assisted-saved-evidence/`) proves the exact stored record, the no-request load with restored inputs and markers, persistence across a reload, per-market listing and an untouched journal. UI VISIBLE:YES (autonomous continuation; the user's physical UI inspection remains deferred to the whole-app checkpoint). No update/delete, no re-estimation, no journal write; P23.6 (closure) may not begin before this PASS. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate489

{label}

Gate489/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P23.4 (application read boundary) is canonical. Gate488 remains its immediate rollback. The next slice (Gate490, P23.5) mounts save/list/load in the Analysis time-assisted preview with browser evidence; P23.6 (closure) follows.

"""
arch=f"""## Gate490 P23.5 saved time-assisted snapshot preview round trip amendment

{label}

Gate489/run{RUN}/head{HEAD} is the latest FULL canonical release: the P23.4 read boundary. Gate488 is the immediate rollback.

The next slice adds `src/app/analysisSavedTimeAssistedSnapshotRoundTrip.ts`, extends the Gate482 preview with the saved group (route-scoped CSS inside the Gate482 block), adds the unit and real-browser evidence and `docs/KAIROS_ANALYSIS_SAVED_TIME_ASSISTED_SNAPSHOT_ROUND_TRIP.md`, and advances the P23 ledger below to P23.5. The workspace mount, P22, P23.1–P23.4, P20 and the journal owners are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate490' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate489 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate488',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate489 P23.4 saved time-assisted snapshot application read amendment',arch)
print('inserted')
