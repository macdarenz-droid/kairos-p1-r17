"""Insert Gate532 continuity entries into the work532 docs. Reads Gate531 evidence from gate531-evidence.txt, zip531.txt and head531.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate531-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip531.txt').read().split()
HEAD=open(sp+'head531.txt').read().strip()
root=sp+'work532/kairos_p76/docs/'
label="**Patch label:** P36.2 · P36 Discipline foundation: checklists, mistake tracking and discipline score (vision P22, discipline half) · owner phase P36 (active from the Gate530 canonical PASS) · definition: the guarded save and the read of the one discipline record per trade, and the P30.1 delete extended so the record leaves with its trade."
ev=f"Gate531/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P36_1_TRADE_DISCIPLINE_RECORD_FOUNDATION_CANDIDATE_2026-09-20.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate530 is the immediate rollback. P36.1 is canonical: schema v6, backup format V5."
approval=f"""## Manual Gate532 slice — 20 September 2026

{label}

{ev}

P36.2 adds `src/application/discipline/` (`saveTradeDiscipline`: refusals by name before any write, one atomic write over trades and tradeDiscipline, trade re-read, the one existing record kept under its own id, halves replaced by name with their moments stamped, shape-checked before put; `loadTradeDiscipline`: clone-safe, null when unanswered) and extends the P30.1 `deleteTradeRecord` so the discipline record leaves with its trade in the same atomic write (`removed.discipline`). The P30.1 test and verifier pins on the delete's store list and result advanced (`pin advanced at Gate532`); the P35.3 and P36.1 "no P36.2 owner yet" checks advanced to the present owners; nothing relaxed. No UI, no score. UI VISIBLE:NO. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate531

{label}

Gate531/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P36.1 (trade discipline record foundation: schema v6, backup format V5) is canonical. Gate530 remains its immediate rollback. The next slice (Gate532, P36.2) adds the discipline save and read commands and extends the trade delete.

"""
arch=f"""## Gate532 P36.2 trade discipline commands amendment

{label}

Gate531/run{RUN}/head{HEAD} is the latest FULL canonical release: the P36.1 trade discipline record foundation. Gate530 is the immediate rollback.

The next slice adds `src/application/discipline/saveTradeDiscipline.ts` and `loadTradeDiscipline.ts` (with their index), extends `src/application/trades/deleteTradeRecord.ts` by the `tradeDiscipline` line and advances the P36 ledger below to P36.2. P30.1 keeps the delete, P36.1 the record and store; every route, control and projection is unchanged. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate532' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate531 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate530',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate531 P36.1 trade discipline record foundation amendment',arch)
print('inserted')
