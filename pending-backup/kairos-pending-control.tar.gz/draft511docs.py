"""Insert Gate511 continuity entries into the work511 docs. Reads Gate510 evidence from gate510-evidence.txt, zip510.txt and head510.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate510-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip510.txt').read().split()
HEAD=open(sp+'head510.txt').read().strip()
root=sp+'work511/kairos_p76/docs/'
label="**Patch label:** P29.3 · P29 Practice foundation: paper trades · owner phase P29 (active from the Gate508 canonical PASS) · definition: the Practice page replacing the More-tab placeholder, with the practice trade form over the P29.1 command and the practice history over the P29.2 scope, proven in unit tests and a real browser."
ev=f"Gate510/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P29_2_REAL_RESULT_ISOLATION_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate509 is the immediate rollback. P29.2 is canonical."
approval=f"""## Manual Gate511 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: the Journal form's mount lines are pinned by the P10 verifiers, so the Practice page reuses the released draft contract, the released currency, execution and guidance components and the released history list in its own route file rather than modifying or extracting the Journal; the Journal stylesheet applies through the shared `kairos-journal` class plus a two-rule practice tint; and because the released open-trade update accepts manual trades only, practice trades are recorded, listed and reviewable, never edited. P29.3 replaces the `/practice` placeholder with `src/app/PracticeRoute.tsx`; the six verifier pins on the Practice placeholder advanced to the route line and no placeholder remains under More. Real browser evidence (`scripts/test-practice-route-browser.mjs`, `.practice-route-evidence/`) proves a real Journal trade as the control, More → Practice, a refused incomplete practice trade with nothing written, a closed practice trade recorded as `paper` with the real trade byte-identical, the Journal history and Home keeping only the real trade, and both viewports in both themes. UI VISIBLE:YES. P29.4 (closure) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate510

{label}

Gate510/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P29.2 (real-result isolation) is canonical. Gate509 remains its immediate rollback. The next slice (Gate511, P29.3) mounts the Practice route with browser evidence; P29.4 (closure) follows.

"""
arch=f"""## Gate511 P29.3 Practice route amendment

{label}

Gate510/run{RUN}/head{HEAD} is the latest FULL canonical release: the P29.2 real-result isolation. Gate509 is the immediate rollback.

The next slice adds `src/app/PracticeRoute.tsx` and `src/app/practiceRoute.css`, wires `/practice` to the route in `src/app/routes.tsx`, adds the unit and real-browser evidence and `docs/KAIROS_PRACTICE_ROUTE.md`, and advances the P29 ledger below to P29.3. The Journal route, its stylesheet, every released component and the navigation are unchanged. UI VISIBLE:YES.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate511' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate510 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate509',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate510 P29.2 real-result isolation amendment',arch)
print('inserted')
