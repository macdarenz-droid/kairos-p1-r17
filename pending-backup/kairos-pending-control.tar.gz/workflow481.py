"""Pin Gate481 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate480 zip, prev = Gate479 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — P22.1 Estimated Market Reference Foundation','name: Kairos Controlled Roadmap Gate — P22.2 Time-Assisted Trade Snapshot Composition')
rep("      - 'KAIROS_P22_1_ESTIMATED_MARKET_REFERENCE_FOUNDATION_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_P22_2_TIME_ASSISTED_TRADE_SNAPSHOT_COMPOSITION_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_P21_28_CHART_WORKSPACE_INTEGRATION_CLOSURE_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_P22_1_ESTIMATED_MARKET_REFERENCE_FOUNDATION_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_P22_1_ESTIMATED_MARKET_REFERENCE_FOUNDATION_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_P22_2_TIME_ASSISTED_TRADE_SNAPSHOT_COMPOSITION_CANDIDATE_2026-09-17.zip')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P22.1 estimated market reference foundation scope from Gate479','      - name: Confirm exact P22.2 time-assisted trade snapshot composition scope from Gate480')
rep("""          expected = {
            'KAIROS_P22_1_ESTIMATED_MARKET_REFERENCE_FOUNDATION_REPORT_2026-09-17.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p22-1-estimated-market-reference-foundation.mjs',
            'src/application/market-reference/estimatedMarketReference.ts',
            'src/application/market-reference/index.ts',
            'tests/estimated-market-reference-foundation.test.ts',
          }
          if changed != expected or removed:
            print('P22.1 estimated market reference foundation scope mismatch', file=sys.stderr)""","""          expected = {
            'KAIROS_P22_2_TIME_ASSISTED_TRADE_SNAPSHOT_COMPOSITION_REPORT_2026-09-17.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p22-1-estimated-market-reference-foundation.mjs',
            'scripts/verify-p22-2-time-assisted-trade-snapshot-composition.mjs',
            'src/application/market-reference/index.ts',
            'src/application/market-reference/timeAssistedTradeSnapshot.ts',
            'tests/time-assisted-trade-snapshot.test.ts',
          }
          if changed != expected or removed:
            print('P22.2 time-assisted trade snapshot composition scope mismatch', file=sys.stderr)""")
rep("""            tests/binance-spot-candle-history.test.ts

      - name: Production TypeScript compilation""","""            tests/binance-spot-candle-history.test.ts

      - name: P22.2 time-assisted trade snapshot composition
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p22:2-time-assisted-trade-snapshot-composition
          npm run verify:p22:1-estimated-market-reference-foundation
          npx vitest run \\
            tests/time-assisted-trade-snapshot.test.ts \\
            tests/estimated-market-reference-foundation.test.ts

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:p22:1-estimated-market-reference-foundation',""","""          for (const required of [
            'verify:p22:2-time-assisted-trade-snapshot-composition',
            'verify:p22:1-estimated-market-reference-foundation',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P22_1_ESTIMATED_MARKET_REFERENCE_FOUNDATION_REPORT_2026-09-17.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P22_2_TIME_ASSISTED_TRADE_SNAPSHOT_COMPOSITION_REPORT_2026-09-17.md
            .gate-candidate/kairos_p76/KAIROS_P22_1_ESTIMATED_MARKET_REFERENCE_FOUNDATION_REPORT_2026-09-17.md""")
open(p,'w').write(s); print('workflow pinned for Gate481')
