"""Pin Gate479 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate478 zip, prev = Gate477 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — Analysis Saved Analysis Round Trip','name: Kairos Controlled Roadmap Gate — P21 Chart Workspace Integration Closure')
rep("      - 'KAIROS_ANALYSIS_SAVED_ANALYSIS_ROUND_TRIP_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_P21_28_CHART_WORKSPACE_INTEGRATION_CLOSURE_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_ANALYSIS_DRAWING_TOOLS_ENDPOINT_EDIT_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_SAVED_ANALYSIS_ROUND_TRIP_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_ANALYSIS_SAVED_ANALYSIS_ROUND_TRIP_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_P21_28_CHART_WORKSPACE_INTEGRATION_CLOSURE_CANDIDATE_2026-09-17.zip')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact Analysis Saved Analysis round trip scope from Gate477','      - name: Confirm exact P21 closure scope from Gate478')
rep("""          expected = {
            'docs/KAIROS_ANALYSIS_SAVED_ANALYSIS_ROUND_TRIP.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/test-analysis-drawing-tools-browser.mjs',
            'scripts/test-analysis-drawing-tools-edit-browser.mjs',
            'scripts/test-analysis-saved-analysis-browser.mjs',
            'scripts/verify-analysis-saved-analysis-round-trip.mjs',
            'src/app/AnalysisHistoryWorkspace.tsx',
            'src/app/AnalysisSavedAnalysisControls.tsx',
            'src/app/analysisDrawingToolsRendererSession.ts',
            'src/app/analysisHistory.css',
            'src/app/analysisSavedAnalysisRoundTrip.ts',
            'src/app/useAnalysisDrawingTools.ts',
            'tests/analysis-drawing-tools-renderer-session.test.ts',
            'tests/analysis-saved-analysis-round-trip.test.tsx',
          }
          if changed != expected or removed:
            print('Analysis Saved Analysis round trip scope mismatch', file=sys.stderr)""","""          expected = {
            'KAIROS_P21_28_CHART_WORKSPACE_INTEGRATION_CLOSURE_REPORT_2026-09-17.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p21-28-chart-workspace-integration-closure.mjs',
          }
          if changed != expected or removed:
            print('P21 closure scope mismatch', file=sys.stderr)""")
rep("""            tests/saved-analysis-save-command.test.ts

      - name: Production TypeScript compilation""","""            tests/saved-analysis-save-command.test.ts

      - name: P21 chart workspace integration system closure
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p21:28-chart-workspace-integration-closure
          npm run verify:p20:5-saved-analysis-system-closure
          npm run verify:p19:7-risk-reward-tool-system-closure
          npm run verify:p18:60-drawing-tools-system-closure
          npm run verify:analysis-saved-analysis-round-trip
          npm run verify:analysis-drawing-tools-endpoint-edit
          npm run verify:analysis-drawing-tools-mount
          npm run verify:analysis-history-workspace
          npm run verify:analysis-saved-trade-position-box

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:analysis-saved-analysis-round-trip',""","""          for (const required of [
            'verify:p21:28-chart-workspace-integration-closure',
            'verify:analysis-saved-analysis-round-trip',""")
rep("""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_SAVED_ANALYSIS_ROUND_TRIP.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P21_28_CHART_WORKSPACE_INTEGRATION_CLOSURE_REPORT_2026-09-17.md
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_SAVED_ANALYSIS_ROUND_TRIP.md""")
open(p,'w').write(s); print('workflow pinned for Gate479')
