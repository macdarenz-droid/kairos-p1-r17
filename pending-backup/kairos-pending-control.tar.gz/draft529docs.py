"""Insert Gate529 continuity entries into the work529 docs. Reads Gate528 evidence from gate528-evidence.txt, zip528.txt and head528.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate528-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip528.txt').read().split()
HEAD=open(sp+'head528.txt').read().strip()
root=sp+'work529/kairos_p76/docs/'
label="**Patch label:** P35.2 · P35 Practice trade lifecycle: fills, close and activation for paper trades · owner phase P35 (active from the Gate527 canonical PASS) · definition: the released P10.4 update and P31.1 activation controls mounted on the Practice history card scoped to `['paper']` through the P35.1 option, proven in unit tests."
ev=f"Gate528/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P35_1_PRACTICE_TRADE_LIFECYCLE_SOURCE_OPTION_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate527 is the immediate rollback. P35.1 is canonical."
approval=f"""## Manual Gate529 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. Research settled the design: `JournalHistoryList` already exposes optional ports mounted only when passed, so Practice gains `onTradeUpdated`/`onTradeOpened` the same way it already has `onTradeDeleted`; both released controls already own their whole panel, so P35.2 threads one `allowedSources` prop through them and the list, touching no other line. Six frozen verifier pins that named the exact pre-existing JSX mount literals or the hard-coded `'manual'` guard strings advanced to the new literals in this same slice, documented in the report; the `tests/journal-draft-trade-activation.test.tsx` case describing "never offers activation on the Practice page" was rewritten to describe the intended behaviour, with every other released test in the affected suites passing unchanged. A saved practice draft can now open and an open practice trade can now take a fill or close, through the exact released controls and commands; the Journal keeps its default manual-only scope. UI VISIBLE:NO (existing controls, no new visible element). P35.3 (closure) follows without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate528

{label}

Gate528/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P35.1 (allowed-source option) is canonical. Gate527 remains its immediate rollback. The next slice (Gate529, P35.2) mounts the released controls on Practice; P35.3 (closure) follows.

"""
arch=f"""## Gate529 P35.2 Practice route lifecycle controls amendment

{label}

Gate528/run{RUN}/head{HEAD} is the latest FULL canonical release: the P35.1 allowed-source option. Gate527 is the immediate rollback.

The next slice threads `allowedSources` through `src/app/JournalHistoryList.tsx`, `src/app/JournalOpenTradeUpdate.tsx` and `src/app/JournalDraftTradeActivation.tsx`, mounts both controls on `src/app/PracticeRoute.tsx` scoped to `['paper']`, and advances the P35 ledger below to P35.2. The Journal keeps its default manual-only scope; no new command and no schema change. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate529' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate528 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate527',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate528 P35.1 allowed-source option amendment',arch)
print('inserted')
