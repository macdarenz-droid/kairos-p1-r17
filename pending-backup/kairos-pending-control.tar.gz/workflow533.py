"""Pin Gate533 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate532 zip, prev = Gate531 zip). Expected scope read from scope533.txt."""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
scope=sorted(l.strip() for l in open(sp+'scope533.txt') if l.strip())
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P36_3_TRADE_DISCIPLINE_CONTROLS_CANDIDATE_2026-09-20.zip'
BASE='KAIROS_P36_2_TRADE_DISCIPLINE_COMMANDS_CANDIDATE_2026-09-20.zip'
PREV='KAIROS_P36_1_TRADE_DISCIPLINE_RECORD_FOUNDATION_CANDIDATE_2026-09-20.zip'
rep('name: Kairos Controlled Roadmap Gate — P36.2 Trade Discipline Commands','name: Kairos Controlled Roadmap Gate — P36.3 Trade Discipline Controls')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P36.2 trade discipline commands scope from Gate531','      - name: Confirm exact P36.3 trade discipline controls scope from Gate532')
start=s.index("          expected = {\n            'KAIROS_P36_2_TRADE_DISCIPLINE_COMMANDS_REPORT_2026-09-20.md',")
end=s.index("            print('P36.2 trade discipline commands scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
body=''.join(f"            '{f}',\n" for f in scope)
s=s[:start]+"          expected = {\n"+body+"""          }
          if changed != expected or removed:
            print('P36.3 trade discipline controls scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P36.2 trade discipline commands\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P36.3 trade discipline controls
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p36:3-trade-discipline-controls
          npm run verify:p36:2-trade-discipline-commands
          npm run verify:p36:1-trade-discipline-record-foundation
          npm run verify:p29:3-practice-route
          npm run verify:p35:2-practice-route-lifecycle-controls
          npm run verify:p31:2-draft-trade-activation-control
          npm run verify:p30:2-trade-delete-controls
          npx vitest run \\
            tests/journal-trade-discipline-control.test.tsx \\
            tests/trade-discipline-commands.test.ts \\
            tests/journal-draft-trade-activation.test.tsx \\
            tests/journal-trade-delete-control.test.tsx

"""+s[end:]
rep("""          for (const required of [
            'verify:p36:2-trade-discipline-commands',""","""          for (const required of [
            'verify:p36:3-trade-discipline-controls',
            'verify:p36:2-trade-discipline-commands',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P36_2_TRADE_DISCIPLINE_COMMANDS_REPORT_2026-09-20.md
            .gate-candidate/kairos_p76/KAIROS_P36_1_TRADE_DISCIPLINE_RECORD_FOUNDATION_REPORT_2026-09-20.md
""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P36_3_TRADE_DISCIPLINE_CONTROLS_REPORT_2026-09-20.md
            .gate-candidate/kairos_p76/KAIROS_P36_2_TRADE_DISCIPLINE_COMMANDS_REPORT_2026-09-20.md
""")
rep("          node scripts/test-profile-data-safety-browser.mjs\n","          node scripts/test-profile-data-safety-browser.mjs\n          node scripts/test-journal-trade-discipline-browser.mjs\n")
open(p,'w').write(s); print('workflow pinned for Gate533')
