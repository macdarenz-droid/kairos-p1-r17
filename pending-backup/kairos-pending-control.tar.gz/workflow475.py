"""Pin Gate475 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA"""
import sys
size,sha,bsize,bsha=sys.argv[1:5]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
rep('name: Kairos Controlled Roadmap Gate — Production Drawing-Binding Seam','name: Kairos Controlled Roadmap Gate — Analysis Drawing-Tools Session')
rep("      - 'KAIROS_LIGHTWEIGHT_CHARTS_V5_PRODUCTION_DRAWING_BINDING_SEAM_CANDIDATE_2026-09-17.zip'\n","      - 'KAIROS_ANALYSIS_DRAWING_TOOLS_RENDERER_SESSION_CANDIDATE_2026-09-17.zip'\n")
rep('  BASE_ZIP: KAIROS_ANALYSIS_SAVED_TRADE_POSITION_BOX_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_LIGHTWEIGHT_CHARTS_V5_PRODUCTION_DRAWING_BINDING_SEAM_CANDIDATE_2026-09-17.zip','  BASE_ZIP: KAIROS_LIGHTWEIGHT_CHARTS_V5_PRODUCTION_DRAWING_BINDING_SEAM_CANDIDATE_2026-09-17.zip\n  CANDIDATE_ZIP: KAIROS_ANALYSIS_DRAWING_TOOLS_RENDERER_SESSION_CANDIDATE_2026-09-17.zip')
rep(f"            ('BASE_ZIP', 3913657, '2da5ddccf149ddee5fbe2482ff4e74ab2cf6c68eab528b091a5c722b4b65bfe0'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact production drawing-binding seam scope from Gate473','      - name: Confirm exact Analysis drawing-tools session scope from Gate474')
rep("""          expected = {
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'docs/KAIROS_LIGHTWEIGHT_CHARTS_V5_PRODUCTION_DRAWING_BINDING_SEAM.md',
            'package.json',
            'scripts/verify-lightweight-charts-v5-production-drawing-binding-seam.mjs',
            'src/features/chart/lightweightChartsV5ProductionRenderer.ts',
            'tests/lightweight-charts-v5-production-drawing-binding-seam.test.ts',
          }
          if changed != expected or removed:
            print('Production drawing-binding seam scope mismatch', file=sys.stderr)""","""          expected = {
            'docs/KAIROS_ANALYSIS_DRAWING_TOOLS_RENDERER_SESSION.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-analysis-drawing-tools-renderer-session.mjs',
            'src/app/analysisDrawingToolsRendererSession.ts',
            'tests/analysis-drawing-tools-renderer-session.test.ts',
          }
          if changed != expected or removed:
            print('Analysis drawing-tools session scope mismatch', file=sys.stderr)""")
rep("""            tests/analysis-saved-trade-position-box.test.tsx

      - name: Production TypeScript compilation""","""            tests/analysis-saved-trade-position-box.test.tsx

      - name: Analysis drawing-tools renderer session
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:analysis-drawing-tools-renderer-session
          npm run verify:lightweight-charts-v5-production-drawing-binding-seam
          npm run verify:p18:60-drawing-tools-system-closure
          npx vitest run \\
            tests/analysis-drawing-tools-renderer-session.test.ts \\
            tests/lightweight-charts-v5-production-drawing-binding-seam.test.ts \\
            tests/chart-trend-line-commit-collection-coordination.test.ts \\
            tests/chart-drawing-deletion-presentation-coordination.test.ts

      - name: Production TypeScript compilation""")
rep("""          for (const required of [
            'verify:lightweight-charts-v5-production-drawing-binding-seam',""","""          for (const required of [
            'verify:analysis-drawing-tools-renderer-session',
            'verify:lightweight-charts-v5-production-drawing-binding-seam',""")
rep("""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_LIGHTWEIGHT_CHARTS_V5_PRODUCTION_DRAWING_BINDING_SEAM.md""","""          path: |
            .gate-candidate/kairos_p76/docs/KAIROS_ANALYSIS_DRAWING_TOOLS_RENDERER_SESSION.md
            .gate-candidate/kairos_p76/docs/KAIROS_LIGHTWEIGHT_CHARTS_V5_PRODUCTION_DRAWING_BINDING_SEAM.md""")
open(p,'w').write(s); print('workflow pinned for Gate475')
