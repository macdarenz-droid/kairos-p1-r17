"""Insert Gate474 (drawing-binding seam) continuity entries into the work474 docs. Usage: RUN JOB HEAD CAND_ID CAND_DIGEST EVID_ID EVID_DIGEST"""
import sys
run,job,head,cid,cdig,eid,edig=sys.argv[1:8]
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work474/kairos_p76/docs/'
ev=f"Gate473/run{run}/job{job}/head{head} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser (including the new position box evidence), TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{cid} (GitHub digest sha256:{cdig}) and KAIROS_GATE_EVIDENCE{eid} (GitHub digest sha256:{edig}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_ANALYSIS_SAVED_TRADE_POSITION_BOX_CANDIDATE_2026-09-17.zip;3913657bytes;SHA256 2da5ddccf149ddee5fbe2482ff4e74ab2cf6c68eab528b091a5c722b4b65bfe0; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run. Gate472 is the immediate rollback."
approval=f"""## Manual Gate474 slice — 17 September 2026

User instruction, 17 September 2026: finish the roadmap first and revisit the UI once the whole app is established; follow the roadmap and rules, no guessing. Further Ink presentation amendments (journal rows and filter chips, the log-trade sheet, Your Trades result amounts, drag-to-plan edges, the motion/loading contract) are parked as recorded intent only; a locally verified journal rows CSS draft is retained outside the chain and is not a candidate. The chain continues with KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md item 5: P18 drawing create/edit/delete and P20 save/load on the live chart, then item 6 (P21 review and closure with user review, then P22 proven from ownership).

{ev}

Under that authority, the next smallest dependency-safe item-5 prerequisite is the production drawing-binding seam in KAIROS_LIGHTWEIGHT_CHARTS_V5_PRODUCTION_DRAWING_BINDING_SEAM.md. Source inspection proves every released P18 provider composition resolves the vendor chart and series only through the P18.9/P18.16 driver binding plus the neutral candlestick series handle, while the P17 production renderer discarded that binding and handed its chart lookup a wrapper without the vendor click/crosshair subscriptions. The renderer now creates the released binding once, still feeds the engine port only the neutral driver, reports the binding and the exact candlestick handle to one optional drawing-binding lifecycle (attached after the series exists, detached before removal, replacement or chart removal, never for price-line series), and forwards exactly `subscribeClick`, `unsubscribeClick`, `subscribeCrosshairMove` and `unsubscribeCrosshairMove` from the vendor chart, failing closed if one is missing. Without that lifecycle the behaviour is byte-for-byte the released behaviour. UI VISIBLE:NO. It adds no drawing truth, layer, interaction, persistence, calculation, provider or navigation owner and no execution, venue, FX or P&L inference. The unmounted Analysis drawing composition and the visible trend-line tool follow one gate each. Candidate publication and complete canonical PASS remain mandatory; P21 stays active.

"""
plan=f"""## Status after FULL Gate473

Gate473/run{run}/head{head} is FULL canonical PASS with every stage and both exact-run artifacts present; a saved trade with a full plan now shows the position box beside the live chart. Gate472 remains its immediate rollback. Per the user's 17 September instruction the remaining Ink presentation amendments are parked; the chain returns to item 5's P18 drawing integration and P20 save/load. The next slice is the production drawing-binding seam (Gate474); the unmounted Analysis drawing composition, the visible trend-line tool with edit/delete evidence, and the Saved Analysis round trip follow one gate each, then item 6. P21 stays active.

"""
arch=f"""## Gate474 production drawing-binding seam amendment

Gate473/run{run}/head{head} is the latest FULL canonical release: `AnalysisSavedTradeRiskRewardEvidencePresentation` is the position box and the overlay canvas retains the latest rendered candle per selection. Gate472 is the immediate rollback.

The next bounded non-UI slice amends only `src/features/chart/lightweightChartsV5ProductionRenderer.ts`: the factory creates the released `createLightweightChartsV5DriverBinding` once, feeds the engine port the neutral driver (wrapped only when an optional `LightweightChartsV5ProductionDrawingBindingLifecycle` is supplied) and forwards the four vendor chart event subscriptions the released P18 compositions call. P18.9/P18.16 remain the identity owners; P18 layer, interaction, collection and presentation ports remain uncomposed; `analysisCandleRendererSession.ts`, the overlay owners and every data owner are unchanged. UI VISIBLE:NO. No product-domain, provider, persistence, journal or calculation owner changes; P14/P17/P18/P19/P20 boundaries and P21 active status are unchanged.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate474' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate473 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate472',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate473 saved-trade position box amendment',arch)
print('inserted')
