"""Pin Gate518 in the repo workflow. Usage: SIZE SHA BASE_SIZE BASE_SHA PREV_BASE_SIZE PREV_BASE_SHA (base = Gate517 zip, prev = Gate516 zip)"""
import sys
size,sha,bsize,bsha,psize,psha=sys.argv[1:7]
p='/home/user/kairos-p1-r17/.github/workflows/kairos-gate.yml'; s=open(p).read()
def rep(old,new):
    global s; assert s.count(old)==1, old; s=s.replace(old,new)
NEW='KAIROS_P31_3_DRAFT_ACTIVATION_CLOSURE_CANDIDATE_2026-09-18.zip'
BASE='KAIROS_P31_2_DRAFT_TRADE_ACTIVATION_CONTROL_CANDIDATE_2026-09-18.zip'
PREV='KAIROS_P31_1_DRAFT_TRADE_ACTIVATION_COMMAND_CANDIDATE_2026-09-18.zip'
rep('name: Kairos Controlled Roadmap Gate — P31.2 Draft Trade Activation Control','name: Kairos Controlled Roadmap Gate — P31.3 Draft Activation Closure')
rep(f"      - '{BASE}'\n",f"      - '{NEW}'\n")
rep(f'  BASE_ZIP: {PREV}\n  CANDIDATE_ZIP: {BASE}',f'  BASE_ZIP: {BASE}\n  CANDIDATE_ZIP: {NEW}')
rep(f"            ('BASE_ZIP', {psize}, '{psha}'),\n            ('CANDIDATE_ZIP', {bsize}, '{bsha}'),",f"            ('BASE_ZIP', {bsize}, '{bsha}'),\n            ('CANDIDATE_ZIP', {size}, '{sha}'),")
rep('      - name: Confirm exact P31.2 draft trade activation control scope from Gate516','      - name: Confirm exact P31.3 closure scope from Gate517')
start=s.index("          expected = {\n            'KAIROS_P31_2_DRAFT_TRADE_ACTIVATION_CONTROL_REPORT_2026-09-18.md',")
end=s.index("            print('P31.2 draft trade activation control scope mismatch', file=sys.stderr)")
end=s.index('\n',end)+1
s=s[:start]+"""          expected = {
            'KAIROS_P31_3_DRAFT_ACTIVATION_CLOSURE_REPORT_2026-09-18.md',
            'docs/KAIROS_ARCHITECTURE_MAP.md',
            'docs/KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md',
            'docs/KAIROS_CONTINUATION_APPROVAL_CONTROL.md',
            'package.json',
            'scripts/verify-p31-2-draft-trade-activation-control.mjs',
            'scripts/verify-p31-3-draft-activation-closure.mjs',
          }
          if changed != expected or removed:
            print('P31.3 closure scope mismatch', file=sys.stderr)
"""+s[end:]
start=s.index("      - name: P31.2 draft trade activation control\n")
end=s.index("      - name: Production TypeScript compilation",start)
s=s[:start]+"""      - name: P31.3 draft activation closure
        working-directory: .gate-candidate/kairos_p76
        run: |
          npm run verify:p31:3-draft-activation-closure
          npm run verify:p31:2-draft-trade-activation-control
          npm run verify:p31:1-draft-trade-activation-command
          npx vitest run \\
            tests/journal-draft-trade-activation.test.tsx \\
            tests/draft-trade-activation-command.test.ts

"""+s[end:]
rep("""          for (const required of [
            'verify:p31:2-draft-trade-activation-control',""","""          for (const required of [
            'verify:p31:3-draft-activation-closure',
            'verify:p31:2-draft-trade-activation-control',""")
rep("""          path: |
            .gate-candidate/kairos_p76/KAIROS_P31_2_DRAFT_TRADE_ACTIVATION_CONTROL_REPORT_2026-09-18.md""","""          path: |
            .gate-candidate/kairos_p76/KAIROS_P31_3_DRAFT_ACTIVATION_CLOSURE_REPORT_2026-09-18.md
            .gate-candidate/kairos_p76/KAIROS_P31_2_DRAFT_TRADE_ACTIVATION_CONTROL_REPORT_2026-09-18.md""")
open(p,'w').write(s); print('workflow pinned for Gate518')
