"""Apply the Gate530 (P35.3) closure ledger/plan edits to work530 (idempotent; run before draft530docs.py)."""
import re
root='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/work530/kairos_p76/docs/'
p=root+'KAIROS_ARCHITECTURE_MAP.md'; s=open(p).read()
s=re.sub(r'## P35 canonical ownership ledger — ACTIVE through P35\.\d+', '## P35 canonical ownership ledger — SYSTEM CLOSED through P35.3', s, count=1)
row="| P35.3 | Practice trade lifecycle system closure and vision realignment | verification/docs/package boundary only; no production runtime owner added | Proves P35.1–P35.2 as the complete source-proven P35 boundary, introduces `docs/KAIROS_VISION_ROADMAP_ALIGNMENT.md` as the canonical roadmap and defines P36 from the vision |\n"
anchor="scope and every released mount line and control literal is otherwise unchanged; no new command, no schema change |\n"
if row not in s:
    assert s.count(anchor)==1; s=s.replace(anchor, anchor+row, 1)
section="""## P35 Practice Trade Lifecycle System Closure — P35.3

P35.3 adds **no production runtime behavior and no new production owner**. It proves, against current source, that the P35.1 allowed-source option and the P35.2 Practice mounts are retained with their verifiers; the closure report is `KAIROS_P35_3_PRACTICE_TRADE_LIFECYCLE_CLOSURE_REPORT_2026-09-20.md` and its verifier `scripts/verify-p35-3-practice-trade-lifecycle-closure.mjs`. A paper trade can now be rehearsed end to end: recorded, opened from a draft, filled, closed with a result in the practice history, deleted; the Journal stays manual-only.

This closure also realigns the roadmap. The user's *Kairos — Vision & Roadmap, September 2026* (40 phases) is the target; built P22–P35 reused its numbers for smaller features. `docs/KAIROS_VISION_ROADMAP_ALIGNMENT.md` is canonical from this gate: it maps each built phase to the vision phase it serves, keeps every built number unchanged (retained verifiers pin them), and fixes the dependency-ordered forward sequence in which every phase from P36 onward is a named vision feature. Closures define the next phase from that sequence, researched against current source.

## P36 — Discipline foundation: checklists, mistake tracking and discipline score (vision P22, discipline half; defined from the vision, not begun)

Research against current source: no file under `src` owns a checklist, a mistake or a discipline score; `TradeRecord` carries no such field and the trade's children are exactly plans, executions and fees, which `deleteTradeRecord` (P30.1) removes in one atomic write; the database is schema V5 with append-only migrations and every schema bump was paired with a backup format bump so a new store is carried by every backup and survives restore and both imports; history reads are source-scoped (P29.2) and day-bucketed by the P13.6 contract in the explicit P13.10R1 time zone; the Home dashboard (P21) is where the vision wants the score at a glance; Goals (built P26) already owns the goals half of vision P22. P36 gives the Discipline pillar its foundation in dependency order: P36.1 the `TradeDisciplineRecord` contract (one per trade: pre-trade checklist answers, post-trade review answers, mistake tags, a note, moments), schema V6 store `tradeDiscipline` (`&id,tradeId,updatedAt`), repository, integrity check and backup format V5 acceptance through the released P6 path, no UI; P36.2 `saveTradeDiscipline` (guarded, one record per trade, atomic, explicit not-found / validation / storage results) and its read, with `deleteTradeRecord` extended so the record leaves with its trade in the same atomic write, no UI; P36.3 the pre-trade checklist on a draft or open trade and the post-trade review with mistake tags on a closed trade, on the released Journal and Practice history cards, in plain words, with unit and real-browser evidence; P36.4 the one-owner discipline score projected from the bounded, source-scoped history and its visual on the Home dashboard, no other owner computing it; P36.5 the closure defining P37 (vision P27 Replay / Backtesting) from the alignment sequence. Proven from ownership: P5 owns the store and migration pattern, P6 the backup format, P30.1 the atomic delete, P10/P31.2 the history cards, P12/P13 the history and day truth, P21 the dashboard; the only new owners are the record, its commands, its controls and the score. P36 may not begin before that PASS (the Gate530 canonical PASS of P35.3).

"""
if '## P35 Practice Trade Lifecycle System Closure — P35.3' not in s:
    anchor2="## Home Your Trades V1 candidate from Gate395"; assert s.count(anchor2)==1; s=s.replace(anchor2, section+anchor2, 1)
open(p,'w').write(s)
p=root+'KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md'; s=open(p).read()
old="Updated at Gate528: P35 ACTIVE (Practice trade lifecycle: fills, close and activation for paper trades) from the Gate527 canonical PASS."
add=" Updated at Gate530: P17–P35 closed; roadmap realigned to the September 2026 vision (docs/KAIROS_VISION_ROADMAP_ALIGNMENT.md); P36 defined (Discipline foundation: checklists, mistake tracking and discipline score — vision P22, discipline half), not begun; P37 onward per the alignment forward sequence."
if add.strip() not in s:
    assert s.count(old)==1; s=s.replace(old, old+add, 1)
open(p,'w').write(s); print('closure edits applied')
