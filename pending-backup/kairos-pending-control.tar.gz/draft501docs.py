"""Insert Gate501 continuity entries into the work501 docs. Reads Gate500 evidence from gate500-evidence.txt, zip500.txt and head500.txt."""
sp='/tmp/claude-0/-home-user-kairos-money/13234d43-a587-5363-9c42-8d67482f0155/scratchpad/'
RUN,JOB,AC,ACS,AE,AES,MAINRUN=open(sp+'gate500-evidence.txt').read().split()
ZSIZE,ZSHA=open(sp+'zip500.txt').read().split()
HEAD=open(sp+'head500.txt').read().strip()
root=sp+'work501/kairos_p76/docs/'
label="**Patch label:** P26.4 · P26 Goals foundation · owner phase P26 (closure) · definition: source-proven closure of P26 and the definition of P27 (Library foundation) from current ownership."
ev=f"Gate500/run{RUN}/job{JOB}/head{HEAD} is FULL canonical PASS on branch claude/kairos-trading-journal-hftwax: every current, historical, browser, TypeScript, build and upload stage succeeded. Exact-run nonexpired KAIROS_CURRENT_CANDIDATE{AC} (GitHub digest {ACS}) and KAIROS_GATE_EVIDENCE{AE} (GitHub digest {AES}) exist per the Actions artifact listing; digests are recorded as reported by GitHub. Nested KAIROS_P26_3_GOALS_ROUTE_CANDIDATE_2026-09-18.zip;{ZSIZE}bytes;SHA256 {ZSHA}; exact kairos_p76 root/path safety/integrity pass. Main was fast-forwarded to the same commit for its canonical run (run{MAINRUN}, completed success). Gate499 is the immediate rollback. P26.3 is canonical: the Goals page is live from More."
approval=f"""## Manual Gate501 slice — 18 September 2026

{label}

{ev}

Autonomous continuation under the user's 18 September 2026 rule. P26.4 adds no production runtime behaviour and no new production owner: it proves P26.1–P26.3 against current source, marks the P26 ledger SYSTEM CLOSED through P26.4 and defines P27 from research: Library is a primary tab still rendering the placeholder with no recorded content, while the app's saved records (Saved Analyses, saved snapshots; labelled, deletable) are reachable only inside Analysis per market; P27 is the Library foundation (cross-market saved-record index over the released listings, the Library route, a kind/market filter and an Open-in-Analysis handoff), one gate per owner with unit and real-browser evidence. UI VISIBLE:NO. P27 begins after this PASS without a further prompt. Candidate publication and complete canonical PASS remain mandatory.

"""
plan=f"""## Status after FULL Gate500

{label}

Gate500/run{RUN}/head{HEAD} is FULL canonical PASS with every stage and both exact-run artifacts present: P26.3 (Goals route) is canonical. Gate499 remains its immediate rollback. The next slice (Gate501, P26.4) is the P26 closure and the definition of P27 (Library foundation) from ownership.

"""
arch=f"""## Gate501 P26 closure and P27 definition amendment

{label}

Gate500/run{RUN}/head{HEAD} is the latest FULL canonical release: the P26.3 Goals route. Gate499 is the immediate rollback.

The next slice adds `scripts/verify-p26-4-goals-foundation-closure.mjs`, closes the P26 ledger below at P26.4 and adds the P26 closure section and the research-backed P27 definition. No production file changes. UI VISIBLE:NO.

"""
def insert(name, marker, text):
    p=root+name; s=open(p).read()
    assert marker in s, (name, marker)
    assert 'Gate501' not in s.split(marker)[0], 'already inserted'
    s=s.replace(marker, text+marker, 1); open(p,'w').write(s)
insert('KAIROS_CONTINUATION_APPROVAL_CONTROL.md','## Manual Gate500 slice',approval)
insert('KAIROS_CHART_WORKSPACE_INTEGRATION_PLAN.md','## Status after FULL Gate499',plan)
insert('KAIROS_ARCHITECTURE_MAP.md','## Gate500 P26.3 Goals route amendment',arch)
print('inserted')
