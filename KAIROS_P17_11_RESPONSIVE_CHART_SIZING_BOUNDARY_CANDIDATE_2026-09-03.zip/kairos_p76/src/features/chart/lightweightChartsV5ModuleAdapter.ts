import type {
  ChartEngineDriver,
  ChartEngineSeriesHandle,
} from './chartEngineDriver';
import type {
  RendererCandle,
  RendererPricePoint,
} from './chartSeriesProjection';

export interface LightweightChartsV5SeriesApi<TData> {
  setData(data: readonly TData[]): void;
  update(data: TData): void;
}

export interface LightweightChartsV5ChartApi {
  addSeries<TData>(
    definition: LightweightChartsV5SeriesDefinition<TData>,
  ): LightweightChartsV5SeriesApi<TData>;
  removeSeries(series: LightweightChartsV5SeriesApi<unknown>): void;
  remove(): void;
}

export interface LightweightChartsV5SeriesDefinition<TData> {
  readonly __kairosSeriesData?: TData;
}

export interface LightweightChartsV5ChartOptions {
  readonly autoSize?: boolean;
}

export interface LightweightChartsV5Module {
  createChart(
    container: HTMLElement,
    options?: LightweightChartsV5ChartOptions,
  ): LightweightChartsV5ChartApi;
  LineSeries: LightweightChartsV5SeriesDefinition<RendererPricePoint>;
  CandlestickSeries: LightweightChartsV5SeriesDefinition<RendererCandle>;
}

export function createLightweightChartsV5Driver(
  module: LightweightChartsV5Module,
): ChartEngineDriver {
  return {
    createChart(container: HTMLElement) {
      const chart = module.createChart(container);

      const wrapLine = (
        series: LightweightChartsV5SeriesApi<RendererPricePoint>,
      ): ChartEngineSeriesHandle => ({
        setPriceLineData(data): void {
          series.setData(data);
        },
        setCandleData(): void {
          throw new Error('chart-series-kind-mismatch');
        },
      });

      const wrapCandles = (
        series: LightweightChartsV5SeriesApi<RendererCandle>,
      ): ChartEngineSeriesHandle => ({
        setPriceLineData(): void {
          throw new Error('chart-series-kind-mismatch');
        },
        setCandleData(data): void {
          series.setData(data);
        },
      });

      const seriesLookup = new Map<
        ChartEngineSeriesHandle,
        LightweightChartsV5SeriesApi<unknown>
      >();

      return {
        addPriceLineSeries(): ChartEngineSeriesHandle {
          const vendorSeries = chart.addSeries(module.LineSeries);
          const handle = wrapLine(vendorSeries);
          seriesLookup.set(
            handle,
            vendorSeries as LightweightChartsV5SeriesApi<unknown>,
          );
          return handle;
        },

        addCandlestickSeries(): ChartEngineSeriesHandle {
          const vendorSeries = chart.addSeries(module.CandlestickSeries);
          const handle = wrapCandles(vendorSeries);
          seriesLookup.set(
            handle,
            vendorSeries as LightweightChartsV5SeriesApi<unknown>,
          );
          return handle;
        },

        removeSeries(handle: ChartEngineSeriesHandle): void {
          const vendorSeries = seriesLookup.get(handle);
          if (vendorSeries === undefined) {
            throw new Error('chart-series-handle-unknown');
          }
          seriesLookup.delete(handle);
          chart.removeSeries(vendorSeries);
        },

        remove(): void {
          seriesLookup.clear();
          chart.remove();
        },
      };
    },
  };
}
