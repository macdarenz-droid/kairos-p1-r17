# Analysis saved-trade Risk/Reward snapshot extent projection

## Scope

Gate462 is the FULL canonical base. This item-5 prerequisite projects the exact time bounds of one caller-authoritative market-history snapshot for the released saved-trade Risk/Reward owners.

`projectAnalysisSavedTradeRiskRewardSnapshotExtent` accepts the exact snapshot plus its caller-selected instrument and interval. It requires `market-reference`/`UTC` provenance, exact venue/symbol/interval agreement, at least one candle and finite, ordered, non-overlapping candle windows. A valid result preserves the snapshot by identity and freezes an extent containing the first candle's exact `openTime` and the last candle's exact `closeTime`.

Explicit gaps remain gaps; the projection does not synthesize candles or normalize timestamps. It does not inspect or infer candle prices. Unavailable provenance, scope, page or window evidence fails closed with a specific reason.

## Ownership boundaries

- P15/P16 and the released live lifecycle remain the history/provider owners.
- P17 remains chart rendering and timestamp-number conversion owner.
- P19 remains Risk/Reward meaning and logical placement owner.
- P14 remains planned and execution truth; P20 remains Saved Analysis persistence.
- No route/workspace mount, React/provider lifecycle, style resolution, journal mutation, financial arithmetic or normalization is added, with no execution, venue, FX or P&L inference.

UI visible: no. A later composition may delegate this exact extent and Gate462's style source into the released overlay; visible workspace replacement and accessible Risk/Reward evidence remain separate.

## Verification

- Dedicated source/contract verifier.
- Focused snapshot-extent and lower-owner Risk/Reward/overlay regressions.
- TypeScript, production build and full regression.
- Fresh-extract installation, verification, build and archive root/path/integrity checks.
