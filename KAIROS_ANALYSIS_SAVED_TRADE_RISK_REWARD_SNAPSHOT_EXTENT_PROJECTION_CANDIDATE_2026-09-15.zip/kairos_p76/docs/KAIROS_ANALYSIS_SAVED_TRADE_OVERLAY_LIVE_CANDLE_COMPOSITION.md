# Analysis saved-trade overlay live-candle composition

Status: Gate461 candidate from FULL canonical Gate460  
UI visible: no

## Purpose

AnalysisSavedTradeOverlayLiveCandleCanvas connects the released Gate460 overlay React lifecycle to the released live-candle canvas. It delegates the exact saved trade, chart scope, caller-authoritative history snapshot, chart theme, logical time extent, style source and revision to Gate460, then injects only Gate460's exact shared renderer factory into the existing route-session renderer boundary.

The live-candle owner remains the sole history, transport, provider, selected-scope and production renderer-lifecycle owner. The exact successful live history snapshot returns to the same overlay hook for marker placement. A selection change clears stale snapshot eligibility before the lower projection owners see the new scope. The existing marker evidence presentation remains delegated unchanged.

## Ownership boundaries

- Gate460 owns the shared marker and Risk/Reward React lifecycle.
- The released live-candle route and renderer sessions retain all acquisition and provider ownership.
- P14 owns saved plan and execution facts; P17 owns chart rendering and conversions; P19 owns Risk/Reward semantics; P20 remains the Saved Analysis persistence owner.
- This composition does not import or mount the Analysis route, workspace or current live canvas.
- There is no duplicated history request, transport, provider primitive, scale/Canvas logic, persistence, P18 interaction, journal mutation, arithmetic or normalization, and no execution, venue, FX or P&L inference.

## Verification

- exact Gate460 input delegation before and after authoritative history;
- no live owner before the shared renderer factory exists;
- exact renderer-factory injection into the released route session;
- exact authoritative snapshot return to the same overlay owner;
- fail-closed snapshot handling across selection replacement;
- lower-owner verifiers, focused tests, TypeScript, production build and full regression.

This remains an unmounted non-UI prerequisite. Workspace replacement and accessible Risk/Reward evidence remain later bounded responsibilities. P21 remains active.
