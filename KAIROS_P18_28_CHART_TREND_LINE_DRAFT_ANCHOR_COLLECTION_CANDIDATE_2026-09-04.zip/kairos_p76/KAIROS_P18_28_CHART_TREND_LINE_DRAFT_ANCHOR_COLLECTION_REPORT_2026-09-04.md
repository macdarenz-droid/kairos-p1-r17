# KAIROS P18.28 — Chart Trend-Line Draft Anchor Collection

## Authoritative base
P18.27 Lightweight Charts v5 Drawing Click Binding Composition canonical PASS #232.

## Evidence basis
Canonical P18.27 ends provider click handling at a provider-neutral `ChartDrawingAnchor | null` callback. Canonical P18.1 requires exactly two anchors (`start` and `end`) for committed trend-line drawing truth. Canonical P18.21-P18.24 own drawing interaction state/event/reducer/session semantics and intentionally contain no anchor evidence. Current authoritative source therefore has no single owner for the temporary first/second anchor evidence required to form a trend-line draft.

This slice is provider-neutral and introduces no external API behavior, so no new vendor API research is required. Its boundary is determined by existing canonical Kairos contracts.

## Responsibility added
Adds one provider-neutral ephemeral trend-line draft anchor collection owner:
- each session starts with zero anchors;
- the first valid anchor becomes the sole draft anchor;
- the second valid anchor completes the two-anchor evidence set;
- a third anchor fails closed until the caller explicitly clears the draft;
- clear removes only temporary draft-anchor evidence;
- separate sessions remain isolated;
- destroy is idempotent and later access fails closed.

## Ownership preserved
- P18.1 remains committed drawing-truth shape owner.
- P18.21 remains interaction-state shape owner.
- P18.22 remains interaction-event vocabulary owner.
- P18.23 remains interaction transition-semantics owner.
- P18.24 remains active interaction-session state/dispatch owner.
- P18.25R1 remains provider event/coordinate -> Kairos anchor projection owner.
- P18.26 remains provider click subscription lifecycle owner.
- P18.27 remains provider chart/series click binding composition owner.
- P18.28 owns only ephemeral 0/1/2 trend-line draft anchor evidence.

## Explicit non-scope
- no interaction-session dispatch or transition changes
- no provider click/pointer/crosshair APIs
- no screen/price/time conversion
- no drawing ID allocation
- no committed drawing construction or mutation
- no drawing persistence/restore
- no presentation-layer replacement
- no selection/drag/edit/delete execution
- no toolbar/UI state
- no undo/redo
- no new drawing kinds
- no Risk/Reward behavior or visuals
- no journal/market truth mutation
- no calculations/navigation/dependency migration
- no P19

## Data/state flow
Future click composition may deliver a valid `ChartDrawingAnchor` -> P18.28 stores only temporary first/second anchor evidence -> later controlled coordination may decide interaction events and committed drawing creation. P18.28 itself performs none of those later responsibilities.

## Changed-file contract
Exactly six files relative to canonical P18.27:
1. `KAIROS_P18_28_CHART_TREND_LINE_DRAFT_ANCHOR_COLLECTION_REPORT_2026-09-04.md`
2. `package.json`
3. `scripts/verify-p18-28-chart-trend-line-draft-anchor-collection.mjs`
4. `src/features/chart/chartTrendLineDraftAnchorCollection.ts`
5. `src/features/chart/index.ts`
6. `tests/chart-trend-line-draft-anchor-collection.test.ts`

## Verification intent
Dedicated verification proves exact two-anchor capacity, explicit clear behavior, isolated sessions, fail-closed completion/destruction, preserved P18.1 and P18.24 ownership, chart export, and absence of provider/persistence/P19 ownership. Canonical gate must additionally prove deterministic install, production TypeScript/build, focused runtime tests, full unit regression, full controlled roadmap regression, P18/P17 regression chain, historical closures, exact scope, candidate artifact, and gate evidence before promotion.
