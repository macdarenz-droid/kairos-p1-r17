# KAIROS PATCH REPORT

Patch: P7.7 — Activation Deployment Contract
Base: P7.6R1 PASS / LOCKED
App version: 0.1.0
Build ID: existing locked build identity

## OBJECTIVE
Freeze the client/deployment boundary required to connect Kairos to a real server-owned invite authority without inventing a production backend, embedding secrets, or letting presentation code interpret deployment values ad hoc.

## RESEARCH
Re-checked the controlling handoff security rule that invite-code authority must live server-side and that client persistence is not authority. Re-checked current OWASP Authorization guidance to deny by default and never rely on client-side authorization checks. Re-checked Vite environment-variable behavior: `VITE_` values are statically exposed to the client bundle, so only public configuration belongs there. Re-checked MDN CSP `connect-src`, which controls `fetch()` destinations and therefore must deliberately allow the activation endpoint in the deployed policy.

## OWNER TRACE
- Deployment configuration parser: `src/services/activation/activationDeployment.ts`
- Runtime composition consumer: existing `ActivationBootstrap`
- Server protocol/deployment boundary: `docs/ACTIVATION_SERVICE_CONTRACT.md`
- Invite authority: external server deployment, unchanged and never moved into the client.

## PRE-CHANGE FLOW
P7.6 read two environment strings directly and attempted to instantiate the adapter/verifier. Missing values failed closed, and the adapter separately rejected non-HTTPS endpoints, but no single deployment contract validated endpoint shape before runtime composition or documented the exact server responsibilities and browser deployment requirements.

## CHANGE
- Added centralized typed activation deployment configuration parsing.
- Requires HTTPS endpoints.
- Rejects endpoint URL credentials, query strings, and fragments.
- Rejects missing/malformed public-key configuration.
- Refactored ActivationBootstrap to use this parser while preserving existing environment variable names.
- Added strict TypeScript declarations for the two public Vite inputs.
- Added `.env.example` with a non-production `.invalid` endpoint and public-key placeholder only.
- Added the server request/response/signing/deployment contract document.
- Added P7.7 tests and static verifier.

## NON-SCOPE
- No production backend/provider selection.
- No real activation endpoint.
- No real production public key.
- No invite database or invite issuance admin UI.
- No private/signing key.
- No P8 navigation work.
- No database schema or backup-format change.
- No entitlement/subscription work.

## DATA/STATE FLOW
Deployment build inputs -> P7.7 configuration parser -> ActivationBootstrap -> existing P7.5 coordinator -> P7.3 server adapter -> P7.4 receipt proof verifier -> P7.2 receipt persistence -> P7.6 activation gate.

The server remains the only invite authorization authority.

## PERSISTENCE
None. Database schema and device-scoped activation receipt format are unchanged.

## SECURITY
- Fails closed on missing/invalid deployment configuration.
- Client-visible Vite configuration is explicitly restricted to endpoint + public verification key.
- Endpoint must use HTTPS and cannot contain URL credentials/query/hash material.
- Server contract requires default deny, server-side invite validation, rate limiting, receipt signing, and private-key isolation.
- Cross-origin deployment must deliberately configure CORS and CSP `connect-src`; wildcard permissiveness is not required by this patch.

## THEME
No presentation/theme changes.

## OFFLINE
No change. Previously verified receipts still unlock locally through the existing P7.2/P7.4/P7.5 path. First activation remains server-dependent.

## TESTS
Added deployment tests covering:
- valid HTTPS/public-key configuration;
- missing endpoint/public key;
- HTTP rejection;
- URL credential rejection;
- query/hash endpoint rejection;
- malformed public key rejection.

Added static P7.7 contract checks for HTTPS enforcement, centralized validation ownership, non-production example configuration, no client secret fields, server default-deny/signing requirements, and CSP deployment coverage.

## REGRESSION
Dependency-free checks passed locally:
- P1 static
- P7.1 activation contract
- P7.2 activation persistence
- P7.3 remote adapter
- P7.4 receipt proof
- P7.5 coordinator
- P7.6 activation gate
- P7.7 deployment contract

The authoritative full P1 release gate reached lock resolution but the local command timed out in this environment. Full TypeScript/Vitest/build and P1-P7.7 regression must pass in GitHub Actions before promotion.

## PERFORMANCE
One small startup configuration parse only. No polling, renderer, observer, recurring request, or journal hot-path work added.

## KNOWN LIMITATIONS
A real server deployment still does not exist in this repository. P7.7 freezes the protocol and deployment requirements but cannot certify real first-activation end-to-end until an actual server endpoint and matching public key are deployed.

## REAL-DEVICE STATUS
No new interactive behavior. Existing P7.6 activation-screen real-device certification remains dependent on a real activation deployment.

## RESULT
HOLD — pending full GitHub gate. P7.6R1 remains authoritative until this candidate passes.

## NEXT
Only if PASS: record P7.7 as the locked client/deployment contract and evaluate P7 closure. Do not advance to P8 unless the controlling P7 dependency is explicitly closed or the external backend deployment is formally recorded as a separate release/deployment blocker rather than silently treated as complete.
