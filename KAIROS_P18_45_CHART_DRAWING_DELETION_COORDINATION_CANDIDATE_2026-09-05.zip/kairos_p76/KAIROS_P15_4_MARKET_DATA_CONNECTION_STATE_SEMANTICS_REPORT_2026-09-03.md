# KAIROS P15.4 — Market Data Connection State Semantics

## BASE
P15.3 canonical PASS — Run #128 / SHA f7aeece58f45a9357171f93bdccbffcc2b147e41.

## OBJECTIVE
Add one deterministic application-owned connection-state transition policy before any concrete live-feed provider is selected.

## RESEARCH
MDN documents that transport APIs expose their own readiness/state models. WebSocket connections establish asynchronously and expose transport-level open/error/close behavior, while EventSource exposes CONNECTING/OPEN/CLOSED. Kairos therefore keeps its existing provider-neutral application states instead of coupling core semantics to a specific browser transport readyState.

## OWNER TRACE
P15.1 owns the adapter/subscription contract.
P15.2 owns observation validation/freshness.
P15.3 owns subscription close/AbortSignal lifecycle.
P15.4 owns only application connection-state transitions.

## PRE-CHANGE FLOW
Adapters could emit one of the existing connection-state strings, but the application had no single deterministic transition policy for accepting or rejecting state changes.

## CHANGE
Added `transitionMarketDataConnectionState` with explicit events:
- connect-requested
- connected
- disconnected
- failed
- reset

Invalid transitions are rejected explicitly and leave current state unchanged.

## NON-SCOPE
No provider, endpoint, WebSocket, EventSource, fetch, polling, reconnect timer, exponential backoff, persistence, UI/chart wiring, execution mutation, Calculation Engine mutation, P&L mutation, API key, or secret.

## DATA/STATE FLOW
current app state + explicit event -> deterministic transition result -> accepted next state or explicit rejection.

## PERSISTENCE
None.

## SECURITY
No network access or credentials introduced.

## THEME
No UI/theme changes.

## OFFLINE
Offline journal remains unaffected.

## TESTS
Runtime tests cover normal connection establishment, disconnect versus failure, reconnect eligibility, invalid transitions, and reset behavior.

## REGRESSION
P15.1 adapter contract, P15.2 observation semantics, and P15.3 lifecycle ownership remain unchanged.

## PERFORMANCE
Constant-time table lookup; no timers, observers, polling, or background work.

## KNOWN LIMITATIONS
No reconnect/backoff policy and no concrete transport/provider yet.

## REAL-DEVICE STATUS
N/A — deterministic service semantics only.

## RESULT
HOLD pending canonical GitHub gate.
