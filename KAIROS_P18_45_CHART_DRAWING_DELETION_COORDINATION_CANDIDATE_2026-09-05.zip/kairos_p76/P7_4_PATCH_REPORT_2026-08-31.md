# Kairos P7.4 — Activation Receipt Proof Foundation

## Base
P7.3 Remote Activation Adapter candidate, promoted only after GitHub run #85 completed successfully.

## Objective
Add the concrete proof-verification owner required before a persisted server-issued activation receipt may unlock normal offline use.

## Research decision
- OWASP continues to require decisive authorization to remain server-side; the client verifier only authenticates a server-issued offline proof and does not validate invite codes.
- Web Crypto `SubtleCrypto.verify()` is broadly available in secure contexts and supports ECDSA.
- Web Cryptography Level 2 specifies P-256 ECDSA output as fixed-width `r || s`; for P-256 this is 64 bytes.
- P-256 + SHA-256 is used for the V1 receipt proof because it is established across the web platform. The deployment supplies only an SPKI public verification key; Kairos ships no signing authority.

## Data / ownership flow
server invite authority -> P7.3 adapter -> server receipt -> P7.4 public proof verifier -> P7.2 receipt persistence / startup restoration.

The V1 signed payload is exact UTF-8 JSON carried by `verifierPayload` and must contain:
- `proofVersion: 1`
- `purpose: "kairos-activation"`
- `receiptVersion: 1`
- the same `activationId` and `issuedAt` as the outer receipt.

The signature is base64url-encoded raw P-256 ECDSA `r || s` bytes. The verifier signs nothing and contains no secret/private material.

## Files
- `src/services/activation/EcdsaActivationReceiptVerifier.ts`
- activation barrel export
- `tests/activation-receipt-proof.test.ts`
- `scripts/verify-p7-activation-receipt-proof.mjs`
- package script `verify:p7:receipt-proof`

## Protected behavior / non-scope
- No production activation endpoint.
- No invite-code list or master code.
- No private/signing key.
- No activation UI or navigation gate.
- No database schema change.
- No journal backup-format change.
- Existing P1-P7.3 ownership remains unchanged.

## Verification target
P1 full release gate, every P2-P7.3 regression contract, P7.4 static contract, TypeScript, Vitest, and production build through the authoritative gate. Until that succeeds, P7.3 remains authoritative.
