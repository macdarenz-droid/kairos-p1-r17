# KAIROS P18.1 — Chart Drawing Contract Foundation

## Authority
Base: canonical P17.16 Chart Engine System Closure, GitHub Actions run 33755336690.

## Scope
Introduces the first provider-neutral Drawing Tools contract only.

- Stable drawing identity is explicit.
- First controlled drawing kind is `trend-line`.
- Drawing anchors use existing `ChartTimestamp` and financial `DecimalString` truth.
- Drawing truth remains separate from journal execution truth and market observation truth.
- No renderer/plugin binding, persistence, editing interaction, pointer ownership, autoscale behavior, or network/provider behavior is introduced.

## Lightweight Charts boundary
Official Lightweight Charts v5.2 exposes series primitives for external graphics and drawing tools. That API is intentionally not owned by this contract; a later adapter may project this provider-neutral model into an `ISeriesPrimitive` implementation.

## Non-scope
No P18 rendering adapter, hit-testing, selection, drag/edit state, undo/redo, persistence/restore, autoscaling, drawing toolbar, or P19 risk/reward behavior.
