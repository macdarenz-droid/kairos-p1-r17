# KAIROS P15.10 — Market Data Reconnect Disposition Semantics

## BASE
P15.9 canonical PASS — Run #137.

## OBJECTIVE
Introduce one pure provider-neutral semantic boundary for deciding whether an already-normalized disconnect cause is eligible for reconnect.

## RESEARCH
AWS standard retry guidance distinguishes transient/retryable failures from conditions that should not simply be retried, and bounds retries separately. MDN documents WebSocket close metadata such as close codes and `wasClean`; those are transport facts. P15.10 deliberately does not interpret WebSocket codes or provider-specific errors. A future concrete adapter must normalize transport/provider facts into the provider-neutral causes owned here.

## OWNER TRACE
P15.5 owns bounded attempt/backoff decisions.
P15.7 owns jitter transformation.
P15.8 owns retry planning.
P15.9 composes an accepted plan with P15.6 scheduling.
P15.10 owns only reconnect eligibility for normalized disconnect causes.

## CHANGE
Adds:
- transient-failure -> retry eligible;
- intentional-close -> no retry;
- terminal-failure -> no retry.

## NON-SCOPE
No WebSocket/CloseEvent interpretation.
No provider-specific error/status codes.
No API/provider selection.
No scheduling/timers.
No entropy.
No persistence.
No UI/chart.
No execution/Calculation Engine/P&L mutation.
No secrets.

## RESULT
HOLD pending canonical GitHub gate.
