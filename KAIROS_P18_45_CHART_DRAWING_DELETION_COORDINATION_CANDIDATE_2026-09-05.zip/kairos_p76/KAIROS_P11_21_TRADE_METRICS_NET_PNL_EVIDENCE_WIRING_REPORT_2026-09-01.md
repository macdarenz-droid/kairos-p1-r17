# KAIROS P11.21 TradeMetrics Net P&L Evidence Wiring Report — 2026-09-01

## Status
HOLD pending authoritative GitHub full gate.

## Authoritative base
P11.20 Net P&L Currency-Aware Composition Primitive — PASS.
GitHub Actions run #47 / run ID 33510818112.

## Objective
Wire the already-validated P11.20 currency-aware net P&L composition primitive into TradeMetrics without inventing fee evidence, gross P&L currency, FX conversion, or P&L percentage data.

## Ownership trace
Executions -> existing gross realized P&L owner -> existing fee aggregation owner -> P11.20 currency-aware composition -> TradeMetrics derived output.

TradeMetrics remains a derived Calculation Engine view. It does not persist, fetch market data, convert currencies, or become a second financial authority.

## Current implementation research
Re-checked decimal.js 10.6.0 upstream documentation. It remains an arbitrary-precision Decimal implementation and recommends string inputs where precision matters. Kairos therefore continues to route money arithmetic through its locked DecimalString/decimal-kernel owners rather than native JavaScript Number arithmetic.

## Change
- Added `TradeMetricsNetPnlCurrencyInput` carrying explicit gross P&L currency evidence only.
- Added nullable `netPnlCurrency` to TradeMetrics.
- `hasNetPnl` is now a real completeness flag rather than permanently false.
- Net P&L composition runs only when both authoritative gross P&L and authoritative total-fee evidence are present.
- Explicit zero-fee evidence may compose net P&L without inventing currency, matching P11.19R1/P11.20 policy.
- Nonzero fees require explicit comparable gross P&L currency evidence.
- Missing or mismatched currency evidence leaves net P&L unavailable rather than guessing or converting.
- P&L percentage remains unresolved.
- Historical P11.5/P11.14/P11.18R2 static verifiers were narrowed so they continue checking their original contracts without forbidding this later controlled wiring.

## Non-scope
- No FX conversion or exchange-rate lookup.
- No account/instrument currency inference.
- No P&L percentage wiring.
- No database, repository, migration, backup/restore, activation, UI, route, or network changes.
- No market-specific formula changes.

## Controlled changed files
1. KAIROS_P11_21_TRADE_METRICS_NET_PNL_EVIDENCE_WIRING_REPORT_2026-09-01.md
2. package.json
3. scripts/verify-p11-trade-metrics.mjs
4. scripts/verify-p11-trade-metrics-risk-evidence.mjs
5. scripts/verify-p11-trade-metrics-fee-evidence.mjs
6. scripts/verify-p11-trade-metrics-net-pnl-evidence.mjs
7. src/domain/calculations/tradeMetrics.ts
8. tests/trade-metrics.test.ts
9. tests/trade-metrics-net-pnl-evidence.test.ts

## Verification target
The canonical GitHub gate must prove exact nine-file scope, deterministic install, build, full unit regression, every prior P1-P11.20 regression verifier, and the new P11.21 verifier before this candidate can become authoritative.
