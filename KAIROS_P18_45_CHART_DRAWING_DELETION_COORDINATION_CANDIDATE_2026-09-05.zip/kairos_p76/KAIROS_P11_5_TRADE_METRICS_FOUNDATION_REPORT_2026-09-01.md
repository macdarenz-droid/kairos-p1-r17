# KAIROS P11.5 TradeMetrics Foundation Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.4 authoritative PASS from controlled gate run #23.

## Objective
Create the first single Calculation Engine output for trade-derived metrics by composing the already-authoritative P11.2-P11.4 calculation layers.

## Controlling architecture
The P0 handoff defines derived metrics as non-authoritative outputs owned by the Calculation Engine, with candidate fields for gross P&L, fees/net P&L, percentages, risk/R, average prices, quantities, state, and completeness flags. It also locks the rule that missing financial data is never silently treated as zero.

## Owner trace
P9 TradeExecutionRecord + TradeSide
-> P11.1R2 decimal kernel
-> P11.2 aggregation
-> P11.3 execution balance
-> P11.4 flat-trade gross realized P&L
-> P11.5 TradeMetrics composition
-> future Journal / Dashboard / Visualizer / Coach consumers.

## Change
Adds `calculateTradeMetrics()` and a typed `TradeMetrics` result containing:
- grossPnl
- totalFees
- netPnl
- pnlPercent
- initialRisk
- realizedR
- averageEntryPrice
- averageExitPrice
- totalEnteredQuantity
- totalExitedQuantity
- remainingQuantity
- state
- completeness flags

## Missing-data semantics
Metrics not yet owned by a completed P11 calculator remain explicitly `null`, with completeness flags `false`.
This means:
- unknown fees are not zero fees
- net P&L is not gross P&L by default
- missing percentage/risk/R values are not zero
- no executions produce no fabricated trade state

## State mapping
- empty execution evidence -> state null
- open -> unrealized
- partially-exited -> partially-realized
- flat -> realized

This is derived execution state only; it does not mutate or replace the authoritative P9 TradeRecord status.

## Arithmetic
P11.5 introduces no new arithmetic. It composes prior PASS calculation owners. Gross P&L remains available only for flat trades under P11.4.

## Non-scope
No fee aggregation/netting, fee currency compatibility, FX conversion, net P&L, P&L percentage, planned/initial risk, R-multiple, leverage, partial cost-basis policy, market-specific multiplier policy, UI, persistence, schema, journal history, activation, or network changes.

## Persistence / security / offline / performance
Pure synchronous in-memory composition. No persistence, network, secret, theme, or platform surface. O(n) work remains in the existing execution aggregation path; this patch adds only constant-time composition after those calculations.

## Tests
Covers empty/incomplete, open, partially realized, fully realized multi-fill, short direction, and invalid over-exit propagation.

## Result
HOLD until canonical GitHub gate passes build, full unit regression, all P1-P10.3R2 regressions, P11.1R2-P11.4 regressions, and P11.5 verification.
