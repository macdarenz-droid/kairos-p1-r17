# KAIROS P16.9 — Binance Spot Public Trade Subscription Composition

## OBJECTIVE
Compose existing P16 Binance Spot owners into one provider subscription while preserving injected transport and caller-owned receipt time.

## RESEARCH
Binance Spot raw streams use `/ws/<streamName>`, lowercase stream symbols, and public trade streams. MDN confirms connection construction is asynchronous and inbound message payload is exposed as message-event data. P16.9 intentionally does not add concrete browser transport.

## OWNER TRACE / PRE-CHANGE FLOW
P16.1 stream naming -> P16.3 endpoint -> P16.4 injected connection -> P16.7 message mapping -> P16.8 P15-handler delivery. Before P16.9 these owners existed but no single provider subscription composed them.

## CHANGE
Added `subscribeBinanceSpotPublicTradeStream`: validates instrument through P16.1, builds endpoint through P16.3, opens only through P16.4 injected connector, acquires injected receipt timestamp per inbound message, and delegates delivery to P16.8. Returns a P15-compatible close-only subscription.

## NON-SCOPE
No concrete browser transport; no reconnect policy/execution; no timers; no AbortSignal ownership; no connection-state ownership; no persistence; no chart/UI; no journal/P&L mutation; no credentials/account/order streams.

## DATA/STATE FLOW
instrument -> stream descriptor -> endpoint -> injected connector -> inbound payload -> injected receipt timestamp -> P16.8 -> P15 handlers.

## PERSISTENCE / SECURITY / THEME / OFFLINE
No persistence changes. No secrets. No theme/UI changes. Local journal remains independent of market-data availability.

## TESTS
Dedicated verifier plus Vitest coverage for endpoint composition/trade delivery, invalid venue preflight, and transport-error forwarding.

## REGRESSION / PERFORMANCE
Reuses existing owners; no polling, timers, observers, retries, or collection scans added.

## KNOWN LIMITATIONS
Transport remains injected; concrete browser connection and reconnect integration remain later controlled work.

## REAL-DEVICE STATUS
Not real-device tested in this patch.

## REPAIR NOTE
P16.9R1 repairs only the dedicated subscription test timestamp expectation. The production P16.2/P16.7 mapping remains unchanged and authoritative: Binance trade timestamp `1672515782136` maps to UTC `2022-12-31T19:43:02.136Z`.

## RESULT
HOLD until canonical GitHub gate passes.
