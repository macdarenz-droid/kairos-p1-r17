# Kairos P8.1R1 — Navigation Shell Presentation Ownership Fix

Status: HOLD pending independent GitHub full gate.
Authoritative input base: P7.9 Activation CORS PASS/LOCKED.
Failed predecessor: P8.1 candidate from run 33411660984. It is not an authoritative base.

## Failure reproduced / understood
GitHub P8.1 run 33411660984 passed deterministic install, build, and the full unit regression, then failed the locked P1 static contract because `src/shell.css` contained presentation rules (`padding`, typography, theme visual tokens, etc.). P1 explicitly reserves `src/shell.css` as presentation-neutral.

## Repair
P8.1R1 is rebuilt from the P7.9 authoritative base plus the P8.1 navigation work, with ownership corrected:
- `src/shell.css` is restored byte-for-byte to the P7.9 presentation-neutral shell baseline.
- Navigation/safe-area/responsive presentation is owned by `src/design-system/shell/navigationShell.css`.
- `src/main.tsx` imports the design-system-owned navigation shell stylesheet after the neutral shell baseline.
- The P8 navigation verifier now checks both ownership boundaries: neutral P1 shell CSS and design-system-owned P8 presentation.
- No P1 verifier weakening, no schema change, no P9 trade-domain logic, no activation behavior change.

## Research check
Current CSS cascade documentation confirms author stylesheets participate in cascade according to source order, so the dedicated design-system stylesheet can be imported after the neutral baseline without creating a second application tree or domain owner. The P8 route architecture remains one shared React Router shell.

## Local evidence
- P1 static contract: PASS.
- P1 gate-result classifier: PASS.
- P8.1 navigation shell verifier: PASS 17/17.
- A fresh local `npm ci` could not complete in this constrained environment before timeout and left an incomplete node_modules tree, so local build/full unit evidence is not used for promotion.
- The failed GitHub predecessor already demonstrated deterministic install, build, and full unit regression success before reaching the P1 ownership failure.

## Promotion rule
P8.1R1 remains HOLD until the reusable GitHub gate completes deterministic install, build, full unit suite, P1–P7 regression, and P8.1 verification successfully. On any failure, P7.9 remains authoritative.
