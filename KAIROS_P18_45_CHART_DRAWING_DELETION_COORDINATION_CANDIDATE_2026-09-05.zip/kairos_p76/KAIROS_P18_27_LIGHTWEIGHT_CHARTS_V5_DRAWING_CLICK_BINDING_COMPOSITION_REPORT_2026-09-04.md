# KAIROS P18.27 — Lightweight Charts v5 Drawing Click Binding Composition

## Authoritative base
P18.26 Lightweight Charts v5 Drawing Click Subscription canonical PASS #231.

## Research
Current official Lightweight Charts 5.2 documentation was re-checked before implementation. `IChartApi` exposes paired `subscribeClick(handler)` / `unsubscribeClick(handler)`, and `ISeriesApi` exposes `coordinateToPrice(coordinate)` for the active series price scale.

## Owner trace
- P18.9 remains the sole neutral-series-handle -> provider-series identity owner.
- P18.16 remains the sole neutral-series-handle -> provider-chart identity owner.
- P18.25R1 remains the sole provider event/time/point + price-coordinate -> Kairos `ChartDrawingAnchor` projection owner.
- P18.26 remains the sole provider click subscribe/unsubscribe lifecycle owner.
- P18.27 owns only composition of those existing owners from one neutral `ChartEngineSeriesHandle`, including fail-closed capability validation before subscription.

## Change
Add one provider-specific composition boundary that:
- resolves the exact provider chart and provider series through the existing binding;
- validates click subscribe/unsubscribe capability on the chart;
- validates coordinate-to-price capability on the series;
- delegates the actual subscription lifecycle to P18.26;
- delegates click-event anchor projection transitively to P18.25R1.

## Explicit non-scope
- no interaction-session dispatch
- no first/second anchor collection
- no preview/commit semantics
- no drawing mutation or persistence
- no toolbar/UI state
- no pointer capture / drag / edit
- no new drawing kinds
- no Risk/Reward behavior
- no P19

## Data/state flow
Neutral series handle -> P18.9/P18.16 provider identity resolution -> P18.27 capability composition -> P18.26 click lifecycle -> P18.25R1 anchor projection -> callback only.

No journal truth, drawing truth, persistence, or interaction state is mutated by this slice.

## Regression target
Canonical gate must prove exact six-file scope, deterministic install, Lightweight Charts 5.2.1, production TypeScript/build, P18.27 verifier/runtime, P18.26 through prior P18 regressions, full unit regression, full controlled roadmap regression, and historical closures.
