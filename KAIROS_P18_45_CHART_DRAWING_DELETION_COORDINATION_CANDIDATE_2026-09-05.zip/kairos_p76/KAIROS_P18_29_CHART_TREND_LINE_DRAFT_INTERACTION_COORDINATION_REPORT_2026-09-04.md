# KAIROS P18.29 — Chart Trend-Line Draft Interaction Coordination

## Authoritative base
P18.28R1 Chart Trend-Line Draft Anchor DecimalString Test Fixture Repair canonical PASS #234.

## Proven missing responsibility
The authoritative source establishes separate owners but no composition between them:
- P18.24 owns the active provider-neutral interaction session and delegates all transition semantics to P18.23.
- P18.28R1 owns only ephemeral 0/1/2 trend-line draft-anchor evidence.
- P18.27 ends provider click handling at a neutral `ChartDrawingAnchor | null` callback.

No current source coordinates a first valid trend-line anchor into `tool-selected -> drawing`, a second valid anchor into `drawing -> preview`, or draft clearing after cancel/reset. P18.29 fills only that composition gap without creating a second state owner or second anchor owner.

## Responsibility
P18.29 owns only provider-neutral coordination between the existing P18.24 interaction session and P18.28R1 draft-anchor collection:
- first valid trend-line anchor while `tool-selected` and draft-empty -> store via P18.28R1, dispatch `start-drawing` via P18.24;
- second valid trend-line anchor while `drawing` and one anchor exists -> store via P18.28R1, dispatch `preview-drawing` via P18.24;
- null provider-neutral anchor evidence -> no-op;
- successful cancel/reset lifecycle transitions -> clear only P18.28R1 ephemeral draft anchors;
- destroy delegates destruction to both composed sessions and is idempotent.

## Ownership preserved
- P18.1 remains committed drawing-truth shape owner.
- P18.21 remains interaction-state shape owner.
- P18.22 remains interaction-event vocabulary owner.
- P18.23 remains sole interaction transition-semantics owner.
- P18.24 remains sole active interaction-session state/dispatch owner.
- P18.25R1 remains provider event/coordinate -> neutral anchor projection owner.
- P18.26 remains provider click subscription lifecycle owner.
- P18.27 remains provider chart/series click binding composition owner.
- P18.28R1 remains sole ephemeral 0/1/2 trend-line draft-anchor evidence owner.
- P18.29 adds coordination only; it stores no parallel interaction state and no parallel anchor collection.

## Explicit non-scope
No provider API imports, click subscription lifecycle, coordinate conversion, drawing ID allocation, committed drawing construction/mutation, persistence/restore, toolbar/UI state, selection rendering, drag/edit/delete execution, undo/redo, new drawing kinds, Risk/Reward behavior/visuals, journal truth, calculations, navigation, dependency migration, or P19 work.

## Exact changed-file contract relative to canonical P18.28R1
Exactly six files:
1. `KAIROS_P18_29_CHART_TREND_LINE_DRAFT_INTERACTION_COORDINATION_REPORT_2026-09-04.md`
2. `package.json`
3. `scripts/verify-p18-29-chart-trend-line-draft-interaction-coordination.mjs`
4. `src/features/chart/chartTrendLineDraftInteractionCoordination.ts`
5. `src/features/chart/index.ts`
6. `tests/chart-trend-line-draft-interaction-coordination.test.ts`

## Verification intent
The dedicated P18.29 verifier must prove delegation to the authoritative P18.24 and P18.28R1 owners, runtime tests must pin first/second anchor transitions plus cancel/reset lifecycle behavior, historical P1 scope must remain clean, and canonical GitHub must prove deterministic install, production TypeScript/build, full unit/roadmap regressions, P18/P17 regressions, historical closures, candidate artifact, and gate evidence before promotion.

## Result
Candidate only. P18.28R1 remains authoritative until canonical PASS.
