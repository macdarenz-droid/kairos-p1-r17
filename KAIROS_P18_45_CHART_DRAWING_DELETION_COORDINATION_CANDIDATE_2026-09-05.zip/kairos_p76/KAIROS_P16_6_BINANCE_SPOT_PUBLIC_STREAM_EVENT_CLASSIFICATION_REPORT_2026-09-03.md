# KAIROS P16.6 — Binance Spot Public Stream Event Classification

## BASE
P16.5 — canonical PASS, Run #150.

## OBJECTIVE
Add the smallest provider-specific event classifier after P16.5 JSON decoding, distinguishing trade events, the documented raw `serverShutdown` event, and all other decoded values without taking lifecycle action.

## RESEARCH
Current official Binance Spot WebSocket Streams documentation documents raw JSON market events and a `serverShutdown` event with event type `e: "serverShutdown"` and event time `E`. Binance says this event precedes disconnection and recommends establishing a new connection promptly. The same documentation states a connection is valid for 24 hours and documents ping/pong protocol behavior. P16.6 records the shutdown signal only; P15 remains the reconnect/lifecycle policy owner.

## OWNER TRACE
P16.1 stream naming.
P16.3 endpoint composition.
P16.4 injected connection seam.
P16.5 JSON text decode.
P16.6 decoded provider-event classification.
P16.2 trade semantic mapping to P15 observation.
P15 lifecycle/reconnect policy.

## PRE-CHANGE FLOW
P16.4 message -> P16.5 decoded unknown -> semantic consumers.
No owner distinguished documented provider shutdown signals from trade/other decoded messages.

## CHANGE
Added `classifyBinanceSpotPublicStreamEvent(payload)` returning:
- `trade` with unchanged payload;
- `server-shutdown` with validated non-negative safe-integer event time;
- `other` with unchanged payload.

## NON-SCOPE
No reconnect execution.
No retry decision.
No timer or 24-hour rotation.
No ping/pong ownership.
No concrete socket.
No receipt-clock acquisition.
No trade-to-observation mapping.
No binary/SBE.
No credentials/account streams.
No orders.
No persistence.
No charts.
No journal/P&L mutation.

## DATA/STATE FLOW
P16.4 connection -> P16.5 JSON decode -> P16.6 event classification.
Trade payloads remain eligible for P16.2 mapping by a later composition owner.
`server-shutdown` is evidence only; it does not itself reconnect.

## PERSISTENCE
None.

## SECURITY
Public market-data events only.

## THEME
No UI.

## OFFLINE
No impact to offline journal operation.

## TESTS
Trade classification preserves raw payload.
Documented raw `serverShutdown` is recognized with event time.
Malformed shutdown event is not elevated to lifecycle authority.
Unknown event remains explicit and unchanged.

## REGRESSION
P1 static and P16.1 through P16.6 verifiers run locally. Canonical gate remains required for build, full unit runtime, and historical regression.

## PERFORMANCE
Constant-time classification per decoded event. No polling, observers, timers, persistence, or repeated journal parsing.

## KNOWN LIMITATIONS
No reconnect action is performed. No 24-hour rotation or ping/pong behavior is introduced. No combined-stream wrapper support is introduced.

## REAL-DEVICE STATUS
Not applicable yet; no concrete transport is created.

## RESULT
HOLD pending upload and canonical GitHub gate.
