# KAIROS P17.14 — Series Logical Range Coverage Boundary

## Patch / Base / app/build identity
- Base: P17.13R2 after canonical GitHub Actions Run #189 / 33749565725 PASS.
- Candidate: P17.14 Series Logical Range Coverage Boundary.
- App: Kairos local-first trading journal.
- Owner: P17 Chart Engine only.

## OBJECTIVE
Add the smallest provider-neutral series coverage seam required to interpret P17.13 visible logical viewport evidence without introducing a history-loading policy, provider request, persistence, candle acquisition, or P18 behavior.

## RESEARCH
Current official Lightweight Charts v5.2 API documentation states that `ISeriesApi.barsInLogicalRange(range)` returns `BarsInfo` or `null`, including `barsBefore` and `barsAfter`, and specifically documents this method as suitable for determining when historical data may need to be loaded while scrolling. Official `BarsInfo` semantics define positive and negative `barsBefore`/`barsAfter` values relative to series data boundaries.

Sources:
- https://tradingview.github.io/lightweight-charts/docs/api/interfaces/ISeriesApi
- https://tradingview.github.io/lightweight-charts/docs/api/interfaces/BarsInfo
- https://tradingview.github.io/lightweight-charts/docs/api/interfaces/ITimeScaleApi

## OWNER TRACE
- P17.13 owns chart visible logical range observation/subscription.
- P17.14 owns only provider-neutral series coverage evidence for a supplied logical range and its Lightweight Charts v5 mapping.
- P15 remains provider-neutral market-data transport owner.
- P16 remains Binance live-feed owner.
- P18 remains drawings/overlay owner.
- No history-fetch threshold or acquisition owner is introduced here.

## PRE-CHANGE FLOW
Chart can expose current logical viewport through P17.13, but Kairos cannot yet query how much loaded series data exists before/after that range. Therefore viewport evidence alone cannot safely support a future history-demand decision.

## CHANGE
- Add `ChartSeriesLogicalRangeCoverage` and `ChartSeriesLogicalRangeCoveragePort`.
- Add a narrow Lightweight Charts v5 `barsInLogicalRange()` adapter.
- Map only `barsBefore` and `barsAfter`; vendor time endpoints are intentionally not promoted into Kairos truth.
- Preserve `null` when the vendor has no series data for the supplied range.
- Export the new boundary.
- Add dedicated tests and static verifier.

## NON-SCOPE
No preload threshold. No historical fetch request. No Binance REST/API work. No candle aggregation. No subscription wiring. No persistence. No journal/execution reconciliation. No calculations. No chart drawings/markers. No navigation, theme, or motion changes.

## DATA/STATE FLOW
Existing P17.13 logical range -> P17.14 coverage query -> vendor `series.barsInLogicalRange(range)` -> `{ barsBefore, barsAfter } | null` presentation evidence.

No reverse flow and no market-data acquisition occurs.

## PERSISTENCE
None.

## SECURITY
No new network/auth/secrets surface.

## THEME
None.

## OFFLINE
Fully local chart-library inspection; no runtime network dependency added.

## TESTS
Actually run locally:
- `node scripts/verify-p17-14-series-logical-range-coverage.mjs` — PASS.
- `node scripts/verify-p17-13-chart-visible-range-boundary.mjs` — PASS.

Attempted local deterministic install for full TypeScript/build/Vitest evidence, but the environment timed out before `npm ci` completed. A subsequent typecheck against that incomplete install failed only because dependency type packages were absent, so it is not counted as a product/test result. Canonical GitHub CI must provide full install/typecheck/build/Vitest authority.

## REGRESSION
P17.13 visible-range ownership remains unchanged. Existing chart engine, renderer, incremental update, provider, journal, calculation, and persistence owners are not modified.

## PERFORMANCE
One synchronous vendor series query per explicit coverage request. No polling, timer, observer, buffering, history fetch, or render-loop ownership added.

## KNOWN LIMITATIONS
This boundary deliberately does not decide when more history is needed or who fetches it. A later P17 slice may compose viewport + coverage into a provider-neutral demand signal only if the architecture and available market-data owners support it.

## REAL-DEVICE STATUS
Not required for this non-UI boundary candidate.

## RESULT
HOLD pending canonical GitHub gate. Local verifier evidence does not promote authority.

## NEXT only if PASS
Re-inspect P17 from the P17.14 authoritative state and determine whether a separate viewport-demand policy/composition boundary is still required before P17 system closure.
