# Kairos P4.1 — Web App Manifest + Install Identity Foundation

## Authoritative base
P3.5 Chart Theme Adapter — PASS / LOCKED.

## Objective
Add the smallest PWA foundation slice: a standards-based web app manifest, stable app identity, install-launch presentation metadata, and Kairos icon assets. This patch intentionally does not add service-worker caching, update activation, offline fetch behavior, or persistent-storage requests.

## Research basis
- MDN Web App Manifest: manifests are linked from document head and define installed presentation/identity.
- MDN `id`: a stable manifest ID lets browsers distinguish/update an installed web app.
- MDN `start_url` / `scope`: launch entry and installed-app URL boundary.
- MDN `icons`: `any` and `maskable` purposes have different OS presentation roles.
- MDN theme/background color guidance: launch/background color should visually match the app shell.

## Ownership / flow
Browser install discovery -> `index.html` manifest link -> `public/manifest.webmanifest` -> app identity/presentation -> icon assets.

No domain owner, repository, market data, chart state, theme preference, or business persistence is touched.

## Implementation
- Added `public/manifest.webmanifest` with stable `/` ID, name, short name, scope, start URL, standalone display and Kairos Depth launch colors.
- Added 192px and 512px standard PNG icons derived from the locked Kairos base logo.
- Added conservative 512px maskable icon with brand artwork inset on Kairos Depth background.
- Added 180px Apple touch icon.
- Linked manifest, favicon and touch icon in `index.html`.
- Aligned document `theme-color` to Kairos Depth `#070b12`.
- Added `verify:p4:manifest` contract verifier for manifest identity, icon metadata, true PNG dimensions and document links.

## Non-scope
- No service-worker registration or caching.
- No `skipWaiting()` / `clients.claim()` behavior.
- No offline app-shell fetch strategy.
- No persistent-storage request/status UI.
- No P5 IndexedDB/Dexie work.
- No navigation or feature UI.

## Promotion rule
HOLD until the full authoritative GitHub gate proves clean install, typecheck, full tests, production build, all P1-P3 regression contracts, and P4.1 manifest contract.
