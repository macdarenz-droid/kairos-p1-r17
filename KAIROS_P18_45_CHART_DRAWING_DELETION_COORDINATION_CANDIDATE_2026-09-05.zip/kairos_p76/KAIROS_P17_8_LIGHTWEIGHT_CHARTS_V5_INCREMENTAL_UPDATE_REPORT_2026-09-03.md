# KAIROS P17.8 — Lightweight Charts v5 Incremental Update Mapping

## OBJECTIVE
Map the authoritative P17.7 provider-neutral incremental presentation contract to the documented Lightweight Charts v5 `ISeriesApi.update()` method without adding live-feed wiring or historical mutation semantics.

## RESEARCH
Official Lightweight Charts v5.2 `ISeriesApi.update(bar, historicalUpdate?)` adds a newer item or replaces the latest item when timestamps are equal. The documentation states that `setData()` fully replaces series data and recommends `update()` for realtime changes because repeated `setData()` can significantly affect performance. Historical updates are slower and are explicitly not used by this slice. Current release notes identify 5.2.1.

## OWNER TRACE
P17.7 owns Kairos incremental presentation semantics.
P17.6 owns the Lightweight Charts v5 module/API shape.
P17.8 owns only the one-way mapping from P17.7 projected items to vendor `series.update()`.

## CHANGE
- extends the injected v5 series shape with `update(data)`
- adds a typed price-line/candle incremental vendor target
- maps line points to `series.update(point)`
- maps candles to `series.update(candle)`
- rejects cross-kind updates
- does not expose or request historical update mode

## DATA / STATE FLOW
Authoritative upstream truth -> P17 projection -> P17.7 incremental presentation item -> P17.8 vendor update call.
No reverse flow exists.

## PERFORMANCE
Uses the vendor's documented incremental update path rather than full-series replacement for latest/new presentation items. No application timer, buffering policy, batching policy, or market subscription ownership is introduced.

## NON-SCOPE
No direct `lightweight-charts` package import.
No dependency/lockfile change.
No Binance subscription wiring.
No candle aggregation from trades.
No historical update flag.
No journal mutation or reconciliation.
No execution markers.
No drawings/P18.
No persistence, financial calculations, timers, navigation, or motion.

## RESULT
Local verifier/static checks below. Canonical CI decides authority.
