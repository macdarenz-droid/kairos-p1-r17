# KAIROS P18.31 — Chart Trend-Line Draft Commit Construction

## Authoritative base
P18.30 Lightweight Charts v5 Trend-Line Draft Interaction Composition canonical PASS #236 / run 33885403018 / head `e64b7f94a4b0e9b80ead03d01a67a1e52d990923`.

## Proven missing responsibility
The canonical P18.30 chain now carries real provider click evidence through P18.27 into P18.29, where exactly two neutral anchors can reach the authoritative P18.23/P18.24 `preview` interaction state while P18.28R1 owns the 0/1/2 draft-anchor evidence.

The source still has no owner that converts that complete two-anchor draft into the committed P18.1 `ChartTrendLineDrawing` shape. P18.23 already defines a later `commit-drawing` transition requiring a `ChartDrawingId`, but creating committed drawing truth inside the interaction reducer, provider binding, or draft collection would violate their established boundaries.

P18.31 fills only the pure construction seam before any later ID-allocation/commit coordination is considered.

## Responsibility
P18.31 adds one provider-neutral pure constructor that:
- accepts a caller-supplied `ChartDrawingId`;
- accepts the existing P18.28R1 `ChartTrendLineDraftAnchors` evidence;
- fails closed unless exactly two anchors are present;
- delegates the final shape through the existing P18.1 `defineChartDrawing` owner;
- returns the exact `ChartTrendLineDrawing` committed truth shape without mutating the draft.

## Ownership preserved
- P18.1 remains the committed drawing-truth shape owner.
- P18.23 remains the sole interaction transition-semantics owner.
- P18.24 remains the sole active interaction-state owner.
- P18.28R1 remains the sole ephemeral draft-anchor evidence owner.
- P18.29 remains neutral draft interaction coordination owner.
- P18.30 remains provider click -> neutral draft interaction composition owner.
- P18.31 allocates no IDs, stores no drawing collection, dispatches no interaction event, and performs no persistence.

## Research
No external provider/API behavior is introduced. P18.31 is a pure composition of already-canonical internal P18 contracts, so current source evidence is sufficient and no new vendor research is required.

## Explicit non-scope
No drawing ID allocation, `crypto.randomUUID`, interaction commit dispatch, committed drawing collection/session ownership, persistence/restore, provider APIs, coordinate conversion, primitive attachment, toolbar/UI state, selection rendering, drag/edit/delete execution, undo/redo, new drawing kinds, Risk/Reward behavior/visuals, journal truth, calculations, navigation, dependency migration, or P19 work.

## Exact changed-file contract relative to canonical P18.30
Exactly six files:
1. `KAIROS_P18_31_CHART_TREND_LINE_DRAFT_COMMIT_CONSTRUCTION_REPORT_2026-09-05.md`
2. `package.json`
3. `scripts/verify-p18-31-chart-trend-line-draft-commit-construction.mjs`
4. `src/features/chart/chartTrendLineDraftCommitConstruction.ts`
5. `src/features/chart/index.ts`
6. `tests/chart-trend-line-draft-commit-construction.test.ts`

## Verification intent
Dedicated verification must prove exact two-anchor construction, fail-closed incomplete drafts, caller-supplied identity, unchanged P18.1/P18.28R1/P18.23 ownership, and absence of ID allocation/provider/persistence/interaction-dispatch/P19 ownership. Canonical GitHub must still prove exact scope, deterministic install, production TypeScript/build, dedicated P18.31 runtime, full unit regression, full controlled roadmap regression, P18/P17 regressions, historical closures, candidate artifact, and gate evidence before promotion.

## Result
Candidate only. P18.30 remains authoritative until P18.31 passes the canonical gate.
