# KAIROS P11.17R1 Fee Currency Evidence Repair Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Authoritative base
P11.16 PASS only.

The failed P11.17 candidate was not used as a base.

## Failure repaired
P11.17 gate run #38 failed because two pre-existing P11.15 unit-test success expectations still asserted the older result shape without the new `currency` field.

P11.17R1 rebuilds the same intended fee-currency evidence contract from P11.16 and updates all affected legacy success expectations.

## Contract
`calculateTotalFees` success returns:
- `totalFees`
- `currency`

Non-empty same-currency fees return their authoritative currency.
An authoritative empty fee set returns exact `0` with `currency: null`.
Mixed currencies still fail explicitly.

## Non-scope
No FX conversion, no TradeMetrics wiring, no net-P&L composition, no persistence, no UI, no market-specific fee rules.

## Verification
Full unit suite and controlled P1/P11 regression must pass before promotion.
