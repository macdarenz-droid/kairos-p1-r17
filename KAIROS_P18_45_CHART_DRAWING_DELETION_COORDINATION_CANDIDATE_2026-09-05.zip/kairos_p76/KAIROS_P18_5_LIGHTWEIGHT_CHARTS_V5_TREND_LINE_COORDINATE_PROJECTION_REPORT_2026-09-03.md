# KAIROS P18.5 — Lightweight Charts v5 Trend-Line Coordinate Projection

## Authority
- Base: canonical P18.4
- Canonical gate run: 33761625490 (#200)
- Canonical head SHA: 22bc56d523b26bdbcf7b55618f29a4b3960e7490

## Controlled purpose
Introduce the smallest provider-specific coordinate projection needed before Canvas rendering. Renderer-safe P18.2 drawing anchors are converted through the active Lightweight Charts v5 time and price coordinate APIs into screen-space trend-line segments.

## Ownership
- Input truth remains the P18 drawing contract and P18.2 renderer projection.
- Provider coordinate conversion remains owned by the active chart/time/price scale APIs.
- P18.5 only composes those presentation values into screen-space segments.

## Explicit non-scope
No Canvas drawing, primitive lifecycle/attachment changes, hit testing, pointer capture, drag/edit state, toolbar, persistence, autoscale ownership, journal/market mutation, or P19 risk/reward behavior.

## Current official research
Lightweight Charts v5.2 series primitives use pane views/renderers for custom graphics. Series APIs expose price-to-coordinate conversion and time-scale APIs expose time-to-coordinate conversion. View updates are triggered when chart viewport state changes. This patch stops before Canvas rendering so coordinate ownership is isolated and testable first.
