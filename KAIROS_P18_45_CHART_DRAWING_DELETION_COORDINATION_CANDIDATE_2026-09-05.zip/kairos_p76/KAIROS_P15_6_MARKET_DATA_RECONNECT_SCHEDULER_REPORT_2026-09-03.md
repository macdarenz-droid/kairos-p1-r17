# KAIROS P15.6 — Market Data Reconnect Scheduler Lifecycle

## BASE
P15.5 canonical PASS — Run #130 / SHA 7ff6975de7488c070b67e3ded248cfae1018d88f.

## OBJECTIVE
Add one provider-neutral lifecycle owner that can schedule or cancel a single reconnect attempt using an injected scheduler.

## RESEARCH
MDN documents that `setTimeout()` schedules a one-shot callback and that the matching timeout can be cancelled before firing. MDN also recommends cleaning up application-added AbortSignal listeners when an operation finishes normally, because `{ once: true }` only removes the listener when abort actually fires. P15.6 follows those lifecycle semantics but injects the scheduler instead of owning the browser timer API directly.

## OWNER TRACE
P15.1 owns adapter/subscription contract.
P15.2 owns observation validation/freshness.
P15.3 owns subscription lifecycle.
P15.4 owns connection-state transitions.
P15.5 owns reconnect decision/backoff policy.
P15.6 owns scheduling/cancellation lifecycle for one already-decided reconnect.

## PRE-CHANGE FLOW
P15.5 could decide whether a retry is permitted and provide a deterministic delay, but no owner existed to lifecycle-manage the resulting one-shot retry.

## CHANGE
Added `scheduleMarketDataReconnect` with injected schedule/cancel operations, one reconnect callback, explicit cancellation, AbortSignal cancellation, already-aborted short circuit, idempotent settlement, and abort-listener cleanup on cancellation or normal firing.

## NON-SCOPE
No concrete browser timer, random jitter generation, provider, endpoint, WebSocket, EventSource, fetch, polling loop, persistence, UI/chart wiring, execution mutation, Calculation Engine mutation, P&L mutation, API keys, or secrets.

## DATA/STATE FLOW
P15.5 decision supplies delay -> P15.6 injected scheduler creates one pending retry -> retry fires once OR cancellation/abort settles it.

## PERSISTENCE
None.

## SECURITY
No network access or credentials.

## THEME
No UI/theme changes.

## OFFLINE
Offline journal remains unaffected.

## TESTS
Runtime tests cover scheduling, delay forwarding, explicit cancellation, abort cancellation, already-aborted behavior, idempotence, and post-fire cancellation safety.

## REGRESSION
P15.1-P15.5 ownership remains unchanged.

## PERFORMANCE
One pending scheduled callback at most per invocation; no polling or interval owner.

## KNOWN LIMITATIONS
Actual browser timer adapter, jitter strategy, provider-specific retryability and multi-attempt orchestration remain deferred.

## REAL-DEVICE STATUS
N/A — provider-neutral service lifecycle.

## RESULT
HOLD pending canonical GitHub gate.
