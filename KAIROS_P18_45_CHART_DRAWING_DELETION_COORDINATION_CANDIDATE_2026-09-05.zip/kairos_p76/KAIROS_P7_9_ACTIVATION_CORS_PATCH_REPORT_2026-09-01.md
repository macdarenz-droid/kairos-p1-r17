# KAIROS P7.9 ACTIVATION CORS INTEGRATION PATCH REPORT — 2026-09-01

## Base
Authoritative base: P7.8R1 Dependency Lock Repair PASS/LOCKED.

## Objective
Permit browser activation only from the deployed Kairos production frontend while preserving the activation authority, signing, rate limiting, D1 one-time consumption, and no-credentials client contract.

## Production origin
`https://kairos-p1-r17.pages.dev`

## Changes
- Added exact-origin CORS handling to `backend/activation-worker/worker.js`.
- Added `OPTIONS` preflight for `/activate` before rate limiting.
- Allows methods `POST, OPTIONS`.
- Allows request headers `Accept, Content-Type`.
- Adds `Vary: Origin`.
- Adds no `Access-Control-Allow-Credentials`.
- Does not use wildcard origin.
- Normal API responses expose CORS only to the exact production origin.
- Updated activation authority README.
- Added `verify:p7:activation-cors`.

## Protected behavior
No changes to invite canonicalization/hashing, ECDSA signing, D1 conditional redemption, rejection mapping, rate limiter semantics, database schema, receipt format, client persistence, or frontend UI.

## Verification status
Local static/source verification completed. GitHub full regression gate required before deployment. Until that gate is PASS, P7.8R1 remains authoritative and the live Worker must not be changed.
