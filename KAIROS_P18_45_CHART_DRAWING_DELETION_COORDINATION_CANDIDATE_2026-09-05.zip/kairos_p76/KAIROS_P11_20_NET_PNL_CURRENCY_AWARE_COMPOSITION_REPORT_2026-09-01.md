# KAIROS P11.20 Net P&L Currency-Aware Composition Primitive Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Authoritative base
KAIROS_P11_19R1_NET_PNL_CURRENCY_COMPARABILITY_GATE_SCOPE_REPAIR_CANDIDATE_2026-09-01.zip

P11.19R1 passed Kairos Controlled Roadmap Gate run #46 on 2026-09-01 and is the only base used for this patch.

## Objective
Add the smallest Calculation Engine composition boundary that can calculate net P&L only after the P11.19R1 currency-comparability policy proves the monetary evidence may be combined.

## Research
The project remains locked to decimal.js 10.6.0. Current upstream documentation still identifies decimal.js 10.6.0 as an arbitrary-precision Decimal implementation and recommends string inputs when precision matters. P11.20 continues to route all arithmetic through the existing locked decimal kernel and does not introduce JavaScript Number authority.

## Owner trace
Authoritative owner: Calculation Engine.

Gross P&L evidence + fee evidence + explicit currency evidence -> P11.19R1 comparability policy -> P11.16 net P&L primitive -> P11.20 composition result.

## Pre-change flow
P11.16 could subtract already-comparable gross P&L and fees. P11.19R1 could independently prove whether currency evidence was comparable. No single Calculation Engine primitive composed those two locked responsibilities.

## Change
Adds `calculateComparableNetPnl()` in `src/domain/calculations/netPnlComposition.ts`.

Semantics:
- authoritative zero fees remain unit-neutral and may compose without invented currency evidence;
- non-zero fees require explicit matching gross-P&L and fee currencies;
- missing currency evidence or a currency mismatch returns an unavailable result rather than silently subtracting values;
- malformed gross P&L or fee decimals fail explicitly as `invalid-decimal`;
- successful composition uses the existing P11.16 exact-decimal net-P&L primitive;
- output currency is only the supplied gross-P&L currency and is never inferred;
- no FX conversion occurs.

## Non-scope
- No TradeMetrics wiring yet.
- No new gross-P&L currency source or inference.
- No percentage calculation wiring.
- No market-specific FX behavior.
- No persistence, schema, repository, backup/restore, activation, UI, route, network, Worker, D1, or deployment changes.

## Data/state flow
Authoritative calculation inputs -> currency comparability policy -> exact net-P&L calculator -> immutable returned evidence for later P11 wiring.

## Persistence
None.

## Security
No new security surface.

## Theme
None.

## Offline
Pure local calculation; no network dependency.

## Tests
Dedicated unit coverage verifies zero-fee composition, same-currency composition, negative net P&L, missing gross currency, missing fee currency, currency mismatch, malformed gross P&L, and malformed fees.

## Regression
Local static verification passed every P11 verifier from P11.1R2 through P11.20 and confirmed the exact six-file controlled scope. A local `npm ci && npm run build && npm test` attempt exceeded the execution transport time limit, so no build/unit result is claimed locally. Canonical GitHub gate must run deterministic install, build, full unit suite, all P1-P10 regressions, and every P11 regression through P11.19R1 before promotion.

## Performance
Constant-size pure composition over already-derived values. No loops, storage, rendering, observers, or network work added.

## Known limitations
TradeMetrics still exposes `netPnl: null`. Gross-P&L currency evidence is not yet wired into TradeMetrics; that is intentionally deferred to a later controlled P11 sub-patch.

## Real-device status
Not required for this pure Calculation Engine primitive.

## Result
HOLD pending canonical GitHub gate.

## Next
Only after PASS: wire explicit gross-P&L currency evidence and this composition primitive into TradeMetrics without inference or FX conversion.
