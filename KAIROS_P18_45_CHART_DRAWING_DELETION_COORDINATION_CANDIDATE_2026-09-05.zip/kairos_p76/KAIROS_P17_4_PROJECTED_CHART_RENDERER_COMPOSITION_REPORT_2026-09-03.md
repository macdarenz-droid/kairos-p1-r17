# KAIROS P17.4 — Projected Chart Renderer Composition

## OBJECTIVE
Compose the P17.2 renderer lifecycle and P17.3 renderer-ready projection through an injected chart-engine port, without making a third-party chart library authoritative.

## RESEARCH
TradingView Lightweight Charts v5.2 documents `addSeries`, `removeSeries`, and irreversible chart `remove()` lifecycle. P17.4 does not duplicate those vendor types. Instead it defines the narrow Kairos engine port that a later concrete Lightweight Charts adapter must implement.

## OWNER TRACE
P17.1R2 owns ChartRenderModel semantics.
P17.2 owns renderer lifecycle.
P17.3 owns ISO/DecimalString -> renderer primitive projection.
P17.4 owns composition of those presentation boundaries through an injected engine session.
P11, P15/P16, and journal/domain owners remain unchanged.

## CHANGE
- adds ChartEnginePort and ChartEngineSession
- session accepts only RendererSeriesProjection
- composes projectChartSeries(model) into session.replaceSeries(...)
- renderer destroy delegates once to the engine session
- render after destroy is rejected
- adds dedicated tests and verifier

## STATE / DATA FLOW
Authoritative ChartRenderModel -> P17.3 projection -> P17.4 injected engine session.
There is no reverse flow into journal, market data, calculations, or persistence.

## NON-SCOPE
No Lightweight Charts dependency.
No createChart/addSeries/removeSeries implementation.
No live-feed wiring.
No historical candle acquisition.
No execution markers.
No drawings.
No P18.
No persistence, calculations, timers, navigation, or motion changes.

## RESULT
Local verifier/static checks below. Canonical CI remains authoritative.
