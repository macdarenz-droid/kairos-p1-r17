# KAIROS P18.7 — Lightweight Charts v5 Trend-Line Primitive View Composition

## Authority
Built directly from canonical P18.6 after GitHub Actions run #202 (`33763604394`) completed successfully at head `32d3c60901c52f6907533566443e12d8d9f9615d`.

## Controlled purpose
Compose the already-canonical P18.5 coordinate projection and P18.6 pane renderer into the provider series-primitive view lifecycle. The primitive captures the active chart/series scale APIs on `attached()`, refreshes screen geometry in `updateAllViews()`, and exposes one stable pane view to Lightweight Charts.

## Production ownership
`lightweightChartsV5TrendLinePrimitive.ts` owns only provider primitive-view composition. P18.2 remains drawing projection truth, P18.5 remains time/price-to-screen projection, P18.6 remains Canvas pane rendering, and P18.4 remains primitive attach/detach driver ownership.

## Official API evidence
Current Lightweight Charts 5.2 series-primitive documentation states that series primitives expose pane views/renderers, receive chart/series references in `attached()`, and should refresh views in `updateAllViews()` when the viewport changes. P18.7 maps exactly those lifecycle responsibilities without adding hit testing or autoscale ownership.

## Explicit non-scope
No provider `attachPrimitive`/`detachPrimitive` mapping changes, no Canvas drawing implementation changes, no hit testing, pointer/crosshair capture, drag/edit state, toolbar, persistence, autoscale ownership, calculations, market acquisition, journal truth, or P19 risk/reward behavior.

## Exact controlled diff from P18.6
1. `KAIROS_P18_7_LIGHTWEIGHT_CHARTS_V5_TREND_LINE_PRIMITIVE_VIEW_COMPOSITION_REPORT_2026-09-03.md`
2. `package.json`
3. `scripts/verify-p18-7-lightweight-charts-v5-trend-line-primitive.mjs`
4. `src/features/chart/index.ts`
5. `src/features/chart/lightweightChartsV5TrendLinePrimitive.ts`
6. `tests/lightweight-charts-v5-trend-line-primitive.test.ts`

## Verification status before canonical gate
Dedicated P18.7 static verifier is run locally. Canonical GitHub Actions remains authoritative for deterministic dependency install, TypeScript compilation, production build, Vitest, full roadmap regression, prior chart regressions, historical closures, and artifact promotion.
