# Kairos P3.2 Active Theme Registry

Status: HOLD pending full GitHub gate.

## Scope
- Promote only Kairos Depth, Cosmic, and Ocean into the active theme registry.
- Kairos Depth is the default.
- All three use the same semantic token keys and dark browser color scheme.
- Geometry, motion, domain state, persistence, PWA behavior, Settings UI, and future themes remain outside this patch.
- Arctic, Ember, and Neon Violet remain future themes.

## Ownership
Theme preference -> Theme Engine -> resolved ThemeId -> document data-kairos-theme + semantic CSS variables.

## Verification
Static P2.1/P2.2/P2.3 and P3.2 contracts must pass locally. Full clean install/typecheck/tests/build and all regression contracts must pass in GitHub before promotion.
