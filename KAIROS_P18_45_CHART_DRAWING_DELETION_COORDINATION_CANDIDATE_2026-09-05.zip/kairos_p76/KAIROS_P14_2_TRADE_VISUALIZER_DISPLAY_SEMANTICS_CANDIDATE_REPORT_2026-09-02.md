# KAIROS PATCH REPORT

Patch: P14.2 — Trade Visualizer Display Semantics
Base: P14.1R1 canonical PASS, Run #104, gate SHA d6b18389c311c807b1cad10f5e40fcfb7b0f2c73.

Purpose: define the presentation vocabulary before any SVG/chart geometry.
- planned entry, stop and target remain explicitly labelled planned;
- authoritative exit executions become Actual exit / Actual exit N;
- absent levels are omitted, never invented;
- open trades without exits show no actual exit.

No SVG/canvas, coordinate scaling, candle/path generation, current/live price, market data, P&L arithmetic, DB/query ownership, FX, animation, or P15+ behavior.

Status: HOLD pending canonical GitHub gate.
