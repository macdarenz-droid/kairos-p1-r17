# KAIROS PATCH REPORT

Patch: P7.6 — Activation Gate Presentation / Bootstrap Integration
Base: P7.5 Activation Coordinator Foundation — GitHub run #93 PASS / LOCKED
App version: 0.1.0
Build ID: unchanged from authoritative base

## OBJECTIVE
Place the existing P7 activation subsystem in front of the journal router without duplicating activation authority in presentation code. Provide a minimal, theme-aware, accessible invite screen while keeping P7.5 as the sole orchestration owner.

## RESEARCH
- React's current conditional-rendering guidance supports returning different UI trees from explicit application state; P7.6 therefore reveals journal children only for the existing `active-online` or `active-offline` snapshots.
- W3C WAI form guidance requires explicit labels for controls, clear submission feedback, and programmatic invalid state after validation. P7.6 uses an explicit Invite code label, live feedback, and `aria-invalid` only after a local validation error.
- Existing Kairos rules require one activation owner, shared semantic theme tokens, no client-side invite authority, and fail-closed handling of fatal storage errors.

## OWNER TRACE
- P7.5 `ActivationCoordinator` remains the authoritative activation orchestration owner.
- P7.3 `RemoteActivationAdapter` remains remote service transport/response owner.
- P7.4R1 `EcdsaActivationReceiptVerifier` remains proof-authenticity owner.
- P7.2 `ActivationReceiptRepository` remains installation receipt persistence owner.
- P7.6 presentation owns only transient invite text and rendering state.

## PRE-CHANGE FLOW
The activation backend could validate, verify, persist, and restore activation, but the application router still rendered directly from `main.tsx`. Deployment configuration also had no single bootstrap point that assembled the adapter, verifier, repository, and coordinator.

## CHANGE
Added:
- `src/features/activation/ActivationGate.tsx`
- `src/features/activation/ActivationBootstrap.tsx`
- `src/features/activation/activationGate.css`
- `src/features/activation/index.ts`
- `tests/activation-gate.test.tsx`
- `scripts/verify-p7-activation-gate.mjs`
- package script `verify:p7:activation-gate`

Updated `src/main.tsx` so the router is a child of `ActivationBootstrap` rather than rendering before activation state is known.

Deployment inputs are explicit build configuration only:
- `VITE_KAIROS_ACTIVATION_ENDPOINT`
- `VITE_KAIROS_ACTIVATION_PUBLIC_KEY_SPKI`

No production values are embedded.

## NON-SCOPE
- No production activation endpoint or backend provider choice.
- No invite-code list/master code in the client.
- No private/signing key.
- No database schema or backup-format change.
- No P8 navigation implementation.
- No entitlement/pro subscription work.
- No clearing/deactivation UI.

## DATA/STATE FLOW
Startup:
`main.tsx database startup -> ActivationBootstrap -> P7.5 coordinator.bootstrap -> P7.2 receipt load -> P7.4 proof verification -> ActivationGate -> router only when active`.

First activation:
`invite input -> ActivationGate -> P7.5 coordinator.activate -> P7.3 remote adapter -> P7.4 proof verification -> P7.2 persistence -> active snapshot -> router`.

Presentation never calls the remote service or persistence repository directly.

## PERSISTENCE
No schema migration. Existing device-scoped activation receipt persistence is reused unchanged.

## SECURITY
- Journal routes stay hidden until an authenticated active snapshot exists.
- Fatal database startup failure does not masquerade as an unactivated/empty journal; it renders a storage failure state.
- Missing deployment endpoint/key fails closed.
- Public verification key is deployment configuration; no signing authority is present in the client.
- The UI cannot decide invite validity and does not call the network directly.

## THEME
The activation UI consumes Kairos semantic theme, typography, spacing, radius, state, and glow tokens. No hard-coded colors were added. The same geometry/state logic is shared across active themes.

## OFFLINE
A previously stored receipt can unlock through P7.5/P7.4 local verification without contacting the activation endpoint. A never-activated installation still requires the remote service.

## TESTS
Added presentation tests for:
- router/journal children hidden while activation bootstrap is unresolved;
- verified offline receipt state reveals children;
- invite input normalization and coordinator request wiring;
- rejected activation keeps the gate closed with plain feedback;
- empty invite produces an accessible local error without calling the coordinator.

Added a static P7.6 contract checking:
- coordinator-only bootstrap/activation ownership;
- router placement behind the activation bootstrap;
- fail-closed storage/config behavior;
- deployment-supplied endpoint/public key;
- no direct remote call or signing authority in presentation;
- semantic token usage and no hard-coded colors.

## REGRESSION
Local dependency-free verification passed:
- P1 static contract
- P7.1 activation contract
- P7.2 activation persistence
- P7.3 remote activation adapter
- P7.4 receipt proof
- P7.5 activation coordinator
- P7.6 activation gate static contract

The clean dependency install timed out in this environment. TypeScript, Vitest, production build, and the full P1-P7.6 regression chain must pass in GitHub Actions before promotion.

## PERFORMANCE
No polling, observer, extra router, or recurring network check is added. Activation bootstrap is one startup sequence; the journal tree is not mounted until activation succeeds.

## KNOWN LIMITATIONS
- The production activation service endpoint and corresponding public verification key still need deployment configuration.
- Full end-to-end first activation against a real server cannot be certified until that server exists.
- Real-device activation UI verification remains pending; automated DOM and token/mobile-layout contracts are included in this candidate.

## REAL-DEVICE STATUS
Pending for the activation screen because no production activation deployment is configured yet.

## RESULT
HOLD — pending full GitHub gate. P7.5 remains authoritative until this candidate passes.

## NEXT
Only if GitHub gate PASS: evaluate the remaining P7 completion dependency. Do not start P8 until the server-side activation/deployment contract is explicitly closed or intentionally separated by the controlling architecture.
