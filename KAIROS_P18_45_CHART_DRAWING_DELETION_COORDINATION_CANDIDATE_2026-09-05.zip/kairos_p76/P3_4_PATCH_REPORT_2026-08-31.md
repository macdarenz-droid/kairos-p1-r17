# Kairos P3.4 — Persistent Theme Preference

## Status
HOLD pending authoritative GitHub clean-install gate.

## Authoritative input
P3.3 PASS / LOCKED.

## Objective
Add one narrow persistent owner for theme preference and wire the existing theme engine into application bootstrap/runtime without introducing P5 database ownership or Settings UI.

## Owner flow
Stored preference -> theme preference adapter -> ThemeProvider -> resolveTheme -> applyTheme -> document semantic presentation tokens -> UI consumers.

## Research
- Web Storage localStorage persists across browser sessions and is origin scoped.
- localStorage access can throw SecurityError / be unavailable, so reads and writes fail safely.
- storage events notify other same-origin browsing contexts; they do not fire in the same context that performed the write.
- React browser/external mutable sources require explicit subscription/state ownership; this patch keeps runtime state in one ThemeProvider and uses storage only as persistence.

## Changes
- Added `themePreference.ts` with versioned key `kairos.theme.preference.v1`, validation and safe read/write fallbacks.
- Added `ThemeProvider.tsx` as runtime theme preference owner.
- Added pre-render `applyInitialTheme()` to avoid starting React with a disconnected theme state.
- ThemeProvider persists explicit selection and applies the resolved theme through the existing `applyTheme` owner.
- Added cross-context storage synchronization.
- Added six persistence/runtime tests.
- Added `verify:p3:theme-preference` static contract.

## Protected scope
No Settings UI, IndexedDB/Dexie, PWA/service worker, chart engine, trading domain, navigation expansion, geometry changes, future themes, or P4+ functionality.

## Verification
Local static contracts PASS:
- P2.1
- P2.2
- P2.3
- P3.2
- P3.3
- P3.4

A local clean-install/typecheck/test/build attempt did not complete because the execution environment timed out. It is therefore not counted as PASS evidence.

## Result
HOLD. P3.3 remains authoritative until the GitHub full gate passes.
