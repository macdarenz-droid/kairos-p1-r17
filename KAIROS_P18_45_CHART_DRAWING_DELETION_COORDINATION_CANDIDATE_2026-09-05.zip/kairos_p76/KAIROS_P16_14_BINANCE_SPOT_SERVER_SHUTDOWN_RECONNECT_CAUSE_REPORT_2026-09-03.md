# KAIROS P16.14 — Binance Spot serverShutdown reconnect cause

## OBJECTIVE
Translate already-classified Binance `serverShutdown` application evidence into the existing provider-neutral P15 transient disconnect cause without executing reconnect behavior.

## RESEARCH
Binance Spot WebSocket documentation defines `serverShutdown` as an application-level event and states connections have finite lifetime. Browser WebSocket protocol ping/pong remains transport-managed by the browser; this slice does not create protocol control ownership.

## OWNER TRACE
P16.5 owns text decode. P16.6 owns provider event classification. P15 owns reconnect cause/policy/scheduling/execution. P16.14 is only the provider-to-P15 cause bridge.

## CHANGE
Added a pure resolver returning `server-shutdown` with original Binance eventTime and `{kind:'transient-failure'}`. Non-shutdown traffic remains non-shutdown; decode errors remain explicit.

## NON-SCOPE
No socket close, WebSocket construction, retry scheduling, timers, jitter sampling, clock acquisition, AbortSignal, persistence, charting, UI, journal mutation, credentials, or orders.

## DATA/STATE FLOW
message data -> P16.5 decode -> P16.6 classify -> P16.14 transient cause evidence. No state mutation.

## PERSISTENCE / SECURITY / THEME / OFFLINE
No persistence, credentials, UI/theme, or offline behavior changes. Local journal remains independent of market data.

## TESTS
Dedicated tests cover valid serverShutdown, normal trade traffic, and invalid JSON. Static verifier forbids transport/reconnect execution ownership.

## REGRESSION / PERFORMANCE
Pure O(1) classification composition. Existing P15/P16 owners are reused.

## KNOWN LIMITATIONS
This slice intentionally does not execute reconnect. A later controlled slice may feed this cause into existing P15 reconnect execution with injected scheduler and external entropy.

## REAL-DEVICE STATUS
Not required for this pure service boundary.

## RESULT
Candidate ready for canonical gate.
