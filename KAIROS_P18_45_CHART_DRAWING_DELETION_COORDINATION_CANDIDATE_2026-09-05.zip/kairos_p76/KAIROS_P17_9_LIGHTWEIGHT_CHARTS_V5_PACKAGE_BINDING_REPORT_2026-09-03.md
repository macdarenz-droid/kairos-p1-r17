# KAIROS P17.9 — Lightweight Charts v5 Package Binding

## Patch/Base/app/build identity
- Base: authoritative P17.8 after canonical GitHub Actions Run #179 / 33736849316 PASS
- Candidate: P17.9 Lightweight Charts v5 package binding
- App: Kairos local-first trading journal
- Scope owner: P17 Chart Engine only

## OBJECTIVE
Bind the already-authoritative P17.6/P17.8 Lightweight Charts v5 injected module seam to the real npm package without introducing market-feed wiring, candle aggregation, persistence, journal mutation, calculations, drawings, navigation, or motion ownership.

## RESEARCH
Current official Lightweight Charts documentation identifies the v5.2 documentation line, instructs npm consumers to install the `lightweight-charts` package, and confirms TypeScript declarations are included. Current official release notes identify 5.2.1 as the latest patch release. Official package metadata shows the package is ESM, exposes TypeScript declarations, targets modern browsers, and depends on `fancy-canvas` 2.1.0.

Sources consulted:
- https://tradingview.github.io/lightweight-charts/docs
- https://tradingview.github.io/lightweight-charts/docs/release-notes
- https://github.com/tradingview/lightweight-charts

## OWNER TRACE
- P17.6 owns the Kairos-facing Lightweight Charts v5 module/API shape.
- P17.8 owns the mapping of Kairos incremental updates to vendor `series.update()`.
- P17.9 owns only the production package binding that supplies `createChart`, `LineSeries`, and `CandlestickSeries` to the existing injected module seam.
- P16 remains market-feed owner.
- P18 remains drawing/overlay owner.

## PRE-CHANGE FLOW
Kairos P17 projection -> P17.6 injected Lightweight Charts module contract -> test/injected module only.

## CHANGE
- Add exact runtime dependency `lightweight-charts` 5.2.1.
- Lock transitive `fancy-canvas` 2.1.0.
- Add `lightweightChartsV5Package.ts` production binding.
- Export the production binding from the chart feature index.
- Add P17.9 runtime identity test.
- Add dedicated P17.9 static verifier and package script.

## NON-SCOPE
- No Binance or P16 subscription wiring.
- No WebSocket ownership.
- No trade-to-candle aggregation.
- No historical update mode.
- No journal mutation or execution reconciliation.
- No persistence or backup/restore changes.
- No calculation changes.
- No P18 drawings, markers, or user overlays.
- No navigation or premium-motion changes.
- No opportunistic toolchain upgrades.

## DATA/STATE FLOW
Authoritative chart input -> existing P17 projection -> existing P17.6/P17.8 adapter behavior -> package-provided Lightweight Charts browser API.

No reverse data flow is introduced.

## PERSISTENCE
None.

## SECURITY
Public client-side chart rendering dependency only. No secrets, auth, account access, order execution, or remote code loading is introduced by this slice.

## THEME
No theme ownership changes. Existing P3 chart-theme adapter remains authoritative for chart presentation tokens.

## OFFLINE
The chart package is bundled at build time. No runtime CDN dependency is introduced.

## TESTS
Actually run locally:
- `node scripts/verify-p17-9-lightweight-charts-v5-package.mjs` — PASS
- `node scripts/verify-p17-8-lightweight-charts-v5-incremental-update.mjs` — PASS

Not run locally:
- deterministic npm install / build / TypeScript / Vitest full regression, because this execution environment cannot resolve the npm registry. Canonical GitHub Actions must decide authority.

## REGRESSION
Controlled diff from P17.8 contains only:
- `package.json`
- `package-lock.json`
- `src/features/chart/index.ts`
- `src/features/chart/lightweightChartsV5Package.ts`
- `tests/lightweight-charts-v5-package.test.ts`
- `scripts/verify-p17-9-lightweight-charts-v5-package.mjs`
- this report

P17.8 dedicated verifier remains PASS after the change.

## PERFORMANCE
No new timers, polling, subscriptions, buffering, observers, or render loops. This slice only resolves the existing adapter to the bundled package implementation.

## KNOWN LIMITATIONS
The real browser package is now available to P17, but no application screen/feed composition is added here. That remains a later dependency-safe P17 slice.

## REAL-DEVICE STATUS
Not tested. No user-facing route is wired by this slice.

## RESULT
HOLD pending canonical GitHub Actions gate. Local/static candidate checks PASS; candidate is not authoritative until canonical CI fully succeeds.

## NEXT only if PASS
Continue P17 from P17.9 authoritative baseline with exactly one next chart-engine slice. Do not enter P18 until P17 receives explicit system closure.

## KAIROS CLAUDE STATUS HANDOFF ready to copy-paste
P17.8 is authoritative after GitHub Actions Run #179 / 33736849316 PASS. P17.9 candidate adds the exact `lightweight-charts@5.2.1` runtime dependency and a production package binding that feeds `createChart`, `LineSeries`, and `CandlestickSeries` into the existing P17.6 injected module contract. P17.8 continues to own incremental `series.update()` mapping. No P16 live-feed wiring, candle aggregation, journal mutation, persistence, calculations, P18 drawings, navigation, or motion ownership is introduced. Dedicated P17.9 static verifier PASS and P17.8 regression verifier PASS locally. Full npm/build/Vitest could not run locally because registry DNS is unavailable. Canonical GitHub gate must decide authority. HOLD until that gate passes.
