# KAIROS P12.6R1 — Journal History USER_HEAVY Performance Canary Test-Contract Repair

Date: 2026-09-02
Status: HOLD — pending canonical GitHub gate

## Authoritative base

This repair was rebuilt from the exact canonical P12.5 PASS artifact, not from failed P12.6.

- Base candidate: `KAIROS_P12_5_JOURNAL_STATUS_FILTER_UI_WIRING_CANDIDATE_2026-09-02.zip`
- Canonical PASS run: #63 / `33572884579`
- Canonical head: `3763a21fb1864a451938ccc236d35293054c4fd9`
- Candidate artifact: `9825638828`

P12.5 remains authoritative until this candidate passes its own canonical gate.

## Why P12.6 failed

P12.6 passed exact scope, deterministic install, and production build. The full unit run reached 317 passing tests plus one new failing canary. The canary queried journal cards with `getAllByRole('article')`, but production renders each history card as a native `<li>`, whose accessible role is `listitem`.

The failure was therefore a test-contract mismatch, not evidence of a production query, rendering, schema, repository, or performance-budget defect.

## R1 repair

P12.6R1 changes only the canary evidence layer:

1. Recreates the 10,500-trade USER_HEAVY fixture from the P12.5 PASS base.
2. Asserts the 100 rendered history cards by their real `listitem` role.
3. Retains the bounded 100-row initial-history check.
4. Retains an indexed status-filter transition to `closed` and a bounded 100-row result.
5. Retains explicit timing budgets: 5,000 ms for initial history render and 3,000 ms for the status-filter refresh.
6. Adds a static verifier that rejects the discarded `article` assertion and protects the indexed query owners.

## Exact scope from P12.5

Exactly four files are changed or added:

- `KAIROS_P12_6R1_JOURNAL_HISTORY_HEAVY_PERFORMANCE_CANARY_TEST_CONTRACT_REPAIR_REPORT_2026-09-02.md`
- `package.json`
- `scripts/verify-p12-journal-history-heavy-performance.mjs`
- `tests/journal-history-performance.test.tsx`

## Protected boundaries

No production source file changes.

No schema or migration changes.
No repository changes.
No Calculation Brain changes.
No P13 Visual P&L work.
No direct UI-to-IndexedDB write path.
No React/application-memory journal filtering.
No timers, observers, animation loops, persistent listeners, or new runtime performance machinery.

The production query owner remains `src/application/journal/historyQuery.ts`, which delegates unfiltered history to `listRecentByUpdatedAt(limit)` and status history to `listRecentByStatusAndUpdatedAt(status, limit)`.

## USER_HEAVY canary contract

- Fixture: 10,500 trades.
- Default journal history window: 100 rows.
- Status-filter history window: 100 rows.
- Initial render/query budget: < 5,000 ms.
- Status-filter refresh budget: < 3,000 ms.
- Production card semantics: `listitem`.

The budgets are regression canaries rather than device benchmarks. The canonical GitHub gate remains the release authority.

## Verification

Static P12.6R1 verifier: PASS.

Relevant historical P12 verifiers executed locally and PASS:
- P12.2 indexed bounded history
- P12.3R1 route repair
- P12.4 indexed status filter
- P12.4R2 backup compatibility regression repair
- P12.4R3 historical verifier compatibility repair
- P12.4R4 package verifier registration integrity (70 `verify:p*` registrations)
- P12.5 status filter UI wiring

Dependency-backed local build/unit evidence is unavailable in this container: the preserved canonical source contains no installed dependencies, a build therefore reported missing development type/module packages, and a clean `npm ci --ignore-scripts` attempt timed out before completion. A broad local `verify:p*` sweep was also terminated by the container timeout before completion. These are environment/incomplete-execution results, not canonical product failures.

The canonical GitHub gate must therefore perform the authoritative clean `npm ci`, production build, full unit suite, complete `verify:p*` sweep, P12.6R1 static verifier, and explicit USER_HEAVY timing canary.

## Gate result

HOLD pending canonical GitHub Actions gate.
