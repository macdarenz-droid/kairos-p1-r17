# KAIROS P18.10R1 — Lightweight Charts v5 Trend-Line Drawing-Layer Type Contract Repair

## Authority
Base: canonical P18.9.
Failed P18.10 run #207 is evidence only and is not an authority base.

## Failure evidence
Canonical run #207 reached deterministic install and exact Lightweight Charts 5.2.1 dependency proof, then failed at production TypeScript compilation:

`lightweightChartsV5TrendLineDrawingLayerComposition.ts(23,17): TS2739: LightweightChartsV5SeriesApi<unknown> is missing attachPrimitive, detachPrimitive`

The failure is in the P18.10 composition type boundary. The P18.9 binding intentionally exposes provider series through the narrower existing series API, while P18.4 requires a narrow primitive lifecycle structural surface.

## Repair
P18.10R1 keeps P18.9 unchanged and repairs only the new P18.10 composition boundary:
- resolve the provider series through the existing P18.9 binding;
- adapt it locally to P18.4's `LightweightChartsV5SeriesPrimitiveApi` structural surface;
- fail closed if `attachPrimitive` or `detachPrimitive` is absent;
- explicitly bind the P18.4 driver generic to the P18.7 trend-line primitive type;
- add a regression test for fail-closed provider series without primitive lifecycle methods.

## Ownership preserved
- P18.3 remains provider-neutral drawing-layer lifecycle owner.
- P18.4 remains provider primitive attach/detach owner.
- P18.8 remains primitive factory owner.
- P18.9 remains neutral-handle -> provider-series identity owner.
- P18.10R1 owns only composition/adaptation of those established boundaries.

## Non-scope
No hit testing, pointer/crosshair capture, drag/edit state, toolbar, persistence, autoscale ownership, calculations, market acquisition, journal truth, or P19 behavior.

## Local evidence
- Dedicated P18.10 static verifier: PASS after repair.
- Local deterministic dependency/typecheck attempt did not complete within the container execution window; no local typecheck/build/Vitest PASS is claimed.
- Canonical GitHub gate remains authoritative.
