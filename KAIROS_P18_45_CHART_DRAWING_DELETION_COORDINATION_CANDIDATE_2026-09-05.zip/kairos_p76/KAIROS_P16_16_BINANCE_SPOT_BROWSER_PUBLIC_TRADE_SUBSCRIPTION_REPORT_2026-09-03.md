# KAIROS P16.16 — BINANCE SPOT BROWSER PUBLIC TRADE SUBSCRIPTION

## OBJECTIVE
Compose the already-canonical P16.12 browser WebSocket transport, P16.13 lifecycle connector, and P16.9 public trade subscription into one browser-ready Binance Spot public trade entry point.

## RESEARCH
Current official Binance Spot WebSocket documentation confirms raw stream form `/ws/<streamName>`, lowercase stream symbols, 24-hour connection lifetime, `serverShutdown` before shutdown, and the requirement to establish a new connection promptly. Public market data remains available without authentication. P16.16 does not alter those semantics.

## OWNER TRACE
- P16.1 owns Binance trade stream naming.
- P16.3 owns endpoint semantics.
- P16.9 owns public trade subscription composition and receipt-time injection.
- P16.12 solely owns native browser `WebSocket` construction/event forwarding.
- P16.13 owns translation of transport lifecycle evidence into the P15 connection-state machine.
- P15 owns reconnect policy, scheduling, jitter, attempt limits, and cancellation.
- P16.16 only composes P16.9 + P16.12 + P16.13 into a browser-ready subscription entry point.

## CHANGE
Added `subscribeBinanceSpotBrowserPublicTradeStream`, dedicated verifier, runtime tests, package script, barrel export, and this report.

## NON-SCOPE
No reconnect execution, retry policy, timer ownership, wall-clock acquisition, randomness, persistence, chart/P17 behavior, journal mutation, credentials, account access, or order execution.

## DATA/STATE FLOW
instrument + handlers + receiptTimestamp -> P16.16 composition -> P16.9 subscription -> P16.3 endpoint -> P16.13 lifecycle-decorated P16.12 browser connector -> trade delivery / P15 lifecycle callbacks.

## PERSISTENCE
None.

## SECURITY
Public read-only market stream only. No keys, secrets, account data, or execution APIs.

## OFFLINE
Failure/unavailability of the online stream does not alter local journal ownership or persistence.

## PERFORMANCE
O(1) composition per subscription; no polling, repeated journal parsing, or additional observers.

## TESTS
Dedicated runtime contract covers browser transport creation, connecting/live lifecycle, trade delivery with caller-owned receipt timestamp, idempotent close delegation, invalid venue preflight, and transport error forwarding.

## KNOWN LIMITATION
P16.16 intentionally does not integrate the P16.15 serverShutdown reconnect execution into the browser-ready subscription lifecycle. That remains the final dependency-safe P16 closure slice.

## RESULT
CANDIDATE — canonical gate required.
