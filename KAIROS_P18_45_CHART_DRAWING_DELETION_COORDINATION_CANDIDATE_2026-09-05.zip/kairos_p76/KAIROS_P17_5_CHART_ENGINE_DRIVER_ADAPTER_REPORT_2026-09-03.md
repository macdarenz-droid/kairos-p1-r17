# KAIROS P17.5 — Chart Engine Driver Adapter

## OBJECTIVE
Add the last provider-neutral adapter seam before concrete Lightweight Charts integration.

## RESEARCH
TradingView Lightweight Charts 5.2.1 remains the current public release. Version 5 uses unified `addSeries`, series-specific definitions, `setData`, `removeSeries`, and irreversible chart `remove()`. Official guidance notes that `setData` replaces the full series and is not recommended for incremental real-time updates; P17.5 does not add live updates.

## OWNER TRACE
P17.1R2 owns ChartRenderModel semantics.
P17.2 owns renderer lifecycle.
P17.3 owns presentation-only numeric/time projection.
P17.4 owns projected renderer composition through ChartEnginePort.
P17.5 adapts a concrete-library-shaped injected driver into ChartEnginePort.
P11, P15/P16, and journal/domain ownership remain unchanged.

## CHANGE
- defines a narrow ChartEngineDriver shape
- maps price-line and candle projections to driver-owned visual series
- removes the prior visual series before a kind replacement
- delegates final destruction once to chart.remove()
- rejects replacement after destruction
- adds dedicated tests and verifier

## DATA / STATE FLOW
ChartRenderModel -> P17.3 projection -> P17.4 ChartEnginePort -> P17.5 injected driver.
No reverse flow exists.

## PERFORMANCE
P17.5 models whole-series replacement only because P17 currently has no authoritative incremental chart-update contract. It does not claim this is the final real-time update strategy. Official Lightweight Charts guidance recommends `update()` for incremental data; that must be introduced only after Kairos owns an explicit incremental presentation contract.

## NON-SCOPE
No `lightweight-charts` dependency.
No direct vendor import.
No live-feed wiring.
No historical candle acquisition.
No execution markers.
No drawings/P18.
No persistence, calculations, timers, navigation, or motion changes.

## RESULT
Local verifier/static checks below. Canonical CI decides authority.
