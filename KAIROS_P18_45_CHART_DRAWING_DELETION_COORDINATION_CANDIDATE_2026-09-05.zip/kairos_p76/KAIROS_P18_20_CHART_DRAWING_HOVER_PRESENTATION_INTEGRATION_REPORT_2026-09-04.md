# KAIROS P18.20 — Chart Drawing Hover Presentation Integration

## Controlled base
Canonical P18.19 PASS, GitHub Actions run #223 / 33858317732.

## Proven missing responsibility
P18.19 explicitly left presentation-session integration out of scope. The authoritative source therefore had a complete provider-neutral hover lifecycle and provider composition, but no lifecycle coordination between that hover session and the already-owned P18.11 chart/drawing presentation session.

## Responsibility added
P18.20 extends the existing P18.11 presentation lifecycle owner with an optional hover binding. On each replace, the hover session attaches to the exact freshly-created series handle and the exact renderer drawing snapshot after drawing-layer setup. On replacement/destroy, hover detaches before drawing-layer destruction and series removal. Partial hover-attachment failure cleans up drawing and series resources before rethrowing.

## Ownership preserved
- P18.11 remains the sole presentation resource ordering/cleanup owner.
- P18.18 remains the provider-neutral hover lifecycle owner.
- P18.19 remains the Lightweight Charts v5 hover-port composition owner.
- P18.17/P18.16/P18.15/P18.14 retain provider resolution/subscription/projection ownership.
- P18.20 adds no provider API implementation and no second drawing/hover truth owner.

## Explicit non-scope
No direct crosshair APIs, hoveredObjectId projection, click selection, drag/edit, drawing truth mutation, persistence, calculations, market acquisition, journal truth, toolbar state, navigation state, autoscale policy, P19 Risk/Reward behavior, dependency migration, or phase jump.

## Changed-file contract
Exactly six files relative to canonical P18.19:
1. `KAIROS_P18_20_CHART_DRAWING_HOVER_PRESENTATION_INTEGRATION_REPORT_2026-09-04.md`
2. `package.json`
3. `scripts/verify-p18-20-chart-drawing-hover-presentation-integration.mjs`
4. `src/features/chart/chartDrawingPresentationPort.ts`
5. `src/features/chart/index.ts`
6. `tests/chart-drawing-hover-presentation-integration.test.ts`
