# KAIROS P16.7R3 — Binance Spot Public Stream Trade Message Timestamp Expectation Repair

## BASE
P16.6 remains authoritative. P16.7, P16.7R1, and P16.7R2 are failed and non-authoritative.

## CANONICAL FAILURE
Run #154 proved build PASS and 490/491 tests PASS. The only failure was the new P16.7 composition test's expected `sourceTimestamp`.

Input trade time:
`T = 1672515782136`

The existing P16.2 mapper uses `new Date(epochMs).toISOString()`, producing:
`2022-12-31T19:43:02.136Z`

The R2 test incorrectly expected:
`2023-01-01T00:03:02.136Z`

## REPAIR
Changed only the test expectation to the actual UTC ISO instant produced by the authoritative P16.2 mapper:
`2022-12-31T19:43:02.136Z`

No production source, mapping semantics, lifecycle, networking, persistence, UI, chart, or journal truth changed.

## LOCAL
P1 static and P16.1-P16.7 verifiers pass.

## RESULT
HOLD pending upload and canonical repair gate.
