# KAIROS P11.11 Leverage Calculator Primitive Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.10 authoritative PASS from controlled gate run #29.

## Objective
Add the protected `LeverageCalculator` arithmetic primitive named by the locked P0 Calculation Engine architecture without introducing the forbidden naive `P&L x leverage` model or deriving market-specific exposure/equity semantics.

## Controlling basis
The handoff names `LeverageCalculator` as a protected Calculation Engine owner and explicitly states:
- market/instrument-specific policies sit below the common Calculation Engine;
- leverage must not be treated as a naive universal `P&L x leverage` rule;
- missing financial evidence must never silently become zero.

P11.11 therefore owns only:
`authoritative exposure / authoritative equity`

Both inputs must already be canonical DecimalString evidence supplied by an upstream account/market policy owner.

## Owner trace
Future account/instrument evidence
-> P11.9 MarketSpecificCalculationPolicy boundary
-> P11.1R2 decimal kernel
-> P11.11 LeverageCalculator primitive
-> future planning/risk consumers.

## Result contract
- valid arithmetic -> canonical DecimalString leverage ratio
- zero equity -> explicit `zero-equity`
- malformed decimal evidence -> explicit `invalid-decimal`

## Precision
All arithmetic routes through the authoritative decimal kernel.
No JavaScript Number, parseFloat, parseInt, Math arithmetic, new dependency, or hidden rounding policy is introduced.

## Zero / missing semantics
A genuine zero exposure may produce leverage `0`.
Missing exposure/equity is not represented as zero by this primitive.
Zero equity is an explicit error; no Infinity/NaN or invented leverage is produced.

## Why exposure and equity are not derived here
Exposure can require instrument-specific valuation rules, contract multipliers, quote/account currency conversion, or other market semantics.
Equity belongs to an account-capital owner not yet introduced in the roadmap.
P11.11 accepts only already-authoritative evidence and does not create those owners prematurely.

## Non-scope
No P&L multiplication.
No margin formula.
No exposure derivation.
No account-equity derivation.
No contract/tick/lot handling.
No FX/currency conversion.
No concrete market policy.
No TradeMetrics wiring.
No position-size wiring.
No UI, persistence, schema, journal history, activation, market API, or network changes.

## Persistence / security / theme / offline
Pure synchronous calculation. No persistence, network, secrets, theme, or platform impact.

## Performance
Constant-time one-operation decimal calculation.

## Tests
Covers standard leverage, exact decimals, genuine zero exposure, zero equity, malformed inputs, and negative evidence without hidden normalization.

## Result
HOLD until canonical GitHub gate passes deterministic install, build, full unit regression, P1-P10.3R2 regressions, P11.1R2-P11.10 regressions, and P11.11 verification.
