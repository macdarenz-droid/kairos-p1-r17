# KAIROS P17.12 — Incremental Chart Engine Driver Composition

## OBJECTIVE
Connect the already-approved P17.7 incremental engine contract and P17.8 Lightweight Charts v5 `series.update()` mapping to a driver-backed Kairos chart engine session while preserving active series identity for latest/new-item presentation updates.

## AUTHORITATIVE BASE
P17.11 Responsive Chart Sizing Boundary — canonical PASS, GitHub Actions Run #183 / Run ID 33742964042.

## RESEARCH
TradingView Lightweight Charts v5.2 documents `ISeriesApi.setData()` as full data replacement and `ISeriesApi.update()` as the latest/new-item path. Official guidance warns against repeated `setData()` for real-time updates because it replaces the entire series and can significantly affect performance.

## CHANGE
- Extended the narrow driver series handle with typed latest/new update operations.
- Added `createIncrementalChartEnginePortFromDriver()` as a separate incremental adapter.
- Same-kind `updateLatest()` reuses the active series handle.
- Lightweight Charts v5 handle update operations map to vendor `series.update()`.
- Cross-kind updates fail closed rather than mutating or silently replacing the wrong series.
- Existing full `replaceSeries()` behavior remains explicit and available.

## NON-SCOPE
No live feed subscription, Binance changes, candle aggregation, persistence, journal mutation, calculations, drawings, markers, navigation, theme ownership, or P18 work.

## OWNERSHIP
P16 remains market acquisition owner. P17.12 consumes only already-projected presentation updates. The chart engine owns presentation resources only.

## RESULT
Candidate prepared for canonical GitHub gate. Local verifier/runtime/type/build evidence must not be treated as canonical PASS.
