# KAIROS PATCH REPORT

Patch: P13.6 — Visual P&L Day-Bucket Semantics Boundary
Base: P13.5R1 canonical PASS, Run #82, gate SHA 2fb4885fa4bec4e004c966a602a1b50df0f5363d

## OBJECTIVE
Define one deterministic and explicit calendar-day projection before any day aggregation, calendar, or heatmap UI is introduced.

## EVIDENCE / RESEARCH
Kairos backup validation accepts trade timestamps only when `Date.parse(value)` succeeds and `new Date(parsed).toISOString() === value`, establishing canonical UTC instants at the persistence boundary.

Current JavaScript internationalization documentation confirms that `Intl.DateTimeFormat` accepts an explicit `timeZone`, including IANA identifiers, and `formatToParts()` exposes structured year/month/day components. This avoids locale-string parsing and avoids runtime default-zone dependence.

## DECISION
A realized Visual P&L day is based on `TradeRecord.closedAt`, because P13 Visual P&L represents realized trade outcome. Day projection requires a caller-supplied time-zone policy. P13.6 does not choose or persist the user's timezone.

## CHANGE
- Add `projectVisualPnlDayKey(closedAt, timeZone)`.
- Require canonical stored close timestamp.
- Require explicit time-zone input; invalid zones block.
- Use ISO-8601 calendar + Latin numeric parts + `formatToParts`.
- Return immutable `YYYY-MM-DD` key with `basis: closed-at`.
- Add focused tests and verifier.
- Export the new projection API.

## NON-SCOPE
No day aggregation, no database query, no timezone preference persistence, no device-zone fallback, no calendar/heatmap UI, no equity curve, no streaks, no FX, and no financial arithmetic.

## OWNERSHIP
Stored UTC instant remains trade-domain/persistence evidence.
Caller owns timezone policy.
P13.6 owns only deterministic calendar-day projection.
P13.5R1 remains the monetary aggregation owner for comparable Visual P&L projections.

## EDGE CASES
- Missing close time -> blocked.
- Non-canonical timestamp -> blocked.
- Invalid time zone -> blocked.
- Explicit zones may map the same instant to different day keys.
- DST is delegated to the runtime's standards-based time-zone database through Intl.

## PERFORMANCE
O(1) per trade. No database scan or repeated journal parsing introduced.

## RESULT
HOLD pending canonical GitHub gate.

## NEXT
Only after PASS: compose Journal History entries into explicit day buckets using the caller-owned timezone policy, then apply P13.5R1 aggregation within each bucket.
