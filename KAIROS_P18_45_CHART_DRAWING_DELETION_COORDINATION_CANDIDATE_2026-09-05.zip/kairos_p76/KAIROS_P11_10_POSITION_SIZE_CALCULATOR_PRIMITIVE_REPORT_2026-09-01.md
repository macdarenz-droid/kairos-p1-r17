# KAIROS P11.10 Position Size Calculator Primitive Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.9 authoritative PASS from controlled gate run #28.

## Objective
Add the protected `PositionSizeCalculator` arithmetic primitive named by the locked P0 Calculation Engine architecture without deriving market-specific risk inputs.

## Controlling basis
The handoff names `PositionSizeCalculator` as a protected Calculation Engine owner and requires market/instrument-specific policies below the common Calculation Engine. Missing financial evidence must never silently become zero.

P11.10 therefore owns only:
`riskBudget / riskPerUnit`

Both inputs must already be authoritative canonical decimal evidence from an upstream risk/policy owner.

## Owner trace
P9 DecimalString
-> future risk-budget / market-specific risk-per-unit evidence
-> P11.1R2 decimal kernel
-> P11.10 PositionSizeCalculator primitive
-> future market policy integration
-> future position-planning UI/Coach consumers.

## Result contract
- valid arithmetic -> canonical DecimalString position size
- zero risk-per-unit -> explicit `zero-risk-per-unit`
- malformed decimal evidence -> explicit `invalid-decimal`

## Precision
All arithmetic routes through the authoritative P11.1R2 decimal division.
No Number, parseFloat, parseInt, Math arithmetic, rounding policy, or new dependency is introduced.

## Missing-data / zero semantics
A genuine zero risk budget may legitimately calculate to zero position size.
Missing risk budget or missing risk-per-unit is not represented as zero by this primitive.
Zero risk-per-unit is an explicit error, never infinity, NaN, or an invented size.

## Why this does not derive risk-per-unit
P11.8 owns only absolute entry-to-stop price distance. Price distance is not universally monetary risk-per-unit across futures, forex, CFDs, options, or other instruments. P11.9 now provides the explicit market-specific policy boundary that future implementations must use.

## Non-scope
No market policy implementation.
No price-distance conversion.
No tick value, contract multiplier, lot-size or FX handling.
No leverage.
No TradeMetrics wiring.
No plannedQuantity mutation.
No rounding to tradable lot/tick constraints.
No UI, persistence, schema, journal history, activation, market API, or network changes.

## Persistence / security / theme / offline
Pure synchronous calculation only. No persistence, network, secret, theme, or platform impact.

## Performance
Constant-time one-operation decimal calculation.

## Tests
Covers normal sizing, exact decimals, genuine zero budget, zero risk-per-unit, malformed inputs, and negative evidence without hidden normalization.

## Result
HOLD until canonical GitHub gate passes deterministic install, build, full unit regression, P1-P10.3R2 regressions, P11.1R2-P11.9 regressions, and P11.10 verification.
