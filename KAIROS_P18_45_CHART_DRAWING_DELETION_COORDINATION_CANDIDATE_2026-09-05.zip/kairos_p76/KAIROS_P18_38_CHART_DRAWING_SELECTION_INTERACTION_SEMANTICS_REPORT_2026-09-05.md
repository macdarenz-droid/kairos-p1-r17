# Kairos P18.38 — Chart Drawing Selection Interaction Semantics

Authority: canonical P18.37 PASS #243, run 33946200300, head c1f165e301f4d1367c1f5350405ac709ffc6d446.

## Responsibility
P18.38 extends the existing provider-neutral interaction state machine with explicit selected-drawing semantics before provider click-selection wiring.

- P18.21 remains the interaction-state vocabulary owner and now includes `selected` with exact `drawingId`.
- P18.22 remains the interaction-event vocabulary owner and now includes `select-drawing`.
- P18.23 remains the sole transition-semantics owner: idle may select a drawing, selected may switch drawing, and edit/delete may start only when the requested identity matches the current selection.
- P18.24 remains the sole ephemeral current-state/dispatch owner; no second selection store is introduced.

This closes the prior unsafe semantic gap where edit/delete could begin directly from idle with arbitrary caller-supplied drawing identity.

## Current provider evidence
Current official Lightweight Charts 5.2 documentation confirms click handlers receive `MouseEventParams`; drawing-object identity remains available through mouse-event hover identity (`hoveredInfo.objectId`, with `hoveredObjectId` retained as deprecated compatibility). That provider-specific projection/subscription wiring is deliberately deferred to a later controlled slice.

## Non-scope
No provider APIs, click subscription changes, hover changes, collection mutation, drawing construction/identity allocation, presentation lifecycle, drag coordinate mutation, delete execution, persistence/restore, toolbar/UI, undo/redo, new drawing kinds, journal truth, calculations, navigation, or P19 Risk/Reward semantics.

## Controlled scope
Exactly eight files versus authoritative P18.37:
1. `KAIROS_P18_38_CHART_DRAWING_SELECTION_INTERACTION_SEMANTICS_REPORT_2026-09-05.md`
2. `package.json`
3. `scripts/verify-p18-38-chart-drawing-selection-interaction-semantics.mjs`
4. `src/features/chart/chartDrawingInteractionContract.ts`
5. `src/features/chart/chartDrawingInteractionEvent.ts`
6. `src/features/chart/chartDrawingInteractionReducer.ts`
7. `tests/chart-drawing-interaction-reducer.test.ts`
8. `tests/chart-drawing-selection-interaction.test.ts`
