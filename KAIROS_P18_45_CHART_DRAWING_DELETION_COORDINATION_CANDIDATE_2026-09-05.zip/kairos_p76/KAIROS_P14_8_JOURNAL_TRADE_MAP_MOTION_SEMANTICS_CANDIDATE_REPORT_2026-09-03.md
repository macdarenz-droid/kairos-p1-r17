# KAIROS P14.8 Journal Trade Map Motion Semantics — Candidate Report — 2026-09-03

## Patch / Base / App / Build Identity
- Patch: P14.8 — Journal Trade Map Motion Semantics
- Authoritative base: KAIROS_P14_7R4_JOURNAL_TRADE_MAP_ARCHIVE_SCOPE_REPAIR_CANDIDATE_2026-09-03.zip
- App: Kairos Trading Journal
- Build identity: 0.1.0

## OBJECTIVE
Add one non-essential presentation motion cue to the existing Trade Map without inventing market movement, execution state, price geometry, or financial truth. Only already-authoritative executed exits receive the reveal.

## RESEARCH
- MDN `prefers-reduced-motion`: widely available and intended to reduce or replace non-essential motion when the user has expressed that system preference.
- MDN CSS animation/SVG accessibility guidance: blinking/flashing and motion can create accessibility problems; reduced-motion accommodation should be provided.
- Existing Kairos P2 accessibility owner already globally collapses animation duration to `--kairos-motion-instant` and iteration count to one under `prefers-reduced-motion: reduce`.

## OWNER TRACE
- Trade facts: `projectJournalTradeVisualizer` / P14 projection owner.
- Executed-exit identity: existing `TradeVisualizerLevel.kind === 'executed-exit'`.
- Exact execution time: existing `executedAt` fact rendered by P14.7.
- Motion: CSS presentation only in `journalRoute.css`.
- Reduced motion: existing P2 `src/design-system/accessibility.css` owner.

## PRE-CHANGE FLOW
Persisted journal evidence -> P12 journal entry -> P14 projection -> JournalTradeMap / JournalTradeMapGraphic -> exact HTML + supplementary categorical SVG.

## CHANGE
- Added an opacity-only, one-shot executed-exit reveal to the SVG executed-exit group and matching HTML fact row.
- Uses registered `--kairos-motion-normal` token.
- Reuses the existing global reduced-motion accessibility contract.
- Added P14.8 static verifier and targeted runtime contract test.

## NON-SCOPE
No new persistence, market data, current price, candles, path simulation, price scaling, calculations, P&L, FX, timers, React state, requestAnimationFrame, or synthetic event ownership.

## DATA / STATE FLOW
Unchanged. Motion derives only from already-rendered `data-level-kind="executed-exit"` presentation markup.

## PERSISTENCE
None.

## SECURITY
No network, executable remote content, secrets, or storage changes.

## THEME
No raw colors or unregistered spacing. Uses existing semantic presentation and registered motion token.

## OFFLINE
Fully local CSS presentation; no network dependency.

## TESTS
- New static verifier: `verify:p14:8-journal-trade-map-motion-semantics`.
- New runtime: `tests/journal-trade-map-motion-semantics.test.tsx`.
- Existing P14.7/P14.6/P14.5/P14.4 and P2 contracts are retained for regression.

## REGRESSION
Protected exact prices, timestamps, accessible SVG semantics, marker shapes, Not-to-scale disclosure, design-system ownership, and reduced-motion behavior.

## PERFORMANCE
One opacity-only single-pass animation on executed exits; no JS animation loop, observer, timer, or repeated work.

## KNOWN LIMITATIONS
This is presentation-only. It does not animate historical price paths or indicate when a trade will exit. Motion begins when the already-authoritative rendered view appears.

## REAL-DEVICE STATUS
Not run on a physical device in this environment.

## LOCAL VERIFICATION STATUS
- PASS: `verify:p2:design-system`.
- PASS: `verify:p14:7-journal-trade-map-execution-time`.
- PASS: `verify:p14:8-journal-trade-map-motion-semantics`.
- Runtime/build verification was not completed locally because this extracted candidate has no `node_modules` and `npm ci` could not complete in the current container session. No runtime/build PASS is claimed.

## RESULT
HOLD until canonical GitHub gate completes.

## NEXT
Only after canonical PASS: continue to the next dependency-safe P14 visualizer slice.
