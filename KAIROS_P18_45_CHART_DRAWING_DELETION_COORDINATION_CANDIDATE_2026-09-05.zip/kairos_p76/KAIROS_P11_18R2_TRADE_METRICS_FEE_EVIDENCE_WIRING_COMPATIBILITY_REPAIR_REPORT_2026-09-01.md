# KAIROS P11.18R2 — TradeMetrics Fee Evidence Wiring Compatibility Repair

Status: HOLD pending canonical GitHub gate.

## Authoritative base
P11.17R1 Fee Currency Evidence Repair. P11.18 and P11.18R1 are failed/discarded and are not bases.

## Repair objective
Preserve the P11.18 fee-evidence wiring while migrating the single legacy P11.5 deep-equality expectation identified by GitHub run #42.

## Functional contract
- Missing fee evidence remains `totalFees: null`, `totalFeesCurrency: null`, `hasTotalFees: false`.
- Explicit empty fee evidence remains authoritative zero fees with null currency and `hasTotalFees: true`.
- Same-currency fees preserve exact decimal aggregation and currency evidence.
- Mixed-currency fees fail explicitly.
- Invalid fee decimals fail explicitly.
- `netPnl` remains unresolved; no FX conversion or monetary comparability inference is introduced.

## Compatibility repair
`tests/trade-metrics.test.ts` now expects `totalFeesCurrency: null` for the empty-trade result. This is a legacy expectation migration only; it does not change runtime behavior beyond the already-scoped P11.18 fee evidence field.

## Controlled changed files
1. `KAIROS_P11_18R2_TRADE_METRICS_FEE_EVIDENCE_WIRING_COMPATIBILITY_REPAIR_REPORT_2026-09-01.md`
2. `package.json`
3. `scripts/verify-p11-trade-metrics-fee-evidence.mjs`
4. `scripts/verify-p11-trade-metrics-risk-evidence.mjs`
5. `scripts/verify-p11-trade-metrics.mjs`
6. `src/domain/calculations/tradeMetrics.ts`
7. `tests/trade-metrics-fee-evidence.test.ts`
8. `tests/trade-metrics.test.ts`

## Regression intent
Canonical gate must run deterministic install, production build, full unit regression, all prior P1–P11.17R1 verifiers, and the P11.18R2 fee-evidence verifier.
