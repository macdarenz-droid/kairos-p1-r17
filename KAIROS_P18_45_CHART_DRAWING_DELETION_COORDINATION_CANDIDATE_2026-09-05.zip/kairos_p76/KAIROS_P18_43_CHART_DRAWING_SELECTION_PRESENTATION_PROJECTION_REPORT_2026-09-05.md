# KAIROS P18.43 — Chart Drawing Selection Presentation Projection

## Authority
Built directly from canonical P18.42, Kairos Controlled Roadmap Gate #249 / run 33952053423 / head `ac5b83b2debf592f8a14d98e0d12dd7905e94b41`.

## Proven missing responsibility
Canonical P18.42 closes provider-click selection lifecycle into the existing P18.24 interaction session, and the P18.38 interaction vocabulary already carries `selected`, `editing`, and `deleting` states. Current production source has no provider-neutral boundary that turns those authoritative interaction states into current renderer selection-presentation evidence. Starting drag/edit/delete execution before that seam would force later UI/provider code to read interaction state and renderer snapshots independently, creating a likely second selection/presentation owner.

## Added responsibility
P18.43 adds one provider-neutral projection:

- input: the caller-supplied current immutable `RendererChartDrawing[]` snapshot plus the authoritative P18.24 interaction state;
- accepted states: `selected`, `editing`, and `deleting` only;
- output: the exact current renderer drawing plus the matching presentation mode;
- stale selected identity: fail closed with `null` when the interaction drawing ID is absent from the current renderer snapshot;
- all non-selection interaction states: `null`.

## Ownership preserved
- P18.2/P18.36 remain the sole drawing truth -> renderer drawing projection owners.
- P18.23 remains the sole interaction transition owner.
- P18.24 remains the sole active interaction-state/dispatch owner.
- P18.33 remains the sole committed in-memory drawing collection owner.
- P18.39 remains provider primitive hit + current renderer snapshot -> selection evidence owner.
- P18.41/P18.42 remain selection dispatch/lifecycle composition owners.
- P18.43 owns only authoritative interaction state + already-projected current renderer snapshot -> selection-presentation projection.

## Research disposition
No external API research was required. This slice is provider-neutral and composes only canonical Kairos contracts.

## Explicit non-scope
Documentation carry-forward: `docs/KAIROS_ARCHITECTURE_MAP.md` preserves the user-requested ownership audit and adds canonical P18.42 after PASS #249; this is descriptive evidence only and does not create P18.43 production ownership.

No provider styling or Canvas changes; no selection color/handle design; no drawing truth or renderer coordinate projection; no interaction dispatch/reducer changes; no provider click/crosshair subscription; no collection mutation; no edit/drag/delete execution; no drawing-only presentation refresh wiring; no persistence/restore; no toolbar/UI; no new drawing kinds; no journal/calculation/navigation ownership; no Risk/Reward semantics and no P19.

## Local verification
PASS:
- dedicated P18.43 verifier;
- all `verify:p18:*` scripts through P18.43 (43/43);
- historical closure scripts P9 through P17 when run individually in the local closure sweep;
- P1 static contract / gate-result classifier: 207 source files, 17 pinned package versions;
- exact seven-file delta from canonical P18.42, where `docs/KAIROS_ARCHITECTURE_MAP.md` is documentation-only carry-forward from the post-P18.42 ownership audit;
- clean package has no `node_modules`, `dist`, coverage, or temporary build residue.

Local limitation:
- a clean `npm ci` did not complete within the local execution window, so local TypeScript, production build, Vitest/full-unit, and the full combined P1 release gate are not claimed for P18.43. Canonical GitHub Actions must establish them before promotion.
