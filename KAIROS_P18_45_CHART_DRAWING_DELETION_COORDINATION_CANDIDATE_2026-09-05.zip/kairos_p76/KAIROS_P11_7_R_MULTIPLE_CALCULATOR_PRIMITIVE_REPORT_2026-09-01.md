# KAIROS P11.7 R-Multiple Calculator Primitive Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.6 authoritative PASS from controlled gate run #25.

## Objective
Add the protected Calculation Engine `RMultipleCalculator` primitive from the locked P0 architecture without inventing initial-risk evidence or wiring incomplete TradeMetrics.

## Controlling architecture
The P0 handoff names `RMultipleCalculator` as a Calculation Engine module and defines `realizedR` plus `initialRisk` as optional derived metrics. It also locks:
- all financial arithmetic belongs to the Calculation Engine,
- missing financial data must never silently become zero,
- market/instrument-specific calculation policies must not be guessed.

P11.7 therefore owns only:
`resultAmount / initialRisk`

It does not decide how initial risk is derived.

## Owner trace
P9 DecimalString
-> P11.1R2 decimal kernel
-> P11.7 R-Multiple Calculator primitive
-> future RiskCalculator / market-specific policy
-> future TradeMetrics composition.

## Change
Adds `calculateRMultiple(resultAmount, initialRisk)`.

Result contract:
- valid arithmetic -> canonical DecimalString R multiple
- initial risk zero -> explicit `zero-initial-risk`
- malformed decimal evidence -> explicit `invalid-decimal`

## Precision
All arithmetic routes through the authoritative P11.1R2 decimal kernel.
No native Number, parseFloat, parseInt, or Math arithmetic is introduced.

## Missing-data / zero semantics
A genuine zero result can correctly produce `0R`.
Missing initial risk is not represented as zero by this primitive.
Zero initial risk is an error, never infinity, NaN, or an invented R value.

## Why TradeMetrics.realizedR remains null
P11.5 deliberately leaves `initialRisk` and `realizedR` null. Kairos does not yet have an authoritative RiskCalculator policy that can derive monetary initial risk across all supported/roadmapped instrument types. Wiring realizedR now would require inventing upstream risk evidence.

## Non-scope
No initial-risk derivation, TradeMetrics wiring, planned stop interpretation, position sizing, leverage, P&L policy, fees, FX/currency conversion, instrument multiplier, market adapter, UI, persistence, schema, journal history, activation, or network changes.

## Persistence / security / offline / performance
Pure synchronous calculation.
No storage, network, secret, platform, or theme surface.
Constant-time work with one decimal-kernel division.

## Tests
Covers positive R, negative R, true zero result, decimal precision, zero initial risk, malformed input, and negative denominator arithmetic without hidden normalization.

## Result
HOLD until canonical GitHub gate passes deterministic install, build, full unit regression, all P1-P10.3R2 regressions, P11.1R2-P11.6 regressions, and P11.7 verification.
