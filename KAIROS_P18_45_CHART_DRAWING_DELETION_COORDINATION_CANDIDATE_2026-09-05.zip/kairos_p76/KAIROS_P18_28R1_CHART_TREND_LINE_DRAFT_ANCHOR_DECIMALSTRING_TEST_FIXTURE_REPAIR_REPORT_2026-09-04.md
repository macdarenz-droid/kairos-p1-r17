# KAIROS P18.28R1 — Chart Trend-Line Draft Anchor DecimalString Test Fixture Repair

## Authoritative base
P18.27 Lightweight Charts v5 Drawing Click Binding Composition canonical PASS #232.

## Failed evidence repaired
Canonical P18.28 run #233 failed at production TypeScript compilation after exact scope, deterministic install, and exact `lightweight-charts@5.2.1` verification had passed.

Exact compiler evidence:
- `tests/chart-trend-line-draft-anchor-collection.test.ts(7,3)` — TS2322 plain `string` not assignable to branded `DecimalString`
- line 11 — same
- line 15 — same

This is a test-fixture/type-contract defect. There is no canonical evidence of a production P18.28 implementation defect.

## Repair
Rebuilds the intended P18.28 controlled slice from authoritative P18.27 and changes the test fixture so anchor prices are created through the existing authoritative trade-domain `parsePositiveDecimalString` parser. The `ChartDrawingAnchor` contract is not weakened and no cast is used to bypass the brand.

## Responsibility preserved
- P18.1 remains committed drawing-truth shape owner.
- P18.21 remains interaction-state shape owner.
- P18.22 remains interaction-event vocabulary owner.
- P18.23 remains interaction transition-semantics owner.
- P18.24 remains active interaction-session state/dispatch owner.
- P18.25R1 remains provider event/coordinate -> Kairos anchor projection owner.
- P18.26 remains provider click subscription lifecycle owner.
- P18.27 remains provider chart/series click binding composition owner.
- P18.28 remains only the ephemeral 0/1/2 trend-line draft-anchor evidence owner.

## Explicit non-scope
No provider APIs, interaction dispatch changes, drawing ID allocation, committed drawing construction/mutation, persistence, toolbar/UI state, selection/drag/edit/delete execution, undo/redo, new drawing kinds, Risk/Reward behavior/visuals, journal truth, calculations, navigation, dependency migration, or P19 work.

## Exact changed-file contract relative to canonical P18.27
Exactly six files:
1. `KAIROS_P18_28R1_CHART_TREND_LINE_DRAFT_ANCHOR_DECIMALSTRING_TEST_FIXTURE_REPAIR_REPORT_2026-09-04.md`
2. `package.json`
3. `scripts/verify-p18-28-chart-trend-line-draft-anchor-collection.mjs`
4. `src/features/chart/chartTrendLineDraftAnchorCollection.ts`
5. `src/features/chart/index.ts`
6. `tests/chart-trend-line-draft-anchor-collection.test.ts`

## Verification intent
The dedicated P18.28 verifier must remain PASS, predecessor P18 interaction/click verifiers must remain PASS, and the historical P1 static boundary must remain PASS. Canonical GitHub must prove deterministic install, production TypeScript/build, focused runtime tests, full unit regression, full controlled roadmap regression, P18/P17 regression chain, historical closures, candidate artifact, and gate evidence before promotion.

## Local verification actually completed
- exact six-file delta from authoritative P18.27 — PASS
- `verify:p18:28-chart-trend-line-draft-anchor-collection` — PASS
- P18.27, P18.26, P18.25R1, P18.24, P18.23, P18.22, P18.21 verifier regressions — PASS
- `verify:static` / historical P1 static contract — PASS

A clean `npm ci` + TypeScript/build/focused Vitest command was attempted, but the local execution transport timed out before a trustworthy completion result was returned. No local claim is made for deterministic install, TypeScript, build, or Vitest. Generated/partial dependency artifacts were removed before packaging. Canonical GitHub Actions must re-prove the failed TypeScript boundary and all required regression stages.

## Result
HOLD pending canonical GitHub gate. P18.27 remains authoritative until this repair passes canonically.
