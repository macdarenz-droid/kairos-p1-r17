# KAIROS P11.6 Percentage Calculator Primitive Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.5 authoritative PASS from controlled gate run #24.

## Objective
Add the protected Calculation Engine `PercentageCalculator` primitive required by the locked P0 financial-calculation architecture without choosing a trade-specific or market-specific P&L percentage policy.

## Research / controlling basis
The locked architecture names `PercentageCalculator` as a Calculation Engine module and separately requires market/instrument-specific calculation policies. It also requires missing financial data to remain missing rather than silently becoming zero.

P11.6 therefore owns only:
`numerator / denominator * 100`

It does not decide what a trading numerator or denominator should mean.

## Owner trace
P9 DecimalString
-> P11.1R2 decimal kernel
-> P11.6 Percentage Calculator primitive
-> future controlled financial calculators / market-specific policy
-> future TradeMetrics composition.

## Change
Adds `calculatePercentage(numerator, denominator)`.

Result contract:
- valid arithmetic -> canonical DecimalString percentage
- denominator zero -> explicit `zero-denominator`
- malformed decimal evidence -> explicit `invalid-decimal`

## Precision
All arithmetic routes through the authoritative P11.1R2 decimal kernel.
No native Number, parseFloat, parseInt, or Math arithmetic is introduced.

## Missing-data / zero semantics
A genuine zero numerator can correctly produce 0%.
A missing value is not represented as zero by this primitive.
A zero denominator is an error, never infinity, NaN, or an invented percentage.

## Why TradeMetrics.pnlPercent remains null
KAIROS has not yet locked a universal trading P&L percentage denominator or market-specific instrument policy. The P0 architecture explicitly warns against assuming one calculation model for every futures, forex, CFD, or other instrument.

P11.6 therefore provides arithmetic capability only. Wiring `TradeMetrics.pnlPercent` is deferred until its semantic policy is explicit.

## Non-scope
No TradeMetrics wiring, P&L policy, fee aggregation, net P&L, FX/currency conversion, initial risk, R-multiple, leverage, position sizing, instrument multiplier, market adapter, UI, persistence, schema, journal history, activation, or network changes.

## Persistence / security / offline / performance
Pure synchronous calculation.
No storage, network, secret, platform, or theme surface.
Constant-time work with two decimal-kernel operations.

## Tests
Covers positive, negative, true zero numerator, fractional decimal precision, zero denominator, malformed input, and negative denominator arithmetic.

## Result
HOLD until canonical GitHub gate passes deterministic install, build, full unit regression, all P1-P10.3R2 regressions, P11.1R2-P11.5 regressions, and P11.6 verification.
