# Kairos P1 Verification Report — R10
Date: 2026-08-31
Status: HOLD

## Authoritative base
P0 remains the latest PASS / LOCKED authoritative base. R10 is a P1 candidate only.

## Objective
Correct the portable CI gate so it can reach the authoritative P1 verifier without adding a network-dependent bootstrap step or assuming a lockfile exists before the gate checks it.

## Research-backed findings
- Current npm documentation defines `npm ci` as the frozen clean-install path and requires an existing lockfile.
- Current GitHub Node.js workflow documentation uses `actions/checkout@v6` and `actions/setup-node@v7`.
- Node.js 22.16.0 ships with npm 10.9.2, so installing npm globally in CI is unnecessary and creates an avoidable pre-gate network dependency.

## R9 defect found
The R9 CI workflow had two pre-gate hazards:
1. `cache: npm` expected a dependency lock path before P1 had a lockfile.
2. `npm install --global npm@10.9.2` required registry network access before the authoritative gate could classify infrastructure failure as HOLD.

Those steps could cause CI to fail outside the PASS/HOLD/FAIL owner.

## Controlled R10 corrections
- Updated workflow actions to current documented major versions: checkout v6, setup-node v7.
- Removed pre-gate npm dependency caching.
- Removed the network-dependent global npm installation.
- Added `verify-p1-toolchain.mjs` as a dependency-free exact toolchain check.
- `npm run verify:p1` now owns the full portable sequence:
  toolchain -> static contract -> frozen P1 gate.
- The workflow contains only environment setup and one call to that authoritative command.

## Ownership / flow
GitHub runner
-> setup Node 22.16.0 (bundles npm 10.9.2)
-> `npm run verify:p1`
-> exact toolchain verification
-> static architecture/scope contract
-> lockfile requirement
-> `npm ci`
-> typecheck
-> tests
-> production build
-> PASS / HOLD / FAIL

## Local evidence
- Exact toolchain verifier: PASS.
- Static P1 architecture/scope contract: PASS.
- Gate result classifier: PASS.
- Verification script syntax: PASS.
- Current container still cannot reach the npm registry and package-lock.json remains absent.

## Decision
HOLD. P0 remains authoritative. P2 remains locked.
