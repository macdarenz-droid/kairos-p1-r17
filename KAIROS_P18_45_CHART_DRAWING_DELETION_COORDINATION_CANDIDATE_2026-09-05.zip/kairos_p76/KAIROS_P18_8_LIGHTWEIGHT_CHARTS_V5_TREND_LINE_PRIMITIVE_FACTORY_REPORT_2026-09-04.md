# KAIROS P18.8 — Lightweight Charts v5 Trend-Line Primitive Factory

## Authority
Built directly from canonical P18.7 after GitHub Actions run #204 (`33765430967`) completed successfully at head `d3b761b992cd0681c4ca482f2ef6cdc42af0fec1`.

## Controlled purpose
Bind the already-canonical P18.7 trend-line primitive/view composition to the generic P18.4 `LightweightChartsV5DrawingPrimitiveFactory` seam. P18.8 supplies only the factory needed by the existing P18.4 replacement lifecycle and snapshots injected presentation stroke style.

## Production ownership
`lightweightChartsV5TrendLinePrimitiveFactory.ts` owns only primitive construction. P18.4 remains primitive attach/detach lifecycle owner; P18.5 remains time/price-to-screen projection owner; P18.6 remains Canvas pane-rendering owner; P18.7 remains primitive/view lifecycle composition owner.

## Official API evidence
Current Lightweight Charts 5.2 documentation defines series drawings as `ISeriesPrimitive` implementations attached/detached through `ISeriesApi.attachPrimitive()` / `detachPrimitive()`. Its primitive lifecycle provides pane views plus `attached`, `detached`, and `updateAllViews`. P18.8 does not duplicate those provider responsibilities; it only supplies fresh P18.7 primitive instances to the already-canonical P18.4 factory seam.

## Explicit non-scope
No provider series resolver, no `attachPrimitive`/`detachPrimitive` mapping, no Canvas implementation, no coordinate conversion, no hit testing, pointer/crosshair capture, drag/edit state, toolbar, persistence, autoscale ownership, calculations, market acquisition, journal truth, or P19 risk/reward behavior.

## Exact controlled diff from P18.7
1. `KAIROS_P18_8_LIGHTWEIGHT_CHARTS_V5_TREND_LINE_PRIMITIVE_FACTORY_REPORT_2026-09-04.md`
2. `package.json`
3. `scripts/verify-p18-8-lightweight-charts-v5-trend-line-primitive-factory.mjs`
4. `src/features/chart/index.ts`
5. `src/features/chart/lightweightChartsV5TrendLinePrimitiveFactory.ts`
6. `tests/lightweight-charts-v5-trend-line-primitive-factory.test.ts`

## Verification status before canonical gate
Dedicated P18.8 static verifier is run locally. Any local TypeScript/build/Vitest results are reported separately; canonical GitHub Actions remains authoritative for promotion.
