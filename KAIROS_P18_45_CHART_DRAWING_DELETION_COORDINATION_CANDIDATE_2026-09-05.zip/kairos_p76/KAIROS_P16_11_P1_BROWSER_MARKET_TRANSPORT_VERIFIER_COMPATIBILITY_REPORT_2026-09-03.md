# KAIROS P16.11 — P1 Browser Market Transport Verifier Compatibility

## OBJECTIVE
Repair the historical P1 static scope verifier so a future concrete Binance browser transport owner can use the standard browser WebSocket API without weakening the original P1 business/backend scope boundary anywhere else.

## RESEARCH
MDN documents the classic WebSocket constructor as a stable, widely supported browser API that immediately attempts a connection to the supplied URL. Binance Spot's official stream documentation continues to expose public raw streams over WSS at `/ws/<streamName>`. A concrete browser transport therefore needs a legitimate WebSocket token, but that token belongs only in the transport boundary.

## OWNER TRACE
- P1 static verifier remains the historical source-scope guard.
- `scripts/p1-source-scope-policy.mjs` owns the exact browser-transport exception path.
- The only approved future source owner is `src/services/market-data/providers/binance/binanceSpotBrowserStreamConnector.ts`.
- P15/P16 contracts remain transport-neutral until a later controlled transport implementation slice.

## PRE-CHANGE FLOW
P1 rejected a standalone `websocket` token in every source file. That correctly blocked accidental transport ownership, but also made a standards-compliant concrete browser transport impossible without evasion.

## CHANGE
Splits the browser transport token from the general P1 business-term regex. The browser transport token remains globally forbidden except for one exact future Binance connector path. A dedicated verifier proves the exact path is permitted while sibling, near-miss, application-layer, and directory-wide alternatives remain rejected.

## NON-SCOPE
No WebSocket construction, no network connection, no Binance lifecycle, no reconnect logic, no timers, no P17 chart work, no UI, no persistence, no journal mutation, no credentials or order execution.

## DATA/STATE FLOW
None. This is verifier policy only.

## PERSISTENCE / SECURITY / THEME / OFFLINE
No runtime ownership changes.

## TESTS
- Historical P1 static verifier executed against the candidate source tree.
- Dedicated P16.11 compatibility verifier validates exact-owner allowance and near-miss rejection.
- No directory-prefix or generic market-data exception is permitted.

## REGRESSION
All prior specialized P1/P5/P11/P13 ownership checks remain unchanged. The general non-transport business-term scope guard remains unchanged except that WebSocket is now checked by its own stricter exact-owner rule.

## PERFORMANCE
Verification-only constant-time path membership check per scanned source file; no runtime impact.

## KNOWN LIMITATIONS
The approved future source file does not exist in this slice. P16.11 only makes its legitimate implementation possible. The next controlled slice must implement and test that exact owner without widening the exception.

## RESULT
Candidate ready for canonical gate. Canonical PASS required before authority promotion.
