# KAIROS P18.21 — Chart Drawing Interaction State Contract

## Controlled base
Canonical P18.20 PASS, GitHub Actions run #224 / 33860640831.

## Evidence / research basis
The controlling Kairos drawing architecture requires drawing interaction to use one explicit state machine/reducer vocabulary rather than unrelated booleans, with the states IDLE, TOOL_SELECTED, DRAWING, PREVIEW, COMMITTED, CANCELLED, EDITING, and DELETING. Current authoritative P18.20 source has no drawing-interaction state owner. This slice is provider-neutral and does not depend on Lightweight Charts API shape, so no new vendor API research is required for this contract-only amendment.

## Responsibility added
Adds only the provider-neutral state-shape contract for drawing interaction. The contract is a discriminated union with exactly one active status and state-specific tool/drawing identity where relevant. It establishes the vocabulary required before any reducer transition behavior or UI interaction wiring is introduced.

## Ownership preserved
- P18.1 remains drawing truth owner.
- P18.11/P18.20 remain presentation lifecycle/hover coordination owners.
- P18.18 remains hover lifecycle owner.
- P18.17/P18.16/P18.15/P18.14 retain provider resolution/subscription/projection ownership.
- P18.21 owns only drawing interaction-state shape; it does not own rendering, provider APIs, persistence, or transition behavior.

## Explicit non-scope
No reducer transition table, click selection, pointer capture, drag/edit implementation, drawing creation/commit commands, toolbar UI, undo/redo, persistence/restore, new drawing kinds, horizontal line, rectangle/order block, freehand, risk/reward, journal truth, market truth, calculations, navigation, theme changes, dependency migration, or P19 work.

## Changed-file contract
Exactly six files relative to canonical P18.20:
1. `KAIROS_P18_21_CHART_DRAWING_INTERACTION_STATE_CONTRACT_REPORT_2026-09-04.md`
2. `package.json`
3. `scripts/verify-p18-21-chart-drawing-interaction-state-contract.mjs`
4. `src/features/chart/chartDrawingInteractionContract.ts`
5. `src/features/chart/index.ts`
6. `tests/chart-drawing-interaction-contract.test.ts`

## Verification intent
Dedicated verifier proves the new state vocabulary, discriminated-union shape, chart export, and absence of provider/persistence/P19 ownership. Canonical gate must additionally prove deterministic install, production TypeScript/build, dedicated runtime tests, full unit regression, P18/P17 regression chain, historical closures, exact scope, candidate artifact, and gate evidence before promotion.
