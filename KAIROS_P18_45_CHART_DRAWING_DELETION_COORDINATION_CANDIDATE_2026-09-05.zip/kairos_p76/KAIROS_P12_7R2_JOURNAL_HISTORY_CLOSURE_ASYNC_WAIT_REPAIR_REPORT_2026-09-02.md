# KAIROS P12.7R2 — Journal History Closure Async Wait Repair

## Patch
P12.7R2

## Base
P12.6R1 canonical PASS — GitHub Actions run #66 / run 33583877839.

## Objective
Repair the P12.7 closure integration test race exposed by canonical P12.7R1 run #68. Preserve production code unchanged and prove the filtered Journal History route only after its asynchronous indexed refresh completes.

## Failure evidence
P12.7R1 compiled and built successfully. Full regression reached 318 passing tests plus one failing new closure test. The failing assertion asked for a `listitem` immediately after the status select value became `closed`, while the Journal History region was still `aria-busy="true"` and rendering `Loading trade history…`.

## Owner trace
- Indexed retrieval owner: trade repositories.
- Journal aggregation owner: `listJournalHistory`.
- Financial calculation owner: P11 Calculation Brain.
- Route orchestration owner: `JournalRoute`, including latest-request-wins behavior.
- Presentation owner: `JournalHistoryList`.
- This repair changes no production owner.

## Change
The closure test now waits for the closed-filter list item to appear before asserting its count and rendered metrics. The closure verifier requires this asynchronous wait contract and continues to reject the previously invalid `decimalFromString` import.

## Exact controlled scope
1. `KAIROS_P12_7R2_JOURNAL_HISTORY_CLOSURE_ASYNC_WAIT_REPAIR_REPORT_2026-09-02.md`
2. `package.json`
3. `scripts/verify-p12-journal-history-closure.mjs`
4. `tests/journal-history-closure.test.tsx`

## Non-scope
No `src/` changes. No schema/migration changes. No persistence behavior changes. No calculation changes. No UI changes. No theme, network, service worker, activation, deployment, charting, Visual P&L, or P13 work.

## Persistence / security / offline
Unchanged. IndexedDB + Dexie remain authoritative. No new network path or secret handling exists.

## Regression and performance
Canonical gate must run deterministic install, production build, full unit suite, all controlled P1–P12.7R2 verifiers, explicit closure integration test, and the existing 10,500-trade USER_HEAVY timing canary.

## Result
HOLD pending canonical GitHub gate. P12.6R1 remains authoritative until P12.7R2 passes.
