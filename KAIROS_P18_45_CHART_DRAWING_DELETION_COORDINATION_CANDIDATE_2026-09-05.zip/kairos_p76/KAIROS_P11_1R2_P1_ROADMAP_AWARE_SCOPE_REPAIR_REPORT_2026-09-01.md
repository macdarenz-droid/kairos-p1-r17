# KAIROS P11.1R2 P1 Roadmap-Aware Scope Repair Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Authoritative base
P10.3R2 PASS.

## Failed predecessors
P11.1: discarded — gate scope falsely required an unchanged buildInfo file.
P11.1R1: discarded — build and 165/165 unit tests passed, then legacy P1 static verification rejected the legitimate P11 decimal owner.

## Failure signal
`P1 scope leak detected in src/domain/calculations/decimalKernel.ts`

## Repair
Rebuilt fresh from P10.3R2 and reapplied the same P11.1 decimal kernel.
Updated the legacy P1 static verifier with one explicit later-roadmap owner:
`src/domain/calculations/`.

The exemption is narrow. Files under the calculation owner remain forbidden from taking persistence, IndexedDB/Dexie, WebSocket, market-data, service-worker, localStorage, or sessionStorage responsibilities.

## Architecture
P9 DecimalString validation -> P11 calculation domain -> future derived metrics.
P5 remains the IndexedDB/Dexie owner.
P4 remains the service-worker owner.
Theme preference remains the presentation localStorage owner.

## Product scope
No new product behavior beyond the original P11.1 decimal kernel.
No P&L, R-multiple, leverage, UI, schema, persistence, activation, market API, or journal changes.

## Gate requirement
Full build, full unit suite, P1-P10.3R2 regressions, and P11.1R2 verifier must all PASS before promotion.
