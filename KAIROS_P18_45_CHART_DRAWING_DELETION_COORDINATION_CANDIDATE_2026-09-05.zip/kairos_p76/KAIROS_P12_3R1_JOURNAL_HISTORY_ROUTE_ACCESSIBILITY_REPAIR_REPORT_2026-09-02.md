# KAIROS P12.3R1 Journal History Route Accessibility Repair

## Status
HOLD pending canonical GitHub gate.

## Base
Exact P12.2R1 canonical PASS artifact from run #55.

## Failed predecessor
P12.3 run #56 failed one existing P10 route test because the new history-loading message also used `role="status"`. The existing P10 save confirmation test intentionally queries the unique status region after a successful save.

## Repair
Reproduce the intended P12.3 history UI from the P12.2R1 PASS base, but keep the loading announcement as `aria-live="polite"` without `role="status"`. This preserves assistive announcement behavior while leaving the P10 save confirmation as the unique status role.

## Ownership
No owner change. JournalRoute owns temporary load state; listJournalHistory remains the read owner; P10 save command remains the write owner; P11 remains metrics owner.

## Non-scope
No test weakening, no P10 contract change, no schema or financial changes, no filter/search/edit/delete, no P13 visual P&L.

## Regression protection
The new P12.3R1 route test now repeats the existing P10 accessibility assertion: `findByRole('status')` must resolve to “Trade saved to your journal.” after save while history refreshes.

## Result
Static architecture and prior P12 query verifiers pass locally. Full deterministic build/unit regression is deferred to the canonical GitHub gate.
