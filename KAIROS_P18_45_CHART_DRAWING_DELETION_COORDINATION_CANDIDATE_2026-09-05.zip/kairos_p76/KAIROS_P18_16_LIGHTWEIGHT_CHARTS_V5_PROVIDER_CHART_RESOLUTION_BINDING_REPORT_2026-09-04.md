# Kairos P18.16 — Lightweight Charts v5 Provider Chart Resolution Binding

## Authoritative base
P18.15R1 — canonical PASS, GitHub Actions run #216 / run ID 33834112713 / head 97661266a4d2911cd0a1326635545839fb190169.

## Controlled purpose
Expose the exact Lightweight Charts provider chart associated with an existing provider-neutral series handle without contaminating `ChartEngineSeriesHandle` with vendor APIs.

## Ownership
- P17/P18.9 `createLightweightChartsV5DriverBinding` remains the provider resource identity owner.
- P18.16 extends that same owner with handle -> provider chart identity.
- P18.15R1 remains the `subscribeCrosshairMove` / `unsubscribeCrosshairMove` lifecycle owner.
- P18.14 remains the `hoveredObjectId` -> drawing-hover projection owner.

## Added
- `resolveChart(handle)` on `LightweightChartsV5DriverBinding`.
- Provider chart identity is registered with each created neutral series handle.
- Series removal and chart removal invalidate chart resolution together with existing series resolution.
- Dedicated P18.16 verifier and tests.

## Explicit non-scope
No crosshair subscription, click subscription, selection, drag/edit, toolbar state, drawing-truth mutation, persistence, calculation, market acquisition, journal truth, navigation, autoscale policy, or P19 behavior.
