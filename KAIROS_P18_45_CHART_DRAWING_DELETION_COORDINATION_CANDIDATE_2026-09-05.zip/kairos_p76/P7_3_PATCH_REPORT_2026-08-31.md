# Kairos P7.3 — Remote Activation Adapter Foundation

## Status
HOLD pending full GitHub CI gate. P7.2 remains authoritative until PASS.

## Authoritative base
KAIROS_P7_2_ACTIVATION_RECEIPT_PERSISTENCE_CANDIDATE_2026-08-31.zip

## Objective
Implement the concrete network adapter behind the P7.1 ActivationAdapter boundary without embedding invite authority or a production endpoint in the client.

## Research decisions
- Authorization remains server-owned; client checks are UX/protocol handling only.
- HTTP success is checked explicitly because Fetch resolves for HTTP error responses.
- Network/abort/timeout failures are mapped separately from server rejection.
- Deployment must inject an HTTPS endpoint.
- Ambient browser credentials are omitted and redirects are rejected for this activation request.

## Production changes
- Added `src/services/activation/RemoteActivationAdapter.ts`.
- Added configurable HTTPS endpoint and bounded timeout.
- Added strict server response/receipt parsing.
- Added mapping for invalid/expired/already-used/rate-limited/service/network outcomes.
- Exported adapter through activation barrel.
- No endpoint, invite authority, reusable validation credential, or activation UI added.

## Verification
- Added `tests/remote-activation-adapter.test.ts`.
- Added `scripts/verify-p7-remote-activation-adapter.mjs`.
- Added `verify:p7:remote-activation` package script.
- P1 static PASS locally.
- P7.1, P7.2, P7.3 static contracts PASS locally.
- Dependency-backed TypeScript/Vitest/build not claimed locally because node_modules is absent; GitHub gate is required.

## Non-scope
Activation UI, navigation gate, real production service endpoint, backend implementation, receipt persistence redesign, invite issuance/admin tools.
