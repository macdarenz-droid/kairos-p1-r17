# Kairos Activation Service Deployment Contract (P7.7)

This document defines the deployment boundary between the Kairos client and the server-owned beta invite authority. It is a protocol contract, not a backend implementation and not a place to store secrets.

## Client deployment inputs

The web build receives two public values:

- `VITE_KAIROS_ACTIVATION_ENDPOINT` — the HTTPS activation endpoint.
- `VITE_KAIROS_ACTIVATION_PUBLIC_KEY_SPKI` — the base64 SPKI public verification key used to verify signed activation receipts.

Vite exposes `VITE_` values to client code. Therefore these values must never contain a private key, signing key, invite-code list, reusable admin credential, or other secret. The public verification key is intentionally public.

## Request

Method: `POST`

Content type: `application/json`

Body:

```json
{
  "inviteCode": "user-supplied-code",
  "appVersion": "0.1.0",
  "buildId": "build-identity"
}
```

The client sends no ambient browser credentials. The server must make the authorization decision itself and must not trust client-side activation state.

## Response contract

Success returns the receipt already defined by the P7 activation contract:

```json
{
  "ok": true,
  "receipt": {
    "receiptVersion": 1,
    "activationId": "server-generated-id",
    "issuedAt": "2026-08-31T00:00:00.000Z",
    "verifierPayload": "exact-signed-payload",
    "verifierSignature": "base64url-p256-signature"
  }
}
```

Known rejection reasons are:

- `invalid-code`
- `expired-code`
- `already-used`
- `rate-limited`
- `service-error`

The server may map transport-level failures to normal HTTP error responses, but must not leak internal secrets or reusable invite authority in the response.

## Server responsibilities

The deployment-side service must:

1. Keep invite issuance and validation authority server-side.
2. Deny by default.
3. Apply expiry/single-use policy where configured by the beta program.
4. Apply rate limiting suitable for the deployment.
5. Generate activation identifiers server-side.
6. Sign the exact P7.4 proof payload with ECDSA P-256 / SHA-256.
7. Keep the signing/private key outside the client bundle and outside `VITE_` variables.
8. Avoid logging raw invite codes where operationally unnecessary.
9. Return only the protocol fields required by the client.
10. Serve only over HTTPS.

## Browser deployment requirements

If the activation endpoint is on another origin, the hosting deployment must deliberately allow that origin through CORS and the app's Content Security Policy `connect-src`. Do not use a wildcard merely to make activation work.

## Offline behavior

A never-activated installation requires the server. After successful first activation, Kairos stores only the server-issued receipt and re-verifies its public proof locally before offline journal access.

## Completion boundary

P7.7 freezes the client/server protocol and deployment requirements. It does not claim that a production activation server exists. End-to-end production activation can only be certified after an actual backend deployment supplies the endpoint and public verification key and passes the same contract.
