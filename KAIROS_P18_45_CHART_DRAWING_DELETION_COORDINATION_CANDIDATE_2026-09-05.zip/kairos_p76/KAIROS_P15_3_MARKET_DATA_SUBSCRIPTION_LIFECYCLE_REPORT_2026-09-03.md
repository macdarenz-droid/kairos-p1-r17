# KAIROS P15.3 — Market Data Subscription Lifecycle

## BASE
P15.2R2 canonical PASS — Run #127 / SHA e3d914e5f9601b80825c380f42c5513e131cc992.

## OBJECTIVE
Add one transport-neutral lifecycle owner that binds an already-created market-data subscription to optional AbortSignal cancellation and guarantees idempotent close.

## RESEARCH
MDN confirms AbortSignal is an EventTarget, exposes `aborted`, fires an `abort` event, and supports listener cleanup. MDN also recommends removing application-added abort listeners when operations finish normally so long-lived signals do not retain listeners unnecessarily.

## OWNER TRACE
P15.1 owns the replaceable MarketDataAdapter subscription boundary and `close()`.
P15.2 owns observation validation/freshness semantics.
P15.3 owns only subscription lifecycle coordination around an existing subscription.

## PRE-CHANGE FLOW
adapter.subscribe(...) -> MarketDataSubscription -> caller manually owns close/AbortSignal behavior.

## CHANGE
Added `bindMarketDataSubscriptionLifecycle`:
- optional AbortSignal binding;
- immediate close for already-aborted signals;
- abort-driven close;
- explicit close;
- idempotent underlying close;
- abort-listener removal during close.

## NON-SCOPE
No provider, endpoint, WebSocket, EventSource, fetch, polling, retry/reconnect, backoff, persistence, UI/chart, execution mutation, Calculation Engine mutation, P&L mutation, credentials, or secrets.

## DATA/STATE FLOW
existing subscription -> lifecycle wrapper -> explicit close or abort -> exactly one underlying subscription.close().

## PERSISTENCE
None.

## SECURITY
No credentials or remote endpoints introduced.

## THEME
No UI/theme change.

## OFFLINE
Offline journal behavior unchanged.

## TESTS
Runtime tests cover abort close, already-aborted signal, idempotent explicit close, and no-signal explicit close.

## REGRESSION
P15.1 adapter interface and P15.2 observation semantics remain unchanged.

## PERFORMANCE
Constant per-subscription state and one optional abort listener; listener is removed on close.

## KNOWN LIMITATIONS
No reconnect/retry/backoff/provider transport yet.

## REAL-DEVICE STATUS
N/A — transport-neutral service contract only.

## RESULT
HOLD pending canonical GitHub gate.
