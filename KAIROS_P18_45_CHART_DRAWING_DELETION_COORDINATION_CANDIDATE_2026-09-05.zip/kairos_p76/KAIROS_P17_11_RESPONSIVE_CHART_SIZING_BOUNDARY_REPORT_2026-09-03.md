# KAIROS P17.11 — Responsive Chart Sizing Boundary

## OBJECTIVE
Bind the production chart composition to Lightweight Charts v5 automatic container sizing without introducing a second resize owner.

## RESEARCH
Official Lightweight Charts 5.2 documents `autoSize: true` as container-watching resize behavior backed by `ResizeObserver`; explicit width/height are ignored while automatic sizing is active.

## CHANGE
- Production composition requests `{ autoSize: true }`.
- Vendor module boundary types the narrow `autoSize` option.
- No Kairos-owned ResizeObserver, window resize listener, timer, or persistent sizing state.

## NON-SCOPE
No feed, Binance, candle aggregation, drawings, markers, journal mutation, persistence, calculations, navigation, or P18 work.

## RESULT
Local static verifier PASS. Canonical CI required for authority.
