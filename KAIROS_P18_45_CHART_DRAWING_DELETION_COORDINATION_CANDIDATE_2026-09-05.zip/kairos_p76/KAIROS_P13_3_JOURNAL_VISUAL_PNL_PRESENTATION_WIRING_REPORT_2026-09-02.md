# KAIROS PATCH REPORT

Patch: P13.3 — Journal Visual P&L Presentation Wiring
Base: P13.2 — canonical PASS, Run #74
App version: 0.1.0
Build ID: controlled candidate 2026-09-02

## OBJECTIVE
Expose the authoritative per-trade Visual P&L projection already carried by Journal History as a compact, accessible visual outcome on each history card.

## RESEARCH
Re-checked the controlling Kairos handoff: P13 owns Visual P&L, the product is visual-first, green/red are semantic trading outcomes, and feature styling must consume semantic theme tokens. Re-checked current W3C WCAG Use of Color guidance: color must not be the only visual means of conveying status; text/shape cues are retained alongside semantic color.

## OWNER TRACE
P11 remains financial calculation owner. P13 outcomeProjection remains semantic outcome owner. P12 bounded Journal History remains query owner. P13.3 only renders `JournalHistoryEntry.visualPnl`.

## PRE-CHANGE FLOW
IndexedDB -> P12 bounded history query -> P11 TradeMetrics -> P13 outcome projection -> JournalHistoryEntry. The route rendered raw gross/net facts but did not expose the P13 projection visually.

## CHANGE
- `src/app/JournalHistoryList.tsx`: render projection label, non-color mark, amount/currency and outcome hook.
- `src/app/journalRoute.css`: semantic presentation using existing `--kairos-trade-profit/loss/flat` tokens.
- `tests/journal-visual-pnl-presentation.test.tsx`: profit/loss/break-even/unavailable presentation coverage.
- `scripts/verify-p13-journal-visual-pnl-presentation.mjs`: ownership/theme/accessibility static contract.
- `package.json`: register P13.3 verifier.

## NON-SCOPE
No calendar/day aggregation, heatmap, equity curve, streaks, summaries, FX conversion, financial arithmetic, database/schema/query changes, trade save changes, or route ownership changes.

## DATA/STATE FLOW
Persisted trade evidence -> bounded P12 query -> P11 metrics -> P13 projection -> JournalHistoryEntry -> P13.3 presentation. No reverse write path.

## PERSISTENCE
None.

## SECURITY
No new surface.

## THEME
Uses existing semantic trade outcome tokens only; no hard-coded outcome colors.

## OFFLINE
Fully local; unchanged.

## TESTS
Focused component coverage verifies visible text plus shape cues for every outcome and amount/currency display.

## REGRESSION
P13.1/P13.2 and P12 closure/USER_HEAVY remain required by canonical gate.

## PERFORMANCE
Constant-time rendering per already bounded history entry; no additional database query or journal scan.

## KNOWN LIMITATIONS
No day-level aggregation or cross-currency totals. Those remain intentionally deferred; mixed currencies must not be silently aggregated before an authoritative currency policy exists.

## REAL-DEVICE STATUS
Pending canonical gate / later UI device certification.

## RESULT
HOLD pending canonical GitHub gate.
