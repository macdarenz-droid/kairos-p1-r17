# KAIROS P18.3 — Chart Drawing Layer Lifecycle Port

## Purpose
Introduce the provider-neutral lifecycle seam that will let projected P18 drawings attach to an active chart series without making Lightweight Charts, Canvas rendering, drawing persistence, or interaction state authoritative.

## Authority
Base: canonical P18.2 Chart Drawing Projection Boundary, GitHub Actions Run 33758036673, head SHA `453b2d5c6a524521b1ff119aed18efdc340e09ec`.

## Evidence and dependency order
P18.1 established drawing truth. P18.2 established renderer projection. Lightweight Charts v5.2 exposes custom drawing through series primitives attached/detached on a series. Before binding that vendor API, Kairos needs a narrow provider-neutral attachment lifecycle.

## Added
- `chartDrawingLayerPort.ts`
- provider-neutral driver handle and driver contract
- guarded drawing-layer session with replace/destroy lifecycle
- idempotent detach behavior
- dedicated P18.3 verifier and unit tests
- public exports and package verifier script

## Ownership
- `ChartDrawing` remains drawing truth.
- `RendererChartDrawing` remains presentation projection.
- `ChartEngineSeriesHandle` remains the provider-neutral presentation target.
- P18.3 owns only drawing-layer attachment lifecycle semantics.

## Explicit non-scope
No Lightweight Charts primitive implementation, Canvas drawing, hit testing, pointer/crosshair capture, drag/edit state, toolbar, persistence, undo/redo, autoscale ownership, network/provider behavior, journal execution mutation, market-observation mutation, or P19 risk/reward behavior.

## Verification intent
Canonical CI must prove deterministic install, exact Lightweight Charts dependency, TypeScript/build, dedicated P18.3 runtime/tests, full unit regression, full controlled roadmap regression, P18.2/P18.1/P17 regressions, historical closures, exact scope, and artifacts.
