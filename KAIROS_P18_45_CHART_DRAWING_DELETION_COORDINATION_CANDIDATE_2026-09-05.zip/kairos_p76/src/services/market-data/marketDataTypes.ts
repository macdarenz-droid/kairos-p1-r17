import type { DecimalString } from '../../domain/trades';

export type MarketDataConnectionState =
  | 'idle'
  | 'connecting'
  | 'live'
  | 'disconnected'
  | 'error';

export interface MarketDataInstrument {
  readonly venue: string;
  readonly symbol: string;
}

export interface MarketPriceObservation {
  readonly instrument: MarketDataInstrument;
  readonly price: DecimalString;
  readonly observedAt: string;
  readonly sourceTimestamp: string | null;
}

export interface MarketDataSubscriptionHandlers {
  readonly onPrice: (observation: MarketPriceObservation) => void;
  readonly onStateChange?: (state: MarketDataConnectionState) => void;
  readonly onError?: (error: unknown) => void;
}

export interface MarketDataSubscription {
  readonly close: () => void;
}
