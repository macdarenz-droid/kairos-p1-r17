# KAIROS P15.8 — Market Data Reconnect Plan Semantics

## BASE
P15.7 canonical PASS — Run #133 / SHA cafd5cd36fd117f78305a4f54451d41e9ef5e198.

## OBJECTIVE
Add one pure provider-neutral reconnect planning owner that composes the already-authoritative bounded reconnect decision with full-jitter delay semantics, without scheduling or transport ownership.

## RESEARCH
Current AWS retry guidance continues to use bounded attempts, exponential backoff and random jitter to reduce retry storms. AWS also recommends implementing retries at one appropriate application layer rather than independently at multiple layers. MDN documents AbortSignal as the browser cancellation primitive, with application-added listeners requiring cleanup when operations complete; cancellation remains owned by the existing P15.6 scheduler lifecycle rather than this pure planner.

## OWNER TRACE
P15.1 adapter/subscription contract.
P15.2 observation validation/freshness.
P15.3 subscription lifecycle.
P15.4 connection-state transitions.
P15.5 bounded deterministic reconnect decision/backoff.
P15.6 one-shot scheduling/cancellation lifecycle.
P15.7 pure full-jitter transformation.
P15.8 pure reconnect-plan composition only.

## PRE-CHANGE FLOW
Callers had authoritative bounded policy semantics and authoritative jitter semantics but no single pure result describing retry, stop, or invalid composition.

## CHANGE
Added `planNextMarketDataReconnect`:
- delegates attempt/backoff policy to P15.5;
- delegates full-jitter transformation to P15.7;
- preserves the base delay for diagnostics;
- returns one explicit `retry`, `stop`, or `invalid` result;
- does not schedule or acquire randomness.

## NON-SCOPE
No timers, scheduling, Math.random, entropy acquisition, AbortSignal listener ownership, provider/API, WebSocket, EventSource, fetch, polling, persistence, UI/chart wiring, execution mutation, Calculation Engine mutation, P&L mutation, credentials, or secrets.

## DATA/STATE FLOW
policy + attempt -> P15.5 bounded decision -> if retry: base delay + external normalized sample -> P15.7 jitter -> P15.8 reconnect plan.

## PERSISTENCE
None.

## SECURITY
No network access or credentials.

## THEME
No UI/theme changes.

## OFFLINE
Offline journal remains unaffected.

## TESTS
Runtime tests cover retry composition, capped delay composition, attempt-limit stop, invalid policy, invalid sample, and no unnecessary sample use after stop.

## REGRESSION
P15.1-P15.7 owners remain unchanged.

## PERFORMANCE
Constant-time composition only.

## KNOWN LIMITATIONS
P15.8 does not execute a retry. Entropy acquisition, scheduling coordination, provider-specific retryability and live provider integration remain deferred.

## REAL-DEVICE STATUS
N/A — pure service semantics.

## RESULT
HOLD pending canonical GitHub gate.
