# KAIROS P17.3 — Chart Series Projection Boundary

## OBJECTIVE
Add the presentation-only numeric/time projection required by a future concrete chart renderer, without installing or wiring the chart library yet.

## RESEARCH
TradingView Lightweight Charts 5.2.1 is the current npm release. Its v5 API creates charts with `createChart`, creates series through unified `addSeries`, and series data uses numeric values plus chart time values. A chart instance is removed through `IChartApi.remove()`.

## OWNER TRACE
P17.1R2 owns authoritative ChartRenderModel semantics.
P17.2 owns renderer lifecycle.
P17.3 owns only conversion from authoritative presentation inputs to renderer-ready numeric/time primitives.
P11 remains financial calculation owner.
P15/P16 remain market-data owners.
Journal/domain remains execution-truth owner.

## CHANGE
- projects ISO timestamps to epoch seconds
- projects DecimalString values to finite JavaScript numbers only at the renderer boundary
- supports line and candle projection
- explicitly excludes journal execution references from market-series projection
- rejects invalid timestamps/values rather than inventing substitutes
- adds dedicated tests and verifier

## NUMERIC SAFETY
DecimalString remains authoritative upstream. Numeric conversion is presentation-only and must never feed calculations, persistence, journal truth, or market truth.

## NON-SCOPE
No charting dependency, createChart call, DOM renderer, live subscription wiring, historical candle acquisition, execution markers, reconciliation, drawings, risk/reward tool, persistence, timers, navigation, or motion changes.

## RESULT
Local verifier/static/dedicated tests run below. Canonical CI decides authority.
