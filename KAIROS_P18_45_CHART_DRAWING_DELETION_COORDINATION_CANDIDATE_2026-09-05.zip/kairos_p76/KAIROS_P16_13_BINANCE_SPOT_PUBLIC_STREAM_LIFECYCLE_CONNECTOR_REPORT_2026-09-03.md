# KAIROS P16.13 — Binance Spot Public Stream Lifecycle Connector

## OBJECTIVE
Translate concrete Binance Spot transport lifecycle evidence into the existing provider-neutral P15 connection-state machine without adding reconnect execution.

## RESEARCH
Current Binance Spot documentation states a connection is valid for 24 hours and may emit `serverShutdown` before disconnection. Browser transport open/error/close evidence remains the appropriate transport-level lifecycle input. This slice does not react to `serverShutdown` or schedule a replacement connection.

## OWNER TRACE
- P15 `marketDataConnectionState.ts`: authoritative connection-state transition semantics.
- P16.4: connector contract.
- P16.12: native browser transport owner.
- P16.13: connector decorator translating transport evidence to P15 state changes.
- P16.9: subscription composition remains unchanged.

## CHANGE
Adds `withBinanceSpotPublicStreamLifecycle`, which emits `connecting` when a connection is requested, `live` after open evidence, `error` after transport error evidence, and `disconnected` after close evidence when accepted by the P15 state machine. Existing transport handlers remain forwarded.

## NON-SCOPE
No reconnect decisions/execution, no timers, jitter, clocks, AbortSignal ownership, socket construction, message decoding, persistence, charting, UI, journal mutation, credentials, or order execution.

## DATA/STATE FLOW
connect invocation -> P15 connect-requested -> underlying connector -> open/error/close evidence -> P15 state transition -> optional onStateChange.

## REGRESSION
Explicit close delegates to the existing connection and does not invent a state transition before transport close evidence. An error transition remains `error`; a later close event is rejected by the existing P15 state machine rather than forcing a second state.

## PERFORMANCE
O(1) state transition work per lifecycle event; no polling/timers.

## RESULT
HOLD pending canonical gate.
