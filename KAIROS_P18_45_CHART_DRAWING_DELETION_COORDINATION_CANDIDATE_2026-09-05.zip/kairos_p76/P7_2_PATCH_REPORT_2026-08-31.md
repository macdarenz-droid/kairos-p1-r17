# KAIROS PATCH REPORT

Patch: P7.2 — Activation Receipt Persistence / Verification Boundary
Base: P7.1 PASS / LOCKED
App version: 0.1.0
Build ID: existing locked build identity

## OBJECTIVE
Persist only the server-issued activation receipt needed for later activation restoration while ensuring stored client bytes never become invite authority by themselves. Keep installation activation evidence device-scoped, outside user backup/restore payloads, and require a replaceable verifier before a persisted receipt can be treated as verified.

## RESEARCH
Re-checked the controlling handoff rules A1, A31, A35, A37, A38 and A39 and the P7 activation ownership boundary. Re-checked current Dexie versioning guidance and MDN database upgrade behavior. A schema migration is required only when the schema changes; this patch adds one singleton to the already-authoritative metadata key/value store, so a new database version would add migration risk without adding a new store/index requirement. Re-checked that client persistence is storage rather than authority, therefore persisted receipt bytes must be re-verified before they can unlock offline use.

## OWNER TRACE
- Activation receipt semantic owner: `src/services/activation/ActivationReceiptRepository.ts`
- Physical persistence owner: existing `MetadataRepository`
- Receipt proof boundary: `ActivationReceiptVerifier`
- Backup/device-scope policy: `src/data/repositories/metadataScope.ts`

## PRE-CHANGE FLOW
P7.1 could represent a server-issued receipt and a verified offline-active state but had no persistence owner. Reloading always lost the receipt. No contract prevented future code from trusting arbitrary stored receipt bytes.

## CHANGE
- Added reserved device-scoped metadata namespace and `device.activation.receipt` key.
- Added strict versioned local receipt serialization/parser.
- Added activation receipt repository over the existing metadata repository.
- Added replaceable receipt-verifier interface.
- Added `loadVerifiedPersistedActivation()` which never returns `verified` without verifier approval.
- User backup snapshots now exclude `device.*` control metadata.
- Backup-scoped replacement preserves existing `device.*` control metadata atomically, and post-reopen restore verification compares only backup-scoped records.
- Added P7.2 tests and static verifier.

## NON-SCOPE
No invite list, master code, signing secret, private key, concrete HTTP endpoint, concrete cryptographic verifier/public key, activation UI, navigation blocking, cloud provider, or P8 work.

## DATA/STATE FLOW
Online activation later: UI command -> ActivationAdapter -> server validation -> server-issued receipt -> ActivationReceiptRepository -> metadata owner.
Startup restoration later: ActivationReceiptRepository -> strict parser -> ActivationReceiptVerifier -> verified result -> activation state reducer/query consumer.

## PERSISTENCE
Database schema remains V1 because no new store or index is required. The receipt is a versioned JSON value under `device.activation.receipt`. This avoids unnecessary schema churn while preserving historical V1. Device-scoped control metadata is excluded from user backup payloads and preserved across backup-scoped restore.

## SECURITY
No reusable invite authority is embedded. No invite code is persisted. A copied or modified local receipt is not considered verified merely because it exists; it must pass the injected verifier boundary. Concrete signature verification remains a separate controlled P7 patch.

## THEME
No UI/theme impact.

## OFFLINE
P7.2 supplies durable receipt storage and the verification boundary needed for offline activation restoration. It does not yet implement the concrete offline signature verifier, so it does not claim offline unlock is production-complete.

## TESTS
Added persistence/reopen, missing/corrupt receipt fail-closed, verifier approval/rejection, backup exclusion, full restore/reopen preservation, and backup-scoped re-query coverage.

## REGRESSION
All locally executable static contracts P1 through P7.2 are required. Full dependency-backed typecheck/build/Vitest and the complete historical gate remain GitHub-owned before promotion.

## PERFORMANCE
One singleton metadata read/write on activation/startup only. No polling, observers, timers, or background loop added.

## KNOWN LIMITATIONS
Concrete signature verification/public-key material and the actual activation service adapter remain intentionally unimplemented. P7.3 should add the verifiable receipt implementation before activation UI/navigation gating.

## REAL-DEVICE STATUS
Not required for this non-UI persistence/contract patch. GitHub integration gate required.

## RESULT
HOLD pending full GitHub gate.

## NEXT
Only if PASS: P7.3 concrete receipt-verification implementation, still without activation UI or P8 navigation.
