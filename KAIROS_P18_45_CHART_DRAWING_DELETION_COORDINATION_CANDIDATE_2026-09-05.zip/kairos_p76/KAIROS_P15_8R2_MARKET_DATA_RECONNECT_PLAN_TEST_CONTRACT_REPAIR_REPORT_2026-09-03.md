# KAIROS P15.8R2 — Market Data Reconnect Plan Test Contract Repair

## BASE
P15.7 remains authoritative. P15.8R1 Run #135 passed scope, install, and build, then failed only in the new P15.8 runtime tests.

## FAILURE
Two P15.8 expectations disagreed with the already-authoritative P15.5 contract:

1. P15.5 accepts `completedAttempts`, which is zero-based. The first retry therefore uses `completedAttempts = 0`, producing the initial delay. The P15.8 test incorrectly passed `1` while expecting the initial delay.
2. P15.5 explicitly permits non-negative safe-integer delays, so `initialDelayMs = 0` is valid. The P15.8 test incorrectly treated zero initial delay as an invalid policy.

## REPAIR
Tests only:
- first retry case now uses completedAttempts `0`;
- capped fourth retry case now uses completedAttempts `3`;
- invalid-policy case now uses `initialDelayMs > maxDelayMs`, which the authoritative P15.5 owner actually rejects.

No production semantics changed.

## NON-SCOPE
No P15.5/P15.6/P15.7/P15.8 production changes.
No provider, timers, entropy acquisition, persistence, UI, charts, execution, Calculation Engine, P&L, or secrets.

## RESULT
HOLD pending canonical GitHub gate.
