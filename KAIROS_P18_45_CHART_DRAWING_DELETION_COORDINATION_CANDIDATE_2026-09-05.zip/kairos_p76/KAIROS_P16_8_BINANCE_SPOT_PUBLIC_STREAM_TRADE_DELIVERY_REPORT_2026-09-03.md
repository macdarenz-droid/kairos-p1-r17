# KAIROS P16.8 — Binance Spot Public Stream Trade Delivery

## BASE
P16.7R3 is authoritative after canonical Run #155 completed SUCCESS on head `67e85cba0e2b2427cd483c411e0978ac1ec5fd03`.

## OBJECTIVE
Bridge one already-received Binance Spot public-stream trade message from the P16.7 mapping owner into the provider-neutral P15 subscription handler boundary without creating a second lifecycle, clock, transport, persistence, chart, or journal-truth owner.

## RESEARCH
Official Binance Spot stream documentation continues to define raw public streams at `/ws/<streamName>`, lowercase stream symbols, 24-hour connection lifetime, server shutdown signaling, and server ping behavior. Browser message delivery exposes received payload through a message event's `data` value. This slice intentionally stops before concrete browser connection ownership.

## OWNER TRACE
P16.7 owns decode -> classify -> trade semantic mapping for one message.
P15 `MarketDataSubscriptionHandlers` owns provider-neutral delivery callbacks (`onPrice`, optional `onError`).
P16.8 owns only the bridge between those existing owners for one already-received message.

## PRE-CHANGE FLOW
received data + caller-owned observedAt
-> P16.7 `mapBinanceSpotPublicStreamTradeMessage`
-> result returned to caller

No provider owner yet delivered a successful mapped observation into P15 `onPrice`.

## CHANGE
Added `binanceSpotPublicStreamTradeDelivery.ts`.

Behavior:
- valid trade -> P16.7 mapping -> exactly one `handlers.onPrice(observation)` call;
- ignored non-trade event -> no price/error callback;
- rejected decode/mapping result -> optional `handlers.onError` receives a small typed provider/stage/reason evidence object;
- returns an explicit delivered/ignored/rejected result for deterministic verification.

Also added dedicated tests, verifier, package script, and market-data barrel export.

## NON-OWNERSHIP
P16.8 does not:
- construct a browser connection;
- acquire wall-clock receipt time;
- own state transitions;
- reconnect or schedule retries;
- handle ping/pong policy;
- persist market observations;
- render charts;
- mutate journal execution or P&L truth;
- use credentials, account streams, or order APIs.

## REGRESSION BOUNDARY
P16.1-P16.7 provider semantics remain reused and unchanged.
P15 remains provider-neutral lifecycle/reconnect authority.
P17 remains chart ownership.

## RESULT
LOCAL CANDIDATE — pending full local regression, upload, and canonical gate.
