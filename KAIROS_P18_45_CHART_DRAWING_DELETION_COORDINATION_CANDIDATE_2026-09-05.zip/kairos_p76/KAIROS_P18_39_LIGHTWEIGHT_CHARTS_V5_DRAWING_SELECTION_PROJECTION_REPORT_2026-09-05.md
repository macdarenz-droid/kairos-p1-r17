# KAIROS P18.39 — Lightweight Charts v5 Drawing Selection Projection

## Purpose
Add the smallest provider-specific evidence boundary required after P18.38 selection-state semantics: project a Lightweight Charts v5.2 drawing primitive hit into provider-neutral drawing-selection evidence.

## Authority / ownership
- P18.13 remains the primitive hit-test owner and exposes the drawing id as `externalId`.
- P18.39 owns only provider mouse-event hover identity -> current-snapshot-filtered neutral selection evidence.
- P18.23 remains the sole interaction transition owner.
- P18.24 remains the sole active interaction state/dispatch owner.
- No click subscription lifecycle is added or duplicated in this slice.

## Current provider evidence
Lightweight Charts v5.2 `MouseEventParams` exposes rich `hoveredInfo`; `HoveredInfo.objectId` carries the associated object id, while `HoveredInfo.sourceKind` and `objectKind` identify ownership/target kind. `PrimitiveHoveredItem.externalId` is the primitive-provided external identity surfaced to mouse subscribers.

P18.39 therefore accepts only:
- `sourceKind === 'series-primitive'`;
- `objectKind === 'primitive'`;
- string `objectId`;
- an id present in the current renderer drawing snapshot.

Everything else fails closed to `null`.

## Explicit non-scope
- no `subscribeClick` / `unsubscribeClick` lifecycle;
- no interaction dispatch;
- no selection state store;
- no drawing mutation;
- no edit/drag/delete execution;
- no persistence/restore;
- no toolbar/UI state;
- no journal truth or calculations;
- no Risk/Reward semantics and no P19 work.

## Verification intent
Dedicated verifier and focused runtime tests pin valid projection plus malformed, wrong-owner, wrong-kind, stale-id, and unrelated-id fail-closed behavior. Historical P18/P17 and earlier closures remain required before promotion.
