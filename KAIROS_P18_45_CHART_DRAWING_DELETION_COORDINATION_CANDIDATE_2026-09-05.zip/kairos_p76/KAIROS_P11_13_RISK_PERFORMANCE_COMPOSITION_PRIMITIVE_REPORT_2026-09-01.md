# KAIROS P11.13 Risk Performance Composition Primitive Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.12 authoritative PASS from controlled gate run #33.

## Objective
Add the smallest safe Calculation Engine composition that can produce both monetary initial risk and an R-multiple when all required inputs are already authoritative.

## Research
The controlling handoff was re-checked before implementation. It requires derived financial metrics to originate in the Calculation Engine, missing financial data never to become zero, and market/instrument-specific calculation policies to sit below the common engine. It also lists RiskCalculator and RMultipleCalculator as protected calculation owners.

The handoff does not lock whether future `TradeMetrics.realizedR` should use gross P&L or net P&L after fees/FX. P11.13 therefore accepts a generic authoritative `resultAmount` and deliberately does not wire TradeMetrics.

## Owner trace
authoritative result amount
+ authoritative monetary risk-per-unit
+ authoritative quantity
-> P11.12 RiskCalculator initial-risk amount
-> P11.7 RMultipleCalculator
-> P11.13 risk-performance composition result

## Pre-change flow
P11.12 could derive initial-risk amount from authoritative risk-per-unit and quantity.
P11.7 could derive R from an authoritative result amount and initial risk.
No common composition existed, and TradeMetrics remained intentionally unwired.

## Change
Adds `calculateRiskPerformance(resultAmount, riskPerUnit, quantity)`.

The composition delegates:
- initial risk to `calculateInitialRiskAmount`;
- R-multiple to `calculateRMultiple`.

It performs no new financial arithmetic itself.

## Contract
Inputs are evidence, not inferred semantics:
- `resultAmount`: already-authoritative result amount;
- `riskPerUnit`: already-authoritative monetary risk per unit;
- `quantity`: already-authoritative quantity.

Output:
- `initialRisk`;
- `realizedR`.

## Missing / zero semantics
Malformed decimal evidence returns explicit `invalid-decimal`.
A zero computed initial risk returns explicit `zero-initial-risk`.
The calculator never converts unavailable R to zero.

## Non-scope
No selection of gross P&L versus net P&L.
No fee aggregation.
No FX conversion.
No direct entry/stop monetary-risk assumption.
No market-specific multiplier/tick/lot semantics.
No TradeMetrics wiring.
No persistence, schema, UI, routing, journal history, market API, or network changes.

## Persistence
None.

## Security
No new surface.

## Theme
No impact.

## Offline
Pure synchronous local domain composition.

## Tests
Covers profitable, exact decimal, loss, zero-risk, malformed result, malformed risk-per-unit, and malformed quantity evidence.

## Regression
P1 and every existing P11 verifier through P11.12 are rerun locally, plus the new P11.13 verifier. Canonical GitHub gate must run the full build, unit suite, and P1-P11.13 regression chain.

## Performance
Constant number of bounded arbitrary-precision decimal operations.

## Known limitations
TradeMetrics remains incomplete by design because the project has not locked the authoritative result-amount semantics for realized R, particularly around future fees and currency conversion.

## Real-device status
Not required; pure domain calculation with no device/UI behavior.

## Result
HOLD pending canonical GitHub gate.

## Next
Only after PASS, reassess whether P11 requires an explicit calculation completeness/orchestration contract before any TradeMetrics derived-field wiring.
