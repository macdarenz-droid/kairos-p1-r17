# KAIROS P16.1 — Binance Spot Trade Stream Semantics

## BASE
P15.14 Market Data Adapter System Closure — canonical PASS.

## OBJECTIVE
Introduce the first concrete provider-specific market-data naming boundary for Binance Spot without creating a WebSocket connection yet.

BTCUSDT is the initial proving symbol only. The implementation must remain data-driven so other supported Binance Spot symbols can use the same owner.

## RESEARCH
Current Binance Spot stream documentation states that symbols in WebSocket stream names are lowercase. The Spot Trade Stream is `<symbol>@trade`, updates in real time, and includes trade price `p`, event time `E`, symbol `s`, trade time `T`, and other trade evidence.

The Binance documentation also separates public market-data streams from authenticated user/account streams. P16.1 therefore uses public market-data semantics only and introduces no API key or account integration.

## OWNER TRACE
Existing provider-neutral boundary:
P15 MarketDataInstrument -> P16 provider descriptor -> later P16 transport adapter -> P15 MarketDataAdapter observations.

New owner:
`src/services/market-data/providers/binance/binanceSpotTradeStream.ts`

## CHANGE
- Adds the stable venue identity `binance-spot`.
- Records `BTCUSDT` as the initial proving symbol.
- Produces the Binance Spot raw trade stream name from any non-empty Binance Spot symbol.
- Lowercases the symbol for the stream name as required by Binance.
- Adds tests proving BTCUSDT is not hard-coded as the only symbol.
- Exports the provider owner through the existing market-data barrel.

## NON-SCOPE
- no WebSocket constructor;
- no network connection;
- no REST fetch;
- no symbol catalogue discovery yet;
- no API key;
- no account/user stream;
- no order execution;
- no reconnect loop;
- no concrete timer;
- no entropy source;
- no chart engine;
- no persistence;
- no journal/P&L mutation.

## DATA/STATE FLOW
`MarketDataInstrument { venue: 'binance-spot', symbol }`
-> Binance Spot trade-stream descriptor
-> `<lowercase-symbol>@trade`

Future P16 transport work will consume this descriptor.

## SECURITY
Public/read-only market-data semantics only. No credentials.

## OFFLINE
No network owner is introduced in this patch. Existing local/offline journal behavior is unaffected.

## TESTS
- BTCUSDT -> btcusdt@trade.
- ETHUSDT -> ethusdt@trade, proving symbol data-driven behavior.
- wrong venue rejected.
- empty symbol rejected.

## REPAIR R1
Canonical Run #144 proved the build and the complete 469-test unit suite passed, including all four Binance Spot stream tests. The first controlled verifier then failed in the historical P1 static contract because the new provider source comment contained the exact infrastructure word `WebSocket`, which that legacy scope canary rejects outside its approved ownership paths.

R1 changes documentation wording in the provider source only: `WebSocket connections` -> `transport connections`. Runtime semantics are unchanged.

## RESULT
HOLD pending canonical GitHub gate for R1.
