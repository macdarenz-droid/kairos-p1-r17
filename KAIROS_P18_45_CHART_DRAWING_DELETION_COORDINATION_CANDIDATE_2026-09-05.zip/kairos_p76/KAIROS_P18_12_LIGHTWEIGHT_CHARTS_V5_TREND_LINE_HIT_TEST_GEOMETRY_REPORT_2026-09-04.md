# KAIROS P18.12 — Lightweight Charts v5 Trend-Line Hit-Test Geometry

## Authoritative base
P18.11 canonical PASS — run #209 / 33817711547 / head 81382a4534c57e067ab93b2ba0d04fa5eeb22a34.

## Controlled purpose
Add exactly one provider presentation boundary that maps a screen point plus explicit pixel tolerance to the top-most projected trend-line segment identity.

## Ownership
- P18.5 remains projected screen-geometry owner.
- P18.6 remains Canvas rendering owner.
- P18.7 remains primitive view lifecycle owner.
- P18.11 remains series/drawing presentation lifecycle coordinator.
- P18.12 owns only pure screen-space hit-test geometry.

## Official Lightweight Charts 5.2 evidence
`ISeriesPrimitiveBase.hitTest(x, y)` is the library hook for reporting the top-most hovered primitive item and optional cursor style. P18.12 deliberately stops before wiring that hook into the primitive; it first establishes the deterministic geometry boundary without introducing pointer subscriptions, selection, or editing state.

## Non-scope
No pointer/crosshair subscription; no primitive hitTest wiring; no selection; no drag/edit; no drawing truth mutation; no persistence; no autoscale; no calculations; no market acquisition; no journal truth; no toolbar; no P19 risk/reward.
