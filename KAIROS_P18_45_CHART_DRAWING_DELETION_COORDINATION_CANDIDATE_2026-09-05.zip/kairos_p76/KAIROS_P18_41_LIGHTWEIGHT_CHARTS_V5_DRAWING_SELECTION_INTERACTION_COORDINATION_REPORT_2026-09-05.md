# KAIROS P18.41 — Lightweight Charts v5 Drawing Selection Interaction Coordination

## Purpose
Compose P18.39 current-snapshot drawing-selection evidence into the existing P18.24 authoritative interaction session without adding provider lifecycle, another interaction-state owner, or drawing mutation.

## Authority / ownership
- P18.39 remains the sole provider hit + current renderer snapshot -> drawing-selection evidence owner.
- P18.22 remains the interaction-event vocabulary owner, including `select-drawing`.
- P18.23 remains the sole interaction transition acceptance owner.
- P18.24 remains the sole active ephemeral interaction state/dispatch owner.
- P18.40/P18.26 remain the single provider click evidence/subscription lifecycle path; P18.41 does not subscribe.

## Change
- Adds one narrow coordinator that receives an existing P18.24-compatible dispatcher, the caller's current renderer drawing snapshot, and one provider selection event.
- Delegates selection validation to P18.39.
- Invalid/stale/non-drawing evidence returns `null` and is never dispatched.
- Valid evidence is forwarded exactly once as the existing `select-drawing` event.
- Returns the authoritative dispatch result unchanged, so acceptance/rejection remains P18.23 semantics.

## Why this slice is required
P18.39 can prove a current drawing identity and P18.40 now preserves raw provider click evidence, but there was no owner-safe seam connecting validated selection evidence to P18.24. P18.41 establishes that composition without prematurely changing the provider lifecycle or creating parallel selection state.

## Explicit non-scope
- no provider `subscribeClick` / `unsubscribeClick` wiring;
- no second click subscription;
- no interaction-state storage or reducer logic;
- no drawing collection mutation;
- no editing/drag/delete execution;
- no persistence/restore;
- no toolbar/UI state or selection rendering;
- no new drawing kinds;
- no journal truth or calculation changes;
- no Risk/Reward semantics and no P19.
