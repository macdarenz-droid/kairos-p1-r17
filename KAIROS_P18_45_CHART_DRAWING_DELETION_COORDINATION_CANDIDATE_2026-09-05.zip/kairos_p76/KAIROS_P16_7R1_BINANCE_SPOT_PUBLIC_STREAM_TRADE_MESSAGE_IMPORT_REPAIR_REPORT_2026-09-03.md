# KAIROS P16.7R1 — Binance Spot Public Stream Trade Message Import Repair

## BASE
P16.6 remains authoritative. P16.7 Run #152 failed and is not authoritative.

## FAILURE
Canonical build failed TS2307 because the P16.7 composition owner imported `MarketDataObservation` from nonexistent `../../types`.

## REPAIR
Changed only that type import to the existing P15 owner `../../marketDataAdapter`.
No runtime mapping, lifecycle, persistence, UI, or journal-truth behavior changed.

## LOCAL
P1 static and P16.1-P16.7 static verifiers pass. Full canonical build/regression is required.

## RESULT
HOLD pending upload and canonical repair gate.
