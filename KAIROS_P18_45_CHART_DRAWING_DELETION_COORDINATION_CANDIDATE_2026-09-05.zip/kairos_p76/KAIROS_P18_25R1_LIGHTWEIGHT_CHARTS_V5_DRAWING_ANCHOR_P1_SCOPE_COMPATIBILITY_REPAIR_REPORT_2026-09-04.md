# KAIROS P18.25R1 — Lightweight Charts v5 Drawing Anchor P1 Scope Compatibility Repair

## Authoritative base
P18.24 Chart Drawing Interaction Port canonical PASS.

## Failed candidate evidence
P18.25 passed exact scope, deterministic install, Lightweight Charts 5.2.1 proof, production TypeScript, production build, its dedicated verifier/runtime, focused Vitest coverage, and the full 628-test unit suite. The canonical full controlled roadmap regression then failed at historical `verify:p1 -> verify:static` because `src/features/chart/lightweightChartsV5DrawingAnchorProjection.ts` imported `decimal.js` directly. The P1 static owner intentionally restricts that dependency to the calculation-domain boundary.

## Repair
Rebuild P18.25 from authoritative P18.24 and preserve the same drawing-anchor projection responsibility while removing direct calculation-library ownership from the chart feature.

Provider numeric price evidence is converted from JavaScript scientific notation to plain decimal notation by a local representation-only helper, then validated through the existing `parseDecimalString` domain parser. No arithmetic/calculation ownership is introduced in the chart feature.

## Responsibility retained
- provider event time + point -> provider-neutral `ChartDrawingAnchor`
- provider series `coordinateToPrice()` remains the provider price-coordinate owner
- missing/non-finite evidence fails closed
- scientific-notation provider numbers are represented as plain decimal strings before domain validation

## Explicit non-scope
- no click/pointer/crosshair subscription lifecycle
- no interaction dispatch
- no drawing mutation or persistence
- no toolbar/UI wiring
- no Risk/Reward behavior
- no P19
- no calculation-domain arithmetic owner moved into chart features

## Repair regression target
The canonical gate must specifically rerun historical P1 static verification in addition to P18.25R1, P18.24-P18.1, production TypeScript/build, full unit regression, full controlled roadmap regression, and historical closures.
