# Kairos P18.36 — Chart Drawing Collection Projection

## Authority

Base: P18.35 — Chart Trend-Line Commit Collection Coordination, canonical PASS #241.

## Proven gap

P18.35 completes the provider-neutral path from a previewed trend-line draft to a committed `ChartDrawing` stored by the P18.33 collection. The committed collection still exposes domain drawing truth, while every drawing-layer/presentation/hover boundary consumes `RendererChartDrawing`. Without one owned collection projection seam, later presentation or selection composition would need to reimplement `map(projectChartDrawing)` ad hoc.

## Controlled change

P18.36 extends the existing P18.2 drawing projection owner with `projectChartDrawings(drawings)`. The function projects one readonly drawing snapshot in insertion order by delegating every element to the already-authoritative `projectChartDrawing` function.

## Ownership preserved

- P18.1 remains committed drawing truth owner.
- P18.2 remains the sole domain drawing -> renderer drawing projection owner.
- P18.33 remains the sole committed in-memory drawing collection owner.
- P18.35 remains commit-to-collection coordination owner.
- P18.11 remains presentation lifecycle owner.
- Provider APIs remain behind the existing P18 Lightweight Charts boundaries.

## Explicit non-scope

No collection mutation, presentation lifecycle, provider API, click/hover subscription, selection state, editing/deleting, persistence/restore, journal truth, calculation logic, Risk/Reward semantics, or P19 behavior.

## Verification intent

The dedicated verifier pins ordered delegation to `projectChartDrawing`, export/package/test coverage, and forbids provider/persistence/interaction/presentation ownership leakage. Historical P18/P17 and roadmap closures remain required by canonical CI.
