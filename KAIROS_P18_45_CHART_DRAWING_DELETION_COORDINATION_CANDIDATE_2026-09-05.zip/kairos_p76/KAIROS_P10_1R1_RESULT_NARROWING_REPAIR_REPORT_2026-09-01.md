# KAIROS P10.1R1 Result Narrowing Repair Report — 2026-09-01

## Status
HOLD pending authoritative GitHub controlled gate.

## Authoritative base
KAIROS_P9_2R4_ACTIVATION_BACKUP_COUNT_CONTRACT_REPAIR_CANDIDATE_2026-09-01.zip
SHA-256: 146bb9f9401b2cd6222c3da5adb554c49bd7946db6cf31c4877c9f72007c72a7

## Failed predecessor
P10.1 failed at TypeScript build. It is discarded and is not an authoritative base.

## Objective
Restore the P10.1 manual-trade save-command foundation using the smallest coherent repair, rebuilt fresh from P9.2R4.

## Repair
The command preparation function returns either a prepared aggregate or a typed validation failure. P10.1 used a compound check that did not narrow the union sufficiently for TypeScript 7.0.2. P10.1R1 uses the presence of the validation result discriminant (`ok`) as an explicit type guard and immediately returns that branch. The remaining branch is therefore statically narrowed to the prepared aggregate before persistence properties are accessed.

## Preserved architecture
- UI does not write IndexedDB directly.
- Validation/normalization occurs before the transaction.
- Trade + optional plan + executions + fees are written through one short atomic repository transaction.
- Missing optional financial values remain null; they are not silently converted to zero.
- No P11 calculations were added.
- No database schema, domain owner, activation, design-system, navigation, backup/restore, or theme behavior was changed.

## Research check
TypeScript's current handbook recommends explicit narrowing of union members through discriminants or the `in` operator. Dexie continues to define `transaction()` as the atomic transaction boundary for scoped tables.

## Required verification
- deterministic install
- TypeScript/production build
- full unit regression
- P1 through P9 regressions
- P10.1 command verifier
- atomic rollback regression
- missing-financial-value regression

No candidate is promoted unless the entire GitHub gate passes.
