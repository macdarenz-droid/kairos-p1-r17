# KAIROS P18.24 — Chart Drawing Interaction Port

## Controlled base
Canonical P18.23 PASS, GitHub Actions run #227 / 33865488099.

## Evidence basis
The controlling Kairos drawing architecture requires one explicit drawing interaction state machine/reducer rather than contradictory UI flags. Canonical P18.21 owns the provider-neutral interaction-state shape. Canonical P18.22 owns the provider-neutral event vocabulary. Canonical P18.23 owns the pure state/event transition semantics and explicitly owns no provider/UI lifecycle.

After P18.23 there is still no single owner for the **ephemeral current interaction state of an active session**. Leaving that state to future UI, pointer, or provider adapters would create multiple state owners and violate the one-owner rule. P18.24 therefore adds only the provider-neutral session/dispatch lifecycle around the already-authoritative reducer.

No external provider API research is required for this slice because it introduces no browser, pointer, Lightweight Charts, persistence, or other external API behavior. Its correctness is determined by the existing Kairos state/event/reducer contracts.

## Responsibility added
Adds the sole provider-neutral active interaction-session owner:
- each created session starts from `INITIAL_CHART_DRAWING_INTERACTION_STATE`;
- `getState()` exposes that session's current ephemeral state;
- `dispatch(event)` delegates every transition to P18.23 `reduceChartDrawingInteraction`;
- state-change notification occurs only when the reducer produces a different state object;
- invalid reducer no-ops therefore do not emit synthetic state changes;
- separate sessions remain isolated;
- `destroy()` is idempotent and later use fails closed.

## Ownership preserved
- P18.1 remains drawing truth owner.
- P18.11/P18.20 remain presentation lifecycle/hover coordination owners.
- P18.14-P18.19 retain provider hover/resolution/subscription/lifecycle ownership.
- P18.21 remains interaction-state shape owner.
- P18.22 remains interaction-event shape owner.
- P18.23 remains interaction transition-semantics owner.
- P18.24 owns only ephemeral active interaction-session state and dispatch lifecycle.

## Explicit non-scope
No pointer/click subscription, DOM event listener ownership, pointer capture, gesture recognition, screen-to-market coordinate conversion, anchor collection, drawing creation/update/delete mutation, persistence, toolbar UI, selection rendering, drag/edit execution, undo/redo, new drawing kinds, horizontal line, rectangle/order block, freehand, Risk/Reward behavior or visuals, journal truth, market truth, calculations, navigation, dependency migration, or P19 work.

## Changed-file contract
Exactly six files relative to canonical P18.23:
1. `KAIROS_P18_24_CHART_DRAWING_INTERACTION_PORT_REPORT_2026-09-04.md`
2. `package.json`
3. `scripts/verify-p18-24-chart-drawing-interaction-port.mjs`
4. `src/features/chart/chartDrawingInteractionPort.ts`
5. `src/features/chart/index.ts`
6. `tests/chart-drawing-interaction-port.test.ts`

## Verification intent
Dedicated verification must prove single-session state ownership, reducer delegation, no-op notification suppression, isolated sessions, fail-closed destruction, preserved P18.21-P18.23 contracts/exports, and absence of provider/persistence/P19 boundaries. Canonical gate must additionally prove deterministic install, production TypeScript/build, dedicated runtime tests, full unit regression, P18/P17 regression chain, historical closures, exact scope, candidate artifact, and gate evidence before promotion.
