# KAIROS P15.12 — Market Data Reconnect Attempt Semantics

## BASE
P15.11 canonical PASS — Run #139.

## OBJECTIVE
Compose the P15.11 pre-planning intent gate with the P15.8 bounded jittered plan without introducing scheduling or provider ownership.

## RESEARCH
AWS retry guidance recommends retries for transient failures with bounded backoff and fail-fast behavior for non-transient failures. MDN exposes WebSocket close details as transport facts. P15.12 therefore stays above transport normalization and below scheduling.

## OWNER TRACE
P15.10 owns normalized reconnect eligibility.
P15.11 owns pre-planning reconnect intent.
P15.5/P15.7/P15.8 own bounded retry planning.
P15.6 owns one-shot scheduling/cancellation.
P15.9 owns plan-to-scheduler coordination.
P15.12 composes P15.11 intent with P15.8 planning only.

## CHANGE
`planMarketDataReconnectAttempt(...)`:
- intentional/terminal causes stop before sample validation;
- transient cause proceeds to P15.8 planning;
- attempt-limit remains explicit stop;
- invalid policy/sample remain explicit invalid;
- accepted retry returns the authoritative P15.8 plan.

## NON-SCOPE
No scheduling.
No reconnect callback execution.
No provider/API.
No WebSocket/CloseEvent interpretation.
No entropy acquisition.
No persistence.
No UI/chart.
No execution/Calculation Engine/P&L mutation.
No secrets.

## RESULT
HOLD pending canonical GitHub gate.
