# Kairos P1 Verification Report — R13
Date: 2026-08-31
Status: HOLD

## Objective
Prove that the R12 lock-integrity verifier itself behaves correctly before relying on it as part of the P1 gate.

## Research
npm documents package-lock.json as the exact dependency-tree record intended for reproducible CI installs. npm ci requires an existing lockfile, rejects package.json/lock mismatches, and never rewrites the lock. npm v9+ uses lockfileVersion 3.

## Controlled change
Added a dependency-free temporary-fixture test harness for `verify-p1-lock.mjs`.

Cases:
1. Missing lock -> HOLD.
2. Matching lock fixture -> PASS.
3. Root manifest drift -> FAIL.
4. Direct dependency version drift -> FAIL.
5. Missing integrity hash -> FAIL.

Fixtures are created only in the OS temporary directory and are deleted after each case. No fake package-lock.json is added to the candidate.

## Evidence
- Exact toolchain: PASS.
- Static P1 contract: PASS.
- Existing gate classifier: PASS.
- Lock verifier tests: PASS (5/5).
- Real candidate lock state: HOLD because package-lock.json remains unavailable while npm registry access is blocked.
- No app/runtime source changed.

## Decision
HOLD. P0 remains authoritative. P2 remains locked.
