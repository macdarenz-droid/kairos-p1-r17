# KAIROS P18.11 — Chart Drawing Presentation Coordination

## Authority
Built only from canonical P18.10R1 PASS (GitHub Actions run #208, run ID 33815952262, head 55541491273e687eaae8d345b3cfee7e3bfe3800).

## Controlled purpose
Add the provider-neutral presentation-resource seam that coordinates one projected chart series with one P18 drawing-layer attachment using the exact same neutral series handle.

## Ownership preserved
- P17 `ChartEngineDriver` remains series/chart resource owner.
- P18.3 `ChartDrawingLayerPort` remains drawing attachment lifecycle owner.
- P18.10R1 remains the Lightweight Charts v5 trend-line drawing-layer composition owner.
- P18.11 owns only ordering/cleanup coordination between those established presentation resources.

## Lifecycle invariant
A replacement detaches the active drawing layer before removing its series. The fresh drawing layer is attached to the exact freshly-created series handle. Partial replacement failure is cleaned up before the error is rethrown. Destroy is idempotent and releases drawing resources before series/chart resources.

## Explicit non-scope
No drawing truth mutation, hit testing, pointer/crosshair handling, drag/edit behavior, toolbar, persistence, autoscale ownership, calculations, market acquisition, journal truth, risk/reward logic, or P19 behavior.

## Verification
Dedicated P18.11 static verifier: PASS locally. Canonical GitHub gate remains authoritative for TypeScript, build, Vitest, full roadmap regression, historical closures, and artifact promotion.
