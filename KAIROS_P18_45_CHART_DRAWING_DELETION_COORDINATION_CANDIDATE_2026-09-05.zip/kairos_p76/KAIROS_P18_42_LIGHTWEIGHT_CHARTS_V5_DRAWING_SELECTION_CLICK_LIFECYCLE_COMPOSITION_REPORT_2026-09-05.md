# KAIROS P18.42 — Lightweight Charts v5 Drawing Selection Click Lifecycle Composition

## Purpose
Connect P18.40 raw provider-click evidence and P18.41 drawing-selection interaction coordination inside the existing P18.30 provider click lifecycle, without adding a second `subscribeClick` owner or a second interaction-state owner.

## Authority / ownership
- P18.26 remains the sole `subscribeClick` / `unsubscribeClick` lifecycle owner.
- P18.27/P18.40 remain the provider chart/series binding and same-click evidence fan-out path.
- P18.39 remains the sole provider hit + current renderer snapshot -> drawing-selection evidence owner.
- P18.41 remains the sole selection evidence -> existing interaction-dispatch coordination owner.
- P18.23 remains the sole interaction transition-acceptance owner.
- P18.24 remains the sole active ephemeral interaction state/dispatch owner.
- P18.29/P18.30 remain the existing trend-line draft interaction/lifecycle path.

## Change
- Extends the existing P18.30 binding composition with one optional caller-supplied `getCurrentRendererDrawings` snapshot provider.
- Preserves the original three-argument P18.30 path unchanged when no selection snapshot provider is supplied.
- When supplied, the same raw click already observed by P18.40 is delegated to P18.41 before the unchanged anchor delivery.
- The current renderer snapshot is read at click time, so stale drawing IDs still fail closed through P18.39.
- The selection dispatcher is the same P18.24-backed draft interaction session; no parallel selection state is introduced.
- Existing P18.23 state semantics remain authoritative: an idle click can select a current drawing, while an active selected tool keeps tool precedence and the existing anchor path proceeds normally.

## Why this slice is required
P18.40 made one provider click safely observable without another subscription, and P18.41 made validated selection evidence dispatchable without owning lifecycle. The remaining gap was lifecycle composition: the production provider-click path still delivered only anchors through P18.30. P18.42 closes that seam by wiring selection into the same existing click lifecycle.

## Explicit non-scope
- no second provider click subscription;
- no new provider capability or neutral-handle leakage;
- no new interaction reducer/state owner;
- no selection projection duplication;
- no drawing collection mutation;
- no editing/drag/delete execution;
- no persistence/restore;
- no toolbar/UI selection rendering;
- no drawing-only presentation refresh behavior;
- no new drawing kinds;
- no journal truth or calculation changes;
- no Risk/Reward semantics and no P19.
