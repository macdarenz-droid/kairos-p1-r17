# KAIROS P18.19 — Lightweight Charts v5 Drawing Hover Port Composition

## Controlled base
Canonical P18.18R2 PASS, GitHub Actions run 33855627608.

## Responsibility added
Adds the single production composition that connects the provider-neutral P18.18 `ChartDrawingHoverPort` lifecycle to the already-owned P18.17 Lightweight Charts v5 drawing-hover binding.

## Ownership preserved
- P18.18 remains the provider-neutral hover lifecycle owner.
- P18.17 remains the provider chart-resolution/subscription/projection composition owner.
- P18.15 remains the exact subscribe/unsubscribe lifecycle owner.
- P18.14 remains the hovered-object projection owner.
- P18.16 remains the neutral-series-handle to provider-chart identity owner.
- P18.19 only adapts the existing P18.17 subscription lifecycle to P18.18's driver contract.

## Explicit non-scope
No click selection, drag/edit, drawing mutation, persistence, calculations, market acquisition, journal truth, toolbar state, navigation state, autoscale policy, presentation-session integration, phase P19 Risk/Reward implementation, dependency migration, or provider API reimplementation.

## Changed-file contract
Exactly six files relative to canonical P18.18R2:
1. `KAIROS_P18_19_LIGHTWEIGHT_CHARTS_V5_DRAWING_HOVER_PORT_COMPOSITION_REPORT_2026-09-04.md`
2. `package.json`
3. `scripts/verify-p18-19-lightweight-charts-v5-drawing-hover-port-composition.mjs`
4. `src/features/chart/index.ts`
5. `src/features/chart/lightweightChartsV5DrawingHoverPortComposition.ts`
6. `tests/lightweight-charts-v5-drawing-hover-port-composition.test.ts`

## Verification intent
Dedicated verifier proves the new boundary delegates to P18.18/P18.17 and does not directly own provider crosshair APIs or unrelated truth. Canonical gate must additionally prove deterministic install, exact Lightweight Charts 5.2.1 dependency, TypeScript, production build, dedicated runtime tests, full unit regression, P18/P17 regression chain, and historical closures before promotion.
