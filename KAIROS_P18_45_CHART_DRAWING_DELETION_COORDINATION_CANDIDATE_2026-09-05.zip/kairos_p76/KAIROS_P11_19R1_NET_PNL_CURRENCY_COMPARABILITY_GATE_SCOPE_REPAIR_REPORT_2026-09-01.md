# KAIROS P11.19R1 — Net P&L Currency Comparability Gate Scope Repair

Status: HOLD pending canonical GitHub gate.

## Authoritative base
P11.18R2 TradeMetrics Fee Evidence Wiring Compatibility Repair.

## Repair reason
P11.19 was rejected at controlled-scope verification because the gate expected two filenames that were not part of the candidate and omitted two files that were actually changed. Per A35, the failed P11.19 candidate was not used as a base. P11.19R1 is reconstructed fresh from authoritative P11.18R2 and reapplies the same narrow calculation-policy implementation.

## Objective
Add the Calculation Engine policy boundary required before TradeMetrics may compose gross P&L and fees into net P&L. Kairos must never silently subtract unlike or unknown monetary currencies.

## Contract
`assessNetPnlCurrencyCompatibility(totalFees, grossPnlCurrency, totalFeesCurrency)`:
- validates fee amount through the locked decimal kernel;
- authoritative zero fees are unit-neutral and may be composed without currency invention;
- non-zero fees require explicit gross-P&L currency evidence;
- non-zero fees require explicit fee currency evidence;
- non-zero fees require exact matching currency evidence;
- unlike currencies return `currency-mismatch`;
- malformed decimals return `invalid-decimal`;
- performs no FX conversion or currency inference.

## Non-scope
- no `netPnl` wiring into TradeMetrics;
- no FX conversion;
- no account/quote-currency inference;
- no P33 Currency Engine work;
- no persistence/schema/UI/navigation changes.

## Controlled changed files
1. `KAIROS_P11_19R1_NET_PNL_CURRENCY_COMPARABILITY_GATE_SCOPE_REPAIR_REPORT_2026-09-01.md`
2. `package.json`
3. `scripts/verify-p11-net-pnl-currency-policy.mjs`
4. `src/domain/calculations/index.ts`
5. `src/domain/calculations/netPnlCurrencyPolicy.ts`
6. `tests/net-pnl-currency-policy.test.ts`

## Gate-scope correction
The canonical P11.19R1 gate must require exactly the six files above. It must not require `scripts/verify-p11-net-pnl-currency-comparability.mjs` or `tests/net-pnl-currency-comparability.test.ts`, because those files do not exist in this controlled patch.

## Performance / persistence / security
Pure synchronous calculation only; no persistence, observers, timers, network, UI, or new main-thread lifecycle machinery.

## Result
HOLD pending canonical GitHub gate.
