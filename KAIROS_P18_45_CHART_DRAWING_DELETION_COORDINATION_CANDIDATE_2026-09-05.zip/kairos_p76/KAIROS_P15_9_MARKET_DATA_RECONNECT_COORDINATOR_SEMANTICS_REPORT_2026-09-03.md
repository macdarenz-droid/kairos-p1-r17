# KAIROS P15.9 — Market Data Reconnect Coordinator Semantics

## BASE
P15.8R2 canonical PASS (Run #136).

## OBJECTIVE
Add one provider-neutral coordinator that composes the existing reconnect plan owner (P15.8) with the existing one-shot scheduler owner (P15.6).

## RESEARCH
Current MDN AbortSignal guidance emphasizes explicit listener cleanup when an operation finishes normally and notes that `{ once: true }` removes a listener only if abort actually fires. P15.6 already owns that cancellation/listener lifecycle, so P15.9 delegates cancellation to P15.6 rather than creating another AbortSignal listener owner.

## OWNER TRACE
P15.5: bounded deterministic retry decision.
P15.7: pure full-jitter transformation using an externally supplied sample.
P15.8: pure retry/stop/invalid planning composition.
P15.6: one-shot scheduling/cancellation and AbortSignal cleanup.
P15.9: composition boundary that schedules only an accepted P15.8 retry plan.

## PRE-CHANGE FLOW
policy + completedAttempts + external sample -> P15.8 plan.
P15.6 scheduler existed separately.

## CHANGE
`coordinateNextMarketDataReconnect(...)`:
- obtains a P15.8 plan;
- returns stop/invalid without scheduling;
- schedules exactly one retry through P15.6 when the plan is retry;
- exposes the accepted plan and schedule cancellation handle.

## NON-SCOPE
No provider selection.
No WebSocket/EventSource/fetch.
No concrete timer API.
No Math.random or entropy acquisition.
No retryability/error classification.
No multi-attempt reconnect loop.
No persistence.
No UI/chart.
No execution, Calculation Engine, or P&L mutation.
No secrets.

## DATA / STATE FLOW
External caller -> P15.9 -> P15.8 -> P15.5/P15.7.
Accepted retry -> P15.9 -> P15.6 scheduler.
AbortSignal cancellation remains owned by P15.6.

## TESTS
Dedicated tests cover:
- jittered delay scheduling;
- no scheduling at attempt limit;
- no scheduling for invalid policy;
- no scheduling for invalid sample;
- AbortSignal cancellation delegated to P15.6.

## RESULT
HOLD pending canonical GitHub gate.
