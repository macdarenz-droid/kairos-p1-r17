# KAIROS P15.11 — Market Data Reconnect Intent Semantics

## BASE
P15.10 canonical PASS — Run #138.

## OBJECTIVE
Add one pure provider-neutral boundary that applies P15.10 reconnect eligibility before any P15.8 planning or P15.6 scheduling can occur.

## RESEARCH
AWS retry guidance recommends retrying transient failures with bounded backoff and failing fast for non-transient failures. MDN exposes WebSocket close transport facts (`code`, `reason`, `wasClean`) but those remain adapter facts rather than core reconnect policy. P15.11 therefore consumes only the normalized P15.10 disconnect cause.

## OWNER TRACE
P15.10: normalized disconnect cause -> reconnect eligibility.
P15.5: bounded retry decision.
P15.7: jitter transform.
P15.8: retry plan.
P15.6: one-shot scheduler/cancellation.
P15.9: plan-to-scheduler coordinator.
P15.11: pre-planning reconnect intent gate.

## CHANGE
`resolveMarketDataReconnectIntent(...)`:
- transient failure preserves policy + completedAttempts for later retry planning;
- intentional close stops before planning;
- terminal failure stops before planning.

## NON-SCOPE
No call to P15.8 planning.
No call to P15.9 coordination.
No scheduling/timers.
No WebSocket/CloseEvent interpretation.
No provider/API.
No entropy.
No persistence.
No UI/chart.
No execution/Calculation Engine/P&L mutation.
No secrets.

## RESULT
HOLD pending canonical GitHub gate.
