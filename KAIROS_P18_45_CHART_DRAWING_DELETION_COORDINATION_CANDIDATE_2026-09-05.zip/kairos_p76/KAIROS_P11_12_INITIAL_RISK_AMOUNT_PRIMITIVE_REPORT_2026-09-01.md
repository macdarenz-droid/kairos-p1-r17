# KAIROS P11.12 Initial Risk Amount Primitive Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.11 authoritative PASS from controlled gate run #32.

## Objective
Extend the protected RiskCalculator with the smallest market-neutral monetary initial-risk primitive needed before future `realizedR` or TradeMetrics initial-risk wiring can be considered.

## Research
The locked handoff requires all derived financial metrics to originate in the Calculation Engine, missing financial evidence not to become zero, and market/instrument-specific policies to sit below the common engine.
The project remains on its locked decimal.js kernel. Current decimal.js documentation continues to recommend string inputs where precision matters and supports arbitrary-precision multiplication; P11.12 therefore routes through the existing decimal kernel rather than JavaScript Number arithmetic.

## Owner trace
Future market/instrument policy
-> authoritative monetary risk-per-unit evidence
-> P11.12 RiskCalculator `calculateInitialRiskAmount`
-> future RMultipleCalculator / TradeMetrics consumers.

## Pre-change flow
P11.8 could calculate absolute entry/stop price distance only.
That value was deliberately not treated as universal monetary risk.
P11.7 R-multiple therefore remained intentionally unwired to TradeMetrics.

## Change
Adds `calculateInitialRiskAmount(riskPerUnit, quantity)` to the existing protected RiskCalculator.
The primitive performs exact decimal multiplication only.

Also narrows the legacy P11.8 static verifier to inspect the `calculateRiskPriceDistance` function scope rather than rejecting future functions added to the same protected RiskCalculator module. The P11.8 prohibition on multiplication inside price-distance calculation remains intact.

## Contract
`initialRisk = authoritative riskPerUnit * authoritative quantity`

The function does not derive either input.

## Missing / zero semantics
Malformed evidence returns explicit `invalid-decimal`.
A genuine zero input remains genuine zero.
Missing evidence is not represented by this primitive and must not be converted to zero upstream.

## Non-scope
No direct multiplication of entry/stop price distance by quantity.
No universal spot/share assumption.
No market-specific conversion.
No contract multiplier, tick value, lot-size, FX conversion, margin, or leverage logic.
No TradeMetrics wiring.
No realized-R wiring.
No persistence, UI, schema, journal history, market API, or network changes.

## Persistence
None.

## Security
No new surface.

## Theme
No impact.

## Offline
Pure synchronous local calculation.

## Tests
Covers standard multiplication, exact decimals, genuine zero values, malformed inputs, and negative evidence without silent normalization.

## Regression
Local static checks cover P1 and P11.1R2 through P11.12. Canonical GitHub gate must additionally run build, full unit regression, and all controlled P2-P10 regressions.

## Performance
One decimal multiplication; constant-time for bounded input sizes used by the domain.

## Known limitations
P11.12 requires an upstream owner to supply monetary risk-per-unit evidence. Current raw planned price distance alone is intentionally insufficient for universal market semantics.

## Real-device status
Not required; pure domain arithmetic with no device/UI behavior.

## Result
HOLD pending canonical GitHub gate.

## Next
Only after PASS, assess whether the new authoritative initial-risk evidence can be safely composed with RMultipleCalculator without inventing market or missing-data semantics.
