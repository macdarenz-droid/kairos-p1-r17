# KAIROS P11.16 Net P&L Primitive Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.15 authoritative PASS from controlled gate run #36, artifact 9798097773.

## Objective
Add the smallest safe net-P&L arithmetic owner required by the locked P11 Calculation Brain contract.

## Formula
`netPnl = authoritative grossPnl - authoritative totalFees`

Both inputs must already represent comparable monetary evidence.

## Currency boundary
P11.16 does not inspect currencies and does not convert them. The caller must only supply gross P&L and total fees after establishing that they share the same monetary unit. This avoids silently treating unlike currencies as comparable money.

## Arithmetic
All subtraction goes through the locked arbitrary-precision decimal kernel. No JavaScript Number authority is introduced.

## Non-scope
- no TradeFeeRecord aggregation;
- no TradeMetrics wiring;
- no P&L percentage;
- no realized-R result selection;
- no FX conversion;
- no market-specific rules;
- no persistence, UI, history, chart, or network work.

## Tests
Covers profitable trade, exact decimal precision, losing trade, fees turning a gross profit into a net loss, zero fees, malformed gross P&L, and malformed fee totals.

## Regression
P1 and every existing P11 static verifier through P11.15 are rerun locally, plus P11.16. Canonical GitHub gate must still run build, full unit regression, P1-P11.16, and artifact capture.

## Result
HOLD pending canonical GitHub gate.
