# KAIROS P14.5R2 — Journal Trade Map Historical Selector Compatibility Repair

## Patch/Base/app/build identity
- Authoritative base: `KAIROS_P14_4R1_JOURNAL_TRADE_MAP_FIXTURE_CONTRACT_REPAIR_CANDIDATE_2026-09-02.zip`
- Failed input candidate: `KAIROS_P14_5R1_JOURNAL_TRADE_MAP_ACCESSIBILITY_ID_OWNERSHIP_REPAIR_CANDIDATE_2026-09-02.zip`
- Repair candidate: `KAIROS_P14_5R2_JOURNAL_TRADE_MAP_HISTORICAL_SELECTOR_COMPATIBILITY_REPAIR_CANDIDATE_2026-09-03.zip`
- App: Kairos Trading Journal
- Phase: P14 Trade Visualizer

## OBJECTIVE
Repair the canonical P14.5R1 full-unit regression failure without changing production behavior or weakening the P14.4 exact-facts contract.

## RESEARCH
Canonical Run #110 proved the P14.5R1 production build and the new dedicated SVG runtime test pass. The sole unit failure is a historical Testing Library selector assumption: `getByText('Actual exit')` requires one matching node, while P14.5 intentionally renders the same semantic label in both the supplementary SVG and the authoritative HTML facts list.

## OWNER TRACE
- P14.1 owns trade facts.
- P14.2 owns display semantics, including the label `Actual exit`.
- P14.3 owns Journal projection.
- P14.4R1 owns the exact native HTML fact/value surface.
- P14.5 owns the supplementary categorical SVG.
- Historical tests must target the owner they intend to verify and must not impose uniqueness across separate presentation surfaces.

## PRE-CHANGE FLOW
`JournalHistoryEntry` → P14.1 facts → P14.2 semantics → P14.3 projection → P14.4R1 HTML exact facts + P14.5 supplementary SVG.

The failed historical assertion selected the label globally. Once P14.5 legitimately repeated `Actual exit` inside SVG text, the global singular selector became ambiguous even though both surfaces were semantically correct.

## CHANGE
- Production code: unchanged from failed P14.5R1.
- Historical P14.4 presentation test now finds the authoritative exit value `118.625` and asserts its owning HTML fact row contains the exact `Actual exit` + `118.625` pair.
- This preserves the P14.4 contract while allowing P14.5's supplementary SVG to reuse the same P14.2 semantic label.

## NON-SCOPE
No production behavior changes, no SVG redesign, no display-model/domain changes, no DB/repository changes, no market data, no current/live price, no candles, no synthetic path, no scaling, no calculations, no FX, no animation, no P15+.

## DATA/STATE FLOW
Unchanged.

## PERSISTENCE
Unchanged.

## SECURITY
Unchanged.

## THEME
Unchanged.

## OFFLINE
Unchanged.

## TESTS
Canonical Run #110:
- scope PASS
- deterministic install PASS
- build PASS
- dedicated `journal-trade-map-graphic.test.tsx` PASS
- full unit regression: 406 PASS / 1 FAIL
- sole failure: historical `journal-trade-map-presentation.test.tsx` singular global text selector found both SVG `<text>` and HTML `<dt>` nodes for `Actual exit`.

P14.5 static verifier and historical static regressions are rerun locally for this repair. Canonical GitHub build/unit/full regression remains required for promotion.

## REGRESSION
The repair strengthens ownership precision in the historical test and does not alter production. P14.4R1 exact prices and labels remain required; P14.5 supplementary SVG remains allowed to expose the same semantic label.

## PERFORMANCE
No production change.

## KNOWN LIMITATIONS
The SVG remains categorical and explicitly not to scale. Exact prices remain in native HTML.

## REAL-DEVICE STATUS
Not claimed.

## RESULT
HOLD pending canonical P14.5R2 gate.
