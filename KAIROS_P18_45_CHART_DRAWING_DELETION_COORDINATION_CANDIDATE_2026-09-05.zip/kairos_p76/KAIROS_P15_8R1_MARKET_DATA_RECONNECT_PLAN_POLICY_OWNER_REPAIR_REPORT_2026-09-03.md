# KAIROS P15.8R1 — Market Data Reconnect Plan Policy Owner Repair

## BASE
P15.7 canonical PASS. P15.8 Run #134 failed at build.

## FAILURE
P15.8 referenced nonexistent `getMarketDataReconnectDecision`.
Authoritative P15.5 exports `decideMarketDataReconnect` with a `retry` discriminant.

## REPAIR
P15.8 only now calls the existing P15.5 owner and maps its existing failure reasons:
- attempt-limit -> stop
- invalid-policy -> invalid
P15.7 remains the jitter owner.

## NON-SCOPE
No P15.5/P15.6/P15.7 production changes. No provider, timers, randomness acquisition, persistence, UI, chart, execution, calculation/P&L, or secrets.

## RESULT
HOLD pending canonical GitHub gate.
