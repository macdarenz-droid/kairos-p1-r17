# KAIROS P18.26 — Lightweight Charts v5 Drawing Click Subscription Lifecycle

## Authoritative base
P18.25R1 Lightweight Charts v5 Drawing Anchor P1 Scope Compatibility Repair canonical PASS #230.

## Research
Current official Lightweight Charts 5.2 API documentation was re-checked before implementation. `IChartApi` exposes paired `subscribeClick(handler)` / `unsubscribeClick(handler)` lifecycle methods. `MouseEventParams` exposes optional event `time` and `point`; P18.25R1 already owns fail-closed projection of those provider values plus series `coordinateToPrice()` evidence into a provider-neutral `ChartDrawingAnchor`.

## Owner trace
- P18.24 remains the provider-neutral active interaction-session/state owner.
- P18.25R1 remains the sole provider event point/time + price-coordinate -> Kairos `ChartDrawingAnchor` projection owner.
- P18.26 owns only Lightweight Charts click subscribe/unsubscribe lifecycle and delegates every click projection to P18.25R1.
- Provider chart/series identity resolution remains with the existing P18.9/P18.16 provider-resource binding; this slice does not resolve those resources yet.

## Change
Add one provider-specific drawing-click subscription boundary that:
- registers exactly one click handler;
- emits the P18.25R1 projected anchor or `null` when evidence is insufficient;
- delegates y-coordinate -> price conversion to the active provider series;
- unsubscribes the exact registered handler once;
- ignores later delivery after idempotent destroy.

## Explicit non-scope
- no provider chart/series resolution composition
- no interaction-session dispatch
- no first/second anchor collection
- no preview/commit semantics
- no drawing mutation or persistence
- no toolbar/UI state
- no pointer capture / drag / edit
- no new drawing kinds
- no Risk/Reward behavior
- no P19

## Data/state flow
Provider click event -> P18.26 subscription lifecycle -> P18.25R1 anchor projection -> callback only.

No journal truth, drawing truth, persistence, or interaction state is mutated by this slice.

## Regression target
Canonical gate must prove exact six-file scope, deterministic install, Lightweight Charts 5.2.1, production TypeScript/build, P18.26 verifier/runtime, P18.25R1 through prior P18 regressions, full unit regression, full controlled roadmap regression, and historical closures.
