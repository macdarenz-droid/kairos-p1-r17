# KAIROS P17.7 — Chart Incremental Update Contract

## OBJECTIVE
Introduce a provider-neutral, presentation-only contract for one latest/new projected chart data item before any concrete vendor `update()` call or live-feed wiring.

## RESEARCH
Official Lightweight Charts v5 documentation states that `setData()` replaces the entire data set and recommends `ISeriesApi.update()` for realtime latest/new items because repeated full replacements can significantly affect performance. `update()` replaces the last item when times are equal or appends when the new time is later. P17.7 models only the Kairos-side incremental presentation semantics and does not call the vendor API.

## OWNER TRACE
P17.1R2 owns ChartRenderModel semantics.
P17.2 owns renderer lifecycle.
P17.3 owns renderer primitive projection.
P17.4 owns projected renderer composition.
P17.5 owns provider-neutral engine driver seam.
P17.6 owns Lightweight Charts v5 module-shape adaptation.
P17.7 owns only the provider-neutral incremental presentation contract.

## CHANGE
- adds `ChartIncrementalUpdate` for one projected line point or candle
- adds `IncrementalChartEngineSession.updateLatest`
- adds `IncrementalChartEnginePort`
- no data acquisition or freshness decisions
- no vendor call yet
- dedicated tests and verifier

## DATA / STATE FLOW
Authoritative upstream data -> existing P17 projection -> one projected incremental item -> P17.7 contract.
There is no reverse flow and no mutation of journal, market-data, or calculation truth.

## PERFORMANCE
This is the Kairos prerequisite for using Lightweight Charts `update()` efficiently later. It prevents the renderer from treating every realtime observation as a whole-series replacement while keeping update semantics presentation-only.

## NON-SCOPE
No `lightweight-charts` import.
No vendor `update()` call.
No live Binance subscription wiring.
No candle construction from trades.
No historical data acquisition.
No execution markers.
No drawings/P18.
No persistence, business calculations, timers, navigation, or motion.

## RESULT
Local verifier/static checks below. Canonical CI decides authority.
