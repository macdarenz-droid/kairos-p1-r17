# KAIROS P15.7 — Market Data Reconnect Jitter Semantics

## BASE
P15.6R1 canonical PASS — Run #132 / SHA 7ca9c2f045e9e6738bc4d778d3d5bf30bff766f6.

## OBJECTIVE
Add one pure, provider-neutral full-jitter transformation for an already-computed reconnect backoff window without owning randomness or scheduling.

## RESEARCH
AWS Well-Architected REL05-BP03 recommends exponential backoff, jitter, and a maximum retry limit, and warns against retries at multiple layers. AWS SDK retry guidance describes full jitter as spreading retries uniformly across the full backoff window. P15.7 therefore owns only the deterministic transformation from a caller-supplied normalized sample to an integer millisecond delay.

## OWNER TRACE
P15.1 adapter/subscription contract.
P15.2 observation validation/freshness.
P15.3 subscription lifecycle.
P15.4 connection-state transitions.
P15.5 bounded exponential reconnect decisions.
P15.6 one-shot reconnect scheduling/cancellation lifecycle.
P15.7 full-jitter delay transformation only.

## PRE-CHANGE FLOW
P15.5 produced a capped deterministic base delay and P15.6 could schedule that delay, but there was no explicit jitter semantic between those owners.

## CHANGE
Added `applyMarketDataReconnectFullJitter` with normalized sample input, integer millisecond output, and explicit invalid-delay/invalid-sample results.

## NON-SCOPE
No Math.random owner, cryptographic randomness, timer scheduling, provider, endpoint, WebSocket, EventSource, fetch, polling, persistence, UI/chart wiring, execution mutation, Calculation Engine mutation, P&L mutation, API keys, or secrets.

## DATA/STATE FLOW
P15.5 base delay + externally supplied normalized sample -> P15.7 jittered delay -> future coordinator may pass delay to P15.6.

## PERSISTENCE
None.

## SECURITY
No network access or credentials.

## THEME
No UI/theme changes.

## OFFLINE
Offline journal remains unaffected.

## TESTS
Runtime tests cover lower/middle/upper window mapping, integer milliseconds, zero delay, invalid delay and invalid sample handling.

## REGRESSION
P15.1-P15.6 owners remain unchanged.

## PERFORMANCE
Constant-time arithmetic only.

## KNOWN LIMITATIONS
Entropy acquisition remains deliberately outside this pure semantic owner. Retry orchestration and provider-specific retryability remain deferred.

## REAL-DEVICE STATUS
N/A — pure service semantics.

## RESULT
HOLD pending canonical GitHub gate.
