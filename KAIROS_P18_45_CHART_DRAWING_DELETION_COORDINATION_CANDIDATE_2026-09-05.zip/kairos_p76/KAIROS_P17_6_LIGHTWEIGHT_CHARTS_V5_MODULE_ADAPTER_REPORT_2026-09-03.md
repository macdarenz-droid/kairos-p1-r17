# KAIROS P17.6 — Lightweight Charts v5 Module Adapter Boundary

## OBJECTIVE
Bind the provider-neutral P17.5 chart-engine driver seam to the documented Lightweight Charts v5 module shape without fabricating a dependency installation or lockfile change.

## RESEARCH
Official Lightweight Charts 5.2 documentation uses the unified v5 API: `chart.addSeries(LineSeries)` / `chart.addSeries(CandlestickSeries)`. `ISeriesApi.setData()` replaces the complete dataset, `ISeriesApi.update()` is intended for efficient latest/new-point realtime updates, `removeSeries()` is irreversible, and `chart.remove()` irreversibly destroys the chart. Version 5.2.1 is the current documented release.

## OWNER TRACE
P17.1R2 owns ChartRenderModel semantics.
P17.2 owns renderer lifecycle.
P17.3 owns renderer primitive projection.
P17.4 owns projected renderer composition.
P17.5 owns the provider-neutral chart engine driver seam.
P17.6 owns only the Lightweight Charts v5 API-shape adapter.

## CHANGE
- defines a minimal injected LightweightChartsV5Module shape
- maps Kairos line series to `addSeries(LineSeries)`
- maps Kairos candle series to `addSeries(CandlestickSeries)`
- delegates full-series presentation data through vendor `setData`
- maps Kairos series handles back to vendor series for `removeSeries`
- delegates final chart destruction to vendor `remove`
- explicitly rejects old v4 vendor API calls
- adds dedicated tests and verifier

## DATA / STATE FLOW
ChartRenderModel -> P17.3 projection -> P17.4 renderer -> P17.5 driver -> P17.6 injected v5 module.
No reverse flow into journal, market data, calculations, or persistence.

## PERFORMANCE
P17.6 intentionally keeps whole-series `setData` semantics because P17 does not yet own an incremental chart update contract. Official docs advise `update()` for realtime incremental points; Kairos will not introduce that until an explicit authoritative incremental presentation contract exists.

## NON-SCOPE
No npm dependency or package-lock change.
No direct import from `lightweight-charts`.
No live-feed subscription wiring.
No historical candle acquisition.
No execution markers.
No drawings/P18.
No risk/reward/P19.
No persistence, business calculations, timers, navigation, or motion changes.

## RESULT
Local verifier/static checks below. Canonical CI decides authority.
