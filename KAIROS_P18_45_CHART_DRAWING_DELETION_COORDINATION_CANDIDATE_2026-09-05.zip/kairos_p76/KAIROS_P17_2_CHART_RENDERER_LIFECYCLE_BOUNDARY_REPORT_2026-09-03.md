# KAIROS P17.2 — Chart Renderer Lifecycle Boundary

## OBJECTIVE
Add the next P17 boundary after P17.1R2 without introducing an unverified chart-library dependency.

## RESEARCH
TradingView Lightweight Charts v5 uses a client-side chart instance created with `createChart`, with series attached through the unified `addSeries` API. The library targets ES2020 and includes TypeScript declarations. Because the local package-manager dependency update could not complete reliably within the execution ceiling, this slice deliberately stops before dependency installation.

## OWNER TRACE
P17.1R2 owns the provider-neutral ChartRenderModel.
P17.2 owns only the renderer lifecycle interface expected of a future concrete client renderer.
P15/P16 remain market-data owners.
P11 remains calculation owner.
Journal/domain paths remain execution-truth owners.

## CHANGE
Adds:
- ChartRendererLifecycle with render() and destroy()
- ChartRendererFactory with explicit HTMLElement construction boundary
- identity factory definition helper
- dedicated lifecycle test
- dedicated static ownership verifier

## NON-SCOPE
No charting package dependency.
No createChart call.
No candlestick rendering.
No line rendering.
No live subscription wiring.
No historical candle acquisition.
No markers.
No drawings.
No risk/reward tool.
No persistence.
No calculations.
No navigation or motion changes.

## RESULT
Local verifier/static checks run below. Canonical CI remains authoritative.
