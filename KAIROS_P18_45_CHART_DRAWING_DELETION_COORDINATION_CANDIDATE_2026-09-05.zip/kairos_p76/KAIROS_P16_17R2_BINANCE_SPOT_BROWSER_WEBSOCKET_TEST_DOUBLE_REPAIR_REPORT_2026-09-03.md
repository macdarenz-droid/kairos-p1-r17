# KAIROS P16.17R2 — Browser WebSocket Test Double Repair

## OBJECTIVE
Repair only the remaining P16.17 runtime test-double incompatibility exposed by canonical Run #167.

## FAILURE CLASSIFICATION
Run #167 passed controlled scope, deterministic install, and production build. 514 existing tests passed. The two new P16.17 tests failed because their fake WebSocket implemented property callbacks while the already-canonical P16.12 browser connector uses the browser-standard `addEventListener` interface.

## CHANGE
Update only the P16.17 test double to implement `addEventListener` and emit message events through registered listeners. Production reconnect implementation is unchanged.

## NON-SCOPE
No production behavior, retry policy, scheduler, lifecycle, transport, journal, persistence, chart/P17, credential, or order changes.

## RESULT
HOLD pending canonical P16.17R2 gate.
