# KAIROS P11.9 Market-Specific Calculation Policy Boundary Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.8 authoritative PASS from controlled gate run #27.

## Objective
Add the protected `MarketSpecificCalculationPolicy` boundary named by the locked P0 Calculation Engine architecture before any further monetary risk, position-size, leverage, or instrument-specific P&L work.

## Controlling basis
The P0 handoff explicitly states that a straightforward spot/share P&L model must not be assumed for every futures, forex, or CFD instrument, and that market/instrument-specific policies sit below the common Calculation Engine.

No new external API/library behavior is introduced in this patch, so no time-sensitive web dependency research is required.

## Owner trace
P9 MarketType
-> P11.9 explicit calculation-policy registry contract
-> future instrument/market policy implementations
-> protected P11 calculators
-> future TradeMetrics composition.

## Change
Adds:
- `MarketCalculationCapability`
- `MarketSpecificCalculationPolicy`
- `resolveMarketSpecificCalculationPolicy(...)`

Capabilities are explicit:
- gross-pnl
- initial-risk
- position-size
- leverage

Resolution rules:
1. policy must explicitly support the requested market type;
2. policy must explicitly support the requested calculation capability;
3. no match => `policy-unavailable`;
4. more than one match => `ambiguous-policy`;
5. there is no default spot policy and no order-based fallback.

## Why this patch is required now
P11.8 reached the boundary between market-neutral arithmetic and monetary/instrument semantics. Continuing directly into monetary risk or position sizing would require assumptions about contract multipliers, lot models, tick values, quote currency, or other instrument details.

P11.9 establishes the explicit ownership seam before those formulas exist.

## Non-scope
No concrete stock, crypto, futures, forex, CFD, options, or other policy implementation.
No arithmetic.
No TradeMetrics wiring.
No monetary initial risk.
No position sizing.
No leverage formula.
No new P&L formula.
No fees or FX conversion.
No instrument schema.
No persistence, migration, UI, journal history, market API, activation, or network changes.

## Missing-data / fallback semantics
Missing market calculation policy is explicit `policy-unavailable`; it is never silently treated as a spot/share calculation.
Ambiguous ownership is explicit `ambiguous-policy`; policy array order never decides financial behavior.

## Persistence / security / theme / offline
Pure synchronous domain resolution only. No persistence, network, secrets, theme, or platform impact.

## Performance
Linear scan over the supplied small policy collection; no I/O or allocation-heavy calculation path.

## Tests
Covers:
- exact policy match;
- no cross-market fallback;
- explicit capability requirement;
- ambiguous-policy rejection;
- no policy collection mutation.

## Result
HOLD until canonical GitHub gate passes deterministic install, build, full unit regression, P1-P10.3R2 regressions, P11.1R2-P11.8 regressions, and P11.9 verification.
