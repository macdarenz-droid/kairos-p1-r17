# KAIROS P15.2 — Market Data Observation Semantics — Candidate Report

## Patch / Base
- Patch: P15.2 — Market Data Observation Validation and Freshness Semantics
- Base: canonical P15.1 — Market Data Adapter Interface Foundation
- Date: 2026-09-03

## OBJECTIVE
Add one deterministic semantics layer for validating P15 market-price observations and classifying receipt freshness before any concrete provider/live-feed implementation exists.

## RESEARCH
Official MDN guidance reviewed before implementation:
- `Date.parse()` reliably supports the ECMAScript date-time string format, while other formats are implementation-defined; P15.2 therefore accepts only explicit UTC ISO instants ending in `Z` for adapter-normalized timestamps.
- `Number.isFinite()` validates finite numeric thresholds without coercing strings/null to numbers.
- `AbortSignal` remains the existing P15.1 lifecycle cancellation primitive; P15.2 does not replace or expand that ownership.

## OWNER TRACE
P15.1 owns transport-neutral adapter and observation types. P15.2 adds a pure observation-semantics module under the same `src/services/market-data` owner. P11 calculation truth, P5 persistence, journal execution truth, and P14 presentation remain unchanged.

## PRE-CHANGE FLOW
Provider-neutral adapters could emit typed observations, but no shared P15 contract yet distinguished malformed observations, stale receipt observations, future-dated receipt observations, or fresh observations.

## CHANGE
Adds `marketDataObservationSemantics.ts` with:
- strict market observation validation,
- positive DecimalString price validation via the existing trade-domain parser,
- explicit UTC receipt/source timestamp validation,
- `fresh | stale | future | invalid` freshness states,
- caller-supplied `now` and `maxAgeMs` inputs,
- receipt-time freshness based only on application-owned `observedAt`.

## NON-SCOPE
No WebSocket, EventSource, fetch, polling, provider SDK, retry/reconnect logic, timers, persistence, UI/chart wiring, journal mutation, execution mutation, calculation mutation, P&L mutation, candles, synthetic history, or secrets.

## DATA / STATE FLOW
`MarketPriceObservation` → pure validation → pure freshness classification. `sourceTimestamp` remains provider evidence only and does not control freshness. No state is persisted or mutated.

## PERSISTENCE
None.

## SECURITY
No credentials, endpoints, provider SDKs, executable remote content, or network ownership added.

## THEME
No UI/CSS change.

## OFFLINE
Pure semantics work offline and do not introduce network requirements.

## TESTS
Adds runtime tests for valid observations, malformed/non-positive observations, receipt-time freshness, stale/future/invalid classification, and proof that provider timestamps do not drive freshness.

Adds `verify:p15:2-market-data-observation-semantics` static verifier enforcing deterministic/no-transport/no-persistence/no-UI ownership.

## REGRESSION
P15.1 interfaces/types remain unchanged. Earlier phase owners are untouched.

## PERFORMANCE
O(1) pure validation/classification per observation. No timers, observers, buffering, loops, subscriptions, or background work added.

## KNOWN LIMITATIONS
This patch intentionally does not choose the eventual freshness threshold, provider, transport, reconnect behavior, stream buffering, or chart consumption policy. Adapters must normalize accepted provider times into explicit UTC ISO instants before constructing authoritative P15 observations.

## REAL-DEVICE STATUS
Not applicable to this semantics-only slice.

## RESULT
HOLD pending canonical GitHub build, runtime, and full controlled regression gate.


## REPAIR ROUND P15.2R1
Canonical Run #125 reached the TypeScript build and exposed a test-fixture typing defect:
plain string literals were assigned directly to the branded `DecimalString` type.

Repair is limited to the P15.2 runtime test:
- valid prices are produced through the existing `parsePositiveDecimalString` domain owner;
- the intentionally invalid `0` test fixture is explicitly cast only to exercise runtime rejection;
- no production market-data semantics, adapter interface, persistence, calculation, journal, UI, transport, or provider code changed.

Result remains HOLD pending canonical GitHub gate.


## REPAIR ROUND P15.2R2
Canonical Run #126 confirmed P15.2R1 exact scope and deterministic install, then failed TypeScript build because the test imported `parsePositiveDecimalString` and `DecimalString` from the market-data barrel even though those are owned/exported by `src/domain/trades`.

Repair is test-only:
- import `parsePositiveDecimalString` from `../src/domain/trades`;
- import `DecimalString` type from `../src/domain/trades`;
- keep `MarketPriceObservation` imported from the market-data boundary;
- do not widen the market-data barrel or create a second domain owner.

No production code changed.
Result remains HOLD pending canonical GitHub gate.
