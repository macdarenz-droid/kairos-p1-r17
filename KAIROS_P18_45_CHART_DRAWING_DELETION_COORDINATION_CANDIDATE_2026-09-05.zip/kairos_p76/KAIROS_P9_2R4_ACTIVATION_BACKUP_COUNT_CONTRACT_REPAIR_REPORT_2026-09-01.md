# Kairos P9.2R4 — Activation Backup Count Contract Repair

Date: 2026-09-01
Status: **HOLD — candidate prepared; not authoritative until the complete GitHub gate passes**
Authoritative input base: `KAIROS_P9_1_TRADE_DOMAIN_FOUNDATION_CANDIDATE_2026-09-01.zip`

## Objective

Rebuild the P9.2 persistence/recovery work from the authoritative P9.1 PASS base and repair the single P9.2R3 regression without weakening P7 activation-backup isolation.

## Failure addressed

P9.2R3 built successfully and passed 143/144 unit tests. The remaining P7.2 regression expected the historical V1 snapshot count shape `{ metadata: 1, total: 1 }`, while the V2 backup contract correctly reports zero counts for the four newly owned trade collections.

## Repair

The activation-persistence regression now asserts the complete V2 count contract: one allowed metadata record, zero trades/plans/executions/fees, and total one. The existing assertion that the backup metadata contains only `journal.setting` remains unchanged, so device-scoped activation evidence must still be excluded from user backups.

No activation implementation, trade-domain implementation, navigation, design-system, or activation authority code is changed.

## Research / architecture check

Dexie continues to require schema evolution through versioned declarations; upgrader history is preserved and failed upgrade transactions roll back. IndexedDB schema changes occur through versionchange transactions. P9.2R4 therefore retains the V1 -> V2 migration/recovery architecture and changes only the stale cross-version P7 regression contract in addition to the already-scoped P9.2 persistence/recovery implementation.

## Promotion rule

P9.2R4 remains HOLD until deterministic install, production build, full unit regression, every P1-P8 regression, P9.1 verification, P9.2 persistence verification, and artifact upload all pass in GitHub Actions. Failed P9.2/R1/R2/R3 candidates remain non-authoritative.
