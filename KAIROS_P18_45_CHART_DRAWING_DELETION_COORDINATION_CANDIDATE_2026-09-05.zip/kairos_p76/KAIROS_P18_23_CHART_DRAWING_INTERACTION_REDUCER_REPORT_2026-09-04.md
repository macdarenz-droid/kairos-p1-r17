# KAIROS P18.23 — Chart Drawing Interaction Reducer

## Controlled base
Canonical P18.22 PASS, GitHub Actions run #226 / 33864135415.

## Evidence / research basis
The controlling Kairos drawing architecture requires one explicit drawing interaction state machine/reducer rather than multiple contradictory booleans. Canonical P18.21 owns only the provider-neutral state vocabulary. Canonical P18.22 owns only the provider-neutral event/action vocabulary and explicitly defers transition acceptance/rejection to a later reducer owner. Therefore the next missing responsibility is the pure transition function that consumes those two already-authoritative contracts.

Current official React guidance states that reducers consolidate state-update logic into one function, take current state plus an action and return the next state, should remain pure, and should use actions that describe individual interactions. P18.23 follows that model without adding React-hook ownership: https://react.dev/learn/extracting-state-logic-into-a-reducer

Project-specific transition semantics are intentionally conservative. There are no implicit chained transitions: unsupported state/event combinations return the existing state unchanged, and terminal `committed` / `cancelled` states require explicit `reset-interaction` before another interaction starts. This prevents later UI/pointer wiring from silently inventing state transitions.

## Responsibility added
Adds the sole provider-neutral drawing-interaction transition owner:
- `idle + select-tool -> tool-selected`
- `tool-selected + start-drawing -> drawing`
- `drawing + preview-drawing -> preview`
- `preview + commit-drawing -> committed`
- active interaction + `cancel-interaction -> cancelled`
- `idle + start-editing -> editing`
- `idle + start-deleting -> deleting`
- any state + `reset-interaction -> idle`
- every unsupported state/event combination -> unchanged state

The reducer is deterministic and side-effect free. It changes only interaction state and never drawing/journal/provider truth.

## Ownership preserved
- P18.1 remains drawing truth owner.
- P18.11/P18.20 remain presentation lifecycle/hover coordination owners.
- P18.14-P18.19 retain provider hover/resolution/subscription/lifecycle ownership.
- P18.21 remains interaction-state shape owner.
- P18.22 remains interaction-event shape owner.
- P18.23 owns only interaction transition semantics.

## Explicit non-scope
No pointer/click subscription, pointer capture, gesture recognition, screen-to-market coordinate conversion, anchor collection, drag/edit execution, drawing creation/update/delete mutation, persistence, toolbar UI, selection rendering, undo/redo, new drawing kinds, horizontal line, rectangle/order block, freehand, Risk/Reward behavior or visuals, journal truth, market truth, calculations, navigation, dependency migration, or P19 work.

## Changed-file contract
Exactly six files relative to canonical P18.22:
1. `KAIROS_P18_23_CHART_DRAWING_INTERACTION_REDUCER_REPORT_2026-09-04.md`
2. `package.json`
3. `scripts/verify-p18-23-chart-drawing-interaction-reducer.mjs`
4. `src/features/chart/chartDrawingInteractionReducer.ts`
5. `src/features/chart/index.ts`
6. `tests/chart-drawing-interaction-reducer.test.ts`

## Verification intent
Dedicated verification must prove the transition sequence, invalid-event no-op semantics, explicit reset behavior, state/event contract preservation, export ownership, and absence of provider/persistence/P19 boundaries. Canonical gate must additionally prove deterministic install, production TypeScript/build, dedicated runtime tests, full unit regression, P18/P17 regression chain, historical closures, exact scope, candidate artifact, and gate evidence before promotion.
