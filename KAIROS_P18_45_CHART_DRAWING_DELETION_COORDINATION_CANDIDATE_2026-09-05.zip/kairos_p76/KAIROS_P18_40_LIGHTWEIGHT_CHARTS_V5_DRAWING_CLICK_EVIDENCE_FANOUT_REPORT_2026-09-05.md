# KAIROS P18.40 — Lightweight Charts v5 Drawing Click Evidence Fan-Out

## Purpose
Preserve the exact provider click event through the existing P18.26/P18.27 single-subscription chain so later P18 selection composition can consume P18.39 drawing-selection evidence without creating a second `subscribeClick` owner.

## Authority / ownership
- P18.26 remains the sole `subscribeClick` / exact `unsubscribeClick` lifecycle owner.
- P18.25R1 remains the sole provider click time/Y -> neutral drawing-anchor projection owner.
- P18.27 remains the provider chart/series resolution + click-binding composition owner.
- P18.39 remains the sole provider hover identity -> current-snapshot-filtered drawing-selection projection owner.
- P18.23/P18.24 remain the sole interaction transition/current-state owners.

## Change
- The P18.26 handler now exposes the same exact provider click event to one optional observer before delivering the existing projected anchor/null evidence.
- P18.27 forwards that optional observer through the existing binding seam.
- The chart feature index exports the new click-evidence/listener types; no new runtime owner is introduced.
- Existing callers remain source-compatible because the observer is optional.
- One provider click still creates exactly one P18.26 subscription lifecycle.

## Why this slice is required
P18.39 proves drawing identity from `hoveredInfo`, but P18.26 previously discarded the raw provider event after anchor projection. A second selection-specific `subscribeClick` lifecycle would duplicate ownership. P18.40 creates the minimal evidence fan-out prerequisite instead.

## Explicit non-scope
- no selection projection invocation or `select-drawing` dispatch;
- no second click subscription;
- no new interaction state owner;
- no drawing mutation/edit/drag/delete execution;
- no persistence/restore;
- no toolbar/UI state;
- no new drawing kinds;
- no journal truth or calculation changes;
- no Risk/Reward semantics and no P19.
