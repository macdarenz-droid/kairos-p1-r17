import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/chartTrendLineDraftInteractionCoordination.ts', 'utf8');
const interactionPort = readFileSync('src/features/chart/chartDrawingInteractionPort.ts', 'utf8');
const draftPort = readFileSync('src/features/chart/chartTrendLineDraftAnchorCollection.ts', 'utf8');
const test = readFileSync('tests/chart-trend-line-draft-interaction-coordination.test.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.29 chart trend-line draft interaction coordination verification FAIL: ${message}`);
  process.exit(1);
};

for (const required of [
  'createChartDrawingInteractionPort().create(onStateChange)',
  'createChartTrendLineDraftAnchorCollectionPort().create()',
  'draft.appendAnchor(anchor)',
  "interaction.dispatch({ type: 'start-drawing' })",
  "interaction.dispatch({ type: 'preview-drawing' })",
  "event.type === 'cancel-interaction'",
  "event.type === 'reset-interaction'",
  'draft.clear()',
  "throw new Error('chart-trend-line-draft-interaction-destroyed')",
]) {
  if (!source.includes(required)) fail(`missing coordination evidence: ${required}`);
}

if (!interactionPort.includes('reduceChartDrawingInteraction(currentState, event)')) {
  fail('P18.24 interaction-session delegation to P18.23 regressed');
}
for (const required of [
  'appendAnchor(anchor: ChartDrawingAnchor): ChartTrendLineDraftAnchors',
  'clear(): ChartTrendLineDraftAnchors',
]) {
  if (!draftPort.includes(required)) fail(`P18.28R1 draft-anchor owner regressed: ${required}`);
}
if (!index.includes('createChartTrendLineDraftInteractionPort')) {
  fail('chart feature export for trend-line draft interaction coordination is missing');
}
if (
  packageJson.scripts?.['verify:p18:29-chart-trend-line-draft-interaction-coordination'] !==
  'node scripts/verify-p18-29-chart-trend-line-draft-interaction-coordination.mjs'
) {
  fail('P18.29 package verifier script missing');
}

for (const token of [
  'routes the first valid anchor through P18.28 draft storage and P18.24 start-drawing dispatch',
  'routes the second valid anchor to preview without constructing committed drawing truth',
  'fails closed on null anchors and anchors outside the eligible trend-line interaction states',
  'clears only ephemeral draft anchors after successful cancel and reset lifecycle transitions',
  'destroy is idempotent and later coordinated access fails closed',
]) {
  if (!test.includes(token)) fail(`runtime test does not pin behavior: ${token}`);
}

for (const forbidden of [
  'reduceChartDrawingInteraction(',
  'subscribeClick(',
  'unsubscribeClick(',
  'coordinateToPrice(',
  'defineChartDrawing(',
  'crypto.randomUUID',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.delete(',
  'riskReward',
]) {
  if (source.includes(forbidden)) fail(`coordination crossed protected boundary: ${forbidden}`);
}

console.log('P18.29 chart trend-line draft interaction coordination verification passed.');
