import { readFileSync } from 'node:fs';
const source=readFileSync('src/application/visual-pnl/dailySummary.ts','utf8');
const index=readFileSync('src/application/visual-pnl/index.ts','utf8');
const tests=readFileSync('tests/visual-pnl-daily-summary.test.ts','utf8');
const req=(h,n,l)=>{if(!h.includes(n)) throw new Error(`P13.7 missing ${l}: ${n}`)};
req(source,'projectVisualPnlDayKey(entry.trade.closedAt, timeZone)','P13.6 day owner reuse');
req(source,'summarizeVisualPnlAggregation','P13.5 aggregate owner reuse');
req(source,"entry.trade.status !== 'closed'",'realized-only guard');
req(source,'blockedTrades','explicit blocked evidence');
req(source,'new Map<string, DayAccumulator>()','bounded in-memory bucketing');
req(index,"export * from './dailySummary';",'public export');
req(tests,"reason: 'mixed-currencies'",'mixed-currency regression');
req(tests,"reason: 'non-closed-trade'",'non-closed evidence regression');
for(const forbidden of ['decimalSum','decimalAdd','parseFloat','parseInt','exchangeRate','toLocaleDateString','new Intl.DateTimeFormat']){
  if(source.includes(forbidden)) throw new Error(`P13.7 rejected duplicate owner/hidden behavior: ${forbidden}`);
}
console.log('PASS P13.7 Visual P&L daily summary composition verifier');
