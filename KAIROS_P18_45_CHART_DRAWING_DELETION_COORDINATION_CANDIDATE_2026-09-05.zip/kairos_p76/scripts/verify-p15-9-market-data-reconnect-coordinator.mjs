import fs from 'node:fs';

const fail = (message) => {
  console.error(`FAIL P15.9 Market Data reconnect coordinator verifier: ${message}`);
  process.exit(1);
};

const ownerPath = 'src/services/market-data/marketDataReconnectCoordinator.ts';
const barrelPath = 'src/services/market-data/index.ts';
const packagePath = 'package.json';

if (!fs.existsSync(ownerPath)) fail('coordinator owner missing');

const source = fs.readFileSync(ownerPath, 'utf8');
const barrel = fs.readFileSync(barrelPath, 'utf8');
const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));

for (const token of [
  'planNextMarketDataReconnect',
  'scheduleMarketDataReconnect',
  "kind: 'scheduled'",
  "kind: 'stop'",
  "kind: 'invalid'",
  'plan.delayMs',
  'MarketDataReconnectScheduler',
]) {
  if (!source.includes(token)) fail(`missing ${token}`);
}

for (const forbidden of [
  'Math.random(',
  'setTimeout(',
  'setInterval(',
  'Date.now(',
  'new WebSocket(',
  'new EventSource(',
  'fetch(',
  'indexedDB',
  'Dexie',
]) {
  if (source.includes(forbidden)) fail(`forbidden ownership token ${forbidden}`);
}

if (!barrel.includes("export * from './marketDataReconnectCoordinator';")) {
  fail('barrel export missing');
}

if (pkg.scripts?.['verify:p15:9-market-data-reconnect-coordinator']
    !== 'node scripts/verify-p15-9-market-data-reconnect-coordinator.mjs') {
  fail('package verifier script missing');
}

console.log('PASS P15.9 Market Data reconnect coordinator verifier');
