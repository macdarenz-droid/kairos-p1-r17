import { readFileSync } from 'node:fs';

const composition = readFileSync(
  'src/features/chart/lightweightChartsV5TrendLineDraftInteractionComposition.ts',
  'utf8',
);
const clickSubscription = readFileSync(
  'src/features/chart/lightweightChartsV5DrawingClickSubscription.ts',
  'utf8',
);
const selectionCoordination = readFileSync(
  'src/features/chart/lightweightChartsV5DrawingSelectionInteractionCoordination.ts',
  'utf8',
);
const reducer = readFileSync('src/features/chart/chartDrawingInteractionReducer.ts', 'utf8');
const test = readFileSync(
  'tests/lightweight-charts-v5-drawing-selection-click-lifecycle-composition.test.ts',
  'utf8',
);
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.42 drawing selection click lifecycle composition verification FAIL: ${message}`);
  process.exit(1);
};

for (const token of [
  'getCurrentRendererDrawings?: () => readonly RendererChartDrawing[]',
  'if (getCurrentRendererDrawings === undefined)',
  'coordinateLightweightChartsV5DrawingSelectionInteraction(',
  'draftInteraction,',
  'getCurrentRendererDrawings(),',
  'event,',
]) {
  if (!composition.includes(token)) fail(`missing lifecycle composition invariant: ${token}`);
}

const bindingCalls = composition.match(/createLightweightChartsV5DrawingClickSubscriptionFromBinding\(/g) || [];
if (bindingCalls.length !== 2) {
  fail('P18.42 must preserve one legacy branch and one selection-enabled branch through the same binding owner');
}
if (!clickSubscription.includes('onProviderClick?.(event);\n    onAnchor(')) {
  fail('P18.40 raw-click-before-anchor delivery ordering regressed');
}
if ((clickSubscription.match(/chart\.subscribeClick\(handleClick\)/g) || []).length !== 1) {
  fail('P18.26 must remain the sole single subscribeClick owner');
}
if (!selectionCoordination.includes('projectLightweightChartsV5DrawingSelection(drawings, event)')) {
  fail('P18.41 selection coordination owner regressed');
}
if (!selectionCoordination.includes('return interaction.dispatch(')) {
  fail('P18.41 authoritative dispatch delegation regressed');
}
if (!reducer.includes("case 'select-drawing':")) {
  fail('P18.23 selection transition owner regressed');
}

for (const token of [
  'existing single click subscription before anchor delivery',
  'current renderer drawing snapshot at provider-click time',
  'keeps P18.23 tool-selected precedence',
  'same P18.24 session and detaches the one click lifecycle once',
]) {
  if (!test.includes(token)) fail(`runtime regression evidence missing: ${token}`);
}

for (const forbidden of [
  'chart.subscribeClick(',
  'chart.unsubscribeClick(',
  'reduceChartDrawingInteraction(',
  'createChartDrawingInteractionPort(',
  'projectLightweightChartsV5DrawingSelection(',
  'new Map(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.add(',
  '.delete(',
  'riskReward',
  'risk-reward',
]) {
  if (composition.includes(forbidden)) fail(`P18.42 crossed protected boundary: ${forbidden}`);
}

if (
  pkg.scripts?.['verify:p18:42-lightweight-charts-v5-drawing-selection-click-lifecycle-composition'] !==
  'node scripts/verify-p18-42-lightweight-charts-v5-drawing-selection-click-lifecycle-composition.mjs'
) {
  fail('P18.42 package verifier script missing');
}

console.log('P18.42 Lightweight Charts v5 drawing selection click lifecycle composition verification passed.');
