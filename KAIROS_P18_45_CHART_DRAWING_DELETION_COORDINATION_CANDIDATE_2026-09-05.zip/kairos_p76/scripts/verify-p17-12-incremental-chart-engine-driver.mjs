import { readFileSync } from 'node:fs';

const driver = readFileSync('src/features/chart/chartEngineDriver.ts', 'utf8');
const adapter = readFileSync('src/features/chart/lightweightChartsV5ModuleAdapter.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync('tests/chart-engine-driver-incremental.test.ts', 'utf8');

for (const token of [
  'createIncrementalChartEnginePortFromDriver',
  'updateLatest(update: ChartIncrementalUpdate)',
  'active.handle.updatePriceLine(update.point)',
  'active.handle.updateCandle(update.candle)',
]) {
  if (!driver.includes(token)) throw new Error(`missing-driver-contract:${token}`);
}
if (!adapter.includes('series.update(point)') || !adapter.includes('series.update(candle)')) {
  throw new Error('missing-lightweight-charts-update-mapping');
}
if (!index.includes('createIncrementalChartEnginePortFromDriver')) {
  throw new Error('missing-public-export');
}
if (!test.includes("expect(removeSeries).not.toHaveBeenCalled()")) {
  throw new Error('missing-series-identity-regression');
}
for (const forbidden of ['WebSocket', 'indexedDB', 'localStorage', 'fetch(']) {
  if (driver.includes(forbidden)) throw new Error(`forbidden-owner:${forbidden}`);
}
console.log('P17.12 incremental chart engine driver verifier: PASS');
