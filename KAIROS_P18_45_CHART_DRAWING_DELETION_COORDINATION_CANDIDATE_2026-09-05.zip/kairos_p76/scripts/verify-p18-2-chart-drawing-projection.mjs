import { readFileSync } from 'node:fs';

const projection = readFileSync(new URL('../src/features/chart/chartDrawingProjection.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/features/chart/index.ts', import.meta.url), 'utf8');

const required = [
  "import type { ChartDrawing, ChartDrawingAnchor } from './chartDrawingContract'",
  "import { projectChartPricePoint, type RendererPricePoint } from './chartSeriesProjection'",
  'export type RendererDrawingAnchor = RendererPricePoint',
  'export interface RendererTrendLineDrawing',
  "readonly kind: 'trend-line'",
  'export type RendererChartDrawing = RendererTrendLineDrawing',
  'export function projectChartDrawingAnchor',
  'return projectChartPricePoint(anchor)',
  'export function projectChartDrawing',
];
for (const token of required) {
  if (!projection.includes(token)) throw new Error(`P18.2 drawing projection missing: ${token}`);
}
for (const forbidden of ['lightweight-charts', 'IndexedDB', 'Dexie', 'fetch(', 'WebSocket', 'attachPrimitive', 'CanvasRenderingContext2D']) {
  if (projection.includes(forbidden)) throw new Error(`P18.2 drawing projection owns forbidden concern: ${forbidden}`);
}
if (!index.includes("from './chartDrawingProjection'")) throw new Error('P18.2 chart index does not export drawing projection');
console.log('P18.2 chart drawing projection boundary verification passed.');
