import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/features/chart/lightweightChartsV5TrendLineCoordinateProjection.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/features/chart/index.ts', import.meta.url), 'utf8');
const required = [
  'LightweightChartsV5TimeCoordinateApi',
  'timeToCoordinate',
  'LightweightChartsV5PriceCoordinateApi',
  'priceToCoordinate',
  'LightweightChartsV5TrendLineScreenSegment',
  'projectLightweightChartsV5TrendLineSegments',
  'startX === null',
  'startY === null',
  'endX === null',
  'endY === null',
];
for (const token of required) if (!source.includes(token)) throw new Error(`P18.5 missing ${token}`);
for (const forbidden of ['CanvasRenderingContext2D', 'attachPrimitive(', 'detachPrimitive(', 'IndexedDB', 'Dexie', 'fetch(', 'WebSocket', 'localStorage', 'risk-reward']) {
  if (source.includes(forbidden)) throw new Error(`P18.5 forbidden ownership ${forbidden}`);
}
if (!index.includes("from './lightweightChartsV5TrendLineCoordinateProjection'")) throw new Error('P18.5 index export missing');
console.log('P18.5 Lightweight Charts v5 trend-line coordinate projection verification passed.');
