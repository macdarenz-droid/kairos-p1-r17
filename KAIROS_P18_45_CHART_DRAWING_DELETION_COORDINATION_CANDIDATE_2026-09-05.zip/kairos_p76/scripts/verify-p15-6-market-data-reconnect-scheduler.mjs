import { readFileSync } from 'node:fs';

const owner = readFileSync('src/services/market-data/marketDataReconnectScheduler.ts', 'utf8');
const index = readFileSync('src/services/market-data/index.ts', 'utf8');

const checks = [
  ['scheduler owner exists', owner.includes('scheduleMarketDataReconnect')],
  ['scheduler dependency injected', owner.includes('MarketDataReconnectScheduler')],
  ['schedule operation explicit', owner.includes('scheduler.schedule(')],
  ['cancel operation explicit', owner.includes('scheduler.cancel(handle)')],
  ['AbortSignal supported', owner.includes('AbortSignal')],
  ['already-aborted handling', owner.includes('signal?.aborted')],
  ['abort listener added', owner.includes("addEventListener('abort'")],
  ['abort listener removed', owner.includes("removeEventListener('abort'")],
  ['idempotent settlement guard', owner.includes('if (settled) return')],
  ['barrel exports scheduler', index.includes("export * from './marketDataReconnectScheduler';")],
];

for (const token of [
  'setTimeout(',
  'setInterval(',
  'Math.random(',
  'Date.now(',
  'new WebSocket(',
  'new EventSource(',
  'fetch(',
  'indexedDB',
  'Dexie',
  'JournalTradeMap',
  'projectJournalTradeVisualizer',
]) {
  checks.push([`forbidden token absent: ${token}`, !owner.includes(token)]);
}

const failed = checks.filter(([, ok]) => !ok);
if (failed.length) {
  for (const [name] of failed) console.error(`FAIL ${name}`);
  process.exit(1);
}
console.log('PASS P15.6 Market Data reconnect scheduler verifier');
