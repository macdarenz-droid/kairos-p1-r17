import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/chartDrawingHoverPort.ts', 'utf8');
const projection = readFileSync('src/features/chart/lightweightChartsV5DrawingHoverProjection.ts', 'utf8');
const test = readFileSync('tests/chart-drawing-hover-port.test.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');

for (const token of [
  'export interface ChartDrawingHoverObservation',
  'export interface ChartDrawingHoverDriverHandle',
  'export interface ChartDrawingHoverDriver',
  'export interface ChartDrawingHoverSession',
  'export interface ChartDrawingHoverPort',
  'createChartDrawingHoverPortFromDriver',
  'handle.detach()',
  'if (destroyed) return;',
]) {
  if (!source.includes(token)) throw new Error(`P18.18 hover port missing: ${token}`);
}
if (!projection.includes('extends ChartDrawingHoverObservation')) {
  throw new Error('P18.18 requires P18.14 hover projection to remain structurally compatible with the neutral observation');
}
if (!projection.includes("readonly kind: 'drawing-hover'")) {
  throw new Error('P18.18 must preserve the canonical P18.14 projection contract');
}
for (const token of ['ChartDrawingHoverObservation', 'ChartDrawingHoverPort', 'createChartDrawingHoverPortFromDriver']) {
  if (!index.includes(token)) throw new Error(`P18.18 export missing: ${token}`);
}
for (const token of ['hover-listener-not-attached', 'session.destroy();', 'toHaveBeenCalledTimes(1)']) {
  if (!test.includes(token)) throw new Error(`P18.18 regression evidence missing: ${token}`);
}
for (const forbidden of ['subscribeCrosshairMove(', 'unsubscribeCrosshairMove(', 'resolveChart(', 'chart.subscribeClick(', 'selectedDrawingId', 'dragStart', 'localStorage.', 'indexedDB.']) {
  if (source.includes(forbidden)) throw new Error(`P18.18 neutral scope violation: ${forbidden}`);
}
console.log('P18.18 chart drawing hover lifecycle port verification passed.');
