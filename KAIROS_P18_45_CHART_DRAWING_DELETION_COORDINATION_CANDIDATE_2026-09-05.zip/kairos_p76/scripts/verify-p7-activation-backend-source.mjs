import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (relative) => readFile(path.join(root, relative), 'utf8');

const worker = await read('backend/activation-worker/worker.js');
const migration = await read('backend/activation-worker/migrations/0001_activation_codes.sql');
const config = await read('backend/activation-worker/wrangler.example.jsonc');
const docs = await read('backend/activation-worker/README.md');

const assertions = [
  ['worker owns only /activate', worker.includes('url.pathname !== "/activate"')],
  ['worker requires POST', worker.includes('request.method !== "POST"')],
  ['worker uses no-store responses', worker.includes('"cache-control": "no-store"')],
  ['worker canonicalizes invite codes', worker.includes('body.inviteCode.trim().toUpperCase()')],
  ['worker hashes invite codes before D1', worker.includes('const codeHash = await sha256Hex(canonicalCode)')],
  ['worker signs before consuming invite', worker.indexOf('createSignedReceipt') < worker.indexOf("UPDATE activation_codes")],
  ['conditional one-time update preserved', worker.includes("AND status = 'unused'")],
  ['expiry guard preserved', worker.includes('(expires_at IS NULL OR expires_at > ?)')],
  ['rate limiter binding is invoked', worker.includes('env.ACTIVATION_RATE_LIMITER.limit')],
  ['rate limiter no longer uses global constant key', !worker.includes('key: "activation"')],
  ['rate limiter key is one-way hashed', worker.includes('activationRateLimitKey') && worker.includes('sha256Hex(actor)')],
  ['429 maps to rate-limited', worker.includes('reason: "rate-limited"') && worker.includes('429')],
  ['private key remains deployment secret', worker.includes('env.KAIROS_ACTIVATION_PRIVATE_KEY')],
  ['migration creates activation_codes', migration.includes('CREATE TABLE activation_codes')],
  ['migration enforces unique code hash', migration.includes('code_hash TEXT NOT NULL UNIQUE')],
  ['migration constrains lifecycle states', migration.includes("status IN ('unused', 'used', 'revoked')")],
  ['migration enforces used metadata coupling', migration.includes("status = 'used' AND used_at IS NOT NULL AND activation_id IS NOT NULL")],
  ['migration creates status index', migration.includes('CREATE INDEX idx_activation_codes_status')],
  ['config preserves D1 binding', config.includes('"binding": "DB"')],
  ['config preserves D1 database name', config.includes('"database_name": "kairos-activation-db"')],
  ['config preserves rate limiter binding', config.includes('"name": "ACTIVATION_RATE_LIMITER"')],
  ['config preserves limiter namespace', config.includes('"namespace_id": "7001"')],
  ['config preserves limiter 10/60', config.includes('"limit": 10') && config.includes('"period": 60')],
  ['config does not embed D1 UUID', config.includes('REPLACE_WITH_CLOUDFLARE_D1_DATABASE_ID')],
  ['docs prohibit private-key commit', docs.includes('private signing key') && docs.includes('must never be committed')],
  ['docs preserve exact-origin CORS contract', docs.includes('https://kairos-p1-r17.pages.dev') && docs.includes('Do not replace the exact origin with `*`')],
  ['docs warn against blind migration replay', docs.includes('do not blindly re-apply migration 0001')],
];

const failures = assertions.filter(([, pass]) => !pass);
if (failures.length > 0) {
  for (const [name] of failures) console.error(`FAIL: ${name}`);
  process.exit(1);
}

for (const [name] of assertions) console.log(`PASS: ${name}`);
