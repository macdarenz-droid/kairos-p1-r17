import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';

const root = new URL('../', import.meta.url);
const required = [
  'src/services/activation/activationTypes.ts',
  'src/services/activation/ActivationAdapter.ts',
  'src/services/activation/activationState.ts',
  'src/services/activation/index.ts',
  'tests/activation-contract.test.ts',
];
for (const file of required) await readFile(new URL(`../${file}`, import.meta.url), 'utf8');

const activationDir = new URL('../src/services/activation/', import.meta.url);
const source = (await Promise.all(
  (await readdir(activationDir)).filter((name) => /\.ts$/.test(name)).map((name) => readFile(join(activationDir.pathname, name), 'utf8')),
)).join('\n');

if (!/interface ActivationAdapter/.test(source) || !/validateInvite/.test(source)) {
  throw new Error('P7.1 must own invite validation behind ActivationAdapter.');
}
if (!/activation-required/.test(source) || !/active-offline/.test(source) || !/network-unavailable/.test(source)) {
  throw new Error('P7.1 must model activation-required, offline-active, and network-unavailable states explicitly.');
}
if (/master\s*code|invite\s*codes?\s*=\s*\[|signing\s*secret|private\s*key/i.test(source)) {
  throw new Error('P7.1 client activation subsystem must not embed invite authority or signing secrets.');
}
if (/fetch\s*\(/.test(source)) {
  throw new Error('P7.1 is contract-only; concrete HTTP activation belongs to a later controlled patch.');
}
if (/localStorage|sessionStorage|indexeddb|dexie/i.test(source)) {
  throw new Error('P7.1 must not add activation persistence before its storage/verification contract is designed.');
}

console.log('P7.1 activation contract: PASS');
