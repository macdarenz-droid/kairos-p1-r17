import { readFileSync } from 'node:fs';
import { isApprovedBrowserMarketTransportOwner } from './p1-source-scope-policy.mjs';

const approved = 'src/services/market-data/providers/binance/binanceSpotBrowserStreamConnector.ts';
const nearMisses = [
  'src/services/market-data/providers/binance/binanceSpotBrowserStreamConnector.test.ts',
  'src/services/market-data/providers/binance/anotherBrowserStreamConnector.ts',
  'src/services/market-data/binanceSpotBrowserStreamConnector.ts',
  'src/application/binanceSpotBrowserStreamConnector.ts',
];

if (!isApprovedBrowserMarketTransportOwner(approved)) {
  throw new Error('P16.11 approved concrete Binance browser transport owner is not permitted.');
}
for (const path of nearMisses) {
  if (isApprovedBrowserMarketTransportOwner(path)) {
    throw new Error(`P16.11 browser transport allowance is too broad: ${path}`);
  }
}

const p1Verifier = readFileSync('scripts/verify-p1-static.mjs', 'utf8');
for (const token of [
  "isApprovedBrowserMarketTransportOwner",
  "const forbiddenBrowserTransportTerm = /\\bwebsocket\\b/i;",
  'P1 browser transport scope leak detected',
]) {
  if (!p1Verifier.includes(token)) throw new Error(`P16.11 missing P1 compatibility token: ${token}`);
}
if (/approvedBrowserMarketTransportPrefix|startsWith\([^\n]*market-data\/providers\/binance/i.test(p1Verifier)) {
  throw new Error('P16.11 must not approve a directory-wide browser transport exception.');
}

const policy = readFileSync('scripts/p1-source-scope-policy.mjs', 'utf8');
if (!policy.includes(`'${approved}'`)) throw new Error('P16.11 exact browser transport owner path missing.');
if ((policy.match(/binanceSpotBrowserStreamConnector\.ts/g) ?? []).length !== 1) {
  throw new Error('P16.11 browser transport owner must have exactly one policy entry.');
}

console.log('PASS P16.11 P1 browser market transport compatibility verifier');
