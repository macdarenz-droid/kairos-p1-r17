import fs from 'node:fs';

const fail = (message) => {
  console.error(`FAIL P16.5 Binance Spot public stream message decode verifier: ${message}`);
  process.exit(1);
};

const owner = 'src/services/market-data/providers/binance/binanceSpotPublicStreamMessageDecode.ts';
const barrel = 'src/services/market-data/index.ts';
const test = 'tests/binance-spot-public-stream-message-decode.test.ts';

for (const path of [owner, barrel, test]) {
  if (!fs.existsSync(path)) fail(`missing ${path}`);
}

const source = fs.readFileSync(owner, 'utf8');
const index = fs.readFileSync(barrel, 'utf8');

for (const token of [
  'decodeBinanceSpotPublicStreamMessage',
  "typeof data !== 'string'",
  'JSON.parse(data)',
  "'unsupported-message-data'",
  "'invalid-json'",
]) {
  if (!source.includes(token)) fail(`missing decode-contract token ${token}`);
}

for (const forbidden of [
  'new WebSocket(',
  'fetch(',
  'apiKey',
  'secret',
  'setTimeout(',
  'setInterval(',
  'Math.random(',
  'Date.now(',
  'indexedDB',
  'Dexie',
]) {
  if (source.includes(forbidden)) fail(`forbidden ownership token ${forbidden}`);
}

if (!index.includes("export * from './providers/binance/binanceSpotPublicStreamMessageDecode';")) {
  fail('decode owner is not exported from market-data barrel');
}

console.log('PASS P16.5 Binance Spot public stream message decode verifier');
