import { existsSync, readFileSync } from 'node:fs';

for (const file of [
  'src/features/chart/chartIncrementalUpdate.ts',
  'src/features/chart/chartEngineIncrementalPort.ts',
  'tests/chart-incremental-update.test.ts',
]) {
  if (!existsSync(file)) throw new Error(`Missing P17.7 file: ${file}`);
}

const updateSource = readFileSync(
  'src/features/chart/chartIncrementalUpdate.ts',
  'utf8',
);
const portSource = readFileSync(
  'src/features/chart/chartEngineIncrementalPort.ts',
  'utf8',
);
const source = `${updateSource}\n${portSource}`;

for (const token of [
  "kind: 'price-line'",
  'RendererPricePoint',
  "kind: 'candles'",
  'RendererCandle',
  'ChartIncrementalUpdate',
  'updateLatest(update: ChartIncrementalUpdate): void',
  'IncrementalChartEnginePort',
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P17.7 token: ${token}`);
  }
}

for (const forbidden of [
  "from 'lightweight-charts'",
  'setData(',
  'update(',
  'indexedDB',
  'localStorage',
  'Dexie',
  'WebSocket',
  'setTimeout(',
  'setInterval(',
  'Math.random',
  'subscribeBinance',
  'executeMarketDataReconnect',
  'createTrade',
  'updateTrade',
  'deleteTrade',
  'decimal.js',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P17.7 ownership violation: ${forbidden}`);
  }
}

console.log('P17.7 chart incremental update contract verifier PASS');
