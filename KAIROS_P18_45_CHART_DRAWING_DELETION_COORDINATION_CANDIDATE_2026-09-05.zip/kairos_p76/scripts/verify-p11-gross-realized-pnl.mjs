import fs from 'node:fs';

const files = [
  'src/domain/calculations/grossRealizedPnl.ts',
  'tests/gross-realized-pnl.test.ts',
];
for (const file of files) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const source = fs.readFileSync('src/domain/calculations/grossRealizedPnl.ts', 'utf8');

for (const token of [
  'assessExecutionBalance',
  "balance.state !== 'flat'",
  "side === 'long'",
  'decimalSubtract',
  'grossRealizedPnl',
]) {
  if (!source.includes(token)) throw new Error(`Missing P11.4 P&L contract: ${token}`);
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error('P11.4 gross realized P&L must not use native numeric arithmetic/coercion.');
}

for (const forbidden of [
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
  'TradeFeeRecord',
  'currency',
  'fx',
  'leverage',
  'rMultiple',
  'unrealized',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.4 out-of-scope owner/metric detected: ${forbidden}`);
  }
}

console.log('P11.4 flat-trade gross realized P&L verification PASS');
