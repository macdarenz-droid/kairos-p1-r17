import fs from 'node:fs';

const files = [
  'src/domain/calculations/leverageCalculator.ts',
  'tests/leverage-calculator.test.ts',
];

for (const file of files) {
  if (!fs.existsSync(file)) {
    throw new Error(`Missing ${file}`);
  }
}

const source = fs.readFileSync(
  'src/domain/calculations/leverageCalculator.ts',
  'utf8',
);

for (const token of [
  'calculateLeverageRatio',
  'decimalDivide',
  "'zero-equity'",
  "'invalid-decimal'",
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P11.11 leverage contract: ${token}`);
  }
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error(
    'P11.11 LeverageCalculator must not use native numeric arithmetic/coercion.',
  );
}

for (const forbidden of [
  'grossPnl',
  'netPnl',
  'realizedR',
  'TradeRecord',
  'TradePlanRecord',
  'TradeExecutionRecord',
  'TradeFeeRecord',
  'marketType',
  'plannedEntryPrice',
  'plannedStopPrice',
  'plannedQuantity',
  'initialRisk',
  'margin',
  'multiplier',
  'tickValue',
  'lotSize',
  'exchangeRate',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.11 out-of-scope policy/owner detected: ${forbidden}`);
  }
}

console.log('P11.11 leverage calculator primitive verification PASS');
