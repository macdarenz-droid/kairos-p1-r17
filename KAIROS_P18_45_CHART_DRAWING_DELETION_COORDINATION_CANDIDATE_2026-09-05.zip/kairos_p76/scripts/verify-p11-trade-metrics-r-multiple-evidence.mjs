import fs from 'node:fs';
const metrics = fs.readFileSync('src/domain/calculations/tradeMetrics.ts', 'utf8');
const tests = fs.readFileSync('tests/trade-metrics-r-multiple-evidence.test.ts', 'utf8');
for (const token of [
  'TradeMetricsRMultipleInput',
  'readonly resultAmount: DecimalString;',
  'readonly initialRiskAmount: DecimalString;',
  'calculateRMultiple(',
  'rMultipleInput?',
  'hasRealizedR: realizedR !== null',
]) if (!metrics.includes(token)) throw new Error(`P11.23 missing TradeMetrics R contract token: ${token}`);
for (const token of ['keeps realized R unavailable', 'exact realized R', 'zero initial risk', 'malformed R-multiple evidence', 'existing risk-performance owner'])
  if (!tests.includes(token)) throw new Error(`P11.23 missing test evidence: ${token}`);
if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(metrics)) throw new Error('P11.23 must not introduce native numeric authority.');
for (const forbidden of ['exchangeRate','currencyConversion','Dexie','indexedDB','fetch(','WebSocket']) if (metrics.includes(forbidden)) throw new Error(`P11.23 out-of-scope owner detected: ${forbidden}`);
console.log('P11.23 TradeMetrics R-multiple evidence static verification PASS');
