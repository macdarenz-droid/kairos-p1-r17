import { readFileSync } from 'node:fs';

const production = readFileSync('src/app/SettingsRoute.tsx', 'utf8');
const tests = readFileSync('tests/settings-visual-pnl-time-zone.test.tsx', 'utf8');

for (const required of [
  'const timeZoneAccessibleName =',
  "screen.getByRole('textbox', { name: timeZoneAccessibleName })",
  'await waitFor(() => expect(input).toBeEnabled())',
  "expect(input).toHaveValue('UTC')",
]) {
  if (!tests.includes(required)) throw new Error(`P13.12R2 missing accessible-name repair evidence: ${required}`);
}

if (tests.includes("name: 'Time zone'")) {
  throw new Error('P13.12R2 exact short accessible-name query regression remains');
}

for (const forbidden of [
  'resolvedOptions().timeZone',
  'getTimezoneOffset',
  'navigator.language',
  'localStorage',
  'sessionStorage',
  'indexedDB.',
]) {
  if (production.includes(forbidden)) throw new Error(`P13.12R2 production ownership regression: ${forbidden}`);
}

console.log('PASS P13.12R2 accessible-name Settings test-contract verifier');
