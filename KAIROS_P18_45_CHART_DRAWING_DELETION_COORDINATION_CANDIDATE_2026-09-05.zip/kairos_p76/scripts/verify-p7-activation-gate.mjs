import fs from 'node:fs';

const required = [
  'src/features/activation/ActivationGate.tsx',
  'src/features/activation/ActivationBootstrap.tsx',
  'src/features/activation/activationGate.css',
  'tests/activation-gate.test.tsx',
];
for (const file of required) {
  if (!fs.existsSync(file)) throw new Error(`P7.6 missing required file: ${file}`);
}

const gate = fs.readFileSync('src/features/activation/ActivationGate.tsx', 'utf8');
const bootstrap = fs.readFileSync('src/features/activation/ActivationBootstrap.tsx', 'utf8');
const main = fs.readFileSync('src/main.tsx', 'utf8');
const css = fs.readFileSync('src/features/activation/activationGate.css', 'utf8');

const checks = [
  [gate.includes('controller.bootstrap()'), 'gate must bootstrap through the activation coordinator'],
  [gate.includes('controller.activate('), 'gate must activate through the activation coordinator'],
  [gate.includes("status === 'active-online'") && gate.includes("status === 'active-offline'"), 'only verified active states may reveal journal children'],
  [gate.includes('<label htmlFor={inputId}>Invite code</label>'), 'invite input requires an explicit label'],
  [gate.includes("aria-invalid={localError ? 'true' : undefined}"), 'input errors require programmatic invalid state'],
  [bootstrap.includes('VITE_KAIROS_ACTIVATION_ENDPOINT'), 'endpoint must come from deployment configuration'],
  [bootstrap.includes('VITE_KAIROS_ACTIVATION_PUBLIC_KEY_SPKI'), 'public verification key must come from deployment configuration'],
  [bootstrap.includes('databaseStatus.state !== \'ready\''), 'activation bootstrap must fail closed on storage startup failure'],
  [main.includes('<ActivationBootstrap databaseStartup={databaseStartup}>'), 'router must sit behind activation bootstrap'],
  [!gate.includes('fetch(') && !bootstrap.includes('fetch('), 'presentation must not own remote validation'],
  [!gate.toLowerCase().includes('master code') && !bootstrap.toLowerCase().includes('master code'), 'client gate must not contain master-code authority'],
  [!bootstrap.includes('PRIVATE_KEY') && !bootstrap.includes('SIGNING_KEY'), 'client bootstrap must not load signing authority'],
  [css.includes('var(--kairos-'), 'activation presentation must consume shared design tokens'],
  [!css.match(/#[0-9a-fA-F]{3,8}\b/), 'activation presentation must not hard-code colors'],
];

for (const [ok, message] of checks) {
  if (!ok) throw new Error(`P7.6 contract failed: ${message}`);
}

console.log('P7.6 activation gate contract: PASS');
