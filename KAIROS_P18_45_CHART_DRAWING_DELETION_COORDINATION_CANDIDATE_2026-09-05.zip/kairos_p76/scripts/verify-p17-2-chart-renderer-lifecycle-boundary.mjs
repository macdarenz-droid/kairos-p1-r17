import { existsSync, readFileSync } from 'node:fs';

for (const file of [
  'src/features/chart/chartRendererLifecycle.ts',
  'tests/chart-renderer-lifecycle.test.ts',
]) {
  if (!existsSync(file)) throw new Error(`Missing P17.2 file: ${file}`);
}

const source = readFileSync('src/features/chart/chartRendererLifecycle.ts', 'utf8');

for (const token of [
  'ChartRendererLifecycle',
  'ChartRendererFactory',
  'render(model: ChartRenderModel): void',
  'destroy(): void',
  'create(container: HTMLElement): ChartRendererLifecycle',
]) {
  if (!source.includes(token)) throw new Error(`Missing P17.2 token: ${token}`);
}

for (const forbidden of [
  'indexedDB',
  'localStorage',
  'Dexie',
  'WebSocket',
  'setTimeout(',
  'setInterval(',
  'Math.random',
  'decimal.js',
  'subscribeBinance',
  'executeMarketDataReconnect',
  'createTrade',
  'updateTrade',
  'deleteTrade',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P17.2 ownership violation: ${forbidden}`);
  }
}

console.log('P17.2 chart renderer lifecycle boundary verifier PASS');
