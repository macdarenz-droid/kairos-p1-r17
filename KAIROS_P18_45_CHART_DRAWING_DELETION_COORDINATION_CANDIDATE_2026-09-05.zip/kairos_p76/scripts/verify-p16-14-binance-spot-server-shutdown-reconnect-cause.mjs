import { readFileSync } from 'node:fs';
const path='src/services/market-data/providers/binance/binanceSpotServerShutdownReconnectCause.ts';
const text=readFileSync(path,'utf8');
for (const token of ['classifyBinanceSpotPublicStreamEvent','decodeBinanceSpotPublicStreamMessage',"kind: 'transient-failure'",'eventTime']) {
  if (!text.includes(token)) throw new Error(`P16.14 missing required ownership token: ${token}`);
}
for (const forbidden of ['setTimeout(', 'setInterval(', 'Date.now(', 'Math.random(', 'new WebSocket', 'indexedDB', 'Dexie', '.close()']) {
  if (text.includes(forbidden)) throw new Error(`P16.14 scope leak: ${forbidden}`);
}
console.log('PASS P16.14 Binance Spot serverShutdown reconnect-cause verifier');
