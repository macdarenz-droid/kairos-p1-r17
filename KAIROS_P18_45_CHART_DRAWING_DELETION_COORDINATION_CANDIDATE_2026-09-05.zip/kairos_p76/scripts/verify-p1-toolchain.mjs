import { spawnSync } from 'node:child_process';

const EXPECTED_NODE = 'v22.16.0';
const EXPECTED_NPM = '10.9.2';

function fail(message) {
  console.error(`P1 toolchain: FAIL — ${message}`);
  process.exit(1);
}

if (process.version !== EXPECTED_NODE) {
  fail(`expected Node ${EXPECTED_NODE}, received ${process.version}.`);
}

const npm = spawnSync('npm', ['--version'], {
  encoding: 'utf8',
  shell: process.platform === 'win32',
});

if (npm.error) {
  fail(`npm could not start: ${npm.error.message}`);
}
if (npm.status !== 0) {
  fail(`npm --version exited with status ${npm.status}.`);
}

const npmVersion = npm.stdout.trim();
if (npmVersion !== EXPECTED_NPM) {
  fail(`expected npm ${EXPECTED_NPM}, received ${npmVersion || 'unknown'}.`);
}

console.log(`P1 toolchain: PASS — Node ${process.version} / npm ${npmVersion}.`);
