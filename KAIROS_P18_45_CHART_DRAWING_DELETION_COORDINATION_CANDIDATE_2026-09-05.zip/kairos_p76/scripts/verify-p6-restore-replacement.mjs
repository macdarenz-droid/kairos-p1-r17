import fs from 'node:fs';const r=fs.readFileSync('src/data/backup/restoreReplacement.ts','utf8');const repos=fs.readFileSync('src/data/repositories/TradeRepositories.ts','utf8');const meta=fs.readFileSync('src/data/repositories/MetadataRepository.ts','utf8');
for(const x of ['replaceKairosDatabaseFromPreparedRestore','runKairosAtomicWrite','assertKairosDatabaseIntegrity(db)',"'metadata', 'trades', 'tradePlans', 'tradeExecutions', 'tradeFees'"])if(!r.includes(x))throw new Error(`P6.4 replacement contract missing: ${x}`);
if(!meta.includes('async replaceAll(')||((repos.match(/async replaceAll\(/g)||[]).length<4))throw new Error('All backup-scoped stores require repository replacement ownership');
console.log('P6.4 atomic validated full replacement: PASS');
