import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/chartTrendLineCommitCollectionCoordination.ts', 'utf8');
const identity = readFileSync('src/features/chart/chartDrawingIdentity.ts', 'utf8');
const commit = readFileSync('src/features/chart/chartTrendLineDraftCommitCoordination.ts', 'utf8');
const collection = readFileSync('src/features/chart/chartDrawingCollection.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync('tests/chart-trend-line-commit-collection-coordination.test.ts', 'utf8');
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.35 chart trend-line commit collection coordination verification FAIL: ${message}`);
  process.exit(1);
};

for (const required of [
  "import { createChartDrawingId } from './chartDrawingIdentity'",
  "import { commitChartTrendLineDraft } from './chartTrendLineDraftCommitCoordination'",
  'export function commitChartTrendLineDraftToCollection(',
  "state.status !== 'preview' || state.tool !== 'trend-line'",
  'const drawingId = createChartDrawingId()',
  'collection.getDrawing(drawingId) !== null',
  'const drawing = commitChartTrendLineDraft(session, drawingId)',
  'collection.addDrawing(drawing)',
  'return drawing',
]) {
  if (!source.includes(required)) fail(`missing composition evidence: ${required}`);
}

for (const required of [
  'export function createChartDrawingId(): ChartDrawingId',
  'return crypto.randomUUID()',
]) {
  if (!identity.includes(required)) fail(`P18.34 identity regressed: ${required}`);
}

for (const required of [
  'commitChartTrendLineDraft(',
  "session.dispatch({ type: 'commit-drawing', drawingId })",
]) {
  if (!commit.includes(required)) fail(`P18.32 commit coordination regressed: ${required}`);
}

for (const required of [
  'export interface ChartDrawingCollectionSession',
  'getDrawing(drawingId: ChartDrawingId): ChartDrawing | null',
  'addDrawing(drawing: ChartDrawing): readonly ChartDrawing[]',
  "throw new Error('chart-drawing-collection-duplicate-id')",
]) {
  if (!collection.includes(required)) fail(`P18.33 collection regressed: ${required}`);
}

if (!index.includes("export { commitChartTrendLineDraftToCollection } from './chartTrendLineCommitCollectionCoordination';")) {
  fail('chart feature export for P18.35 coordination is missing');
}

if (
  packageJson.scripts?.['verify:p18:35-chart-trend-line-commit-collection-coordination'] !==
  'node scripts/verify-p18-35-chart-trend-line-commit-collection-coordination.mjs'
) {
  fail('P18.35 package verifier script missing');
}

for (const token of [
  'allocates identity through P18.34, commits through P18.32, and stores through P18.33',
  'fails closed before preview without allocating committed collection truth',
  'preflights collection lifecycle before authoritative commit transition',
  'fails closed on an allocated identity collision before committing or replacing collection truth',
]) {
  if (!test.includes(token)) fail(`runtime test does not pin behavior: ${token}`);
}

for (const forbidden of [
  'crypto.randomUUID',
  'defineChartDrawing(',
  "session.dispatch({ type: 'commit-drawing'",
  'reduceChartDrawingInteraction(',
  'new Map<',
  'subscribeClick(',
  'coordinateToPrice(',
  'projectChartDrawing(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.delete(',
  'riskReward',
  'lightweight-charts',
]) {
  if (source.includes(forbidden)) fail(`coordination crossed protected boundary: ${forbidden}`);
}

console.log('P18.35 chart trend-line commit collection coordination verification passed.');
