import fs from 'node:fs';

const read = (path) => fs.readFileSync(path, 'utf8');
const fail = (message) => {
  console.error(`P7.2 activation persistence verification FAIL: ${message}`);
  process.exit(1);
};

const schema = read('src/data/database/schema.ts');
const repository = read('src/services/activation/ActivationReceiptRepository.ts');
const verifier = read('src/services/activation/ActivationReceiptVerifier.ts');
const persistence = read('src/services/activation/activationPersistence.ts');
const metadataRepository = read('src/data/repositories/MetadataRepository.ts');
const metadataScope = read('src/data/repositories/metadataScope.ts');
const backupSnapshot = read('src/data/backup/backupSnapshot.ts');
const tests = read('tests/activation-persistence.test.ts');
const pkg = JSON.parse(read('package.json'));

if (!schema.includes('KAIROS_V1_STORES') || !schema.includes("metadata: '&key'")) {
  fail('P7.2 device activation must remain compatible with the immutable V1 metadata owner.');
}
if (!repository.includes("KAIROS_ACTIVATION_RECEIPT_METADATA_KEY = 'device.activation.receipt'")) {
  fail('activation receipt must use the reserved device-scoped metadata namespace.');
}
if (!repository.includes('MetadataRepository') || /localStorage|sessionStorage/.test(repository + persistence)) {
  fail('activation persistence must stay behind repository ownership and avoid alternate browser storage.');
}
if (!verifier.includes('ActivationReceiptVerifier') || !persistence.includes('verifier.verifyReceipt(stored.receipt)')) {
  fail('stored receipt bytes must pass the replaceable verifier boundary before becoming verified activation.');
}
if (!metadataScope.includes("KAIROS_DEVICE_METADATA_PREFIX = 'device.'")) {
  fail('device-scoped metadata namespace owner is missing.');
}
if (!backupSnapshot.includes('isKairosDeviceScopedMetadataKey(record.key)')) {
  fail('user backup snapshot must exclude installation-local activation evidence.');
}
if (!metadataRepository.includes('deviceScoped') || !metadataRepository.includes('isKairosDeviceScopedMetadataKey')) {
  fail('validated restore must preserve device-scoped control state.');
}
for (const forbidden of ['inviteCode:', 'masterCode', 'signingSecret', 'privateKey', 'fetch(']) {
  if (repository.includes(forbidden) || persistence.includes(forbidden) || verifier.includes(forbidden)) {
    fail(`client activation persistence contains forbidden authority/network scope: ${forbidden}`);
  }
}
for (const requiredTest of [
  'reloads the raw receipt after a database reopen',
  'never turns stored bytes into verified activation without the verifier boundary',
  'fails closed on malformed local receipt data',
  'keeps installation activation evidence out of user backup snapshots',
  'preserves device-scoped activation evidence through the full verified restore cycle',
]) {
  if (!tests.includes(requiredTest)) fail(`missing regression coverage: ${requiredTest}`);
}
if (pkg.scripts?.['verify:p7:activation-persistence'] !== 'node scripts/verify-p7-activation-persistence.mjs') {
  fail('verify:p7:activation-persistence package script is missing or changed.');
}

console.log('P7.2 activation receipt persistence / verification boundary contract: PASS');
