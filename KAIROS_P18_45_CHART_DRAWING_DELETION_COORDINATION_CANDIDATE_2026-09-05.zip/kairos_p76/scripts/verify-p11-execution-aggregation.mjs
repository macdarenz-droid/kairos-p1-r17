import fs from 'node:fs';

const files = [
  'src/domain/calculations/executionAggregation.ts',
  'tests/execution-aggregation.test.ts',
];
for (const file of files) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const source = fs.readFileSync('src/domain/calculations/executionAggregation.ts', 'utf8');

for (const token of [
  'TradeExecutionRecord',
  'decimalAdd',
  'decimalMultiply',
  'decimalDivide',
  'decimalSubtract',
  'weightedAveragePrice',
  'netQuantity',
]) {
  if (!source.includes(token)) throw new Error(`Missing P11.2 aggregation contract: ${token}`);
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error('P11.2 execution aggregation must not use native numeric arithmetic/coercion.');
}

for (const forbidden of [
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
  'profit',
  'loss',
  'rMultiple',
  'leverage',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.2 out-of-scope owner/metric detected: ${forbidden}`);
  }
}

console.log('P11.2 execution aggregation verification PASS');
