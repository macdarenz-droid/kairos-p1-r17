import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/application/visual-pnl/aggregationEligibility.ts', import.meta.url), 'utf8');
const test = readFileSync(new URL('../tests/visual-pnl-aggregation-eligibility.test.ts', import.meta.url), 'utf8');

const requiredSource = [
  "'no-trades'",
  "'unavailable-trade-outcome'",
  "'missing-currency-evidence'",
  "'mixed-currencies'",
  'projection.currency !== currency',
  'amounts.push(projection.amount)',
];
for (const token of requiredSource) {
  if (!source.includes(token)) throw new Error(`P13.4 verifier: missing source contract ${token}`);
}
for (const forbidden of ['new Decimal(', 'Decimal.', 'Number(', 'parseFloat(', 'parseInt(', '.plus(', '.add(', 'reduce(']) {
  if (source.includes(forbidden)) throw new Error(`P13.4 verifier: financial arithmetic/inference forbidden: ${forbidden}`);
}
if (!test.includes("projection('profit', '10', 'USD')") || !test.includes("projection('profit', '20', 'AUD')")) {
  throw new Error('P13.4 verifier: mixed-currency regression fixture missing');
}
if (!test.includes("projection('profit', '2', 'usd')")) {
  throw new Error('P13.4 verifier: exact currency evidence fixture missing');
}
console.log('P13.4 Visual P&L aggregation eligibility verifier: PASS');
