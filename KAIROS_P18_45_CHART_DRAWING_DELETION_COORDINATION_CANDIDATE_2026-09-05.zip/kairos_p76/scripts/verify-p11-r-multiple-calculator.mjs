import fs from 'node:fs';

const files = [
  'src/domain/calculations/rMultipleCalculator.ts',
  'tests/r-multiple-calculator.test.ts',
];

for (const file of files) {
  if (!fs.existsSync(file)) {
    throw new Error(`Missing ${file}`);
  }
}

const source = fs.readFileSync(
  'src/domain/calculations/rMultipleCalculator.ts',
  'utf8',
);

for (const token of [
  'calculateRMultiple',
  'decimalDivide',
  "'zero-initial-risk'",
  "'invalid-decimal'",
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P11.7 R-multiple contract: ${token}`);
  }
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error(
    'P11.7 R-Multiple Calculator must not use native numeric arithmetic/coercion.',
  );
}

for (const forbidden of [
  'TradeRecord',
  'TradeExecutionRecord',
  'TradeFeeRecord',
  'TradePlanRecord',
  'marketType',
  'grossPnl',
  'netPnl',
  'realizedR',
  'plannedStopPrice',
  'plannedEntryPrice',
  'plannedQuantity',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
  'exchangeRate',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.7 out-of-scope policy/owner detected: ${forbidden}`);
  }
}

console.log('P11.7 R-multiple calculator primitive verification PASS');
