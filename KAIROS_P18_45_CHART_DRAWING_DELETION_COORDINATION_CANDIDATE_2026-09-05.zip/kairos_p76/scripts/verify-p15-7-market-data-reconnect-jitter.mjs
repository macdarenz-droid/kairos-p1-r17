import { readFileSync } from 'node:fs';

const owner = readFileSync('src/services/market-data/marketDataReconnectJitter.ts', 'utf8');
const index = readFileSync('src/services/market-data/index.ts', 'utf8');

const checks = [
  ['jitter owner exists', owner.includes('applyMarketDataReconnectFullJitter')],
  ['safe integer delay validation', owner.includes('Number.isSafeInteger(baseDelayMs)')],
  ['finite sample validation', owner.includes('Number.isFinite(sample)')],
  ['normalized lower bound', owner.includes('sample < 0')],
  ['normalized upper bound', owner.includes('sample > 1')],
  ['integer millisecond output', owner.includes('Math.floor(baseDelayMs * sample)')],
  ['invalid delay explicit', owner.includes("reason: 'invalid-delay'")],
  ['invalid sample explicit', owner.includes("reason: 'invalid-sample'")],
  ['barrel exports jitter owner', index.includes("export * from './marketDataReconnectJitter';")],
];

for (const token of ['Math.random(', 'setTimeout(', 'setInterval(', 'Date.now(', 'new WebSocket(', 'new EventSource(', 'fetch(', 'indexedDB', 'Dexie']) {
  checks.push([`forbidden token absent: ${token}`, !owner.includes(token)]);
}

const failed = checks.filter(([, ok]) => !ok);
if (failed.length) {
  for (const [name] of failed) console.error(`FAIL ${name}`);
  process.exit(1);
}
console.log('PASS P15.7 Market Data reconnect jitter verifier');
