import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/lightweightChartsV5TrendLinePrimitive.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');

for (const required of [
  'LightweightChartsV5TrendLinePrimitiveAttachedParameter',
  'createLightweightChartsV5TrendLinePrimitive',
  'attached(parameter)',
  'detached()',
  'updateAllViews()',
  'paneViews()',
  'projectLightweightChartsV5TrendLineSegments',
  'createLightweightChartsV5TrendLinePaneRenderer',
  'attached.chart.timeScale()',
  'attached.series',
]) {
  if (!source.includes(required)) throw new Error(`P18.7 missing required primitive-view composition evidence: ${required}`);
}

for (const forbidden of [
  'CanvasRenderingContext2D',
  'attachPrimitive(',
  'detachPrimitive(',
  'localStorage',
  'IndexedDB',
  'Dexie',
  'fetch(',
  'WebSocket',
  'risk-reward',
]) {
  if (source.includes(forbidden)) throw new Error(`P18.7 crossed controlled scope: ${forbidden}`);
}

if (!index.includes("from './lightweightChartsV5TrendLinePrimitive'")) {
  throw new Error('P18.7 chart index export missing');
}

console.log('P18.7 Lightweight Charts v5 trend-line primitive view composition verification passed.');
