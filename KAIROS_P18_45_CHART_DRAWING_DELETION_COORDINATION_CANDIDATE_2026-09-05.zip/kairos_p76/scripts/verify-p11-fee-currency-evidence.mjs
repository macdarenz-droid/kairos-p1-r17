import fs from 'node:fs';

const sourceFile = 'src/domain/calculations/feeCalculator.ts';
const legacyTestFile = 'tests/fee-calculator.test.ts';
const evidenceTestFile = 'tests/fee-currency-evidence.test.ts';

for (const file of [sourceFile, legacyTestFile, evidenceTestFile]) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const source = fs.readFileSync(sourceFile, 'utf8');
const legacyTests = fs.readFileSync(legacyTestFile, 'utf8');

for (const token of [
  'readonly currency: string | null',
  'currency: null',
  'fee.currency',
  "'mixed-currency'",
  'decimalSum',
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P11.17R1 fee-currency evidence contract: ${token}`);
  }
}

for (const legacyExpectation of [
  "totalFees: '0',\n      currency: null",
  "totalFees: '1.55',\n      currency: 'USD'",
  "totalFees: '0.3',\n      currency: 'USD'",
]) {
  if (!legacyTests.includes(legacyExpectation)) {
    throw new Error(`Legacy fee regression expectation not migrated: ${legacyExpectation}`);
  }
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error('P11.17R1 must preserve locked decimal arithmetic.');
}

for (const forbidden of [
  'exchangeRate',
  'currencyConversion',
  'calculateNetPnl',
  'TradeMetrics',
  'pnlPercent',
  'realizedR',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.17R1 out-of-scope owner detected: ${forbidden}`);
  }
}

console.log('P11.17R1 fee currency evidence verification PASS');
