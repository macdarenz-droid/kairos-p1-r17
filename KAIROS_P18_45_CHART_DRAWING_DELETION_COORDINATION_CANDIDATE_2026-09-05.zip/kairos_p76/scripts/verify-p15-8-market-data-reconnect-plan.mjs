import { readFileSync } from 'node:fs';

const owner = readFileSync('src/services/market-data/marketDataReconnectPlan.ts', 'utf8');
const index = readFileSync('src/services/market-data/index.ts', 'utf8');

const checks = [
  ['plan owner exists', owner.includes('planNextMarketDataReconnect')],
  ['reuses P15.5 decision owner', owner.includes('decideMarketDataReconnect')],
  ['reuses P15.7 jitter owner', owner.includes('applyMarketDataReconnectFullJitter')],
  ['retry result explicit', owner.includes("kind: 'retry'")],
  ['stop result explicit', owner.includes("kind: 'stop'")],
  ['invalid result explicit', owner.includes("kind: 'invalid'")],
  ['base delay preserved', owner.includes('baseDelayMs')],
  ['jittered delay explicit', owner.includes('delayMs: jitter.delayMs')],
  ['attempt limit preserved', owner.includes("reason: 'attempt-limit'")],
  ['invalid policy preserved', owner.includes("reason: 'invalid-policy'")],
  ['invalid sample preserved', owner.includes("reason: 'invalid-sample'")],
  ['barrel exports plan owner', index.includes("export * from './marketDataReconnectPlan';")],
];

for (const token of [
  'Math.random(',
  'setTimeout(',
  'setInterval(',
  'Date.now(',
  'new WebSocket(',
  'new EventSource(',
  'fetch(',
  'indexedDB',
  'Dexie',
]) {
  checks.push([`forbidden token absent: ${token}`, !owner.includes(token)]);
}

const failed = checks.filter(([, ok]) => !ok);
if (failed.length) {
  for (const [name] of failed) console.error(`FAIL ${name}`);
  process.exit(1);
}
console.log('PASS P15.8 Market Data reconnect plan verifier');
