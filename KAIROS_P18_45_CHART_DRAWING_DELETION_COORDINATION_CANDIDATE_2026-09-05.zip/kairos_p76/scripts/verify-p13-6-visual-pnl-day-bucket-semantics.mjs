import { readFileSync } from 'node:fs';

const source = readFileSync('src/application/visual-pnl/dayBucket.ts', 'utf8');
const index = readFileSync('src/application/visual-pnl/index.ts', 'utf8');
const tests = readFileSync('tests/visual-pnl-day-bucket.test.ts', 'utf8');

const requireText = (haystack, needle, label) => {
  if (!haystack.includes(needle)) throw new Error(`P13.6 verifier missing ${label}: ${needle}`);
};

requireText(source, "basis: 'closed-at'", 'closed-at ownership');
requireText(source, "timeZone,", 'explicit time-zone input');
requireText(source, "calendar: 'iso8601'", 'ISO calendar projection');
requireText(source, "numberingSystem: 'latn'", 'stable numeric date parts');
requireText(source, '.formatToParts(instant)', 'structured calendar projection');
requireText(source, "instant.toISOString() === value", 'canonical stored instant validation');
requireText(source, "reason: VisualPnlDayKeyBlockReason", 'explicit blocked state');
requireText(index, "export * from './dayBucket';", 'public export');
requireText(tests, "dayKey: '2026-09-03'", 'Sydney-vs-UTC boundary regression');
requireText(tests, "reason: 'invalid-time-zone'", 'invalid-zone regression');

for (const forbidden of [
  'new Intl.DateTimeFormat()',
  '.toDateString()',
  '.toLocaleDateString()',
  '.getFullYear()',
  '.getMonth()',
  '.getDate()',
  "timeZone: 'UTC'",
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P13.6 verifier rejected implicit/runtime calendar behavior: ${forbidden}`);
  }
}

console.log('PASS P13.6 Visual P&L day-bucket semantics verifier');
