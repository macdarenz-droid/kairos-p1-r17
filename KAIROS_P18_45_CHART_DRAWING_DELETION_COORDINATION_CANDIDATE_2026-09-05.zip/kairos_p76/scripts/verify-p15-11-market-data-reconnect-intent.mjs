import fs from 'node:fs';
const fail=m=>{console.error(`FAIL P15.11 Market Data reconnect intent verifier: ${m}`);process.exit(1)};
const p='src/services/market-data/marketDataReconnectIntent.ts';
if(!fs.existsSync(p))fail('owner missing');
const s=fs.readFileSync(p,'utf8'), b=fs.readFileSync('src/services/market-data/index.ts','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
for(const t of ['classifyMarketDataReconnectDisposition','MarketDataReconnectPolicy','completedAttempts',"kind: 'retry'","kind: 'stop'"])
  if(!s.includes(t))fail(`missing ${t}`);
for(const t of ['planNextMarketDataReconnect','scheduleMarketDataReconnect','Math.random(','setTimeout(','setInterval(','WebSocket','CloseEvent','fetch(','indexedDB','Dexie'])
  if(s.includes(t))fail(`forbidden ownership token ${t}`);
if(!b.includes("export * from './marketDataReconnectIntent';"))fail('barrel export missing');
if(pkg.scripts?.['verify:p15:11-market-data-reconnect-intent']!=='node scripts/verify-p15-11-market-data-reconnect-intent.mjs')fail('package verifier missing');
console.log('PASS P15.11 Market Data reconnect intent verifier');
