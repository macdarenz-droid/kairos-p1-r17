import fs from 'node:fs';

const sourceFile = 'src/domain/calculations/netPnlCalculator.ts';
const testFile = 'tests/net-pnl-calculator.test.ts';
const indexFile = 'src/domain/calculations/index.ts';

for (const file of [sourceFile, testFile, indexFile]) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const source = fs.readFileSync(sourceFile, 'utf8');
const index = fs.readFileSync(indexFile, 'utf8');

for (const token of [
  'calculateNetPnl',
  'grossPnl',
  'totalFees',
  'netPnl',
  'decimalSubtract',
  "'invalid-decimal'",
  'same monetary unit',
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P11.16 net-P&L contract: ${token}`);
  }
}

if (!index.includes("export * from './netPnlCalculator';")) {
  throw new Error('P11.16 net P&L calculator is not exported from calculation boundary.');
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error('P11.16 must use the locked decimal kernel, not native numeric arithmetic.');
}

for (const forbidden of [
  'TradeFeeRecord',
  'TradeMetrics',
  'exchangeRate',
  'currencyConversion',
  'marketType',
  'plannedEntryPrice',
  'plannedStopPrice',
  'realizedR',
  'pnlPercent',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.16 out-of-scope owner detected: ${forbidden}`);
  }
}

console.log('P11.16 net P&L primitive verification PASS');
