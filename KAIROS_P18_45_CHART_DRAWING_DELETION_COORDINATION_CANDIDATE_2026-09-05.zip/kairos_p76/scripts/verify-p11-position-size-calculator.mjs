import fs from 'node:fs';

const files = [
  'src/domain/calculations/positionSizeCalculator.ts',
  'tests/position-size-calculator.test.ts',
];

for (const file of files) {
  if (!fs.existsSync(file)) {
    throw new Error(`Missing ${file}`);
  }
}

const source = fs.readFileSync(
  'src/domain/calculations/positionSizeCalculator.ts',
  'utf8',
);

for (const token of [
  'calculatePositionSize',
  'decimalDivide',
  "'zero-risk-per-unit'",
  "'invalid-decimal'",
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P11.10 position-size contract: ${token}`);
  }
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error(
    'P11.10 PositionSizeCalculator must not use native numeric arithmetic/coercion.',
  );
}

for (const forbidden of [
  'TradeRecord',
  'TradePlanRecord',
  'TradeExecutionRecord',
  'TradeFeeRecord',
  'marketType',
  'plannedEntryPrice',
  'plannedStopPrice',
  'plannedQuantity',
  'initialRisk',
  'leverage',
  'multiplier',
  'tickValue',
  'lotSize',
  'exchangeRate',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.10 out-of-scope policy/owner detected: ${forbidden}`);
  }
}

console.log('P11.10 position-size calculator primitive verification PASS');
