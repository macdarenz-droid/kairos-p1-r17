import fs from 'node:fs';

const adapter = fs.readFileSync('src/design-system/themes/chartThemeAdapter.ts', 'utf8');
const index = fs.readFileSync('src/design-system/themes/index.ts', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));

const requiredTokens = [
  'background','grid','axis','crosshair','candle-up','candle-down','wick-up','wick-down',
  'volume-up','volume-down','drawing-primary','drawing-secondary','support','resistance',
].map((name) => `--kairos-chart-${name}`);

for (const token of requiredTokens) {
  if (!adapter.includes(token)) throw new Error(`P3.5 chart adapter missing ${token}`);
}
if (!adapter.includes('themeRegistry[themeId].tokens')) throw new Error('P3.5 chart adapter must resolve from the authoritative theme registry.');
if (!adapter.includes('Object.freeze')) throw new Error('P3.5 chart adapter output must be immutable.');
if (!index.includes('getChartTheme')) throw new Error('P3.5 chart adapter must be exported through the theme public API.');
if (pkg.scripts?.['verify:p3:chart-theme-adapter'] !== 'node scripts/verify-p3-chart-theme-adapter.mjs') throw new Error('P3.5 verification script is not registered.');
const forbidden = ['localStorage', 'indexedDB', 'fetch(', 'createChart(', 'spacing', 'radius', 'motionDuration'];
for (const text of forbidden) {
  if (adapter.includes(text)) throw new Error(`P3.5 chart adapter contains forbidden ownership/geometry surface: ${text}`);
}
console.log('P3.5 chart theme adapter contract: PASS');
