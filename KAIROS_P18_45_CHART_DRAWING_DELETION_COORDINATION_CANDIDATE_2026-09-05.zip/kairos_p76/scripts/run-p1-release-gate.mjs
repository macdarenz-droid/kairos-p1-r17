import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { P1_GATE_EXIT } from './p1-gate-result.mjs';

const evidencePath = 'P1_GATE_EVIDENCE.json';
const startedAt = new Date().toISOString();

const steps = [
  ['Toolchain', ['run', 'verify:toolchain']],
  ['Static contract', ['run', 'verify:static']],
  ['Resolve lockfile', ['run', 'lock:resolve']],
  ['Verify lockfile', ['run', 'verify:lock']],
  ['Frozen verification gate', ['run', 'verify:gate']],
];

function sha256File(path) {
  if (!existsSync(path)) return null;
  return createHash('sha256').update(readFileSync(path)).digest('hex');
}

function npmVersion() {
  const result = spawnSync('npm', ['--version'], {
    encoding: 'utf8',
    shell: process.platform === 'win32',
  });
  return result.status === 0 ? result.stdout.trim() : null;
}

function run(args) {
  return spawnSync('npm', args, {
    encoding: 'utf8',
    stdio: 'pipe',
    shell: process.platform === 'win32',
  });
}

const evidence = {
  schemaVersion: 1,
  phase: 'P1',
  startedAt,
  completedAt: null,
  status: 'RUNNING',
  blocker: null,
  runtime: {
    node: process.version,
    npm: npmVersion(),
    platform: process.platform,
    arch: process.arch,
  },
  inputs: {
    packageJsonSha256: sha256File('package.json'),
    packageLockSha256: sha256File('package-lock.json'),
  },
  steps: [],
};

function finish(status, exitCode, blocker = null) {
  evidence.completedAt = new Date().toISOString();
  evidence.status = status;
  evidence.blocker = blocker;
  evidence.inputs.packageLockSha256 = sha256File('package-lock.json');
  writeFileSync(evidencePath, `${JSON.stringify(evidence, null, 2)}\n`, 'utf8');

  console.log(`\n[P1 release] Evidence written to ${evidencePath}`);
  console.log(`P1 release: ${status}${blocker ? ` — ${blocker}` : ''}`);
  process.exit(exitCode);
}

for (const [label, args] of steps) {
  console.log(`\n[P1 release] ${label}`);
  const stepStartedAt = new Date().toISOString();
  const result = run(args);
  const stdout = result.stdout ?? '';
  const stderr = result.stderr ?? '';

  if (stdout) process.stdout.write(stdout);
  if (stderr) process.stderr.write(stderr);

  const step = {
    label,
    command: `npm ${args.join(' ')}`,
    startedAt: stepStartedAt,
    completedAt: new Date().toISOString(),
    exitCode: result.status,
    status: 'PASS',
  };

  if (result.error) {
    step.status = 'FAIL';
    step.error = result.error.message;
    evidence.steps.push(step);
    finish('FAIL', P1_GATE_EXIT.FAIL, `${label} could not start.`);
  }

  if (result.status === P1_GATE_EXIT.HOLD) {
    step.status = 'HOLD';
    evidence.steps.push(step);
    finish('HOLD', P1_GATE_EXIT.HOLD, `${label} is blocked.`);
  }

  if (result.status !== P1_GATE_EXIT.PASS) {
    step.status = 'FAIL';
    evidence.steps.push(step);
    finish('FAIL', P1_GATE_EXIT.FAIL, `${label} exited with status ${result.status}.`);
  }

  evidence.steps.push(step);
}

finish(
  'PASS',
  P1_GATE_EXIT.PASS,
  null,
);
