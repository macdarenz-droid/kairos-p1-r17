import fs from 'node:fs';

const sourceFile = 'src/domain/calculations/feeCalculator.ts';
const testFile = 'tests/fee-calculator.test.ts';
const indexFile = 'src/domain/calculations/index.ts';

for (const file of [sourceFile, testFile, indexFile]) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const source = fs.readFileSync(sourceFile, 'utf8');
const index = fs.readFileSync(indexFile, 'utf8');

for (const token of [
  'calculateTotalFees',
  'TradeFeeRecord',
  'decimalSum',
  'fee.amount',
  'fee.currency',
  "'invalid-decimal'",
  "'mixed-currency'",
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P11.15 fee-calculation contract: ${token}`);
  }
}

if (!index.includes("export * from './feeCalculator';")) {
  throw new Error('P11.15 fee calculator is not exported from calculation boundary.');
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error('P11.15 must use the locked decimal kernel, not native numeric arithmetic.');
}

for (const forbidden of [
  'grossPnl',
  'netPnl',
  'realizedR',
  'pnlPercent',
  'TradeMetrics',
  'exchangeRate',
  'currencyConversion',
  'marketType',
  'plannedEntryPrice',
  'plannedStopPrice',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.15 out-of-scope semantic owner detected: ${forbidden}`);
  }
}

console.log('P11.15 fee aggregation primitive verification PASS');
