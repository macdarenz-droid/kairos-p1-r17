import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/chartTrendLineDraftAnchorCollection.ts', 'utf8');
const drawingContract = readFileSync('src/features/chart/chartDrawingContract.ts', 'utf8');
const interactionPort = readFileSync('src/features/chart/chartDrawingInteractionPort.ts', 'utf8');
const test = readFileSync('tests/chart-trend-line-draft-anchor-collection.test.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.28 chart trend-line draft anchor collection verification FAIL: ${message}`);
  process.exit(1);
};

for (const required of [
  'export type ChartTrendLineDraftAnchors =',
  'readonly [ChartDrawingAnchor]',
  'readonly [ChartDrawingAnchor, ChartDrawingAnchor]',
  'getAnchors(): ChartTrendLineDraftAnchors',
  'appendAnchor(anchor: ChartDrawingAnchor): ChartTrendLineDraftAnchors',
  'clear(): ChartTrendLineDraftAnchors',
  "throw new Error('chart-trend-line-draft-anchor-collection-complete')",
  "throw new Error('chart-trend-line-draft-anchor-collection-destroyed')",
]) {
  if (!source.includes(required)) fail(`missing anchor collection evidence: ${required}`);
}

for (const required of [
  'readonly start: ChartDrawingAnchor',
  'readonly end: ChartDrawingAnchor',
]) {
  if (!drawingContract.includes(required)) fail(`P18.1 trend-line anchor truth regressed: ${required}`);
}
if (!interactionPort.includes('reduceChartDrawingInteraction(currentState, event)')) {
  fail('P18.24 interaction-session transition delegation regressed');
}
if (!index.includes('createChartTrendLineDraftAnchorCollectionPort')) {
  fail('chart feature export for trend-line draft anchor collection is missing');
}
if (
  packageJson.scripts?.['verify:p18:28-chart-trend-line-draft-anchor-collection'] !==
  'node scripts/verify-p18-28-chart-trend-line-draft-anchor-collection.mjs'
) {
  fail('P18.28 package verifier script missing');
}

for (const token of [
  'collects exactly the first and second anchors without creating committed drawing truth',
  'fails closed on a third anchor until the draft is explicitly cleared',
  'clear removes only ephemeral draft-anchor evidence and allows a new first anchor',
  'keeps separate draft sessions isolated',
  'destroy is idempotent and later draft access fails closed',
]) {
  if (!test.includes(token)) fail(`runtime test does not pin behavior: ${token}`);
}

for (const forbidden of [
  'subscribeClick(',
  'unsubscribeClick(',
  'subscribeCrosshairMove(',
  'coordinateToPrice(',
  'reduceChartDrawingInteraction(',
  '.dispatch(',
  'defineChartDrawing(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.delete(',
  'riskReward',
]) {
  if (source.includes(forbidden)) fail(`draft anchor collection crossed protected boundary: ${forbidden}`);
}

console.log('P18.28 chart trend-line draft anchor collection verification passed.');
