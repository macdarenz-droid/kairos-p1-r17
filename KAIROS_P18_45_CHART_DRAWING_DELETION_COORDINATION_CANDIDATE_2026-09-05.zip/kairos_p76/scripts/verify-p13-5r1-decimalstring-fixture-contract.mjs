import { readFileSync } from 'node:fs';

const test = readFileSync('tests/visual-pnl-aggregation-summary.test.ts', 'utf8');
const source = readFileSync('src/application/visual-pnl/aggregationSummary.ts', 'utf8');

const requireText = (haystack, needle, label) => {
  if (!haystack.includes(needle)) throw new Error(`P13.5R1 verifier missing ${label}: ${needle}`);
};

requireText(test, "import { parseDecimalString } from '../src/domain/trades';", 'authoritative DecimalString parser import');
requireText(test, 'function dec(value: string)', 'validated fixture helper');
requireText(test, 'const parsed = parseDecimalString(value);', 'fixture parser use');
requireText(test, "projection('profit', dec('10.25'), 'USD')", 'branded decimal fixture');
requireText(test, "projection('loss', dec('-3.1'), 'USD')", 'negative branded decimal fixture');
requireText(test, "projection('unavailable', null, null)", 'null unavailable fixture');

for (const forbidden of [
  "as DecimalString",
  "as VisualPnlOutcomeProjection['amount']",
  "projection('profit', '10.25'",
  "projection('loss', '-3.1'",
]) {
  if (test.includes(forbidden)) throw new Error(`P13.5R1 verifier rejected fixture contract bypass: ${forbidden}`);
}

if (!source.includes('decimalSum(eligibility.amounts)')) {
  throw new Error('P13.5R1 verifier expected unchanged production aggregation ownership');
}

console.log('PASS P13.5R1 DecimalString fixture contract verifier');
