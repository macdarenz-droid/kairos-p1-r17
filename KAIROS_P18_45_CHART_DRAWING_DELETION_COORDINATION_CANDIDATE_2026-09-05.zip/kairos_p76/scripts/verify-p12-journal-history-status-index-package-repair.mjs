import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const pkg = JSON.parse(readFileSync('package.json', 'utf8'));
const verifyScripts = Object.entries(pkg.scripts ?? {}).filter(([name]) => name.startsWith('verify:p'));
const dangling = [];

for (const [name, command] of verifyScripts) {
  const matches = [...String(command).matchAll(/(?:^|&&|;)\s*node\s+([^\s;&]+)/g)];
  for (const match of matches) {
    const scriptPath = match[1];
    if (!existsSync(resolve(scriptPath))) dangling.push(`${name} -> ${scriptPath}`);
  }
}

if ('verify:p12:journal-history-status-index-backup-repair' in (pkg.scripts ?? {})) {
  throw new Error('Superseded P12.4R1 backup-repair verifier registration must not remain.');
}
for (const required of [
  'verify:p12:journal-history-status-index',
  'verify:p12:journal-history-status-index-backup-regression-repair',
  'verify:p12:journal-history-status-index-verifier-compatibility-repair',
  'verify:p12:journal-history-status-index-package-repair',
]) {
  if (!(required in (pkg.scripts ?? {}))) throw new Error(`Missing required ${required}`);
}
if (dangling.length) throw new Error(`Dangling verify:p script targets:\n${dangling.join('\n')}`);
console.log(`P12.4R4 package verifier registration integrity PASS (${verifyScripts.length} verify:p entries checked).`);
