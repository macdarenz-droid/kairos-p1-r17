import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/features/chart/chartDrawingLayerPort.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/features/chart/index.ts', import.meta.url), 'utf8');

const required = [
  "import type { ChartEngineSeriesHandle } from './chartEngineDriver'",
  "import type { RendererChartDrawing } from './chartDrawingProjection'",
  'export interface ChartDrawingLayerDriverHandle',
  'replaceDrawings(drawings: readonly RendererChartDrawing[]): void',
  'detach(): void',
  'export interface ChartDrawingLayerDriver',
  'attach(series: ChartEngineSeriesHandle): ChartDrawingLayerDriverHandle',
  'export interface ChartDrawingLayerSession',
  'destroy(): void',
  'export interface ChartDrawingLayerPort',
  'export function createChartDrawingLayerPortFromDriver',
  "throw new Error('chart-drawing-layer-destroyed')",
  'handle.detach()',
];
for (const token of required) {
  if (!source.includes(token)) throw new Error(`P18.3 drawing layer port missing: ${token}`);
}
for (const forbidden of ['lightweight-charts', 'CanvasRenderingContext2D', 'IndexedDB', 'Dexie', 'fetch(', 'WebSocket', 'localStorage', 'risk-reward']) {
  if (source.includes(forbidden)) throw new Error(`P18.3 drawing layer port owns forbidden concern: ${forbidden}`);
}
if (!index.includes("from './chartDrawingLayerPort'")) throw new Error('P18.3 chart index does not export drawing layer port');
console.log('P18.3 chart drawing layer lifecycle port verification passed.');
