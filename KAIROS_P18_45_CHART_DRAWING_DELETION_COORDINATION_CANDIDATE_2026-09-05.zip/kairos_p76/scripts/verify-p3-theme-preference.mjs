import fs from 'node:fs';

const preference = fs.readFileSync('src/design-system/themes/themePreference.ts', 'utf8');
const provider = fs.readFileSync('src/design-system/themes/ThemeProvider.tsx', 'utf8');
const main = fs.readFileSync('src/main.tsx', 'utf8');

const checks = [
  ['versioned storage key', preference.includes("kairos.theme.preference.v1")],
  ['default preference is theme default', preference.includes('defaultThemePreference: ThemePreference = defaultThemeId')],
  ['safe read fallback', preference.includes('return defaultThemePreference')],
  ['safe write failure', preference.includes('return false')],
  ['provider is single runtime preference owner', provider.includes('ThemeProvider') && provider.includes('setPreference')],
  ['provider listens for cross-context storage updates', provider.includes("addEventListener('storage'")],
  ['initial theme applied before root render', main.indexOf('applyInitialTheme();') < main.indexOf('createRoot(root')],
  ['provider wraps application shell', main.includes('<ThemeProvider><AppErrorBoundary>')],
  ['no P5 database ownership introduced', !preference.includes('indexedDB') && !provider.includes('indexedDB') && !preference.includes('Dexie')],
];

const failed = checks.filter(([, ok]) => !ok);
if (failed.length) {
  for (const [name] of failed) console.error(`P3.4 contract FAIL: ${name}`);
  process.exit(1);
}
console.log('P3.4 persistent theme preference contract: PASS');
