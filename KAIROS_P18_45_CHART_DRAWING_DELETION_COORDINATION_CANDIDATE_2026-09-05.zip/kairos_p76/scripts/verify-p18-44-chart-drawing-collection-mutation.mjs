import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/chartDrawingCollection.ts', 'utf8');
const legacyVerifier = readFileSync('scripts/verify-p18-33-chart-drawing-collection.mjs', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync('tests/chart-drawing-collection-mutation.test.ts', 'utf8');
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.44 chart drawing collection mutation verification FAIL: ${message}`);
  process.exit(1);
};

for (const required of [
  'replaceDrawing(drawingId: ChartDrawingId, drawing: ChartDrawing): readonly ChartDrawing[]',
  'removeDrawing(drawingId: ChartDrawingId): readonly ChartDrawing[]',
  "throw new Error('chart-drawing-collection-missing-id')",
  "throw new Error('chart-drawing-collection-identity-mismatch')",
  'drawings.set(drawingId, drawing)',
  'drawings.delete(drawingId)',
]) {
  if (!source.includes(required)) fail(`missing committed-set mutation evidence: ${required}`);
}

for (const preserved of [
  'getDrawings(): readonly ChartDrawing[]',
  'getDrawing(drawingId: ChartDrawingId): ChartDrawing | null',
  'addDrawing(drawing: ChartDrawing): readonly ChartDrawing[]',
  "throw new Error('chart-drawing-collection-duplicate-id')",
  "throw new Error('chart-drawing-collection-destroyed')",
]) {
  if (!source.includes(preserved)) fail(`P18.33 collection contract regressed: ${preserved}`);
}

if (!index.includes('createChartDrawingCollectionPort')) {
  fail('chart feature export for the sole committed collection owner is missing');
}

if (
  packageJson.scripts?.['verify:p18:44-chart-drawing-collection-mutation'] !==
  'node scripts/verify-p18-44-chart-drawing-collection-mutation.mjs'
) {
  fail('P18.44 package verifier script missing');
}

for (const token of [
  'replaces an existing committed drawing without changing identity or insertion order',
  'fails closed when replacement identity does not match the authoritative key',
  'fails closed when replacement targets a missing committed drawing',
  'removes exactly one existing committed drawing while preserving survivor order',
  'fails closed when removal targets a missing committed drawing',
  'destroyed collections reject later replace and remove mutation',
]) {
  if (!test.includes(token)) fail(`runtime test does not pin behavior: ${token}`);
}

for (const forbidden of [
  'randomUUID',
  'crypto.',
  'defineChartDrawing(',
  'commitChartTrendLineDraft(',
  'dispatch(',
  'reduceChartDrawingInteraction(',
  'subscribeClick(',
  'coordinateToPrice(',
  'projectChartDrawing(',
  'replaceChartDrawingPresentationFromCollection(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  'riskReward',
  'lightweight-charts',
]) {
  if (source.includes(forbidden)) fail(`collection mutation crossed protected boundary: ${forbidden}`);
}

if (legacyVerifier.includes("  '.delete(',")) {
  fail('P18.33 verifier still forbids the controlled P18.44 owner extension');
}

console.log('P18.44 chart drawing collection mutation verification passed.');
