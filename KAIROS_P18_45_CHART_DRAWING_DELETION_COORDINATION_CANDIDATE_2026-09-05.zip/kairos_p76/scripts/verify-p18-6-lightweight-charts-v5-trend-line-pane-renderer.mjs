import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/features/chart/lightweightChartsV5TrendLinePaneRenderer.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/features/chart/index.ts', import.meta.url), 'utf8');

for (const required of [
  "IPrimitivePaneRenderer",
  "LightweightChartsV5TrendLineScreenSegment",
  "LightweightChartsV5TrendLineStrokeStyle",
  "createLightweightChartsV5TrendLinePaneRenderer",
  "useBitmapCoordinateSpace",
  "horizontalPixelRatio",
  "verticalPixelRatio",
  "context.moveTo",
  "context.lineTo",
  "context.stroke",
]) {
  if (!source.includes(required)) throw new Error(`P18.6 missing required renderer token: ${required}`);
}

for (const forbidden of [
  'timeToCoordinate(',
  'priceToCoordinate(',
  'attachPrimitive(',
  'detachPrimitive(',
  'hitTest(',
  'subscribeClick(',
  'subscribeCrosshairMove(',
  'localStorage',
  'indexedDB',
  'Dexie',
  'fetch(',
  'WebSocket',
  'risk-reward',
]) {
  if (source.includes(forbidden)) throw new Error(`P18.6 forbidden ownership token: ${forbidden}`);
}

if (!index.includes("from './lightweightChartsV5TrendLinePaneRenderer'")) {
  throw new Error('P18.6 index export missing');
}

console.log('P18.6 Lightweight Charts v5 trend-line pane renderer verification passed.');
