import fs from 'node:fs';

const sourceFile = 'src/domain/calculations/netPnlComposition.ts';
const testFile = 'tests/net-pnl-composition.test.ts';
const indexFile = 'src/domain/calculations/index.ts';
for (const file of [sourceFile, testFile, indexFile]) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const source = fs.readFileSync(sourceFile, 'utf8');
for (const token of [
  'calculateComparableNetPnl',
  'assessNetPnlCurrencyCompatibility',
  'calculateNetPnl',
  'available: false',
  "'missing-gross-pnl-currency'",
  "'missing-fee-currency'",
  "'currency-mismatch'",
  "'zero-fees'",
  "'same-currency'",
]) {
  if (!source.includes(token)) throw new Error(`Missing P11.20 contract: ${token}`);
}
if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error('P11.20 must not introduce native numeric authority.');
}
for (const forbidden of [
  'exchangeRate',
  'currencyConversion',
  'fetch(',
  'WebSocket',
  'Dexie',
  'indexedDB',
  'calculateTradeMetrics(',
]) {
  if (source.includes(forbidden)) throw new Error(`P11.20 out-of-scope owner detected: ${forbidden}`);
}
const index = fs.readFileSync(indexFile, 'utf8');
if (!index.includes("export * from './netPnlComposition';")) {
  throw new Error('P11.20 composition primitive must be exported through Calculation Engine index.');
}
console.log('P11.20 Net P&L currency-aware composition verification PASS');
