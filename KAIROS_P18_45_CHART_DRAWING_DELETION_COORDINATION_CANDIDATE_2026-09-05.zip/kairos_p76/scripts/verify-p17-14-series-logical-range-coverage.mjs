import { readFileSync } from 'node:fs';

const contract = readFileSync(
  'src/features/chart/chartSeriesLogicalRangeCoverage.ts',
  'utf8',
);
const adapter = readFileSync(
  'src/features/chart/lightweightChartsV5SeriesLogicalRangeCoverage.ts',
  'utf8',
);
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync(
  'tests/lightweight-charts-v5-series-logical-range-coverage.test.ts',
  'utf8',
);

const required = [
  [contract, 'ChartSeriesLogicalRangeCoveragePort'],
  [contract, 'barsBefore'],
  [contract, 'barsAfter'],
  [adapter, 'barsInLogicalRange'],
  [adapter, 'createLightweightChartsV5SeriesLogicalRangeCoveragePort'],
  [index, "from './chartSeriesLogicalRangeCoverage'"],
  [index, "from './lightweightChartsV5SeriesLogicalRangeCoverage'"],
  [test, 'preserves null'],
];

for (const [source, token] of required) {
  if (!source.includes(token)) {
    throw new Error(`P17.14 verifier missing required token: ${token}`);
  }
}

const forbidden = [
  'fetch(',
  'WebSocket',
  'Binance',
  '50 bars',
  'threshold',
];
for (const token of forbidden) {
  if (contract.includes(token) || adapter.includes(token)) {
    throw new Error(`P17.14 boundary owns forbidden behavior: ${token}`);
  }
}

console.log('P17.14 series logical range coverage verifier: PASS');
