import { readFileSync } from 'node:fs';

const map = readFileSync(new URL('../src/app/JournalTradeMap.tsx', import.meta.url), 'utf8');
const graphic = readFileSync(new URL('../src/app/JournalTradeMapGraphic.tsx', import.meta.url), 'utf8');
const css = readFileSync(new URL('../src/app/journalRoute.css', import.meta.url), 'utf8');
const accessibility = readFileSync(new URL('../src/design-system/accessibility.css', import.meta.url), 'utf8');

for (const token of [
  "[data-level-kind='executed-exit']",
  'animation: kairos-trade-map-executed-exit-reveal var(--kairos-motion-normal) ease-out both;',
  '@keyframes kairos-trade-map-executed-exit-reveal',
  'from { opacity: 0.55; }',
  'to { opacity: 1; }',
]) {
  if (!css.includes(token)) throw new Error(`P14.8 missing motion token: ${token}`);
}

for (const forbidden of ['transform:', 'translate(', 'scale(', 'rotate(', 'repeat(', 'infinite']) {
  const block = css.slice(css.indexOf('/* P14.8 motion semantics'));
  if (block.includes(forbidden)) throw new Error(`P14.8 positional/repeating motion forbidden: ${forbidden}`);
}

for (const token of [
  '@media (prefers-reduced-motion: reduce)',
  'animation-duration: var(--kairos-motion-instant) !important;',
  'animation-iteration-count: 1 !important;',
]) {
  if (!accessibility.includes(token)) throw new Error(`P14.8 reduced-motion contract missing: ${token}`);
}

for (const token of ['data-level-kind={level.kind}', "level.kind === 'executed-exit'", 'level.executedAt !== null']) {
  if (!map.includes(token) && !graphic.includes(token)) throw new Error(`P14.8 authoritative level token missing: ${token}`);
}

for (const source of [map, graphic]) {
  for (const forbidden of ['setTimeout(', 'requestAnimationFrame(', 'fetch(', 'WebSocket', 'indexedDB']) {
    if (source.includes(forbidden)) throw new Error(`P14.8 forbidden new truth/timing owner token: ${forbidden}`);
  }
}

console.log('P14.8 Journal Trade Map motion semantics verifier PASS');
