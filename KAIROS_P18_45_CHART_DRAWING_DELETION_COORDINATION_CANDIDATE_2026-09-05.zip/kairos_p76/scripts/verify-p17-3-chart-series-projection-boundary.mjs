import { existsSync, readFileSync } from 'node:fs';

for (const file of [
  'src/features/chart/chartSeriesProjection.ts',
  'tests/chart-series-projection.test.ts',
]) {
  if (!existsSync(file)) throw new Error(`Missing P17.3 file: ${file}`);
}

const source = readFileSync('src/features/chart/chartSeriesProjection.ts', 'utf8');

for (const token of [
  'projectChartPricePoint',
  'projectChartCandle',
  'projectChartSeries',
  'Date.parse(timestamp)',
  'Number(value)',
  "throw new Error('invalid-chart-timestamp')",
  "throw new Error('invalid-chart-decimal')",
]) {
  if (!source.includes(token)) throw new Error(`Missing P17.3 token: ${token}`);
}

for (const forbidden of [
  'indexedDB',
  'localStorage',
  'Dexie',
  'WebSocket',
  'setTimeout(',
  'setInterval(',
  'Math.random',
  'subscribeBinance',
  'executeMarketDataReconnect',
  'createTrade',
  'updateTrade',
  'deleteTrade',
  'lightweight-charts',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P17.3 ownership violation: ${forbidden}`);
  }
}

console.log('P17.3 chart series projection boundary verifier PASS');
