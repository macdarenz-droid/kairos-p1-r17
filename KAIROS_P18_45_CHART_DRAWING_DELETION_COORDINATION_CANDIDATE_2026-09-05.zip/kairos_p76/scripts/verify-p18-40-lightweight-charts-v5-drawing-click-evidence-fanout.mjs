import { readFileSync } from 'node:fs';

const subscription = readFileSync('src/features/chart/lightweightChartsV5DrawingClickSubscription.ts', 'utf8');
const binding = readFileSync('src/features/chart/lightweightChartsV5DrawingClickBindingComposition.ts', 'utf8');
const selection = readFileSync('src/features/chart/lightweightChartsV5DrawingSelectionProjection.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const subscriptionTest = readFileSync('tests/lightweight-charts-v5-drawing-click-subscription.test.ts', 'utf8');
const bindingTest = readFileSync('tests/lightweight-charts-v5-drawing-click-binding-composition.test.ts', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.40 drawing click evidence fan-out verification FAIL: ${message}`);
  process.exit(1);
};

for (const token of [
  'LightweightChartsV5DrawingAnchorEvent & LightweightChartsV5DrawingSelectionMouseEvent',
  'onProviderClick?: LightweightChartsV5DrawingProviderClickListener',
  'onProviderClick?.(event)',
  'onAnchor(projectLightweightChartsV5DrawingAnchor(event, series))',
  'chart.subscribeClick(handleClick)',
  'chart.unsubscribeClick(handleClick)',
]) {
  if (!subscription.includes(token)) fail(`missing single-lifecycle fan-out evidence: ${token}`);
}

if (subscription.indexOf('onProviderClick?.(event)') > subscription.indexOf('onAnchor(projectLightweightChartsV5DrawingAnchor(event, series))')) {
  fail('raw provider click evidence must be forwarded before anchor delivery');
}
if ((subscription.match(/chart\.subscribeClick\(handleClick\)/g) || []).length !== 1) {
  fail('P18.26 must still own exactly one subscribeClick call');
}

for (const token of [
  'onProviderClick?: LightweightChartsV5DrawingProviderClickListener',
  'createLightweightChartsV5DrawingClickSubscription(',
  'onProviderClick,',
]) {
  if (!binding.includes(token)) fail(`binding pass-through missing: ${token}`);
}
if (!selection.includes('projectLightweightChartsV5DrawingSelection')) {
  fail('P18.39 selection projection owner regressed');
}
for (const token of ['LightweightChartsV5DrawingClickEvent', 'LightweightChartsV5DrawingProviderClickListener']) {
  if (!index.includes(token)) fail(`chart feature export missing: ${token}`);
}

for (const token of [
  'fans out the exact provider click event before anchor projection without a second subscription',
  "expect(calls).toEqual(['provider', 'anchor'])",
]) {
  if (!subscriptionTest.includes(token)) fail(`P18.26 runtime evidence missing: ${token}`);
}
for (const token of [
  'forwards raw provider click evidence through P18.26 while keeping one subscription',
  'expect(onProviderClick).toHaveBeenCalledWith(event)',
]) {
  if (!bindingTest.includes(token)) fail(`P18.27 runtime evidence missing: ${token}`);
}

for (const source of [subscription, binding]) {
  for (const forbidden of [
    'reduceChartDrawingInteraction(',
    "dispatch({ type: 'select-drawing'",
    'projectLightweightChartsV5DrawingSelection(',
    'IndexedDB',
    'Dexie',
    'localStorage',
    'riskReward',
  ]) {
    if (source.includes(forbidden)) fail(`P18.40 crossed protected boundary: ${forbidden}`);
  }
}

if (
  pkg.scripts?.['verify:p18:40-lightweight-charts-v5-drawing-click-evidence-fanout'] !==
  'node scripts/verify-p18-40-lightweight-charts-v5-drawing-click-evidence-fanout.mjs'
) {
  fail('P18.40 package verifier script missing');
}

console.log('P18.40 Lightweight Charts v5 drawing click evidence fan-out verification passed.');
