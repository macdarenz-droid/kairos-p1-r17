import { existsSync, readFileSync } from 'node:fs';

for (const file of [
  'src/features/chart/lightweightChartsV5IncrementalUpdate.ts',
  'tests/lightweight-charts-v5-incremental-update.test.ts',
]) {
  if (!existsSync(file)) throw new Error(`Missing P17.8 file: ${file}`);
}

const source = readFileSync(
  'src/features/chart/lightweightChartsV5IncrementalUpdate.ts',
  'utf8',
);
const adapter = readFileSync(
  'src/features/chart/lightweightChartsV5ModuleAdapter.ts',
  'utf8',
);

for (const token of [
  'ChartIncrementalUpdate',
  'LightweightChartsV5IncrementalSeries',
  'applyLightweightChartsV5IncrementalUpdate',
  'target.series.update(update.point)',
  'target.series.update(update.candle)',
  'chart-series-kind-mismatch',
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P17.8 token: ${token}`);
  }
}

if (!adapter.includes('update(data: TData): void;')) {
  throw new Error('P17.8 requires v5 series update API shape');
}

for (const forbidden of [
  "from 'lightweight-charts'",
  'historicalUpdate',
  'setData(',
  'indexedDB',
  'localStorage',
  'Dexie',
  'WebSocket',
  'setTimeout(',
  'setInterval(',
  'Math.random',
  'subscribeBinance',
  'executeMarketDataReconnect',
  'createTrade',
  'updateTrade',
  'deleteTrade',
  'decimal.js',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P17.8 ownership/performance violation: ${forbidden}`);
  }
}

console.log('P17.8 Lightweight Charts v5 incremental update verifier PASS');
