import { readFileSync } from 'node:fs';

const source = readFileSync(
  'src/features/chart/chartViewportHistoryDemand.ts',
  'utf8',
);
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync('tests/chart-viewport-history-demand.test.ts', 'utf8');

const required = [
  [source, 'ChartViewportHistoryDemandPolicy'],
  [source, 'minimumBarsBefore'],
  [source, 'barsBeforeShortfall'],
  [source, 'createChartViewportHistoryDemandPort'],
  [source, 'subscribeVisibleLogicalRangeChange'],
  [source, 'coveragePort.getCoverage'],
  [index, "from './chartViewportHistoryDemand'"],
  [test, 'missing viewport'],
  [test, 'missing series coverage'],
  [test, 'invalid injected policy'],
];

for (const [text, token] of required) {
  if (!text.includes(token)) {
    throw new Error(`P17.15 verifier missing required token: ${token}`);
  }
}

for (const forbidden of ['fetch(', 'WebSocket', 'Binance', 'lightweight-charts', 'setData(', 'update(']) {
  if (source.includes(forbidden)) {
    throw new Error(`P17.15 composition owns forbidden behavior: ${forbidden}`);
  }
}

if (/minimumBarsBefore\s*:\s*50/.test(source)) {
  throw new Error('P17.15 must not hard-code the documentation example threshold');
}

console.log('P17.15 chart viewport history demand verifier: PASS');
