import fs from 'node:fs';

const read = (path) => fs.readFileSync(path, 'utf8');
const fail = (message) => {
  console.error(`P18.26 drawing click subscription verification FAIL: ${message}`);
  process.exit(1);
};

const source = read('src/features/chart/lightweightChartsV5DrawingClickSubscription.ts');
const projection = read('src/features/chart/lightweightChartsV5DrawingAnchorProjection.ts');
const interaction = read('src/features/chart/chartDrawingInteractionPort.ts');
const test = read('tests/lightweight-charts-v5-drawing-click-subscription.test.ts');
const index = read('src/features/chart/index.ts');

for (const token of [
  'subscribeClick(handler:',
  'unsubscribeClick(handler:',
  'projectLightweightChartsV5DrawingAnchor(event, series)',
  'chart.subscribeClick(handleClick)',
  'chart.unsubscribeClick(handleClick)',
  'if (destroyed) return;',
]) {
  if (!source.includes(token)) fail(`missing subscription lifecycle token: ${token}`);
}

if (!projection.includes('projectLightweightChartsV5DrawingAnchor')) {
  fail('P18.25R1 anchor projection owner regressed');
}
if (!interaction.includes('createChartDrawingInteractionPort')) {
  fail('P18.24 neutral interaction session owner regressed');
}
if (!index.includes('createLightweightChartsV5DrawingClickSubscription')) {
  fail('chart feature export for drawing click subscription is missing');
}

for (const token of [
  'subscribes once and emits the P18.25R1 projected drawing anchor',
  'emits null when provider click evidence cannot produce an anchor',
  'delegates every valid click projection to the active provider series price owner',
  'unsubscribes the same handler exactly once and ignores later delivery',
]) {
  if (!test.includes(token)) fail(`runtime test does not pin behavior: ${token}`);
}

for (const forbidden of [
  'subscribeCrosshairMove',
  'unsubscribeCrosshairMove',
  'subscribeDblClick',
  'addEventListener',
  'removeEventListener',
  'PointerEvent',
  'setPointerCapture',
  'reduceChartDrawingInteraction(',
  '.dispatch(',
  'resolveChart(',
  'resolveSeries(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.add(',
  '.delete(',
  'riskReward',
]) {
  if (source.includes(forbidden)) fail(`subscription crossed protected boundary: ${forbidden}`);
}

console.log('P18.26 Lightweight Charts v5 drawing click subscription verification passed.');
