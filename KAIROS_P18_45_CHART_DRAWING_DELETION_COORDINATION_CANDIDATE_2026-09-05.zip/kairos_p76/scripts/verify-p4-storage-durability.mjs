import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('../src/pwa/storageDurability.ts', import.meta.url), 'utf8');
const main = await readFile(new URL('../src/main.tsx', import.meta.url), 'utf8');

const requirements = [
  ['StorageManager persisted status inspection', /storage\.persisted\(\)/],
  ['explicit persistence request command', /export async function requestPersistentStorage[\s\S]*storage\.persist\(\)/],
  ['best-effort state', /['"]best-effort['"]/],
  ['persistent state', /['"]persistent['"]/],
  ['unsupported fallback', /['"]unsupported['"]/],
  ['error fallback', /['"]error['"]/],
  ['subscription boundary', /subscribeStorageDurabilityStatus/],
];
for (const [label, pattern] of requirements) {
  if (!pattern.test(source)) throw new Error(`P4.3 storage durability contract missing ${label}.`);
}

const inspectBody = source.match(/export async function inspectStorageDurability\(\)[\s\S]*?\n}\n\nexport async function requestPersistentStorage/)?.[0] ?? '';
if (/\.persist\(\)/.test(inspectBody)) {
  throw new Error('P4.3 bootstrap inspection must not request persistent storage automatically.');
}
if (!/void inspectStorageDurability\(\);/.test(main)) {
  throw new Error('P4.3 bootstrap must inspect storage durability without prompting for persistence.');
}
if (/indexeddb|dexie|localstorage|sessionstorage|websocket|tradeexecution|trademetrics|marketdata/i.test(source)) {
  throw new Error('P4.3 durability owner must report origin storage durability only; P5 business persistence is out of scope.');
}

console.log('P4.3 storage durability status / explicit persistence-request contract: PASS');
