import fs from 'node:fs';const s=fs.readFileSync('src/data/backup/restorePreflight.ts','utf8');
for(const x of ['parseKairosBackup(serializedIncomingBackup)','assertRestoreCompatibility(incoming)','DUPLICATE_METADATA_KEY','INVALID_TRADE_REFERENCE','createKairosDatabaseSnapshot(db)','const preflight = preflightKairosRestore(serializedIncomingBackup);','const recovery = await createKairosRecoverySnapshot(db);'])if(!s.includes(x))throw new Error(`P6.3 preflight contract missing: ${x}`);
if(/\.(?:delete|clear|bulkPut|put|update)\s*\(/.test(s))throw new Error('P6.3 preflight must not write');
console.log('P6.3 restore preflight/recovery ownership: PASS');
