import fs from 'node:fs';
const fail=m=>{console.error(`FAIL P15.10 Market Data reconnect disposition verifier: ${m}`);process.exit(1)};
const p='src/services/market-data/marketDataReconnectDisposition.ts';
if(!fs.existsSync(p))fail('owner missing');
const s=fs.readFileSync(p,'utf8'), b=fs.readFileSync('src/services/market-data/index.ts','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
for(const t of ['transient-failure','intentional-close','terminal-failure','retry: true','retry: false'])
  if(!s.includes(t))fail(`missing ${t}`);
for(const t of ['WebSocket','CloseEvent','Math.random(','setTimeout(','setInterval(','fetch(','indexedDB','Dexie'])
  if(s.includes(t))fail(`forbidden provider/runtime token ${t}`);
if(!b.includes("export * from './marketDataReconnectDisposition';"))fail('barrel export missing');
if(pkg.scripts?.['verify:p15:10-market-data-reconnect-disposition']!=='node scripts/verify-p15-10-market-data-reconnect-disposition.mjs')fail('package verifier missing');
console.log('PASS P15.10 Market Data reconnect disposition verifier');
