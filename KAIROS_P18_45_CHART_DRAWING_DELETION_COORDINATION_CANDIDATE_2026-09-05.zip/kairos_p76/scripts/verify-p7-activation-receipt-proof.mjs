import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const verifierPath = path.join(root, 'src/services/activation/EcdsaActivationReceiptVerifier.ts');
const indexPath = path.join(root, 'src/services/activation/index.ts');
const testPath = path.join(root, 'tests/activation-receipt-proof.test.ts');

for (const required of [verifierPath, indexPath, testPath]) {
  if (!fs.existsSync(required)) throw new Error(`P7.4 missing required file: ${path.relative(root, required)}`);
}

const verifier = fs.readFileSync(verifierPath, 'utf8');
const index = fs.readFileSync(indexPath, 'utf8');

for (const required of [
  'class EcdsaActivationReceiptVerifier',
  "name: 'ECDSA'",
  "namedCurve: 'P-256'",
  "hash: 'SHA-256'",
  "'spki'",
  "['verify']",
  "KAIROS_ACTIVATION_PROOF_PURPOSE = 'kairos-activation'",
  'proofMatchesReceipt',
  'signature.byteLength !== 64',
]) {
  if (!verifier.includes(required)) throw new Error(`P7.4 verifier contract missing: ${required}`);
}

for (const forbidden of [
  'BEGIN PRIVATE KEY',
  'BEGIN EC PRIVATE KEY',
  '.generateKey(',
  '.sign(',
  "['sign']",
  'privateKeySpki',
]) {
  if (verifier.includes(forbidden)) throw new Error(`P7.4 client verifier contains signing authority marker: ${forbidden}`);
}

if (!index.includes("from './EcdsaActivationReceiptVerifier'")) {
  throw new Error('P7.4 verifier is not exported by the activation boundary.');
}

console.log('PASS: P7.4 activation receipt proof contract is present, public-key-only, domain-separated, and receipt-bound.');
