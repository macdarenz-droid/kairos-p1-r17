import { readFileSync } from 'node:fs';

const source = readFileSync('src/application/journal/visualPnlDailySummaryQuery.ts', 'utf8');
const index = readFileSync('src/application/journal/index.ts', 'utf8');
const tests = readFileSync('tests/journal-visual-pnl-daily-summary-query.test.ts', 'utf8');

const requireText = (haystack, needle, label) => {
  if (!haystack.includes(needle)) throw new Error(`P13.8 missing ${label}: ${needle}`);
};

requireText(source, "status: 'closed' as const", 'closed-trade indexed Journal History selection');
requireText(source, 'listJournalHistory(db, historyOptions)', 'bounded Journal History owner reuse');
requireText(source, 'summarizeVisualPnlByDay(entries, timeZone)', 'P13.7 grouping owner reuse');
requireText(source, 'readonly limit?: number', 'bounded consumer option');
requireText(index, 'listJournalVisualPnlDailySummary', 'Journal public export');
requireText(tests, "{ limit: 2 }", 'bounded-query regression');
requireText(tests, "'Not/A_TimeZone'", 'no implicit timezone fallback regression');

for (const forbidden of [
  'createKairosRepositories',
  'decimalSum',
  'decimalAdd',
  'parseFloat',
  'parseInt',
  'new Intl.DateTimeFormat',
  'resolvedOptions().timeZone',
  'exchangeRate',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P13.8 rejected duplicate owner or hidden behavior: ${forbidden}`);
  }
}

console.log('PASS P13.8 Journal daily Visual P&L query wiring verifier');
