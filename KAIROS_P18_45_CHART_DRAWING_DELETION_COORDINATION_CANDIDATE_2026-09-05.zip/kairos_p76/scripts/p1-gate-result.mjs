export const P1_GATE_EXIT = Object.freeze({
  PASS: 0,
  FAIL: 1,
  HOLD: 2,
});

const INFRASTRUCTURE_PATTERNS = [
  /\bEAI_AGAIN\b/i,
  /\bENOTFOUND\b/i,
  /\bETIMEDOUT\b/i,
  /\bECONNRESET\b/i,
  /\bECONNREFUSED\b/i,
  /\bENETUNREACH\b/i,
  /\bEHOSTUNREACH\b/i,
  /network.*(unavailable|timeout|timed out)/i,
  /getaddrinfo/i,
];

export function classifyInstallFailure(output) {
  const text = String(output ?? '');
  return INFRASTRUCTURE_PATTERNS.some((pattern) => pattern.test(text)) ? 'HOLD' : 'FAIL';
}
