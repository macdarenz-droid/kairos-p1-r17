import fs from 'node:fs';

const fail = (message) => {
  console.error(`FAIL P16.1 Binance Spot trade stream verifier: ${message}`);
  process.exit(1);
};

const owner = 'src/services/market-data/providers/binance/binanceSpotTradeStream.ts';
const index = 'src/services/market-data/index.ts';
const test = 'tests/binance-spot-trade-stream.test.ts';

for (const path of [owner, index, test]) {
  if (!fs.existsSync(path)) fail(`missing ${path}`);
}

const source = fs.readFileSync(owner, 'utf8');
const barrel = fs.readFileSync(index, 'utf8');

for (const token of [
  "BINANCE_SPOT_VENUE = 'binance-spot'",
  "BINANCE_SPOT_INITIAL_SYMBOL = 'BTCUSDT'",
  "BINANCE_SPOT_TRADE_STREAM_SUFFIX = '@trade'",
  'symbol.toLowerCase()',
]) {
  if (!source.includes(token)) fail(`missing semantic token ${token}`);
}

for (const forbidden of [
  'new WebSocket(',
  'fetch(',
  'apiKey',
  'secret',
  'setTimeout(',
  'setInterval(',
  'Math.random(',
  'indexedDB',
  'Dexie',
]) {
  if (source.includes(forbidden)) fail(`forbidden ownership token ${forbidden}`);
}

if (!barrel.includes("export * from './providers/binance/binanceSpotTradeStream';")) {
  fail('provider owner is not exported from market-data barrel');
}

console.log('PASS P16.1 Binance Spot trade stream verifier');
