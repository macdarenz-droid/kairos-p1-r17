import { readFileSync } from 'node:fs';

const source = readFileSync(
  'src/features/chart/lightweightChartsV5TrendLineDraftInteractionComposition.ts',
  'utf8',
);
const providerBinding = readFileSync(
  'src/features/chart/lightweightChartsV5DrawingClickBindingComposition.ts',
  'utf8',
);
const neutralCoordination = readFileSync(
  'src/features/chart/chartTrendLineDraftInteractionCoordination.ts',
  'utf8',
);
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync(
  'tests/lightweight-charts-v5-trend-line-draft-interaction-composition.test.ts',
  'utf8',
);
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.30 trend-line draft interaction composition verification FAIL: ${message}`);
  process.exit(1);
};

for (const required of [
  "binding: Pick<LightweightChartsV5DriverBinding, 'resolveChart' | 'resolveSeries'>",
  'const draftInteraction = createChartTrendLineDraftInteractionPort().create(onStateChange)',
  'createLightweightChartsV5DrawingClickSubscriptionFromBinding(',
  'draftInteraction.acceptAnchor(anchor)',
  'draftInteraction.destroy()',
  'clickSubscription.destroy()',
]) {
  if (!source.includes(required)) fail(`missing composition evidence: ${required}`);
}

for (const required of [
  'createLightweightChartsV5DrawingClickSubscription(clickChart, priceSeries, onAnchor)',
  'binding.resolveChart(handle)',
  'binding.resolveSeries(handle)',
]) {
  if (!providerBinding.includes(required)) fail(`P18.27 provider binding owner regressed: ${required}`);
}

for (const required of [
  'createChartDrawingInteractionPort().create(onStateChange)',
  'createChartTrendLineDraftAnchorCollectionPort().create()',
  "interaction.dispatch({ type: 'start-drawing' })",
  "interaction.dispatch({ type: 'preview-drawing' })",
]) {
  if (!neutralCoordination.includes(required)) fail(`P18.29 coordination owner regressed: ${required}`);
}

if (!index.includes('createLightweightChartsV5TrendLineDraftInteractionFromBinding')) {
  fail('chart feature export for P18.30 composition is missing');
}

if (
  packageJson.scripts?.['verify:p18:30-lightweight-charts-v5-trend-line-draft-interaction-composition'] !==
  'node scripts/verify-p18-30-lightweight-charts-v5-trend-line-draft-interaction-composition.mjs'
) {
  fail('P18.30 package verifier script missing');
}

for (const token of [
  'routes provider click anchors into the existing P18.29 draft interaction session',
  'keeps provider null-anchor evidence a no-op through the existing owners',
  'preserves P18.29 cancel/reset lifecycle behavior while provider click delivery remains attached',
  'fails closed on provider capability setup and detaches clicks before neutral session destruction',
]) {
  if (!test.includes(token)) fail(`runtime test does not pin behavior: ${token}`);
}

for (const forbidden of [
  'subscribeClick(',
  'unsubscribeClick(',
  'coordinateToPrice(',
  'projectLightweightChartsV5DrawingAnchor(',
  'reduceChartDrawingInteraction(',
  'let currentState',
  'let draft',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.delete(',
  'riskReward',
]) {
  if (source.includes(forbidden)) fail(`composition crossed protected boundary: ${forbidden}`);
}

console.log('P18.30 Lightweight Charts v5 trend-line draft interaction composition verification passed.');
