import { readFile, readdir } from 'node:fs/promises';
import { extname, relative } from 'node:path';
const root = new URL('../', import.meta.url);
const requiredSemanticRoles = [
  'background-base','background-depth','background-overlay','surface-card','surface-raised','surface-input','surface-modal',
  'border-default','border-subtle','border-active','text-primary','text-secondary','text-muted','text-disabled',
  'accent-primary','accent-secondary','accent-soft','accent-glow','trade-profit','trade-loss','trade-flat','trade-long','trade-short','trade-entry','trade-stop','trade-target','trade-risk-zone','trade-reward-zone',
  'chart-background','chart-grid','chart-axis','chart-crosshair','chart-candle-up','chart-candle-down','chart-wick-up','chart-wick-down','chart-volume-up','chart-volume-down','chart-drawing-primary','chart-drawing-secondary','chart-support','chart-resistance',
  'state-success','state-warning','state-error','state-info','state-focus','state-hover','state-pressed','state-disabled','glow-none','glow-subtle','glow-active','glow-emphasis'
];
const semantic = await readFile(new URL('../src/design-system/tokens/semantic.ts', import.meta.url), 'utf8');
for (const role of requiredSemanticRoles) if (!semantic.includes(`role('${role}')`)) throw new Error(`Missing semantic role ${role}`);
const tokenCss = await readFile(new URL('../src/design-system/tokens.css', import.meta.url), 'utf8');
if (/#[0-9a-f]{3,8}\b|\brgb\(|\bhsl\(/i.test(tokenCss)) throw new Error('P2.1 geometry token CSS must not introduce theme colors.');
if (/--kairos-(background|surface|border|text|accent|trade|chart|state|glow)-/.test(tokenCss)) throw new Error('P2.1 must not assign semantic theme values before P3.');
async function walk(url){const out=[]; for(const e of await readdir(url,{withFileTypes:true})){const c=new URL(`${e.name}${e.isDirectory()?'/':''}`,url); e.isDirectory()?out.push(...await walk(c)):out.push(c)} return out}
for(const f of await walk(new URL('../src/', import.meta.url))){
  if(!['.ts','.tsx','.css'].includes(extname(f.pathname))) continue;
  if(f.pathname.includes('/design-system/')) continue;
  const text=await readFile(f,'utf8');
  if (/#[0-9a-f]{3,8}\b|\brgb\(|\bhsl\(|\b(?:padding|margin|gap|border-radius|min-height|height)\s*:\s*\d+(?:\.\d+)?(?:px|rem)\b/i.test(text)) throw new Error(`Unregistered design primitive outside design system: ${relative(root.pathname,f.pathname)}`);
}
console.log('P2.1 design-system contract: PASS');
