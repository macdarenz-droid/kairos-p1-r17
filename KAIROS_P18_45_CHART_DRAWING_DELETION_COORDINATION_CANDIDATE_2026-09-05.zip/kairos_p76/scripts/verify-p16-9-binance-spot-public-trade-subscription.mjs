import { readFileSync } from 'node:fs';
const source = readFileSync('src/services/market-data/providers/binance/binanceSpotPublicTradeSubscription.ts','utf8');
const barrel = readFileSync('src/services/market-data/index.ts','utf8');
for (const token of ['subscribeBinanceSpotPublicTradeStream','describeBinanceSpotTradeStream','describeBinanceSpotPublicRawStreamEndpoint','openBinanceSpotPublicRawStreamConnection','deliverBinanceSpotPublicStreamTradeMessage','receiptTimestamp']) {
  if (!source.includes(token)) throw new Error(`P16.9 missing ${token}`);
}
for (const token of ['Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'Math.random(', 'indexedDB', 'Dexie', 'apiKey', 'secret', 'onStateChange?.']) {
  if (source.includes(token)) throw new Error(`P16.9 forbidden ownership token ${token}`);
}
if (!barrel.includes("./providers/binance/binanceSpotPublicTradeSubscription")) throw new Error('P16.9 barrel export missing');
console.log('PASS P16.9 Binance Spot public trade subscription verifier');
