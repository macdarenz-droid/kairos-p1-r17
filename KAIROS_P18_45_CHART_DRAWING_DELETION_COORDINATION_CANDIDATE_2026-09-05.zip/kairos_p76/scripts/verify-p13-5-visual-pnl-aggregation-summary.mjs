import { readFileSync } from 'node:fs';

const source = readFileSync('src/application/visual-pnl/aggregationSummary.ts', 'utf8');
const index = readFileSync('src/application/visual-pnl/index.ts', 'utf8');
const tests = readFileSync('tests/visual-pnl-aggregation-summary.test.ts', 'utf8');

const requireText = (haystack, needle, label) => {
  if (!haystack.includes(needle)) throw new Error(`P13.5 verifier missing ${label}: ${needle}`);
};

requireText(source, "assessVisualPnlAggregationEligibility(projections)", 'P13.4R1 eligibility gate reuse');
requireText(source, "decimalSum(eligibility.amounts)", 'Calculation Engine decimalSum ownership');
requireText(source, "available: false", 'explicit unavailable aggregate');
requireText(source, "reason: eligibility.reason", 'blocked reason propagation');
requireText(source, "tradeCount: projections.length", 'trade count evidence');
requireText(index, "export * from './aggregationSummary';", 'public export');
requireText(tests, "reason: 'mixed-currencies'", 'mixed-currency regression');
requireText(tests, "total: '7.15'", 'exact decimal addition regression');

for (const forbidden of ['Number(', 'parseFloat(', 'parseInt(', 'new Decimal(', "from 'decimal.js'", 'exchangeRate']) {
  if (source.includes(forbidden)) throw new Error(`P13.5 verifier rejected forbidden application arithmetic/inference token: ${forbidden}`);
}

console.log('PASS P13.5 Visual P&L aggregation summary verifier');
