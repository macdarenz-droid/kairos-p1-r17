import fs from 'node:fs';

const canaryPath = new URL('../src/design-system/themes/themeCanary.ts', import.meta.url);
const source = fs.readFileSync(canaryPath, 'utf8');
const requiredSurfaces = ['card','button','input','tabs','profit','loss','chart','modal','warning','disabled','selected','focus','loading'];
const requiredMarkers = ['evaluateThemeCanary', 'evaluateActiveThemeMatrix', 'themeCanaryTokenContract'];
const forbidden = ['--kairos-spacing-', '--kairos-radius-', '--kairos-motion-'];
const missing = [...requiredSurfaces, ...requiredMarkers].filter((marker) => !source.includes(marker));
if (missing.length) {
  console.error(`P3.3 theme canary contract: FAIL — missing ${missing.join(', ')}`);
  process.exit(1);
}
const contractSection = source.slice(source.indexOf('themeCanaryTokenContract'), source.indexOf('const forbiddenGeometryPrefixes'));
const geometryLeak = forbidden.filter((marker) => contractSection.includes(marker));
if (geometryLeak.length) {
  console.error(`P3.3 theme canary contract: FAIL — geometry leaked into canary contract: ${geometryLeak.join(', ')}`);
  process.exit(1);
}
console.log('P3.3 active theme canary contract: PASS');
