import fs from 'node:fs';

const read = (path) => fs.readFileSync(path, 'utf8');
const fail = (message) => {
  console.error(`P18.25R1 drawing anchor P1 scope compatibility repair verification FAIL: ${message}`);
  process.exit(1);
};

const source = read('src/features/chart/lightweightChartsV5DrawingAnchorProjection.ts');
const index = read('src/features/chart/index.ts');
const contract = read('src/features/chart/chartDrawingContract.ts');
const interaction = read('src/features/chart/chartDrawingInteractionPort.ts');
const p1Static = read('scripts/verify-p1-static.mjs');
const test = read('tests/lightweight-charts-v5-drawing-anchor-projection.test.ts');

for (const token of [
  'LightweightChartsV5DrawingAnchorPoint',
  'LightweightChartsV5DrawingAnchorEvent',
  'LightweightChartsV5DrawingAnchorPriceApi',
  'coordinateToPrice(coordinate: number): number | null',
  'projectLightweightChartsV5DrawingAnchor',
  'event.time === undefined',
  'event.point === undefined',
  'series.coordinateToPrice(event.point.y)',
  'providerNumberToPlainDecimal',
  'parseDecimalString(normalized)',
]) {
  if (!source.includes(token)) fail(`missing repaired projection token: ${token}`);
}

if (source.includes("from 'decimal.js'")) fail('chart feature still imports calculation dependency directly');
if (!p1Static.includes('forbiddenBusinessTerms')) fail('historical P1 static scope guard unavailable');
if (!contract.includes('ChartDrawingAnchor')) fail('P18.1 drawing anchor contract regressed');
if (!interaction.includes('createChartDrawingInteractionPort')) fail('P18.24 interaction port regressed');
if (!index.includes("from './lightweightChartsV5DrawingAnchorProjection'")) fail('chart feature export missing');

for (const token of [
  'projects provider event time and y-coordinate price',
  'coordinateToPrice',
  "price: '0.0000001'",
  "price: '1000000000000000000000'",
  'fails closed when provider event time, point, or price is unavailable',
]) {
  if (!test.includes(token)) fail(`runtime test does not pin repaired behavior: ${token}`);
}

for (const forbidden of [
  'subscribeClick',
  'unsubscribeClick',
  'subscribeCrosshairMove',
  'unsubscribeCrosshairMove',
  'addEventListener',
  'removeEventListener',
  'PointerEvent',
  'setPointerCapture',
  'reduceChartDrawingInteraction(',
  '.dispatch(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.add(',
  '.delete(',
  'riskReward',
]) {
  if (source.includes(forbidden)) fail(`projection crossed protected boundary: ${forbidden}`);
}

console.log('P18.25R1 drawing anchor P1 scope compatibility repair verification passed.');
