import fs from 'node:fs';
const required = [
  'src/domain/trades/tradeTypes.ts',
  'src/domain/trades/tradeIdentity.ts',
  'src/domain/trades/tradeValidation.ts',
  'src/domain/trades/index.ts',
  'tests/trade-domain.test.ts',
];
for (const file of required) {
  if (!fs.existsSync(file)) throw new Error(`Missing P9.1 file: ${file}`);
}
const types = fs.readFileSync('src/domain/trades/tradeTypes.ts','utf8');
for (const token of ['TradeRecord','TradePlanRecord','TradeExecutionRecord','TradeFeeRecord','DecimalString','entry','exit']) {
  if (!types.includes(token)) throw new Error(`Missing P9.1 domain token: ${token}`);
}
const all = required.map((f) => fs.readFileSync(f,'utf8')).join('\n').toLowerCase();
for (const forbidden of ['profitloss','r-multiple','rmultiple','averageentry','positionsize','leveragecalculation']) {
  if (all.includes(forbidden)) throw new Error(`P11 calculation leaked into P9.1: ${forbidden}`);
}
console.log('P9.1 trade domain static contract: PASS');
