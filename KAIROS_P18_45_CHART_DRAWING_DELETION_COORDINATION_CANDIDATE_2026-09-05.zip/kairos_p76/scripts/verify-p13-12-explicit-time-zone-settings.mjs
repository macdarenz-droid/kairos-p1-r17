import { readFileSync } from 'node:fs';
const settings=readFileSync('src/app/SettingsRoute.tsx','utf8');
const routes=readFileSync('src/app/routes.tsx','utf8');
const css=readFileSync('src/app/settingsRoute.css','utf8');
const need=(text,value,label)=>{if(!text.includes(value))throw new Error(`P13.12 missing ${label}: ${value}`)};
need(routes,"{ path: 'settings', element: <SettingsRoute /> }",'real Settings route');
need(settings,'readVisualPnlTimeZonePreference(repositories.metadata)','P13.10R1 read owner');
need(settings,'writeVisualPnlTimeZonePreference(','P13.10R1 write owner');
need(settings,"new Date().toISOString()",'write evidence timestamp');
need(settings,'Kairos will not guess this setting from your device.','explicit policy copy');
need(settings,'Use an IANA time zone','plain format guidance');
need(settings,'Not configured','unconfigured state');
for(const forbidden of ['resolvedOptions().timeZone','getTimezoneOffset','navigator.language','localStorage','sessionStorage','indexedDB.']){
 if(settings.includes(forbidden))throw new Error(`P13.12 forbidden inferred/direct owner: ${forbidden}`);
}
if(!css.includes('var(--kairos-accent-primary)')||!css.includes('@media (max-width:34rem)')) throw new Error('P13.12 semantic/mobile styling contract missing');
console.log('PASS P13.12 explicit timezone Settings verifier');
