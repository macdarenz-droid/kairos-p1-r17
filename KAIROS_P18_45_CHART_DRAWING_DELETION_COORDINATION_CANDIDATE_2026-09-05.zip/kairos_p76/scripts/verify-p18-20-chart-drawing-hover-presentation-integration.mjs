import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/features/chart/chartDrawingPresentationPort.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/features/chart/index.ts', import.meta.url), 'utf8');

for (const required of [
  'ChartDrawingPresentationHoverBinding',
  'activeHover: ChartDrawingHoverSession | null',
  'activeHover.destroy()',
  'hover.port.attach(nextSeries, drawings, hover.onHover)',
  'nextHover.destroy()',
  'activeHover = nextHover',
]) {
  if (!source.includes(required)) throw new Error(`p18.20-missing:${required}`);
}

const hoverDestroy = source.indexOf('activeHover.destroy()');
const drawingDestroy = source.indexOf('activeDrawingLayer.destroy()');
const seriesRemove = source.indexOf('chart.removeSeries(activeSeries)');
if (!(hoverDestroy >= 0 && hoverDestroy < drawingDestroy && drawingDestroy < seriesRemove)) {
  throw new Error('p18.20-resource-order-must-be-hover-drawing-series');
}

if (!index.includes('type ChartDrawingPresentationHoverBinding')) {
  throw new Error('p18.20-index-export-missing');
}

for (const forbidden of ['subscribeCrosshairMove', 'unsubscribeCrosshairMove', 'hoveredObjectId', 'IndexedDB', 'localStorage', 'riskReward']) {
  if (source.includes(forbidden)) throw new Error(`p18.20-forbidden-scope:${forbidden}`);
}

console.log('P18.20 chart drawing hover presentation integration verifier: PASS');
