import fs from 'node:fs';

const files = [
  'src/domain/calculations/executionBalance.ts',
  'tests/execution-balance.test.ts',
];
for (const file of files) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const source = fs.readFileSync('src/domain/calculations/executionBalance.ts', 'utf8');

for (const token of [
  'aggregateTradeExecutions',
  "'empty'",
  "'open'",
  "'partially-exited'",
  "'flat'",
  "'exit-without-entry'",
  "'over-exited'",
]) {
  if (!source.includes(token)) throw new Error(`Missing P11.3 balance contract: ${token}`);
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error('P11.3 execution balance must not use native numeric arithmetic/coercion.');
}

for (const forbidden of [
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
  'profit',
  'loss',
  'rMultiple',
  'leverage',
  'fee',
  'currency',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.3 out-of-scope owner/metric detected: ${forbidden}`);
  }
}

console.log('P11.3 execution balance verification PASS');
