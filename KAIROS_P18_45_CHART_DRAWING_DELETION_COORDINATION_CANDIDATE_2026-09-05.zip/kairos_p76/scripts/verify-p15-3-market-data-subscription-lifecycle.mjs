import { readFileSync } from 'node:fs';

const lifecycle = readFileSync('src/services/market-data/marketDataSubscriptionLifecycle.ts', 'utf8');
const index = readFileSync('src/services/market-data/index.ts', 'utf8');
const adapter = readFileSync('src/services/market-data/MarketDataAdapter.ts', 'utf8');

const checks = [
  ['lifecycle binder exists', lifecycle.includes('bindMarketDataSubscriptionLifecycle')],
  ['uses AbortSignal', lifecycle.includes('AbortSignal')],
  ['handles already-aborted signal', lifecycle.includes('signal?.aborted')],
  ['binds abort event', lifecycle.includes("addEventListener('abort'")],
  ['removes abort listener on close', lifecycle.includes("removeEventListener('abort'")],
  ['idempotent close guard', lifecycle.includes('if (closed) return')],
  ['delegates underlying close', lifecycle.includes('subscription.close()')],
  ['barrel exports lifecycle', index.includes("export * from './marketDataSubscriptionLifecycle';")],
  ['P15.1 adapter signal contract preserved', adapter.includes('readonly signal?: AbortSignal')],
];

const forbidden = [
  'new WebSocket(',
  'new EventSource(',
  'fetch(',
  'setInterval(',
  'setTimeout(',
  'indexedDB',
  'Dexie',
  'JournalTradeMap',
  'projectJournalTradeVisualizer',
];
for (const token of forbidden) checks.push([`forbidden token absent: ${token}`, !lifecycle.includes(token)]);

const failed = checks.filter(([, ok]) => !ok);
if (failed.length) {
  for (const [name] of failed) console.error(`FAIL ${name}`);
  process.exit(1);
}
console.log('PASS P15.3 Market Data subscription lifecycle verifier');
