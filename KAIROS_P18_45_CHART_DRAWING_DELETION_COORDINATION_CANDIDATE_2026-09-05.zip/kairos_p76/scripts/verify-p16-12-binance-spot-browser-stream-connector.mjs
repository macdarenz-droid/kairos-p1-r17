import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('../src/services/market-data/providers/binance/binanceSpotBrowserStreamConnector.ts', import.meta.url), 'utf8');
const index = await readFile(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const policy = await readFile(new URL('./p1-source-scope-policy.mjs', import.meta.url), 'utf8');

const required = [
  'new WebSocket(url)',
  "addEventListener('open'",
  "addEventListener('message'",
  'handlers.onMessage(event.data)',
  "addEventListener('error'",
  "addEventListener('close'",
  'closeRequested',
  'socket.close()',
];
for (const token of required) {
  if (!source.includes(token)) throw new Error(`P16.12 missing browser connector contract token: ${token}`);
}
for (const forbidden of ['setTimeout', 'setInterval', 'indexedDB', 'localStorage', 'sessionStorage', 'fetch(', 'AbortController', 'Math.random', 'Date.now']) {
  if (source.includes(forbidden)) throw new Error(`P16.12 browser connector owns forbidden behavior: ${forbidden}`);
}
if (!index.includes("export * from './providers/binance/binanceSpotBrowserStreamConnector';")) {
  throw new Error('P16.12 browser connector must be exported by the market-data barrel.');
}
if (!policy.includes("'src/services/market-data/providers/binance/binanceSpotBrowserStreamConnector.ts'")) {
  throw new Error('P16.12 concrete connector path must remain the exact P16.11 approved owner.');
}
console.log('P16.12 Binance Spot browser stream connector contract: PASS');
