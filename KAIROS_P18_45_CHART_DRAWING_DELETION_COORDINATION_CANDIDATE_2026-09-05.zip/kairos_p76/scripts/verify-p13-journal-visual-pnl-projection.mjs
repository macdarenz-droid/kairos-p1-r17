import { readFileSync } from 'node:fs';

const history = readFileSync('src/application/journal/historyQuery.ts', 'utf8');
const projection = readFileSync('src/application/visual-pnl/outcomeProjection.ts', 'utf8');
const tests = readFileSync('tests/journal-visual-pnl-projection.test.ts', 'utf8');

const requiredHistory = [
  "projectVisualPnlOutcome, type VisualPnlOutcomeProjection",
  'readonly visualPnl: VisualPnlOutcomeProjection;',
  'visualPnl: projectVisualPnlOutcome(metricsResult.ok ? metricsResult.value : null)',
];
for (const token of requiredHistory) {
  if (!history.includes(token)) throw new Error(`P13.2 journal projection wiring missing: ${token}`);
}
if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(/.test(projection)) throw new Error('P13 Visual P&L projection must not introduce binary-number financial interpretation.');
if (!tests.includes("outcome: 'unavailable'")) throw new Error('P13.2 must test unavailable semantics for incomparable currency evidence.');
if (!tests.includes("metricsError).toBe('exit-without-entry')")) throw new Error('P13.2 must preserve journal calculation-error visibility.');
console.log('P13.2 journal Visual P&L projection verifier PASS');
