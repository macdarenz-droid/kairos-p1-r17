import fs from 'node:fs';

const files = [
  'src/domain/calculations/marketSpecificCalculationPolicy.ts',
  'tests/market-specific-calculation-policy.test.ts',
];

for (const file of files) {
  if (!fs.existsSync(file)) {
    throw new Error(`Missing ${file}`);
  }
}

const source = fs.readFileSync(
  'src/domain/calculations/marketSpecificCalculationPolicy.ts',
  'utf8',
);

for (const token of [
  'MarketSpecificCalculationPolicy',
  'MarketCalculationCapability',
  'resolveMarketSpecificCalculationPolicy',
  "'policy-unavailable'",
  "'ambiguous-policy'",
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P11.9 policy boundary contract: ${token}`);
  }
}

for (const forbidden of [
  'decimalAdd',
  'decimalSubtract',
  'decimalMultiply',
  'decimalDivide',
  'decimalAbs',
  'Number(',
  'parseFloat(',
  'parseInt(',
  'Math.',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
  'exchangeRate',
  'TradeExecutionRecord',
  'TradeFeeRecord',
  'TradePlanRecord',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.9 out-of-scope implementation detected: ${forbidden}`);
  }
}

console.log('P11.9 market-specific calculation policy boundary verification PASS');
