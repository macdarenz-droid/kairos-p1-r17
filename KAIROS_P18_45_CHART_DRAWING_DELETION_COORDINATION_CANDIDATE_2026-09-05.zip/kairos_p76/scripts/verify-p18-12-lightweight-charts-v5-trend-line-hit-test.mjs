import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/features/chart/lightweightChartsV5TrendLineHitTest.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/features/chart/index.ts', import.meta.url), 'utf8');
const test = readFileSync(new URL('../tests/lightweight-charts-v5-trend-line-hit-test.test.ts', import.meta.url), 'utf8');
for (const token of ['squaredDistanceToSegment','tolerancePx','chart-drawing-hit-test-invalid-input','cursorStyle']) if (!source.includes(token)) throw new Error('missing '+token);
if (!index.includes('hitTestLightweightChartsV5TrendLineSegments')) throw new Error('missing index export');
for (const token of ['within the supplied presentation tolerance','top-most/latest segment','invalid geometry inputs']) if (!test.includes(token)) throw new Error('missing test '+token);
console.log('P18.12 trend-line hit-test geometry verifier: PASS');
