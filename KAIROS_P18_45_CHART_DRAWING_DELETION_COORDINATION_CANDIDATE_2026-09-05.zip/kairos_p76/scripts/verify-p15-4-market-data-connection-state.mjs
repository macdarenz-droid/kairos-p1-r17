import { readFileSync } from 'node:fs';

const owner = readFileSync('src/services/market-data/marketDataConnectionState.ts', 'utf8');
const types = readFileSync('src/services/market-data/marketDataTypes.ts', 'utf8');
const index = readFileSync('src/services/market-data/index.ts', 'utf8');

const checks = [
  ['state owner exists', owner.includes('transitionMarketDataConnectionState')],
  ['connect-requested event explicit', owner.includes("'connect-requested'")],
  ['connected event explicit', owner.includes("'connected'")],
  ['disconnected event explicit', owner.includes("'disconnected'")],
  ['failed event explicit', owner.includes("'failed'")],
  ['reset event explicit', owner.includes("'reset'")],
  ['invalid transitions explicit', owner.includes('accepted: false')],
  ['existing five states preserved', ['idle','connecting','live','disconnected','error'].every((s) => types.includes(`'${s}'`))],
  ['barrel exports state owner', index.includes("export * from './marketDataConnectionState';")],
];

for (const token of [
  'new WebSocket(',
  'new EventSource(',
  'fetch(',
  'setInterval(',
  'setTimeout(',
  'Date.now(',
  'indexedDB',
  'Dexie',
  'JournalTradeMap',
  'projectJournalTradeVisualizer',
]) {
  checks.push([`forbidden token absent: ${token}`, !owner.includes(token)]);
}

const failed = checks.filter(([, ok]) => !ok);
if (failed.length) {
  for (const [name] of failed) console.error(`FAIL ${name}`);
  process.exit(1);
}
console.log('PASS P15.4 Market Data connection-state semantics verifier');
