import { readFileSync } from 'node:fs';
const source = readFileSync('src/application/trade-visualizer/tradeVisualizerFacts.ts', 'utf8');
const test = readFileSync('tests/trade-visualizer-facts.test.ts', 'utf8');

for (const required of ['plannedEntryPrice','plannedStopPrice','plannedTargetPrice',"execution.type === 'exit'",'executedExits']) {
  if (!source.includes(required)) throw new Error(`missing production contract: ${required}`);
}
for (const forbidden of ['Number(','parseFloat(','parseInt(','decimalAdd','calculateTradeMetrics','indexedDB','Dexie','fetch(','WebSocket','exchangeRate']) {
  if (source.includes(forbidden)) throw new Error(`ownership violation: ${forbidden}`);
}
for (const required of ['createTradeDomainId<TradeExecutionId>()','satisfies readonly TradeExecutionRecord[]']) {
  if (!test.includes(required)) throw new Error(`fixture repair missing: ${required}`);
}
if (test.includes("as readonly TradeExecutionRecord[]")) throw new Error('unsafe branded execution fixture cast remains');

console.log('PASS P14.1R1 trade visualizer branded-ID fixture contract verifier');
