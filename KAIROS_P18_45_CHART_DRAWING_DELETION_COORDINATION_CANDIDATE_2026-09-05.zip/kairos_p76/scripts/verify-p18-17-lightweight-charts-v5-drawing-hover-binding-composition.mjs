import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/lightweightChartsV5DrawingHoverBindingComposition.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));

for (const required of [
  "binding: Pick<LightweightChartsV5DriverBinding, 'resolveChart'>",
  'const providerChart = binding.resolveChart(handle)',
  'requireDrawingHoverChartApi(providerChart)',
  'createLightweightChartsV5DrawingHoverSubscription(hoverChart, drawings, onHover)',
  "throw new Error('chart-drawing-hover-capability-unavailable')",
]) {
  if (!source.includes(required)) throw new Error(`P18.17 missing hover-binding composition evidence: ${required}`);
}

for (const forbidden of [
  'subscribeClick(',
  'unsubscribeClick(',
  'attachPrimitive(',
  'detachPrimitive(',
  'hitTest(',
  'localStorage',
  'IndexedDB',
  'Dexie',
  'fetch(',
  'WebSocket',
  'risk-reward',
]) {
  if (source.includes(forbidden)) throw new Error(`P18.17 crossed controlled scope: ${forbidden}`);
}

if (!index.includes('createLightweightChartsV5DrawingHoverSubscriptionFromBinding')) {
  throw new Error('P18.17 chart index export missing');
}

if (
  packageJson.scripts?.['verify:p18:17-lightweight-charts-v5-drawing-hover-binding-composition'] !==
  'node scripts/verify-p18-17-lightweight-charts-v5-drawing-hover-binding-composition.mjs'
) {
  throw new Error('P18.17 package verifier script missing');
}

console.log('P18.17 Lightweight Charts v5 drawing hover binding composition verification passed.');
