import { readFileSync, existsSync } from 'node:fs';

const requiredFiles = [
  'src/services/market-data/providers/binance/binanceSpotTradeStream.ts',
  'src/services/market-data/providers/binance/binanceSpotTradeObservation.ts',
  'src/services/market-data/providers/binance/binanceSpotPublicStreamEndpoint.ts',
  'src/services/market-data/providers/binance/binanceSpotPublicStreamConnection.ts',
  'src/services/market-data/providers/binance/binanceSpotPublicStreamMessageDecode.ts',
  'src/services/market-data/providers/binance/binanceSpotPublicStreamEvent.ts',
  'src/services/market-data/providers/binance/binanceSpotPublicStreamTradeMessage.ts',
  'src/services/market-data/providers/binance/binanceSpotPublicStreamTradeDelivery.ts',
  'src/services/market-data/providers/binance/binanceSpotPublicTradeSubscription.ts',
  'src/services/market-data/providers/binance/binanceSpotBrowserStreamConnector.ts',
  'src/services/market-data/providers/binance/binanceSpotPublicStreamLifecycleConnector.ts',
  'src/services/market-data/providers/binance/binanceSpotServerShutdownReconnectCause.ts',
  'src/services/market-data/providers/binance/binanceSpotServerShutdownReconnectExecution.ts',
  'src/services/market-data/providers/binance/binanceSpotBrowserPublicTradeSubscription.ts',
  'src/services/market-data/providers/binance/binanceSpotBrowserPublicTradeReconnectSubscription.ts',
  'src/application/market-reference/executionMarketReferenceTruth.ts',
];

for (const file of requiredFiles) {
  if (!existsSync(file)) throw new Error(`Missing P16 closure owner: ${file}`);
}

const pkg = JSON.parse(readFileSync('package.json', 'utf8'));
const requiredScripts = [
  'verify:p15:14-market-data-adapter-system-closure',
  'verify:p16:1-binance-spot-trade-stream',
  'verify:p16:2-binance-spot-trade-observation',
  'verify:p16:3-binance-spot-public-stream-endpoint',
  'verify:p16:4-binance-spot-public-stream-connection',
  'verify:p16:5-binance-spot-public-stream-message-decode',
  'verify:p16:6-binance-spot-public-stream-event',
  'verify:p16:7-binance-spot-public-stream-trade-message',
  'verify:p16:8-binance-spot-public-stream-trade-delivery',
  'verify:p16:9-binance-spot-public-trade-subscription',
  'verify:p16:10-execution-market-reference-truth',
  'verify:p16:11-p1-browser-transport-compatibility',
  'verify:p16:12-binance-spot-browser-stream-connector',
  'verify:p16:13-binance-spot-public-stream-lifecycle-connector',
  'verify:p16:14-binance-spot-server-shutdown-reconnect-cause',
  'verify:p16:15-binance-spot-server-shutdown-reconnect-execution',
  'verify:p16:16-binance-spot-browser-public-trade-subscription',
  'verify:p16:17-binance-spot-browser-public-trade-reconnect-subscription',
];
for (const name of requiredScripts) {
  if (!pkg.scripts?.[name]) throw new Error(`Missing required verifier: ${name}`);
}

const reconnect = readFileSync(
  'src/services/market-data/providers/binance/binanceSpotBrowserPublicTradeReconnectSubscription.ts',
  'utf8',
);
for (const required of [
  'executeBinanceSpotServerShutdownReconnect',
  'withBinanceSpotPublicStreamLifecycle',
  'connectBinanceSpotBrowserStream',
  'subscribeBinanceSpotPublicTradeStream',
]) {
  if (!reconnect.includes(required)) throw new Error(`Missing P16 composition owner: ${required}`);
}
for (const forbidden of [
  'localStorage',
  'indexedDB',
  'Math.random',
  'setTimeout(',
  'setInterval(',
  'createChart',
  'lightweight-charts',
  'placeOrder',
  'apiKey',
  'secret',
]) {
  if (reconnect.includes(forbidden)) throw new Error(`P16 closure boundary violation: ${forbidden}`);
}

const truth = readFileSync(
  'src/application/market-reference/executionMarketReferenceTruth.ts',
  'utf8',
);
for (const required of ['journal', 'market']) {
  if (!truth.toLowerCase().includes(required)) {
    throw new Error(`Execution/market-reference truth boundary missing term: ${required}`);
  }
}

console.log('P16.18 crypto live feed system closure verifier PASS');
