import { readFileSync } from 'node:fs';
const repository=readFileSync('src/data/repositories/TradeRepositories.ts','utf8');
const query=readFileSync('src/application/journal/historyQuery.ts','utf8');
const tests=readFileSync('tests/journal-history-query.test.ts','utf8');
const checks=[
 [repository.includes("orderBy('updatedAt').reverse().limit(limit).toArray()"),'repository uses indexed updatedAt descending limit'],
 [query.includes('DEFAULT_JOURNAL_HISTORY_LIMIT = 100'),'bounded default exists'],
 [query.includes('MAX_JOURNAL_HISTORY_LIMIT = 500'),'hard maximum exists'],
 [query.includes('listRecentByUpdatedAt(normalizeHistoryLimit(options.limit))'),'query delegates bounded selection'],
 [!query.includes('repositories.trades.listAll()'),'history does not load all trades'],
 [!query.includes('entries.sort('),'history does not full-sort in application memory'],
 [tests.includes('{ limit: 2 }'),'bounded regression exists'],
 [tests.includes('limit: 501'),'maximum guard regression exists'],
];
for(const [ok,msg] of checks){if(!ok){console.error(`P12.2 verification FAIL: ${msg}`);process.exit(1)}}
console.log('P12.2 indexed bounded journal history verification PASS');
