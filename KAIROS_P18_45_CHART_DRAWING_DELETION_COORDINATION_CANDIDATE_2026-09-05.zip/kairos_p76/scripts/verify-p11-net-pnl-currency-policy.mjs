import fs from 'node:fs';

const sourceFile = 'src/domain/calculations/netPnlCurrencyPolicy.ts';
const testFile = 'tests/net-pnl-currency-policy.test.ts';
const indexFile = 'src/domain/calculations/index.ts';
for (const file of [sourceFile, testFile, indexFile]) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const source = fs.readFileSync(sourceFile, 'utf8');
for (const token of [
  'assessNetPnlCurrencyCompatibility',
  "'zero-fees'",
  "'same-currency'",
  "'missing-gross-pnl-currency'",
  "'missing-fee-currency'",
  "'currency-mismatch'",
  'decimalSubtract',
]) {
  if (!source.includes(token)) throw new Error(`Missing P11.19 contract: ${token}`);
}
if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error('P11.19 must not introduce native numeric authority.');
}
for (const forbidden of ['exchangeRate', 'currencyConversion', 'fetch(', 'WebSocket', 'Dexie', 'indexedDB', 'calculateTradeMetrics(', 'calculateNetPnl(']) {
  if (source.includes(forbidden)) throw new Error(`P11.19 out-of-scope owner detected: ${forbidden}`);
}
const index = fs.readFileSync(indexFile, 'utf8');
if (!index.includes("export * from './netPnlCurrencyPolicy';")) {
  throw new Error('P11.19 policy must be exported through Calculation Engine index.');
}
console.log('P11.19 Net P&L currency comparability policy verification PASS');
