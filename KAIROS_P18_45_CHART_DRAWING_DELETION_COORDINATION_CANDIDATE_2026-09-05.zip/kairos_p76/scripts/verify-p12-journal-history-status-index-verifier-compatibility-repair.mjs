import { readFile } from 'node:fs/promises';
const read = (p) => readFile(new URL(`../${p}`, import.meta.url), 'utf8');
const [schema,p5,p9,migrations] = await Promise.all([
  read('src/data/database/schema.ts'),
  read('scripts/verify-p5-database-kernel.mjs'),
  read('scripts/verify-p9-trade-persistence.mjs'),
  read('src/data/database/migrations.ts'),
]);
const checks = [
  [schema.includes('KAIROS_DB_SCHEMA_VERSION = 3 as const'), 'current schema must be v3'],
  [schema.includes("trades: '&id,status,symbol,updatedAt'"), 'released V2 trade schema history must remain present'],
  [schema.includes("trades: '&id,status,symbol,updatedAt,[status+updatedAt]'"), 'current V3 compound index must remain present'],
  [p5.includes('Current V3 status+updatedAt index is missing.'), 'P5 verifier must validate current V3 while preserving historical schema checks'],
  [p9.includes('Current schema must be v3 after the P12 index-only migration'), 'P9 verifier must allow current V3'],
  [p9.includes('V3 must append to immutable V1/V2 history'), 'P9 verifier must require append-only migration history'],
  [migrations.includes('KAIROS_V1_MIGRATION') && migrations.includes('KAIROS_V2_MIGRATION') && migrations.includes('KAIROS_V3_MIGRATION'), 'V1/V2/V3 migrations must all be registered'],
];
for (const [ok,message] of checks) if (!ok) throw new Error(message);
console.log('P12.4R3 historical verifier compatibility repair: PASS');
