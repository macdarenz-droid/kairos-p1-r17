import { readFileSync } from 'node:fs';

const source = readFileSync('src/application/visual-pnl/dailyStreak.ts', 'utf8');
const index = readFileSync('src/application/visual-pnl/index.ts', 'utf8');
const tests = readFileSync('tests/visual-pnl-daily-streak.test.ts', 'utf8');

for (const required of [
  'projectVisualPnlDailyStreak',
  'VisualPnlDailyStreakProjection',
  'if (!day.summary.available)',
  'day.summary.outcome !== outcome',
]) {
  if (!source.includes(required)) throw new Error(`P13.13 missing streak contract: ${required}`);
}
if (!index.includes("export * from './dailyStreak'")) throw new Error('P13.13 export missing');
for (const required of ['missing calendar dates', 'unavailable daily result', 'break-even']) {
  if (!tests.includes(required)) throw new Error(`P13.13 missing test evidence: ${required}`);
}
for (const forbidden of [
  'Number(', 'parseFloat(', 'parseInt(', 'decimalSum', 'Decimal',
  'Intl.', 'Date(', 'indexedDB', 'Dexie', 'localStorage', 'sessionStorage',
  'resolvedOptions().timeZone', 'getTimezoneOffset', 'exchangeRate',
]) {
  if (source.includes(forbidden)) throw new Error(`P13.13 ownership/scope violation: ${forbidden}`);
}
console.log('PASS P13.13 Visual P&L daily streak semantics verifier');
