import { readFileSync } from 'node:fs';
const history = readFileSync('src/application/journal/historyQuery.ts', 'utf8');
const test = readFileSync('tests/journal-history-query.test.ts', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));
const checks = [
  ['repository ownership', history.includes('createKairosRepositories(db)')],
  ['no direct IndexedDB owner', !history.includes('indexedDB') && !history.includes('new Dexie')],
  ['joins plans executions fees', ['tradePlans.listByTradeId','tradeExecutions.listByTradeId','tradeFees.listByTradeId'].every(x=>history.includes(x))],
  ['reuses P11 metrics', history.includes('calculateTradeMetrics(trade.side, executions, undefined, fees)')],
  ['deterministic newest-first order', history.includes('listRecentByUpdatedAt(normalizeHistoryLimit(options.limit))') || history.includes('historyTimestamp(b.trade).localeCompare(historyTimestamp(a.trade))')],
  ['calculation errors retained', history.includes('metricsError: metricsResult.ok ? null : metricsResult.reason')],
  ['unknown currency not guessed fixture', test.includes('netPnl).toBeNull()')],
  ['script registered', pkg.scripts?.['verify:p12:journal-history-query-scope-repair'] === 'node scripts/verify-p12-journal-history-query-scope-repair.mjs'],
];
const failed=checks.filter(([,ok])=>!ok); for(const [name,ok] of checks) console.log(`${ok?'PASS':'FAIL'} ${name}`); if(failed.length) process.exit(1);
