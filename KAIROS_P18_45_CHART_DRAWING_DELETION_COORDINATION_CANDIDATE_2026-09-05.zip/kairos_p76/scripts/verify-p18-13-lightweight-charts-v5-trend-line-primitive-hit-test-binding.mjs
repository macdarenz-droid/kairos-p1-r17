import { readFileSync } from 'node:fs';

const primitive = readFileSync('src/features/chart/lightweightChartsV5TrendLinePrimitive.ts', 'utf8');
const geometry = readFileSync('src/features/chart/lightweightChartsV5TrendLineHitTest.ts', 'utf8');
const test = readFileSync('tests/lightweight-charts-v5-trend-line-primitive-hit-test.test.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');

const requiredPrimitive = [
  'hitTestLightweightChartsV5TrendLineSegments',
  'hitTest(x: number, y: number)',
  "externalId: hit.id",
  "zOrder: 'normal'",
  "hitTestPriority: 1",
  "itemType: 'primitive'",
  'segments = projectLightweightChartsV5TrendLineSegments(',
  'segments = [];',
];
for (const token of requiredPrimitive) {
  if (!primitive.includes(token)) throw new Error(`P18.13 primitive binding missing: ${token}`);
}
if (!geometry.includes('export function hitTestLightweightChartsV5TrendLineSegments')) {
  throw new Error('P18.13 must reuse the canonical P18.12 geometry owner');
}
if (!index.includes('LightweightChartsV5TrendLinePrimitiveHoveredItem')) {
  throw new Error('P18.13 public provider hover shape export missing');
}
for (const token of ['before projected presentation geometry exists', 'same projected segment snapshot', 'clears provider hover geometry when detached']) {
  if (!test.includes(token)) throw new Error(`P18.13 regression evidence missing: ${token}`);
}
for (const forbidden of ['subscribeClick', 'subscribeCrosshairMove', 'IndexedDB', 'riskReward', 'risk-reward']) {
  if (primitive.includes(forbidden)) throw new Error(`P18.13 scope violation: ${forbidden}`);
}
console.log('P18.13 Lightweight Charts v5 trend-line primitive hit-test binding verifier: PASS');
