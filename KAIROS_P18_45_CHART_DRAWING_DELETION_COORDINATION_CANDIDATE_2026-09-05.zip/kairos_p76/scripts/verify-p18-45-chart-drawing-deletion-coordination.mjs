import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/chartDrawingDeletionCoordination.ts', 'utf8');
const collection = readFileSync('src/features/chart/chartDrawingCollection.ts', 'utf8');
const reducer = readFileSync('src/features/chart/chartDrawingInteractionReducer.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync('tests/chart-drawing-deletion-coordination.test.ts', 'utf8');
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.45 chart drawing deletion coordination verification FAIL: ${message}`);
  process.exit(1);
};

for (const required of [
  "state.status !== 'deleting'",
  'collection.getDrawing(state.drawingId)',
  'collection.removeDrawing(state.drawingId)',
  "interaction.dispatch({ type: 'reset-interaction' })",
  "throw new Error('chart-drawing-deletion-reset-rejected')",
]) {
  if (!source.includes(required)) fail(`missing deletion coordination evidence: ${required}`);
}

for (const forbidden of [
  "type: 'start-deleting'",
  'presentation.replace',
  'replaceChartDrawingPresentationFromCollection',
  'subscribeClick',
  'subscribeCrosshairMove',
  'attachPrimitive',
  'detachPrimitive',
]) {
  if (source.includes(forbidden)) fail(`scope leak in deletion coordinator: ${forbidden}`);
}

for (const preserved of [
  'removeDrawing(drawingId: ChartDrawingId): readonly ChartDrawing[]',
  "throw new Error('chart-drawing-collection-missing-id')",
]) {
  if (!collection.includes(preserved)) fail(`P18.44 collection mutation owner regressed: ${preserved}`);
}

for (const preserved of [
  "case 'start-deleting'",
  "case 'reset-interaction'",
]) {
  if (!reducer.includes(preserved)) fail(`P18.23/P18.38 interaction semantics regressed: ${preserved}`);
}

if (!index.includes("export { executeChartDrawingDeletion } from './chartDrawingDeletionCoordination';")) {
  fail('chart feature export for P18.45 deletion coordination missing');
}

if (
  packageJson.scripts?.['verify:p18:45-chart-drawing-deletion-coordination'] !==
  'node scripts/verify-p18-45-chart-drawing-deletion-coordination.mjs'
) {
  fail('P18.45 package verifier script missing');
}

for (const token of [
  'removes exactly the authoritative deleting drawing and resets interaction after success',
  'does not initiate deletion from selected state',
  'fails closed when deleting state points at a stale committed identity',
  'never removes a different committed drawing than the authoritative deleting identity',
]) {
  if (!test.includes(token)) fail(`missing focused runtime case: ${token}`);
}

console.log('P18.45 chart drawing deletion coordination verification PASS');
