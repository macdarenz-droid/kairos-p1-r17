import { readFileSync } from 'node:fs';

const component = readFileSync('src/app/VisualPnlCalendar.tsx', 'utf8');
const css = readFileSync('src/app/journalRoute.css', 'utf8');
const tests = readFileSync('tests/visual-pnl-calendar-presentation.test.tsx', 'utf8');

const need = (text, value, label) => {
  if (!text.includes(value)) throw new Error(`P13.9 missing ${label}: ${value}`);
};

need(component, 'VisualPnlDailySummaryProjection', 'P13.7 projection consumer');
need(component, 'data-day-outcome={kind}', 'semantic outcome hook');
need(component, 'Mixed currencies', 'mixed-currency unavailable language');
need(component, "if (outcome === 'profit') return '▲'", 'non-color profit cue');
need(component, "if (outcome === 'loss') return '▼'", 'non-color loss cue');
need(component, "return '—'", 'non-color breakeven cue');
need(css, 'var(--kairos-trade-profit)', 'semantic profit token');
need(css, 'var(--kairos-trade-loss)', 'semantic loss token');
need(css, 'var(--kairos-trade-flat)', 'semantic flat token');
need(tests, 'text and shape cues', 'accessibility regression');

for (const forbidden of [
  'listJournalHistory',
  'listJournalVisualPnlDailySummary',
  'createKairosRepositories',
  'decimalSum',
  'decimalAdd',
  'parseFloat',
  'parseInt',
  'Intl.DateTimeFormat',
  'exchangeRate',
]) {
  if (component.includes(forbidden)) throw new Error(`P13.9 presentation became a duplicate owner: ${forbidden}`);
}

console.log('PASS P13.9 accessible Visual P&L calendar presentation verifier');
