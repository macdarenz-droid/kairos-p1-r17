import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/chartDrawingIdentity.ts', 'utf8');
const contract = readFileSync('src/features/chart/chartDrawingContract.ts', 'utf8');
const collection = readFileSync('src/features/chart/chartDrawingCollection.ts', 'utf8');
const commit = readFileSync('src/features/chart/chartTrendLineDraftCommitCoordination.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync('tests/chart-drawing-identity.test.ts', 'utf8');
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.34 chart drawing identity verification FAIL: ${message}`);
  process.exit(1);
};

for (const required of [
  "import type { ChartDrawingId } from './chartDrawingContract'",
  'export function createChartDrawingId(): ChartDrawingId',
  'return crypto.randomUUID()',
]) {
  if (!source.includes(required)) fail(`missing identity evidence: ${required}`);
}

if (!contract.includes('export type ChartDrawingId = string')) {
  fail('P18.1 ChartDrawingId contract regressed');
}

for (const required of [
  'const drawings = new Map<ChartDrawingId, ChartDrawing>()',
  "throw new Error('chart-drawing-collection-duplicate-id')",
]) {
  if (!collection.includes(required)) fail(`P18.33 collection regressed: ${required}`);
}

for (const required of [
  'commitChartTrendLineDraft(',
  "session.dispatch({ type: 'commit-drawing', drawingId })",
]) {
  if (!commit.includes(required)) fail(`P18.32 commit coordination regressed: ${required}`);
}

if (!index.includes("export { createChartDrawingId } from './chartDrawingIdentity';")) {
  fail('chart feature export for P18.34 identity is missing');
}

if (
  packageJson.scripts?.['verify:p18:34-chart-drawing-identity'] !==
  'node scripts/verify-p18-34-chart-drawing-identity.mjs'
) {
  fail('P18.34 package verifier script missing');
}

for (const token of [
  'allocates fresh chart drawing identities as platform UUIDs',
  'keeps drawing identity allocation independent from trade-domain identity ownership',
]) {
  if (!test.includes(token)) fail(`runtime test does not pin behavior: ${token}`);
}

for (const forbidden of [
  "from '../../domain/trades",
  "from '../domain/trades",
  'createTradeDomainId',
  'defineChartDrawing(',
  'commitChartTrendLineDraft(',
  'createChartDrawingCollectionPort(',
  'dispatch(',
  'subscribeClick(',
  'coordinateToPrice(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.delete(',
  'riskReward',
  'lightweight-charts',
]) {
  if (source.includes(forbidden)) fail(`identity crossed protected boundary: ${forbidden}`);
}

console.log('P18.34 chart drawing identity verification passed.');
