import { readFileSync } from 'node:fs';

const source = readFileSync(
  'src/features/chart/chartTrendLineDraftCommitCoordination.ts',
  'utf8',
);
const interaction = readFileSync(
  'src/features/chart/chartTrendLineDraftInteractionCoordination.ts',
  'utf8',
);
const construction = readFileSync(
  'src/features/chart/chartTrendLineDraftCommitConstruction.ts',
  'utf8',
);
const reducer = readFileSync('src/features/chart/chartDrawingInteractionReducer.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync(
  'tests/chart-trend-line-draft-commit-coordination.test.ts',
  'utf8',
);
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.32 trend-line draft commit coordination verification FAIL: ${message}`);
  process.exit(1);
};

for (const required of [
  'commitChartTrendLineDraft(',
  'session: ChartTrendLineDraftInteractionSession',
  'drawingId: ChartDrawingId',
  "if (state.status !== 'preview' || state.tool !== 'trend-line') return null",
  'constructChartTrendLineDrawingFromDraft(drawingId, session.getAnchors())',
  "session.dispatch({ type: 'commit-drawing', drawingId })",
  "next.status !== 'committed'",
  'next.drawingId !== drawingId',
]) {
  if (!source.includes(required)) fail(`missing commit coordination evidence: ${required}`);
}

for (const required of [
  'constructChartTrendLineDrawingFromDraft(',
  'return defineChartDrawing({',
]) {
  if (!construction.includes(required)) fail(`P18.31 construction owner regressed: ${required}`);
}

for (const required of [
  "case 'commit-drawing':",
  "state.status === 'preview'",
  "{ status: 'committed', drawingId: event.drawingId }",
]) {
  if (!reducer.includes(required)) fail(`P18.23 transition owner regressed: ${required}`);
}

for (const required of [
  "(event.type === 'commit-drawing' && next.status === 'committed')",
  'draft.clear()',
]) {
  if (!interaction.includes(required)) fail(`P18.29 draft lifecycle coordination missing: ${required}`);
}

if (!index.includes('commitChartTrendLineDraft')) {
  fail('chart feature export for P18.32 commit coordination is missing');
}

if (
  packageJson.scripts?.['verify:p18:32-chart-trend-line-draft-commit-coordination'] !==
  'node scripts/verify-p18-32-chart-trend-line-draft-commit-coordination.mjs'
) {
  fail('P18.32 package verifier script missing');
}

for (const token of [
  'constructs through P18.31 then commits through the existing P18.29 interaction session',
  'fails closed outside trend-line preview without constructing or dispatching commit truth',
  'preserves caller-supplied drawing identity across construction and authoritative commit state',
  'fails closed if the supplied authoritative session refuses the commit transition',
]) {
  if (!test.includes(token)) fail(`runtime test does not pin behavior: ${token}`);
}

for (const forbidden of [
  'randomUUID',
  'crypto.',
  'defineChartDrawing(',
  'reduceChartDrawingInteraction(',
  'createChartDrawingInteractionPort(',
  'createChartTrendLineDraftAnchorCollectionPort(',
  'subscribeClick(',
  'unsubscribeClick(',
  'coordinateToPrice(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.delete(',
  'riskReward',
  'lightweight-charts',
]) {
  if (source.includes(forbidden)) fail(`commit coordination crossed protected boundary: ${forbidden}`);
}

console.log('P18.32 chart trend-line draft commit coordination verification passed.');
