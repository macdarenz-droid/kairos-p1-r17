import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/features/chart/chartDrawingProjection.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/features/chart/index.ts', import.meta.url), 'utf8');
const tests = readFileSync(new URL('../tests/chart-drawing-projection.test.ts', import.meta.url), 'utf8');
const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

for (const required of [
  'export function projectChartDrawings(',
  'drawings: readonly ChartDrawing[]',
  '): readonly RendererChartDrawing[]',
  'return drawings.map(projectChartDrawing)',
]) {
  if (!source.includes(required)) throw new Error(`p18.36-missing:${required}`);
}

if (!index.includes('projectChartDrawings,')) {
  throw new Error('p18.36-index-export-missing');
}

if (pkg.scripts?.['verify:p18:36-chart-drawing-collection-projection'] !== 'node scripts/verify-p18-36-chart-drawing-collection-projection.mjs') {
  throw new Error('p18.36-package-script-missing');
}

for (const required of [
  "describe('P18.36 chart drawing collection projection'",
  'projectChartDrawings(drawings)',
  'projectChartDrawings([])',
]) {
  if (!tests.includes(required)) throw new Error(`p18.36-test-coverage-missing:${required}`);
}

for (const forbidden of [
  'lightweight-charts',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'fetch(',
  'WebSocket',
  'attachPrimitive',
  'coordinateToPrice',
  'createChartDrawingCollectionPort',
  'commitChartTrendLineDraft',
  'createChartDrawingPresentationPort',
  'riskReward',
]) {
  if (source.includes(forbidden)) throw new Error(`p18.36-forbidden-scope:${forbidden}`);
}

console.log('P18.36 chart drawing collection projection verifier: PASS');
