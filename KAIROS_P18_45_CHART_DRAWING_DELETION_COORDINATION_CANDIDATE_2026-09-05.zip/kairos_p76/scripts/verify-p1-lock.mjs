import { readFileSync, existsSync } from 'node:fs';

const fail = (message) => {
  console.error(`P1 lock: FAIL — ${message}`);
  process.exit(1);
};

if (!existsSync('package-lock.json')) {
  console.error('P1 lock: HOLD — package-lock.json does not exist yet.');
  process.exit(2);
}

let pkg;
let lock;
try {
  pkg = JSON.parse(readFileSync('package.json', 'utf8'));
  lock = JSON.parse(readFileSync('package-lock.json', 'utf8'));
} catch (error) {
  fail(`manifest/lockfile JSON is invalid: ${error.message}`);
}

if (lock.lockfileVersion !== 3) {
  fail(`expected npm lockfileVersion 3, received ${String(lock.lockfileVersion)}.`);
}

const root = lock.packages?.[''];
if (!root) fail('root package entry is missing.');

const sameMap = (a = {}, b = {}) => {
  const ak = Object.keys(a).sort();
  const bk = Object.keys(b).sort();
  if (ak.length !== bk.length || ak.some((key, i) => key !== bk[i])) return false;
  return ak.every((key) => a[key] === b[key]);
};

if (!sameMap(pkg.dependencies, root.dependencies)) {
  fail('root dependencies do not exactly match package.json.');
}
if (!sameMap(pkg.devDependencies, root.devDependencies)) {
  fail('root devDependencies do not exactly match package.json.');
}

for (const [name, version] of Object.entries({
  ...(pkg.dependencies ?? {}),
  ...(pkg.devDependencies ?? {}),
})) {
  const entry = lock.packages?.[`node_modules/${name}`];
  if (!entry) fail(`direct dependency ${name} is missing from the lockfile.`);
  if (entry.version !== version) {
    fail(`direct dependency ${name} is locked to ${entry.version ?? 'unknown'}, expected ${version}.`);
  }
  if (!entry.integrity) fail(`direct dependency ${name} has no integrity hash.`);
}

console.log('P1 lock integrity: PASS — root manifest and direct dependency locks match exactly.');
