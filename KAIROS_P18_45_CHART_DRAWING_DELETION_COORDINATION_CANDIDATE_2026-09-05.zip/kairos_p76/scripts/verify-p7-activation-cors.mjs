import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const worker = await readFile(path.join(root, 'backend/activation-worker/worker.js'), 'utf8');

const origin = 'https://kairos-p1-r17.pages.dev';
const assertions = [
  ['exact production origin is locked', worker.includes(`const ACTIVATION_ALLOWED_ORIGIN = "${origin}"`)],
  ['wildcard origin is absent', !worker.includes('"access-control-allow-origin": "*"') && !worker.includes("'access-control-allow-origin': '*'" )],
  ['OPTIONS preflight is handled before POST-only rejection', worker.indexOf('request.method === "OPTIONS"') < worker.indexOf('request.method !== "POST"')],
  ['preflight allows POST and OPTIONS only', worker.includes('"access-control-allow-methods": "POST, OPTIONS"')],
  ['preflight allows Accept and Content-Type only', worker.includes('"access-control-allow-headers": "Accept, Content-Type"')],
  ['responses vary by Origin', worker.includes('"vary": "Origin"')],
  ['allowed origin is attached only on exact Origin match', worker.includes('request.headers.get("origin") === ACTIVATION_ALLOWED_ORIGIN')],
  ['disallowed preflight is rejected', worker.includes('status: 403')],
  ['preflight does not consume rate limit', worker.indexOf('return preflight(request)') < worker.indexOf('env.ACTIVATION_RATE_LIMITER.limit')],
  ['normal JSON responses receive CORS policy', worker.includes('...corsHeaders(request)')],
  ['credentials are not enabled', !worker.toLowerCase().includes('access-control-allow-credentials')],
  ['D1 conditional one-time authority remains', worker.includes("AND status = 'unused'")],
  ['private signing secret remains server-side', worker.includes('env.KAIROS_ACTIVATION_PRIVATE_KEY')],
  ['rate limiting remains enabled', worker.includes('env.ACTIVATION_RATE_LIMITER.limit')],
];

const failures = assertions.filter(([, pass]) => !pass);
if (failures.length) {
  for (const [name] of failures) console.error(`FAIL: ${name}`);
  process.exit(1);
}
for (const [name] of assertions) console.log(`PASS: ${name}`);
