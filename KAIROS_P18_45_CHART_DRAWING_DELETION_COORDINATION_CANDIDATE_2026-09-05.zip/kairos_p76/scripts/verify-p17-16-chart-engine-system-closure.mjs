import { existsSync, readFileSync } from 'node:fs';

const requiredFiles = [
  'src/features/chart/chartRenderContract.ts',
  'src/features/chart/chartRendererLifecycle.ts',
  'src/features/chart/chartSeriesProjection.ts',
  'src/features/chart/projectedChartRenderer.ts',
  'src/features/chart/chartEngineDriver.ts',
  'src/features/chart/lightweightChartsV5ModuleAdapter.ts',
  'src/features/chart/chartIncrementalUpdate.ts',
  'src/features/chart/lightweightChartsV5IncrementalUpdate.ts',
  'src/features/chart/lightweightChartsV5Package.ts',
  'src/features/chart/lightweightChartsV5ProductionRenderer.ts',
  'src/features/chart/chartVisibleRange.ts',
  'src/features/chart/chartSeriesLogicalRangeCoverage.ts',
  'src/features/chart/lightweightChartsV5SeriesLogicalRangeCoverage.ts',
  'src/features/chart/chartViewportHistoryDemand.ts',
];
for (const file of requiredFiles) {
  if (!existsSync(file)) throw new Error(`Missing P17 closure owner: ${file}`);
}

const pkg = JSON.parse(readFileSync('package.json', 'utf8'));
const requiredScripts = [
  'verify:p17:1-chart-render-contract-foundation',
  'verify:p17:2-chart-renderer-lifecycle-boundary',
  'verify:p17:3-chart-series-projection-boundary',
  'verify:p17:4-projected-chart-renderer-composition',
  'verify:p17:5-chart-engine-driver-adapter',
  'verify:p17:6-lightweight-charts-v5-module-adapter',
  'verify:p17:7-chart-incremental-update-contract',
  'verify:p17:8-lightweight-charts-v5-incremental-update',
  'verify:p17:9-lightweight-charts-v5-package',
  'verify:p17:10-lightweight-charts-v5-production-renderer',
  'verify:p17:11-responsive-chart-sizing',
  'verify:p17:12-incremental-chart-engine-driver',
  'verify:p17:13-chart-visible-range-boundary',
  'verify:p17:14-series-logical-range-coverage',
  'verify:p17:15-chart-viewport-history-demand',
];
for (const name of requiredScripts) {
  if (!pkg.scripts?.[name]) throw new Error(`Missing required P17 verifier: ${name}`);
}
if (pkg.dependencies?.['lightweight-charts'] !== '5.2.1') {
  throw new Error('P17 closure requires lightweight-charts exactly 5.2.1');
}

const demand = readFileSync('src/features/chart/chartViewportHistoryDemand.ts', 'utf8');
for (const required of [
  'minimumBarsBefore',
  'getCurrentDemand',
  'subscribeDemandChange',
  'ChartVisibleRangePort',
  'ChartSeriesLogicalRangeCoveragePort',
]) {
  if (!demand.includes(required)) throw new Error(`Missing P17.15 composition evidence: ${required}`);
}
for (const forbidden of [
  'fetch(',
  'WebSocket',
  'indexedDB',
  'localStorage',
  'placeOrder',
  'apiKey',
  'secret',
  'createPriceLine',
  'createSeriesMarkers',
]) {
  if (demand.includes(forbidden)) throw new Error(`P17 closure boundary violation in demand owner: ${forbidden}`);
}

const contract = readFileSync('src/features/chart/chartRenderContract.ts', 'utf8');
if (!contract.includes('DecimalString')) {
  throw new Error('P17 render contract must preserve DecimalString upstream evidence');
}

const lifecycle = readFileSync('src/features/chart/chartRendererLifecycle.ts', 'utf8');
if (!lifecycle.includes('destroy')) {
  throw new Error('P17 lifecycle must retain explicit destroy semantics');
}

console.log('P17.16 chart engine system closure verifier PASS');
