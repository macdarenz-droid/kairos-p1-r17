import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/lightweightChartsV5DrawingHoverProjection.ts', 'utf8');
const primitive = readFileSync('src/features/chart/lightweightChartsV5TrendLinePrimitive.ts', 'utf8');
const test = readFileSync('tests/lightweight-charts-v5-drawing-hover-projection.test.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');

for (const token of [
  'hoveredObjectId?: string',
  "kind: 'drawing-hover'",
  'drawing.id === hoveredObjectId',
  "return { kind: 'drawing-hover', drawingId: drawing.id }",
]) {
  if (!source.includes(token)) throw new Error(`P18.14 hover projection missing: ${token}`);
}
if (!primitive.includes('externalId: hit.id')) {
  throw new Error('P18.14 requires the canonical P18.13 primitive externalId source');
}
if (!index.includes('projectLightweightChartsV5DrawingHover')) {
  throw new Error('P18.14 hover projection export missing');
}
for (const token of ['belongs to the current drawing snapshot', 'unrelated provider object ids', 'stale drawing ids']) {
  if (!test.includes(token)) throw new Error(`P18.14 regression evidence missing: ${token}`);
}
for (const forbidden of ['subscribeClick', 'subscribeCrosshairMove', 'IndexedDB', 'riskReward', 'risk-reward', 'drag', 'selection']) {
  if (source.includes(forbidden) && !source.includes(`no chart subscription lifecycle, selection state, click state, drag/edit`)) {
    throw new Error(`P18.14 scope violation: ${forbidden}`);
  }
}
console.log('P18.14 Lightweight Charts v5 drawing hover-event projection verifier: PASS');
