import fs from 'node:fs';

const fail = (message) => {
  console.error(`FAIL P15.14 Market Data adapter system closure verifier: ${message}`);
  process.exit(1);
};

const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const scripts = packageJson.scripts ?? {};

const requiredScripts = [
  'verify:p15:1-market-data-adapter-interface',
  'verify:p15:2-market-data-observation-semantics',
  'verify:p15:3-market-data-subscription-lifecycle',
  'verify:p15:4-market-data-connection-state',
  'verify:p15:5-market-data-reconnect-policy',
  'verify:p15:6-market-data-reconnect-scheduler',
  'verify:p15:7-market-data-reconnect-jitter',
  'verify:p15:8-market-data-reconnect-plan',
  'verify:p15:9-market-data-reconnect-coordinator',
  'verify:p15:10-market-data-reconnect-disposition',
  'verify:p15:11-market-data-reconnect-intent',
  'verify:p15:12-market-data-reconnect-attempt',
  'verify:p15:13-market-data-reconnect-execution',
];

for (const script of requiredScripts) {
  if (!scripts[script]) fail(`missing registered predecessor verifier ${script}`);
}

const requiredOwners = [
  'src/services/market-data/index.ts',
  'src/services/market-data/marketDataReconnectPolicy.ts',
  'src/services/market-data/marketDataReconnectScheduler.ts',
  'src/services/market-data/marketDataReconnectJitter.ts',
  'src/services/market-data/marketDataReconnectPlan.ts',
  'src/services/market-data/marketDataReconnectCoordinator.ts',
  'src/services/market-data/marketDataReconnectDisposition.ts',
  'src/services/market-data/marketDataReconnectIntent.ts',
  'src/services/market-data/marketDataReconnectAttempt.ts',
  'src/services/market-data/marketDataReconnectExecution.ts',
];

for (const owner of requiredOwners) {
  if (!fs.existsSync(owner)) fail(`missing owner ${owner}`);
}

const closureOwners = requiredOwners
  .filter((owner) => owner !== 'src/services/market-data/index.ts')
  .map((owner) => fs.readFileSync(owner, 'utf8'))
  .join('\n');

for (const forbidden of [
  'new WebSocket(',
  'CloseEvent',
  'Math.random(',
  'setTimeout(',
  'setInterval(',
  'indexedDB',
  'Dexie',
]) {
  if (closureOwners.includes(forbidden)) {
    fail(`provider/transport/persistence ownership leaked into P15 core: ${forbidden}`);
  }
}

console.log('PASS P15.14 Market Data adapter system closure verifier');
