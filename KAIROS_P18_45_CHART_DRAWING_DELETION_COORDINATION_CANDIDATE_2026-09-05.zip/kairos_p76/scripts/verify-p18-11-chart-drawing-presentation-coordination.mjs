import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/features/chart/chartDrawingPresentationPort.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/features/chart/index.ts', import.meta.url), 'utf8');

for (const required of [
  'createChartDrawingPresentationPort',
  'drawingLayer.attach(nextSeries)',
  'nextDrawingLayer.replaceDrawings(drawings)',
  'activeDrawingLayer.destroy()',
  'chart.removeSeries(activeSeries)',
  "throw new Error('chart-drawing-presentation-destroyed')",
]) {
  if (!source.includes(required)) throw new Error(`p18.11-missing:${required}`);
}

if (source.indexOf('activeDrawingLayer.destroy()') > source.indexOf('chart.removeSeries(activeSeries)')) {
  throw new Error('p18.11-detach-must-precede-series-removal');
}

if (!index.includes("from './chartDrawingPresentationPort'")) {
  throw new Error('p18.11-index-export-missing');
}

for (const forbidden of ['IndexedDB', 'fetch(', 'WebSocket', 'localStorage', 'riskReward']) {
  if (source.includes(forbidden)) throw new Error(`p18.11-forbidden-scope:${forbidden}`);
}

console.log('P18.11 chart drawing presentation coordination verifier: PASS');
