import assert from 'node:assert/strict';
import { P1_GATE_EXIT, classifyInstallFailure } from './p1-gate-result.mjs';

assert.deepEqual(P1_GATE_EXIT, { PASS: 0, FAIL: 1, HOLD: 2 });
for (const sample of [
  'npm error code EAI_AGAIN',
  'getaddrinfo ENOTFOUND registry.npmjs.org',
  'npm ERR! code ETIMEDOUT',
  'connect ECONNREFUSED 10.0.0.1:443',
  'request failed: ENETUNREACH',
]) {
  assert.equal(classifyInstallFailure(sample), 'HOLD', sample);
}
for (const sample of [
  'npm error EUSAGE package.json and package-lock.json are not in sync',
  'npm error ERESOLVE unable to resolve dependency tree',
  'integrity checksum failed',
]) {
  assert.equal(classifyInstallFailure(sample), 'FAIL', sample);
}
console.log('P1 gate result classifier: PASS');
