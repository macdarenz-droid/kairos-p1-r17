import { readFileSync } from 'node:fs';

const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));
const test = readFileSync('tests/journal-history-performance.test.tsx', 'utf8');
const query = readFileSync('src/application/journal/historyQuery.ts', 'utf8');
const route = readFileSync('src/app/JournalRoute.tsx', 'utf8');
const list = readFileSync('src/app/JournalHistoryList.tsx', 'utf8');

function requireCondition(condition, message) {
  if (!condition) {
    console.error(`P12.6R1 verifier failure: ${message}`);
    process.exit(1);
  }
}

requireCondition(
  packageJson.scripts?.['verify:p12:journal-history-heavy-performance'] === 'node scripts/verify-p12-journal-history-heavy-performance.mjs',
  'package registration must point to the P12.6 heavy-performance verifier.',
);
requireCondition(/HEAVY_TRADE_COUNT\s*=\s*10_500/.test(test), 'USER_HEAVY fixture must contain 10,500 trades.');
requireCondition(/HISTORY_PAGE_LIMIT\s*=\s*100/.test(test), 'history canary must pin the bounded 100-row journal window.');
requireCondition(test.includes("getAllByRole('listitem')"), 'history cards must be asserted by their actual listitem semantics.');
requireCondition(!test.includes("getAllByRole('article')"), 'the discarded P12.6 article-role assertion must not return.');
requireCondition(test.includes("value: 'closed'"), 'canary must exercise a status-filter transition.');
requireCondition(test.includes('INITIAL_RENDER_BUDGET_MS'), 'canary must retain an initial-render timing budget.');
requireCondition(test.includes('STATUS_FILTER_BUDGET_MS'), 'canary must retain a status-filter timing budget.');
requireCondition(query.includes('listRecentByUpdatedAt(normalizeHistoryLimit(options.limit))'), 'unfiltered history must remain delegated to the indexed recent-trades repository owner.');
requireCondition(query.includes('listRecentByStatusAndUpdatedAt(options.status, normalizeHistoryLimit(options.limit))'), 'status history must remain delegated to the compound-index repository owner.');
requireCondition(!route.includes('.filter('), 'JournalRoute must not perform in-memory history filtering.');
requireCondition(!list.includes('.filter('), 'JournalHistoryList must not perform in-memory history filtering.');
requireCondition(list.includes('<li className="kairos-history-card"'), 'production history cards must retain native list-item semantics.');

console.log('P12.6R1 USER_HEAVY journal history performance verifier: PASS');
console.log(' - fixture: 10,500 trades');
console.log(' - bounded window: 100 rows');
console.log(' - all/status paths: repository-index delegated');
console.log(' - accessibility contract: listitem');
