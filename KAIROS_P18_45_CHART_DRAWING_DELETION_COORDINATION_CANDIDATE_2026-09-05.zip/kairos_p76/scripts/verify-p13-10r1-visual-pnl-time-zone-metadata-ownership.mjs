import { readFileSync } from 'node:fs';

const source = readFileSync('src/application/visual-pnl/timeZonePreference.ts', 'utf8');
const index = readFileSync('src/application/visual-pnl/index.ts', 'utf8');
const tests = readFileSync('tests/visual-pnl-time-zone-preference.test.ts', 'utf8');

const need = (text, value, label) => {
  if (!text.includes(value)) throw new Error(`P13.10R1 missing ${label}: ${value}`);
};

need(source, "import type { MetadataRepository } from '../../data/repositories';", 'existing metadata owner dependency');
need(source, "preferences.visual-pnl.time-zone.v1", 'versioned preference metadata key');
need(source, 'metadata.get(visualPnlTimeZonePreferenceMetadataKey)', 'metadata read ownership');
need(source, 'metadata.put({', 'metadata write ownership');
need(source, 'metadata.delete(visualPnlTimeZonePreferenceMetadataKey)', 'metadata clear ownership');
need(source, 'projectVisualPnlDayKey(VALIDATION_INSTANT, timeZone).available', 'P13.6 validation reuse');
need(index, "export * from './timeZonePreference';", 'public export');
need(tests, 'through MetadataRepository', 'persistence ownership regression');
need(tests, 'propagates metadata persistence failures', 'fatal storage failure regression');

for (const forbidden of [
  'localStorage',
  'sessionStorage',
  'indexedDB',
  'Dexie',
  'resolvedOptions().timeZone',
  'getTimezoneOffset',
  'navigator.language',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P13.10R1 application preference leaked infrastructure or implicit timezone policy: ${forbidden}`);
  }
}

console.log('PASS P13.10R1 Visual P&L timezone metadata-ownership verifier');
