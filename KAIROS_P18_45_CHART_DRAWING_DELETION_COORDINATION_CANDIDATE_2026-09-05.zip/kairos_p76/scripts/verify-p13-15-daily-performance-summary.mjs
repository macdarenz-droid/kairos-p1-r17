import { readFileSync } from 'node:fs';
const source=readFileSync('src/application/visual-pnl/dailyPerformanceSummary.ts','utf8');
const index=readFileSync('src/application/visual-pnl/index.ts','utf8');
const tests=readFileSync('tests/visual-pnl-daily-performance-summary.test.ts','utf8');
for (const required of ['summarizeVisualPnlDailyPerformance','profitDays','lossDays','breakEvenDays','unavailableResultDays','availableResultDays','totalResultDays']) {
  if(!source.includes(required)) throw new Error(`P13.15 missing summary contract: ${required}`);
}
if(!index.includes("export * from './dailyPerformanceSummary'")) throw new Error('P13.15 export missing');
for(const required of ['no result days','without monetary aggregation','unavailable result days separately']) {
  if(!tests.includes(required)) throw new Error(`P13.15 test evidence missing: ${required}`);
}
for(const forbidden of ['Number(','parseFloat(','parseInt(','Decimal','Intl.','Date(','indexedDB','Dexie','localStorage','sessionStorage','exchangeRate','currency ===','currency !==']) {
  if(source.includes(forbidden)) throw new Error(`P13.15 scope/ownership violation: ${forbidden}`);
}
console.log('PASS P13.15 Visual P&L daily performance summary verifier');
