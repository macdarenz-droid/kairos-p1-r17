import { existsSync } from 'node:fs';
import { lookup } from 'node:dns/promises';
import { spawnSync } from 'node:child_process';

const registry = process.env.npm_config_registry || 'https://registry.npmjs.org/';
const host = new URL(registry).hostname;
const report = {
  node: process.version,
  npm: null,
  registry,
  packageLockPresent: existsSync('package-lock.json'),
  dns: { status: 'UNKNOWN' },
};

const npmVersion = spawnSync('npm', ['--version'], { encoding: 'utf8' });
if (npmVersion.status === 0) report.npm = npmVersion.stdout.trim();
else report.npm = `unavailable: ${npmVersion.error?.message ?? npmVersion.stderr?.trim() ?? 'unknown error'}`;

try {
  const records = await lookup(host, { all: true });
  report.dns = {
    status: 'PASS',
    host,
    addresses: records.map(({ address, family }) => ({ address, family })),
  };
} catch (error) {
  report.dns = {
    status: 'HOLD',
    host,
    code: error?.code ?? 'UNKNOWN',
    message: error?.message ?? String(error),
  };
}

const status = !report.packageLockPresent || report.dns.status !== 'PASS' ? 'HOLD' : 'READY';
console.log(JSON.stringify({ status, ...report }, null, 2));
process.exit(status === 'READY' ? 0 : 2);
