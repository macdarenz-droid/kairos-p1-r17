import { readFile } from 'node:fs/promises';
const source = await readFile(new URL('../src/services/market-data/providers/binance/binanceSpotPublicStreamLifecycleConnector.ts', import.meta.url), 'utf8');
const index = await readFile(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
for (const token of [
  'transitionMarketDataConnectionState',
  "apply('connect-requested')",
  "apply('connected')",
  "apply('failed')",
  "apply('disconnected')",
  'handlers.onOpen?.()',
  'handlers.onError?.(error)',
  'handlers.onClose?.(reason)',
]) {
  if (!source.includes(token)) throw new Error(`P16.13 missing lifecycle token: ${token}`);
}
for (const forbidden of ['new WebSocket', 'setTimeout', 'setInterval', 'Date.now', 'Math.random', 'indexedDB', 'localStorage', 'sessionStorage', 'fetch(', 'AbortController']) {
  if (source.includes(forbidden)) throw new Error(`P16.13 lifecycle decorator owns forbidden behavior: ${forbidden}`);
}
if (!index.includes("export * from './providers/binance/binanceSpotPublicStreamLifecycleConnector';")) {
  throw new Error('P16.13 lifecycle connector must be exported by the market-data barrel.');
}
console.log('P16.13 Binance Spot public-stream lifecycle connector contract: PASS');
