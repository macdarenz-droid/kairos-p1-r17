import fs from 'node:fs';

const adapter = fs.readFileSync('src/services/activation/RemoteActivationAdapter.ts', 'utf8');
const barrel = fs.readFileSync('src/services/activation/index.ts', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));

const checks = [
  ['implements the existing ActivationAdapter boundary', /implements ActivationAdapter/.test(adapter)],
  ['requires HTTPS endpoint', /parsed\.protocol !== 'https:'/.test(adapter)],
  ['endpoint is deployment-injected', /options\.endpoint/.test(adapter)],
  ['uses POST JSON request', /method: 'POST'/.test(adapter) && /'content-type': 'application\/json'/.test(adapter)],
  ['does not send ambient credentials', /credentials: 'omit'/.test(adapter)],
  ['does not silently follow redirects', /redirect: 'error'/.test(adapter)],
  ['checks HTTP success explicitly', /response\.ok/.test(adapter)],
  ['maps rate limiting', /response\.status === 429/.test(adapter)],
  ['maps service failures', /reason: 'service-error'/.test(adapter)],
  ['maps transport failures', /reason: 'network-unavailable'/.test(adapter)],
  ['strictly parses server receipt', /parseReceipt/.test(adapter) && /verifierSignature/.test(adapter)],
  ['is exported from activation owner', /RemoteActivationAdapter/.test(barrel)],
  ['verification script is registered', pkg.scripts?.['verify:p7:remote-activation'] === 'node scripts/verify-p7-remote-activation-adapter.mjs'],
];

const failed = checks.filter(([, ok]) => !ok);
if (failed.length) {
  console.error('P7.3 remote activation adapter verification failed:');
  for (const [name] of failed) console.error(`- ${name}`);
  process.exit(1);
}
console.log(`P7.3 remote activation adapter verification PASS (${checks.length}/${checks.length}).`);
