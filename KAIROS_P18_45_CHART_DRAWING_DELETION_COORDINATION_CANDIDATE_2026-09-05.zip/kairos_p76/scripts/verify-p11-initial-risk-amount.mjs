import fs from 'node:fs';

const sourceFile = 'src/domain/calculations/riskCalculator.ts';
const testFile = 'tests/initial-risk-amount.test.ts';

for (const file of [sourceFile, testFile]) {
  if (!fs.existsSync(file)) {
    throw new Error(`Missing ${file}`);
  }
}

const source = fs.readFileSync(sourceFile, 'utf8');

for (const token of [
  'calculateInitialRiskAmount',
  'decimalMultiply',
  'riskPerUnit',
  'quantity',
  "'invalid-decimal'",
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P11.12 initial-risk contract: ${token}`);
  }
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error(
    'P11.12 RiskCalculator must not use native numeric arithmetic/coercion.',
  );
}

for (const forbidden of [
  'marketType',
  'plannedEntryPrice *',
  'plannedStopPrice *',
  'grossPnl',
  'netPnl',
  'realizedR',
  'TradeMetrics',
  'margin',
  'leverage',
  'multiplier',
  'tickValue',
  'lotSize',
  'exchangeRate',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.12 out-of-scope policy/owner detected: ${forbidden}`);
  }
}

console.log('P11.12 initial risk amount primitive verification PASS');
