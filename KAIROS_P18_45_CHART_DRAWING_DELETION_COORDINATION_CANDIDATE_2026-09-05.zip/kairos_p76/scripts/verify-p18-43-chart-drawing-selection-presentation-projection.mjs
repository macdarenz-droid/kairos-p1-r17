import { readFileSync } from 'node:fs';

const projection = readFileSync(
  'src/features/chart/chartDrawingSelectionPresentationProjection.ts',
  'utf8',
);
const interactionContract = readFileSync(
  'src/features/chart/chartDrawingInteractionContract.ts',
  'utf8',
);
const rendererProjection = readFileSync('src/features/chart/chartDrawingProjection.ts', 'utf8');
const test = readFileSync(
  'tests/chart-drawing-selection-presentation-projection.test.ts',
  'utf8',
);
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.43 chart drawing selection presentation projection verification FAIL: ${message}`);
  process.exit(1);
};

for (const token of [
  "export type ChartDrawingSelectionPresentationMode = 'selected' | 'editing' | 'deleting'",
  'state.status !== \'selected\'',
  'state.status !== \'editing\'',
  'state.status !== \'deleting\'',
  'drawings.find((candidate) => candidate.id === state.drawingId)',
  'drawing,',
  'mode: state.status,',
]) {
  if (!projection.includes(token)) fail(`missing projection invariant: ${token}`);
}

for (const status of ["'selected'", "'editing'", "'deleting'"]) {
  if (!interactionContract.includes(status)) fail(`authoritative interaction status missing: ${status}`);
}
if (!rendererProjection.includes('export type RendererChartDrawing = RendererTrendLineDrawing')) {
  fail('authoritative renderer drawing projection contract missing');
}

for (const token of [
  'exact current renderer drawing',
  'editing and deleting presentation modes',
  'fails stale selected identity closed',
  'does not present non-selection interaction states',
]) {
  if (!test.includes(token)) fail(`runtime evidence missing: ${token}`);
}

for (const forbidden of [
  'projectChartDrawing(',
  'projectChartDrawings(',
  'reduceChartDrawingInteraction(',
  '.dispatch(',
  'createChartDrawingInteractionPort(',
  'createChartDrawingCollectionPort(',
  'new Map(',
  'subscribeClick(',
  'unsubscribeClick(',
  'subscribeCrosshairMove(',
  'unsubscribeCrosshairMove(',
  'lightweight-charts',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.add(',
  '.delete(',
  'riskReward',
  'risk-reward',
]) {
  if (projection.includes(forbidden)) fail(`P18.43 crossed protected boundary: ${forbidden}`);
}

if (!index.includes("from './chartDrawingSelectionPresentationProjection';")) {
  fail('P18.43 chart export missing');
}
if (
  pkg.scripts?.['verify:p18:43-chart-drawing-selection-presentation-projection'] !==
  'node scripts/verify-p18-43-chart-drawing-selection-presentation-projection.mjs'
) {
  fail('P18.43 package verifier script missing');
}

console.log('P18.43 chart drawing selection presentation projection verification passed.');
