import fs from 'node:fs';const v=fs.readFileSync('src/data/backup/restoreVerification.ts','utf8');
for(const x of ['restoreAndVerifyKairosDatabase','replaceKairosDatabaseFromPreparedRestore(db, prepared)','closeKairosDatabase(db)','openKairosDatabase(db)','assertKairosDatabaseIntegrity(db)','repositories.metadata.listAll()','repositories.trades.listAll()',"'REQUERY_MISMATCH'","'REOPEN_FAILED'",'prepared.recovery'])if(!v.includes(x))throw new Error(`P6.5 verification contract missing: ${x}`);
console.log('P6.5 post-restore full re-query verification: PASS');
