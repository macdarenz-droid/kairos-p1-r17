import { readFileSync } from 'node:fs';
const component=readFileSync('src/app/VisualPnlCumulativeProgress.tsx','utf8');
const child=readFileSync('src/app/JournalDailyResults.tsx','utf8');
for (const required of ['Cumulative realized P&amp;L','This is not account equity','mixed currencies','cumulativeAmount']) if(!component.includes(required)) throw new Error(`missing ${required}`);
for (const forbidden of ['Number(','parseFloat(','parseInt(','decimalAdd','decimalSum','indexedDB','Dexie','localStorage','sessionStorage']) if(component.includes(forbidden)) throw new Error(`ownership violation ${forbidden}`);
for (const required of ['projectVisualPnlProgressSeries','projectVisualPnlCumulativeRealizedPnl','VisualPnlCumulativeProgress']) if(!child.includes(required)) throw new Error(`wiring missing ${required}`);
console.log('PASS P13.19 cumulative realized P&L presentation verifier');
