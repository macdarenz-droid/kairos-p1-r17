import { existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { P1_GATE_EXIT, classifyInstallFailure } from './p1-gate-result.mjs';

const localSteps = [
  ['Typecheck', ['run', 'typecheck']],
  ['Tests', ['run', 'test']],
  ['Production build', ['run', 'build']],
];

function runNpm(args, { capture = false } = {}) {
  return spawnSync('npm', args, {
    encoding: capture ? 'utf8' : undefined,
    stdio: capture ? 'pipe' : 'inherit',
    shell: process.platform === 'win32',
  });
}

if (!existsSync('package-lock.json')) {
  console.error('P1 gate: HOLD — package-lock.json is required before reproducible verification can run.');
  console.error('Generate it from the pinned package.json with npm run lock:resolve, then rerun npm run verify:gate.');
  process.exit(P1_GATE_EXIT.HOLD);
}

console.log('\n[P1 gate] Clean dependency install');
const install = runNpm(['ci', '--no-audit', '--no-fund'], { capture: true });
const installOutput = `${install.stdout ?? ''}${install.stderr ?? ''}`;
if (installOutput) process.stdout.write(installOutput);

if (install.error) {
  console.error(`P1 gate: HOLD — clean dependency install could not start: ${install.error.message}`);
  process.exit(P1_GATE_EXIT.HOLD);
}
if (install.status !== 0) {
  const result = classifyInstallFailure(installOutput);
  if (result === 'HOLD') {
    console.error('P1 gate: HOLD — clean dependency install was blocked by external network/infrastructure availability.');
    process.exit(P1_GATE_EXIT.HOLD);
  }
  console.error(`P1 gate: FAIL — clean dependency install exited with status ${install.status}.`);
  process.exit(P1_GATE_EXIT.FAIL);
}

for (const [label, args] of localSteps) {
  console.log(`\n[P1 gate] ${label}`);
  const result = runNpm(args);
  if (result.error) {
    console.error(`P1 gate: FAIL — ${label} could not start: ${result.error.message}`);
    process.exit(P1_GATE_EXIT.FAIL);
  }
  if (result.status !== 0) {
    console.error(`P1 gate: FAIL — ${label} exited with status ${result.status}.`);
    process.exit(P1_GATE_EXIT.FAIL);
  }
}

console.log('\nP1 gate: PASS — clean install, typecheck, tests, and production build all succeeded.');
process.exit(P1_GATE_EXIT.PASS);
