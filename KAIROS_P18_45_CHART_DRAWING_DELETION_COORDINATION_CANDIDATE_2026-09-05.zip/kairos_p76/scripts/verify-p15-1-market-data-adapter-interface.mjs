import { readFileSync } from 'node:fs';

const adapter = readFileSync('src/services/market-data/MarketDataAdapter.ts', 'utf8');
const types = readFileSync('src/services/market-data/marketDataTypes.ts', 'utf8');
const index = readFileSync('src/services/market-data/index.ts', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

const checks = [
  [adapter.includes('export interface MarketDataAdapter'), 'MarketDataAdapter interface is required'],
  [adapter.includes('subscribe('), 'adapter must expose a subscription boundary'],
  [adapter.includes('AbortSignal'), 'adapter must accept AbortSignal for lifecycle cancellation'],
  [types.includes('export interface MarketPriceObservation'), 'market observation type is required'],
  [types.includes('readonly price: DecimalString'), 'market price must reuse DecimalString truth representation'],
  [types.includes('readonly observedAt: string'), 'market observation receipt time must remain explicit'],
  [types.includes('readonly sourceTimestamp: string | null'), 'provider/source timestamp must remain explicit and nullable'],
  [types.includes("'disconnected'"), 'connection state must represent disconnection explicitly'],
  [index.includes("export * from './MarketDataAdapter'"), 'market-data service barrel must export adapter'],
  [pkg.scripts?.['verify:p15:1-market-data-adapter-interface'], 'package verifier registration is required'],
];
for (const [ok, message] of checks) if (!ok) throw new Error(message);

const combined = `${adapter}\n${types}`;
const forbidden = [
  /new\s+WebSocket\s*\(/,
  /new\s+EventSource\s*\(/,
  /fetch\s*\(/,
  /indexedDB/,
  /Dexie/,
  /JournalTradeMap/,
  /projectJournalTradeVisualizer/,
];
for (const pattern of forbidden) {
  if (pattern.test(combined)) throw new Error(`P15.1 interface foundation must not implement transport/persistence/UI ownership: ${pattern}`);
}

console.log('PASS P15.1 Market Data Adapter interface verifier');
