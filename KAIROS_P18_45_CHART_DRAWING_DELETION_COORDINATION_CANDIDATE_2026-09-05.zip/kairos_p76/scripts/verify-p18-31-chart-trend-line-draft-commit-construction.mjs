import { readFileSync } from 'node:fs';

const source = readFileSync(
  'src/features/chart/chartTrendLineDraftCommitConstruction.ts',
  'utf8',
);
const drawingContract = readFileSync('src/features/chart/chartDrawingContract.ts', 'utf8');
const draftOwner = readFileSync(
  'src/features/chart/chartTrendLineDraftAnchorCollection.ts',
  'utf8',
);
const interactionReducer = readFileSync(
  'src/features/chart/chartDrawingInteractionReducer.ts',
  'utf8',
);
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync(
  'tests/chart-trend-line-draft-commit-construction.test.ts',
  'utf8',
);
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.31 trend-line draft commit construction verification FAIL: ${message}`);
  process.exit(1);
};

for (const required of [
  'constructChartTrendLineDrawingFromDraft(',
  'drawingId: ChartDrawingId',
  'anchors: ChartTrendLineDraftAnchors',
  'if (anchors.length !== 2) return null',
  'return defineChartDrawing({',
  'id: drawingId',
  "kind: 'trend-line'",
  'start: anchors[0]',
  'end: anchors[1]',
]) {
  if (!source.includes(required)) fail(`missing construction evidence: ${required}`);
}

for (const required of [
  'export interface ChartTrendLineDrawing',
  'readonly id: ChartDrawingId',
  "readonly kind: 'trend-line'",
  'readonly start: ChartDrawingAnchor',
  'readonly end: ChartDrawingAnchor',
]) {
  if (!drawingContract.includes(required)) fail(`P18.1 drawing truth owner regressed: ${required}`);
}

for (const required of [
  'export type ChartTrendLineDraftAnchors =',
  '| readonly [ChartDrawingAnchor, ChartDrawingAnchor]',
]) {
  if (!draftOwner.includes(required)) fail(`P18.28R1 draft owner regressed: ${required}`);
}

if (!interactionReducer.includes("case 'commit-drawing':")) {
  fail('P18.23 commit transition vocabulary regressed');
}

if (!index.includes('constructChartTrendLineDrawingFromDraft')) {
  fail('chart feature export for P18.31 construction is missing');
}

if (
  packageJson.scripts?.['verify:p18:31-chart-trend-line-draft-commit-construction'] !==
  'node scripts/verify-p18-31-chart-trend-line-draft-commit-construction.mjs'
) {
  fail('P18.31 package verifier script missing');
}

for (const token of [
  'constructs the P18.1 committed trend-line shape from exactly two draft anchors',
  'fails closed for an empty draft instead of inventing committed drawing truth',
  'fails closed for a one-anchor draft instead of inventing a second anchor',
  'uses the caller-supplied drawing identity and leaves draft-anchor evidence unchanged',
]) {
  if (!test.includes(token)) fail(`runtime test does not pin behavior: ${token}`);
}

for (const forbidden of [
  'randomUUID',
  'crypto.',
  'dispatch(',
  'subscribeClick(',
  'unsubscribeClick(',
  'coordinateToPrice(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.delete(',
  'riskReward',
  'lightweight-charts',
]) {
  if (source.includes(forbidden)) fail(`construction crossed protected boundary: ${forbidden}`);
}

console.log('P18.31 chart trend-line draft commit construction verification passed.');
