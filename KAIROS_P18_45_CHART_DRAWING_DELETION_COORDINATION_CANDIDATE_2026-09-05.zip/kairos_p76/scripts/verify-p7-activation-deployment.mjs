import fs from 'node:fs';

const required = [
  'src/services/activation/activationDeployment.ts',
  'src/features/activation/ActivationBootstrap.tsx',
  'src/vite-env.d.ts',
  '.env.example',
  'docs/ACTIVATION_SERVICE_CONTRACT.md',
  'tests/activation-deployment.test.ts',
];
for (const file of required) {
  if (!fs.existsSync(file)) throw new Error(`P7.7 missing required file: ${file}`);
}

const deployment = fs.readFileSync('src/services/activation/activationDeployment.ts', 'utf8');
const bootstrap = fs.readFileSync('src/features/activation/ActivationBootstrap.tsx', 'utf8');
const envExample = fs.readFileSync('.env.example', 'utf8');
const contract = fs.readFileSync('docs/ACTIVATION_SERVICE_CONTRACT.md', 'utf8');

const checks = [
  [deployment.includes("url.protocol !== 'https:'"), 'deployment config must require HTTPS'],
  [deployment.includes('url.username') && deployment.includes('url.password'), 'deployment config must reject URL credentials'],
  [deployment.includes('url.search') && deployment.includes('url.hash'), 'deployment config must reject query/hash credential decoration'],
  [bootstrap.includes('parseActivationDeploymentConfig'), 'bootstrap must consume the centralized deployment validator'],
  [envExample.includes('example.invalid'), 'example endpoint must remain non-production'],
  [contract.includes('VITE_ values are visible in the browser bundle') || contract.includes('Vite exposes `VITE_` values'), 'deployment contract must state that VITE values are public'],
  [contract.includes('Deny by default') || contract.includes('Deny by Default') || contract.includes('deny by default'), 'server contract must require default deny'],
  [contract.includes('ECDSA P-256 / SHA-256'), 'server contract must bind the receipt proof algorithm'],
  [contract.includes('Content Security Policy `connect-src`'), 'deployment contract must cover fetch CSP'],
  [!envExample.match(/PRIVATE|SIGNING|SECRET/i), 'client env example must not contain secret/signing configuration'],
];

for (const [ok, message] of checks) {
  if (!ok) throw new Error(`P7.7 contract failed: ${message}`);
}

console.log('P7.7 activation deployment contract: PASS');
