import { mkdtempSync, writeFileSync, rmSync, copyFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

const verifier = resolve('scripts/verify-p1-lock.mjs');
const projectPackage = JSON.parse(await import('node:fs').then(({ readFileSync }) => readFileSync('package.json', 'utf8')));

const allDeps = {
  ...(projectPackage.dependencies ?? {}),
  ...(projectPackage.devDependencies ?? {}),
};

function makeLock({ mutateRoot = false, mutateVersion = false, omitIntegrity = false } = {}) {
  const packages = {
    '': {
      name: projectPackage.name,
      version: projectPackage.version,
      dependencies: { ...(projectPackage.dependencies ?? {}) },
      devDependencies: { ...(projectPackage.devDependencies ?? {}) },
    },
  };

  for (const [name, version] of Object.entries(allDeps)) {
    packages[`node_modules/${name}`] = {
      version,
      resolved: `https://registry.npmjs.org/${name}/-/${name.split('/').at(-1)}-${version}.tgz`,
      integrity: 'sha512-test-fixture',
    };
  }

  if (mutateRoot) {
    packages[''].dependencies = { ...(packages[''].dependencies ?? {}), react: '0.0.0-test' };
  }
  if (mutateVersion) {
    packages['node_modules/react'].version = '0.0.0-test';
  }
  if (omitIntegrity) {
    delete packages['node_modules/react'].integrity;
  }

  return {
    name: projectPackage.name,
    version: projectPackage.version,
    lockfileVersion: 3,
    requires: true,
    packages,
  };
}

function runFixture(lock) {
  const dir = mkdtempSync(join(tmpdir(), 'kairos-p1-lock-test-'));
  try {
    writeFileSync(join(dir, 'package.json'), JSON.stringify(projectPackage, null, 2));
    if (lock) writeFileSync(join(dir, 'package-lock.json'), JSON.stringify(lock, null, 2));
    const result = spawnSync(process.execPath, [verifier], { cwd: dir, encoding: 'utf8' });
    return { code: result.status, output: `${result.stdout ?? ''}${result.stderr ?? ''}` };
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}

const cases = [
  ['missing lock => HOLD', null, 2],
  ['matching fixture => PASS', makeLock(), 0],
  ['root manifest drift => FAIL', makeLock({ mutateRoot: true }), 1],
  ['direct version drift => FAIL', makeLock({ mutateVersion: true }), 1],
  ['missing integrity => FAIL', makeLock({ omitIntegrity: true }), 1],
];

for (const [label, lock, expected] of cases) {
  const result = runFixture(lock);
  if (result.code !== expected) {
    console.error(`${label}: expected ${expected}, got ${result.code}\n${result.output}`);
    process.exit(1);
  }
}

console.log(`P1 lock verifier tests: PASS (${cases.length} cases)`);
