import { access, readFile } from 'node:fs/promises';
import { join } from 'node:path';

const root = new URL('../', import.meta.url);
const manifestUrl = new URL('../public/manifest.webmanifest', import.meta.url);
const manifest = JSON.parse(await readFile(manifestUrl, 'utf8'));
const indexHtml = await readFile(new URL('../index.html', import.meta.url), 'utf8');

const expected = {
  id: '/',
  name: 'Kairos Trading Journal',
  short_name: 'Kairos',
  start_url: '/',
  scope: '/',
  display: 'standalone',
  background_color: '#070b12',
  theme_color: '#070b12',
};

for (const [key, value] of Object.entries(expected)) {
  if (manifest[key] !== value) throw new Error(`P4.1 manifest ${key} must equal ${JSON.stringify(value)}.`);
}

if (!Array.isArray(manifest.icons)) throw new Error('P4.1 manifest must declare icons.');
const requiredIcons = [
  ['/icons/kairos-icon-192.png', '192x192', 'any'],
  ['/icons/kairos-icon-512.png', '512x512', 'any'],
  ['/icons/kairos-icon-maskable-512.png', '512x512', 'maskable'],
];
for (const [src, sizes, purpose] of requiredIcons) {
  const icon = manifest.icons.find((candidate) => candidate.src === src);
  if (!icon || icon.sizes !== sizes || icon.type !== 'image/png' || icon.purpose !== purpose) {
    throw new Error(`P4.1 manifest icon contract missing for ${src}.`);
  }
}

if (!/<link\s+rel="manifest"\s+href="\/manifest\.webmanifest"\s*\/?>/i.test(indexHtml)) {
  throw new Error('P4.1 index must link the web app manifest.');
}
if (!/<link\s+rel="apple-touch-icon"[^>]+href="\/icons\/apple-touch-icon\.png"/i.test(indexHtml)) {
  throw new Error('P4.1 index must link the Apple touch icon.');
}
if (!/<meta\s+name="theme-color"\s+content="#070b12"\s*\/?>/i.test(indexHtml)) {
  throw new Error('P4.1 document theme-color must match Kairos Depth launch color.');
}

function pngDimensions(buffer) {
  const signature = '89504e470d0a1a0a';
  if (buffer.subarray(0, 8).toString('hex') !== signature) throw new Error('Icon is not a PNG file.');
  return { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
}

const iconFiles = [
  ['public/icons/kairos-icon-192.png', 192],
  ['public/icons/kairos-icon-512.png', 512],
  ['public/icons/kairos-icon-maskable-512.png', 512],
  ['public/icons/apple-touch-icon.png', 180],
];
for (const [relativePath, expectedSize] of iconFiles) {
  const buffer = await readFile(new URL(`../${relativePath}`, import.meta.url));
  const { width, height } = pngDimensions(buffer);
  if (width !== expectedSize || height !== expectedSize) {
    throw new Error(`${relativePath} must be ${expectedSize}x${expectedSize}; received ${width}x${height}.`);
  }
}

// When this verifier runs after the production build, also prove Vite copied the PWA assets.
const distPath = new URL('../dist/', import.meta.url);
try {
  await access(distPath);
  await access(new URL('../dist/manifest.webmanifest', import.meta.url));
  for (const [relativePath] of iconFiles) {
    const distRelative = relativePath.replace(/^public\//, 'dist/');
    await access(new URL(`../${distRelative}`, import.meta.url));
  }
} catch (error) {
  if (error?.code !== 'ENOENT') throw error;
  // No dist directory means this is a source-only verification pass.
  try {
    await access(join(new URL('../dist/', import.meta.url).pathname, 'index.html'));
  } catch {}
}

console.log('P4.1 web app manifest / install identity contract: PASS');
