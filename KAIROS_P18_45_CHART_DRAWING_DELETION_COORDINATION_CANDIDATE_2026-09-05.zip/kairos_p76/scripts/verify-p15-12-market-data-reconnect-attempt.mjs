import fs from 'node:fs';
const fail=m=>{console.error(`FAIL P15.12 Market Data reconnect attempt verifier: ${m}`);process.exit(1)};
const p='src/services/market-data/marketDataReconnectAttempt.ts';
if(!fs.existsSync(p))fail('owner missing');
const s=fs.readFileSync(p,'utf8'),b=fs.readFileSync('src/services/market-data/index.ts','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
for(const t of ['resolveMarketDataReconnectIntent','planNextMarketDataReconnect',"kind: 'retry'","kind: 'stop'","kind: 'invalid'","'attempt-limit'","'intentional-close'","'terminal-failure'"])
  if(!s.includes(t))fail(`missing ${t}`);
for(const t of ['scheduleMarketDataReconnect','coordinateNextMarketDataReconnect','Math.random(','setTimeout(','setInterval(','WebSocket','CloseEvent','fetch(','indexedDB','Dexie'])
  if(s.includes(t))fail(`forbidden ownership token ${t}`);
if(!b.includes("export * from './marketDataReconnectAttempt';"))fail('barrel export missing');
if(pkg.scripts?.['verify:p15:12-market-data-reconnect-attempt']!=='node scripts/verify-p15-12-market-data-reconnect-attempt.mjs')fail('package verifier missing');
console.log('PASS P15.12 Market Data reconnect attempt verifier');
