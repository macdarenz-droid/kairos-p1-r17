import fs from 'node:fs';

const sourceFile = 'src/domain/calculations/tradeMetrics.ts';
const testFile = 'tests/trade-metrics-net-pnl-evidence.test.ts';
for (const file of [sourceFile, testFile]) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const source = fs.readFileSync(sourceFile, 'utf8');
for (const token of [
  'TradeMetricsNetPnlCurrencyInput',
  'grossPnlCurrency',
  'calculateComparableNetPnl',
  'netPnl: DecimalString | null',
  'netPnlCurrency: string | null',
  'hasNetPnl: boolean',
  'hasNetPnl: netPnl !== null',
  "'invalid-net-pnl-decimal'",
]) {
  if (!source.includes(token)) throw new Error(`Missing P11.21 contract: ${token}`);
}

if (!source.includes('grossPnl !== null && totalFees !== null')) {
  throw new Error('P11.21 must require authoritative gross P&L and fee evidence before composition.');
}
if (!source.includes('netPnlCurrencyInput?.grossPnlCurrency ?? null')) {
  throw new Error('P11.21 must not infer missing gross P&L currency evidence.');
}
if (!source.includes('pnlPercent:') || !source.includes('hasPnlPercent:')) {
  throw new Error('P11.21 must preserve the P&L percentage contract.');
}
if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error('P11.21 must compose existing decimal owners, not native numeric arithmetic.');
}
for (const forbidden of [
  'exchangeRate',
  'currencyConversion',
  'marketType',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
]) {
  if (source.includes(forbidden)) throw new Error(`P11.21 out-of-scope owner detected: ${forbidden}`);
}

console.log('P11.21 TradeMetrics net P&L evidence wiring verification PASS');
