import { readFileSync } from 'node:fs';

const source = readFileSync('src/application/visual-pnl/aggregationEligibility.ts', 'utf8');
if (!source.includes('amounts: readonly [];')) throw new Error('P13.4R1 must preserve the blocked-result readonly empty tuple contract');
if (!source.includes('Object.freeze([] as [])')) throw new Error('P13.4R1 must construct blocked amounts as an explicit empty tuple');
if (source.includes('amounts: readonly DecimalString[];\n      reason: VisualPnlAggregationBlockReason;')) throw new Error('P13.4R1 must not weaken the blocked-result contract to a general readonly array');
console.log('P13.4R1 empty amounts tuple verifier: PASS');
