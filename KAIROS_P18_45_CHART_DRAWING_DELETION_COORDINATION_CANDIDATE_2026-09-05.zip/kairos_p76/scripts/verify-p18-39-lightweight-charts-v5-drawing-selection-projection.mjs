import fs from 'node:fs';

const read = (path) => fs.readFileSync(path, 'utf8');
const fail = (message) => {
  console.error(`P18.39 Lightweight Charts v5 drawing selection projection verification FAIL: ${message}`);
  process.exit(1);
};

const source = read('src/features/chart/lightweightChartsV5DrawingSelectionProjection.ts');
const primitive = read('src/features/chart/lightweightChartsV5TrendLinePrimitive.ts');
const test = read('tests/lightweight-charts-v5-drawing-selection-projection.test.ts');
const index = read('src/features/chart/index.ts');
const pkg = read('package.json');

for (const token of [
  'hoveredInfo?: LightweightChartsV5DrawingSelectionHoveredInfo',
  "hoveredInfo.sourceKind !== 'series-primitive'",
  "hoveredInfo.objectKind !== 'primitive'",
  "typeof hoveredInfo.objectId !== 'string'",
  'drawing.id === hoveredInfo.objectId',
  "kind: 'drawing-selection'",
]) {
  if (!source.includes(token)) fail(`missing projection invariant: ${token}`);
}
if (!primitive.includes('externalId: hit.id')) {
  fail('canonical P18.13 primitive externalId identity source is missing');
}
for (const token of [
  'projectLightweightChartsV5DrawingSelection',
  'LightweightChartsV5DrawingSelectionMouseEvent',
  'ChartDrawingSelectionProjection',
]) {
  if (!index.includes(token)) fail(`index export missing: ${token}`);
}
for (const token of [
  'series-primitive drawing hit',
  'objectId is not a string',
  'not owned by a series primitive',
  'non-primitive target kinds',
  'current drawing snapshot',
]) {
  if (!test.includes(token)) fail(`runtime regression evidence missing: ${token}`);
}
if (!pkg.includes('verify:p18:39-lightweight-charts-v5-drawing-selection-projection')) {
  fail('package verifier registration is missing');
}
for (const forbidden of [
  'subscribeClick',
  'unsubscribeClick',
  'subscribeCrosshairMove',
  'dispatch(',
  'createChartDrawingInteractionPort',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.add(',
  '.delete(',
  'riskReward',
  'risk-reward',
]) {
  if (source.includes(forbidden)) fail(`projection crossed protected boundary: ${forbidden}`);
}

console.log('P18.39 Lightweight Charts v5 drawing selection projection verification passed.');
