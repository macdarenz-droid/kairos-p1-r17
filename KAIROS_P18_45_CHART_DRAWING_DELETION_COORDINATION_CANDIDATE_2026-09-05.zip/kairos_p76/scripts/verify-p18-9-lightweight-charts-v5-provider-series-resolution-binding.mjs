import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/lightweightChartsV5ModuleAdapter.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');

for (const required of [
  'LightweightChartsV5DriverBinding',
  'createLightweightChartsV5DriverBinding',
  'resolveSeries(handle: ChartEngineSeriesHandle)',
  "throw new Error('chart-series-handle-unknown')",
  'seriesLookup.delete(handle)',
  'seriesLookup.clear()',
  'return createLightweightChartsV5DriverBinding(module).driver',
]) {
  if (!source.includes(required)) throw new Error(`P18.9 missing required provider-series resolution evidence: ${required}`);
}

for (const forbidden of [
  'attachPrimitive(',
  'detachPrimitive(',
  'timeToCoordinate(',
  'priceToCoordinate(',
  'useBitmapCoordinateSpace(',
  'hitTest(',
  'localStorage',
  'IndexedDB',
  'Dexie',
  'fetch(',
  'WebSocket',
  'risk-reward',
]) {
  if (source.includes(forbidden)) throw new Error(`P18.9 crossed controlled scope: ${forbidden}`);
}

if (!index.includes('createLightweightChartsV5DriverBinding')) {
  throw new Error('P18.9 chart index export missing');
}

console.log('P18.9 Lightweight Charts v5 provider series resolution binding verification passed.');
