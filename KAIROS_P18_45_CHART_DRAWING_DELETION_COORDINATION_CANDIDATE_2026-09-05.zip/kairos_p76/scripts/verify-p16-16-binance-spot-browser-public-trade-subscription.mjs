import { readFileSync } from 'node:fs';

const path = 'src/services/market-data/providers/binance/binanceSpotBrowserPublicTradeSubscription.ts';
const source = readFileSync(path, 'utf8');
const barrel = readFileSync('src/services/market-data/index.ts', 'utf8');

const required = [
  'connectBinanceSpotBrowserStream',
  'withBinanceSpotPublicStreamLifecycle',
  'subscribeBinanceSpotPublicTradeStream',
  'subscribeBinanceSpotBrowserPublicTradeStream',
];
for (const token of required) {
  if (!source.includes(token)) throw new Error(`P16.16 missing required ownership token: ${token}`);
}

const forbidden = [
  'new WebSocket', 'setTimeout(', 'setInterval(', 'Date.now(', 'Math.random(',
  'indexedDB', 'localStorage', 'sessionStorage', 'fetch(', 'AbortController',
];
for (const token of forbidden) {
  if (source.includes(token)) throw new Error(`P16.16 illegally owns ${token}`);
}

if (!barrel.includes("./providers/binance/binanceSpotBrowserPublicTradeSubscription")) {
  throw new Error('P16.16 browser subscription is not exported from market-data barrel');
}

console.log('P16.16 Binance Spot browser public trade subscription verifier PASS');
