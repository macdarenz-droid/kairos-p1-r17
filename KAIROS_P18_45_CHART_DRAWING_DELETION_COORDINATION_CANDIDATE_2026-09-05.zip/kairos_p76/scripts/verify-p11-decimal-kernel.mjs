import fs from 'node:fs';

const required = [
  'src/domain/calculations/decimalKernel.ts',
  'src/domain/calculations/index.ts',
  'tests/decimal-kernel.test.ts',
];
for (const file of required) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
if (pkg.dependencies?.['decimal.js'] !== '10.6.0') {
  throw new Error('decimal.js must be a locked production dependency');
}

const src = fs.readFileSync('src/domain/calculations/decimalKernel.ts', 'utf8');
for (const token of [
  'Decimal.clone',
  'precision: 40',
  'parseDecimalString',
  'division-by-zero',
  'decimalAdd',
  'decimalSubtract',
  'decimalMultiply',
  'decimalDivide',
  'decimalSum',
]) {
  if (!src.includes(token)) throw new Error(`Missing decimal kernel contract: ${token}`);
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(/.test(src)) {
  throw new Error('Native numeric coercion forbidden in decimal kernel');
}

console.log('P11.1R2 decimal calculation kernel verification PASS');
