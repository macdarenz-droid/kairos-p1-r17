import fs from 'node:fs';

const fail = (message) => {
  console.error(`FAIL P16.6 Binance Spot public stream event verifier: ${message}`);
  process.exit(1);
};

const owner = 'src/services/market-data/providers/binance/binanceSpotPublicStreamEvent.ts';
const barrel = 'src/services/market-data/index.ts';
const test = 'tests/binance-spot-public-stream-event.test.ts';

for (const path of [owner, barrel, test]) {
  if (!fs.existsSync(path)) fail(`missing ${path}`);
}

const source = fs.readFileSync(owner, 'utf8');
const index = fs.readFileSync(barrel, 'utf8');

for (const token of [
  'classifyBinanceSpotPublicStreamEvent',
  "'serverShutdown'",
  "'server-shutdown'",
  "'trade'",
  "'other'",
  'Number.isSafeInteger(eventTime)',
]) {
  if (!source.includes(token)) fail(`missing event-classification token ${token}`);
}

for (const forbidden of [
  'new WebSocket(',
  'fetch(',
  'apiKey',
  'secret',
  'setTimeout(',
  'setInterval(',
  'Math.random(',
  'Date.now(',
  'indexedDB',
  'Dexie',
]) {
  if (source.includes(forbidden)) fail(`forbidden ownership token ${forbidden}`);
}

if (!index.includes("export * from './providers/binance/binanceSpotPublicStreamEvent';")) {
  fail('event classifier is not exported from market-data barrel');
}

console.log('PASS P16.6 Binance Spot public stream event verifier');
