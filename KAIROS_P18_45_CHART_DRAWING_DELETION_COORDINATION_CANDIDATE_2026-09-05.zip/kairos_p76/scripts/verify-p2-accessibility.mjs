import fs from 'node:fs';

const contract = fs.readFileSync('src/design-system/accessibility.ts', 'utf8');
const css = fs.readFileSync('src/design-system/accessibility.css', 'utf8');
const main = fs.readFileSync('src/main.tsx', 'utf8');
const fail = (message) => { console.error(`P2.3 accessibility contract: FAIL — ${message}`); process.exit(1); };

for (const required of ['minimumCssPixels: 24', 'preferredControlCssPixels: 44', "selector: ':focus-visible'", 'requiresTextEquivalent: true', 'colorAloneIsInsufficient: true']) {
  if (!contract.includes(required)) fail(`missing ${required}`);
}
for (const required of [':focus-visible', '@media (prefers-reduced-motion: reduce)', 'var(--kairos-motion-instant)', 'min-block-size: var(--kairos-control-md)']) {
  if (!css.includes(required)) fail(`CSS missing ${required}`);
}
if (!main.includes("import './design-system/accessibility.css';")) fail('accessibility CSS is not bootstrapped');
if (/(#[0-9a-f]{3,8}\b|\brgba?\(|\bhsla?\()/i.test(css)) fail('concrete theme color found before P3');
console.log('P2.3 accessibility/interaction contract: PASS');
