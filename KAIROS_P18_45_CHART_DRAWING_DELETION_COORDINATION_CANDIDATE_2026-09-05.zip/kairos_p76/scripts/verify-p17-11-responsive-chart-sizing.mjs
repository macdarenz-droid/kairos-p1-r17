import fs from 'node:fs';
const production=fs.readFileSync('src/features/chart/lightweightChartsV5ProductionRenderer.ts','utf8');
const adapter=fs.readFileSync('src/features/chart/lightweightChartsV5ModuleAdapter.ts','utf8');
if(!production.includes('autoSize: true')) throw new Error('production chart must opt into vendor autoSize');
if(!adapter.includes('readonly autoSize?: boolean')) throw new Error('module boundary must type the sizing option');
for(const token of ['ResizeObserver','window.addEventListener','setInterval','setTimeout','WebSocket','indexedDB','localStorage']) {
  if(production.includes(token)) throw new Error('P17.11 must not create a second sizing/lifecycle owner: '+token);
}
console.log('P17.11 responsive chart sizing verifier: PASS');
