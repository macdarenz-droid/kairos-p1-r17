import { existsSync, readFileSync } from 'node:fs';

for (const file of [
  'src/features/chart/lightweightChartsV5Package.ts',
  'tests/lightweight-charts-v5-package.test.ts',
  'package.json',
  'package-lock.json',
]) {
  if (!existsSync(file)) throw new Error(`Missing P17.9 file: ${file}`);
}

const source = readFileSync('src/features/chart/lightweightChartsV5Package.ts', 'utf8');
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));
const lock = JSON.parse(readFileSync('package-lock.json', 'utf8'));

for (const token of [
  "from 'lightweight-charts'",
  'createChart',
  'LineSeries',
  'CandlestickSeries',
  'LightweightChartsV5Module',
  'lightweightChartsV5Package',
]) {
  if (!source.includes(token)) throw new Error(`Missing P17.9 token: ${token}`);
}

if (packageJson.dependencies?.['lightweight-charts'] !== '5.2.1') {
  throw new Error('P17.9 requires exact lightweight-charts 5.2.1 dependency');
}
if (lock.packages?.['node_modules/lightweight-charts']?.version !== '5.2.1') {
  throw new Error('P17.9 lockfile does not pin lightweight-charts 5.2.1');
}
if (lock.packages?.['node_modules/lightweight-charts']?.dependencies?.['fancy-canvas'] !== '2.1.0') {
  throw new Error('P17.9 lockfile missing documented lightweight-charts dependency');
}

for (const forbidden of [
  'WebSocket',
  'setTimeout(',
  'setInterval(',
  'indexedDB',
  'localStorage',
  'Dexie',
  'decimal.js',
  'subscribeBinance',
  'executeMarketDataReconnect',
  'createTrade',
  'updateTrade',
  'deleteTrade',
  'historicalUpdate',
  'createSeriesMarkers',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P17.9 ownership violation: ${forbidden}`);
  }
}

console.log('P17.9 Lightweight Charts v5 package binding verifier PASS');
