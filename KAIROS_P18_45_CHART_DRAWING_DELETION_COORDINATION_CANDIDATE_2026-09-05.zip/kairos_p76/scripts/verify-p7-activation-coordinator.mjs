import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const coordinatorPath = path.join(root, 'src/services/activation/ActivationCoordinator.ts');
const indexPath = path.join(root, 'src/services/activation/index.ts');
const testPath = path.join(root, 'tests/activation-coordinator.test.ts');

for (const required of [coordinatorPath, indexPath, testPath]) {
  if (!fs.existsSync(required)) throw new Error(`P7.5 missing required file: ${path.relative(root, required)}`);
}

const coordinator = fs.readFileSync(coordinatorPath, 'utf8');
const index = fs.readFileSync(indexPath, 'utf8');

for (const required of [
  'class ActivationCoordinator',
  'loadVerifiedPersistedActivation',
  'validateInvite',
  'verifyReceipt',
  'saveServerIssuedReceipt',
  "type: 'START_VALIDATION'",
  "type: 'VALIDATION_FINISHED'",
  "type: 'OFFLINE_WITH_VERIFIED_RECEIPT'",
  'validationInFlight',
]) {
  if (!coordinator.includes(required)) throw new Error(`P7.5 coordinator contract missing: ${required}`);
}

const verifyIndex = coordinator.indexOf('verifyReceipt(remoteResult.receipt)');
const saveIndex = coordinator.indexOf('saveServerIssuedReceipt(proofResult.receipt)');
const successIndex = coordinator.indexOf('const verifiedSuccess');
if (!(verifyIndex >= 0 && saveIndex > verifyIndex && successIndex > saveIndex)) {
  throw new Error('P7.5 activation sequence must verify proof, then persist, then report success.');
}

for (const forbidden of [
  'masterCode',
  'master-code',
  'inviteCodes',
  'BEGIN PRIVATE KEY',
  '.sign(',
  'localStorage',
  'sessionStorage',
]) {
  if (coordinator.includes(forbidden)) throw new Error(`P7.5 coordinator contains forbidden authority/persistence marker: ${forbidden}`);
}

if (!index.includes("from './ActivationCoordinator'")) {
  throw new Error('P7.5 coordinator is not exported by the activation boundary.');
}

console.log('PASS: P7.5 activation coordinator enforces verified startup restore and verify -> persist -> success ordering.');
