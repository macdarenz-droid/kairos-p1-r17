import { readFileSync } from 'node:fs';
const source = readFileSync('src/application/visual-pnl/cumulativeRealizedPnl.ts', 'utf8');
const index = readFileSync('src/application/visual-pnl/index.ts', 'utf8');
const tests = readFileSync('tests/visual-pnl-cumulative-realized-pnl.test.ts', 'utf8');
for (const required of ['decimalAdd','VisualPnlProgressSeriesProjection','cumulativeAmount','dailyAmount','invalid-cumulative-decimal','This is not account equity']) {
  if (!source.includes(required)) throw new Error(`P13.18 contract missing: ${required}`);
}
if (!index.includes("export * from './cumulativeRealizedPnl'")) throw new Error('P13.18 export missing');
for (const required of ['single-currency daily results exactly','mixed-currency blocking without FX','instead of treating them as zero']) {
  if (!tests.includes(required)) throw new Error(`P13.18 test evidence missing: ${required}`);
}
for (const forbidden of ['Number(','parseFloat(','parseInt(','new Decimal','Intl.','new Date(','indexedDB','Dexie','localStorage','sessionStorage','exchangeRate']) {
  if (source.includes(forbidden)) throw new Error(`P13.18 ownership violation: ${forbidden}`);
}
console.log('PASS P13.18 cumulative realized P&L semantics verifier');
