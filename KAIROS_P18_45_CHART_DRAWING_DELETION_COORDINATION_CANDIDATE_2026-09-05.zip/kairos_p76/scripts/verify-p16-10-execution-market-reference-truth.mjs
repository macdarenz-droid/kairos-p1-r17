import { readFileSync } from 'node:fs';
const source = readFileSync('src/application/market-reference/executionMarketReferenceTruth.ts','utf8');
for (const token of ['JournalExecutionTruth','ExternalMarketReferenceTruth','projectExecutionMarketReferenceTruth',"reconciliation: 'none'",'mayOverwriteExecution: false','referenceKind']) {
  if (!source.includes(token)) throw new Error(`P16.10 missing ${token}`);
}
for (const token of ['indexedDB','Dexie','put(','add(','update(','delete(','fetch(','setTimeout(','setInterval(','Date.now(','Math.random(']) {
  if (source.includes(token)) throw new Error(`P16.10 forbidden ownership token ${token}`);
}
if (source.includes('execution.price =') || source.includes('marketObservation.price =')) throw new Error('P16.10 must not mutate truth inputs');
console.log('PASS P16.10 execution vs market-reference truth contract verifier');
