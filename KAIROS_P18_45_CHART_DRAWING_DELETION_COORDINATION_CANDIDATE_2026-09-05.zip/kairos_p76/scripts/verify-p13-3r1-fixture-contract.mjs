import { readFileSync } from 'node:fs';

const test = readFileSync('tests/journal-visual-pnl-presentation.test.tsx','utf8');
if (!test.includes('plans: []')) throw new Error('P13.3R1 JournalHistoryEntry fixture must include plans: []');
if (!test.includes("function entry(outcome: JournalHistoryEntry['visualPnl']): JournalHistoryEntry")) throw new Error('P13.3R1 fixture must remain typed as JournalHistoryEntry');
console.log('P13.3R1 fixture contract verifier: PASS');
