import { existsSync, readFileSync } from 'node:fs';

for (const file of [
  'src/features/chart/chartEngineDriver.ts',
  'tests/chart-engine-driver.test.ts',
]) {
  if (!existsSync(file)) throw new Error(`Missing P17.5 file: ${file}`);
}

const source = readFileSync('src/features/chart/chartEngineDriver.ts', 'utf8');

for (const token of [
  'ChartEngineDriver',
  'createChart(container: HTMLElement)',
  'addPriceLineSeries()',
  'addCandlestickSeries()',
  'removeSeries(series: ChartEngineSeriesHandle)',
  'createChartEnginePortFromDriver',
  'clearActiveSeries()',
  'chart.remove()',
]) {
  if (!source.includes(token)) throw new Error(`Missing P17.5 token: ${token}`);
}

for (const forbidden of [
  'indexedDB',
  'localStorage',
  'Dexie',
  'WebSocket',
  'setTimeout(',
  'setInterval(',
  'Math.random',
  'subscribeBinance',
  'executeMarketDataReconnect',
  'createTrade',
  'updateTrade',
  'deleteTrade',
  'lightweight-charts',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P17.5 ownership violation: ${forbidden}`);
  }
}

console.log('P17.5 chart engine driver adapter verifier PASS');
