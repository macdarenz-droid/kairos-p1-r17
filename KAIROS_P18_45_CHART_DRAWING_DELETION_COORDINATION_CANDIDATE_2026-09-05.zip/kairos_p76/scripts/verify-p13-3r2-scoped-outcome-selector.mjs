import { readFileSync } from 'node:fs';

const test = readFileSync('tests/journal-visual-pnl-presentation.test.tsx','utf8');

if (!test.includes('plans: []')) {
  throw new Error('P13.3R2 must preserve the repaired JournalHistoryEntry fixture contract');
}
if (!test.includes('container.querySelector(`[data-outcome="${kind}"]`)')) {
  throw new Error('P13.3R2 must scope outcome selection to the authoritative data-outcome element');
}
if (test.includes("screen.getByText(label).closest('[data-outcome]')")) {
  throw new Error('P13.3R2 must not use the ambiguous global label lookup');
}
if (!test.includes('expect(outcome).toHaveTextContent(label)')) {
  throw new Error('P13.3R2 must still assert the explicit outcome label');
}

console.log('P13.3R2 scoped selector repair verifier: PASS');
