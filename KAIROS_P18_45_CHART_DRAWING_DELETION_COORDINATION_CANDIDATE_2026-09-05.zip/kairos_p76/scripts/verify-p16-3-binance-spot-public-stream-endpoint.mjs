import fs from 'node:fs';

const fail = (message) => {
  console.error(`FAIL P16.3 Binance Spot public stream endpoint verifier: ${message}`);
  process.exit(1);
};

const owner = 'src/services/market-data/providers/binance/binanceSpotPublicStreamEndpoint.ts';
const barrel = 'src/services/market-data/index.ts';
const test = 'tests/binance-spot-public-stream-endpoint.test.ts';

for (const path of [owner, barrel, test]) {
  if (!fs.existsSync(path)) fail(`missing ${path}`);
}

const source = fs.readFileSync(owner, 'utf8');
const index = fs.readFileSync(barrel, 'utf8');

for (const token of [
  "BINANCE_SPOT_PUBLIC_STREAM_HOST = 'stream.binance.com'",
  "BINANCE_SPOT_PUBLIC_STREAM_PORTS = ['9443', '443']",
  'wss://${BINANCE_SPOT_PUBLIC_STREAM_HOST}:${port}/ws/${stream.streamName}',
  'describeBinanceSpotPublicRawStreamEndpoint',
]) {
  if (!source.includes(token)) fail(`missing endpoint semantic token ${token}`);
}

for (const forbidden of [
  'new WebSocket(',
  'fetch(',
  'apiKey',
  'secret',
  'setTimeout(',
  'setInterval(',
  'Math.random(',
  'Date.now(',
  'indexedDB',
  'Dexie',
]) {
  if (source.includes(forbidden)) fail(`forbidden ownership token ${forbidden}`);
}

if (!index.includes("export * from './providers/binance/binanceSpotPublicStreamEndpoint';")) {
  fail('endpoint owner is not exported from market-data barrel');
}

console.log('PASS P16.3 Binance Spot public stream endpoint verifier');
