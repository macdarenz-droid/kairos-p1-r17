import { readFileSync } from 'node:fs';

const contract = readFileSync(new URL('../src/features/chart/chartDrawingInteractionContract.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/features/chart/index.ts', import.meta.url), 'utf8');

const required = [
  "import type { ChartDrawingId, ChartDrawingKind } from './chartDrawingContract'",
  'export type ChartDrawingInteractionStatus =',
  "| 'idle'",
  "| 'tool-selected'",
  "| 'drawing'",
  "| 'preview'",
  "| 'committed'",
  "| 'cancelled'",
  "| 'editing'",
  "| 'deleting'",
  'export type ChartDrawingInteractionState =',
  "readonly status: 'tool-selected'",
  'readonly tool: ChartDrawingKind',
  "readonly status: 'editing'",
  'readonly drawingId: ChartDrawingId',
  'INITIAL_CHART_DRAWING_INTERACTION_STATE',
  'defineChartDrawingInteractionState',
];
for (const token of required) {
  if (!contract.includes(token)) throw new Error(`P18.21 interaction contract missing: ${token}`);
}
for (const forbidden of [
  'boolean',
  'lightweight-charts',
  'subscribeClick',
  'subscribeCrosshairMove',
  'IndexedDB',
  'Dexie',
  'localStorage',
  'fetch(',
  'WebSocket',
  'riskReward',
  'risk-reward',
]) {
  if (contract.includes(forbidden)) throw new Error(`P18.21 interaction contract owns forbidden concern: ${forbidden}`);
}
if (!index.includes("from './chartDrawingInteractionContract'")) {
  throw new Error('P18.21 chart index does not export interaction-state contract');
}
console.log('P18.21 chart drawing interaction-state contract verification passed.');
