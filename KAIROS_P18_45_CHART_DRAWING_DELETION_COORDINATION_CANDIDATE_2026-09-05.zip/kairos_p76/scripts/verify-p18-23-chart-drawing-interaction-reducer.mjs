import fs from 'node:fs';

const read = (path) => fs.readFileSync(path, 'utf8');
const fail = (message) => {
  console.error(`P18.23 chart drawing interaction reducer verification FAIL: ${message}`);
  process.exit(1);
};

const reducerSource = read('src/features/chart/chartDrawingInteractionReducer.ts');
const stateSource = read('src/features/chart/chartDrawingInteractionContract.ts');
const eventSource = read('src/features/chart/chartDrawingInteractionEvent.ts');
const indexSource = read('src/features/chart/index.ts');
const testSource = read('tests/chart-drawing-interaction-reducer.test.ts');

for (const token of [
  'reduceChartDrawingInteraction',
  "case 'select-tool'",
  "case 'start-drawing'",
  "case 'preview-drawing'",
  "case 'commit-drawing'",
  "case 'cancel-interaction'",
  "case 'start-editing'",
  "case 'start-deleting'",
  "case 'reset-interaction'",
  "state.status === 'idle'",
  "state.status === 'tool-selected'",
  "state.status === 'drawing'",
  "state.status === 'preview'",
]) {
  if (!reducerSource.includes(token)) fail(`missing reducer transition token: ${token}`);
}

if (!reducerSource.includes('return state;') && !reducerSource.includes(': state;')) {
  fail('invalid transition no-op behavior is not explicit');
}

for (const status of [
  "'idle'",
  "'tool-selected'",
  "'drawing'",
  "'preview'",
  "'committed'",
  "'cancelled'",
  "'editing'",
  "'deleting'",
]) {
  if (!stateSource.includes(status)) fail(`P18.21 state vocabulary regressed: ${status}`);
}

for (const event of [
  "'select-tool'",
  "'start-drawing'",
  "'preview-drawing'",
  "'commit-drawing'",
  "'cancel-interaction'",
  "'start-editing'",
  "'start-deleting'",
  "'reset-interaction'",
]) {
  if (!eventSource.includes(event)) fail(`P18.22 event vocabulary regressed: ${event}`);
}

if (!indexSource.includes("from './chartDrawingInteractionReducer'")) {
  fail('chart feature export for interaction reducer is missing');
}

for (const token of [
  "type: 'select-tool'",
  "type: 'start-drawing'",
  "type: 'preview-drawing'",
  "type: 'commit-drawing'",
  "type: 'cancel-interaction'",
  "type: 'reset-interaction'",
  '.toBe(drawing)',
]) {
  if (!testSource.includes(token)) fail(`runtime reducer tests do not pin behavior: ${token}`);
}

for (const forbidden of [
  'lightweight-charts',
  'subscribeCrosshairMove',
  'unsubscribeCrosshairMove',
  'addEventListener',
  'removeEventListener',
  'setPointerCapture',
  'IndexedDB',
  'Dexie',
  '.put(',
  '.add(',
  '.delete(',
  'localStorage',
  'riskReward',
]) {
  if (reducerSource.includes(forbidden)) fail(`reducer crossed protected boundary: ${forbidden}`);
}

console.log('P18.23 chart drawing interaction reducer verification passed.');
