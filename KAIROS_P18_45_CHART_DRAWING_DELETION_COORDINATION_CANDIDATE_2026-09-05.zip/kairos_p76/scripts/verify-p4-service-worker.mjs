import { access, readFile } from 'node:fs/promises';

const sw = await readFile(new URL('../public/sw.js', import.meta.url), 'utf8');
const registration = await readFile(new URL('../src/pwa/serviceWorkerRegistration.ts', import.meta.url), 'utf8');
const main = await readFile(new URL('../src/main.tsx', import.meta.url), 'utf8');

const requiredSwContracts = [
  ['versioned Kairos app-shell cache', /CACHE_PREFIX\s*=\s*['"]kairos-app-shell-/],
  ['install lifecycle', /addEventListener\(['"]install['"]/],
  ['install waitUntil', /install[\s\S]*?waitUntil\(discoverAndCacheAppShell\(\)\)/],
  ['activate lifecycle', /addEventListener\(['"]activate['"]/],
  ['owned-cache cleanup', /startsWith\(CACHE_PREFIX\)/],
  ['navigation offline fallback', /request\.mode\s*===\s*['"]navigate['"][\s\S]*networkFirstNavigation/],
  ['static asset cache boundary', /isStaticAssetRequest/],
  ['explicit update message', /KAIROS_ACTIVATE_UPDATE/],
];
for (const [label, pattern] of requiredSwContracts) {
  if (!pattern.test(sw)) throw new Error(`P4.2 service worker missing ${label}.`);
}

if (/self\.skipWaiting\(\)/.test(sw.replace(/if \(event\.data\?\.type === 'KAIROS_ACTIVATE_UPDATE'\)[\s\S]*?event\.waitUntil\(self\.skipWaiting\(\)\);/, ''))) {
  throw new Error('P4.2 must not force skipWaiting outside the explicit user/app update command path.');
}
if (/clients\.claim\s*\(/i.test(sw)) {
  throw new Error('P4.2 must not claim existing clients automatically; controlled documents keep their current worker until reload.');
}
if (/indexeddb|dexie|localstorage|sessionstorage|websocket|tradeexecution|trademetrics|marketdata/i.test(sw)) {
  throw new Error('P4.2 service worker must own app-shell/static caching only, never Kairos business state.');
}
if (!/navigator\.serviceWorker\.register\(['"]\/sw\.js['"],\s*\{\s*scope:\s*['"]\/['"]\s*\}\)/.test(registration)) {
  throw new Error('P4.2 registration owner must register /sw.js at root scope.');
}
if (!/registration\.waiting/.test(registration) || !/updatefound/.test(registration)) {
  throw new Error('P4.2 registration owner must expose waiting-update state without auto-activating it.');
}
if (!/waiting\.postMessage\(\{\s*type:\s*['"]KAIROS_ACTIVATE_UPDATE['"]\s*\}\)/.test(registration)) {
  throw new Error('P4.2 update activation must be explicit through the waiting worker message contract.');
}
if (!/void registerKairosServiceWorker\(\);/.test(main)) {
  throw new Error('P4.2 app bootstrap must invoke the single service-worker registration owner.');
}

try {
  await access(new URL('../dist/index.html', import.meta.url));
  await access(new URL('../dist/sw.js', import.meta.url));
} catch (error) {
  if (error?.code !== 'ENOENT') throw error;
}

console.log('P4.2 service-worker app-shell / controlled-update contract: PASS');
