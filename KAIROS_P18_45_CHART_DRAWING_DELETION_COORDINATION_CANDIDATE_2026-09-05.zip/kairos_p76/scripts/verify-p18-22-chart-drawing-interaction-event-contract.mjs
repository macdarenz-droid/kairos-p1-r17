import fs from 'node:fs';

const read = (path) => fs.readFileSync(path, 'utf8');
const fail = (message) => {
  console.error(`P18.22 chart drawing interaction-event contract verification FAIL: ${message}`);
  process.exit(1);
};

const eventSource = read('src/features/chart/chartDrawingInteractionEvent.ts');
const stateSource = read('src/features/chart/chartDrawingInteractionContract.ts');
const indexSource = read('src/features/chart/index.ts');
const testSource = read('tests/chart-drawing-interaction-event.test.ts');

for (const token of [
  "readonly type: 'select-tool'",
  "readonly type: 'start-drawing'",
  "readonly type: 'preview-drawing'",
  "readonly type: 'commit-drawing'",
  "readonly type: 'cancel-interaction'",
  "readonly type: 'start-editing'",
  "readonly type: 'start-deleting'",
  "readonly type: 'reset-interaction'",
  'readonly tool: ChartDrawingKind',
  'readonly drawingId: ChartDrawingId',
  'defineChartDrawingInteractionEvent',
]) {
  if (!eventSource.includes(token)) fail(`missing event contract token: ${token}`);
}

for (const status of [
  "'idle'",
  "'tool-selected'",
  "'drawing'",
  "'preview'",
  "'committed'",
  "'cancelled'",
  "'editing'",
  "'deleting'",
]) {
  if (!stateSource.includes(status)) fail(`P18.21 state vocabulary regressed: ${status}`);
}

if (!indexSource.includes("from './chartDrawingInteractionEvent'")) {
  fail('chart feature export for interaction event contract is missing');
}

if (!testSource.includes("type: 'select-tool'") || !testSource.includes("type: 'commit-drawing'")) {
  fail('runtime contract tests do not pin event identity/payload behavior');
}

for (const forbidden of [
  'lightweight-charts',
  'subscribeCrosshairMove',
  'unsubscribeCrosshairMove',
  'IndexedDB',
  'Dexie',
  '.put(',
  '.add(',
  '.delete(',
  'localStorage',
  'riskReward',
]) {
  if (eventSource.includes(forbidden)) fail(`event contract crossed protected boundary: ${forbidden}`);
}

console.log('P18.22 chart drawing interaction-event contract verification passed.');
