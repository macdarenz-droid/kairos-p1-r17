import fs from 'node:fs';

const sourceFile = 'src/domain/calculations/riskPerformanceCalculator.ts';
const testFile = 'tests/risk-performance-calculator.test.ts';
const indexFile = 'src/domain/calculations/index.ts';

for (const file of [sourceFile, testFile, indexFile]) {
  if (!fs.existsSync(file)) {
    throw new Error(`Missing ${file}`);
  }
}

const source = fs.readFileSync(sourceFile, 'utf8');
const index = fs.readFileSync(indexFile, 'utf8');

for (const token of [
  'calculateRiskPerformance',
  'calculateInitialRiskAmount',
  'calculateRMultiple',
  'resultAmount',
  'riskPerUnit',
  'quantity',
  'initialRisk',
  'realizedR',
  "'invalid-decimal'",
  "'zero-initial-risk'",
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P11.13 risk-performance contract: ${token}`);
  }
}

if (!index.includes("export * from './riskPerformanceCalculator';")) {
  throw new Error('P11.13 calculator is not exported from calculation boundary.');
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error(
    'P11.13 must compose existing decimal owners, not native numeric arithmetic.',
  );
}

for (const forbidden of [
  'grossPnl',
  'netPnl',
  'totalFees',
  'pnlPercent',
  'TradeMetrics',
  'TradeRecord',
  'TradePlanRecord',
  'TradeExecutionRecord',
  'TradeFeeRecord',
  'marketType',
  'plannedEntryPrice',
  'plannedStopPrice',
  'margin',
  'leverage',
  'multiplier',
  'tickValue',
  'lotSize',
  'exchangeRate',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.13 out-of-scope semantic owner detected: ${forbidden}`);
  }
}

console.log('P11.13 risk performance composition primitive verification PASS');
