import { readFileSync } from 'node:fs';

const graphic = readFileSync('src/app/JournalTradeMapGraphic.tsx','utf8');
const presentation = readFileSync('src/app/JournalTradeMap.tsx','utf8');
const css = readFileSync('src/app/journalRoute.css','utf8');
const forbidden = [/parseFloat\s*\(/, /parseInt\s*\(/, /new\s+Decimal\s*\(/, /fetch\s*\(/, /WebSocket/, /indexedDB/, /<canvas/i];

for (const pattern of forbidden) {
  if (pattern.test(graphic)) throw new Error(`P14.5 forbidden graphic behavior: ${pattern}`);
}
if (!graphic.includes('role="img"')) throw new Error('P14.5 SVG must expose role img');
if (!graphic.includes('aria-labelledby')) throw new Error('P14.5 SVG must have accessible name/description linkage');
if (!graphic.includes('<title')) throw new Error('P14.5 SVG title missing');
if (!graphic.includes('<desc')) throw new Error('P14.5 SVG description missing');
if (!graphic.includes('Not to scale')) throw new Error('P14.5 non-scaled semantic guarantee missing');
if (!graphic.includes('model.levels.map')) throw new Error('P14.5 must consume authoritative display levels');
if (!presentation.includes('<JournalTradeMapGraphic model={model} />')) throw new Error('P14.5 graphic is not wired through P14.4 presentation owner');
if (!presentation.includes('<dl className="kairos-trade-map__levels">')) throw new Error('P14.5 must preserve exact HTML text equivalent');
if (!presentation.includes('Visual guide · Not to scale')) throw new Error('P14.5 visible non-scale disclosure missing');
if (!css.includes('.kairos-trade-map__graphic')) throw new Error('P14.5 theme-owned SVG presentation styles missing');

console.log('P14.5 Journal Trade Map accessible SVG shell verifier PASS');
