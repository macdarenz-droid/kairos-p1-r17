import { existsSync, readFileSync } from 'node:fs';

for (const file of [
  'src/features/chart/chartEnginePort.ts',
  'src/features/chart/projectedChartRenderer.ts',
  'tests/projected-chart-renderer.test.ts',
]) {
  if (!existsSync(file)) throw new Error(`Missing P17.4 file: ${file}`);
}

const port = readFileSync('src/features/chart/chartEnginePort.ts', 'utf8');
const renderer = readFileSync('src/features/chart/projectedChartRenderer.ts', 'utf8');

for (const token of [
  'ChartEngineSession',
  'replaceSeries(series: RendererSeriesProjection): void',
  'ChartEnginePort',
  'create(container: HTMLElement): ChartEngineSession',
]) {
  if (!port.includes(token)) throw new Error(`Missing P17.4 port token: ${token}`);
}

for (const token of [
  'createProjectedChartRendererFactory',
  'projectChartSeries(model)',
  'session.replaceSeries',
  'session.destroy()',
  "throw new Error('chart-renderer-destroyed')",
]) {
  if (!renderer.includes(token)) throw new Error(`Missing P17.4 renderer token: ${token}`);
}

for (const forbidden of [
  'indexedDB',
  'localStorage',
  'Dexie',
  'WebSocket',
  'setTimeout(',
  'setInterval(',
  'Math.random',
  'subscribeBinance',
  'executeMarketDataReconnect',
  'createTrade',
  'updateTrade',
  'deleteTrade',
  'lightweight-charts',
]) {
  if (port.includes(forbidden) || renderer.includes(forbidden)) {
    throw new Error(`P17.4 ownership violation: ${forbidden}`);
  }
}

console.log('P17.4 projected chart renderer composition verifier PASS');
