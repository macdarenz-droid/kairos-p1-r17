import fs from 'node:fs';

const files = [
  'src/domain/calculations/percentageCalculator.ts',
  'tests/percentage-calculator.test.ts',
];

for (const file of files) {
  if (!fs.existsSync(file)) {
    throw new Error(`Missing ${file}`);
  }
}

const source = fs.readFileSync(
  'src/domain/calculations/percentageCalculator.ts',
  'utf8',
);

for (const token of [
  'calculatePercentage',
  'decimalDivide',
  'decimalMultiply',
  "'zero-denominator'",
  "'invalid-decimal'",
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P11.6 percentage contract: ${token}`);
  }
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error(
    'P11.6 Percentage Calculator must not use native numeric arithmetic/coercion.',
  );
}

for (const forbidden of [
  'TradeRecord',
  'TradeExecutionRecord',
  'TradeFeeRecord',
  'marketType',
  'grossPnl',
  'netPnl',
  'pnlPercent',
  'initialRisk',
  'realizedR',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
  'exchangeRate',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.6 out-of-scope policy/owner detected: ${forbidden}`);
  }
}

console.log('P11.6 percentage calculator primitive verification PASS');
