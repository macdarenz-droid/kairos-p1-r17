import fs from 'node:fs';const s=fs.readFileSync('src/data/backup/backupSnapshot.ts','utf8');const schema=fs.readFileSync('src/data/database/schema.ts','utf8');
for(const x of ['assertKairosDatabaseIntegrity(db)','repositories.metadata.listAll()','repositories.trades.listAll()','db.tradePlans.toArray()','db.tradeExecutions.toArray()','db.tradeFees.toArray()','createKairosBackupEnvelope'])if(!s.includes(x))throw new Error(`P6.2 snapshot contract missing: ${x}`);
if(/\.(?:delete|clear|bulkPut|put|add|update)\s*\(/.test(s))throw new Error('P6.2 snapshot must remain read-only');
if(!schema.includes('KAIROS_V1_STORES'))throw new Error('Immutable V1 schema history missing');
console.log('P6.2 full database snapshot ownership: PASS');
