import { readFileSync } from 'node:fs';
const s=readFileSync('src/application/trade-visualizer/tradeVisualizerDisplayModel.ts','utf8');
for(const r of ["'planned-entry'","'planned-stop'","'planned-target'","'executed-exit'",'Planned entry','Planned stop','Planned target','Actual exit']) if(!s.includes(r)) throw new Error(`missing ${r}`);
for(const f of ['Number(','parseFloat(','parseInt(','decimalAdd','calculateTradeMetrics','indexedDB','Dexie','fetch(','WebSocket','<svg','<canvas']) if(s.includes(f)) throw new Error(`boundary violation ${f}`);
console.log('PASS P14.2 Trade Visualizer display semantics verifier');
