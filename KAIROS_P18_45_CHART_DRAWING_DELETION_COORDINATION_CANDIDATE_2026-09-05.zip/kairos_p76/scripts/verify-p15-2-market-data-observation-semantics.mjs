import { readFileSync } from 'node:fs';

const semantics = readFileSync('src/services/market-data/marketDataObservationSemantics.ts', 'utf8');
const index = readFileSync('src/services/market-data/index.ts', 'utf8');
const types = readFileSync('src/services/market-data/marketDataTypes.ts', 'utf8');
const adapter = readFileSync('src/services/market-data/MarketDataAdapter.ts', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

const checks = [
  [semantics.includes('validateMarketPriceObservation'), 'observation validation owner is required'],
  [semantics.includes('assessMarketObservationFreshness'), 'freshness semantics owner is required'],
  [semantics.includes("'fresh' | 'stale' | 'future' | 'invalid'"), 'freshness states must remain explicit'],
  [semantics.includes('parsePositiveDecimalString'), 'market price must reuse positive DecimalString validation'],
  [semantics.includes('observation.observedAt'), 'freshness must use application-owned receipt time'],
  [semantics.includes('sourceTimestamp'), 'source timestamp validation must remain explicit'],
  [semantics.includes('Number.isFinite(maxAgeMs)'), 'freshness threshold must reject invalid finite values'],
  [index.includes("export * from './marketDataObservationSemantics'"), 'service barrel must export observation semantics'],
  [types.includes('readonly sourceTimestamp: string | null'), 'P15.1 source timestamp contract must remain'],
  [adapter.includes('export interface MarketDataAdapter'), 'P15.1 adapter boundary must remain'],
  [pkg.scripts?.['verify:p15:2-market-data-observation-semantics'], 'package verifier registration is required'],
];
for (const [ok, message] of checks) if (!ok) throw new Error(message);

const forbidden = [
  /Date\.now\s*\(/,
  /new\s+WebSocket\s*\(/,
  /new\s+EventSource\s*\(/,
  /fetch\s*\(/,
  /setInterval\s*\(/,
  /setTimeout\s*\(/,
  /indexedDB/,
  /Dexie/,
  /JournalTradeMap/,
  /projectJournalTradeVisualizer/,
];
for (const pattern of forbidden) {
  if (pattern.test(semantics)) throw new Error(`P15.2 semantics must remain deterministic and transport/persistence/UI-free: ${pattern}`);
}

if (/sourceTimestamp[^\n]*[-+]|[-+]\s*sourceTimestamp/.test(semantics)) {
  throw new Error('provider/source timestamp must not drive freshness arithmetic');
}

console.log('PASS P15.2 Market Data observation validation/freshness semantics verifier');
