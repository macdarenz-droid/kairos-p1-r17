import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/chartDrawingCollection.ts', 'utf8');
const contract = readFileSync('src/features/chart/chartDrawingContract.ts', 'utf8');
const commit = readFileSync('src/features/chart/chartTrendLineDraftCommitCoordination.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync('tests/chart-drawing-collection.test.ts', 'utf8');
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.33 chart drawing collection verification FAIL: ${message}`);
  process.exit(1);
};

for (const required of [
  'export interface ChartDrawingCollectionSession',
  'getDrawings(): readonly ChartDrawing[]',
  'getDrawing(drawingId: ChartDrawingId): ChartDrawing | null',
  'addDrawing(drawing: ChartDrawing): readonly ChartDrawing[]',
  'const drawings = new Map<ChartDrawingId, ChartDrawing>()',
  "throw new Error('chart-drawing-collection-duplicate-id')",
  "throw new Error('chart-drawing-collection-destroyed')",
  'drawings.clear()',
]) {
  if (!source.includes(required)) fail(`missing committed collection evidence: ${required}`);
}

for (const required of [
  'export type ChartDrawingId = string',
  'export type ChartDrawing = ChartTrendLineDrawing',
]) {
  if (!contract.includes(required)) fail(`P18.1 drawing contract regressed: ${required}`);
}

for (const required of [
  'commitChartTrendLineDraft(',
  'constructChartTrendLineDrawingFromDraft(',
  "session.dispatch({ type: 'commit-drawing', drawingId })",
]) {
  if (!commit.includes(required)) fail(`P18.32 commit coordination regressed: ${required}`);
}

if (!index.includes('createChartDrawingCollectionPort')) {
  fail('chart feature export for P18.33 collection is missing');
}

if (
  packageJson.scripts?.['verify:p18:33-chart-drawing-collection'] !==
  'node scripts/verify-p18-33-chart-drawing-collection.mjs'
) {
  fail('P18.33 package verifier script missing');
}

for (const token of [
  'owns the committed in-memory drawing set without creating or persisting drawing truth',
  'resolves an exact committed drawing by caller-owned identity',
  'rejects duplicate drawing identities without replacing existing committed truth',
  'keeps independent committed drawing collections isolated',
  'destroy is idempotent and later collection access fails closed',
]) {
  if (!test.includes(token)) fail(`runtime test does not pin behavior: ${token}`);
}

for (const forbidden of [
  'randomUUID',
  'crypto.',
  'defineChartDrawing(',
  'commitChartTrendLineDraft(',
  'dispatch(',
  'reduceChartDrawingInteraction(',
  'subscribeClick(',
  'coordinateToPrice(',
  'projectChartDrawing(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  'riskReward',
  'lightweight-charts',
]) {
  if (source.includes(forbidden)) fail(`collection crossed protected boundary: ${forbidden}`);
}

console.log('P18.33 chart drawing collection verification passed.');
