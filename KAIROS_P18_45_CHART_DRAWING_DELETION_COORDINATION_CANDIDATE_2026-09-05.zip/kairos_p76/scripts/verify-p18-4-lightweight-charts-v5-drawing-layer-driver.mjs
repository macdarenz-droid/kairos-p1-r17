import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/features/chart/lightweightChartsV5DrawingLayerDriver.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/features/chart/index.ts', import.meta.url), 'utf8');

const required = [
  "import type { ChartEngineSeriesHandle } from './chartEngineDriver'",
  "from './chartDrawingLayerPort'",
  "import type { RendererChartDrawing } from './chartDrawingProjection'",
  'export interface LightweightChartsV5SeriesPrimitiveApi',
  'attachPrimitive(primitive: TPrimitive): void',
  'detachPrimitive(primitive: TPrimitive): void',
  'export type LightweightChartsV5SeriesPrimitiveResolver',
  'export interface LightweightChartsV5DrawingPrimitiveFactory',
  'export function createLightweightChartsV5DrawingLayerDriver',
  'vendorSeries.detachPrimitive(activePrimitive)',
  'vendorSeries.attachPrimitive(nextPrimitive)',
  "throw new Error('lightweight-charts-drawing-layer-detached')",
];
for (const token of required) {
  if (!source.includes(token)) throw new Error(`P18.4 LWC drawing layer driver missing: ${token}`);
}
for (const forbidden of ['CanvasRenderingContext2D', 'IndexedDB', 'Dexie', 'fetch(', 'WebSocket', 'localStorage', 'risk-reward', 'priceToCoordinate', 'timeToCoordinate']) {
  if (source.includes(forbidden)) throw new Error(`P18.4 LWC drawing layer driver owns forbidden concern: ${forbidden}`);
}
if (!index.includes("from './lightweightChartsV5DrawingLayerDriver'")) throw new Error('P18.4 chart index does not export LWC drawing layer driver');
console.log('P18.4 Lightweight Charts v5 drawing layer driver verification passed.');
