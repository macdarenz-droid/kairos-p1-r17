import { existsSync, readFileSync } from 'node:fs';

for (const file of [
  'src/features/chart/lightweightChartsV5ModuleAdapter.ts',
  'tests/lightweight-charts-v5-module-adapter.test.ts',
]) {
  if (!existsSync(file)) throw new Error(`Missing P17.6 file: ${file}`);
}

const source = readFileSync(
  'src/features/chart/lightweightChartsV5ModuleAdapter.ts',
  'utf8',
);

for (const token of [
  'LightweightChartsV5Module',
  'createChart(container: HTMLElement)',
  'LineSeries',
  'CandlestickSeries',
  'chart.addSeries(module.LineSeries)',
  'chart.addSeries(module.CandlestickSeries)',
  'series.setData(data)',
  'chart.removeSeries(vendorSeries)',
  'chart.remove()',
  'createLightweightChartsV5Driver',
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P17.6 token: ${token}`);
  }
}

for (const forbidden of [
  "from 'lightweight-charts'",
  '.addLineSeries(',
  '.addCandlestickSeries(',
  'indexedDB',
  'localStorage',
  'Dexie',
  'WebSocket',
  'setTimeout(',
  'setInterval(',
  'Math.random',
  'subscribeBinance',
  'executeMarketDataReconnect',
  'createTrade',
  'updateTrade',
  'deleteTrade',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P17.6 ownership/API violation: ${forbidden}`);
  }
}

console.log('P17.6 Lightweight Charts v5 module adapter verifier PASS');
