import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/lightweightChartsV5DrawingHoverPortComposition.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

for (const token of [
  'createLightweightChartsV5DrawingHoverPort',
  'createChartDrawingHoverPortFromDriver',
  'createLightweightChartsV5DrawingHoverSubscriptionFromBinding',
  "Pick<LightweightChartsV5DriverBinding, 'resolveChart'>",
  'subscription.destroy()',
]) {
  if (!source.includes(token)) throw new Error(`P18.19 missing composition token: ${token}`);
}

for (const forbidden of [
  'subscribeCrosshairMove(',
  'unsubscribeCrosshairMove(',
  'hoveredObjectId',
  'attachPrimitive(',
  'detachPrimitive(',
  'indexedDB',
  'localStorage',
]) {
  if (source.includes(forbidden)) throw new Error(`P18.19 re-owns forbidden responsibility: ${forbidden}`);
}

if (!index.includes("createLightweightChartsV5DrawingHoverPort } from './lightweightChartsV5DrawingHoverPortComposition'")) {
  throw new Error('P18.19 chart barrel export missing');
}

if (pkg.scripts?.['verify:p18:19-lightweight-charts-v5-drawing-hover-port-composition'] !== 'node scripts/verify-p18-19-lightweight-charts-v5-drawing-hover-port-composition.mjs') {
  throw new Error('P18.19 package verifier script missing');
}

console.log('P18.19 Lightweight Charts v5 drawing hover port composition verification passed.');
