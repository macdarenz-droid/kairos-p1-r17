import { readFileSync } from 'node:fs';

const source = readFileSync('src/services/market-data/providers/binance/binanceSpotServerShutdownReconnectExecution.ts', 'utf8');
const barrel = readFileSync('src/services/market-data/index.ts', 'utf8');

const required = [
  'resolveBinanceSpotServerShutdownReconnectCause',
  'executeMarketDataReconnectAttempt',
  "kind: 'server-shutdown'",
  'eventTime: resolved.eventTime',
  'resolved.cause',
  'completedAttempts',
  'sample',
  'reconnect',
];
for (const token of required) {
  if (!source.includes(token)) throw new Error(`P16.15 missing required token: ${token}`);
}
const forbidden = [
  'setTimeout(', 'setInterval(', 'new WebSocket(', 'Date.now(', 'Math.random(',
  'indexedDB', 'localStorage', 'sessionStorage', 'fetch(', 'Dexie',
];
for (const token of forbidden) {
  if (source.includes(token)) throw new Error(`P16.15 owns forbidden behavior: ${token}`);
}
if (!barrel.includes("./providers/binance/binanceSpotServerShutdownReconnectExecution")) {
  throw new Error('P16.15 market-data barrel export missing');
}
console.log('P16.15 Binance Spot serverShutdown reconnect execution composition: PASS');
