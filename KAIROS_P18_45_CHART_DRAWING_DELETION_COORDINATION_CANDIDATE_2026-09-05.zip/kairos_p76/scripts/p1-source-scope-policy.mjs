const approvedBrowserMarketTransportOwners = new Set([
  'src/services/market-data/providers/binance/binanceSpotBrowserStreamConnector.ts',
]);

export function isApprovedBrowserMarketTransportOwner(relativePath) {
  return approvedBrowserMarketTransportOwners.has(relativePath);
}
