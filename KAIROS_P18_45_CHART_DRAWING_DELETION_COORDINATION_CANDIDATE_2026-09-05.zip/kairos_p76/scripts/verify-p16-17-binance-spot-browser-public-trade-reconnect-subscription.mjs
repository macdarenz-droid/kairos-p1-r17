import { readFileSync } from 'node:fs';
const source = readFileSync('src/services/market-data/providers/binance/binanceSpotBrowserPublicTradeReconnectSubscription.ts','utf8');
const required = [
  'subscribeBinanceSpotPublicTradeStream',
  'withBinanceSpotPublicStreamLifecycle',
  'connectBinanceSpotBrowserStream',
  'executeBinanceSpotServerShutdownReconnect',
  'MarketDataReconnectScheduler',
  'MarketDataReconnectPolicy',
  'pendingCancel',
  'completedAttempts',
];
for (const token of required) {
  if (!source.includes(token)) throw new Error(`P16.17 missing required ownership token: ${token}`);
}
const forbidden = ['setTimeout(', 'setInterval(', 'Math.random(', 'Date.now(', 'indexedDB', 'localStorage'];
for (const token of forbidden) {
  if (source.includes(token)) throw new Error(`P16.17 introduced forbidden owner: ${token}`);
}
console.log('P16.17 browser public trade reconnect subscription verifier PASS');
