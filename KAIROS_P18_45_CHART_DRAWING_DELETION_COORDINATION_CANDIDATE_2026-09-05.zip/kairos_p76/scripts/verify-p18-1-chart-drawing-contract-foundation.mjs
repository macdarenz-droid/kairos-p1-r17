import { readFileSync } from 'node:fs';

const contract = readFileSync(new URL('../src/features/chart/chartDrawingContract.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/features/chart/index.ts', import.meta.url), 'utf8');

const required = [
  "import type { DecimalString } from '../../domain/trades'",
  "import type { ChartTimestamp } from './chartRenderContract'",
  "export type ChartDrawingId = string",
  "export type ChartDrawingKind = 'trend-line'",
  'export interface ChartDrawingAnchor',
  'readonly timestamp: ChartTimestamp',
  'readonly price: DecimalString',
  'export interface ChartTrendLineDrawing',
  "readonly kind: 'trend-line'",
  'export type ChartDrawing = ChartTrendLineDrawing',
  'export function defineChartDrawing',
];
for (const token of required) {
  if (!contract.includes(token)) throw new Error(`P18.1 drawing contract missing: ${token}`);
}
for (const forbidden of ['lightweight-charts', 'IndexedDB', 'Dexie', 'fetch(', 'WebSocket', 'journalExecutions', 'market-reference']) {
  if (contract.includes(forbidden)) throw new Error(`P18.1 drawing contract owns forbidden concern: ${forbidden}`);
}
if (!index.includes("from './chartDrawingContract'")) throw new Error('P18.1 chart index does not export drawing contract');
console.log('P18.1 chart drawing contract foundation verification passed.');
