import fs from 'node:fs';

const read = (path) => fs.readFileSync(path, 'utf8');
const fail = (message) => {
  console.error(`P18.24 chart drawing interaction port verification FAIL: ${message}`);
  process.exit(1);
};

const portSource = read('src/features/chart/chartDrawingInteractionPort.ts');
const reducerSource = read('src/features/chart/chartDrawingInteractionReducer.ts');
const stateSource = read('src/features/chart/chartDrawingInteractionContract.ts');
const eventSource = read('src/features/chart/chartDrawingInteractionEvent.ts');
const indexSource = read('src/features/chart/index.ts');
const testSource = read('tests/chart-drawing-interaction-port.test.ts');

for (const token of [
  'ChartDrawingInteractionStateListener',
  'ChartDrawingInteractionSession',
  'ChartDrawingInteractionPort',
  'createChartDrawingInteractionPort',
  'getState()',
  'dispatch(event:',
  'reduceChartDrawingInteraction(currentState, event)',
  'nextState !== currentState',
  'onStateChange(currentState)',
  'chart-drawing-interaction-destroyed',
]) {
  if (!portSource.includes(token)) fail(`missing session-lifecycle token: ${token}`);
}

if (!reducerSource.includes('reduceChartDrawingInteraction')) {
  fail('P18.23 reducer owner regressed');
}
if (!stateSource.includes('INITIAL_CHART_DRAWING_INTERACTION_STATE')) {
  fail('P18.21 initial-state contract regressed');
}
if (!eventSource.includes('ChartDrawingInteractionEvent')) {
  fail('P18.22 event contract regressed');
}
if (!indexSource.includes("from './chartDrawingInteractionPort'")) {
  fail('chart feature export for interaction port is missing');
}

for (const token of [
  'createChartDrawingInteractionPort()',
  "status: 'idle'",
  "type: 'select-tool'",
  "type: 'start-drawing'",
  'not.toHaveBeenCalled()',
  'keeps separate sessions isolated',
  'chart-drawing-interaction-destroyed',
]) {
  if (!testSource.includes(token)) fail(`runtime tests do not pin session behavior: ${token}`);
}

for (const forbidden of [
  'lightweight-charts',
  'subscribeClick',
  'unsubscribeClick',
  'subscribeCrosshairMove',
  'unsubscribeCrosshairMove',
  'addEventListener',
  'removeEventListener',
  'PointerEvent',
  'setPointerCapture',
  'timeToCoordinate',
  'coordinateToTime',
  'priceToCoordinate',
  'coordinateToPrice',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.add(',
  '.delete(',
  'riskReward',
]) {
  if (portSource.includes(forbidden)) fail(`interaction port crossed protected boundary: ${forbidden}`);
}

console.log('P18.24 chart drawing interaction port verification passed.');
