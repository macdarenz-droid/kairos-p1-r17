import fs from 'node:fs';
const fail=m=>{console.error(`FAIL P15.13 Market Data reconnect execution verifier: ${m}`);process.exit(1)};
const p='src/services/market-data/marketDataReconnectExecution.ts';
if(!fs.existsSync(p))fail('owner missing');
const s=fs.readFileSync(p,'utf8'),b=fs.readFileSync('src/services/market-data/index.ts','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
for(const t of ['planMarketDataReconnectAttempt','scheduleMarketDataReconnect','MarketDataReconnectScheduler',"kind: 'scheduled'",'attempt.plan.delayMs'])
  if(!s.includes(t))fail(`missing ${t}`);
for(const t of ['coordinateNextMarketDataReconnect','Math.random(','setTimeout(','setInterval(','WebSocket','CloseEvent','fetch(','indexedDB','Dexie'])
  if(s.includes(t))fail(`forbidden ownership token ${t}`);
if(!b.includes("export * from './marketDataReconnectExecution';"))fail('barrel export missing');
if(pkg.scripts?.['verify:p15:13-market-data-reconnect-execution']!=='node scripts/verify-p15-13-market-data-reconnect-execution.mjs')fail('package verifier missing');
console.log('PASS P15.13 Market Data reconnect execution verifier');
