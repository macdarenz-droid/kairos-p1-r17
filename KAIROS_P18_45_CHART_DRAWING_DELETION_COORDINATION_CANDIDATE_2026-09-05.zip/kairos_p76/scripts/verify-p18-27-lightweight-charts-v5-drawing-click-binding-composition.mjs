import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/lightweightChartsV5DrawingClickBindingComposition.ts', 'utf8');
const clickSubscription = readFileSync('src/features/chart/lightweightChartsV5DrawingClickSubscription.ts', 'utf8');
const anchorProjection = readFileSync('src/features/chart/lightweightChartsV5DrawingAnchorProjection.ts', 'utf8');
const adapter = readFileSync('src/features/chart/lightweightChartsV5ModuleAdapter.ts', 'utf8');
const test = readFileSync('tests/lightweight-charts-v5-drawing-click-binding-composition.test.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.27 drawing click binding composition verification FAIL: ${message}`);
  process.exit(1);
};

for (const required of [
  "binding: Pick<LightweightChartsV5DriverBinding, 'resolveChart' | 'resolveSeries'>",
  'const providerChart = binding.resolveChart(handle)',
  'const providerSeries = binding.resolveSeries(handle)',
  'requireDrawingClickChartApi(providerChart)',
  'requireDrawingAnchorPriceApi(providerSeries)',
  'createLightweightChartsV5DrawingClickSubscription(clickChart, priceSeries, onAnchor)',
  "throw new Error('chart-drawing-click-capability-unavailable')",
  "throw new Error('chart-drawing-anchor-price-capability-unavailable')",
]) {
  if (!source.includes(required)) fail(`missing binding composition evidence: ${required}`);
}

if (!clickSubscription.includes('chart.subscribeClick(handleClick)')) {
  fail('P18.26 click lifecycle owner regressed');
}
if (!anchorProjection.includes('projectLightweightChartsV5DrawingAnchor')) {
  fail('P18.25R1 anchor projection owner regressed');
}
for (const required of ['resolveSeries(handle:', 'resolveChart(handle:']) {
  if (!adapter.includes(required)) fail(`provider identity owner regressed: ${required}`);
}
if (!index.includes('createLightweightChartsV5DrawingClickSubscriptionFromBinding')) {
  fail('chart feature export for drawing click binding composition is missing');
}
if (
  packageJson.scripts?.['verify:p18:27-lightweight-charts-v5-drawing-click-binding-composition'] !==
  'node scripts/verify-p18-27-lightweight-charts-v5-drawing-click-binding-composition.mjs'
) {
  fail('P18.27 package verifier script missing');
}

for (const token of [
  'resolves provider chart and series for the neutral handle and delegates click projection',
  'fails closed before subscription when the resolved chart lacks click capability',
  'fails closed before subscription when the resolved series lacks price-coordinate capability',
  'delegates destroy to P18.26 so the exact click handler is unsubscribed once',
]) {
  if (!test.includes(token)) fail(`runtime test does not pin behavior: ${token}`);
}

for (const forbidden of [
  'subscribeCrosshairMove(',
  'unsubscribeCrosshairMove(',
  'subscribeDblClick(',
  'addEventListener(',
  'PointerEvent',
  'setPointerCapture(',
  'reduceChartDrawingInteraction(',
  '.dispatch(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.delete(',
  'riskReward',
]) {
  if (source.includes(forbidden)) fail(`binding composition crossed protected boundary: ${forbidden}`);
}

console.log('P18.27 Lightweight Charts v5 drawing click binding composition verification passed.');
