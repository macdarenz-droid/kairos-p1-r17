import fs from 'node:fs';

const fail = (message) => {
  console.error(`FAIL P16.2 Binance Spot trade observation verifier: ${message}`);
  process.exit(1);
};

const owner = 'src/services/market-data/providers/binance/binanceSpotTradeObservation.ts';
const index = 'src/services/market-data/index.ts';
const test = 'tests/binance-spot-trade-observation.test.ts';

for (const path of [owner, index, test]) {
  if (!fs.existsSync(path)) fail(`missing ${path}`);
}

const source = fs.readFileSync(owner, 'utf8');
const barrel = fs.readFileSync(index, 'utf8');

for (const token of [
  "payload.e !== 'trade'",
  'parsePositiveDecimalString(payload.p)',
  'BINANCE_SPOT_VENUE',
  'observedAt,',
  'sourceTimestamp,',
  'validateMarketPriceObservation(observation)',
]) {
  if (!source.includes(token)) fail(`missing semantic token ${token}`);
}

for (const forbidden of [
  'new WebSocket(',
  'fetch(',
  'apiKey',
  'secret',
  'setTimeout(',
  'setInterval(',
  'Math.random(',
  'Date.now(',
  'indexedDB',
  'Dexie',
]) {
  if (source.includes(forbidden)) fail(`forbidden ownership token ${forbidden}`);
}

if (!barrel.includes("export * from './providers/binance/binanceSpotTradeObservation';")) {
  fail('mapper owner is not exported from market-data barrel');
}

console.log('PASS P16.2 Binance Spot trade observation verifier');
