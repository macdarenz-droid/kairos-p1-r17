import { readFileSync } from 'node:fs';
const s=readFileSync('src/application/trade-visualizer/journalTradeVisualizerProjection.ts','utf8');
for(const r of ['JournalHistoryEntry','projectTradeVisualizerFacts','projectTradeVisualizerDisplayModel','entry.trade','entry.plans','entry.executions']) if(!s.includes(r)) throw new Error(`missing ${r}`);
for(const f of ['createKairosRepositories','indexedDB','Dexie','calculateTradeMetrics','Number(','parseFloat(','fetch(','WebSocket','<svg','<canvas']) if(s.includes(f)) throw new Error(`ownership violation ${f}`);
console.log('PASS P14.3 Journal Trade Visualizer projection wiring verifier');
