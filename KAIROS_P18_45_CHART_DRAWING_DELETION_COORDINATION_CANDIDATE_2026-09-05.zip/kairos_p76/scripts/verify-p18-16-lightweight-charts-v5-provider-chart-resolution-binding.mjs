import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/lightweightChartsV5ModuleAdapter.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');

for (const required of [
  'resolveChart(handle: ChartEngineSeriesHandle): LightweightChartsV5ChartApi',
  'const chartLookup = new Map<ChartEngineSeriesHandle, LightweightChartsV5ChartApi>()',
  'chartLookup.set(handle, chart)',
  'chartLookup.delete(handle)',
  'chartLookup.clear()',
  "throw new Error('chart-series-handle-unknown')",
]) {
  if (!source.includes(required)) throw new Error(`P18.16 missing provider-chart identity evidence: ${required}`);
}

for (const forbidden of [
  'subscribeCrosshairMove(',
  'unsubscribeCrosshairMove(',
  'subscribeClick(',
  'attachPrimitive(',
  'detachPrimitive(',
  'hitTest(',
  'localStorage',
  'IndexedDB',
  'Dexie',
  'fetch(',
  'WebSocket',
  'risk-reward',
]) {
  if (source.includes(forbidden)) throw new Error(`P18.16 crossed controlled scope: ${forbidden}`);
}

if (!index.includes('LightweightChartsV5DriverBinding')) {
  throw new Error('P18.16 chart index binding export missing');
}

console.log('P18.16 Lightweight Charts v5 provider chart resolution binding verification passed.');
