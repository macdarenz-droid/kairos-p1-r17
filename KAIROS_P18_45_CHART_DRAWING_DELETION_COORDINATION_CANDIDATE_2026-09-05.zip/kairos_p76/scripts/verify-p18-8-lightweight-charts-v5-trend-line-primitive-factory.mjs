import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/lightweightChartsV5TrendLinePrimitiveFactory.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');

for (const required of [
  'LightweightChartsV5DrawingPrimitiveFactory',
  'LightweightChartsV5TrendLinePrimitive',
  'createLightweightChartsV5TrendLinePrimitiveFactory',
  'createLightweightChartsV5TrendLinePrimitive(drawings, styleSnapshot)',
  'styleSnapshot',
]) {
  if (!source.includes(required)) throw new Error(`P18.8 missing required primitive-factory evidence: ${required}`);
}

for (const forbidden of [
  'attachPrimitive(',
  'detachPrimitive(',
  'timeToCoordinate(',
  'priceToCoordinate(',
  'useBitmapCoordinateSpace(',
  'hitTest(',
  'localStorage',
  'IndexedDB',
  'Dexie',
  'fetch(',
  'WebSocket',
  'risk-reward',
]) {
  if (source.includes(forbidden)) throw new Error(`P18.8 crossed controlled scope: ${forbidden}`);
}

if (!index.includes("from './lightweightChartsV5TrendLinePrimitiveFactory'")) {
  throw new Error('P18.8 chart index export missing');
}

console.log('P18.8 Lightweight Charts v5 trend-line primitive factory verification passed.');
