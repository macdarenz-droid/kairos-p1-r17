import fs from 'node:fs';
import process from 'node:process';

const draftPath = 'src/application/trades/manualTradeDraft.ts';
const testPath = 'tests/manual-trade-draft.test.ts';
const draft = fs.readFileSync(draftPath, 'utf8');
const tests = fs.readFileSync(testPath, 'utf8');

const requiredDraftFragments = [
  'export function createEmptyManualTradeDraft()',
  "marketType: ''",
  "side: ''",
  "status: ''",
  'export function prepareManualTradeSubmission(',
  "type: 'draft-incomplete'",
  "reason: 'selection-required'",
  'hasPlanValue(draft.plan)',
  'readonly input: SaveManualTradeInput',
];
const missingDraft = requiredDraftFragments.filter((fragment) => !draft.includes(fragment));
if (missingDraft.length) {
  console.error('P10.2 draft contract missing:', missingDraft);
  process.exit(1);
}

const forbiddenDraftFragments = [
  'indexedDB',
  'runKairosAtomicWrite',
  'parsePositiveDecimalString',
  'grossPnL',
  'netPnL',
  'realizedR',
  'averageEntryPrice',
  'fetch(',
];
const forbidden = forbiddenDraftFragments.filter((fragment) => draft.includes(fragment));
if (forbidden.length) {
  console.error('P10.2 crossed protected scope:', forbidden);
  process.exit(1);
}

const requiredTests = [
  'without silently choosing market, direction, or trade state',
  'requires an explicit %s selection before submission',
  'does not create an empty plan aggregate',
  'preserves raw financial strings for the P10.1 command to validate and normalize',
];
const missingTests = requiredTests.filter((fragment) => !tests.includes(fragment));
if (missingTests.length) {
  console.error('P10.2 regression coverage missing:', missingTests);
  process.exit(1);
}

console.log('P10.2 manual trade draft static contract: PASS');
