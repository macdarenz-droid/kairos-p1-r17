import { readFileSync } from 'node:fs';

const pkg=JSON.parse(readFileSync('package.json','utf8'));
const scripts=pkg.scripts ?? {};
const journal=readFileSync('src/app/JournalDailyResults.tsx','utf8');
const progress=readFileSync('src/app/VisualPnlCumulativeProgress.tsx','utf8');
const cumulative=readFileSync('src/application/visual-pnl/cumulativeRealizedPnl.ts','utf8');

const requiredScripts=[
  'verify:p13:visual-pnl-outcome-projection',
  'verify:p13:7-visual-pnl-daily-summary-composition',
  'verify:p13:9-visual-pnl-calendar-presentation',
  'verify:p13:13-daily-streak-semantics',
  'verify:p13:15-daily-performance-summary',
  'verify:p13:17r1-progress-series-empty-points-contract',
  'verify:p13:18-cumulative-realized-pnl-semantics',
  'verify:p13:19-cumulative-realized-pnl-presentation',
];
for(const name of requiredScripts) if(!scripts[name]) throw new Error(`P13 closure missing verifier ${name}`);

for(const required of [
  'VisualPnlStreak',
  'VisualPnlPerformanceSummary',
  'VisualPnlCumulativeProgress',
  'VisualPnlCalendar',
  'projectVisualPnlProgressSeries',
  'projectVisualPnlCumulativeRealizedPnl',
]) if(!journal.includes(required)) throw new Error(`P13 closure missing Journal composition ${required}`);

if(!progress.includes('This is not account equity')) throw new Error('P13 closure lost realized-P&L/equity distinction');
if(!progress.includes('mixed currencies')) throw new Error('P13 closure lost mixed-currency unavailable presentation');
if(!cumulative.includes('decimalAdd')) throw new Error('P13 closure lost Calculation Engine decimal ownership');

for(const forbidden of ['exchangeRate','fxRate','accountEquity','brokerBalance']) {
  if(journal.includes(forbidden) || cumulative.includes(forbidden)) throw new Error(`P13 closure crossed deferred boundary: ${forbidden}`);
}

console.log('PASS P13.20 Visual P&L System closure verifier');
