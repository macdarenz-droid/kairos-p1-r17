import { readFileSync } from 'node:fs';

const required = {
  'src/design-system/primitives/registry.ts': ['button', 'input', 'card', 'modal', 'tabs', 'status', 'loading'],
  'src/design-system/tokens/typography.ts': ['family', 'size', 'weight', 'lineHeight'],
  'tests/design-primitives.test.ts': ['designPrimitiveRegistry', 'typographyTokens'],
};

for (const [file, markers] of Object.entries(required)) {
  const source = readFileSync(file, 'utf8');
  for (const marker of markers) {
    if (!source.includes(marker)) throw new Error(`P2.2 primitive contract missing ${marker} in ${file}`);
  }
}

const semantic = readFileSync('src/design-system/tokens/semantic.ts', 'utf8');
if (/#[0-9a-f]{3,8}\b/i.test(semantic)) throw new Error('P2.2 must not introduce concrete theme colors.');
console.log('P2.2 primitive/typography contract: PASS');
