import fs from 'node:fs';

const read = (path) => fs.readFileSync(path, 'utf8');
const fail = (message) => {
  console.error(`P18.38 chart drawing selection interaction semantics verification FAIL: ${message}`);
  process.exit(1);
};

const stateSource = read('src/features/chart/chartDrawingInteractionContract.ts');
const eventSource = read('src/features/chart/chartDrawingInteractionEvent.ts');
const reducerSource = read('src/features/chart/chartDrawingInteractionReducer.ts');
const portSource = read('src/features/chart/chartDrawingInteractionPort.ts');
const testSource = read('tests/chart-drawing-selection-interaction.test.ts');
const packageSource = read('package.json');

for (const token of [
  "| 'selected'",
  "readonly status: 'selected'",
  'readonly drawingId: ChartDrawingId',
]) {
  if (!stateSource.includes(token)) fail(`missing selected-state contract token: ${token}`);
}
if (!eventSource.includes("readonly type: 'select-drawing'")) {
  fail('select-drawing event is missing');
}
for (const token of [
  "case 'select-drawing'",
  "state.status === 'selected'",
  "state.drawingId === event.drawingId",
  "status: 'selected'",
]) {
  if (!reducerSource.includes(token)) fail(`missing selection reducer token: ${token}`);
}
if (!portSource.includes('reduceChartDrawingInteraction(currentState, event)')) {
  fail('P18.24 interaction session is no longer the sole current-state dispatcher');
}
for (const token of [
  "type: 'select-drawing'",
  "status: 'selected'",
  "type: 'start-editing'",
  "type: 'start-deleting'",
  '.toBe(selected)',
  "type: 'cancel-interaction'",
]) {
  if (!testSource.includes(token)) fail(`runtime selection tests do not pin behavior: ${token}`);
}
if (!packageSource.includes('verify:p18:38-chart-drawing-selection-interaction-semantics')) {
  fail('package verifier registration is missing');
}
for (const source of [stateSource, eventSource, reducerSource]) {
  for (const forbidden of [
    'lightweight-charts',
    'subscribeClick',
    'unsubscribeClick',
    'subscribeCrosshairMove',
    'IndexedDB',
    'Dexie',
    'localStorage',
    '.put(',
    '.add(',
    '.delete(',
    'riskReward',
    'risk-reward',
  ]) {
    if (source.includes(forbidden)) fail(`selection semantics crossed protected boundary: ${forbidden}`);
  }
}

console.log('P18.38 chart drawing selection interaction semantics verification passed.');
