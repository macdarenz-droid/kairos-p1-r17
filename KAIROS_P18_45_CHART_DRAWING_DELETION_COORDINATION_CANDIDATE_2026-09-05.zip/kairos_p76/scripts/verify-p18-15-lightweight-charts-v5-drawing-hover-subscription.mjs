import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/lightweightChartsV5DrawingHoverSubscription.ts', 'utf8');
const projection = readFileSync('src/features/chart/lightweightChartsV5DrawingHoverProjection.ts', 'utf8');
const test = readFileSync('tests/lightweight-charts-v5-drawing-hover-subscription.test.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');

for (const token of [
  'subscribeCrosshairMove(handler:',
  'unsubscribeCrosshairMove(handler:',
  'projectLightweightChartsV5DrawingHover(drawingSnapshot, event)',
  'chart.subscribeCrosshairMove(handleCrosshairMove)',
  'chart.unsubscribeCrosshairMove(handleCrosshairMove)',
  'if (destroyed) return;',
]) {
  if (!source.includes(token)) throw new Error(`P18.15 hover subscription missing: ${token}`);
}
if (!projection.includes("readonly kind: 'drawing-hover'")) {
  throw new Error('P18.15 requires the canonical P18.14 hover projection');
}
if (!index.includes('createLightweightChartsV5DrawingHoverSubscription')) {
  throw new Error('P18.15 hover subscription export missing');
}
for (const token of ['subscribes once', 'emits null', 'immutable drawing snapshot', 'unsubscribes the same handler exactly once']) {
  if (!test.includes(token)) throw new Error(`P18.15 regression evidence missing: ${token}`);
}
for (const forbidden of ['chart.subscribeClick(', 'selectedDrawingId', 'dragStart', 'localStorage.', 'indexedDB.']) {
  if (source.includes(forbidden)) throw new Error(`P18.15 scope violation: ${forbidden}`);
}
console.log('P18.15 Lightweight Charts v5 drawing hover subscription lifecycle verifier: PASS');
