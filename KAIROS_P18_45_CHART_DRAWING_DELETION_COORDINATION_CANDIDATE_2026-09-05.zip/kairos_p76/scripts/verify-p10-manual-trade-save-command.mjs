import fs from 'node:fs';
import process from 'node:process';

const commandPath = 'src/application/trades/saveManualTrade.ts';
const testPath = 'tests/manual-trade-save-command.test.ts';
const command = fs.readFileSync(commandPath, 'utf8');
const tests = fs.readFileSync(testPath, 'utf8');

const requiredCommandFragments = [
  'export async function saveManualTrade(',
  "source: 'manual'",
  'validateTradeRecord(trade)',
  'parsePositiveDecimalString',
  "runKairosAtomicWrite(db, storeNames",
  "type: 'validation-error'",
  "type: 'storage-error'",
  "reason: 'trade-save-failed'",
  "if ('ok' in prepared) return prepared;",
];
const missingCommand = requiredCommandFragments.filter((fragment) => !command.includes(fragment));
if (missingCommand.length) {
  console.error('P10.1 command contract missing:', missingCommand);
  process.exit(1);
}

const forbiddenCommandFragments = [
  'indexedDB.',
  'fetch(',
  'XMLHttpRequest',
  'decimal.js',
  'grossPnL',
  'netPnL',
  'realizedR',
  'averageEntryPrice',
];
const forbidden = forbiddenCommandFragments.filter((fragment) => command.includes(fragment));
if (forbidden.length) {
  console.error('P10.1 crossed protected scope:', forbidden);
  process.exit(1);
}

const requiredTests = [
  'atomically persists one manual trade aggregate',
  'rejects invalid financial input before any persistence starts',
  'rolls back all required records on write failure',
  'does not silently convert missing optional financial values to zero',
];
const missingTests = requiredTests.filter((fragment) => !tests.includes(fragment));
if (missingTests.length) {
  console.error('P10.1 regression coverage missing:', missingTests);
  process.exit(1);
}

console.log('P10.1 manual trade save command static contract: PASS');
