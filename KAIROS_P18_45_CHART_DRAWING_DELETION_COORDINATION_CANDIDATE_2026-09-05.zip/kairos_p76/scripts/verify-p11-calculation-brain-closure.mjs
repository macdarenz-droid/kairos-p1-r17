import fs from 'node:fs';

const requiredFiles = [
  'src/domain/calculations/decimalKernel.ts',
  'src/domain/calculations/executionAggregation.ts',
  'src/domain/calculations/executionBalance.ts',
  'src/domain/calculations/grossRealizedPnl.ts',
  'src/domain/calculations/tradeMetrics.ts',
  'src/domain/calculations/percentageCalculator.ts',
  'src/domain/calculations/rMultipleCalculator.ts',
  'src/domain/calculations/riskCalculator.ts',
  'src/domain/calculations/marketSpecificCalculationPolicy.ts',
  'src/domain/calculations/positionSizeCalculator.ts',
  'src/domain/calculations/leverageCalculator.ts',
  'src/domain/calculations/riskPerformanceCalculator.ts',
  'src/domain/calculations/feeCalculator.ts',
  'src/domain/calculations/netPnlCalculator.ts',
  'src/domain/calculations/netPnlCurrencyPolicy.ts',
  'src/domain/calculations/netPnlComposition.ts',
  'tests/calculation-brain-closure.test.ts',
];

for (const file of requiredFiles) {
  if (!fs.existsSync(file)) throw new Error(`P11.24 missing required Calculation Brain artifact: ${file}`);
}

const metrics = fs.readFileSync('src/domain/calculations/tradeMetrics.ts', 'utf8');
for (const field of [
  'grossPnl', 'totalFees', 'netPnl', 'pnlPercent', 'initialRisk', 'realizedR',
  'averageEntryPrice', 'averageExitPrice', 'totalEnteredQuantity',
  'totalExitedQuantity', 'remainingQuantity', 'state', 'completeness',
]) {
  if (!metrics.includes(field)) throw new Error(`P11.24 TradeMetrics contract missing ${field}`);
}

for (const owner of [
  'calculateFlatTradeGrossRealizedPnl',
  'calculateTotalFees',
  'calculateComparableNetPnl',
  'calculatePercentage',
  'calculateRiskPerformance',
  'calculateRMultiple',
]) {
  if (!metrics.includes(owner)) throw new Error(`P11.24 TradeMetrics does not delegate to ${owner}`);
}

const closureTest = fs.readFileSync('tests/calculation-brain-closure.test.ts', 'utf8');
for (const assertion of [
  "grossPnl: '40'",
  "netPnl: '35'",
  "pnlPercent: '17.5'",
  "realizedR: '1.75'",
  'preserves unknown financial evidence as unavailable rather than zero',
  'does not compose nonzero fee evidence across currencies without FX',
]) {
  if (!closureTest.includes(assertion)) throw new Error(`P11.24 closure regression missing: ${assertion}`);
}

console.log('P11.24 Calculation Brain closure verification PASS');
