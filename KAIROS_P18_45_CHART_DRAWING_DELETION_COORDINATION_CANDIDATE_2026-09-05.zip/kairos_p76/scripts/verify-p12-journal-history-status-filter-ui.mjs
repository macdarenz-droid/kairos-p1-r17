import { readFileSync } from 'node:fs';
const route=readFileSync('src/app/JournalRoute.tsx','utf8');
const list=readFileSync('src/app/JournalHistoryList.tsx','utf8');
const css=readFileSync('src/app/journalRoute.css','utf8');
const tests=readFileSync('tests/journal-history-route.test.tsx','utf8');
const query=readFileSync('src/application/journal/historyQuery.ts','utf8');
const checks=[
  [route.includes("useState<TradeStatus | ''>('')"), 'route must own temporary status-filter state'],
  [route.includes("historyStatus === '' ? {} : { status: historyStatus }"), 'route must pass status to P12 query owner'],
  [route.includes('historyRequestSequence') && route.includes('requestSequence !== historyRequestSequence.current'), 'latest filter request must win'],
  [!route.includes('.filter(') && !list.includes('.filter('), 'UI must not filter trade history in React memory'],
  [!route.toLowerCase().includes('indexeddb') && !list.toLowerCase().includes('indexeddb'), 'UI must not call IndexedDB directly'],
  [query.includes('listRecentByStatusAndUpdatedAt(options.status'), 'status query must remain repository/index owned'],
  [list.includes('htmlFor="kairos-history-status-filter"') && list.includes('<select') && list.includes('All trades'), 'accessible controlled filter select required'],
  [list.includes('No ${statusLabel(statusFilter).toLowerCase()} trades found.'), 'filtered empty state required'],
  [css.includes('.kairos-history__filter') && css.includes('@media (max-width: 420px)'), 'mobile filter layout required'],
  [tests.includes("getByLabelText('Show trades')") && tests.includes("target:{value:'closed'}") && tests.includes("target:{value:'cancelled'}"), 'status filter and rapid-change regressions must be pinned'],
  [!list.includes('role="status">Loading trade history'), 'P10 save status role must remain unique'],
];
for(const [ok,msg] of checks){if(!ok){console.error(`P12.5 verification FAIL: ${msg}`);process.exit(1)}}
console.log('P12.5 journal status filter UI wiring verification PASS');
