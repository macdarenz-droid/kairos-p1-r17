import { readFileSync } from 'node:fs';

const source = readFileSync('src/features/chart/lightweightChartsV5DrawingSelectionInteractionCoordination.ts', 'utf8');
const projection = readFileSync('src/features/chart/lightweightChartsV5DrawingSelectionProjection.ts', 'utf8');
const reducer = readFileSync('src/features/chart/chartDrawingInteractionReducer.ts', 'utf8');
const port = readFileSync('src/features/chart/chartDrawingInteractionPort.ts', 'utf8');
const index = readFileSync('src/features/chart/index.ts', 'utf8');
const test = readFileSync('tests/lightweight-charts-v5-drawing-selection-interaction-coordination.test.ts', 'utf8');
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));

const fail = (message) => {
  console.error(`P18.41 drawing selection interaction coordination verification FAIL: ${message}`);
  process.exit(1);
};

for (const token of [
  'projectLightweightChartsV5DrawingSelection(drawings, event)',
  'if (selection === null) return null',
  "type: 'select-drawing'",
  'drawingId: selection.drawingId',
  'return interaction.dispatch(',
]) {
  if (!source.includes(token)) fail(`missing coordination invariant: ${token}`);
}

if (!projection.includes('drawing.id === hoveredInfo.objectId')) {
  fail('P18.39 current-snapshot selection owner regressed');
}
if (!reducer.includes("case 'select-drawing':")) {
  fail('P18.23 select-drawing transition owner regressed');
}
if (!port.includes('reduceChartDrawingInteraction(currentState, event)')) {
  fail('P18.24 authoritative dispatch path regressed');
}
for (const token of [
  'coordinateLightweightChartsV5DrawingSelectionInteraction',
  'ChartDrawingSelectionInteractionDispatcher',
]) {
  if (!index.includes(token)) fail(`chart feature export missing: ${token}`);
}
for (const token of [
  'authoritative P18.24 session',
  'selection switching semantics owned by the existing reducer',
  'fails closed without dispatch',
  'does not bypass P18.23',
]) {
  if (!test.includes(token)) fail(`runtime regression evidence missing: ${token}`);
}

for (const forbidden of [
  'subscribeClick',
  'unsubscribeClick',
  'subscribeCrosshairMove',
  'createChartDrawingInteractionPort',
  'reduceChartDrawingInteraction(',
  'new Map(',
  'IndexedDB',
  'Dexie',
  'localStorage',
  '.put(',
  '.add(',
  '.delete(',
  'riskReward',
  'risk-reward',
]) {
  if (source.includes(forbidden)) fail(`P18.41 crossed protected boundary: ${forbidden}`);
}

if (
  pkg.scripts?.['verify:p18:41-lightweight-charts-v5-drawing-selection-interaction-coordination'] !==
  'node scripts/verify-p18-41-lightweight-charts-v5-drawing-selection-interaction-coordination.mjs'
) {
  fail('P18.41 package verifier script missing');
}

console.log('P18.41 Lightweight Charts v5 drawing selection interaction coordination verification passed.');
