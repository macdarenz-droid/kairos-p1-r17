import { readFileSync } from 'node:fs';

const owner = readFileSync('src/services/market-data/marketDataReconnectPolicy.ts', 'utf8');
const index = readFileSync('src/services/market-data/index.ts', 'utf8');

const checks = [
  ['policy owner exists', owner.includes('decideMarketDataReconnect')],
  ['initial delay explicit', owner.includes('initialDelayMs')],
  ['max delay explicit', owner.includes('maxDelayMs')],
  ['max attempts explicit', owner.includes('maxAttempts')],
  ['attempt limit explicit', owner.includes("reason: 'attempt-limit'")],
  ['invalid policy explicit', owner.includes("reason: 'invalid-policy'")],
  ['exponential progression explicit', owner.includes('2 ** completedAttempts')],
  ['delay cap explicit', owner.includes('Math.min')],
  ['safe integer validation', owner.includes('Number.isSafeInteger')],
  ['barrel exports reconnect policy', index.includes("export * from './marketDataReconnectPolicy';")],
];

for (const token of [
  'Math.random(',
  'setTimeout(',
  'setInterval(',
  'Date.now(',
  'new WebSocket(',
  'new EventSource(',
  'fetch(',
  'indexedDB',
  'Dexie',
  'JournalTradeMap',
  'projectJournalTradeVisualizer',
]) {
  checks.push([`forbidden token absent: ${token}`, !owner.includes(token)]);
}

const failed = checks.filter(([, ok]) => !ok);
if (failed.length) {
  for (const [name] of failed) console.error(`FAIL ${name}`);
  process.exit(1);
}
console.log('PASS P15.5 Market Data reconnect policy verifier');
