import { readFileSync } from 'node:fs';

const ui=readFileSync('src/app/JournalHistoryList.tsx','utf8');
const css=readFileSync('src/app/journalRoute.css','utf8');
const test=readFileSync('tests/journal-visual-pnl-presentation.test.tsx','utf8');

const requiredUi=["entry.visualPnl.outcome","entry.visualPnl.label","visualPnlAmount(entry)","data-outcome={entry.visualPnl.outcome}","'▲'","'▼'","'—'"];
for (const token of requiredUi) if (!ui.includes(token)) throw new Error(`P13.3 UI contract missing: ${token}`);
for (const token of ['--kairos-trade-profit','--kairos-trade-loss','--kairos-trade-flat']) if (!css.includes(token)) throw new Error(`P13.3 semantic theme token missing: ${token}`);
for (const forbidden of ['#45d7a7','#ff6f87','#9aaab4','Number(','parseFloat(','parseInt(']) if (ui.includes(forbidden) || css.includes(forbidden)) throw new Error(`P13.3 forbidden presentation ownership/value: ${forbidden}`);
for (const token of ["data-outcome","▲","▼","—","Not available"]) if (!test.includes(token)) throw new Error(`P13.3 accessibility regression evidence missing: ${token}`);
console.log('P13.3 Journal Visual P&L presentation verifier: PASS');
