import fs from 'node:fs';

const metrics = fs.readFileSync('src/domain/calculations/tradeMetrics.ts', 'utf8');
const tests = fs.readFileSync('tests/trade-metrics-pnl-percentage-evidence.test.ts', 'utf8');
const requiredMetrics = [
  'TradeMetricsPnlPercentageInput',
  'readonly resultAmount: DecimalString;',
  'readonly basisAmount: DecimalString;',
  'calculatePercentage(',
  "'zero-pnl-percentage-basis'",
  "'invalid-pnl-percentage-decimal'",
  'readonly pnlPercent: DecimalString | null;',
  'hasPnlPercent: pnlPercent !== null',
];
for (const token of requiredMetrics) {
  if (!metrics.includes(token)) throw new Error(`P11.22 missing TradeMetrics contract token: ${token}`);
}
for (const token of ['keeps P&L percentage unavailable', 'exact percentage', 'zero basis', 'malformed percentage evidence']) {
  if (!tests.includes(token)) throw new Error(`P11.22 missing test evidence: ${token}`);
}
console.log('P11.22 TradeMetrics P&L percentage evidence static verification PASS');
