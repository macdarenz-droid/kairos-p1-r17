# KAIROS PATCH REPORT

Patch: P13.9 — Accessible Visual P&L Calendar Presentation Contract
Base: P13.8 canonical PASS, Run #85, gate SHA 98c90220052251b84dcc2824dbc49a4960be8de0

## OBJECTIVE
Define the first visual calendar/heatmap-style P&L consumer without adding database, calculation, FX, grouping, or timezone ownership.

## OWNERSHIP
VisualPnlCalendar receives the already-authoritative P13.7 daily projection. It never queries storage and never recomputes daily totals. P13.8 remains the Journal query owner; P13.6/P13.7 remain calendar-day and composition owners.

## PRESENTATION
- Compact responsive day-cell grid.
- Profit: semantic profit token + ▲ + text.
- Loss: semantic loss token + ▼ + text.
- Break-even: semantic flat token + — + text.
- Unavailable: neutral presentation + explicit reason/text.
- Amount/currency and trade count remain visible.
- Mixed currencies remain 'Not available'; never visually aggregated.
- Blocked day evidence is surfaced as a count.
- Empty state is explicit.
- Theme semantic tokens only for outcome styling.
- Color is never the sole information carrier.

## NON-SCOPE
No route/data fetching wiring yet, no timezone preference owner, no calendar navigation/month paging, no financial arithmetic, no FX, no database/schema change, no transition animation.

## RESULT
HOLD pending canonical GitHub gate.

## NEXT
After PASS, wire this presentation to P13.8 through an explicit caller-supplied timezone policy boundary. Do not silently read device timezone.
