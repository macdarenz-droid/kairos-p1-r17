# KAIROS P14.6R2 — Journal Trade Map Accessible Name Selector Repair

## Patch/Base/app/build identity
Base: KAIROS_P14_5R2_JOURNAL_TRADE_MAP_HISTORICAL_SELECTOR_COMPATIBILITY_REPAIR_CANDIDATE_2026-09-03.zip
Candidate: KAIROS_P14_6R2_JOURNAL_TRADE_MAP_ACCESSIBLE_NAME_SELECTOR_REPAIR_CANDIDATE_2026-09-03.zip
Slice: P14.6R2

## OBJECTIVE
Repair the remaining P14.6 marker-semantics runtime test failure without changing production behavior.

## RESEARCH
Canonical Run #113 proved build success and 407/408 unit tests passing. The sole failure was the new P14.6 test querying the SVG image by the incomplete accessible name `SOLUSDT trade map visual`. Because the SVG uses `aria-labelledby` referencing both `<title>` and `<desc>`, its accessible name correctly contains the title followed by the description.

## OWNER TRACE
Accessible-name ownership remains in JournalTradeMapGraphic.tsx via the existing `<title>`, `<desc>`, and `aria-labelledby` relationship. The test is only a consumer of that accessibility contract.

## PRE-CHANGE FLOW
The test required an exact accessible name equal to the title only. Testing Library correctly exposed the combined title + description accessible name and the assertion failed.

## CHANGE
Changed only the runtime selector to match the stable title prefix with `/^SOLUSDT trade map visual\\b/`, allowing the standards-correct description to remain part of the accessible name.

## NON-SCOPE
No production component, domain model, persistence, calculation, visual geometry, market-data behavior, animation, routing, or theme behavior was changed from P14.6R1.

## DATA/STATE FLOW
Unchanged.

## PERSISTENCE
Unchanged.

## SECURITY
Unchanged.

## THEME
Unchanged.

## OFFLINE
Unchanged.

## TESTS
Canonical evidence before repair: build PASS; 407/408 tests PASS; only the new P14.6 accessible-name selector failed. Static P14.6 verifier remains applicable. Canonical GitHub gate remains authoritative for final PASS.

## REGRESSION
P14.5R2 accessibility semantics are preserved. The repair does not weaken the requirement that the SVG has role=img and a title-based accessible name; it simply accepts the required description contribution from aria-labelledby.

## PERFORMANCE
No runtime production change.

## KNOWN LIMITATIONS
Final status depends on canonical GitHub Actions completion.

## REAL-DEVICE STATUS
Not required for this test-selector-only repair.

## RESULT
HOLD pending canonical gate.
