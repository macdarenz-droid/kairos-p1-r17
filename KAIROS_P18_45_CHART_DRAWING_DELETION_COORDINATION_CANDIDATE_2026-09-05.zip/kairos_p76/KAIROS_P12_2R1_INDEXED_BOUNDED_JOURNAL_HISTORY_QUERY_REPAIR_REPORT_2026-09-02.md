# KAIROS P12.2R1 Indexed Bounded Journal History Query Repair

## Status
HOLD pending canonical GitHub gate.

## Authoritative base
KAIROS_P12_1R1_JOURNAL_HISTORY_QUERY_SCOPE_REPAIR_CANDIDATE_2026-09-02.zip — canonical PASS run #53.

## Rejected predecessor
P12.2 failed canonical run #54 at TypeScript build because two new tests called the established zero-argument `dbName()` fixture with one argument. P12.2 is not a base.

## Repair
Reapply the intended P12.2 indexed/bounded history changes from P12.1R1, but keep the existing test fixture contract unchanged: both new tests now call `dbName()` with zero arguments and use the established `openKairosDatabase(db)` path. No production behavior changed from the intended P12.2 design.

## P12.2 design retained
- Indexed newest-first trade selection via existing `trades.updatedAt`.
- Default history limit 100; hard maximum 500.
- Invalid/unbounded limits rejected.
- Child evidence loaded only for the bounded selected trade set.
- P11 remains sole financial calculation owner.
- No schema migration.

## Scope
Seven-file controlled delta from P12.1R1: this report, package script registration, indexed-history verifier, evolved P12.1R1 verifier, application history query, TradeRepository, and journal-history tests.

## Non-scope
No UI, filters, search, cursor pagination, schema change, writes, backup/restore, activation, theme, network, FX, charts, P13, or financial formula changes.

## Verification
P1 static architecture guard, P12.1R1 verifier, P12.2 indexed/bounded verifier, deterministic install, TypeScript/Vite build, unit tests, and full roadmap regression are required. Canonical GitHub gate remains authoritative.
