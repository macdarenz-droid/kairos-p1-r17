# KAIROS P15.5 — Market Data Reconnect Policy

## BASE
P15.4 canonical PASS — Run #129 / SHA 8a8321888d9374f42d876deac797630eb2a9fc5d.

## OBJECTIVE
Add one deterministic, bounded reconnect decision policy without scheduling timers or selecting a concrete provider.

## RESEARCH
AWS reliability guidance recommends controlling and limiting retries, using progressively longer backoff intervals, capping retries, and using jitter in distributed retry execution to avoid synchronized retry storms. P15.5 deliberately owns only deterministic backoff/limit policy. Random jitter and timer scheduling remain outside this pure policy slice so tests stay deterministic and no background execution owner is introduced prematurely.

## OWNER TRACE
P15.1 owns adapter/subscription contract.
P15.2 owns observation validation/freshness.
P15.3 owns subscription lifecycle.
P15.4 owns connection-state transitions.
P15.5 owns bounded reconnect decisions only.

## PRE-CHANGE FLOW
The application could represent disconnected/error states and a later connect-requested transition, but had no central policy for whether another attempt is permitted or how long the base backoff should be.

## CHANGE
Added `decideMarketDataReconnect`:
- explicit initial delay;
- explicit maximum delay;
- explicit maximum attempts;
- deterministic exponential delay;
- capped delay;
- explicit attempt-limit result;
- explicit invalid-policy result.

## NON-SCOPE
No timer scheduling, random jitter execution, provider, endpoint, WebSocket, EventSource, fetch, polling, persistence, UI/chart wiring, execution mutation, Calculation Engine mutation, P&L mutation, API keys, or secrets.

## DATA/STATE FLOW
policy + completed-attempt count -> pure reconnect decision -> retry with base delay/next attempt OR explicit stop reason.

## PERSISTENCE
None.

## SECURITY
No network access or credentials.

## THEME
No UI/theme changes.

## OFFLINE
Offline journal remains unaffected.

## TESTS
Runtime tests cover exponential progression, cap, attempt limit, invalid policies, invalid counters, and zero-delay policy.

## REGRESSION
P15.1-P15.4 owners remain unchanged.

## PERFORMANCE
Constant-time arithmetic; no timers, observers, polling, or background work.

## KNOWN LIMITATIONS
Jitter application and actual scheduling are intentionally deferred to the future execution owner. Provider-specific retryability classification is also deferred until a provider contract exists.

## REAL-DEVICE STATUS
N/A — pure service policy.

## RESULT
HOLD pending canonical GitHub gate.
