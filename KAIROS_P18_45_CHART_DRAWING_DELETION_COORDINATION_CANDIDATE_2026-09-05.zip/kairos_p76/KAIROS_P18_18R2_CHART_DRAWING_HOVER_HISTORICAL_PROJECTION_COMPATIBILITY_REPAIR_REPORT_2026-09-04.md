# KAIROS P18.18R2 — Chart Drawing Hover Historical Projection Compatibility Repair

## Authority
- Authoritative base: canonical P18.17 PASS, workflow run #218 / 33845110303.
- Failed P18.18 and P18.18R1 candidates are evidence only and are not used as authority.

## Failure evidence
Canonical P18.18R1 gate #221 passed exact scope, deterministic install, Lightweight Charts 5.2.1 proof, production TypeScript, production build, and the dedicated P18.18/P18.17/P18.16 checks. It then failed the historical P18.15 verifier because the P18.18 change had removed the canonical P18.14 `readonly kind: 'drawing-hover'` interface declaration that P18.15 verifies.

## Repair
P18.18R2 is rebuilt from canonical P18.17. It adds the provider-neutral hover lifecycle port and neutral hover observation, while preserving P18.14 as an interface that extends the neutral observation and explicitly retains the canonical drawing-hover fields. This keeps the new neutral ownership without altering P18.14 runtime behavior or invalidating the historical P18.15 contract.

## Non-scope
No provider chart resolution ownership, direct crosshair subscription implementation, click selection, drag/edit, drawing truth mutation, persistence, calculations, market acquisition, journal truth, toolbar state, navigation state, autoscale policy, presentation-session integration, or P19 behavior is added.
