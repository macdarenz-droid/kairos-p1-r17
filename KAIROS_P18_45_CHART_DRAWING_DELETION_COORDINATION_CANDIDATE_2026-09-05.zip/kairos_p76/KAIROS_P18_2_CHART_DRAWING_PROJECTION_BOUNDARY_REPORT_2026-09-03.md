# KAIROS P18.2 — Chart Drawing Projection Boundary

## Purpose
Project provider-neutral P18 drawing anchors into renderer-safe numeric coordinates without moving drawing truth into the rendering layer.

## Authority
Base: canonical P18.1R1 Chart Drawing Contract Foundation, GitHub Actions Run 33757028238.

## Ownership
- Drawing truth remains `ChartDrawing` / `ChartDrawingAnchor` with stable IDs, `ChartTimestamp`, and `DecimalString` prices.
- Existing P17.3 `projectChartPricePoint` remains the sole owner of chart timestamp/DecimalString conversion into renderer numbers.
- P18.2 reuses that projection for drawing anchors and preserves drawing ID/kind.

## Added
- `chartDrawingProjection.ts`
- renderer-safe trend-line drawing projection types
- dedicated P18.2 verifier and unit tests
- public chart exports and package verifier script

## Explicit non-scope
No Lightweight Charts primitive attachment, Canvas drawing, hit testing, drag/edit state, toolbar, persistence, undo/redo, autoscale ownership, network/provider behavior, journal execution mutation, market-observation mutation, or P19 risk/reward behavior.

## Verification intent
Canonical CI must prove deterministic install, production TypeScript/build, P18.2 verifier/runtime, full unit regression, full controlled roadmap regression, P18.1/P17 regressions, historical closures, exact scope, and artifacts.
