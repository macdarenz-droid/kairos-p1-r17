# KAIROS P16.2 — Binance Spot Trade Observation Mapping

## BASE
P16.1R1 Binance Spot P1 Static Contract Repair — canonical PASS, Run #145.

## OBJECTIVE
Map a Binance Spot raw trade event into the provider-neutral P15 market-price observation contract without creating network transport, a receipt clock, persistence, chart ownership, or journal execution truth.

## RESEARCH
Official Binance Spot market-stream documentation identifies the raw Trade Stream as `{symbol}@trade`, real-time, with fields including event type `e`, event time `E`, symbol `s`, trade ID `t`, price `p`, quantity `q`, trade time `T`, and maker flags.

For Kairos market-price observations, the provider trade time `T` is retained as `sourceTimestamp`. The application receipt time remains separately supplied as `observedAt`, preserving the P15 freshness rule that provider timestamps do not own application freshness.

## OWNER TRACE
P16.1R1:
`MarketDataInstrument -> Binance Spot trade stream descriptor`

P16.2:
`unknown Binance trade payload + caller-owned observedAt`
-> Binance Spot trade mapper
-> validated P15 `MarketPriceObservation`

New owner:
`src/services/market-data/providers/binance/binanceSpotTradeObservation.ts`

## CHANGE
- validates the provider payload as a raw `trade` event;
- requires a non-empty symbol;
- parses provider price with the existing positive DecimalString owner;
- converts provider trade time `T` deterministically to an ISO UTC source timestamp;
- keeps `observedAt` caller-supplied;
- validates the final object with the existing P15 observation validator;
- remains symbol-agnostic across Binance Spot pairs.

## NON-SCOPE
- no network connection;
- no transport construction;
- no endpoint ownership;
- no symbol catalogue discovery;
- no API key;
- no Binance account/user stream;
- no orders;
- no reconnect loop;
- no concrete timer;
- no entropy;
- no receipt-clock acquisition;
- no chart engine;
- no persistence;
- no journal/P&L mutation.

## DATA/STATE FLOW
Provider raw trade event
-> payload validation
-> existing DecimalString price parser
-> provider trade-time evidence
-> P15 MarketPriceObservation validation
-> read-only observation result

## SECURITY
Public market-data payload only. No credentials.

## OFFLINE
No networking is introduced. Existing local/offline journal behavior is unchanged.

## TESTS
- BTCUSDT valid trade maps to normalized DecimalString price and ISO source timestamp.
- ETHUSDT proves mapping remains data-driven.
- wrong event type rejected.
- invalid/non-positive price rejected.
- invalid provider trade time rejected.
- invalid caller receipt timestamp rejected.

## REPAIR R1
Canonical Run #146 proved exact scope and production build passed. The full unit suite then failed only in two new P16.2 assertions. The production mapper correctly preserved the validated DecimalString lexical value and correctly converted Binance trade-time epoch `1672515782136` to UTC `2022-12-31T19:43:02.136Z`.

R1 repairs the test contract only:
- expected price `42123.45` -> `42123.45000000`;
- expected source timestamp `2023-01-01T00:03:02.136Z` -> `2022-12-31T19:43:02.136Z`;
- expected ETHUSDT price `2500.1` -> `2500.10`.

No production code changes.

## RESULT
HOLD pending canonical GitHub gate for R1.
