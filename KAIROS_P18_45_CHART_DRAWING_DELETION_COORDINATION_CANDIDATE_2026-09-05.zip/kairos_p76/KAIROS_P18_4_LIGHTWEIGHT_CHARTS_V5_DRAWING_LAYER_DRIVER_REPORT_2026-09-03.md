# KAIROS P18.4 — Lightweight Charts v5 Drawing Layer Driver

## Purpose
Bind the provider-neutral P18.3 drawing-layer lifecycle to the current Lightweight Charts v5 series primitive attachment semantics without implementing the drawing renderer itself.

## Authority
Base: canonical P18.3 Chart Drawing Layer Lifecycle Port, GitHub Actions Run 33759551572, head SHA `21e1494e7d573ea14bc5fab4ad9bbe8bb7ac8944`.

## Official API evidence
Lightweight Charts v5.2 documents that series primitives are attached to a series through `attachPrimitive()` and removed through `detachPrimitive()`. A series primitive implements `ISeriesPrimitive`; its pane/axis views and Canvas renderer are separate concerns. This slice therefore owns only vendor attachment/detachment mapping.

## Added
- `lightweightChartsV5DrawingLayerDriver.ts`
- narrow structural series-primitive API
- injected provider-series resolver
- injected primitive factory
- replacement semantics that detach the previous primitive before attaching the next
- idempotent layer detach
- dedicated verifier and unit tests
- public exports and package verifier script

## Ownership
- `ChartDrawing` remains drawing truth.
- `RendererChartDrawing` remains renderer projection.
- P18.3 remains the provider-neutral drawing-layer lifecycle contract.
- P18.4 owns only Lightweight Charts v5 primitive attachment/detachment mapping.
- The actual primitive implementation remains a later P18 slice.

## Explicit non-scope
No Canvas drawing, pane renderer, axis renderer, coordinate conversion, hit testing, pointer/crosshair capture, drag/edit state, toolbar, persistence, undo/redo, autoscale ownership, market-data acquisition, journal execution mutation, market-observation mutation, navigation state, or P19 risk/reward behavior.

## Verification intent
Canonical CI must prove exact six-file scope from P18.3, deterministic install, exact `lightweight-charts@5.2.1`, production TypeScript/build, dedicated P18.4 runtime/tests, full unit regression, full controlled roadmap regression, P18.3/P18.2/P18.1/P17 regressions, historical closures, and artifacts.
