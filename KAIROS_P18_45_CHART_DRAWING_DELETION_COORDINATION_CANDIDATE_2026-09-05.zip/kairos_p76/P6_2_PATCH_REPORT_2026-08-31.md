# KAIROS P6.2 Database Snapshot / Export Ownership Patch Report

Date: 2026-08-31
Status: HOLD pending authoritative GitHub full gate
Base: P6.1 Backup Envelope Foundation — PASS / LOCKED (GitHub Actions run #64)
Base commit: 9748f5e8b126c47ad60d1a5e1bab718ac71ec384

## OBJECTIVE
Add the smallest read-only export owner that snapshots the current authoritative Kairos database into the locked P6.1 backup envelope without adding restore/import mutation.

## RESEARCH
Re-checked current IndexedDB and Dexie transaction behavior. IndexedDB reads occur inside transactions, readonly mode should be used when mutation is unnecessary, transaction scope should list only required stores, and transactions should stay short. Dexie supports explicitly scoped `r` transactions and resolves the transaction promise when the transaction completes.

## OWNER TRACE
- Database health: `src/data/database/integrity.ts`
- Persistent metadata ownership: `src/data/repositories/MetadataRepository.ts`
- Snapshot/export ownership: `src/data/backup/backupSnapshot.ts`
- Backup format/envelope ownership remains P6.1 under `src/data/backup/`

Flow: opened healthy database -> integrity assertion -> explicit readonly metadata transaction -> repository `listAll()` -> deterministic detached record ordering -> P6.1 envelope creation.

## PRE-CHANGE FLOW
P6.1 defined and validated the backup format, but no production owner existed to read authoritative database records and create a real snapshot from them.

## CHANGE
- Added repository `listAll()` read operation for metadata.
- Added `createKairosDatabaseSnapshot()`.
- Snapshot fails closed through the P5.4 integrity owner before export.
- Snapshot reads metadata through repository ownership inside a Dexie readonly transaction.
- Records are sorted by stable metadata key for deterministic output.
- P6.1 envelope remains the only backup serialization contract.
- Added tests for export contents, detached records, corruption rejection and read-only scope.
- Added `verify:p6:backup-snapshot` static contract.

## NON-SCOPE
- No database schema change or migration.
- No restore/import writes.
- No delete/clear/replacement behavior.
- No merge mode.
- No pre-import safety snapshot.
- No file download/picker UI.
- No compression, encryption or integrity hash.
- No Trade/domain stores.
- No dependencies changed.

## DATA / STATE FLOW
Database -> integrity assertion -> readonly transaction -> repository read -> detached/sorted snapshot -> versioned P6.1 backup envelope.

## PERSISTENCE
Read-only. Production database remains schema V1 / metadata-only. `package-lock.json` remains SHA-256 `2b7a654d6f69ad43053d5b327dd9ef191982b713314906cdc7587451721025bf`.

## SECURITY
No new network, secret, authority or executable-content surface. Snapshot data remains local application data. No secrecy claim is made for backups.

## THEME
No impact.

## OFFLINE
Fully local/offline.

## TESTS
P6.2 coverage includes:
- authoritative metadata exported into the P6.1 envelope;
- deterministic key order and correct counts;
- detached backup objects cannot mutate persisted data;
- malformed/corrupt database records block export rather than creating a valid-looking backup;
- snapshot owner contains no persistent mutation operations.

## REGRESSION
Local static contracts PASS through P6.2:
- P2.1-P2.3
- P3.1-P3.5
- P4.1-P4.3
- P5.1-P5.5
- P6.1-P6.2

Dependency-backed `npm ci` / typecheck / Vitest / production build remain authoritative GitHub CI work.

## PERFORMANCE
One explicit export performs one integrity inspection plus one scoped metadata snapshot read. No polling, observers, startup scan or background export work is introduced.

## KNOWN LIMITATIONS
The snapshot currently contains metadata only because production schema V1 contains only metadata. Future domain stores must be deliberately added to both database schema and backup format/snapshot ownership when their roadmap patches arrive.

## REAL-DEVICE STATUS
Not required for this non-UI data-layer patch.

## RESULT
HOLD pending authoritative GitHub full-gate PASS.

## NEXT
Only after PASS: audit P6.3 for pre-restore validation and recoverable pre-import snapshot ownership. Do not implement destructive replacement until validation and recovery prerequisites are locked.
