# KAIROS P15.1 — MARKET DATA ADAPTER INTERFACE FOUNDATION

## PATCH / BASE / IDENTITY
- Patch: P15.1 — Market Data Adapter Interface Foundation
- Base: P14.9 Trade Visualizer System Closure (canonical PASS required before promotion)
- Date: 2026-09-03

## OBJECTIVE
Create the first P15 ownership boundary without selecting or implementing a concrete exchange/provider. The patch defines typed external market observations, explicit connection state, a replaceable subscription adapter, lifecycle cancellation, and a close handle.

## RESEARCH
Current MDN Web API guidance was reviewed before implementation:
- The standard `WebSocket` API is widely supported but does not provide backpressure.
- `WebSocketStream` provides stream backpressure but is non-standard/limited and should not be selected as the Kairos cross-browser owner at this interface-foundation stage.
- `AbortSignal` is a widely available cancellation primitive suitable for abortable asynchronous/lifecycle APIs.

Architectural consequence: P15.1 defines transport-neutral lifecycle/cancellation contracts only. It deliberately does not choose WebSocket, WebSocketStream, polling, SSE, or a provider-specific SDK.

## OWNER TRACE
- P14 remains owner of Trade Visualizer presentation and authoritative journal-derived trade facts.
- P11 remains owner of Calculation Engine financial truth.
- P5 remains owner of local persistence infrastructure.
- New P15 service boundary owns only adaptation of external market observations.

## PRE-CHANGE FLOW
No P15 market-data service boundary existed. P14 closure explicitly forbade live/synthetic market ownership inside presentation components.

## CHANGE
Added:
- `src/services/market-data/marketDataTypes.ts`
- `src/services/market-data/MarketDataAdapter.ts`
- `src/services/market-data/index.ts`
- `tests/market-data-adapter-contract.test.ts`
- `scripts/verify-p15-1-market-data-adapter-interface.mjs`
- package verifier registration
- this report

Contract details:
- instrument identity is explicit: venue + symbol
- observed price uses existing `DecimalString`
- application observation receipt time is explicit
- provider/source timestamp is explicit and nullable
- connection state distinguishes idle / connecting / live / disconnected / error
- subscription has an explicit `close()` lifecycle
- caller may pass `AbortSignal`

## NON-SCOPE
No concrete provider.
No exchange endpoint.
No WebSocket/EventSource/fetch implementation.
No retry policy.
No reconnection algorithm.
No buffering/backpressure implementation.
No persistence.
No UI wiring.
No chart wiring.
No P&L calculation.
No execution mutation.
No synthetic candle/path/history.

## DATA / STATE FLOW
Future intended direction:
provider implementation -> MarketDataAdapter -> typed MarketPriceObservation -> future P15/P16 consumer boundary.

The observation cannot overwrite journal execution truth merely by existing in this interface.

## PERSISTENCE
None.

## SECURITY
No credentials, secrets, endpoints, or provider tokens introduced.

## THEME
No UI/theme changes.

## OFFLINE
No online provider is implemented. Existing offline journal behavior remains untouched.

## TESTS
- Static verifier confirms interface ownership, DecimalString use, explicit timestamps/state, lifecycle cancellation, and no transport/persistence/UI implementation.
- Runtime contract test exercises replaceability, close lifecycle, and AbortSignal acceptance using an in-memory probe implementation.

## REGRESSION
P14 production sources are unchanged. Earlier Calculation Engine, journal, persistence, and presentation owners are not modified.

## PERFORMANCE
No runtime network connection, loop, observer, timer, or buffering behavior is added.

## KNOWN LIMITATIONS
This is an interface foundation only. Provider semantics, rate limits, sequencing, stale-data policy, reconnect behavior, and backpressure strategy remain future controlled P15/P16 work.

## REAL-DEVICE STATUS
Not applicable for an interface-only patch.

## RESULT
HOLD pending canonical GitHub gate. Local static verifier PASS. Runtime/build/full regression must be established by canonical gate before this candidate becomes authoritative.

## NEXT
Only after canonical PASS: continue one dependency-safe P15 sub-patch, likely market-observation validation/staleness semantics before any concrete crypto live-feed provider.
