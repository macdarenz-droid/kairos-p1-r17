# KAIROS P16.12 — Binance Spot Browser Stream Connector

## OBJECTIVE
Implement exactly one concrete browser transport adapter behind the existing P16.4 injected Binance Spot public-stream connector boundary.

## BASE
Canonical PASS P16.11.

## OWNER TRACE
- P16.3 owns secure Binance raw-stream endpoint composition.
- P16.4 owns the provider-neutral injected connector seam used by Binance composition.
- P16.12 owns only translation between the native browser WebSocket event surface and that existing seam.
- P15 remains owner of higher subscription/reconnect abstractions.
- Journal execution truth remains separate and immutable from market-reference transport.

## CHANGE
Added `binanceSpotBrowserStreamConnector.ts` at the exact source path approved by P16.11. It creates one native browser WebSocket, forwards open/message/error/close evidence, forwards `MessageEvent.data` unchanged, and returns an idempotent close handle.

## NON-SCOPE
No reconnect scheduling, retry policy, clock acquisition, provider payload mapping, persistence, charting, journal writes, credentials, account streams, order execution, AbortSignal ownership, or P17 work.

## OFFLINE
Failure or absence of live market transport does not alter local journal ownership or persistence.

## TESTS
Dedicated runtime tests cover one connection, event forwarding, raw message data forwarding, idempotent close, and absence of reconnect behavior. Dedicated static verifier rejects timers, storage, fetch, AbortController, random jitter, and wall-clock acquisition in this owner.

## RESULT
HOLD until canonical GitHub gate PASS.
