# KAIROS P16.15 — Binance Spot serverShutdown Reconnect Execution Composition

## Patch/Base/app/build identity
BASE: canonical PASS P16.14. CANDIDATE: P16.15.

## OBJECTIVE
Compose Binance Spot `serverShutdown` evidence with the existing P15 bounded reconnect execution owner without creating a provider-specific retry algorithm or scheduler.

## RESEARCH
Current Binance Spot WebSocket documentation states that a connection is valid for 24 hours, `serverShutdown` is emitted before shutdown/disconnection, and clients should establish a new connection as soon as possible to avoid interruption. P16.15 therefore treats the already-classified event as transient reconnect evidence while leaving retry bounds and delay policy to P15.

## OWNER TRACE
P16.14 owns provider-event-to-disconnect-cause classification. P15.13 `executeMarketDataReconnectAttempt` owns reconnect disposition, attempt bounds, jitter-derived plan, scheduler use, and optional AbortSignal cancellation. P16.15 only composes those owners and preserves Binance event time as provenance.

## PRE-CHANGE FLOW
P16.14 could resolve `serverShutdown` to `{kind:'transient-failure'}`, but no Binance composition called the existing P15 reconnect executor with that cause.

## CHANGE
Added a pure composition entry point that resolves a Binance message, and only for `serverShutdown`, delegates the cause to P15 reconnect execution using caller-injected scheduler, policy, completed-attempt count, entropy sample, reconnect callback, and optional AbortSignal.

## NON-SCOPE
No WebSocket construction, close ownership, reconnect callback implementation, timer implementation, clock acquisition, entropy generation, new retry policy, persistence, chart rendering, journal mutation, credentials, account streams, or order execution.

## DATA/STATE FLOW
raw message -> P16.14 cause classification -> P15.13 reconnect execution -> injected scheduler/callback. Non-serverShutdown/invalid messages do not schedule.

## PERSISTENCE
None.

## SECURITY
Public read-only market-data path only. No credentials or secret material.

## THEME
No UI.

## OFFLINE
Offline journal behavior unchanged; this code runs only when supplied live-stream evidence exists.

## TESTS
Dedicated verifier checks required ownership composition and forbids new transport/timer/storage/clock/random owners. Runtime tests cover scheduled serverShutdown retry, non-serverShutdown no-op, and P15 attempt-limit preservation.

## REGRESSION
P16.14 cause classification and all P15 reconnect semantics remain owners rather than duplicated logic.

## PERFORMANCE
O(1) per serverShutdown event; no loops or collections added.

## KNOWN LIMITATIONS
P16.15 does not yet integrate this composition into the concrete live Binance subscription lifecycle. That remains a later controlled slice.

## REAL-DEVICE STATUS
Not claimed until integrated browser lifecycle closure is canonically verified.

## RESULT
HOLD pending canonical GitHub Actions gate.
