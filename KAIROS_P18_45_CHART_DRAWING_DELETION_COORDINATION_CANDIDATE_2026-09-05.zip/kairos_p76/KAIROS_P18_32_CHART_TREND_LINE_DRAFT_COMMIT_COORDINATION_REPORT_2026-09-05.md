# Kairos P18.32 — Chart Trend-Line Draft Commit Coordination

## Authority
Built from canonical P18.31 authority (Kairos Controlled Roadmap Gate #237, run 33887431810, head a5be92c33c9671933bf1eb57d46fc69a0583b502).

## Added responsibility
P18.32 owns only provider-neutral coordination of a complete trend-line preview draft into the already-existing authoritative commit path:

1. Read current state and anchors from the P18.29 interaction/draft session.
2. Require `preview` + `trend-line`.
3. Delegate drawing-shape construction to P18.31 using caller-supplied `ChartDrawingId`.
4. Delegate `commit-drawing` through the same P18.29 -> P18.24 -> P18.23 interaction path.
5. Return the constructed drawing only if the authoritative session confirms matching `committed` state.
6. P18.29 clears only its P18.28R1 ephemeral draft anchors after that successful commit lifecycle transition.

## Ownership preserved
- P18.1 remains committed drawing shape owner.
- P18.23 remains sole interaction transition-semantics owner.
- P18.24 remains sole active current-state/dispatch owner.
- P18.28R1 remains sole ephemeral draft-anchor evidence owner.
- P18.29 remains draft/interation lifecycle coordination owner and clears only its existing draft evidence.
- P18.31 remains sole draft -> committed trend-line shape constructor.
- P18.32 stores no parallel state, anchors, or committed drawing collection.

## Explicit non-scope
No drawing-ID allocation; no committed drawing collection; no persistence/restore; no provider APIs; no coordinate conversion; no toolbar/UI state; no selection rendering; no drag/edit/delete execution; no undo/redo; no new drawing kinds; no Risk/Reward/P19 semantics; no journal truth; no calculation/navigation/toolchain migration.
