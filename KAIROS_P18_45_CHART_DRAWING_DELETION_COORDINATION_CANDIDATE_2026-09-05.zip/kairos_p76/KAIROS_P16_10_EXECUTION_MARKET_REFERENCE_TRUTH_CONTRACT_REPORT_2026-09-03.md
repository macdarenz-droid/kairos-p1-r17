# KAIROS P16.10 — Execution vs Market Reference Truth Contract

## OBJECTIVE
Close the pre-P17 ambiguity between journal execution truth and external market-reference truth without adding charting, reconciliation, persistence, or transport behavior.

## RESEARCH
Official Binance Spot stream documentation distinguishes raw trade events (individual trade price `p` and trade time `T`) from kline/candlestick interval data (open `o`, close `c`, high `h`, low `l`, interval start/close times). Public market-data-only endpoints are unauthenticated market evidence. Therefore a Binance market value is provider/venue evidence and is not proof of the user's broker fill.

## OWNER TRACE
- TradeExecutionRecord remains journal execution truth owner.
- P11 Calculation Brain continues deriving trade metrics from journal execution truth.
- P15/P16 MarketPriceObservation remains external market observation owner.
- P16.10 application boundary owns only the side-by-side truth projection/provenance contract.
- P17 may render these facts but must not reconcile or overwrite them.

## PRE-CHANGE FLOW
Journal executions and Binance market observations were separately owned, but no explicit cross-boundary contract stated what happens when their prices disagree.

## CHANGE
Adds an immutable projection containing `execution` and `marketReference` as separate facts, explicit `reconciliation: 'none'`, and `mayOverwriteExecution: false`.

## NON-SCOPE
No discrepancy threshold, no automatic correction, no OHLC comparison, no candle fetching, no chart engine, no persistence writes, no broker reconciliation, no venue inference, no P&L changes, no transport/lifecycle changes.

## DATA/STATE FLOW
Existing TradeExecutionRecord + existing MarketPriceObservation -> pure projection -> consumer/rendering boundary. Inputs are not mutated.

## PERSISTENCE
None.

## SECURITY
No credentials, account data, orders, or executable remote content.

## THEME / OFFLINE
No UI/theme ownership. Pure projection works offline when both facts are already available.

## TESTS
Dedicated runtime tests prove disagreeing prices remain side by side, execution price remains unchanged, provenance is retained, and nullable source timestamp is not invented. Static verifier forbids persistence/network/time/random ownership.

## REGRESSION
Designed as additive application-layer contract only. Existing journal and market-data owners are imported, not duplicated.

## PERFORMANCE
O(1) immutable projection; no journal scans, subscriptions, timers, or observers.

## KNOWN LIMITATIONS
P16.10 intentionally does not decide whether a difference is material. A later explicit comparison policy may classify evidence, but cannot mutate execution truth. Candle OHLC semantics belong to future historical market-data/chart work and must remain contextual rather than execution authority.

## RESULT
Candidate ready for canonical gate. Canonical PASS required before authority promotion.
