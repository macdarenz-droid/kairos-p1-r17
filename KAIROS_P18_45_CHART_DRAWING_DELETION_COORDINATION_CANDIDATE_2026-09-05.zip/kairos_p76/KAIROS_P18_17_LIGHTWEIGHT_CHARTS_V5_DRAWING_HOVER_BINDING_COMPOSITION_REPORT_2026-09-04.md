# Kairos P18.17 — Lightweight Charts v5 Drawing Hover Binding Composition

## Authoritative base
P18.16 — canonical PASS, GitHub Actions run #217 / run ID 33843224723 / head 3f4bf3f7671c061d4ceebcc24aae72b74d18b32c.

## Controlled purpose
Compose the canonical provider chart-resolution owner with the existing provider hover-subscription lifecycle without exposing Lightweight Charts APIs on the provider-neutral `ChartEngineSeriesHandle`.

## Evidence and ownership
- P18.16 `LightweightChartsV5DriverBinding.resolveChart(handle)` remains the provider chart identity owner.
- P18.15R1 remains the `subscribeCrosshairMove` / `unsubscribeCrosshairMove` lifecycle owner.
- P18.14 remains the `hoveredObjectId` -> Kairos drawing-hover projection owner.
- Lightweight Charts 5.2 official API documents `subscribeCrosshairMove(handler)` and `unsubscribeCrosshairMove(handler)` on `IChartApi`; `hoveredObjectId` is the provider hover identity field.

## Added
- `createLightweightChartsV5DrawingHoverSubscriptionFromBinding(...)`.
- Runtime structural capability validation for provider crosshair subscription APIs.
- Delegation to P18.15R1 after P18.16 chart resolution.
- Dedicated P18.17 verifier and tests.

## Failure semantics
If the resolved provider chart lacks the required crosshair subscription capability, the composition fails closed with `chart-drawing-hover-capability-unavailable` before a subscription is created.

## Explicit non-scope
No click subscription, selection state, drag/edit, drawing-truth mutation, persistence, calculation, market acquisition, journal truth, toolbar state, navigation, autoscale policy, or P19 behavior.
