# KAIROS P11.22 TradeMetrics P&L Percentage Evidence Wiring Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Authoritative base
P11.21 TradeMetrics Net P&L Evidence Wiring, passed canonical GitHub gate run #48.

## Objective
Wire the existing P11.6 exact PercentageCalculator into TradeMetrics through an explicit evidence boundary, without inventing what capital/notional/account basis a market should use.

## Research / architecture decision
The controlling handoff defines `pnlPercent` as an optional derived TradeMetrics field, assigns percentage arithmetic to the Calculation Engine, and forbids missing financial data from silently becoming zero. It also requires market/instrument-specific behavior below the common Calculation Engine. Therefore P11.22 accepts explicit `resultAmount` and `basisAmount` evidence and does not derive a universal denominator from entry price, quantity, leverage, account balance, margin, or market type.

The existing P11.6 PercentageCalculator remains the sole arithmetic owner and uses the locked decimal kernel. No native Number arithmetic is introduced.

## Owner trace
Caller-supplied authoritative percentage evidence -> TradeMetrics -> P11.6 PercentageCalculator -> decimal kernel -> TradeMetrics `pnlPercent` + completeness.

## Change
- `TradeMetricsPnlPercentageInput` carries explicit `resultAmount` and `basisAmount` DecimalStrings.
- `TradeMetrics.pnlPercent` becomes `DecimalString | null`.
- `hasPnlPercent` becomes evidence-derived boolean.
- zero basis fails explicitly as `zero-pnl-percentage-basis`.
- malformed decimal evidence fails explicitly as `invalid-pnl-percentage-decimal`.
- absence of percentage evidence preserves `pnlPercent: null` / `hasPnlPercent: false`.

## Non-scope
No universal P&L percentage denominator policy; no market-specific notional/margin/account-balance rule; no FX; no persistence/schema/repository changes; no UI; no P12 journal history; no deployment changes.

## Tests
New tests cover absent evidence, exact positive percentage, negative percentage, zero basis, and malformed evidence.

## Result
HOLD until canonical GitHub gate runs deterministic install, build, full unit regression, all prior roadmap regressions, and `verify:p11:trade-metrics-pnl-percentage-evidence`.

## Compatibility verifier maintenance
The historical P11.5 static verifier previously required the implementation literal `pnlPercent: null`. P11.22 legitimately evolves that optional field, so the verifier is minimally relaxed to require the `pnlPercent:` contract while the original P11.5 unit regression and the new P11.22 tests preserve missing-evidence behavior. No runtime ownership is changed by this verifier maintenance.
The same minimal compatibility maintenance is applied to the P11.14 and P11.21 static verifiers, which also encoded the old literal-null implementation. Their runtime/unit regressions remain unchanged; P11.22 adds the explicit absent-evidence regression.
