# KAIROS P12.1R1 Journal History Query Scope Repair

Status: HOLD pending canonical GitHub gate.

## Objective
Repair the P12.1 P1 static-scope failure without weakening the locked P1 architecture guard.

## Failure repaired
P12.1 used the exact calculation-domain type token `TradeMetrics` in `src/application/journal/historyQuery.ts`. The locked P1 static contract reserves that owner token to `src/domain/calculations/`, so the canonical gate correctly rejected the candidate.

## Controlled repair
- Keep the P12 journal history orchestration in the application layer.
- Keep all financial calculation behavior delegated to `calculateTradeMetrics()`.
- Remove the direct named `TradeMetrics` type dependency from the application-layer contract.
- Derive the successful metric value type from `TradeMetricsResult` instead.
- Do not change calculations, persistence, schema, UI, routing, FX behavior, or P1 guard rules.

## Promotion rule
PASS only if deterministic install, build, full unit regression, full P1-P12.1R1 controlled regression, P1 static guard, and P12.1R1 verifier all pass in canonical GitHub Actions.
