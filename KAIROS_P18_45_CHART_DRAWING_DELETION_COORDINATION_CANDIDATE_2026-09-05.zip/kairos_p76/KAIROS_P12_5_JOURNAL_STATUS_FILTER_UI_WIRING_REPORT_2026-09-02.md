# KAIROS P12.5 — Journal Status Filter UI Wiring

Status: HOLD pending canonical GitHub gate.

## Base
Exact canonical P12.4R4 PASS artifact from GitHub Actions run #62, artifact 9825250849.

## Objective
Wire a small, accessible status filter into the real `/journal` history UI using the indexed P12.4 query foundation. The UI must never load all trades and filter them in React memory.

## Research
- React official `<select>` guidance: a controlled select uses `value` plus synchronous `onChange` state updates.
- W3C WAI forms guidance: dropdown controls need clear associated labels and instructions/relationships that remain understandable on mobile.
- Kairos controlling handoff performance rule: query through database indexes; do not always load all trades and filter in React. Journal filter query is an explicit performance canary.

## Owner trace
User changes `Show trades` -> local `JournalRoute` filter state -> `listJournalHistory(db, {status})` -> existing P12 application query -> existing P12.4 `TradeRepository.listRecentByStatusAndUpdatedAt()` -> Dexie compound `[status+updatedAt]` index -> P11 metrics -> `JournalHistoryList` presentation.

## Change
- Add local `TradeStatus | ''` filter state to `JournalRoute`.
- Re-run the existing application query whenever the filter changes.
- Add a request-sequence guard so stale async query results cannot overwrite a newer filter selection.
- Add an accessible controlled `Show trades` select with All/Draft/Open/Closed/Cancelled.
- Add filtered empty-state wording.
- Add small responsive filter layout using existing semantic tokens/layout primitives.
- Extend route tests for indexed filter behavior, filtered empty state, save-status role uniqueness, and rapid filter changes.
- Update the historical P12.3R1 verifier only so it accepts the same `listJournalHistory` owner with query options; direct storage ownership remains forbidden.
- Add a P12.5 static verifier.

## Non-scope
No schema/migration change. No repository/query redesign. No free-text search. No date/symbol filters. No trade editing/deletion. No P13 Visual P&L. No new calculation owner. No toolchain change.

## Persistence
None. Filter selection is intentionally temporary UI state and is not persisted.

## Performance
No load-all React filtering is introduced. Each status selection delegates to the existing indexed compound status/update query. One request-sequence ref is added; no timers, observers, RAF loops, DOM scans, or additional persistent listeners are introduced.

## Accessibility / mobile
Visible label is associated with the native select. The control remains full width at <=420px. Loading remains `aria-live="polite"` without `role="status"`, preserving the unique P10 save confirmation status role.

## Verification
Local static PASS:
- P1 static ownership contract.
- P12.1R1 query scope verifier.
- P12.2 indexed bounded query verifier.
- P12.3R1 route/accessibility verifier, updated only for query-options compatibility.
- P12.4 status-index verifier.
- P12.4R2 backup compatibility verifier.
- P12.4R3 historical verifier compatibility.
- P12.4R4 package verifier integrity: all 69 `verify:p*` registrations resolve.
- P12.5 status-filter UI verifier.

A local `npm ci` attempt timed out and left an incomplete dependency tree, so subsequent local build/test missing-type errors are not promoted as application failures. Canonical GitHub gate must perform a clean deterministic install, production build, full unit regression, full controlled roadmap verifier sweep, and P12.5 verifier before PASS.

## Result
HOLD until canonical gate succeeds.
