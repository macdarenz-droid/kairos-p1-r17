# Kairos P1 Verification Report — R17
Date: 2026-08-31
Status: HOLD

## Objective
Make an external clean verification run self-reporting so a successful or blocked run can be brought back as concrete machine-readable evidence instead of relying on copied terminal text.

## Research
npm documents `package-lock.json` as the exact dependency-tree record intended to make installs reproducible across teammates, deployments, and CI. `npm ci` requires an existing lockfile, rejects manifest/lock mismatches, and never rewrites the lock. Node's built-in crypto hashing API can produce SHA-256 digests without adding another dependency.

## Controlled change
`npm run release:p1` now always writes `P1_GATE_EVIDENCE.json` on PASS, HOLD, or FAIL.

Evidence includes:
- P1 evidence schema version;
- start/completion timestamps;
- overall PASS/HOLD/FAIL;
- Node/npm/platform information;
- SHA-256 of `package.json`;
- SHA-256 of `package-lock.json` when one exists;
- every executed release step, command, exit code, and status;
- the exact step that blocked or failed the sequence.

The evidence file is generated output and is excluded from source control. It does not become a second verification authority: `release:p1` remains the gate owner.

## Owner flow
release request
-> `npm run release:p1`
-> ordered P1 gate steps
-> PASS/HOLD/FAIL
-> generated `P1_GATE_EVIDENCE.json`

## Evidence in this environment
The real release command was executed. It produced HOLD evidence after:
- Toolchain: PASS
- Static contract: PASS
- Resolve lockfile: HOLD (npm registry/network unavailable)

No later step ran after HOLD.

## Non-scope
No app runtime, UI, router, domain, persistence, theme, market, journal, calculation, or P2 behavior changed.

## Decision
HOLD. P0 remains authoritative. P2 remains locked.
