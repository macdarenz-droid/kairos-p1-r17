# KAIROS P17.13R2 — Chart Visible Range Typed Mock Repair

## BASE
P17.12 Incremental Chart Engine Driver Composition — canonical PASS #184.

## CURRENT SLICE
P17.13 Chart Visible Range Boundary, repaired forward from the authoritative P17.12 base.

## EVIDENCE
Canonical Run #188 passed exact scope, deterministic install, and exact lightweight-charts 5.2.1 verification, then failed TypeScript compilation.

Compiler-proven defects:
- tests/chart-engine-driver-incremental.test.ts: vendor chart mock missing required timeScale().
- tests/lightweight-charts-v5-module-adapter.test.ts: three vendor chart mocks missing required timeScale().

## CHANGE
Added the minimum typed timeScale() test stubs required by the P17.13 vendor API seam. No production behavior was broadened.

## NON-SCOPE
No provider acquisition, Binance behavior, persistence, journal truth, calculations, drawings, markers, navigation, theme, or P18 work.

## STATUS
Candidate only. Canonical GitHub gate required before authority promotion.
