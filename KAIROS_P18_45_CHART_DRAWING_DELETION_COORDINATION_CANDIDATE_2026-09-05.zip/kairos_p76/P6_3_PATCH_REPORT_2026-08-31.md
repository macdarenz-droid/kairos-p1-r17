# KAIROS P6.3 Restore Preflight + Recovery Snapshot Patch Report

Date: 2026-08-31  
Status: HOLD pending authoritative GitHub full gate  
Base: P6.2 Database Snapshot Export — PASS / LOCKED (GitHub Actions run #66)  
Base commit: 5f4469a2f1764cea3ae5d8ecaff294627fc0046a

## OBJECTIVE
Add the smallest safe restore prerequisite after P6.2: validate an incoming serialized Kairos backup for restore compatibility, produce a non-destructive restore preview, and preserve the current authoritative database as a separately serializable recovery snapshot before any future destructive import is allowed.

## RESEARCH
Re-checked the controlling Kairos safe-import order and current IndexedDB/Dexie transaction behavior. The locked architecture requires validation before user confirmation, a recoverable pre-import state before destructive import, then transactional import and a post-import integrity sweep. MDN confirms IndexedDB mutations belong in scoped readwrite transactions and transaction abort rolls back transaction changes. P6.3 deliberately stops before mutation.

## OWNER TRACE
- Structural backup parsing/validation: `src/data/backup/backupValidation.ts` + `backupSerialization.ts` (P6.1).
- Authoritative current-database snapshot: `src/data/backup/backupSnapshot.ts` (P6.2).
- Restore-specific compatibility/preparation: `src/data/backup/restorePreflight.ts` (P6.3).

## PRE-CHANGE FLOW
P6.1 could validate backup structure and P6.2 could export the current database, but no restore-preparation owner guaranteed incoming compatibility or preserved current data before a later replacement operation.

## CHANGE
- Added `preflightKairosRestore()`.
- Added typed `KairosRestorePreflightError` codes for incompatible DB schema and duplicate persistent keys.
- Requires incoming `databaseSchemaVersion` to match the currently supported production schema before restore preparation.
- Rejects duplicate metadata keys that would make replacement ambiguous.
- Added immutable restore preview containing version/timestamp/count information only.
- Added `createKairosRecoverySnapshot()` reusing P6.2 snapshot ownership and P6.1 serialization.
- Added `prepareKairosRestore()` with strict order: incoming parse/validation -> restore compatibility -> preview -> recoverable current-state snapshot.
- Added tests and static verification.

## NON-SCOPE
- No restore/import writes.
- No clear/delete/replacement behavior.
- No merge mode.
- No user confirmation UI.
- No transactional import yet.
- No post-import integrity sweep yet.
- No backup-format migration because only format V1 exists.
- No schema migration.
- No Trade/domain stores.
- No encryption/compression/hash.
- No dependency changes.

## DATA / STATE FLOW
Incoming JSON -> P6.1 parse/structural validation -> P6.3 compatibility + duplicate-key dry run -> immutable preview -> P6.2 snapshot of current DB -> P6.1 serialization -> prepared restore package. P6.3 stops before database mutation.

## PERSISTENCE
No schema or migration change. Production remains DB schema V1 / metadata-only. `package-lock.json` SHA-256 remains `2b7a654d6f69ad43053d5b327dd9ef191982b713314906cdc7587451721025bf`.

## SECURITY
Incoming JSON remains untrusted data. No code execution, secret, encryption or authentication claim is introduced. Invalid/unsupported restore inputs fail before recovery preparation.

## THEME
No impact.

## OFFLINE
Fully local/offline.

## TESTS
P6.3 coverage includes:
- valid incoming backup produces preview plus recovery snapshot while current DB remains unchanged;
- unsupported database schema rejected;
- duplicate persistent keys rejected;
- invalid JSON fails before recovery snapshot work;
- P6.3 owner contains no destructive persistence operation.

## REGRESSION
Local static contracts PASS through P6.3:
- P2.1-P2.3
- P3.1-P3.5
- P4.1-P4.3
- P5.1-P5.5
- P6.1-P6.3

Dependency-backed typecheck/Vitest/production build remain authoritative GitHub CI work.

## PERFORMANCE
Restore preparation is explicit user-driven work only. It adds no polling, startup observer, background scan or render-time calculation. Recovery snapshot cost is the same bounded database snapshot path established in P6.2.

## KNOWN LIMITATIONS
The restore preflight currently has one production store (metadata) because DB schema V1 has one production store. Future stores/backups must extend restore dry-run validation deliberately.

## REAL-DEVICE STATUS
Not required for this non-UI foundation patch.

## RESULT
HOLD pending authoritative GitHub full-gate PASS.

## NEXT
Only after PASS: audit P6.4 transactional validated replacement. It must consume a prepared/validated restore, replace the scoped stores in one short atomic transaction, roll back on failure, and then run post-import integrity before the restored state can be treated as successful. Merge remains out of scope.
