# KAIROS P11.4 Flat-Trade Gross Realized P&L Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.3 authoritative PASS from controlled gate run #22.

## Objective
Introduce the first actual derived trade result while preserving conservative accounting semantics.

## Research / accounting basis
Broker reporting distinguishes realized P&L from unrealized P&L and may use explicit lot-matching methods such as FIFO for partial positions. Because KAIROS has not yet locked a partial-position cost-basis policy, P11.4 refuses to estimate partial realized P&L.

For a mathematically flat trade, total gross result is unambiguous from aggregate execution notionals:
- long: exit notional - entry notional
- short: entry notional - exit notional

## Data flow
P9 executions -> P11.1R2 decimal kernel -> P11.2 aggregation -> P11.3 balance assessment -> P11.4 flat-trade gross realized P&L.

## Availability rule
Gross realized P&L is available only when P11.3 state is `flat`.
For `empty`, `open`, or `partially-exited`, result is explicitly unavailable.
Invalid execution balances remain errors.

## Precision
All arithmetic uses P11.1R2 decimal string arithmetic; no native Number/parseFloat/Math arithmetic.

## Non-scope
No fee netting, commissions, taxes, FX/currency conversion, partial-position cost basis, FIFO/LIFO/average-cost policy, unrealized P&L, live prices, leverage, R-multiple, UI, persistence, schema, journal history, activation, or network changes.

## Verification
Tests cover long profit/loss, short profit/loss, multi-fill flat trades, open unavailable, partial unavailable, fractional precision, and impossible over-exit propagation.

## Result
HOLD until canonical GitHub gate passes build, full tests, P1-P10.3R2 regressions, P11.1R2-P11.3 regressions, and P11.4 verification.
