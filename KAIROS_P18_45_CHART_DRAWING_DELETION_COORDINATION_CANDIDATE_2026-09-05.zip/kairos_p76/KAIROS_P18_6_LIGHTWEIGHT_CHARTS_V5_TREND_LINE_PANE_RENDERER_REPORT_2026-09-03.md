# KAIROS P18.6 — Lightweight Charts v5 Trend-Line Pane Renderer

## Authority
Built directly from canonical P18.5 after GitHub Actions run #201 (`33762648242`) completed successfully at head `97310da0986ac51a13f6dc2cb92a72ac65b2114e`.

## Controlled purpose
Add the first provider Canvas rendering boundary for already-projected trend-line screen segments. P18.5 remains the sole time/price-to-screen coordinate projection owner.

## Production ownership
`lightweightChartsV5TrendLinePaneRenderer.ts` owns only provider pane stroke rendering. It accepts screen-space segments and injected presentation stroke style, then renders through Lightweight Charts v5 bitmap coordinate space.

## Explicit non-scope
No time/price conversion, primitive attachment lifecycle, primitive view lifecycle, hit testing, pointer/crosshair capture, drag/edit state, toolbar, persistence, autoscale ownership, calculations, market acquisition, journal truth, or P19 risk/reward behavior.

## Official API evidence
Lightweight Charts 5.2 documents `IPrimitivePaneRenderer.draw(target)` for Canvas rendering and recommends primitive pane views/renderers for custom series graphics. Official current guidance uses bitmap coordinate space for pixel-aligned strokes. P18.6 follows that rendering boundary without taking over the P18.5 coordinate owner.

## Exact controlled diff from P18.5
1. `KAIROS_P18_6_LIGHTWEIGHT_CHARTS_V5_TREND_LINE_PANE_RENDERER_REPORT_2026-09-03.md`
2. `package.json`
3. `scripts/verify-p18-6-lightweight-charts-v5-trend-line-pane-renderer.mjs`
4. `src/features/chart/index.ts`
5. `src/features/chart/lightweightChartsV5TrendLinePaneRenderer.ts`
6. `tests/lightweight-charts-v5-trend-line-pane-renderer.test.ts`

## Verification status before canonical gate
Dedicated static verifier is intended to run locally. Canonical GitHub Actions remains authoritative for deterministic install, TypeScript, production build, Vitest, full roadmap regression, prior chart regressions, historical closures, and artifact promotion.
