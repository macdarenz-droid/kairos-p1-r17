# KAIROS PATCH REPORT

Patch: P13.12R2 — Accessible Name Test Contract Repair
Base: P13.11R1 canonical PASS, Run #90, gate SHA 771fcc8c13ec02119f8946bf632c6d959b3dfc77.
Rejected predecessors: P13.12 Run #91; P13.12R1 Run #92.

## FAILURE EVIDENCE
P13.12R1 confirmed the textbox is present. Testing Library exposes its accessible name as:
`Time zone Use an IANA time zone, for example Australia/Sydney, America/New_York, Europe/London, or UTC.`

The R1 helper incorrectly queried the exact short name `Time zone`, so all three new tests failed before the async wait.

## REPAIR
Production SettingsRoute, route wiring, CSS, validation, persistence ownership and no-device-inference behavior remain unchanged.

Tests now:
- query the textbox using the actual accessible-name semantics via a stable regex;
- then wait for the existing async preference load to enable the field;
- preserve unconfigured, valid-save and invalid-write-protection coverage.

## NON-SCOPE
No production behavior change. No ARIA/label restructuring. No storage change. No timezone inference. No verifier weakening. No P&L arithmetic, FX, grouping, calendar navigation, animation, schema or index change.

## RESULT
HOLD pending canonical GitHub gate.
