# Kairos P4.2 Patch Report — Service Worker App Shell + Controlled Update Lifecycle

## Objective
Add the PWA service-worker foundation without allowing the worker to own business state or to force normal updates into active clients.

## Owner flow
Browser bootstrap -> serviceWorkerRegistration owner -> /sw.js lifecycle -> versioned app-shell cache -> navigation/static fetch handling.
Waiting update -> registration status -> explicit activation command -> waiting worker receives KAIROS_ACTIVATE_UPDATE -> skipWaiting only on that explicit path.

## Scope
- root-scoped service worker registration
- versioned Kairos-owned app-shell cache
- install-time discovery/caching of built shell assets
- network-first same-origin navigation with offline shell fallback
- cache-first same-origin static assets
- cleanup only of obsolete Kairos app-shell caches
- waiting-update detection and explicit activation contract
- no clients.claim() and no unconditional skipWaiting()
- no IndexedDB, domain data, market data, WebSocket, or P5+ persistence ownership

## Non-scope
No update UI, no persistent-storage request/status, no business data caching, no background sync, no market-data caching, no P5 database work.

## Verification status
Source/static contracts PASS locally. Full frozen gate still requires authoritative GitHub verification before promotion.
