# KAIROS P16.4 — Binance Spot Public Stream Connection Boundary

## BASE
P16.3 — canonical PASS, Run #148.

## OBJECTIVE
Introduce the smallest injectable Binance Spot public-stream connection seam above the P16.3 endpoint descriptor and below later concrete transport ownership.

## RESEARCH
Current Binance Spot documentation separates public stream endpoint semantics from connection-lifecycle constraints such as connection lifetime, ping/pong handling, control-message limits, and stream-count limits. P16.4 deliberately does not implement those lifecycle behaviors.

## OWNER TRACE
P16.1 owns provider stream naming.
P16.3 owns public raw-stream URL composition.
P16.4 owns only the injected connector seam.
P16.2 remains the raw trade payload-to-P15 observation mapper.
P15 remains the provider-neutral lifecycle/reconnect policy boundary.

## PRE-CHANGE FLOW
P16.1 stream descriptor -> P16.3 endpoint descriptor.
No controlled production seam existed for opening that endpoint.

## CHANGE
Added `binanceSpotPublicStreamConnection.ts`.
It accepts a validated P16.3 endpoint descriptor, raw message/open/close/error handlers, and an externally supplied connector. It invokes the connector exactly once with the endpoint URL and handlers and returns the connector-owned close handle.

## NON-SCOPE
No concrete browser/network constructor.
No ping/pong implementation.
No connection-lifetime reconnect behavior.
No retry loop.
No concrete timers.
No entropy.
No clock acquisition.
No provider payload mapping.
No account/user stream.
No credentials.
No orders.
No persistence.
No chart rendering.
No journal/P&L mutation.

## DATA/STATE FLOW
P16.1 stream -> P16.3 endpoint -> P16.4 injected connector -> raw provider message handler.
Mapping into a P15 observation remains separately owned by P16.2 and still requires caller-owned receipt time.

## PERSISTENCE
None.

## SECURITY
Public market-data boundary only. No secrets or authenticated endpoints.

## THEME
No UI.

## OFFLINE
Offline journal behavior is untouched. Connector failure cannot mutate journal truth.

## TESTS
Connector gets exact P16.3 URL and handlers once; raw provider payload is forwarded unchanged; closing the returned connection does not create retries/additional connections.

## REGRESSION
P1 static, P16.1, P16.2, P16.3 and dedicated P16.4 verifiers run locally. Canonical gate still required for build/full runtime/full historical regression.

## PERFORMANCE
No polling, observers, timers, persistence, or repeated parsing introduced.

## KNOWN LIMITATIONS
This is not yet a concrete live network implementation. Lifecycle constraints remain intentionally deferred.

## REAL-DEVICE STATUS
Not applicable yet; no concrete transport is created.

## RESULT
HOLD pending canonical GitHub gate.
