# KAIROS P11.15 Fee Aggregation Primitive Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.14 authoritative PASS from controlled gate run #35, artifact 9797793356.

## Objective
Add the smallest safe fee calculation owner required by the locked P11 Calculation Brain contract, without yet wiring net P&L or TradeMetrics.

## Ownership
`TradeFeeRecord[]` evidence -> `FeeCalculator` -> exact `totalFees`.

The primitive owns only aggregation of already-recorded fees.

## Currency safety
Fee records include a currency. P11.15 therefore refuses to add unlike currencies. Mixed-currency evidence returns `mixed-currency` until a later Currency Engine or explicit conversion policy supplies normalized monetary evidence.

## Zero semantics
An explicitly supplied empty fee collection is authoritative evidence that the collection contains no fees, so its exact aggregate is zero. Missing fee evidence is a separate caller-level state and is not converted to zero by this primitive.

## Arithmetic
All amounts are summed through the locked arbitrary-precision decimal kernel. No JavaScript Number authority is introduced.

## Non-scope
- no TradeMetrics wiring;
- no net P&L;
- no P&L percentage;
- no realized-R result selection;
- no FX conversion;
- no market-specific fee rules;
- no repository/persistence/schema change;
- no UI/history/chart/network change.

## Tests
Covers empty-set zero, exact same-currency aggregation, 0.1+0.2 precision, malformed decimal rejection, and mixed-currency rejection.

## Regression
P1 and every existing P11 static verifier through P11.14 are rerun locally, plus P11.15. Canonical GitHub gate must run build, full unit regression, P1-P11.15 and artifact capture.

## Result
HOLD pending canonical GitHub gate.
