# KAIROS PATCH REPORT

Patch: P13.2 Journal Visual P&L Projection Wiring
Base: P13.1R3 canonical PASS (Run #73, head d00297d3bd8c1a88e657c7d88eea8af7fd3ba359)
App version: unchanged
Build ID: unchanged

## OBJECTIVE
Wire the P13.1 Visual P&L semantic projection into each bounded P12 Journal History entry so later P13 visual surfaces consume one explicit outcome contract rather than recalculating or inferring P&L in UI code.

## RESEARCH
Re-read the controlling handoff and P13 vision. The product requires a visual-first P&L logbook while preserving Calculation Engine ownership, bounded IndexedDB journal queries, no hidden FX, and no color-only meaning. No external API/library behavior is changed by this application-composition patch.

## OWNER TRACE
P11 Calculation Engine remains the financial authority. P12 Journal History remains the bounded repository/query composition owner. P13 Visual P&L owns only semantic projection of already-authoritative TradeMetrics.

## PRE-CHANGE FLOW
Indexed repositories -> P12 listJournalHistory -> P11 calculateTradeMetrics -> JournalHistoryEntry.metrics. P13.1 projection existed but was not wired into journal query results.

## CHANGE
JournalHistoryEntry now exposes `visualPnl: VisualPnlOutcomeProjection`. `listJournalHistory` calls `projectVisualPnlOutcome` on successful P11 metrics and projects calculation failures as `Not available`. Added focused integration tests and a static verifier.

## NON-SCOPE
No UI/calendar/heatmap/equity curve/streak/day aggregation. No schema or repository change. No P11 arithmetic change. No FX/currency inference. No theme tokens. No route changes.

## DATA/STATE FLOW
IndexedDB repositories -> bounded P12 trade selection -> child evidence -> P11 TradeMetrics -> P13 semantic projection -> JournalHistoryEntry consumer.

## PERSISTENCE
None. No schema/migration/backup-format changes.

## SECURITY
No new network, secret, or executable-content surface.

## THEME
None. Semantic outcome contains text labels; presentation colors remain future UI work and must use registered tokens.

## OFFLINE
Fully local/offline; no new dependency.

## TESTS
Focused tests cover profitable zero-fee projection, nonzero-fee incomparable currency evidence remaining unavailable, and invalid calculation evidence remaining visible without dropping the journal entry.

## REGRESSION
P13.1 verifier, P13.2 verifier, P12 closure verifier, USER_HEAVY verifier and canonical full gate required.

## PERFORMANCE
No new database scan. Projection is O(1) per already-bounded journal entry after P11 metrics composition. Existing 100 default / 500 max P12 bounds remain unchanged.

## KNOWN LIMITATIONS
Nonzero-fee journal rows remain unavailable when P11 cannot prove P&L/fee currency comparability. Day-level aggregation is intentionally deferred because P33 Currency Engine is not implemented and incomparable currencies must not be silently summed.

## REAL-DEVICE STATUS
Not required for this non-visual application-composition slice.

## RESULT
HOLD pending canonical GitHub gate.

## NEXT
Only after PASS: continue P13 with the next dependency-safe visual/logbook slice without cross-currency aggregation.
