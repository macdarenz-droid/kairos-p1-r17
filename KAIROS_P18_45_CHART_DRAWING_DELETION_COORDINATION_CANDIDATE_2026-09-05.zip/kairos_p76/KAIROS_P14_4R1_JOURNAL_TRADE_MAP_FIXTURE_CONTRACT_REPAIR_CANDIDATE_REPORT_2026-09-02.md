# KAIROS P14.4R1 — Journal Trade Map Fixture Contract Repair

## OBJECTIVE
Repair the failed P14.4 test fixture against the authoritative TradePlanRecord contract without changing the P14.4 production presentation behavior.

## RESEARCH
The canonical P14.4 gate failed during TypeScript build because the new test fixture used non-contract plan fields. The authoritative TradePlanRecord requires plannedEntryPrice, plannedStopPrice, plannedTargetPrice, and plannedQuantity. This repair follows the existing P14.1R1 branded/typed fixture pattern and keeps production ownership unchanged.

## OWNER TRACE
TradePlanRecord remains owned by src/domain/trades/tradeTypes.ts. JournalHistoryEntry remains the hydrated owner consumed by P14.3. JournalTradeMap continues to consume projectJournalTradeVisualizer(entry) only.

## PRE-CHANGE FLOW
JournalHistoryEntry → P14.1 facts → P14.2 display semantics → P14.3 journal projection → P14.4 native accessible presentation.

## CHANGE
Only the new P14.4 runtime fixture contract is repaired: entryPrice → plannedEntryPrice, stopLossPrice → plannedStopPrice, takeProfitPrice → plannedTargetPrice, and plannedQuantity is supplied. P14.4 production presentation files remain identical to the failed candidate.

## NON-SCOPE
No production behavior change, no DB/query/storage owner, no calculation owner, no SVG/canvas, no geometry/scaling, no market data/current price/candles/path, no FX, no animation, no P15+ work.

## DATA/STATE FLOW
Unchanged from P14.4. DecimalString fixture values are produced through parseDecimalString and passed through the authoritative projection chain without numeric conversion.

## PERSISTENCE / SECURITY / THEME / OFFLINE
Unchanged. No persistence, credential, network, theme-geometry, or offline behavior changes.

## TESTS
Canonical build must type-check the repaired fixture. Dedicated P14.4 runtime tests cover open trade planned facts with no invented exit and closed trade authoritative actual exit. Existing P14.4 static verifier plus the full historical gate chain remain required.

## REGRESSION / PERFORMANCE
No production code delta versus failed P14.4, so regression risk is limited to fixture correctness. Canonical gate must still run full unit, registered verify:p*, Journal History closure, and USER_HEAVY canary before promotion.

## KNOWN LIMITATIONS
P14.4 remains text-first accessible presentation. No visual geometry is introduced.

## REAL-DEVICE STATUS
Not applicable to this fixture-only repair.

## RESULT
HOLD until canonical GitHub gate passes. P14.3 remains authoritative.
