# KAIROS P18.13R1 — Lightweight Charts v5 Trend-Line Primitive Historical Verifier Compatibility Repair

## Authority
Base: canonical P18.12, promoted by GitHub Actions run #210 (`33819236565`) at head `969c3f9faeb8d26adf70f1956a37752e020e3488`.

Failed P18.13 run #211 (`33820351818`) is evidence only and is not authority.

## Canonical failure classification
P18.13 production TypeScript compilation and production build passed. The dedicated P18.13 verifier also passed. The gate then failed only when the historical P18.7 verifier rejected the newly intentional `hitTest(` method in `lightweightChartsV5TrendLinePrimitive.ts`.

Exact failure:
`Error: P18.7 crossed controlled scope: hitTest(`

This is a historical verifier compatibility defect exposed by P18.13, not a production hit-test implementation defect and not a gate filename/scope defect.

## Controlled repair
P18.13R1 is rebuilt from canonical P18.12. It reapplies the P18.13 primitive hit-test binding and makes one compatibility-only change to the historical P18.7 verifier: `hitTest(` is no longer treated as permanently forbidden in the shared primitive source file.

The P18.7 verifier still proves its original primitive-view composition evidence and continues to forbid Canvas ownership, primitive attach/detach ownership, persistence, acquisition, and P19 risk/reward scope.

## Ownership preserved
- P18.5 remains screen-coordinate projection owner.
- P18.6 remains Canvas rendering owner.
- P18.7 remains primitive view/lifecycle composition owner.
- P18.12 remains hit-test geometry/top-most resolution owner.
- P18.13R1 remains provider primitive hover-shape binding owner.

No second hit-test geometry owner is introduced.

## Explicit non-scope
No chart pointer subscription, click selection, drag/edit state, toolbar state, drawing-truth mutation, persistence, autoscale ownership, financial calculation, market acquisition, journal truth, or P19 behavior.

## Local evidence
- `verify:p18:7-lightweight-charts-v5-trend-line-primitive`: PASS after compatibility repair.
- `verify:p18:13-lightweight-charts-v5-trend-line-primitive-hit-test-binding`: PASS.
- No claim of canonical full TypeScript/build/unit/full-regression PASS is made locally. GitHub canonical gate remains authoritative.
