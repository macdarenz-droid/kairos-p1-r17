# KAIROS P11.8 Risk Price-Distance Primitive Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.7 authoritative PASS from controlled gate run #26.

## Objective
Add the smallest safe `RiskCalculator` capability from the locked P0 Calculation Engine architecture: exact planned entry-to-stop price distance.

## Research / controlling basis
The controlling handoff names `RiskCalculator` as a protected Calculation Engine module and keeps planned intent distinct from actual execution. It also warns that futures, forex, CFDs, and other instruments cannot be forced through one universal financial calculation model.

Therefore P11.8 owns only:
`abs(plannedEntryPrice - plannedStopPrice)`

It does not convert price distance into monetary initial risk.

## Owner trace
P9 canonical DecimalString plan values
-> P11.1R2 decimal kernel
-> P11.8 RiskCalculator price-distance primitive
-> future MarketSpecificCalculationPolicy / monetary RiskCalculator layer
-> future TradeMetrics.initialRisk
-> P11.7 RMultipleCalculator
-> future TradeMetrics.realizedR.

## Change
Adds `calculateRiskPriceDistance(plannedEntryPrice, plannedStopPrice)`.

Result contract:
- valid decimal evidence -> canonical non-negative DecimalString distance
- malformed decimal evidence -> explicit `invalid-decimal`

## Precision
Uses only the authoritative P11.1R2 `decimalSubtract` and `decimalAbs` operations.
No JavaScript Number, parseFloat, parseInt, Math arithmetic, or new dependency is introduced.

## Zero / missing semantics
Equal entry and stop prices legitimately produce numeric distance `0`.
Missing entry/stop is not represented by this primitive and must not be silently converted to zero by callers.
A future monetary-risk layer must decide whether zero price distance is valid for its business use.

## Why TradeMetrics.initialRisk remains null
Price distance is not universally identical to monetary initial risk. Contract multipliers, tick values, lot models, quote currencies, FX conversion, and other instrument rules may be required. The locked architecture places those policies below the common Calculation Engine rather than in generic UI or one universal formula.

## Non-scope
No quantity multiplication, monetary initial risk, TradeMetrics wiring, R-multiple wiring, position sizing, leverage, P&L percentage, fees, FX/currency conversion, contract/tick multiplier, market adapter, UI, persistence, schema, journal history, activation, or network changes.

## Persistence / security / theme / offline
Pure synchronous domain calculation. No persistence, network, secret, theme, or platform surface.

## Performance
Constant-time composition of two existing decimal-kernel operations.

## Tests
Covers entry above stop, stop above entry, high precision decimals, true zero distance, negative decimal evidence, and malformed entry/stop inputs.

## Result
HOLD until canonical GitHub gate passes deterministic install, build, full unit regression, all P1-P10.3R2 regressions, P11.1R2-P11.7 regressions, and P11.8 verification.
