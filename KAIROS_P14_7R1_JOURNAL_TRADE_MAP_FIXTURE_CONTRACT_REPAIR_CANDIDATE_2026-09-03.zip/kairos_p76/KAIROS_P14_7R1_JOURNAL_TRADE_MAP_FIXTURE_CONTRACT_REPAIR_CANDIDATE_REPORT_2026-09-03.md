# KAIROS P14.7R1 — Journal Trade Map Fixture Contract Repair Candidate Report — 2026-09-03

## Patch / base identity
- Patch: P14.7R1
- Authoritative base: P14.6R2 canonical PASS, Run #114, gate SHA `92367617a124310c0059d8f0943320e63f9dde60`.
- Repairs failed P14.7 canonical Run #116 / job `100302073722` after the P14.7 gate-path repair.

## OBJECTIVE
Repair only the new P14.7 runtime-test fixture so it conforms to the authoritative Journal History / trade-domain contracts. Preserve all P14.7 production behavior: exact authoritative actual-exit execution timestamps rendered with semantic `<time>` elements.

## FAILURE EVIDENCE
Run #116 passed controlled scope and deterministic install, then failed TypeScript build only in `tests/journal-trade-map-execution-time.test.tsx`:
- `TradeExecutionRecord` does not own a `fees` field.
- `JournalHistoryEntry.visualPnl` is non-nullable.
- The fixture also must carry the Journal History `fees` and `metricsError` fields at entry level.

## OWNER TRACE
- Execution truth remains owned by `TradeExecutionRecord`: `executedAt`, `price`, `quantity`, `type`.
- Fee evidence remains owned by `JournalHistoryEntry.fees` / `TradeFeeRecord`, not individual execution records.
- Visual P&L remains owned by the existing P13 projection contract.
- P14.7 UI remains presentation-only.

## CHANGE
Test fixture only:
- remove invalid per-execution `fees: []` properties;
- add entry-level `fees: []`;
- add `metricsError: null`;
- provide the existing explicit unavailable `visualPnl` projection object instead of `null`.

No P14.7 production code, CSS behavior, execution-time display semantics, domain owner, persistence, calculations, or SVG geometry changed from the failed P14.7 candidate.

## NON-SCOPE
No market data, FX, P&L arithmetic, persistence, network, price scaling, synthetic history, animation, canvas, P15+, or toolchain changes.

## RESULT
HOLD pending canonical GitHub gate. Failed or unverified candidates are not authoritative.
