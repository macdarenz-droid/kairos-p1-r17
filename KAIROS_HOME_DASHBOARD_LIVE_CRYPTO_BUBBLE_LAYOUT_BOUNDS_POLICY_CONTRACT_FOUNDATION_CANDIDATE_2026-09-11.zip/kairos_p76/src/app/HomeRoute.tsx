import { HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime } from './HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime';
import { createHomeDashboardLiveCryptoBubbleDefaultRuntimeProductConfiguration } from './homeDashboardLiveCryptoBubbleRuntimeProductPolicy';

export function HomeRoute() {
  const configuration = createHomeDashboardLiveCryptoBubbleDefaultRuntimeProductConfiguration();

  return (
    <section
      className="kairos-route"
      aria-labelledby="kairos-route-home"
      data-kairos-home-dashboard="live-crypto-text-runtime"
    >
      <header>
        <h1 id="kairos-route-home">Home</h1>
        <p>Your Kairos dashboard lives here.</p>
      </header>
      <section aria-labelledby="kairos-home-dashboard-heading">
        <h2 id="kairos-home-dashboard-heading">Live Crypto Bubble</h2>
        <HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime
          configuration={configuration}
        />
      </section>
    </section>
  );
}
