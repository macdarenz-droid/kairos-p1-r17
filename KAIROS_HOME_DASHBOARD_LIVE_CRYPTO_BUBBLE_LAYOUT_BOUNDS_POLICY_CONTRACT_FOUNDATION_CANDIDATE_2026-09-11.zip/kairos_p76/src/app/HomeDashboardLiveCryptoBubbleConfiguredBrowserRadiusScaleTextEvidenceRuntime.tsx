import { HomeDashboardLiveCryptoBubbleRadiusScaleTextEvidence } from './HomeDashboardLiveCryptoBubbleRadiusScaleTextEvidence';
import type { HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration } from './homeDashboardLiveCryptoBubbleRuntimeOptionsComposition';
import { useHomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleViewModel } from './useHomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleViewModel';

export interface HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntimeProps {
  readonly configuration: HomeDashboardLiveCryptoBubbleRuntimeProductConfiguration;
}

/**
 * Thin configured browser radius-scale textual-evidence composition edge.
 * It delegates the exact caller-owned configuration to the released configured
 * browser radius-scale hook, then presents the exact released model once.
 */
export function HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntime({
  configuration,
}: HomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleTextEvidenceRuntimeProps) {
  const model = useHomeDashboardLiveCryptoBubbleConfiguredBrowserRadiusScaleViewModel(configuration);

  return <HomeDashboardLiveCryptoBubbleRadiusScaleTextEvidence model={model} />;
}
