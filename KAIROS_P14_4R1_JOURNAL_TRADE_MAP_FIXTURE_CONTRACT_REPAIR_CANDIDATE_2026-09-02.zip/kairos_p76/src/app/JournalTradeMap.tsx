import type { JournalHistoryEntry } from '../application/journal';
import { projectJournalTradeVisualizer } from '../application/trade-visualizer';

interface JournalTradeMapProps {
  readonly entry: JournalHistoryEntry;
}

function sideLabel(side: 'long' | 'short'): string {
  return side === 'long' ? 'Long' : 'Short';
}

function statusLabel(status: 'draft' | 'open' | 'closed' | 'cancelled'): string {
  if (status === 'draft') return 'Draft';
  if (status === 'open') return 'Open';
  if (status === 'closed') return 'Closed';
  return 'Cancelled';
}

/**
 * P14.4 first presentation boundary for the Trade Visualizer.
 * This deliberately renders exact textual trade-map facts before any geometry.
 * It consumes the P14.3 projection and performs no price arithmetic, scaling,
 * market-data lookup, path inference, or financial calculation.
 */
export function JournalTradeMap({ entry }: JournalTradeMapProps) {
  const model = projectJournalTradeVisualizer(entry);

  if (model.levels.length === 0) return null;

  return (
    <section className="kairos-trade-map" aria-label={`${model.symbol} trade map`}>
      <div className="kairos-trade-map__heading">
        <strong>Trade map</strong>
        <span>{sideLabel(model.side)} · {statusLabel(model.status)}</span>
      </div>
      <dl className="kairos-trade-map__levels">
        {model.levels.map((level, index) => (
          <div key={`${level.kind}-${index}`} data-level-kind={level.kind}>
            <dt>{level.label}</dt>
            <dd>{level.price}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}
