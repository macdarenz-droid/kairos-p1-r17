# KAIROS P14.7R2 — Journal Trade Map Historical Presentation Selector Repair Candidate Report — 2026-09-03

## Patch / base identity
- Patch: P14.7R2
- Authoritative base: P14.6R2 canonical PASS, Run #114, gate SHA `92367617a124310c0059d8f0943320e63f9dde60`.
- Repairs P14.7R1 canonical Run #117 / job `100303672475`.

## OBJECTIVE
Repair only the historical P14.4 Journal Trade Map presentation assertion made stale by P14.7's intentional addition of authoritative actual-exit execution time. Preserve all P14.7 production behavior and the fixture-contract repair from P14.7R1.

## FAILURE EVIDENCE
Run #117 passed controlled scope, deterministic install, and production build. Full unit regression reached 408/409 passing. The sole failure was `tests/journal-trade-map-presentation.test.tsx`, whose closed-trade assertion expected the actual-exit row to contain only the exit price. P14.7 now correctly adds `Executed <timestamp>` to that same row, so the historical exact row-text assertion became incompatible with the new presentation contract.

## OWNER TRACE
- Actual exit price remains authoritative `TradeExecutionRecord.price`.
- Actual execution time remains authoritative `TradeExecutionRecord.executedAt`.
- `JournalTradeMap` only presents those existing facts; it does not derive or mutate them.
- The repair changes test expectation only. Production code, CSS, domain ownership, persistence, calculations, and SVG semantics are unchanged.

## PRE-CHANGE FLOW
Historical P14.4 test located the exact exit price and then asserted the parent row text was exactly the price-only presentation. P14.7 intentionally extended that row with the exact execution timestamp, invalidating the historical string equality without invalidating any truth or behavior.

## CHANGE
- Update only the historical closed-trade presentation assertion so it expects the authoritative exit price followed by the exact authoritative execution timestamp now rendered by P14.7.
- Retain the dedicated P14.7 runtime test that separately proves two exits preserve their distinct execution timestamps and that planned rows do not receive `<time>` elements.

## NON-SCOPE
No production changes. No market data, FX, P&L arithmetic, persistence, network, price scaling, synthetic history, animation, canvas, P15+, or toolchain changes.

## DATA/STATE FLOW
Unchanged: execution record -> existing P14 display model -> JournalTradeMap presentation.

## PERSISTENCE
Unchanged. No writes or schema changes.

## SECURITY
Unchanged. No remote input or executable content added.

## THEME
Unchanged from P14.7.

## OFFLINE
Unchanged; all data remains local-first.

## TESTS
Candidate retains the P14.7 execution-time runtime test and updates the one historical P14.4 presentation assertion that became stale after the intended UI extension.

## REGRESSION
Canonical gate must run build, the full unit suite, all registered `verify:p*` scripts, dedicated P14.7 execution-time checks, P14.6R2 through P14.1R1 regressions, P13/P10/P1 closure checks, Journal History closure, and USER_HEAVY canary.

## PERFORMANCE
No runtime production change from P14.7R1; test-only repair.

## KNOWN LIMITATIONS
This patch does not introduce localization or timezone formatting; it preserves exact stored execution timestamp text as already defined by P14.7.

## REAL-DEVICE STATUS
Not claimed. Canonical GitHub gate is authoritative for this repair candidate.

## RESULT
HOLD pending canonical GitHub gate. Failed or unverified candidates are not authoritative.
