import type { RendererChartDrawing } from './chartDrawingProjection';
import {
  projectLightweightChartsV5TrendLineSegments,
  type LightweightChartsV5PriceCoordinateApi,
  type LightweightChartsV5TimeCoordinateApi,
} from './lightweightChartsV5TrendLineCoordinateProjection';
import {
  createLightweightChartsV5TrendLinePaneRenderer,
  type LightweightChartsV5TrendLineStrokeStyle,
} from './lightweightChartsV5TrendLinePaneRenderer';

export interface LightweightChartsV5TrendLinePrimitiveChartApi {
  timeScale(): LightweightChartsV5TimeCoordinateApi;
}

export interface LightweightChartsV5TrendLinePrimitiveAttachedParameter {
  readonly chart: LightweightChartsV5TrendLinePrimitiveChartApi;
  readonly series: LightweightChartsV5PriceCoordinateApi;
  readonly requestUpdate: () => void;
}

export interface LightweightChartsV5TrendLinePrimitivePaneView {
  renderer(): ReturnType<typeof createLightweightChartsV5TrendLinePaneRenderer>;
}

export interface LightweightChartsV5TrendLinePrimitive {
  attached(parameter: LightweightChartsV5TrendLinePrimitiveAttachedParameter): void;
  detached(): void;
  updateAllViews(): void;
  paneViews(): readonly LightweightChartsV5TrendLinePrimitivePaneView[];
}

/**
 * P18.7 provider primitive-view composition invariant:
 * - P18.2 renderer-safe drawings remain the immutable drawing input
 * - P18.5 remains the sole time/price-to-screen projection owner
 * - P18.6 remains the sole Canvas pane-rendering owner
 * - attached() only captures the active provider chart/series scale APIs
 * - updateAllViews() refreshes presentation geometry when the provider viewport changes
 * - paneViews() exposes one stable view whose renderer is replaced with the latest frame
 * - no hit testing, interaction, persistence, autoscale, calculation, market acquisition,
 *   journal truth, toolbar state, or P19 risk/reward behavior is owned here
 */
export function createLightweightChartsV5TrendLinePrimitive(
  drawings: readonly RendererChartDrawing[],
  style: LightweightChartsV5TrendLineStrokeStyle,
): LightweightChartsV5TrendLinePrimitive {
  const drawingSnapshot = drawings.map((drawing) => ({
    ...drawing,
    start: { ...drawing.start },
    end: { ...drawing.end },
  }));

  let attached: LightweightChartsV5TrendLinePrimitiveAttachedParameter | null = null;
  let renderer = createLightweightChartsV5TrendLinePaneRenderer([], style);

  const paneView: LightweightChartsV5TrendLinePrimitivePaneView = {
    renderer: () => renderer,
  };
  const paneViews = [paneView] as const;

  return {
    attached(parameter): void {
      attached = parameter;
    },

    detached(): void {
      attached = null;
      renderer = createLightweightChartsV5TrendLinePaneRenderer([], style);
    },

    updateAllViews(): void {
      if (attached === null) {
        renderer = createLightweightChartsV5TrendLinePaneRenderer([], style);
        return;
      }

      const segments = projectLightweightChartsV5TrendLineSegments(
        drawingSnapshot,
        attached.chart.timeScale(),
        attached.series,
      );
      renderer = createLightweightChartsV5TrendLinePaneRenderer(segments, style);
    },

    paneViews(): readonly LightweightChartsV5TrendLinePrimitivePaneView[] {
      return paneViews;
    },
  };
}
