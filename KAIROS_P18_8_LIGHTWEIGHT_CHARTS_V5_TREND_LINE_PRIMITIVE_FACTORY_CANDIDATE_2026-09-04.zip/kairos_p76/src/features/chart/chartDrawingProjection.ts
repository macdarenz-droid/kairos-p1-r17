import type { ChartDrawing, ChartDrawingAnchor } from './chartDrawingContract';
import { projectChartPricePoint, type RendererPricePoint } from './chartSeriesProjection';

export type RendererDrawingAnchor = RendererPricePoint;

export interface RendererTrendLineDrawing {
  readonly id: string;
  readonly kind: 'trend-line';
  readonly start: RendererDrawingAnchor;
  readonly end: RendererDrawingAnchor;
}

export type RendererChartDrawing = RendererTrendLineDrawing;

export function projectChartDrawingAnchor(
  anchor: ChartDrawingAnchor,
): RendererDrawingAnchor {
  return projectChartPricePoint(anchor);
}

export function projectChartDrawing(
  drawing: ChartDrawing,
): RendererChartDrawing {
  return {
    id: drawing.id,
    kind: drawing.kind,
    start: projectChartDrawingAnchor(drawing.start),
    end: projectChartDrawingAnchor(drawing.end),
  };
}
