# Kairos Analysis live-candle production browser session

Date: 13 September 2026

## Responsibility

This bounded item-4 amendment binds the released Gate417 browser runtime sources to the released Gate415 Analysis live-candle subscription composition. `startBinanceAnalysisLiveCandleProductionBrowserSession` supplies the production receipt clock, timeout scheduler/cancellation and reconnect entropy only when the caller starts an explicitly scoped session.

The caller remains authoritative for the exact Binance Spot instrument, interval, initial historical candle, renderer, reconnect policy, backfill execution, route/selection replacement, hidden/offline lifecycle and visible connection state. The boundary forwards caller callbacks and an optional deterministic subscription seam unchanged.

## Exclusions

It creates no default reconnect policy, initial history request, backfill request execution, route mount, visibility listener, persistence, IndexedDB access, journal mutation, calculation, execution inference, FX, drawing, marker or Live Bubble behavior. Importing the module starts no timer, socket or subscription. UI VISIBLE:NO. P21 remains active.

## Evidence

- Dedicated source verifier: `npm run verify:analysis-live-candle-production-browser-session`
- Focused regression: `npx vitest run tests/binance-analysis-live-candle-production-browser-session.test.ts tests/binance-analysis-live-candle-browser-runtime-sources.test.ts tests/binance-analysis-live-candle-browser-subscription-composition.test.ts`
- Required release checks remain TypeScript, production build, full unit suite, all existing browser/current/historical closures, exact archive scope/integrity and both exact-run artifacts under `.github/workflows/kairos-gate.yml` / `verify-current-candidate`.

Local checks are supporting evidence only. Canonical PASS is not claimed until every gate stage and both artifacts succeed.
