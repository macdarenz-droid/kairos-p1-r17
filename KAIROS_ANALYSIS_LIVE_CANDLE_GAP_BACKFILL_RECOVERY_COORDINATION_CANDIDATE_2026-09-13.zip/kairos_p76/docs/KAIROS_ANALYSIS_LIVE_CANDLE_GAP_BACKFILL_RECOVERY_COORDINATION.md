# Kairos Analysis live-candle gap backfill recovery coordination

Date: 13 September 2026

## Responsibility

This bounded item-4 amendment composes Gate420's authoritative history-to-live bootstrap with the released gap demand from the live-candle projection session. One exact-scope gap demand stops the old live session through Gate420, reacquires and renders a fresh authoritative recent page, and starts the replacement live session from only that page's final candle.

Duplicate demands are coalesced while recovery is pending. Superseded selections and late completions are ignored. Venue, symbol and interval mismatches fail closed without another acquisition. A failed or empty authoritative recovery removes the live claim; it never invents a candle.

## Exclusions

No new provider request, transport, retry/default policy, route mount, visibility/offline listener, UI status, persistence, IndexedDB access, journal mutation, calculation, execution inference, FX, drawing, marker or Live Bubble behavior is introduced. History limit, selected scope, reconnect policy, renderer creation and visible state remain caller-owned. UI VISIBLE:NO. P21 remains active.

## Evidence

- `npm run verify:analysis-live-candle-gap-backfill-recovery-coordination`
- `npx vitest run tests/binance-analysis-live-candle-gap-backfill-recovery-coordination.test.ts tests/binance-analysis-history-live-candle-bootstrap-coordination.test.ts tests/binance-analysis-selected-live-candle-session-controller.test.ts`
- The dedicated verifier, 16 focused/lower-owner tests, TypeScript and production build pass locally.
- One full-suite attempt passed 311/313 files and 1,292/1,294 tests. Its two failures were inherited asynchronous Journal UI timing cases; both files then passed all 25 tests in three consecutive isolated reruns. No unrelated source or expectation changed from that evidence.
- Canonical full unit, browser/current/historical checks and both exact-run artifacts remain mandatory.
