# Kairos Analysis history-to-live candle bootstrap coordination

Date: 13 September 2026

## Responsibility

This bounded item-4 amendment coordinates one caller-authoritative recent candle-history request into Gate419's released selected live-candle session controller. It cancels the previous pending acquisition, stops the previous live selection, suppresses late results, confirms the returned snapshot matches the exact venue/symbol/interval/limit request, refuses an empty page, asks the caller to render that authoritative snapshot and hands only its final candle to the live session.

The caller still owns selected instrument/timeframe, history limit, reconnect policy, renderer construction, visible state and gap-backfill execution. P15/P16 retain acquisition/provider truth and Gate419 retains selected subscription replacement.

## Exclusions

No metadata acquisition, route mount, gap-backfill execution, retry/default policy, visibility/offline listener, UI status, timer, transport, persistence, IndexedDB access, journal mutation, calculation, execution inference, FX, drawing, marker or Live Bubble behavior is introduced. UI VISIBLE:NO. P21 remains active.

## Evidence

- `npm run verify:analysis-history-live-candle-bootstrap-coordination`
- `npx vitest run tests/binance-analysis-history-live-candle-bootstrap-coordination.test.ts tests/binance-analysis-selected-live-candle-session-controller.test.ts tests/binance-spot-candle-history.test.ts`
- TypeScript, production build, full unit, canonical browser/current/historical checks and both exact-run artifacts remain mandatory.
