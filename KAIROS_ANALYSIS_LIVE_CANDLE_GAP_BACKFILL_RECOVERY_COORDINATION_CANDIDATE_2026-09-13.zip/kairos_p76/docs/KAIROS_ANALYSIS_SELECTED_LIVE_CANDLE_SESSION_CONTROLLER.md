# Kairos Analysis selected live-candle session controller

Date: 13 September 2026

## Responsibility

This bounded item-4 amendment owns replacement and cleanup for exactly one caller-selected Analysis live-candle browser session. A replacement invalidates the old generation before closing its subscription, then starts the new session through Gate418's released production browser binding. Late state, error, disposition and backfill callbacks from the replaced selection are suppressed.

The caller remains authoritative for instrument, interval, initial history, renderer, reconnect policy, backfill execution and visible state. A failed replacement leaves the controller inactive rather than retaining a stale feed. Explicit stop is idempotent.

## Exclusions

No history fetch, backfill execution, route mount, visibility/offline listener, reconnect policy default, timer, transport, persistence, IndexedDB access, journal mutation, calculation, execution inference, FX, drawing, marker or Live Bubble behavior is introduced. UI VISIBLE:NO. P21 remains active.

## Evidence

- `npm run verify:analysis-selected-live-candle-session-controller`
- `npx vitest run tests/binance-analysis-selected-live-candle-session-controller.test.ts tests/binance-analysis-live-candle-production-browser-session.test.ts tests/binance-analysis-live-candle-browser-subscription-composition.test.ts`
- TypeScript, production build and the full unit suite are supporting local evidence. The full canonical workflow, all historical/browser checks and both exact-run artifacts remain mandatory.
