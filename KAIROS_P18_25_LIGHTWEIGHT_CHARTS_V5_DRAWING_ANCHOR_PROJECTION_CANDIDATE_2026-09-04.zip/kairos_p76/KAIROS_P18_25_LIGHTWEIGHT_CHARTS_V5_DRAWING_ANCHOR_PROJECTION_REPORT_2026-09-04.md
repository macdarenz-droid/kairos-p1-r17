# KAIROS P18.25 — Lightweight Charts v5 Drawing Anchor Projection

## Controlled base
Canonical P18.24 PASS, GitHub Actions run #228 / 33868099767.

## Evidence basis
Canonical P18.24 closes the provider-neutral interaction session/state owner but explicitly leaves provider input evidence, screen-to-market conversion, anchor collection, subscriptions, and drawing mutation outside its boundary. P18.1 already owns the logical `ChartDrawingAnchor` shape, while P18.5 owns the opposite provider direction: logical/render-safe drawing coordinates -> provider screen coordinates.

Current official Lightweight Charts v5.2 documentation establishes the provider facts needed for the reverse seam: chart mouse/click parameters may expose `time` and `point`; the point is unavailable outside the chart; `ISeriesApi.coordinateToPrice()` converts a y screen coordinate to the active series price. Because Kairos production chart data is supplied to this adapter as epoch-second time values, this slice accepts only that exact provider time representation and converts it back to Kairos ISO `ChartTimestamp` truth.

Therefore the next single responsibility is the provider-specific, side-effect-free reverse projection from one provider event point into one existing Kairos logical drawing anchor. Subscription lifecycle remains separate.

## Responsibility added
Adds the sole Lightweight Charts v5 drawing-anchor projection owner:
- requires provider event `time` plus `point`;
- delegates y -> price conversion to the active provider series `coordinateToPrice()` API;
- converts provider epoch seconds back to an ISO `ChartTimestamp`;
- normalizes the provider numeric price to the existing branded `DecimalString` contract without exponential notation;
- returns `null` when time, point, price, or numeric evidence is unavailable/non-finite.

## Ownership preserved
- P18.1 remains provider-neutral drawing/anchor truth owner.
- P18.5 remains logical/render-safe drawing -> provider screen-coordinate projection owner.
- P18.21 remains interaction-state shape owner.
- P18.22 remains interaction-event shape owner.
- P18.23 remains interaction transition-semantics owner.
- P18.24 remains ephemeral active interaction-session state/dispatch owner.
- P18.25 owns only provider event-point -> provider-neutral logical anchor projection.

## Explicit non-scope
No click/crosshair subscription lifecycle, DOM listener ownership, pointer capture, gesture recognition, interaction dispatch, anchor-pair collection, drawing id allocation, drawing creation/update/delete mutation, persistence/restore, toolbar UI, selection rendering, drag/edit execution, undo/redo, new drawing kinds, horizontal line, rectangle/order block, freehand, Risk/Reward behavior or visuals, journal truth, market-data acquisition, calculations, navigation, dependency migration, or P19 work.

## Official research used
- Lightweight Charts v5.2 `MouseEventParams`: optional `time`, optional `point`, provider event location semantics.
- Lightweight Charts v5.2 `ISeriesApi.coordinateToPrice()`: active-series y-coordinate -> provider price conversion.

## Changed-file contract
Exactly six files relative to canonical P18.24:
1. `KAIROS_P18_25_LIGHTWEIGHT_CHARTS_V5_DRAWING_ANCHOR_PROJECTION_REPORT_2026-09-04.md`
2. `package.json`
3. `scripts/verify-p18-25-lightweight-charts-v5-drawing-anchor-projection.mjs`
4. `src/features/chart/lightweightChartsV5DrawingAnchorProjection.ts`
5. `src/features/chart/index.ts`
6. `tests/lightweight-charts-v5-drawing-anchor-projection.test.ts`

## Verification intent
Dedicated verification must prove event time/point -> anchor projection, active-series price conversion delegation, decimal normalization, fail-closed missing/non-finite evidence, preserved P18.1/P18.24 ownership, exact exports, and absence of subscription/mutation/persistence/P19 ownership. Canonical gate must additionally prove deterministic install, exact Lightweight Charts dependency, production TypeScript/build, dedicated runtime tests, full unit regression, P18/P17 regression chain, historical closures, exact scope, candidate artifact, and gate evidence before promotion.
