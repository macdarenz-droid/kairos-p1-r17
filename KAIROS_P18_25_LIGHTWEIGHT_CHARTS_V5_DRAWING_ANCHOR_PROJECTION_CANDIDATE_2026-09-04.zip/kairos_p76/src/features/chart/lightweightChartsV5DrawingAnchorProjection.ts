import Decimal from 'decimal.js';
import { parseDecimalString } from '../../domain/trades';
import type { ChartDrawingAnchor } from './chartDrawingContract';

export interface LightweightChartsV5DrawingAnchorPoint {
  readonly x: number;
  readonly y: number;
}

export interface LightweightChartsV5DrawingAnchorEvent {
  readonly time?: number;
  readonly point?: LightweightChartsV5DrawingAnchorPoint;
}

export interface LightweightChartsV5DrawingAnchorPriceApi {
  coordinateToPrice(coordinate: number): number | null;
}

function projectProviderEpochSeconds(time: number): string | null {
  if (!Number.isFinite(time)) return null;
  const date = new Date(time * 1000);
  if (!Number.isFinite(date.getTime())) return null;
  return date.toISOString();
}

function projectProviderPrice(price: number): ChartDrawingAnchor['price'] | null {
  if (!Number.isFinite(price)) return null;
  const parsed = parseDecimalString(new Decimal(price).toFixed());
  return parsed.ok ? parsed.value : null;
}

/**
 * P18.25 Lightweight Charts v5 reverse anchor projection.
 *
 * The provider event owns screen/time evidence and the active series owns
 * y-coordinate -> price conversion. This function projects that evidence into
 * the existing provider-neutral ChartDrawingAnchor contract and fails closed
 * when any required value is unavailable.
 *
 * It owns no click/crosshair subscription lifecycle, interaction transition,
 * drawing mutation, persistence, toolbar state, journal truth, or P19 behavior.
 */
export function projectLightweightChartsV5DrawingAnchor(
  event: LightweightChartsV5DrawingAnchorEvent,
  series: LightweightChartsV5DrawingAnchorPriceApi,
): ChartDrawingAnchor | null {
  if (event.time === undefined || event.point === undefined) return null;

  const timestamp = projectProviderEpochSeconds(event.time);
  const providerPrice = series.coordinateToPrice(event.point.y);
  if (timestamp === null || providerPrice === null) return null;

  const price = projectProviderPrice(providerPrice);
  if (price === null) return null;

  return { timestamp, price };
}
