# KAIROS P12.4 Indexed Journal Status Filter Foundation

## Status
HOLD pending canonical GitHub gate.

## Base
P12.3R1 canonical PASS artifact from run #57.

## Objective
Add the first filter-capable Journal History query path without loading all trades into React/application memory.

## Design
- Append database schema v3.
- Add compound trade index `[status+updatedAt]`.
- Add `TradeRepository.listRecentByStatusAndUpdatedAt(status, limit)`.
- Use a compound range covering all valid ISO timestamp strings for the selected status, then reverse and limit.
- Extend `listJournalHistory()` with optional `status`.
- Preserve the existing unfiltered newest-first path.
- Apply the trade bound before hydrating plans, executions, fees, and P11 metrics.

## Ownership
IndexedDB -> TradeRepository -> listJournalHistory -> consumers.
No UI filtering and no duplicate business/calculation owner.

## Migration
Index-only schema migration; no stored record shape changes and no data upgrader required.

## Non-scope
No Journal UI controls, no free-text symbol search, no pagination/cursor UI, no edit/delete, no P13 Visual P&L.

## Performance
The status predicate and newest-first ordering are both satisfied by IndexedDB through a compound index; application-level `.filter()` is prohibited.

## Tests
- live v3 schema contains `[status+updatedAt]`;
- filtered newest-first bounded history fixture;
- prior P1-P12 regression remains required by canonical gate.

## Result
Static verification PASS locally. Full build/unit regression deferred to canonical GitHub gate.
