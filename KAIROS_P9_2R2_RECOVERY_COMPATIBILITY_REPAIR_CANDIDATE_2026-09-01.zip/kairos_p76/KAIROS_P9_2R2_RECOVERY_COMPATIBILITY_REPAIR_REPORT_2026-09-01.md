# Kairos P9.2R2 Recovery Compatibility Repair

Status: HOLD pending independent GitHub full gate.
Authoritative base: P9.1 Trade Domain Foundation PASS/LOCKED candidate, SHA-256 0f9fc60e6e32890c1c949cfe40852d0f58a0655cbe3676c4469630d133af7ef6.

## Why R2 exists
P9.2R1 built successfully and its new trade-persistence tests passed, but the full regression suite exposed eight failures. The failures showed that schema V2 had not been reconciled with the released P6 full-backup/restore contract and that several schema tests accidentally treated Dexie table enumeration order as an invariant.

## Controlled repair
- Rebuilt from the authoritative P9.1 base, not from failed P9.2/P9.2R1.
- Retains immutable database schema V1 and appends schema V2 trade stores.
- Retains backup format V1 as a supported historical input contract.
- Advances the current full-backup format to V2 because trades/plans/executions/fees are now authoritative persistent user state.
- Migrates validated V1 metadata-only backups into the current V2 restore model with empty trade collections.
- Full V2 snapshots include metadata, trades, plans, executions, and fees in one read-only snapshot transaction.
- Restore preflight rejects duplicate IDs and broken trade references before destructive work.
- Replacement covers all backup-scoped stores in one short atomic write transaction and preserves device-scoped activation metadata behavior.
- Post-restore verification closes, reopens, re-queries all authoritative backup-scoped stores, and requires exact normalized equality plus database integrity.
- Schema table-list assertions are order-independent because Dexie table enumeration order is not a Kairos domain invariant.

## Explicit non-scope
No Journal UI, trade-entry form, P&L/R-multiple/position-size calculations, charts, broker/network integration, activation authority changes, theme changes, or P10/P11 work.

## Verification state
Static P6.1-P6.5 compatibility verifiers: PASS locally.
P9.2R2 static persistence/recovery verifier: PASS locally.
Executable npm gate is not promoted from this environment because dependency installation did not complete reliably. GitHub full gate is required for PASS/LOCKED promotion.
