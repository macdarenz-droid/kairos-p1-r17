# Kairos P1 Verification Report — R16
Date: 2026-08-31
Status: HOLD

## Objective
Turn the remaining P1 verification into one deterministic command that can run end-to-end in any normal npm-enabled environment.

## Controlled change
Added `npm run release:p1`.

It owns the full sequence:
1. exact Node/npm toolchain check;
2. static P1 architecture/scope contract;
3. genuine npm package-lock resolution;
4. package-lock integrity verification;
5. frozen P1 gate (`npm ci` -> typecheck -> tests -> production build).

PASS/HOLD/FAIL propagates from the real step that stops the sequence.
No later step runs after HOLD or FAIL.

## Why this is useful
Previously a normal machine needed two separate commands: first resolve the lockfile, then run the gate. R16 removes that manual gap. The user does not need to know the internal sequence; one command is sufficient.

The generated package-lock remains a genuine npm artifact. The runner does not fabricate or edit it.

## Research
Current npm documentation states that package-lock.json records the exact dependency tree and that `npm ci` requires an existing lockfile, rejects package.json/lock mismatches, and does not rewrite the lockfile. GitHub's current Node CI guidance likewise uses `npm ci` for reproducible installs.

## Evidence in this environment
- Node/npm toolchain: PASS.
- Static P1 contract: PASS.
- Existing PASS/HOLD/FAIL classifier: PASS.
- Lock-verifier fixture suite: PASS.
- One-command release runner syntax: PASS.
- Real `npm run release:p1`: HOLD at genuine lock resolution because this container still cannot reach registry.npmjs.org.
- GitHub connector currently exposes zero repositories, so no remote Actions runner is available from this chat.
- No app/runtime behavior changed.

## Decision
HOLD. P0 remains authoritative. P2 remains locked.
