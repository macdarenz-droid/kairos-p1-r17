# Kairos P9.1 Trade Domain Foundation

Status: HOLD pending independent GitHub full gate.

Authoritative base: P8.1R1 PASS/LOCKED candidate, SHA-256 2605b85580285affc66c5df5a9dd9bbe186f59de9ec8f199e9986ea501186205.

Scope:
- Separate branded IDs for trade, plan, execution, and fee records.
- Explicit trade lifecycle, side, source, market, and execution vocabularies.
- Decimal-string validation without numeric coercion.
- Multiple entry/exit executions supported by record shape.
- Stable UUID v4 creation through Web Crypto.
- Domain lifecycle invariants and tests.

Protected non-scope:
- No IndexedDB schema or migration change.
- No repositories or persistence writes.
- No trade-entry UI.
- No P&L, R-multiple, average price, leverage, sizing, or other P11 calculations.
- No activation/navigation changes.
