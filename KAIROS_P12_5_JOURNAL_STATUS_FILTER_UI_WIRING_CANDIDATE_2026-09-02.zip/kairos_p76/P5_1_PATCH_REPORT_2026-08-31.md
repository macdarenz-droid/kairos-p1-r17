# Kairos P5.1 Patch Report — Dexie Database Kernel + V1 Metadata Schema

Date: 2026-08-31
Authoritative base entering patch: P4.3 PASS / LOCKED
Patch result before authoritative GitHub gate: HOLD

## Objective
Establish the smallest real local-database foundation for P5 without creating future trade/domain tables early.

## Research / architecture basis
- IndexedDB upgrades are versioned and can be blocked by other open connections; open connections must cooperate with version changes.
- Dexie version declarations own schema versions and forward upgrade definitions.
- Dexie upgrade work runs transactionally; failed upgrades roll back rather than leaving half-upgraded data.
- Database transactions must stay short; no network/user waiting belongs inside them.

## Owner flow
Browser IndexedDB -> Dexie -> KairosDatabase -> database lifecycle owner -> future repositories -> future application queries/commands.

Presentation components do not write IndexedDB directly.

## Implemented
- Added exactly pinned `dexie@4.4.5` production dependency.
- Added exactly pinned `fake-indexeddb@6.2.5` test dependency.
- Added `src/data/database/schema.ts` as authoritative database name/schema registry.
- Established immutable V1 schema version `1`.
- V1 intentionally contains only `metadata` (`&key`).
- Added typed `DatabaseMetadataRecord`.
- Added `KairosDatabase extends Dexie` as the IndexedDB/Dexie owner.
- Added database lifecycle owner with explicit `idle/opening/ready/version-change/closed/error` states.
- Database open failures surface as an error state and are not converted to an empty-data success path.
- Added startup database open and diagnostics reporting.
- Added database schema version to build identity metadata.
- Added P5.1 static verifier and focused database tests.
- Narrowly evolved the inherited P1 scope guard to permit Dexie/IndexedDB only inside `src/data/database/`; unrelated restricted terms remain forbidden there.

## Intentionally not implemented
- Trade/trade-plan/execution/fee tables.
- Chart analysis/drawing tables.
- Goals, strategies, attachments or domain repositories.
- Backup/restore.
- Migration from a historical released schema (no pre-V1 schema exists yet).
- Long-running or network work inside transactions.
- UI database access.
- Cloud/sync.

## Local verification
PASS:
- P1 static contract
- P2.1 design-system contract
- P2.2 primitive/typography contract
- P2.3 accessibility contract
- P3 active theme registry
- P3.3 theme canary
- P3.4 theme preference
- P3.5 chart theme adapter
- P4.1 manifest
- P4.2 service worker
- P4.3 storage durability
- P5.1 database-kernel static contract

The full local dependency/typecheck/test/build gate could not be completed because dependency installation timed out in the execution environment. The previous authoritative P4.3 base therefore remains authoritative until the clean GitHub gate passes.

## Required authoritative verification
- clean dependency resolution/install
- lock integrity after adding Dexie/fake-indexeddb
- typecheck
- full Vitest regression including database kernel tests
- production build
- all P1 through P4.3 contracts
- P5.1 database-kernel contract

## Result
HOLD — awaiting authoritative GitHub gate.
