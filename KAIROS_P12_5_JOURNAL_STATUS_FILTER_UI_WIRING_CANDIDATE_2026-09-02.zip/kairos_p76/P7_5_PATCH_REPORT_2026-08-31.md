# KAIROS PATCH REPORT

Patch: P7.5 — Activation Coordinator Foundation
Base: P7.4R1 Activation Receipt Proof Foundation — GitHub run #91 PASS / LOCKED
App version: 0.1.0
Build ID: unchanged from authoritative base

## OBJECTIVE
Create the application-layer activation owner that sequences startup restore and first activation without adding presentation UI or moving invite authority into the client.

## RESEARCH
- MDN documents `Navigator.onLine` as inherently unreliable for deciding whether a particular service is reachable. P7.5 therefore does not use browser online state as activation authority or to skip the remote adapter.
- MDN documents online/offline events as network hints, not proof that a specific service is reachable.
- Existing P7.3 remote adapter remains the owner of actual remote reachability and server response mapping.
- Existing P7.4 public-key verifier remains the owner of receipt authenticity.

## OWNER TRACE
ActivationCoordinator is the application orchestration owner.
It depends on, but does not replace:
- P7.3 ActivationAdapter for remote server validation.
- P7.4 ActivationReceiptVerifier for proof authenticity.
- P7.2 ActivationReceiptRepository for installation-scoped persistence.
- P7.1 activation state reducer for state transitions and user-facing messages.

## PRE-CHANGE FLOW
The system had all individual pieces but no owner that guaranteed their ordering. A caller could theoretically receive a server receipt, persist it, or report activation success without a single application-level sequence enforcing proof verification and successful persistence first.

## CHANGE
Added `src/services/activation/ActivationCoordinator.ts`.
Added `tests/activation-coordinator.test.ts`.
Added `scripts/verify-p7-activation-coordinator.mjs`.
Added package script `verify:p7:activation-coordinator`.
Exported the coordinator through the activation boundary.

## NON-SCOPE
- No activation screen or navigation gate.
- No production activation endpoint.
- No invite-code authority/master code.
- No private/signing key.
- No database schema change.
- No backup-format change.
- No P8 navigation work.
- No browser connectivity listener.

## DATA/STATE FLOW
Startup:
persisted installation receipt -> P7.2 repository -> P7.4 verifier -> P7.5 coordinator -> P7.1 active-offline state.

First activation:
invite request -> P7.5 coordinator -> P7.3 adapter -> server receipt -> P7.4 verifier -> P7.2 repository commit -> P7.1 active-online state.

The coordinator never reports successful first activation before proof verification and the local save complete.

## PERSISTENCE
No schema migration. The existing `device.activation.receipt` metadata owner is reused.

## SECURITY
- Remote server remains invite authority.
- Server receipt is not trusted merely because the HTTP response is structurally valid.
- Receipt proof must verify before persistence.
- Persistence must succeed before activation success is reported.
- Corrupt/rejected persisted receipt fails closed to activation-required.
- Proof-verification unavailability fails closed to error.
- Duplicate activation submits are single-flight and do not create duplicate server requests.

## THEME
No theme changes.

## OFFLINE
A previously persisted receipt unlocks only after local public-proof verification. No service reachability is inferred from `navigator.onLine`.

## TESTS
New tests cover:
- missing receipt startup remains locked;
- verified persisted receipt restores offline-capable active state;
- rejected persisted proof fails closed;
- first activation performs remote validation -> proof verification -> persistence -> success;
- invalid server proof is not persisted and does not unlock;
- persistence failure does not report success;
- server rejection maps through existing state model;
- duplicate activation submissions remain single-flight.

## REGRESSION
Dependency-free P1 static contract and P7.5 static contract pass locally.
The local clean dependency resolution step timed out in this environment, so dependency-backed TypeScript/Vitest/build and the full P1-P7.5 regression sequence must run in GitHub Actions before promotion.

## PERFORMANCE
No polling, network monitoring, background loop, renderer, or observer introduced. Duplicate activation requests are suppressed while one validation attempt is in flight.

## KNOWN LIMITATIONS
Deployment configuration still needs to instantiate the remote adapter and public-key verifier. Presentation gating is intentionally deferred to the next controlled sub-patch.

## REAL-DEVICE STATUS
Not required for this non-UI application-layer patch. Future activation gate UI will require mobile/online/offline real-device verification.

## RESULT
HOLD — pending full GitHub gate.

## NEXT
Only if GitHub gate PASS: P7.6 activation gate presentation/bootstrap integration, using P7.5 as the sole activation orchestration owner.
