# KAIROS PATCH REPORT

Patch: P6.5 — Post-Restore Reopen / Re-query Verification
Base: P6.4R2 PASS / LOCKED
App version: 0.1.0
Build ID: existing locked build identity

## OBJECTIVE
Close the remaining P6 safe-import sequence by proving a committed restore survives a fresh database connection and authoritative repository re-query before Kairos reports restore success.

## RESEARCH
Re-checked the controlling handoff Safe Import Flow: transactional import -> post-import integrity sweep -> reload/re-query. Re-checked current MDN transaction guidance: successful completion marks transaction commit; clear + rewrite belongs in one transaction; later reads should use a new scoped read transaction. No experimental durability mode added.

## OWNER TRACE
- Transactional replacement owner: `src/data/backup/restoreReplacement.ts` (unchanged from P6.4R2)
- Database lifecycle owner: `src/data/database/databaseLifecycle.ts` (unchanged)
- Integrity owner: `src/data/database/integrity.ts` (unchanged)
- Repository owner: `src/data/repositories/MetadataRepository.ts` (unchanged)
- New final restore verification owner: `src/data/backup/restoreVerification.ts`

## PRE-CHANGE FLOW
P6.4R2 validated/prepared restore, preserved recovery snapshot, replaced metadata atomically, and ran post-import integrity. It did not yet close/reopen the database and verify the authoritative persisted records through a fresh query.

## CHANGE
Added `restoreAndVerifyKairosDatabase()` which:
1. delegates replacement to the P6.4 owner;
2. closes via the lifecycle owner;
3. reopens via the lifecycle owner;
4. runs integrity again after reopen;
5. re-queries metadata through the repository in a readonly transaction;
6. compares reloaded records with the prepared incoming backup;
7. returns success only when they match.

Typed failure codes: `REOPEN_FAILED`, `REQUERY_MISMATCH`. Recovery snapshot stays attached to verification errors and the success result.

## NON-SCOPE
No UI/file picker, merge restore, backup encryption/compression/hash, cloud backup, new schema, trade tables, or automatic recovery overwrite.

## DATA/STATE FLOW
Prepared restore -> P6.4 atomic replacement -> commit -> integrity -> lifecycle close -> lifecycle reopen -> integrity -> repository readonly re-query -> expected/actual verification -> success.

## PERSISTENCE
No schema change. Database remains V1 metadata-only. No package dependency change.

## SECURITY
No new secrets or executable imported content. Incoming backup remains data validated by prior P6 owners.

## THEME
No UI/theme impact.

## OFFLINE
Fully local/offline-capable.

## TESTS
Added `tests/restore-verification.test.ts` for successful non-empty verification, intentional empty restore, mismatch rejection, recovery preservation, and V1 schema preservation.

## REGRESSION
Static contracts P1/P2/P3/P4/P5/P6.1-P6.5 rerun locally where dependency-free. Full dependency-backed typecheck/tests/build remain GitHub gate owned.

## PERFORMANCE
Adds one deliberate close/reopen plus one readonly re-query per restore operation only. No normal journal hot path changed.

## KNOWN LIMITATIONS
Only backup format V1 / database schema V1 metadata store exists. Backup-format migration becomes meaningful only when a later backup format exists. No merge policy.

## REAL-DEVICE STATUS
Not required for this non-UI foundation patch; GitHub integration verification required.

## RESULT
HOLD pending full GitHub gate.

## NEXT
Only if PASS: close P6 Backup / Restore Foundation and proceed to controlled P7 Invite / Activation Gate discovery.
