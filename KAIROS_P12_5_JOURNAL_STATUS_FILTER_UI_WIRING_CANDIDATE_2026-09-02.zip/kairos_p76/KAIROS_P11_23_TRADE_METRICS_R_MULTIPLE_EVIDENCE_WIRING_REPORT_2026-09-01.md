# KAIROS P11.23 — TradeMetrics R-Multiple Evidence Wiring

Base: authoritative GitHub-gated P11.22 artifact.

Scope: wire the existing P11.7 `calculateRMultiple` primitive into TradeMetrics through explicit result amount + initial risk amount evidence. Existing P11.14 risk-performance evidence remains authoritative when supplied. No inferred risk, FX, persistence, UI, network, or native Number arithmetic.

Missing R evidence remains unavailable. Zero initial risk and malformed decimal evidence remain explicit errors through existing TradeMetrics error contracts.
