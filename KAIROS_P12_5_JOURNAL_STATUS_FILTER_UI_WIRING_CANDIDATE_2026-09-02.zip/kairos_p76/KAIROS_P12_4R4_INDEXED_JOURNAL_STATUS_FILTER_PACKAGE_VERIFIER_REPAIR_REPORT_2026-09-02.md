# KAIROS P12.4R4 — Indexed Journal Status Filter Package Verifier Repair

Status: HOLD pending canonical GitHub gate.

## Base
Exact canonical P12.3R1 PASS candidate.

## Purpose
Repair the P12.4R3 canonical gate failure caused solely by a dangling npm verifier registration for a superseded P12.4R1 script file.

## Controlled repair
- Preserve the P12.4 status-index implementation, schema-v3/backup-format-v2 compatibility work, and P5/P9 historical verifier compatibility repairs unchanged.
- Remove only the obsolete `verify:p12:journal-history-status-index-backup-repair` package registration.
- Preserve the cumulative P12.4R2 backup regression verifier.
- Preserve the P12.4R3 historical verifier compatibility verifier.
- Add a P12.4R4 package-verifier integrity check that walks every `verify:p*` package entry and fails if any directly referenced Node verifier file is missing.

## Non-scope
No UI filter wiring, no persistence owner changes, no backup format bump, no record-shape changes, no P13 work, no toolchain changes.
