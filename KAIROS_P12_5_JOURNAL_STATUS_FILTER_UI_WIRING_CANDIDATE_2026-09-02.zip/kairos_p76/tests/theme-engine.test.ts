import { describe, expect, it } from 'vitest';
import { applyTheme, defaultThemeId, resolveTheme, themeIds, themeRegistry } from '../src/design-system/themes';

describe('P3 theme engine active registry', () => {
  it('registers only the three approved active themes and keeps Kairos Depth default', () => {
    expect(themeIds).toEqual(['kairos-depth', 'cosmic', 'ocean']);
    expect(defaultThemeId).toBe('kairos-depth');
    expect(Object.keys(themeRegistry)).toEqual(themeIds);
  });

  it('resolves system preference to the certified default until a later preference policy owns it', () => {
    expect(resolveTheme('system', false)).toBe('kairos-depth');
    expect(resolveTheme('system', true)).toBe('kairos-depth');
    expect(resolveTheme('cosmic', true)).toBe('cosmic');
    expect(resolveTheme('ocean', false)).toBe('ocean');
  });

  it('keeps every active theme on one semantic token contract', () => {
    const expected = Object.keys(themeRegistry[defaultThemeId].tokens).sort();
    for (const theme of Object.values(themeRegistry)) expect(Object.keys(theme.tokens).sort()).toEqual(expected);
  });

  it('keeps geometry out of every theme definition', () => {
    for (const theme of Object.values(themeRegistry)) {
      expect(Object.keys(theme.tokens).some((key) => /spacing|radius|control|page-padding|card-gap|chart-min|navigation|motion/.test(key))).toBe(false);
    }
  });

  it('keeps themes visually distinct without changing their token shape', () => {
    expect(themeRegistry['kairos-depth'].tokens['--kairos-accent-primary']).not.toBe(themeRegistry.cosmic.tokens['--kairos-accent-primary']);
    expect(themeRegistry.cosmic.tokens['--kairos-accent-primary']).not.toBe(themeRegistry.ocean.tokens['--kairos-accent-primary']);
  });

  it('applies presentation state through the single theme owner', () => {
    const root = document.createElement('html');
    applyTheme(root, 'ocean');
    expect(root.dataset.kairosTheme).toBe('ocean');
    expect(root.style.colorScheme).toBe('dark');
    expect(root.style.getPropertyValue('--kairos-background-base')).toBe(themeRegistry.ocean.tokens['--kairos-background-base']);
  });
});
