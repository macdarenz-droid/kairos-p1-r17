import { describe, expect, it } from 'vitest';
import { buildInfo } from '../src/app/buildInfo';
import { KAIROS_BACKUP_FORMAT_NAME, KAIROS_BACKUP_FORMAT_VERSION, KairosBackupValidationError, createKairosBackupEnvelope, parseKairosBackup, serializeKairosBackup, validateKairosBackupEnvelope } from '../src/data/backup';

describe('P6 backup envelope compatibility under P9.2', () => {
 const metadata=[{key:'theme',value:'dark',updatedAt:'2026-08-31T08:00:00.000Z'}];
 it('creates current V2-format full-backup envelope with schema V3',()=>{const e=createKairosBackupEnvelope({metadata,exportedAt:new Date('2026-08-31T08:30:00.000Z'),appVersion:'test-app',buildId:'test-build'});expect(e).toMatchObject({formatName:KAIROS_BACKUP_FORMAT_NAME,formatVersion:2,databaseSchemaVersion:3,recordCounts:{metadata:1,trades:0,tradePlans:0,tradeExecutions:0,tradeFees:0,total:1}});expect(buildInfo.backupFormatVersion).toBe(KAIROS_BACKUP_FORMAT_VERSION);});
 it('round-trips current V2 JSON',()=>{const e=createKairosBackupEnvelope({metadata});expect(parseKairosBackup(serializeKairosBackup(e))).toEqual(e);});
 it('accepts an existing V2-format schema V2 backup after the index-only schema V3 upgrade',()=>{const current=createKairosBackupEnvelope({metadata});const legacySchemaTwo={...current,databaseSchemaVersion:2 as const};expect(parseKairosBackup(JSON.stringify(legacySchemaTwo))).toMatchObject({formatVersion:2,databaseSchemaVersion:2});});
 it('accepts and migrates legacy V1 metadata-only backup to V2 restore model',()=>{const legacy={formatName:KAIROS_BACKUP_FORMAT_NAME,formatVersion:1,appVersion:'old',buildId:'old',exportedAt:'2026-08-31T08:30:00.000Z',databaseSchemaVersion:1,recordCounts:{metadata:1,total:1},payload:{metadata}};const migrated=parseKairosBackup(JSON.stringify(legacy));expect(migrated).toMatchObject({formatVersion:2,databaseSchemaVersion:2,recordCounts:{metadata:1,trades:0,total:1}});expect(migrated.payload.metadata).toEqual(metadata);});
 it('rejects unsupported future format versions and malformed payloads',()=>{const e=createKairosBackupEnvelope({metadata});expect(()=>validateKairosBackupEnvelope({...e,formatVersion:3})).toThrowError(expect.objectContaining({code:'UNSUPPORTED_FORMAT_VERSION'}));expect(()=>validateKairosBackupEnvelope({...e,payload:{...e.payload,trades:[{}]}})).toThrow(KairosBackupValidationError);});
});
