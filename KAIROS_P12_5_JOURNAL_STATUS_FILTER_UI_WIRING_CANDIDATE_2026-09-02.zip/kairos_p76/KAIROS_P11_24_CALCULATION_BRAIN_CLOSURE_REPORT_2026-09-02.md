# KAIROS P11.24 — Calculation Brain Closure / Orchestration Gate

## Status
HOLD pending canonical GitHub gate.

## Authoritative base
P11.23 TradeMetrics R-Multiple Evidence Wiring — canonical PASS from run #50 / 33515982101.

## Objective
Close the P11 Calculation Brain only after proving that the independently gated calculation owners compose coherently through TradeMetrics and still preserve the architecture's missing-evidence and no-hidden-FX rules.

## Research
Current npm metadata still lists `decimal.js` 10.6.0 as latest. Kairos is already locked to exactly 10.6.0. Its arbitrary-precision decimal model remains appropriate for Kairos financial truth, so P11.24 introduces no dependency or arithmetic-owner change.

## Ownership / data flow
Authoritative trade execution evidence -> execution balance / gross realized P&L.
Authoritative fee evidence -> fee aggregation.
Explicit currency evidence -> comparability policy -> net P&L composition.
Explicit percentage evidence -> PercentageCalculator.
Explicit risk evidence -> RiskCalculator / RMultipleCalculator composition.
All results -> TradeMetrics immutable derived view -> later P12+ consumers.

## Architecture audit result
The locked P0 candidate Calculation Engine owners are present: RiskCalculator, PositionSizeCalculator, LeverageCalculator, RMultipleCalculator, PercentageCalculator, and MarketSpecificCalculationPolicy, together with the execution/P&L/fee composition owners added during P11.

Every candidate TradeMetrics field named by the controlling handoff is represented, and missing financial evidence remains nullable/unavailable rather than silently becoming zero.

## Controlled change
No production calculation formula or owner is changed.

Adds only:
- one P11 orchestration/closure regression test;
- one static closure verifier;
- one package verification script entry;
- this report.

## Closure regression coverage
- a fully realized trade composes gross P&L, fees, comparable net P&L, P&L percentage, initial risk and realized R simultaneously;
- all completeness flags become true only when corresponding evidence exists;
- open/missing evidence remains null rather than zero;
- mismatched nonzero fee currency leaves net P&L unavailable and performs no FX conversion.

## Non-scope
No new financial formula. No universal market-specific risk, P&L percentage denominator, leverage, margin, contract multiplier, tick-value, lot-size, or FX assumption. No persistence/schema/repository, backup/restore, UI, routing, P12 Journal History, network, activation, deployment, or theme change.

## Promotion rule
P11.24 may close P11 only if the canonical GitHub gate passes deterministic install, build, full unit regression, all P1-P10 regressions, every P11.1R2-P11.23 verifier, and the new P11.24 closure verifier/test. Until then P11.23 remains authoritative.

## Next
Only after canonical PASS: mark P11 Calculation Brain closed and allow the next controlled roadmap patch to begin P12 Journal History from the exact P11.24 PASS artifact.
