# KAIROS P11.14 TradeMetrics Risk Evidence Wiring Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.13 authoritative PASS from controlled gate run #34.

## Objective
Allow the existing TradeMetrics owner to expose `initialRisk` and `realizedR` only when already-authoritative risk-performance evidence is supplied to the Calculation Engine.

## Research
The controlling handoff was re-checked before implementation. It defines TradeMetrics as derived output, lists `initialRisk` and `realizedR` as optional metrics, requires completeness flags, and explicitly states that missing financial data must never silently become zero. It also protects the Calculation Engine as the owner of financial derivation.

No current third-party API behavior is introduced by this patch, so no new external runtime dependency research was required.

## Owner trace
authoritative caller evidence
-> TradeMetrics risk-performance input contract
-> P11.13 RiskPerformanceCalculator
-> P11.12 InitialRiskAmount primitive
-> P11.7 RMultipleCalculator
-> TradeMetrics `initialRisk` / `realizedR` + completeness

Existing execution evidence continues independently through execution balance and flat-trade gross P&L.

## Pre-change flow
TradeMetrics always emitted `initialRisk: null` and `realizedR: null` with both completeness flags false, even though P11.13 could safely compose those values from authoritative inputs.

## Change
`calculateTradeMetrics` gains an optional third argument, `TradeMetricsRiskPerformanceInput`, containing:
- `resultAmount`;
- `riskPerUnit`;
- `quantity`.

When omitted, risk metrics remain null/incomplete exactly as before.

When supplied, TradeMetrics delegates all risk arithmetic to `calculateRiskPerformance` and exposes the returned `initialRisk` and `realizedR`.

Invalid supplied risk evidence fails explicitly instead of being downgraded to unavailable data.

The historical P11.5 static verifier was narrowed so it continues enforcing the original execution/metric foundation without permanently requiring future risk fields to remain null.

## Critical semantic boundary
P11.14 deliberately does not assert that `resultAmount` equals `grossPnl`.

That value must already be authoritative when supplied. This keeps future fee/net-P&L/currency semantics open and prevents TradeMetrics from silently choosing gross versus net R.

## Non-scope
- no fee aggregation;
- no net P&L;
- no P&L percentage wiring;
- no FX/currency conversion;
- no market/instrument policy selection;
- no direct stop-distance monetary-risk inference;
- no persistence/schema/repository changes;
- no UI, journal-history, chart, market-data, or network changes.

## Data/state flow
caller authoritative evidence -> Calculation Engine -> existing calculation owners -> TradeMetrics output.

No repository or renderer is involved.

## Persistence
None.

## Security
No new surface.

## Theme
No impact.

## Offline
Pure synchronous local Calculation Engine behavior.

## Tests
Covers:
- omitted risk evidence remains unavailable;
- successful initial-risk/R wiring;
- independent resultAmount versus gross P&L;
- negative loss/R preservation;
- explicit zero-initial-risk failure;
- explicit malformed risk-evidence failure.

## Regression
P1 and every existing P11 static verifier through P11.13 are rerun locally, plus P11.14. The canonical GitHub gate must still run npm ci, build, the full unit suite, P1-P11.14 regression, and artifact capture.

## Performance
One optional bounded P11.13 composition when risk evidence is supplied. No loops, persistence, rendering, observers, or network work added.

## Known limitations
- caller ownership of `resultAmount` is intentionally not yet selected from gross versus future net P&L;
- fees, FX, percentage and market-specific monetary-risk policies remain unresolved;
- no journal consumer is wired in P11.

## Real-device status
Not required. Pure domain calculation with no device/UI behavior.

## Result
HOLD pending canonical GitHub gate.

## Next
Only after PASS, reassess the remaining P11 Calculation Brain gaps before any move to P12 Journal History.
