# Analysis saved-trade Risk/Reward React lifecycle binding

## Gate456 bounded scope

Gate455 is the FULL canonical base. This non-UI item-5 slice binds the released saved-trade Risk/Reward presentation session to one React hook lifetime.

The hook creates one session per mounted hook, exposes its exact renderer factory, and delegates the exact P12-hydrated saved trade plus caller-authoritative chart scope, logical time extent, style source and refresh revision through that same session. Complete results update atomically. If a released lower owner rejects ambiguous evidence, the last complete result remains available with the exact error kept separately. Unmount closes only the hook's own session once, and synchronous construction failure cannot manufacture a renderer or presentation.

Gate455 remains the application composition owner. Gate454 remains the production renderer lifecycle owner. Gate449 remains the renderer conversion owner, Gate448 remains the logical Risk/Reward composition owner, and Gate438 remains chart-reference eligibility truth. P14/P17/P18/P19/P20 ownership is unchanged.

This hook does not import or mount the Analysis route, history workspace or live canvas. It starts no history request or transport, implements no provider primitive, scale conversion, Canvas drawing, persistence, journal read or mutation, arithmetic or normalization, and makes no execution, venue, FX or P&L inference.

UI visible: no. Live-canvas composition, workspace mount, accessible Risk/Reward evidence, P18 interactions, P20 save/load and rendered browser interactions remain separate bounded slices.
