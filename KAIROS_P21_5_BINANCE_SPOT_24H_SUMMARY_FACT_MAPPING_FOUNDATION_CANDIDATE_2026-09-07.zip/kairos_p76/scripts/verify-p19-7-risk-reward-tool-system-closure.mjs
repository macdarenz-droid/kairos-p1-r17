import { readFileSync } from 'node:fs';

const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const architecture = readFileSync(new URL('../docs/KAIROS_ARCHITECTURE_MAP.md', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P19_7_RISK_REWARD_TOOL_SYSTEM_CLOSURE_REPORT_2026-09-06.md', import.meta.url), 'utf8');

const requiredScripts = [
  'verify:p19:1-risk-reward-analysis-contract-foundation',
  'verify:p19:2-risk-reward-zone-semantics-projection',
  'verify:p19:3-risk-reward-chart-composition-semantic-contract',
  'verify:p19:4-risk-reward-chart-semantic-style-projection',
  'verify:p19:5-risk-reward-chart-logical-placement-projection',
  'verify:p19:6-risk-reward-chart-logical-object-projection',
];
for (const name of requiredScripts) {
  if (typeof pkg.scripts?.[name] !== 'string') throw new Error(`P19.7 closure missing retained verifier registration: ${name}`);
}

for (const token of [
  'P19 (SYSTEM CLOSED through P19.7)',
  '## P19 Risk/Reward Tool System Closure — canonical P19.7',
  'P19.7 adds **no production runtime behavior and no new production owner**',
  'P18 remains the sole generic chart drawing / provider / interaction machinery owner',
  'P20 owns later Saved Analysis persistence',
  'renderer-number conversion, Lightweight Charts production calls, and pixel/screen geometry remain outside this closure',
]) {
  if (!architecture.includes(token)) throw new Error(`P19.7 architecture closure evidence missing: ${token}`);
}

for (const token of [
  '# KAIROS P19.7 — Risk/Reward Tool System Closure',
  'No production runtime source changes',
  'P19.1 through P19.6',
  'P20 retains Saved Analysis persistence',
  'P18 retains generic chart drawing, provider, and interaction machinery',
]) {
  if (!report.includes(token)) throw new Error(`P19.7 closure report evidence missing: ${token}`);
}

console.log('P19.7 Risk/Reward Tool system closure verification passed.');
