import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/app/riskRewardChartStyleProjection.ts', import.meta.url), 'utf8');
const test = readFileSync(new URL('../tests/risk-reward-chart-style-projection.test.ts', import.meta.url), 'utf8');
const semantic = readFileSync(new URL('../src/design-system/tokens/semantic.ts', import.meta.url), 'utf8');

for (const token of [
  "import type { RiskRewardChartSemantics } from '../application/risk-reward'",
  "import { semanticTokens } from '../design-system/tokens/semantic'",
  'export interface RiskRewardChartStyleRoleProjection',
  'export interface RiskRewardChartStyleProjection',
  "readonly entry: RiskRewardChartStyleRoleProjection<'entry'>",
  "readonly stop: RiskRewardChartStyleRoleProjection<'stop'>",
  "readonly target: RiskRewardChartStyleRoleProjection<'target'>",
  "readonly risk: RiskRewardChartStyleRoleProjection<'risk'>",
  "readonly reward: RiskRewardChartStyleRoleProjection<'reward'>",
  'export function projectRiskRewardChartStyle',
  'role: semantics.levels.entry.role, token: semanticTokens.trade.entry',
  'role: semantics.levels.stop.role, token: semanticTokens.trade.stop',
  'role: semantics.levels.target.role, token: semanticTokens.trade.target',
  'role: semantics.zones.risk.role, token: semanticTokens.trade.riskZone',
  'role: semantics.zones.reward.role, token: semanticTokens.trade.rewardZone',
]) {
  if (!source.includes(token)) throw new Error(`P19.4 style projection missing: ${token}`);
}
for (const token of [
  "entry: role('trade-entry')",
  "stop: role('trade-stop')",
  "target: role('trade-target')",
  "riskZone: role('trade-risk-zone')",
  "rewardZone: role('trade-reward-zone')",
]) {
  if (!semantic.includes(token)) throw new Error(`P19.4 required semantic token missing: ${token}`);
}
for (const forbidden of [
  'lightweight-charts', 'ChartDrawing', 'IndexedDB', 'Dexie', 'localStorage',
  'fetch(', 'WebSocket', 'calculateTradeMetrics', 'calculateRisk', 'calculateRMultiple',
  'Math.min', 'Math.max', 'timestamp', 'document.', 'window.', '.applyOptions(',
  'addSeries(', 'createChart(', 'setData(', 'update(', 'priceToCoordinate(',
]) {
  if (source.includes(forbidden)) throw new Error(`P19.4 style projection owns forbidden concern: ${forbidden}`);
}
if (/(#[0-9a-fA-F]{3,8}\b|rgba?\(|hsla?\()/.test(source)) {
  throw new Error('P19.4 style projection hard-codes a visual color value');
}
for (const token of [
  'semanticTokens.trade.entry',
  'semanticTokens.trade.stop',
  'semanticTokens.trade.target',
  'semanticTokens.trade.riskZone',
  'semanticTokens.trade.rewardZone',
  'CSS-variable semantic references',
  'not.toMatch(/^(#|rgb|hsl)/)',
]) {
  if (!test.includes(token)) throw new Error(`P19.4 focused test missing: ${token}`);
}
console.log('P19.4 Risk/Reward chart semantic style projection verification passed.');
