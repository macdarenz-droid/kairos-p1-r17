import { readFileSync } from 'node:fs';

const save = readFileSync(new URL('../src/application/saved-analysis/saveSavedAnalysis.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/application/saved-analysis/index.ts', import.meta.url), 'utf8');
const test = readFileSync(new URL('../tests/saved-analysis-save-command.test.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P20_3_SAVED_ANALYSIS_APPLICATION_SAVE_ORCHESTRATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');

for (const token of [
  "import { createSavedAnalysisId } from '../../app/savedAnalysisIdentity'",
  "import { runKairosAtomicWrite } from '../../data/database/transactions'",
  "export type SaveSavedAnalysisInput = Omit<SavedAnalysis, 'id'>",
  "await runKairosAtomicWrite(db, ['savedAnalyses']",
  'await repositories.savedAnalyses.put(record)',
  "reason: 'saved-analysis-save-failed'",
  'return { ok: true, savedAnalysisId }',
]) {
  if (!save.includes(token)) throw new Error(`P20.3 save orchestration evidence missing: ${token}`);
}

for (const forbidden of [
  'LightweightCharts',
  'timeframe',
  'createdAt',
  'updatedAt',
  'name:',
  'delete(',
  'listAll(',
  'get(',
]) {
  if (save.includes(forbidden)) throw new Error(`P20.3 save orchestration contains forbidden scope: ${forbidden}`);
}

if (!index.includes("export * from './saveSavedAnalysis'")) {
  throw new Error('P20.3 application export evidence missing');
}

for (const token of [
  'P20.3 Saved Analysis application save orchestration',
  'saved-analysis-save-failed',
  'does not mutate the caller-owned logical input',
]) {
  if (!test.includes(token)) throw new Error(`P20.3 focused test evidence missing: ${token}`);
}

for (const token of [
  '# KAIROS P20.3 — Saved Analysis Application Save Orchestration',
  'P20.2',
  'createSavedAnalysisId',
  'SavedAnalysisRepository',
  'No UI',
  'No list/load/delete orchestration',
]) {
  if (!report.includes(token)) throw new Error(`P20.3 report evidence missing: ${token}`);
}

console.log('P20.3 Saved Analysis application save orchestration verification passed.');
