import { readFileSync } from 'node:fs';

const contract = readFileSync(new URL('../src/app/savedAnalysisContract.ts', import.meta.url), 'utf8');
const identity = readFileSync(new URL('../src/app/savedAnalysisIdentity.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P20_1_SAVED_ANALYSIS_CONTRACT_FOUNDATION_REPORT_2026-09-06.md', import.meta.url), 'utf8');

for (const token of [
  "import type { RiskRewardAnalysis } from '../application/risk-reward'",
  "import type { ChartDrawing, ChartMarketReference } from '../features/chart'",
  "import type { RiskRewardChartTimeExtent } from './riskRewardChartPlacementProjection'",
  'export type SavedAnalysisId = string',
  'readonly analysis: RiskRewardAnalysis',
  'readonly extent: RiskRewardChartTimeExtent',
  'readonly market: ChartMarketReference',
  'readonly drawings: readonly ChartDrawing[]',
  'readonly riskRewards: readonly SavedRiskRewardAnalysis[]',
]) {
  if (!contract.includes(token)) throw new Error(`P20.1 Saved Analysis contract evidence missing: ${token}`);
}

for (const token of [
  'export function createSavedAnalysisId()',
  'return crypto.randomUUID()',
]) {
  if (!identity.includes(token)) throw new Error(`P20.1 Saved Analysis identity evidence missing: ${token}`);
}

for (const forbidden of [
  'timeframe:',
  'tradeId:',
  'createdAt:',
  'updatedAt:',
  'pixel',
  'LightweightCharts',
  'KairosDatabase',
]) {
  if (contract.includes(forbidden)) throw new Error(`P20.1 contract contains forbidden unowned field/dependency: ${forbidden}`);
}

for (const token of [
  '# KAIROS P20.1 — Saved Analysis Contract Foundation',
  'P19.7 Risk/Reward Tool System Closure',
  'contract-only',
  'empty drawing and Risk/Reward collections remain representable',
  'No database schema, migration, repository, transaction, backup/restore, UI, provider, or pixel work',
]) {
  if (!report.includes(token)) throw new Error(`P20.1 report evidence missing: ${token}`);
}

console.log('P20.1 Saved Analysis contract foundation verification passed.');
