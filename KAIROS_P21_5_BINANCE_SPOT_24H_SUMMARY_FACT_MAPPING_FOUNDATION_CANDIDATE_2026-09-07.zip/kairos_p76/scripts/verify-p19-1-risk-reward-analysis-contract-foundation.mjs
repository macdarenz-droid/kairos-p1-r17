import { readFileSync } from 'node:fs';

const contract = readFileSync(new URL('../src/application/risk-reward/riskRewardAnalysisContract.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/application/risk-reward/index.ts', import.meta.url), 'utf8');
const test = readFileSync(new URL('../tests/risk-reward-analysis-contract.test.ts', import.meta.url), 'utf8');

const required = [
  "import type { DecimalString, TradeSide } from '../../domain/trades'",
  'export type RiskRewardAnalysisId = string',
  'export interface RiskRewardAnalysisLevels',
  'readonly entry: DecimalString',
  'readonly stop: DecimalString',
  'readonly target: DecimalString',
  'export interface RiskRewardAnalysis',
  'readonly side: TradeSide',
  'readonly levels: RiskRewardAnalysisLevels',
  'export function defineRiskRewardAnalysis',
];
for (const token of required) {
  if (!contract.includes(token)) throw new Error(`P19.1 RR contract missing: ${token}`);
}
for (const forbidden of [
  'lightweight-charts', 'ChartDrawing', 'IndexedDB', 'Dexie', 'fetch(', 'WebSocket',
  'calculateTradeMetrics', 'calculateRisk', 'calculateRMultiple', 'journalExecutions',
  'TradeExecutionRecord', 'TradePlanRecord', 'TradeRecord',
]) {
  if (contract.includes(forbidden)) throw new Error(`P19.1 RR contract owns forbidden concern: ${forbidden}`);
}
if (!index.includes("from './riskRewardAnalysisContract'")) throw new Error('P19.1 risk-reward index does not export semantic contract');
for (const token of ["side: 'long'", "entry: decimal('100')", "stop: decimal('90')", "target: decimal('120')"]) {
  if (!test.includes(token)) throw new Error(`P19.1 focused test missing: ${token}`);
}
console.log('P19.1 Risk/Reward analysis semantic contract foundation verification passed.');
