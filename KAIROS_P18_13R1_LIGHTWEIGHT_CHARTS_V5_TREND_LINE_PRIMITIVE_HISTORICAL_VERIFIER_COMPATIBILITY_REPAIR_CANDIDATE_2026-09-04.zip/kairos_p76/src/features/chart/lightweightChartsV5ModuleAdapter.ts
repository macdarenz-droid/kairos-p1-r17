import type {
  ChartEngineDriver,
  ChartEngineSeriesHandle,
} from './chartEngineDriver';
import type {
  RendererCandle,
  RendererPricePoint,
} from './chartSeriesProjection';

export interface LightweightChartsV5SeriesApi<TData> {
  setData(data: readonly TData[]): void;
  update(data: TData): void;
}

export interface LightweightChartsV5LogicalRange {
  readonly from: number;
  readonly to: number;
}

export type LightweightChartsV5LogicalRangeChangeHandler = (
  range: LightweightChartsV5LogicalRange | null,
) => void;

export interface LightweightChartsV5TimeScaleApi {
  getVisibleLogicalRange(): LightweightChartsV5LogicalRange | null;
  subscribeVisibleLogicalRangeChange(
    handler: LightweightChartsV5LogicalRangeChangeHandler,
  ): void;
  unsubscribeVisibleLogicalRangeChange(
    handler: LightweightChartsV5LogicalRangeChangeHandler,
  ): void;
}

export interface LightweightChartsV5ChartApi {
  timeScale(): LightweightChartsV5TimeScaleApi;
  addSeries<TData>(
    definition: LightweightChartsV5SeriesDefinition<TData>,
  ): LightweightChartsV5SeriesApi<TData>;
  removeSeries(series: LightweightChartsV5SeriesApi<unknown>): void;
  remove(): void;
}

export interface LightweightChartsV5SeriesDefinition<TData> {
  readonly __kairosSeriesData?: TData;
}

export interface LightweightChartsV5ChartOptions {
  readonly autoSize?: boolean;
}

export interface LightweightChartsV5Module {
  createChart(
    container: HTMLElement,
    options?: LightweightChartsV5ChartOptions,
  ): LightweightChartsV5ChartApi;
  LineSeries: LightweightChartsV5SeriesDefinition<RendererPricePoint>;
  CandlestickSeries: LightweightChartsV5SeriesDefinition<RendererCandle>;
}

export interface LightweightChartsV5DriverBinding {
  readonly driver: ChartEngineDriver;
  resolveSeries(handle: ChartEngineSeriesHandle): LightweightChartsV5SeriesApi<unknown>;
}

/**
 * P18.9 provider-series resolution invariant:
 * - the neutral ChartEngineSeriesHandle remains free of vendor methods
 * - this binding owns only the existing handle-to-vendor-series identity map
 * - resolution fails closed for unknown or already-removed handles
 * - createLightweightChartsV5Driver remains backward-compatible by returning only the neutral driver
 * - no primitive lifecycle, Canvas, drawing projection, interaction, persistence, calculation,
 *   market acquisition, journal truth, or P19 behavior lives here
 */
export function createLightweightChartsV5DriverBinding(
  module: LightweightChartsV5Module,
): LightweightChartsV5DriverBinding {
  const seriesLookup = new Map<
    ChartEngineSeriesHandle,
    LightweightChartsV5SeriesApi<unknown>
  >();

  const driver: ChartEngineDriver = {
    createChart(container: HTMLElement) {
      const chart = module.createChart(container);

      const wrapLine = (
        series: LightweightChartsV5SeriesApi<RendererPricePoint>,
      ): ChartEngineSeriesHandle => ({
        setPriceLineData(data): void {
          series.setData(data);
        },
        setCandleData(): void {
          throw new Error('chart-series-kind-mismatch');
        },
        updatePriceLine(point): void {
          series.update(point);
        },
        updateCandle(): void {
          throw new Error('chart-series-kind-mismatch');
        },
      });

      const wrapCandles = (
        series: LightweightChartsV5SeriesApi<RendererCandle>,
      ): ChartEngineSeriesHandle => ({
        setPriceLineData(): void {
          throw new Error('chart-series-kind-mismatch');
        },
        setCandleData(data): void {
          series.setData(data);
        },
        updatePriceLine(): void {
          throw new Error('chart-series-kind-mismatch');
        },
        updateCandle(candle): void {
          series.update(candle);
        },
      });

      return {
        addPriceLineSeries(): ChartEngineSeriesHandle {
          const vendorSeries = chart.addSeries(module.LineSeries);
          const handle = wrapLine(vendorSeries);
          seriesLookup.set(
            handle,
            vendorSeries as LightweightChartsV5SeriesApi<unknown>,
          );
          return handle;
        },

        addCandlestickSeries(): ChartEngineSeriesHandle {
          const vendorSeries = chart.addSeries(module.CandlestickSeries);
          const handle = wrapCandles(vendorSeries);
          seriesLookup.set(
            handle,
            vendorSeries as LightweightChartsV5SeriesApi<unknown>,
          );
          return handle;
        },

        removeSeries(handle: ChartEngineSeriesHandle): void {
          const vendorSeries = seriesLookup.get(handle);
          if (vendorSeries === undefined) {
            throw new Error('chart-series-handle-unknown');
          }
          seriesLookup.delete(handle);
          chart.removeSeries(vendorSeries);
        },

        remove(): void {
          seriesLookup.clear();
          chart.remove();
        },
      };
    },
  };

  return {
    driver,
    resolveSeries(handle: ChartEngineSeriesHandle): LightweightChartsV5SeriesApi<unknown> {
      const vendorSeries = seriesLookup.get(handle);
      if (vendorSeries === undefined) {
        throw new Error('chart-series-handle-unknown');
      }
      return vendorSeries;
    },
  };
}

export function createLightweightChartsV5Driver(
  module: LightweightChartsV5Module,
): ChartEngineDriver {
  return createLightweightChartsV5DriverBinding(module).driver;
}
