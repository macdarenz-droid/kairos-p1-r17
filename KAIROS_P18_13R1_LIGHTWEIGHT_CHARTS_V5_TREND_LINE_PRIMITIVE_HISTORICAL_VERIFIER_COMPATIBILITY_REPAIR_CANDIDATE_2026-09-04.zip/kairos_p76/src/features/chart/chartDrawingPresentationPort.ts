import type { ChartEngineDriver, ChartEngineSeriesHandle } from './chartEngineDriver';
import type { RendererSeriesProjection } from './chartSeriesProjection';
import type { ChartDrawingLayerPort, ChartDrawingLayerSession } from './chartDrawingLayerPort';
import type { RendererChartDrawing } from './chartDrawingProjection';

export interface ChartDrawingPresentationSession {
  replace(
    series: RendererSeriesProjection,
    drawings: readonly RendererChartDrawing[],
  ): void;
  destroy(): void;
}

export interface ChartDrawingPresentationPort {
  create(container: HTMLElement): ChartDrawingPresentationSession;
}

/**
 * P18.11 provider-neutral presentation coordination invariant:
 * - P17 ChartEngineDriver remains the series-resource owner
 * - P18.3 ChartDrawingLayerPort remains the drawing attachment lifecycle owner
 * - each replace() builds one fresh series and one drawing-layer attachment for the same handle
 * - the drawing layer is detached before its series is removed
 * - failed replacement is cleaned up without promoting a partial active presentation
 * - this boundary owns no drawing truth, journal truth, market truth, persistence,
 *   calculations, acquisition, interaction state, autoscale policy, or navigation state
 */
export function createChartDrawingPresentationPort(
  driver: ChartEngineDriver,
  drawingLayer: ChartDrawingLayerPort,
): ChartDrawingPresentationPort {
  return {
    create(container: HTMLElement): ChartDrawingPresentationSession {
      const chart = driver.createChart(container);
      let activeSeries: ChartEngineSeriesHandle | null = null;
      let activeDrawingLayer: ChartDrawingLayerSession | null = null;
      let destroyed = false;

      const clearActive = (): void => {
        if (activeDrawingLayer !== null) {
          activeDrawingLayer.destroy();
          activeDrawingLayer = null;
        }
        if (activeSeries !== null) {
          chart.removeSeries(activeSeries);
          activeSeries = null;
        }
      };

      const createSeries = (series: RendererSeriesProjection): ChartEngineSeriesHandle => {
        if (series.kind === 'price-line') {
          const handle = chart.addPriceLineSeries();
          handle.setPriceLineData(series.data);
          return handle;
        }

        const handle = chart.addCandlestickSeries();
        handle.setCandleData(series.data);
        return handle;
      };

      return {
        replace(series, drawings): void {
          if (destroyed) throw new Error('chart-drawing-presentation-destroyed');
          clearActive();

          let nextSeries: ChartEngineSeriesHandle | null = null;
          let nextDrawingLayer: ChartDrawingLayerSession | null = null;
          try {
            nextSeries = createSeries(series);
            nextDrawingLayer = drawingLayer.attach(nextSeries);
            nextDrawingLayer.replaceDrawings(drawings);
            activeSeries = nextSeries;
            activeDrawingLayer = nextDrawingLayer;
          } catch (error) {
            if (nextDrawingLayer !== null) nextDrawingLayer.destroy();
            if (nextSeries !== null) chart.removeSeries(nextSeries);
            throw error;
          }
        },

        destroy(): void {
          if (destroyed) return;
          destroyed = true;
          clearActive();
          chart.remove();
        },
      };
    },
  };
}
