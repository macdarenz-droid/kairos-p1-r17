# KAIROS P23.2 — Saved Time-Assisted Snapshot Persistence Foundation

**Patch label:** P23.2 · P23 durable time-assisted snapshot provenance · owner phase P23 (active from the Gate485 canonical PASS) · definition: the raw persistence, integrity and full backup/restore extension for the P23.1 saved time-assisted snapshot contract.

## Authority
Base: canonical Gate486 (P23.1 contract foundation). The user chose on 18 September 2026 to proceed with P23 under the same gate discipline ("1"); the P22 closure report named the schema bump and the new backup format version as the controlled extensions P23 requires.

## Result
P23.2 evolves the closed P5/P6/P20 persistence owners coherently instead of adding a side store:

- Database schema version 5 appends `KAIROS_V5_STORES = { savedTimeAssistedSnapshots: '&id' }` through the append-only `KAIROS_V5_MIGRATION`; v1–v4 history stays declared and frozen. The store keeps only the stable id primary key; no secondary index is introduced because no query owner exists yet.
- `SavedTimeAssistedSnapshotRepository` persists the P23.1 contract verbatim (get, listAll, put, delete, replaceAll with structured clones) and is registered on the repository set.
- Integrity adds `saved-time-assisted-snapshot-primary-key` and `saved-time-assisted-snapshot-record-shape` and reports `savedTimeAssistedSnapshotRecordCount`; the shape check validates the P22.1 estimate provenance (candle-range or unavailable), `isEstimate: true` and `source: 'market-reference'`, and fails closed.
- The backup format V4 describes database schema version 5 and carries `savedTimeAssistedSnapshots` in the payload and the record counts. `KAIROS_SAVED_ANALYSIS_BACKUP_FORMAT_VERSION = 3` names the released V3 contract. V1, V2 and V3 backups remain accepted and migrate to V4 with an empty snapshot store. Validation rejects malformed snapshot payloads; restore preflight rejects `DUPLICATE_SAVED_TIME_ASSISTED_SNAPSHOT_ID`, previews `savedTimeAssistedSnapshotRecords`, and the recovery snapshot captures the current snapshots; replacement runs in the single atomic write over all seven stores and reports `restoredSavedTimeAssistedSnapshotRecords`; verification re-reads and compares the store after reopen.

`tests/saved-time-assisted-snapshot-persistence.test.ts` proves the schema, clone-safe repository round trip, closed integrity failure, V4 round trip and database snapshot, V3 → V4 migration, malformed/duplicate rejection before replacement, and atomic replacement with verified reload. Existing P5/P6/P9/P12/P20 tests and verifiers advance their current-version pins to schema 5 / format V4 while keeping every released-history pin (V1 metadata, V2 trades, V3 status index, V4 Saved Analyses, backup V1/V2/V3).

## Ownership
P23 owns the saved snapshot store, its migration, repository, integrity checks and the V4 backup/restore extension. P5 keeps the database kernel and migration harness; P6 keeps the backup/restore lifecycle; P20 keeps Saved Analyses; P23.1 keeps the logical contract; P22.1/P22.2 keep estimate semantics; the journal owners keep trade truth.

## Non-scope
No application save/load orchestration, UI, provider or pixel work. No query index, display name, trade relation or renderer state is introduced. Nothing in the workspace changes.

## Next dependency boundary
P23.3 must add the application save orchestration (contract composition from the P22.2 snapshot, identity allocation, save moment, repository write) on top of this store; P23.4 the load-one path; P23.5 the preview UI save/list/load; P23.6 the closure.

## Canonical requirement
This persistence becomes authoritative only after the exact P23.2 candidate receives a full `Kairos Controlled Roadmap Gate` PASS with both canonical artifacts and main carries the same commit with its own canonical PASS. P23.3 may not begin before that PASS.
