import 'fake-indexeddb/auto';
import Dexie from 'dexie';
import { afterEach, describe, expect, it } from 'vitest';
import {
  KAIROS_DATABASE_MIGRATIONS,
  KAIROS_DB_SCHEMA_VERSION,
  KAIROS_V1_STORES,
  createKairosDatabase,
  openKairosDatabase,
  registerKairosMigrations,
  validateKairosMigrationSequence,
  type KairosMigrationDefinition,
} from '../src/data/database';

const openedNames = new Set<string>();

function makeDatabaseName(label: string) {
  const name = `kairos-test-p5-3-${label}-${crypto.randomUUID()}`;
  openedNames.add(name);
  return name;
}

afterEach(async () => {
  for (const name of openedNames) {
    await new Promise<void>((resolve, reject) => {
      const request = indexedDB.deleteDatabase(name);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
      request.onblocked = () => reject(new Error(`Delete blocked for ${name}`));
    });
  }
  openedNames.clear();
});

describe('P5.3 migration harness', () => {
  it('keeps the production migration registry aligned to immutable schema v1', () => {
    expect(KAIROS_DB_SCHEMA_VERSION).toBe(1);
    expect(KAIROS_DATABASE_MIGRATIONS).toHaveLength(1);
    expect(KAIROS_DATABASE_MIGRATIONS[0]).toEqual({
      version: 1,
      stores: KAIROS_V1_STORES,
    });
    expect(Object.isFrozen(KAIROS_DATABASE_MIGRATIONS)).toBe(true);
    expect(Object.isFrozen(KAIROS_DATABASE_MIGRATIONS[0])).toBe(true);
    expect(() => validateKairosMigrationSequence(KAIROS_DATABASE_MIGRATIONS)).not.toThrow();
  });

  it('rejects skipped, reordered, or mismatched migration history before database open', () => {
    const skipped = [
      { version: 1, stores: KAIROS_V1_STORES },
      { version: 3, stores: KAIROS_V1_STORES },
    ] satisfies readonly KairosMigrationDefinition[];

    expect(() => validateKairosMigrationSequence(skipped, 3)).toThrow(/contiguous and append-only/);
    expect(() => validateKairosMigrationSequence(KAIROS_DATABASE_MIGRATIONS, 2)).toThrow(/ends at v1/);
  });

  it('leaves the live production schema at v1 with metadata only', async () => {
    const db = createKairosDatabase(makeDatabaseName('production-schema'));
    const status = await openKairosDatabase(db);

    expect(status).toEqual({ state: 'ready', schemaVersion: 1 });
    expect(db.verno).toBe(1);
    expect(db.tables.map((table) => table.name)).toEqual(['metadata']);
    db.close();
  });

  it('proves old fixture -> versioned upgrade -> integrity read -> reload using the harness', async () => {
    const name = makeDatabaseName('upgrade-fixture');

    const oldDb = new Dexie(name);
    oldDb.version(1).stores({ metadata: '&key' });
    await oldDb.open();
    await oldDb.table('metadata').put({ key: 'fixture', value: 'legacy' });
    oldDb.close();

    const syntheticMigrations: readonly KairosMigrationDefinition[] = [
      Object.freeze({ version: 1, stores: Object.freeze({ metadata: '&key' }) }),
      Object.freeze({
        version: 2,
        stores: Object.freeze({ metadata: '&key,updatedAt' }),
        upgrade: (transaction) => transaction.table('metadata').toCollection().modify((record) => {
          if (typeof record.updatedAt !== 'string') {
            record.updatedAt = '2026-08-31T07:00:00.000Z';
          }
        }),
      }),
    ];

    const upgradedDb = new Dexie(name);
    registerKairosMigrations(upgradedDb, syntheticMigrations, 2);
    await upgradedDb.open();

    await expect(upgradedDb.table('metadata').get('fixture')).resolves.toEqual({
      key: 'fixture',
      value: 'legacy',
      updatedAt: '2026-08-31T07:00:00.000Z',
    });
    expect(upgradedDb.verno).toBe(2);
    expect(upgradedDb.table('metadata').schema.indexes.map((index) => index.name)).toContain('updatedAt');

    upgradedDb.close();
    const reloadedDb = new Dexie(name);
    registerKairosMigrations(reloadedDb, syntheticMigrations, 2);
    await reloadedDb.open();
    await expect(reloadedDb.table('metadata').get('fixture')).resolves.toMatchObject({
      key: 'fixture',
      value: 'legacy',
      updatedAt: '2026-08-31T07:00:00.000Z',
    });
    reloadedDb.close();
  });
});
