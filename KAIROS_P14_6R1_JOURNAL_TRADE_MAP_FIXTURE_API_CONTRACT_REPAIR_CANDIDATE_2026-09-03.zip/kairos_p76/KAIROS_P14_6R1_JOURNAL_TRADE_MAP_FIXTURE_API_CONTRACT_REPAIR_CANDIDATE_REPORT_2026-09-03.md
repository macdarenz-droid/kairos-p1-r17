# KAIROS P14.6R1 — Journal Trade Map Fixture/API Contract Repair

## Patch / Base / Identity
- Patch: P14.6R1
- Base: canonical P14.5R2 (Run #111, gate SHA c55269542c49848f99e445cfcc1f016eaa30cdaf)
- Repairs failed P14.6 Run #112 / job 100288870570.
- Candidate: KAIROS_P14_6R1_JOURNAL_TRADE_MAP_FIXTURE_API_CONTRACT_REPAIR_CANDIDATE_2026-09-03.zip

## OBJECTIVE
Repair only the P14.6 runtime-test fixture/API contract that prevented TypeScript compilation. Preserve P14.6 production marker semantics unchanged.

## FAILURE EVIDENCE
Canonical P14.6 Run #112 reached deterministic install and failed at Build. The new test imported a non-existent `src/application/journal-history` module and passed string arguments into the zero-argument branded-ID factory.

## OWNER TRACE
JournalHistoryEntry remains owned by `src/application/journal`. Branded IDs remain created through `createTradeDomainId<T>()`; DecimalString fixtures remain created through `parseDecimalString`. No production owner changes.

## CHANGE
- Correct test import to `../src/application/journal`.
- Use zero-argument `createTradeDomainId<TradeId | TradePlanId | TradeExecutionId>()`.
- Use authoritative fixture fields: `marketType`, `source`, plan `id`, execution `type`, `fees`, metrics fields, and `visualPnl`.
- Parse fixture financial strings through the existing DecimalString parser.
- Production SVG, CSS, verifier logic, and package script remain the P14.6 behavior.

## NON-SCOPE
No production behavior expansion, price scaling, numeric geometry, candles, live/current price, market data, P&L, FX, persistence, network, animation, canvas, or P15+ work.

## DATA / STATE FLOW
Read-only. Marker kind continues to derive from existing `TradeVisualizerLevel.kind`.

## PERSISTENCE / SECURITY / THEME / OFFLINE
Unchanged from P14.6: no writes, no secrets, no network; semantic theme tokens only; offline-safe.

## TESTS
- P14.6 static verifier.
- Corrected P14.6 runtime marker-semantics fixture.
- Historical P14.5/P14.4/P14.3/P14.2/P14.1 and earlier regressions remain required by canonical gate.

## PERFORMANCE
Unchanged: O(level count), no observers/timers/DB/network work.

## KNOWN LIMITATIONS
Trade map remains deliberately categorical and explicitly not to scale.

## REAL-DEVICE STATUS
Not proven in this environment.

## RESULT
HOLD pending canonical GitHub gate.
