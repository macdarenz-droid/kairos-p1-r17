# Analysis saved-trade overlay runtime input composition

Date: 15 September 2026
Roadmap status: P21 item 5 bounded amendment
UI visible: no

## Purpose

Compose the released Gate462 theme style source and Gate463
caller-authoritative snapshot extent projection into Gate461's unmounted
saved-trade overlay live-candle boundary.

The shared Gate459 renderer factory remains available before history exists so
the released live-candle owner can acquire and publish its authoritative page.
Only Risk/Reward projection waits for an exact accepted extent. Marker
projection continues to consume that same exact snapshot independently.

## Ownership and behavior

- Gate460 still owns one shared overlay presentation session per mounted hook.
- A null extent is explicit pending evidence. It suppresses only
  presentRiskReward; it does not suppress the existing renderer factory or
  create a replacement renderer/session.
- Gate461 now derives style only through
  createAnalysisSavedTradeRiskRewardThemeStyleSource(themeId).
- Gate461 delegates the exact live snapshot and selected venue/symbol/interval
  through projectAnalysisSavedTradeRiskRewardSnapshotExtent.
- Only extent-ready evidence reaches Gate460. Unavailable or mismatched
  snapshot evidence supplies null extent and cannot create Risk/Reward
  presentation.
- Selection/revision replacement still clears stale snapshot eligibility.

## Exclusions

No route or workspace import, visible UI, second history request, transport or
provider owner, scale/Canvas duplication, candle-price inspection, P18
interaction, P20 persistence, journal mutation, financial arithmetic,
normalization, or execution, venue, FX or P&L inference is introduced.
P14/P17/P18/P19/P20 ownership remains unchanged.

## Verification

- dedicated runtime-input composition verifier
- released Gate461 and Gate460 owner verifiers
- focused overlay, extent, theme, marker and Risk/Reward regressions
- TypeScript compilation and production build
- full unit regression
- fresh-archive install, focused verification, root/path safety and ZIP integrity

