import { readFileSync } from 'node:fs';

const route = readFileSync('src/app/JournalRoute.tsx', 'utf8');
const child = readFileSync('src/app/JournalDailyResults.tsx', 'utf8');
const tests = readFileSync('tests/journal-daily-results-boundary.test.tsx', 'utf8');

function requireText(text, value, label) {
  if (!text.includes(value)) throw new Error(`P13.11R1 missing ${label}: ${value}`);
}

requireText(route, "import { JournalDailyResults } from './JournalDailyResults';", 'neutral P13 child import');
requireText(route, '<JournalDailyResults db={db} refreshRevision={journalRevision} />', 'child composition');
requireText(route, 'setJournalRevision((current) => current + 1);', 'post-success child refresh signal');

// This exact P10 validation-field address carries no calculated result.
const routeWithoutCurrencyFieldAddress = route.replaceAll("'grossPnlCurrency'", "''");
if (/profit|loss|riskReward|leverage|pnl/i.test(routeWithoutCurrencyFieldAddress) || /domain\/calculations|decimal\.js|calculateTradeMetrics|parseFloat\s*\(|Number\s*\(/.test(route)) {
  throw new Error('P13.11R1 rejected P13 calculation-derived ownership leak in historical JournalRoute');
}

requireText(child, 'readVisualPnlTimeZonePreference(repositories.metadata)', 'P13.10R1 preference reuse');
requireText(child, 'listJournalVisualPnlDailySummary(db, timeZone)', 'P13.8 query reuse');
requireText(child, '<VisualPnlCalendar projection={state.projection} />', 'P13.9 presentation reuse');
requireText(child, 'let ignore = false;', 'stale async result guard');
requireText(child, 'ignore = true;', 'effect cleanup');
requireText(child, 'Choose a time zone in Settings to view daily results.', 'explicit unconfigured state');

for (const forbidden of [
  'resolvedOptions().timeZone',
  'getTimezoneOffset',
  'decimalSum',
  'decimalAdd',
  'parseFloat',
  'exchangeRate',
  'indexedDB.',
]) {
  if (child.includes(forbidden)) {
    throw new Error(`P13.11R1 rejected duplicate/fallback owner in child surface: ${forbidden}`);
  }
}

requireText(tests, "'Australia/Sydney'", 'Sydney regression');
requireText(tests, "'UTC'", 'UTC regression');
requireText(tests, "queryByText('03/09/2026')", 'day-policy distinction');

console.log('PASS P13.11R1 Journal daily-results child-boundary verifier');
