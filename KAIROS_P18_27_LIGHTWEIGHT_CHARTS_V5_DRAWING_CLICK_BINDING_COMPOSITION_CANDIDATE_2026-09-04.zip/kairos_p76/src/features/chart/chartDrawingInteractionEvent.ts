import type { ChartDrawingId, ChartDrawingKind } from './chartDrawingContract';

/**
 * P18.22 provider-neutral drawing interaction event vocabulary.
 *
 * Events describe one interaction intent/evidence item at a time. They do not
 * decide whether a transition is valid and they do not mutate drawing truth.
 * Transition acceptance remains a later reducer responsibility.
 */
export type ChartDrawingInteractionEvent =
  | { readonly type: 'select-tool'; readonly tool: ChartDrawingKind }
  | { readonly type: 'start-drawing' }
  | { readonly type: 'preview-drawing' }
  | { readonly type: 'commit-drawing'; readonly drawingId: ChartDrawingId }
  | { readonly type: 'cancel-interaction' }
  | { readonly type: 'start-editing'; readonly drawingId: ChartDrawingId }
  | { readonly type: 'start-deleting'; readonly drawingId: ChartDrawingId }
  | { readonly type: 'reset-interaction' };

export function defineChartDrawingInteractionEvent(
  event: ChartDrawingInteractionEvent,
): ChartDrawingInteractionEvent {
  return event;
}
