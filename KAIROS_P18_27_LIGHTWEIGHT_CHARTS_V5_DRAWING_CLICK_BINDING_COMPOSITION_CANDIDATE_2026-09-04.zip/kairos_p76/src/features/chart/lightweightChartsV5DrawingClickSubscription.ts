import type { ChartDrawingAnchor } from './chartDrawingContract';
import {
  projectLightweightChartsV5DrawingAnchor,
  type LightweightChartsV5DrawingAnchorEvent,
  type LightweightChartsV5DrawingAnchorPriceApi,
} from './lightweightChartsV5DrawingAnchorProjection';

export type LightweightChartsV5DrawingClickEventHandler = (
  event: LightweightChartsV5DrawingAnchorEvent,
) => void;

export interface LightweightChartsV5DrawingClickChartApi {
  subscribeClick(handler: LightweightChartsV5DrawingClickEventHandler): void;
  unsubscribeClick(handler: LightweightChartsV5DrawingClickEventHandler): void;
}

export interface LightweightChartsV5DrawingClickSubscription {
  destroy(): void;
}

/**
 * P18.26 Lightweight Charts v5 drawing-click subscription lifecycle.
 *
 * This boundary owns only provider subscribeClick/unsubscribeClick lifecycle.
 * P18.25R1 remains the sole provider event-point -> Kairos drawing-anchor
 * projection owner. Every provider click emits either that projected anchor or
 * null when the event does not contain sufficient drawing-anchor evidence.
 *
 * destroy() unsubscribes the exact registered handler once and is idempotent.
 * This boundary owns no interaction dispatch, anchor-pair collection, drawing
 * mutation, persistence, toolbar state, drag/edit behavior, journal truth, or
 * P19 Risk/Reward behavior.
 */
export function createLightweightChartsV5DrawingClickSubscription(
  chart: LightweightChartsV5DrawingClickChartApi,
  series: LightweightChartsV5DrawingAnchorPriceApi,
  onAnchor: (anchor: ChartDrawingAnchor | null) => void,
): LightweightChartsV5DrawingClickSubscription {
  let destroyed = false;

  const handleClick: LightweightChartsV5DrawingClickEventHandler = (event) => {
    if (destroyed) return;
    onAnchor(projectLightweightChartsV5DrawingAnchor(event, series));
  };

  chart.subscribeClick(handleClick);

  return {
    destroy(): void {
      if (destroyed) return;
      destroyed = true;
      chart.unsubscribeClick(handleClick);
    },
  };
}
