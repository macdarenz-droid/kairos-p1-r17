import type { ChartDrawingId, ChartDrawingKind } from './chartDrawingContract';

/**
 * P18.21 provider-neutral drawing interaction-state vocabulary.
 *
 * This contract intentionally models interaction state as one discriminated
 * union instead of independent flags that can contradict each other.
 * Transition ownership is deliberately deferred to a later controlled reducer
 * slice; this file owns state shape only.
 */
export type ChartDrawingInteractionStatus =
  | 'idle'
  | 'tool-selected'
  | 'drawing'
  | 'preview'
  | 'committed'
  | 'cancelled'
  | 'editing'
  | 'deleting';

export type ChartDrawingInteractionState =
  | { readonly status: 'idle' }
  | { readonly status: 'tool-selected'; readonly tool: ChartDrawingKind }
  | { readonly status: 'drawing'; readonly tool: ChartDrawingKind }
  | { readonly status: 'preview'; readonly tool: ChartDrawingKind }
  | { readonly status: 'committed'; readonly drawingId: ChartDrawingId }
  | { readonly status: 'cancelled' }
  | { readonly status: 'editing'; readonly drawingId: ChartDrawingId }
  | { readonly status: 'deleting'; readonly drawingId: ChartDrawingId };

export const INITIAL_CHART_DRAWING_INTERACTION_STATE: ChartDrawingInteractionState = {
  status: 'idle',
};

export function defineChartDrawingInteractionState(
  state: ChartDrawingInteractionState,
): ChartDrawingInteractionState {
  return state;
}
