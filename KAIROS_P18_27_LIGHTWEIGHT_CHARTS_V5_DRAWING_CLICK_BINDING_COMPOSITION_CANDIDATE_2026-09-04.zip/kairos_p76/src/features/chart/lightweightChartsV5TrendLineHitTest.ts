import type { LightweightChartsV5TrendLineScreenSegment } from './lightweightChartsV5TrendLineCoordinateProjection';

export interface LightweightChartsV5TrendLineHit {
  readonly id: string;
  readonly kind: 'trend-line';
  readonly cursorStyle: 'pointer';
}

function squaredDistanceToSegment(
  x: number,
  y: number,
  segment: LightweightChartsV5TrendLineScreenSegment,
): number {
  const dx = segment.end.x - segment.start.x;
  const dy = segment.end.y - segment.start.y;
  if (dx === 0 && dy === 0) {
    const px = x - segment.start.x;
    const py = y - segment.start.y;
    return px * px + py * py;
  }
  const t = Math.max(0, Math.min(1, ((x - segment.start.x) * dx + (y - segment.start.y) * dy) / (dx * dx + dy * dy)));
  const nearestX = segment.start.x + t * dx;
  const nearestY = segment.start.y + t * dy;
  const px = x - nearestX;
  const py = y - nearestY;
  return px * px + py * py;
}

/**
 * P18.12 provider hit-test geometry invariant:
 * - P18.5 projected screen segments remain the geometry owner
 * - this function only answers whether a screen point is within a presentation tolerance
 * - reverse iteration makes the visually latest segment the top-most hit
 * - no pointer subscription, selection, drag/edit, drawing truth mutation, persistence,
 *   autoscale, calculations, market acquisition, journal truth, toolbar, or P19 behavior lives here
 */
export function hitTestLightweightChartsV5TrendLineSegments(
  segments: readonly LightweightChartsV5TrendLineScreenSegment[],
  x: number,
  y: number,
  tolerancePx: number,
): LightweightChartsV5TrendLineHit | null {
  if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(tolerancePx) || tolerancePx < 0) {
    throw new Error('chart-drawing-hit-test-invalid-input');
  }
  const toleranceSquared = tolerancePx * tolerancePx;
  for (let index = segments.length - 1; index >= 0; index -= 1) {
    const segment = segments[index];
    if (squaredDistanceToSegment(x, y, segment) <= toleranceSquared) {
      return { id: segment.id, kind: 'trend-line', cursorStyle: 'pointer' };
    }
  }
  return null;
}
