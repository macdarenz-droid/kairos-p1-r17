# KAIROS P15.13 — Market Data Reconnect Execution Semantics

## BASE
P15.12 canonical PASS — Run #140.

## OBJECTIVE
Compose the accepted P15.12 reconnect attempt with the existing P15.6 one-shot scheduler, without introducing provider transport, concrete timers, entropy acquisition, or a multi-attempt loop.

## RESEARCH
AWS retry guidance recommends bounded backoff for transient failures and fail-fast treatment for non-transient failures. AWS also recommends selecting one retry layer and limiting retries. MDN confirms WebSocket connection failures ultimately produce close handling, while CloseEvent facts remain transport-specific. Therefore this slice schedules only an already-normalized, already-planned accepted retry.

## OWNER TRACE
P15.10 normalized reconnect eligibility.
P15.11 pre-planning intent.
P15.12 accepted/stop/invalid attempt planning.
P15.6 one-shot scheduling/cancellation.
P15.13 composes P15.12 accepted retry with P15.6 scheduling.

## CHANGE
`executeMarketDataReconnectAttempt(...)`:
- stop/invalid results return without scheduling;
- accepted retry schedules exactly the P15.12/P15.8 planned delay;
- cancellation remains owned by P15.6;
- AbortSignal is forwarded, not duplicated.

## NON-SCOPE
No provider/API.
No WebSocket/CloseEvent interpretation.
No concrete timer.
No entropy acquisition.
No multi-attempt reconnect loop.
No connection-state mutation.
No persistence.
No UI/chart.
No financial/execution truth mutation.
No secrets.

## RESULT
HOLD pending canonical GitHub gate.
