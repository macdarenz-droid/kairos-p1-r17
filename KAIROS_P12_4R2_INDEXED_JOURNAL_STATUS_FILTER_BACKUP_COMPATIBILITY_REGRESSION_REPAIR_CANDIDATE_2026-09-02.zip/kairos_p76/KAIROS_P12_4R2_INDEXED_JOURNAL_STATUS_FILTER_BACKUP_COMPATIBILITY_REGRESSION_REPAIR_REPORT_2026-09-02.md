# KAIROS P12.4R2 — Indexed Journal Status Filter Backup Compatibility Regression Repair
Date: 2026-09-02

## Base
Exact canonical PASS base: P12.3R1.

## Scope
Carries forward the P12.4 indexed status-filter foundation and the P12.4R1 backup/schema compatibility implementation, with only the three canonical regression repairs identified by GitHub run #59.

## Repairs
1. Current database lifecycle assertion now expects schemaVersion 3.
2. Legacy V1 backup migration expectation remains historically truthful at databaseSchemaVersion 2 while backup format remains V2.
3. Migration-sequence negative coverage now constructs a genuinely reordered/mismatched sequence instead of expecting the valid v1,v2,v3 sequence to fail.

## Invariants preserved
- Backup format remains V2.
- Existing schema-v2 backups remain accepted.
- New/current snapshots use schema v3.
- Legacy V1→V2 migration semantics remain unchanged.
- No validator weakening.
- Indexed [status+updatedAt] bounded query remains the sole status-filter path.
- No UI filtering and no P13 work.

## Local verification
Static P1/P12 ownership, bounded-query, route/accessibility, P12.4 status-index, P12.4R1 backup-compatibility, and P12.4R2 regression-repair checks passed where locally executable.
Full dependency-backed build/unit regression remains authoritative in canonical GitHub Actions.
