import type { LiveMarketSummaryBaselineAcquisitionPort } from '../../LiveMarketSummaryBaselineAcquisitionPort';
import { validateLiveMarketSummaryBaselineSuccess } from '../../liveMarketSummaryBaselineAcquisitionSemantics';
import {
  composeBinanceSpot24hPublicRestBaselineRoundTrip,
} from './binanceSpot24hPublicRestBaselineRoundTrip';
import type {
  BinanceSpot24hPublicRestBaselineRequestConnector,
} from './binanceSpot24hPublicRestBaselineRequestExecution';

/**
 * Caller-owned observation-time dependency. The adapter reads it once per
 * baseline acquisition and does not own clock, freshness, or timestamp policy.
 */
export type BinanceSpot24hPublicRestBaselineObservedAtSource = () => string;

/**
 * Concrete Binance composition for the provider-neutral P21.4 baseline port.
 * Network transport remains injected. P21.12 caller cancellation is forwarded
 * unchanged through the existing round-trip seam.
 */
export function createBinanceSpot24hPublicRestBaselineAcquisitionPort(
  connect: BinanceSpot24hPublicRestBaselineRequestConnector<unknown>,
  readObservedAt: BinanceSpot24hPublicRestBaselineObservedAtSource,
): LiveMarketSummaryBaselineAcquisitionPort {
  return {
    async acquireBaseline(scope, options) {
      try {
        const result = await composeBinanceSpot24hPublicRestBaselineRoundTrip(
          scope,
          readObservedAt(),
          connect,
          options,
        );
        if (!result.ok) return { ok: false, reason: 'acquisition-failed' };
        const validated = validateLiveMarketSummaryBaselineSuccess(scope, result.delivery);
        if (!validated.ok) return { ok: false, reason: 'acquisition-failed' };
        return { ok: true, delivery: validated.delivery };
      } catch {
        return { ok: false, reason: 'acquisition-failed' };
      }
    },
  };
}
