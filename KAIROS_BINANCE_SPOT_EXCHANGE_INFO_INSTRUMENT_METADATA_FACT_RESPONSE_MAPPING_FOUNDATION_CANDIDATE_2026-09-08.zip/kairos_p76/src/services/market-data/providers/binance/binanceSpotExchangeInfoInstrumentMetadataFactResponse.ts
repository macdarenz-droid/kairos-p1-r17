import type { LiveMarketUniverseInstrumentMetadataFact } from '../../liveMarketUniverseInstrumentMetadataFact';
import {
  mapBinanceSpotExchangeInfoInstrumentMetadataFactCollection,
  type BinanceSpotExchangeInfoInstrumentMetadataFactCollectionResult,
} from './binanceSpotExchangeInfoInstrumentMetadataFactCollection';

export type BinanceSpotExchangeInfoInstrumentMetadataFactResponseResult =
  | { readonly ok: true; readonly facts: readonly LiveMarketUniverseInstrumentMetadataFact[] }
  | { readonly ok: false; readonly reason: 'response-invalid' }
  | Extract<BinanceSpotExchangeInfoInstrumentMetadataFactCollectionResult, { readonly ok: false }>;

type UnknownRecord = Readonly<Record<string, unknown>>;

function isRecord(value: unknown): value is UnknownRecord {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/**
 * Extracts the explicit `symbols` collection from one whole already-decoded
 * Binance Spot exchangeInfo response object and delegates the collection
 * unchanged to the released collection mapper. Universe policy remains outside.
 */
export function mapBinanceSpotExchangeInfoInstrumentMetadataFactResponse(
  payload: unknown,
): BinanceSpotExchangeInfoInstrumentMetadataFactResponseResult {
  if (!isRecord(payload)) return { ok: false, reason: 'response-invalid' };

  return mapBinanceSpotExchangeInfoInstrumentMetadataFactCollection(payload.symbols);
}
