import { KAIROS_BACKUP_FORMAT_NAME, KAIROS_BACKUP_FORMAT_VERSION, type KairosBackupEnvelope, type KairosBackupEnvelopeV3 } from './backupFormat';
import { KairosBackupValidationError, validateKairosBackupEnvelope } from './backupValidation';
function migrateToCurrent(envelope:KairosBackupEnvelope):KairosBackupEnvelopeV3 {
 if(envelope.formatVersion===KAIROS_BACKUP_FORMAT_VERSION)return envelope;
 const metadata=envelope.payload.metadata.map(record=>({...record}));
 const base=envelope.formatVersion===2?envelope.payload:{metadata,trades:[],tradePlans:[],tradeExecutions:[],tradeFees:[]};
 const payload=Object.freeze({metadata:Object.freeze(metadata),trades:Object.freeze(base.trades.map(record=>({...record}))),tradePlans:Object.freeze(base.tradePlans.map(record=>({...record}))),tradeExecutions:Object.freeze(base.tradeExecutions.map(record=>({...record}))),tradeFees:Object.freeze(base.tradeFees.map(record=>({...record}))),savedAnalyses:Object.freeze([])});
 return Object.freeze({formatName:KAIROS_BACKUP_FORMAT_NAME,formatVersion:3,appVersion:envelope.appVersion,buildId:envelope.buildId,exportedAt:envelope.exportedAt,databaseSchemaVersion:4,recordCounts:Object.freeze({metadata:payload.metadata.length,trades:payload.trades.length,tradePlans:payload.tradePlans.length,tradeExecutions:payload.tradeExecutions.length,tradeFees:payload.tradeFees.length,savedAnalyses:0,total:payload.metadata.length+payload.trades.length+payload.tradePlans.length+payload.tradeExecutions.length+payload.tradeFees.length}),payload});
}
export function serializeKairosBackup(envelope:KairosBackupEnvelope):string{validateKairosBackupEnvelope(envelope);return JSON.stringify(envelope);}
export function parseKairosBackup(serialized:string):KairosBackupEnvelopeV3{let parsed:unknown;try{parsed=JSON.parse(serialized)}catch{throw new KairosBackupValidationError('INVALID_JSON','Backup is not valid JSON.')}const validated=validateKairosBackupEnvelope(parsed);const migrated=migrateToCurrent(validated);return validateKairosBackupEnvelope(migrated) as KairosBackupEnvelopeV3;}
