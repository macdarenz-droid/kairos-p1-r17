import type { SavedAnalysis } from '../../app/savedAnalysisContract';
import type { TradeExecutionRecord, TradeFeeRecord, TradePlanRecord, TradeRecord } from '../../domain/trades';

export const KAIROS_DATABASE_NAME = 'kairos';
export const KAIROS_DB_SCHEMA_VERSION = 4 as const;

/** Immutable released V1 contract. Never edit. */
export const KAIROS_V1_STORES = Object.freeze({
  metadata: '&key',
});

/** V2 appends the first roadmap-owned trade persistence stores. */
export const KAIROS_V2_STORES = Object.freeze({
  metadata: '&key',
  trades: '&id,status,symbol,updatedAt',
  tradePlans: '&id,tradeId,updatedAt',
  tradeExecutions: '&id,tradeId,type,executedAt',
  tradeFees: '&id,tradeId,executionId',
});


/** V3 adds an indexed newest-first status history access path without changing stored trade records. */
export const KAIROS_V3_STORES = Object.freeze({
  trades: '&id,status,symbol,updatedAt,[status+updatedAt]',
});

/** V4 appends Saved Analysis persistence without rewriting released history. */
export const KAIROS_V4_STORES = Object.freeze({
  savedAnalyses: '&id',
});

/** Current complete store authority used by transactions/integrity only. */
export const KAIROS_CURRENT_STORES = Object.freeze({
  ...KAIROS_V2_STORES,
  ...KAIROS_V3_STORES,
  ...KAIROS_V4_STORES,
});

export interface DatabaseMetadataRecord {
  readonly key: string;
  readonly value: string;
  readonly updatedAt: string;
}

export type DatabaseTradeRecord = TradeRecord;
export type DatabaseTradePlanRecord = TradePlanRecord;
export type DatabaseTradeExecutionRecord = TradeExecutionRecord;
export type DatabaseTradeFeeRecord = TradeFeeRecord;

export type DatabaseSavedAnalysisRecord = SavedAnalysis;
