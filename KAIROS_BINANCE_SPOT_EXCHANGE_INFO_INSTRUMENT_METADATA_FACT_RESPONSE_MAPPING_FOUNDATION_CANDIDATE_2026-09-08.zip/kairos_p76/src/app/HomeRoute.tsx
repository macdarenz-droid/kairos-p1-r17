export function HomeRoute() {
  return (
    <section className="kairos-route" aria-labelledby="kairos-route-home" data-kairos-home-dashboard="foundation">
      <header>
        <h1 id="kairos-route-home">Home</h1>
        <p>Your Kairos dashboard lives here.</p>
      </header>
      <section aria-labelledby="kairos-home-dashboard-heading">
        <h2 id="kairos-home-dashboard-heading">Dashboard</h2>
        <p>No dashboard insights are connected yet.</p>
      </section>
    </section>
  );
}
