import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hPublicRestBaselineRequestExecution.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_8_BINANCE_SPOT_24H_PUBLIC_REST_BASELINE_REQUEST_EXECUTION_BOUNDARY_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');
for (const token of [
  'BinanceSpot24hPublicRestBaselineRequestConnector<TResult>',
  'executeBinanceSpot24hPublicRestBaselineRequest<TResult>',
  'return connect(request);',
  'BinanceSpot24hPublicRestBaselineRequestDescriptor',
]) if (!source.includes(token)) throw new Error(`P21.8 execution-boundary evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpot24hPublicRestBaselineRequestExecution';")) throw new Error('P21.8 barrel export missing');
for (const forbidden of ['fetch(', 'XMLHttpRequest', 'WebSocket(', 'JSON.parse(', 'indexedDB', 'acquireBaseline(', 'setTimeout(', 'requestWeight']) {
  if (source.includes(forbidden)) throw new Error(`P21.8 broadened into forbidden scope: ${forbidden}`);
}
for (const token of ['No fetch/XHR/WebSocket/browser transport', 'No JSON/text/binary response decoding', 'No scope selection', 'No concrete P21.4 acquisition-port adapter orchestration', 'No Bubble Map sizing', 'No persistence']) {
  if (!report.includes(token)) throw new Error(`P21.8 report evidence missing: ${token}`);
}
console.log('P21.8 Binance Spot 24h public REST baseline request execution boundary verification passed.');
