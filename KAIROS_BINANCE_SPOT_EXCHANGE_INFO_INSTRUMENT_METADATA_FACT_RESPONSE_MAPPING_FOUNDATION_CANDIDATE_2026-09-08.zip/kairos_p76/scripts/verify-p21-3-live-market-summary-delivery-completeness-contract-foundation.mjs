import { readFileSync } from 'node:fs';

const types = readFileSync(new URL('../src/services/market-data/marketDataTypes.ts', import.meta.url), 'utf8');
const semantics = readFileSync(new URL('../src/services/market-data/liveMarketSummaryDeliverySemantics.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_3_LIVE_MARKET_SUMMARY_DELIVERY_COMPLETENESS_CONTRACT_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');

for (const token of [
  'export interface LiveMarketSummaryIncrementalDelivery',
  "readonly completeness: 'incremental';",
  'export interface LiveMarketSummaryCompleteForScopeDelivery',
  "readonly completeness: 'complete-for-scope';",
  'readonly scope: readonly MarketDataInstrument[];',
  'export type LiveMarketSummaryDelivery =',
]) if (!types.includes(token)) throw new Error(`P21.3 delivery contract evidence missing: ${token}`);

for (const token of [
  'export function validateLiveMarketSummaryDelivery(',
  "'scope-fact-missing'",
  "'fact-outside-scope'",
  "'fact-instrument-duplicate'",
]) if (!semantics.includes(token)) throw new Error(`P21.3 validation evidence missing: ${token}`);

if (!index.includes("export * from './liveMarketSummaryDeliverySemantics';")) throw new Error('P21.3 market-data export missing');

for (const forbidden of [
  'fetch(', 'WebSocket', 'EventSource', 'indexedDB', 'createChart(', 'bubbleSize', 'marketCap', 'setInterval(', 'setTimeout(',
]) if (semantics.includes(forbidden)) throw new Error(`P21.3 delivery semantics broadened into forbidden scope: ${forbidden}`);

for (const token of [
  '# KAIROS P21.3 — Live Market Summary Delivery Completeness Contract Foundation',
  'incremental',
  'complete-for-scope',
  'No Binance REST-vs-WebSocket choice',
  'No market-universe selection policy',
  'No Bubble Map size metric',
  'No journal/trade-history reads',
]) if (!report.includes(token)) throw new Error(`P21.3 report evidence missing: ${token}`);

console.log('P21.3 Live Market Summary delivery completeness contract verification passed.');
