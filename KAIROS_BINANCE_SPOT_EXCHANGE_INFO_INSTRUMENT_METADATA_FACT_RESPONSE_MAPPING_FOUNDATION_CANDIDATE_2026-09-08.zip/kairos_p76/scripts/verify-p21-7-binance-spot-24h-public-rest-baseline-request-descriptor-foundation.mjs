import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hPublicRestBaselineRequest.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_7_BINANCE_SPOT_24H_PUBLIC_REST_BASELINE_REQUEST_DESCRIPTOR_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');
for (const token of [
  "'https://data-api.binance.vision'",
  "'/api/v3/ticker/24hr'",
  "'FULL'",
  'describeBinanceSpot24hPublicRestBaselineRequest(',
  "symbols=${encodeURIComponent(JSON.stringify(symbols))}",
  'BINANCE_SPOT_VENUE',
]) if (!source.includes(token)) throw new Error(`P21.7 descriptor evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpot24hPublicRestBaselineRequest';")) throw new Error('P21.7 barrel export missing');
for (const forbidden of ['fetch(', 'XMLHttpRequest', 'WebSocket(', 'indexedDB', 'acquireBaseline(', 'setTimeout(', 'retry', 'backoff', 'requestWeight']) {
  if (source.includes(forbidden)) throw new Error(`P21.7 broadened into forbidden scope: ${forbidden}`);
}
for (const token of ['No fetch/XHR/WebSocket/browser transport', 'No multi-request batching/chunking', 'No credentials', 'No market-universe selection/ranking', 'No Bubble Map sizing', 'No persistence']) {
  if (!report.includes(token)) throw new Error(`P21.7 report evidence missing: ${token}`);
}
console.log('P21.7 Binance Spot 24h public REST baseline request descriptor verification passed.');
