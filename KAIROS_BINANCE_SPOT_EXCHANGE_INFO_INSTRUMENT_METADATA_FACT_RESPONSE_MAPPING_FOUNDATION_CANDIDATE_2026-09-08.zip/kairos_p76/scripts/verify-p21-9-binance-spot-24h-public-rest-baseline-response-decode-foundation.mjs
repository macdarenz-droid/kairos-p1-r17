import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hPublicRestBaselineResponseDecode.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_9_BINANCE_SPOT_24H_PUBLIC_REST_BASELINE_RESPONSE_DECODE_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');
for (const token of [
  'BinanceSpot24hPublicRestBaselineResponseDecodeResult',
  'decodeBinanceSpot24hPublicRestBaselineResponse',
  "typeof data !== 'string'",
  'JSON.parse(data)',
  "'unsupported-response-data'",
  "'invalid-json'",
]) if (!source.includes(token)) throw new Error(`P21.9 response-decode evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpot24hPublicRestBaselineResponseDecode';")) throw new Error('P21.9 barrel export missing');
for (const forbidden of ['fetch(', 'XMLHttpRequest', 'WebSocket(', 'new Response(', '.json(', 'acquireBaseline(', 'mapBinanceSpot24hBaselineDelivery(', 'indexedDB', 'setTimeout(', 'requestWeight']) {
  if (source.includes(forbidden)) throw new Error(`P21.9 broadened into forbidden scope: ${forbidden}`);
}
for (const token of ['No fetch/XHR/WebSocket/browser transport', 'No provider ticker-field validation', 'No scope/universe selection', 'No concrete P21.4 acquisition-port adapter orchestration', 'decoded array order is not ranking/universe truth', 'No persistence']) {
  if (!report.includes(token)) throw new Error(`P21.9 report evidence missing: ${token}`);
}
console.log('P21.9 Binance Spot 24h public REST baseline response decode verification passed.');
