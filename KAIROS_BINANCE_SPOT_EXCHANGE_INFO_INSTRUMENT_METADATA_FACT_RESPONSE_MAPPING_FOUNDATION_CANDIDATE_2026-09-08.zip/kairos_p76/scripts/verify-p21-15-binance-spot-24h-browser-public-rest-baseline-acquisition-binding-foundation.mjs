import { readFileSync } from 'node:fs';
const binding = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hBrowserPublicRestBaselineAcquisitionBinding.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_15_BINANCE_SPOT_24H_BROWSER_PUBLIC_REST_BASELINE_ACQUISITION_BINDING_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');
for (const token of [
  'createBinanceSpot24hBrowserPublicRestBaselineAcquisitionPort(',
  'LiveMarketSummaryBaselineAcquisitionPort',
  'createBinanceSpot24hPublicRestBaselineAcquisitionPort(',
  'connectBinanceSpot24hBrowserPublicRestBaselineRequest,',
  'readObservedAt,',
]) if (!binding.includes(token)) throw new Error(`P21.15 binding evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpot24hBrowserPublicRestBaselineAcquisitionBinding';")) throw new Error('P21.15 binding export missing');
for (const forbidden of [
  'globalThis.fetch(', 'fetch(', 'XMLHttpRequest', 'WebSocket(', 'Response(', 'JSON.parse(',
  'Date.now(', 'new Date(', 'new AbortController(', 'AbortSignal.any(', 'AbortSignal.timeout(',
  'setTimeout(', 'setInterval(', 'indexedDB', 'createChart(',
]) if (binding.includes(forbidden)) throw new Error(`P21.15 broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'Canonical P21.13 implements the provider-neutral P21.4 baseline acquisition port',
  'Canonical P21.14 supplies the missing concrete browser P21.8 connector',
  'Existing P16.16 demonstrates the released project pattern for a narrow browser-ready provider entry point',
  'Keep `readObservedAt` mandatory and externally supplied',
  'No `Date.now`, `new Date`',
  'No Live Crypto Bubble Map sizing',
  'No Your Trades Bubble Map',
]) if (!report.includes(token)) throw new Error(`P21.15 report evidence missing: ${token}`);
console.log('P21.15 Binance Spot browser baseline acquisition binding verification passed.');
