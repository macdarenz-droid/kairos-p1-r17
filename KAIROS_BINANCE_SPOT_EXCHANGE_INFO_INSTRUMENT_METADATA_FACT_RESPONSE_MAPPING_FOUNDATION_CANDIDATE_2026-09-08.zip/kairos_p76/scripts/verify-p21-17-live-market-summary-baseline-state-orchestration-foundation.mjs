import { readFileSync } from 'node:fs';
const orchestration = readFileSync(new URL('../src/services/market-data/liveMarketSummaryBaselineStateOrchestration.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_17_LIVE_MARKET_SUMMARY_BASELINE_STATE_ORCHESTRATION_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');
for (const token of [
  'acquireLiveMarketSummaryBaselineIntoState(',
  'LiveMarketSummaryBaselineAcquisitionPort',
  'LiveMarketSummaryDeliveryState',
  'acquisitionPort.acquireBaseline(scope)',
  'acquisitionPort.acquireBaseline(scope, options)',
  "reason: 'acquisition-failed'",
  'applyLiveMarketSummaryDeliveryState(state, acquisition.delivery)',
  "reason: 'delivery-invalid'",
]) if (!orchestration.includes(token)) throw new Error(`P21.17 orchestration evidence missing: ${token}`);
if (!index.includes("export * from './liveMarketSummaryBaselineStateOrchestration';")) throw new Error('P21.17 orchestration export missing');
for (const forbidden of [
  'globalThis.fetch(', 'fetch(', 'XMLHttpRequest', 'WebSocket(', 'Response(', 'JSON.parse(',
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'indexedDB', '.sort(', 'createChart(',
  'createBinanceSpot24hBrowserPublicRestBaselineAcquisitionPort(',
]) if (orchestration.includes(forbidden)) throw new Error(`P21.17 broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'Canonical P21.15 exposes the browser-ready P21.4 baseline acquisition port',
  'Canonical P21.16 owns provider-neutral current-summary delivery state',
  'no production owner that composes these released seams',
  'Invoke `acquireBaseline` exactly once',
  'On `acquisition-failed`, return the exact prior state unchanged',
  'Preserve released P21.16 `delivery-invalid` semantics',
  'No market-universe/scope selection, ranking, filtering, grouping, sorting',
  'No persistence, repository/schema/backup, direct IndexedDB',
]) if (!report.includes(token)) throw new Error(`P21.17 report evidence missing: ${token}`);
console.log('P21.17 live market summary baseline state orchestration verification passed.');
