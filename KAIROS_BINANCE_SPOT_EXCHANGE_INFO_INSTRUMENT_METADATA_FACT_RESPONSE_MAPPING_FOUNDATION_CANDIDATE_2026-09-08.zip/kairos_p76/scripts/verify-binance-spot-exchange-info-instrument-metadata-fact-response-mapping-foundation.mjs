import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpotExchangeInfoInstrumentMetadataFactResponse.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_BINANCE_SPOT_EXCHANGE_INFO_INSTRUMENT_METADATA_FACT_RESPONSE_MAPPING_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');

for (const token of [
  'BinanceSpotExchangeInfoInstrumentMetadataFactResponseResult',
  'mapBinanceSpotExchangeInfoInstrumentMetadataFactResponse',
  "reason: 'response-invalid'",
  '!Array.isArray(value)',
  'mapBinanceSpotExchangeInfoInstrumentMetadataFactCollection(payload.symbols)',
]) if (!source.includes(token)) throw new Error(`exchangeInfo metadata response mapper evidence missing: ${token}`);

if (!index.includes("export * from './providers/binance/binanceSpotExchangeInfoInstrumentMetadataFactResponse';")) {
  throw new Error('exchangeInfo instrument metadata response mapper barrel export missing');
}

for (const forbidden of [
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'JSON.parse(', 'decodeBinanceSpotExchangeInfoPublicRestResponse(',
  'for (', '.filter(', '.sort(', "quoteAsset === 'USDT'", "quoteAsset !== 'USDT'", 'quoteVolume24h',
  'Top 30', 'topN', 'stablecoin', 'new Map(', 'new Set(', 'setTimeout(', 'setInterval(', 'Date.now(',
  'new Date(', 'indexedDB', 'React', 'useEffect',
]) if (source.includes(forbidden)) throw new Error(`metadata response mapper broadened into forbidden scope: ${forbidden}`);

for (const token of [
  'requires a non-null non-array object',
  "extracts only that object's `symbols` property",
  'delegates that exact value unchanged to the released `mapBinanceSpotExchangeInfoInstrumentMetadataFactCollection(...)` owner',
  'Missing or non-array `symbols` therefore remains the released `collection-invalid` result',
  'explicit empty `symbols` array remains an empty successful fact list',
  'Other exchangeInfo fields are ignored rather than interpreted here',
  'No USDT eligibility filtering or symbol-suffix inference',
  'No stablecoin exclusion',
  'No 24h quote-volume lookup, ranking/sorting, symbol tie-break, Top-N/Top-30',
  'No freshness-age/classification changes',
  'No Home React wiring',
  'No Your Trades/journal ownership',
]) if (!report.includes(token)) throw new Error(`exchangeInfo metadata response mapper report evidence missing: ${token}`);

console.log('Binance Spot exchangeInfo instrument metadata fact response mapping verification passed.');
