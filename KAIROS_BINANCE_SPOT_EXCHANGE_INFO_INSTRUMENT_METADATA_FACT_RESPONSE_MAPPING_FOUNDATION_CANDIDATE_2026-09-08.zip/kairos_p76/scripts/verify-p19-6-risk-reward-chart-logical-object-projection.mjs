import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/app/riskRewardChartObjectProjection.ts', import.meta.url), 'utf8');
const test = readFileSync(new URL('../tests/risk-reward-chart-object-projection.test.ts', import.meta.url), 'utf8');

for (const token of [
  "import type { DecimalString, TradeSide } from '../domain/trades'",
  "import type { RiskRewardChartSemantics } from '../application/risk-reward'",
  "import type { ChartTimestamp } from '../features/chart'",
  "import type { RiskRewardChartPlacementProjection } from './riskRewardChartPlacementProjection'",
  "import type { RiskRewardChartStyleProjection } from './riskRewardChartStyleProjection'",
  'export interface RiskRewardChartLogicalLevelSpan',
  "Role extends 'entry' | 'stop' | 'target'",
  "export interface RiskRewardChartLogicalZone<Role extends 'risk' | 'reward'>",
  'export interface RiskRewardChartObjectProjection',
  'export function projectRiskRewardChartObject',
  'side: semantics.side',
  'role: style.entry.role',
  'token: style.entry.token',
  'start: placement.start',
  'end: placement.end',
  'price: semantics.levels.entry.price',
  'from: semantics.zones.risk.from',
  'to: semantics.zones.reward.to',
]) {
  if (!source.includes(token)) throw new Error(`P19.6 logical object projection missing: ${token}`);
}

for (const forbidden of [
  'lightweight-charts', 'ChartDrawing', 'IndexedDB', 'Dexie', 'localStorage',
  'fetch(', 'WebSocket', 'calculateTradeMetrics', 'calculateRisk', 'calculateRMultiple',
  'Math.min', 'Math.max', 'new Date(', 'Date.parse', '.sort(', 'localeCompare(',
  'parseInt(', 'parseFloat(', 'Number(', 'document.', 'window.', '.applyOptions(',
  'addSeries(', 'createChart(', 'setData(', 'update(', 'priceToCoordinate(',
]) {
  if (source.includes(forbidden)) throw new Error(`P19.6 logical object projection owns forbidden concern: ${forbidden}`);
}
if (/(#[0-9a-fA-F]{3,8}\b|rgba?\(|hsla?\()/.test(source)) {
  throw new Error('P19.6 logical object projection hard-codes a visual color value');
}

for (const token of [
  'composes level spans from authoritative semantic prices, style roles/tokens, and logical placement',
  'composes risk/reward logical rectangles without recomputing or normalizing semantic zone bounds',
  'from: semantics.zones.risk.from',
  'to: semantics.zones.reward.to',
]) {
  if (!test.includes(token)) throw new Error(`P19.6 focused test missing: ${token}`);
}

console.log('P19.6 Risk/Reward logical chart-object projection verification passed.');
