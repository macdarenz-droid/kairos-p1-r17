import { readFileSync } from 'node:fs';

const load = readFileSync(new URL('../src/application/saved-analysis/loadSavedAnalysis.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/application/saved-analysis/index.ts', import.meta.url), 'utf8');
const test = readFileSync(new URL('../tests/saved-analysis-load-query.test.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P20_4_SAVED_ANALYSIS_APPLICATION_LOAD_ORCHESTRATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');

for (const token of [
  "import type { SavedAnalysis, SavedAnalysisId } from '../../app/savedAnalysisContract'",
  "import { createKairosRepositories } from '../../data/repositories'",
  'savedAnalyses.get(savedAnalysisId)',
  "type: 'not-found'",
  "reason: 'saved-analysis-not-found'",
  "type: 'storage-error'",
  "reason: 'saved-analysis-load-failed'",
  'savedAnalysis: structuredClone(record)',
]) {
  if (!load.includes(token)) throw new Error(`P20.4 load orchestration evidence missing: ${token}`);
}

for (const forbidden of [
  'LightweightCharts',
  'listAll(',
  '.delete(',
  '.put(',
  'runKairosAtomicWrite',
  'timeframe',
  'createdAt',
  'updatedAt',
  'name:',
]) {
  if (load.includes(forbidden)) throw new Error(`P20.4 load orchestration contains forbidden scope: ${forbidden}`);
}

if (!index.includes("export * from './loadSavedAnalysis'")) {
  throw new Error('P20.4 application export evidence missing');
}

for (const token of [
  'P20.4 Saved Analysis application load orchestration',
  'canonical stable id',
  'saved-analysis-not-found',
  'saved-analysis-load-failed',
]) {
  if (!test.includes(token)) throw new Error(`P20.4 focused test evidence missing: ${token}`);
}

for (const token of [
  '# KAIROS P20.4 — Saved Analysis Application Load Orchestration',
  'P20.3',
  'SavedAnalysisRepository.get',
  'No UI',
  'No list/update/delete orchestration',
]) {
  if (!report.includes(token)) throw new Error(`P20.4 report evidence missing: ${token}`);
}

console.log('P20.4 Saved Analysis application load orchestration verification passed.');
