import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hBrowserPublicRestBaselineStateSessionScopedSnapshotAcquisitionComposition.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_23_LIVE_MARKET_SUMMARY_BROWSER_STATE_SESSION_SCOPED_SNAPSHOT_ACQUISITION_COMPOSITION_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');
for (const token of [
  'acquireBinanceSpot24hBrowserPublicRestBaselineIntoSession(',
  'readLiveMarketSummaryStateSessionScopedSnapshot(session, scope)',
  'const orchestrationResult = await acquireBinanceSpot24hBrowserPublicRestBaselineIntoSession',
  'const scopedSnapshot = readLiveMarketSummaryStateSessionScopedSnapshot(session, scope)',
  'return { orchestrationResult, scopedSnapshot }',
]) if (!source.includes(token)) throw new Error(`P21.23 composition evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpot24hBrowserPublicRestBaselineStateSessionScopedSnapshotAcquisitionComposition';")) throw new Error('P21.23 composition export missing');
const acquireCalls = (source.match(/acquireBinanceSpot24hBrowserPublicRestBaselineIntoSession\(/g) || []).length;
const readCalls = (source.match(/readLiveMarketSummaryStateSessionScopedSnapshot\(session, scope\)/g) || []).length;
if (acquireCalls !== 1) throw new Error(`P21.23 must invoke released P21.20 exactly once, found ${acquireCalls}`);
if (readCalls !== 1) throw new Error(`P21.23 must invoke released P21.22 exactly once, found ${readCalls}`);
const acquireAt = source.indexOf('const orchestrationResult = await acquireBinanceSpot24hBrowserPublicRestBaselineIntoSession');
const readAt = source.indexOf('const scopedSnapshot = readLiveMarketSummaryStateSessionScopedSnapshot(session, scope)');
if (acquireAt < 0 || readAt <= acquireAt) throw new Error('P21.23 scoped read must occur only after released P21.20 fulfillment');
for (const forbidden of [
  '.sort(', '.filter(', '.reduce(', 'new Map(', 'new Set(',
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'XMLHttpRequest',
  'WebSocket(', 'indexedDB', 'new AbortController(', 'createChart(',
]) if (source.includes(forbidden)) throw new Error(`P21.23 broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'no production owner composing those seams',
  'Invoke released P21.20 exactly once',
  'Only after P21.20 fulfills, invoke released P21.22 exactly once',
  'perform no scoped read',
  'No universe/default symbols/default scope/scope discovery',
  'No Live Crypto Bubble Map sizing/color/geometry/interactions/animation or Home wiring',
  'No persistence/IndexedDB/repository/schema/backup/journal/Saved Analysis/chart ownership',
]) if (!report.includes(token)) throw new Error(`P21.23 report evidence missing: ${token}`);
console.log('P21.23 Live Market Summary Browser State Session Scoped Snapshot Acquisition Composition verification passed.');
