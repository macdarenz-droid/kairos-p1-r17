import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hBrowserPublicRestBaselineStateSessionBinding.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_20_LIVE_MARKET_SUMMARY_BROWSER_STATE_SESSION_BINDING_FOUNDATION_REPORT_2026-09-08.md', import.meta.url), 'utf8');
for (const token of [
  'LiveMarketSummaryStateSession',
  'acquireBinanceSpot24hBrowserPublicRestBaselineIntoSession(',
  'await session.transition(async (state) =>',
  'acquireBinanceSpot24hBrowserPublicRestBaselineIntoState(',
  'orchestrationResult = result',
  'return result.state',
  'return orchestrationResult',
]) if (!source.includes(token)) throw new Error(`P21.20 binding evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpot24hBrowserPublicRestBaselineStateSessionBinding';")) throw new Error('P21.20 browser state session binding export missing');
for (const forbidden of [
  'globalThis.fetch(', 'fetch(', 'XMLHttpRequest', 'WebSocket(', 'Response(', 'JSON.parse(',
  'Date.now(', 'new Date(', 'setTimeout(', 'setInterval(', 'indexedDB', '.sort(', 'createChart(',
  'createLiveMarketSummaryStateSession(', 'applyLiveMarketSummaryDeliveryState(',
]) if (source.includes(forbidden)) throw new Error(`P21.20 broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'Released P21.18 owns the browser-ready one-shot',
  'Released P21.19 owns `LiveMarketSummaryStateSession`',
  'no production owner composing these released seams',
  'Execute exactly one explicit P21.19 session transition',
  'Commit only released P21.18 `result.state`',
  'No universe/default symbols/scope selection',
  'No persistence/IndexedDB/repository/schema/backup',
  'No UI reactivity/subscription framework choice',
]) if (!report.includes(token)) throw new Error(`P21.20 report evidence missing: ${token}`);
console.log('P21.20 Live Market Summary Browser State Session Binding verification passed.');
