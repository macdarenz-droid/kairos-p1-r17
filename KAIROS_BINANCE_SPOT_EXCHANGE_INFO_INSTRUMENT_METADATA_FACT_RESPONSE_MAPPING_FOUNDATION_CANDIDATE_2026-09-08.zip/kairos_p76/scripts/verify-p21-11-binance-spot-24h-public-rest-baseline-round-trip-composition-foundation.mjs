import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hPublicRestBaselineRoundTrip.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_11_BINANCE_SPOT_24H_PUBLIC_REST_BASELINE_ROUND_TRIP_COMPOSITION_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');
for (const token of [
  'composeBinanceSpot24hPublicRestBaselineRoundTrip',
  'describeBinanceSpot24hPublicRestBaselineRequest(scope)',
  'executeBinanceSpot24hPublicRestBaselineRequest(described.request, connect)',
  'mapBinanceSpot24hPublicRestBaselineResponseDelivery(scope, data, observedAt)',
  'BinanceSpot24hPublicRestBaselineRequestConnector<unknown>',
]) if (!source.includes(token)) throw new Error(`P21.11 round-trip evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpot24hPublicRestBaselineRoundTrip';")) throw new Error('P21.11 barrel export missing');
for (const forbidden of ['fetch(', 'XMLHttpRequest', 'WebSocket(', 'new Response(', 'AbortSignal', 'acquireBaseline(', 'setTimeout(', 'requestWeight', 'indexedDB']) {
  if (source.includes(forbidden)) throw new Error(`P21.11 broadened into forbidden scope: ${forbidden}`);
}
for (const token of ['No concrete fetch/XHR/WebSocket/browser transport', 'No P21.4 acquisition-port implementation', 'no AbortSignal handling', 'No new request, decode, ticker mapping or completeness algorithms', 'No scope/universe selection/ranking', 'No Bubble/Your-Trades/Home/persistence/transitions']) {
  if (!report.includes(token)) throw new Error(`P21.11 report evidence missing: ${token}`);
}
console.log('P21.11 Binance Spot 24h public REST baseline round-trip composition verification passed.');
