import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/services/market-data/providers/binance/binanceSpot24hPublicRestBaselineResponseDelivery.ts', import.meta.url), 'utf8');
const index = readFileSync(new URL('../src/services/market-data/index.ts', import.meta.url), 'utf8');
const report = readFileSync(new URL('../KAIROS_P21_10_BINANCE_SPOT_24H_PUBLIC_REST_BASELINE_RESPONSE_DELIVERY_COMPOSITION_FOUNDATION_REPORT_2026-09-07.md', import.meta.url), 'utf8');
for (const token of [
  'BinanceSpot24hPublicRestBaselineResponseDeliveryResult',
  'mapBinanceSpot24hPublicRestBaselineResponseDelivery',
  'decodeBinanceSpot24hPublicRestBaselineResponse(data)',
  'mapBinanceSpot24hBaselineDelivery(scope, decoded.payload, observedAt)',
  'MarketDataInstrument',
  'LiveMarketSummaryCompleteForScopeDelivery',
]) if (!source.includes(token)) throw new Error(`P21.10 response-delivery evidence missing: ${token}`);
if (!index.includes("export * from './providers/binance/binanceSpot24hPublicRestBaselineResponseDelivery';")) throw new Error('P21.10 barrel export missing');
for (const forbidden of [
  'fetch(', 'XMLHttpRequest', 'WebSocket(', 'new Response(',
  'executeBinanceSpot24hPublicRestBaselineRequest(',
  'describeBinanceSpot24hPublicRestBaselineRequest(',
  'acquireBaseline(', 'AbortSignal', 'indexedDB', 'setTimeout(', 'requestWeight',
]) if (source.includes(forbidden)) throw new Error(`P21.10 broadened into forbidden scope: ${forbidden}`);
for (const token of [
  'No request description or request execution',
  'No concrete fetch/XHR/WebSocket/browser transport',
  'No new ticker-field validation',
  'No scope/universe selection or ranking',
  'No concrete P21.4 acquisition-port adapter orchestration',
  'No persistence',
]) if (!report.includes(token)) throw new Error(`P21.10 report evidence missing: ${token}`);
console.log('P21.10 Binance Spot 24h public REST baseline response delivery composition verification passed.');
