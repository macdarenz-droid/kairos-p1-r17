import fs from 'node:fs';

const sourceFile = 'src/domain/calculations/feeCalculator.ts';
const testFile = 'tests/fee-currency-evidence.test.ts';

for (const file of [sourceFile, testFile]) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}

const source = fs.readFileSync(sourceFile, 'utf8');

for (const token of [
  'calculateTotalFees',
  'readonly currency: string | null',
  'currency: null',
  'fee.currency',
  "'mixed-currency'",
  'decimalSum',
]) {
  if (!source.includes(token)) {
    throw new Error(`Missing P11.17 fee-currency evidence contract: ${token}`);
  }
}

if (/Number\s*\(|parseFloat\s*\(|parseInt\s*\(|Math\./.test(source)) {
  throw new Error('P11.17 must preserve locked decimal arithmetic.');
}

for (const forbidden of [
  'exchangeRate',
  'currencyConversion',
  'calculateNetPnl',
  'TradeMetrics',
  'pnlPercent',
  'realizedR',
  'Dexie',
  'indexedDB',
  'localStorage',
  'sessionStorage',
  'fetch(',
  'WebSocket',
]) {
  if (source.includes(forbidden)) {
    throw new Error(`P11.17 out-of-scope owner detected: ${forbidden}`);
  }
}

console.log('P11.17 fee currency evidence verification PASS');
