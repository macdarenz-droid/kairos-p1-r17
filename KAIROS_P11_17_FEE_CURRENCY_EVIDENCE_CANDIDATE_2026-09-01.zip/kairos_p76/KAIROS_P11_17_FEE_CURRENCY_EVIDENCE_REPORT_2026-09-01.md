# KAIROS P11.17 Fee Currency Evidence Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P11.16 authoritative PASS from controlled gate run #37, artifact 9798274943.

## Objective
Close the currency-evidence gap before any TradeMetrics fee/net-P&L composition.

The locked handoff requires fee records to carry currency, derived metrics to come from the Calculation Engine, and missing FX data never to be silently treated as 1.0. fileciteturn106file5

## Change
The existing `calculateTotalFees` success result now returns:
- `totalFees`
- `currency`

For a non-empty same-currency fee set, currency is the authoritative fee currency.
For an authoritative empty fee set, totalFees is exactly `0` and currency is `null`.
Mixed currencies remain an explicit failure.

## Why this precedes TradeMetrics wiring
P11.16 can only subtract fees from gross P&L when both represent the same monetary unit. Without fee currency evidence, the next composition patch could silently subtract unlike currencies.

## Non-scope
- no FX conversion;
- no assumption that missing FX equals 1;
- no TradeMetrics wiring;
- no net-P&L composition;
- no P&L percentage;
- no persistence/schema/UI work.

## Result
HOLD pending canonical GitHub gate.
