# KAIROS P11.1 Decimal Calculation Kernel Report — 2026-09-01

## Status
HOLD pending canonical GitHub gate.

## Base
P10.3R2 authoritative PASS artifact from run #17 (`1deadbc172cf2bf54f02fddf4a03c0b99c6e6b65`).

## Objective
Start P11 Calculation Brain with one authoritative decimal-arithmetic kernel before any P&L, R-multiple, leverage, or visual metric logic is added.

## Research
Current decimal.js 10.6.0 documentation confirms arbitrary-precision decimal arithmetic, recommends string inputs to avoid JavaScript Number precision loss, supports independent cloned constructors, and rounds calculations according to configured precision/rounding.

## Owner trace
Canonical DecimalString validation (P9) -> P11 decimal kernel -> future P11 derived metric functions -> later P13/P14 renderers.

## Change
- Adds decimal.js 10.6.0 as a direct locked production dependency.
- Adds a P11-owned cloned 40-significant-digit Decimal context using ROUND_HALF_UP.
- Adds pure add/subtract/multiply/divide/abs/sum operations returning canonical DecimalString results.
- Rejects malformed decimal strings and division by zero explicitly.
- Normalizes negative zero to canonical `0`.

## Non-scope
No P&L, R, leverage, fee conversion, FX conversion, UI, persistence, schema, repository, trade-save, activation, market API, history, or visual changes.

## Persistence / offline / security
No persistence or network behavior. Pure local deterministic arithmetic only.

## Tests
Precision drift, high-precision string input, signed arithmetic, negative-zero normalization, multiplication/division, divide-by-zero, malformed input, exact summation.

## Result
HOLD until canonical GitHub gate passes build, full unit regression, P1-P10.3R2 regressions, and P11.1 verification.
